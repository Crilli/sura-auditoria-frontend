package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.puertos.RepositorioTrazaAuditoria;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Traza de auditoría del perfil local: en memoria y acotada, sin base de datos.
 * Evita depender de MySQL para levantar el servicio en un portátil.
 */
@Component
@Profile("local")
public class TrazaAuditoriaSimulada implements RepositorioTrazaAuditoria {

    /** Tope de eventos conservados por cuenta; los más antiguos se descartan. */
    private static final int MAXIMO_POR_CUENTA = 200;

    private final Map<String, List<EventoAuditoria>> eventos = new ConcurrentHashMap<>();

    @Override
    public Mono<EventoAuditoria> guardar(EventoAuditoria evento) {
        return Mono.fromCallable(() -> {
            eventos.compute(evento.codigoCuenta(), (codigo, existentes) -> {
                var lista = existentes == null ? new ArrayList<EventoAuditoria>() : new ArrayList<>(existentes);
                lista.add(evento);
                return lista.size() > MAXIMO_POR_CUENTA
                        ? List.copyOf(lista.subList(lista.size() - MAXIMO_POR_CUENTA, lista.size()))
                        : List.copyOf(lista);
            });
            return evento;
        });
    }

    @Override
    public Flux<EventoAuditoria> buscarPorCuenta(String codigoCuenta, int limite) {
        return Flux.defer(() -> Flux.fromIterable(eventos.getOrDefault(codigoCuenta, List.of()))
                .sort(Comparator.comparing(EventoAuditoria::ocurridoEn).reversed())
                .take(limite));
    }
}
