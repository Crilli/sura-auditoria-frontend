package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Construye el catálogo de cuentas simuladas.
 *
 * <p>La generación es <b>determinista por fórmula</b>: no usa aleatoriedad, así que
 * el mismo arranque produce siempre las mismas cuentas, líneas, novedades y pendientes.
 * Las reglas están documentadas en el README (sección «Perfil local»), de modo que un
 * cliente puede saber de antemano qué línea está bloqueada o cuál tiene novedad bloqueante.
 */
final class GeneradorCuentasSimuladas {

    /** Base de la referencia de línea; la línea n de la cuenta c es BASE + c·1.000.000 + n. */
    private static final long BASE_REFERENCIA_LINEA = 90_114_522L;
    private static final long BASE_IDENTIFICADOR_PENDIENTE_CABECERA = 77_000L;
    private static final long BASE_IDENTIFICADOR_PENDIENTE_LINEA    = 780_000L;
    private static final long BASE_IDENTIFICADOR_NOVEDAD            = 55_000L;
    private static final long BASE_AFILIADO                         = 483_921L;

    private static final LocalDate FECHA_BASE = LocalDate.of(2026, 5, 4);

    /** Cuántos afiliados distintos comparten una misma cuenta (agrupados por bloques de líneas). */
    private static final int LINEAS_POR_AFILIADO = 150;

    private static final BigDecimal FACTOR_COBERTURA = new BigDecimal("0.90");

    /**
     * Escenarios de la batería: estado inicial, pendientes de cabecera, periodicidad de
     * pendientes de línea y desenlace del envío. Se recorren con módulo, así que la
     * batería sigue siendo coherente si se cambia {@code simulador.local.cantidad-cuentas}.
     */
    private record Escenario(EstadoCuenta estado, int pendientesCabecera,
                             int periodoPendienteLinea, boolean elEnvioFalla) {}

    private static final List<Escenario> ESCENARIOS = List.of(
            // Envío bloqueado por pendientes: hay que resolverlos antes de enviar.
            new Escenario(EstadoCuenta.ADJUDICACION_MANUAL,            2, 23, false),
            // Camino feliz: sin pendientes, se puede enviar de inmediato.
            new Escenario(EstadoCuenta.MODIFICACION,                   0,  0, false),
            // Un pendiente de cabecera y ninguno de línea.
            new Escenario(EstadoCuenta.TARIFACION_MANUAL,              1,  0, false),
            // Solo pendientes de línea, espaciados.
            new Escenario(EstadoCuenta.BENEFICIOS_MANUALES,            0, 37, false),
            new Escenario(EstadoCuenta.TARIFACION_ADJUDICACION_MANUAL, 2, 53, false),
            new Escenario(EstadoCuenta.ADJUDICACION_MANUAL,            1, 23, false),
            // Segundo camino feliz.
            new Escenario(EstadoCuenta.MODIFICACION,                   0,  0, false),
            // Se puede enviar, pero el proceso termina en FALLIDO.
            new Escenario(EstadoCuenta.ADJUDICACION_MANUAL,            0,  0, true),
            // Estados sin intervención manual: ENVIAR y RESOLVER_* no están disponibles.
            new Escenario(EstadoCuenta.TARIFACION_COMPLETA,            0,  0, false),
            new Escenario(EstadoCuenta.FINALIZADA,                     0,  0, false));

    private GeneradorCuentasSimuladas() {}

    /** @return catálogo indexado por código de cuenta, en orden de generación. */
    static Map<String, CuentaSimulada> generar(PropiedadesSimulador propiedades) {
        var catalogo = new LinkedHashMap<String, CuentaSimulada>();
        for (int indice = 0; indice < propiedades.cantidadCuentas(); indice++) {
            var cuenta = generarCuenta(indice, propiedades);
            catalogo.put(cuenta.codigo().valor(), cuenta);
        }
        return Map.copyOf(catalogo);
    }

    private static CuentaSimulada generarCuenta(int indice, PropiedadesSimulador propiedades) {
        var escenario = ESCENARIOS.get(indice % ESCENARIOS.size());
        var codigo    = new CodigoCuenta(
                propiedades.prefijoCuenta() + (propiedades.primerConsecutivo() + indice));

        int cantidadLineas = cantidadLineas(indice, propiedades);
        var fechaInicio    = FECHA_BASE.plusDays(indice * 7L);
        var fechaFin       = fechaInicio.plusDays(5);

        var cuenta = new CuentaSimulada(
                codigo, fechaInicio, fechaFin,
                escenario.estado(), accionesPara(escenario.estado()),
                1L,
                pendientesDeCabecera(indice, escenario.pendientesCabecera()),
                escenario.elEnvioFalla(),
                informacionFacturacionDe(indice, codigo, fechaInicio, fechaFin, cantidadLineas));

        long referenciaBase = BASE_REFERENCIA_LINEA + (long) indice * 1_000_000L;
        for (int numero = 1; numero <= cantidadLineas; numero++) {
            cuenta.agregarLinea(generarLinea(indice, numero, referenciaBase + numero,
                    codigo, fechaInicio, escenario));
        }
        return cuenta;
    }

    /**
     * Reparte la cantidad de líneas de forma pareja dentro del rango configurado,
     * de manera que todas las cuentas queden entre el mínimo y el máximo.
     */
    private static int cantidadLineas(int indice, PropiedadesSimulador propiedades) {
        long desplazamiento = (long) (indice % propiedades.cantidadCuentas())
                * propiedades.rangoLineas() / propiedades.cantidadCuentas();
        return propiedades.minimoLineas() + (int) desplazamiento;
    }

    private static Set<AccionCuenta> accionesPara(EstadoCuenta estado) {
        if (estado.permiteIntervencionManual())
            return Set.of(AccionCuenta.ENVIAR,
                          AccionCuenta.SEGUIR_PROCESO,
                          AccionCuenta.RESOLVER_PENDIENTE,
                          AccionCuenta.RESOLVER_PENDIENTE_LINEA,
                          AccionCuenta.DEVOLVER_A_MODIFICACION,
                          AccionCuenta.DESBLOQUEAR_LINEAS,
                          AccionCuenta.DESHACER_REEMPLAZOS);

        return estado == EstadoCuenta.FINALIZADA
                ? Set.of(AccionCuenta.SEGUIR_PROCESO, AccionCuenta.REVERTIR_FINALIZACION)
                : Set.of(AccionCuenta.SEGUIR_PROCESO, AccionCuenta.DEVOLVER_A_MODIFICACION);
    }

    /**
     * Ficha de facturación de la cuenta.
     *
     * <p>Los valores monetarios son proporcionales a la cantidad de líneas, no una
     * suma exacta de ellas: en la vida real el valor facturado por el prestador y
     * el valor auditado tampoco coinciden centavo a centavo, así que replicar esa
     * diferencia es más realista que forzar que cuadren.
     */
    private static InformacionFacturacion informacionFacturacionDe(
            int indice, CodigoCuenta codigo, LocalDate fechaInicio, LocalDate fechaFin,
            int cantidadLineas) {

        var prestador = CatalogoSimulado.PRESTADORES.get(indice % CatalogoSimulado.PRESTADORES.size());
        var tarifaPromedio = new BigDecimal("185000.00");
        var valorFactura = tarifaPromedio.multiply(BigDecimal.valueOf(cantidadLineas))
                .setScale(2, RoundingMode.HALF_UP);
        // El IVA y los ajustes de radicación elevan el total frente al valor base de la factura.
        var valorTotalFactura = valorFactura.multiply(new BigDecimal("1.05")).setScale(2, RoundingMode.HALF_UP);
        var totalValorGlosado = valorFactura.multiply(new BigDecimal("0.03")).setScale(2, RoundingMode.HALF_UP);
        var valorNotaCredito  = indice % 4 == 0
                ? valorFactura.multiply(new BigDecimal("0.01")).setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);

        return new InformacionFacturacion(
                prestador.nit(),
                "FE-%06d".formatted(BASE_IDENTIFICADOR_NOVEDAD + indice),
                codigo.valor(),
                fechaInicio.minusDays(3),          // fechaRadicacion: llega unos días después de prestado el servicio
                fechaInicio.minusDays(2),           // fechaEmision de la factura
                fechaInicio.plusDays(30),           // fechaVencimiento: 30 días desde el inicio de la cuenta
                fechaInicio,                        // fechaIngreso de la atención
                fechaFin,                           // fechaEgreso de la atención
                valorFactura,
                valorTotalFactura,
                valorFactura,                        // totalCargado: lo que el prestador cobró
                null,                                // totalConvenido: sin fuente en OHI
                totalValorGlosado,
                valorNotaCredito,
                CatalogoSimulado.TIPOS_SERVICIO.get(indice % CatalogoSimulado.TIPOS_SERVICIO.size()),
                indice % 3 == 0 ? "Sí" : "No",       // acuseRecibido
                indice % 5 == 0 ? "Sí" : "No",       // marcaRadicadoAtep
                indice % 6 == 0 ? "Sí" : "No",       // marcaMulticore
                indice % 2 == 0 ? "Sí" : "No",       // marcaPendienteManual
                "Radicación simulada #%d — sin novedades de trámite.".formatted(indice + 1),
                "Cuenta en revisión de auditoría; sujeta a ajustes de tarifación y beneficios.",
                prestador.nit());
    }

    private static List<MotivoPendiente> pendientesDeCabecera(int indice, int cantidad) {
        var pendientes = new ArrayList<MotivoPendiente>(cantidad);
        for (int k = 0; k < cantidad; k++) {
            var plantilla = CatalogoSimulado.PENDIENTES_CABECERA
                    .get(k % CatalogoSimulado.PENDIENTES_CABECERA.size());
            pendientes.add(new MotivoPendiente(
                    BASE_IDENTIFICADOR_PENDIENTE_CABECERA + indice * 100L + (k + 1),
                    plantilla.codigo(), plantilla.descripcion(),
                    false, plantilla.soloAdjudicacion(),
                    NivelPendiente.CABECERA, null, null, new Version(1L)));
        }
        return List.copyOf(pendientes);
    }

    private static LineaCuenta generarLinea(int indiceCuenta, int numero, long referencia,
                                            CodigoCuenta codigo, LocalDate fechaInicioCuenta,
                                            Escenario escenario) {

        var procedimiento = CatalogoSimulado.PROCEDIMIENTOS
                .get((numero - 1 + indiceCuenta) % CatalogoSimulado.PROCEDIMIENTOS.size());

        var unidadesAutorizadas = BigDecimal.valueOf(1 + ((numero - 1) % 3));
        var valorAutorizado     = procedimiento.tarifa()
                .multiply(unidadesAutorizadas)
                .setScale(2, RoundingMode.HALF_UP);

        boolean bloqueada   = numero % 97 == 0;
        boolean reemplazada = numero % 89 == 0;

        var novedades = novedadesDe(indiceCuenta, numero);
        boolean tieneBloqueante = novedades.stream()
                .anyMatch(n -> n.severidad() == Severidad.BLOQUEANTE);

        var valorCubierto = (tieneBloqueante || bloqueada || reemplazada)
                ? BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
                : valorAutorizado.multiply(FACTOR_COBERTURA).setScale(2, RoundingMode.HALF_UP);

        var unidadesCubiertas = valorCubierto.signum() == 0
                ? BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
                : unidadesAutorizadas;

        var afiliado = "AF-%08d".formatted(
                BASE_AFILIADO + indiceCuenta * 137L + ((numero - 1) / LINEAS_POR_AFILIADO));

        var fechaPrestacion = fechaInicioCuenta.plusDays((numero - 1) % 6);

        return new LineaCuenta(
                new ReferenciaLinea(referencia), codigo, numero,
                fechaPrestacion, fechaPrestacion,
                afiliado, nombreAfiliadoSimulado(afiliado),
                procedimiento.codigo(), procedimiento.descripcion(), "CUPS",
                valorAutorizado, unidadesAutorizadas,
                valorCubierto, unidadesCubiertas,
                valorAutorizado, unidadesAutorizadas,   // cargado = autorizado en el simulador
                BigDecimal.ZERO, null,                   // sin glosa
                "AUT-%06d".formatted(referencia % 1_000_000),
                "8110078325-001", "IPS SURA SIMULADA",
                false, false,
                numero % 13 == 0,          // beneficiosManuales
                numero % 11 == 0,          // tarifacionManual
                bloqueada, reemplazada,
                new Prestacion(procedimiento.codigo(), procedimiento.descripcion(), "CUPS",
                               null, null, null, "Ambulatorio", "Medicina general"),
                new DatosConvenio(null, null, null, "CONTRATO-SIM-001", null, null, null,
                                  valorAutorizado, "Tarifa simulada de contrato"),
                new OtrosDatosLinea("Sala general", "Ambulatoria", "UEN-SIM", null),
                List.of(new DiagnosticoLinea(1, "PRINCIPAL", "Diagnóstico principal",
                                             "S626", "FRACTURA DE OTRO DEDO DE LA MANO")),
                List.of(),
                novedades,
                pendientesDeLinea(indiceCuenta, numero, referencia, escenario),
                new Version(1L + (numero % 5)));
    }

    /** Nombres de pega para el perfil local, estables para un mismo afiliado. */
    private static final List<String> NOMBRES_SIMULADOS = List.of(
            "ANA MARIA GOMEZ RESTREPO", "CARLOS ANDRES MUNOZ VELEZ",
            "LUZ ADRIANA TORRES PALACIO", "JUAN SEBASTIAN RIOS CARDONA",
            "MARTHA LUCIA ARANGO OSPINA", "DIEGO FERNANDO LOPEZ MEJIA",
            "SANDRA PATRICIA CASTANO RUIZ", "JORGE ENRIQUE VALENCIA SOTO");

    private static String nombreAfiliadoSimulado(String codigoAfiliado) {
        return NOMBRES_SIMULADOS.get(Math.abs(codigoAfiliado.hashCode()) % NOMBRES_SIMULADOS.size());
    }

    /**
     * Novedades por periodicidad: bloqueante cada 7 líneas, advertencia cada 5,
     * informativa cada 17. Una línea puede acumular varias.
     */
    private static List<Novedad> novedadesDe(int indiceCuenta, int numero) {
        var novedades = new ArrayList<Novedad>(3);
        long base = BASE_IDENTIFICADOR_NOVEDAD + indiceCuenta * 1_000_000L + numero * 10L;

        if (numero % 7 == 0)
            novedades.add(aNovedad(base + 1, CatalogoSimulado.NOVEDADES_BLOQUEANTES
                    .get((numero / 7) % CatalogoSimulado.NOVEDADES_BLOQUEANTES.size())));

        if (numero % 5 == 0)
            novedades.add(aNovedad(base + 2, CatalogoSimulado.NOVEDADES_ADVERTENCIA
                    .get((numero / 5) % CatalogoSimulado.NOVEDADES_ADVERTENCIA.size())));

        if (numero % 17 == 0)
            novedades.add(aNovedad(base + 3, CatalogoSimulado.NOVEDADES_INFORMATIVAS
                    .get((numero / 17) % CatalogoSimulado.NOVEDADES_INFORMATIVAS.size())));

        return List.copyOf(novedades);
    }

    /**
     * <p>Usa el constructor completo y no el reducido: el reducido deja
     * {@code esDelSistema} en falso y los valores vacíos, y entonces el perfil
     * local nunca enseña ni el distintivo de sistema ni un texto compuesto a
     * partir de sus marcadores, que son justamente dos de las cosas que la
     * pantalla pinta.
     */
    private static Novedad aNovedad(long identificador, CatalogoSimulado.PlantillaNovedad plantilla) {
        return new Novedad(identificador, plantilla.codigo(), plantilla.descripcion(),
                plantilla.severidad(), plantilla.origen(),
                null, null, "motor.local", java.time.Instant.now(),
                plantilla.esDelSistema(), plantilla.valores());
    }

    private static List<MotivoPendiente> pendientesDeLinea(int indiceCuenta, int numero,
                                                           long referencia, Escenario escenario) {
        int periodo = escenario.periodoPendienteLinea();
        if (periodo <= 0 || numero % periodo != 0) return List.of();

        var plantilla = CatalogoSimulado.PENDIENTES_LINEA
                .get((numero / periodo) % CatalogoSimulado.PENDIENTES_LINEA.size());

        return List.of(new MotivoPendiente(
                BASE_IDENTIFICADOR_PENDIENTE_LINEA + indiceCuenta * 10_000L + numero,
                plantilla.codigo(), plantilla.descripcion(),
                false, plantilla.soloAdjudicacion(),
                NivelPendiente.LINEA, new ReferenciaLinea(referencia), numero, new Version(1L)));
    }
}
