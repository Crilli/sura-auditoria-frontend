package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListMap;

/**
 * Estado mutable en memoria de una cuenta médica simulada.
 *
 * <p>Hace el papel que en los demás perfiles cumple OHI: es la autoridad sobre el
 * estado, las acciones disponibles, las versiones y el resultado del envío.
 * Todas las mutaciones están sincronizadas sobre la instancia; el perfil local
 * no busca rendimiento sino comportamiento reproducible.
 */
public final class CuentaSimulada {

    /** Porcentaje del valor autorizado que queda cubierto al recalcular en cascada. */
    private static final BigDecimal FACTOR_COBERTURA = new BigDecimal("0.90");

    private final CodigoCuenta codigo;
    private final LocalDate fechaInicio;
    private final LocalDate fechaFin;
    private final EstadoCuenta estadoInicial;
    private final Set<AccionCuenta> accionesIniciales;
    /** Marca la cuenta cuyo proceso de envío simulado termina en FALLIDO. */
    private final boolean elEnvioFalla;
    private final InformacionFacturacion informacionFacturacion;

    private final NavigableMap<Long, LineaCuenta> lineas = new ConcurrentSkipListMap<>();

    private EstadoCuenta estado;
    private Set<AccionCuenta> acciones;
    private long version;
    private List<MotivoPendiente> pendientesCabecera;
    /** Novedades de la cabecera. Mutable: el auditor las pone y las quita. */
    private List<Novedad> novedadesCabecera = sembrarNovedadesDeCabecera();

    /**
     * Siembra la cabecera con las del catálogo simulado.
     *
     * <p>Sin esto, en el perfil local la tabla de novedades de la cuenta sale
     * siempre vacía y no hay forma de probar la pantalla —ni el rechazo de la
     * baja de una del motor— sin el sistema real.
     */
    private static List<Novedad> sembrarNovedadesDeCabecera() {
        long id = 9_000;
        var sembradas = new ArrayList<Novedad>();
        for (var p : CatalogoSimulado.NOVEDADES_CABECERA) {
            sembradas.add(new Novedad(++id, p.codigo(), p.descripcion(), p.severidad(),
                                      p.origen(), null, null,
                                      Novedad.ORIGEN_MANUAL.equals(p.origen())
                                              ? "carlpase" : "Internal System User",
                                      java.time.Instant.now(), false, Map.of()));
        }
        return List.copyOf(sembradas);
    }

    private Proceso proceso;
    private boolean desenlaceAplicado;

    private record Proceso(String referencia, Instant inicio) {}

    CuentaSimulada(CodigoCuenta codigo, LocalDate fechaInicio, LocalDate fechaFin,
                   EstadoCuenta estado, Set<AccionCuenta> acciones, long version,
                   List<MotivoPendiente> pendientesCabecera, boolean elEnvioFalla,
                   InformacionFacturacion informacionFacturacion) {
        this.codigo                 = codigo;
        this.fechaInicio            = fechaInicio;
        this.fechaFin               = fechaFin;
        this.estadoInicial          = estado;
        this.accionesIniciales      = Set.copyOf(acciones);
        this.estado                 = estado;
        this.acciones               = Set.copyOf(acciones);
        this.version                = version;
        this.pendientesCabecera     = List.copyOf(pendientesCabecera);
        this.elEnvioFalla           = elEnvioFalla;
        this.informacionFacturacion = informacionFacturacion;
    }

    void agregarLinea(LineaCuenta linea) {
        lineas.put(linea.referencia().valor(), linea);
    }

    public CodigoCuenta codigo() {
        return codigo;
    }

    /**
     * Estado actual. Lo pide la gestión de pendientes, que necesita saber qué
     * bloquea el envío sin construir la cabecera entera para averiguarlo.
     */
    public synchronized EstadoCuenta estado() {
        return estado;
    }

    // ── Consultas ────────────────────────────────────────────────────────────

    public synchronized CuentaMedica cabecera() {
        return new CuentaMedica(codigo, estado, fechaInicio, fechaFin,
                totalAutorizado(), totalCubierto(), new Version(version),
                pendientesCabecera, novedadesCabecera, informacionFacturacion);
    }

    /**
     * Aplica altas y bajas de novedad sobre la cabecera.
     *
     * <p>Reproduce el efecto, no la mecánica del {@code op}, igual que
     * {@link #aplicarCambiosDeNovedadDeCabecera(List, EdicionLinea)} hace con las de
     * línea. La baja no comprueba el origen: de eso se ocupa el caso de uso,
     * que es común a los dos perfiles.
     *
     * <p>Sube la versión de la cuenta, que es lo que hace el sistema de
     * registro: se midió que un alta de novedad la mueve.
     */
    public synchronized CuentaMedica aplicarCambiosDeNovedadDeCabecera(List<CambioNovedad> cambios) {
        novedadesCabecera = aplicarCambiosDeNovedadDeCabecera(novedadesCabecera,
                new ArrayList<>(cambios));
        version++;
        return cabecera();
    }

    /**
     * Aplica una de las acciones habilitadas, moviendo el estado como lo haría
     * el sistema de registro.
     *
     * <p>Reproduce la máquina de estados que documenta el repositorio: anular
     * lleva a CANCELADA, que es <b>terminal</b>; devolver a modificación lleva a
     * MODIFICACION; revertir la finalización saca de FINALIZADA. Sin esto el
     * perfil local dejaría pulsar los botones sin que pasara nada, que es la
     * peor forma de dar algo por probado.
     */
    public synchronized CuentaMedica ejecutarAccion(EjecucionAccion ejecucion) {
        estado = switch (ejecucion.accion()) {
            case ANULAR                         -> EstadoCuenta.ANULADA;
            case DEVOLVER_A_MODIFICACION        -> EstadoCuenta.MODIFICACION;
            case REVERTIR_FINALIZACION          -> EstadoCuenta.MODIFICACION;
            case DEVOLVER_A_BENEFICIOS_MANUALES -> EstadoCuenta.BENEFICIOS_MANUALES;
            case DEVOLVER_A_TARIFACION_MANUAL   -> EstadoCuenta.TARIFACION_MANUAL;
            // Desbloquear líneas y deshacer reemplazos no mueven el estado.
            default                             -> estado;
        };

        if (ejecucion.accion() == AccionCuenta.DESBLOQUEAR_LINEAS) desbloquearLineas(ejecucion.lineas());

        // Una cuenta anulada no admite ya ninguna acción: es terminal.
        if (estado == EstadoCuenta.ANULADA) acciones = java.util.Set.of();

        version++;
        return cabecera();
    }

    /** Quita la marca de bloqueo. Lista vacía = todas, como hace el sistema real. */
    private void desbloquearLineas(List<Long> referencias) {
        for (var clave : List.copyOf(lineas.keySet())) {
            var linea = lineas.get(clave);
            if (!linea.bloqueada()) continue;
            if (!referencias.isEmpty() && !referencias.contains(linea.referencia().valor())) continue;
            lineas.put(clave, sinBloqueo(linea));
        }
    }

    /**
     * La misma línea con la marca de bloqueo quitada.
     *
     * <p>Se reconstruye entera porque es un record: no hay forma de cambiar un
     * campo sin repetir los demás. Si el día de mañana crece, el compilador
     * avisa aquí, que es lo que se quiere.
     */
    private static LineaCuenta sinBloqueo(LineaCuenta l) {
        return new LineaCuenta(
                l.referencia(), l.codigoCuenta(), l.numeroLinea(),
                l.fechaInicio(), l.fechaFin(),
                l.codigoAfiliado(), l.nombreAfiliado(),
                l.codigoProcedimiento(), l.descripcionProcedimiento(),
                l.catalogoProcedimiento(), l.valorAutorizado(), l.unidadesAutorizadas(),
                l.valorCubierto(), l.unidadesCubiertas(),
                l.valorCargado(), l.unidadesCargadas(),
                l.valorGlosado(), l.observacionesGlosa(),
                l.codigoAutorizacion(),
                l.prestadorAtencionCodigo(), l.prestadorAtencionNombre(),
                l.conservarBeneficios(), l.conservarTarifacion(),
                l.beneficiosManuales(), l.tarifacionManual(),
                false, l.reemplazada(),
                l.prestacion(), l.convenio(), l.otrosDatos(),
                l.diagnosticos(), l.glosas(),
                l.novedades(), l.pendientes(),
                new Version(l.version().numero() + 1));
    }

    /** Acciones disponibles, aparte de la cabecera igual que contra OHI. */
    public synchronized AccionesDisponibles accionesDisponibles() {
        return new AccionesDisponibles(acciones);
    }

    public synchronized LineaCuenta linea(long referencia) {
        return lineas.get(referencia);
    }

    public synchronized long cantidadLineas() {
        return lineas.size();
    }

    /**
     * Página keyset: devuelve las líneas con referencia estrictamente mayor al cursor.
     *
     * @param desde referencia de la última línea de la página anterior (0 = primera página)
     */
    public synchronized List<ResumenLinea> pagina(long desde, int tamano) {
        return lineas.tailMap(desde, false).values().stream()
                .limit(tamano)
                .map(CuentaSimulada::aResumen)
                .toList();
    }

    public synchronized List<ResumenLinea> todasLasLineas() {
        return lineas.values().stream().map(CuentaSimulada::aResumen).toList();
    }

    /** Pendientes sin resolver de cabecera y de líneas, en ese orden. */
    public synchronized List<MotivoPendiente> pendientesSinResolver() {
        var resultado = new ArrayList<MotivoPendiente>();
        pendientesCabecera.stream().filter(p -> !p.resuelto()).forEach(resultado::add);
        lineas.values().forEach(linea ->
                linea.pendientes().stream().filter(p -> !p.resuelto()).forEach(resultado::add));
        return List.copyOf(resultado);
    }

    // ── Comandos ─────────────────────────────────────────────────────────────

    /**
     * Aplica la edición y devuelve la línea recalculada.
     *
     * <p>El simulador vuelve a validar editabilidad y versión aunque el caso de uso
     * ya lo haya hecho: el sistema de registro es la autoridad, no el llamador.
     */
    public synchronized LineaCuenta aplicarEdicion(EdicionLinea edicion) {
        long referencia = edicion.referencia().valor();
        var actual = lineas.get(referencia);

        if (actual == null)
            throw ExcepcionDeDominio.de(new ErrorDeDominio.LineaNoEncontrada(referencia));

        if (!actual.esEditable())
            throw ExcepcionDeDominio.de(
                    new ErrorDeDominio.LineaNoEditable(referencia, actual.razonNoEditable()));

        if (!actual.version().coincideCon(edicion.versionEsperada()))
            throw ExcepcionDeDominio.de(new ErrorDeDominio.ModificacionConcurrente(
                    "linea:" + referencia, edicion.versionEsperada().numero()));

        var valorAutorizado     = edicion.valorAutorizado().orElse(actual.valorAutorizado());
        var unidadesAutorizadas = edicion.unidadesAutorizadas().orElse(actual.unidadesAutorizadas());
        var conservarBeneficios = edicion.conservarBeneficios().orElse(actual.conservarBeneficios());
        var conservarTarifacion = edicion.conservarTarifacion().orElse(actual.conservarTarifacion());
        var valorCargado        = edicion.valorCargado().orElse(actual.valorCargado());
        var unidadesCargadas    = edicion.unidadesCargadas().orElse(actual.unidadesCargadas());
        var valorGlosado        = edicion.valorGlosado().orElse(actual.valorGlosado());
        var observacionesGlosa  = edicion.observacionesGlosa().orElse(actual.observacionesGlosa());
        var codigoAutorizacion  = edicion.codigoAutorizacion().orElse(actual.codigoAutorizacion());
        var inicio              = edicion.fechaInicio().orElse(actual.fechaInicio());
        var fin                 = edicion.fechaFin().orElse(actual.fechaFin());

        // Los demás campos editables viven en los registros anidados, así que hay
        // que rearmarlos: un record no se modifica, se vuelve a construir.
        var prestacionActual = actual.prestacion();
        var prestacion = new Prestacion(
                prestacionActual.codigo(),
                prestacionActual.descripcion(),
                prestacionActual.catalogo(),
                edicion.codigoNoDefinido().orElse(prestacionActual.codigoNoDefinido()),
                edicion.codigoNoDefinidoDef().orElse(prestacionActual.codigoNoDefinidoDef()),
                edicion.descripcionRips().orElse(prestacionActual.descripcionRips()),
                prestacionActual.claseServicio(),
                prestacionActual.especialidad());

        var convenioActual = actual.convenio();
        var convenio = new DatosConvenio(
                convenioActual.codigoTarifarioIss2001(),
                convenioActual.codigoTarifarioIss2000(),
                convenioActual.codigoTarifarioSoat(),
                edicion.numeroContrato().orElse(convenioActual.numeroContrato()),
                edicion.homologoCups().orElse(convenioActual.homologoCups()),
                convenioActual.multiplesCupsHomologos(),
                edicion.codigoUnicoContratoSiifa().orElse(convenioActual.codigoUnicoContratoSiifa()),
                convenioActual.valorConvenido(),
                convenioActual.tarifaAplicada());

        var otrosActual = actual.otrosDatos();
        var otrosDatos = new OtrosDatosLinea(
                otrosActual.tipoSala(),
                otrosActual.viaDeAcceso(),
                otrosActual.unidadEstrategicaNegocio(),
                edicion.codigoSiniestro().orElse(otrosActual.codigoSiniestro()));

        var novedades         = actual.novedades();
        var valorCubierto     = actual.valorCubierto();
        var unidadesCubiertas = actual.unidadesCubiertas();

        if (edicion.modoRecalculo() == ModoRecalculo.EN_CASCADA) {
            // El recálculo en cascada readjudica: retira las novedades que frenan
            // la cuenta y recalcula la cobertura sobre el nuevo valor autorizado.
            //
            // **Las que puso una persona se respetan.** Antes se retiraban todas
            // las bloqueantes, y eso no es lo que hace el sistema de registro: se
            // comprobó contra su entorno de pruebas que una novedad manual
            // sobrevive al recálculo. Con el filtro de antes, un auditor podía
            // poner una novedad fatal en el perfil local, guardar con recálculo en
            // cascada y verla desaparecer sin ningún aviso.
            novedades = actual.novedades().stream()
                    .filter(n -> n.laPusoUnaPersona() || !n.severidad().frenaLaCuenta())
                    .toList();
            valorCubierto     = valorAutorizado.multiply(FACTOR_COBERTURA).setScale(2, RoundingMode.HALF_UP);
            unidadesCubiertas = unidadesAutorizadas;
        }

        // Después del recálculo, para que lo que el auditor acaba de poner no lo
        // barra la readjudicación de arriba.
        novedades = aplicarCambiosDeNovedadDeCabecera(novedades, edicion);

        var actualizada = new LineaCuenta(
                actual.referencia(), actual.codigoCuenta(), actual.numeroLinea(),
                inicio, fin,
                actual.codigoAfiliado(), actual.nombreAfiliado(),
                actual.codigoProcedimiento(), actual.descripcionProcedimiento(),
                actual.catalogoProcedimiento(), valorAutorizado, unidadesAutorizadas,
                valorCubierto, unidadesCubiertas,
                valorCargado, unidadesCargadas,
                valorGlosado, observacionesGlosa,
                codigoAutorizacion,
                actual.prestadorAtencionCodigo(), actual.prestadorAtencionNombre(),
                conservarBeneficios, conservarTarifacion,
                actual.beneficiosManuales(), actual.tarifacionManual(),
                actual.bloqueada(), actual.reemplazada(),
                prestacion, convenio, otrosDatos,
                actual.diagnosticos(), aplicarCambiosDeGlosa(actual.glosas(), edicion),
                novedades, actual.pendientes(),
                new Version(actual.version().numero() + 1));

        lineas.put(referencia, actualizada);
        version++;   // la cabecera cambia porque cambiaron sus totales
        return actualizada;
    }

    /**
     * Registra el inicio del proceso de envío y deja la cuenta en seguimiento.
     * Mientras el proceso corre, la única acción disponible es SEGUIR_PROCESO.
     */
    public synchronized TiqueteProceso iniciarEnvio(String referenciaSeguimiento) {
        proceso           = new Proceso(referenciaSeguimiento, Instant.now());
        desenlaceAplicado = false;
        estado            = EstadoCuenta.ENVIADA_A_PREPROCESO;
        acciones          = Set.of(AccionCuenta.SEGUIR_PROCESO);
        version++;
        return new TiqueteProceso(codigo, referenciaSeguimiento);
    }

    /**
     * Estado del proceso derivado del tiempo transcurrido desde el envío.
     * Al completarse aplica el desenlace sobre la cuenta: FINALIZADA si fue exitoso,
     * o el estado previo al envío si falló, para poder corregir y reintentar.
     */
    public synchronized EstadoProceso estadoProceso(Duration duracion) {
        if (proceso == null)
            return new EstadoProceso(EstadoProceso.Avance.NO_INICIADO, false, List.of());

        if (Duration.between(proceso.inicio(), Instant.now()).compareTo(duracion) < 0)
            return new EstadoProceso(EstadoProceso.Avance.EN_PROCESO, false, List.of());

        if (elEnvioFalla) {
            if (!desenlaceAplicado) {
                estado   = estadoInicial;
                acciones = accionesIniciales;
                version++;
                desenlaceAplicado = true;
            }
            return new EstadoProceso(EstadoProceso.Avance.FALLIDO, true, CatalogoSimulado.ERRORES_PROCESO);
        }

        if (!desenlaceAplicado) {
            estado   = EstadoCuenta.FINALIZADA;
            acciones = Set.of(AccionCuenta.SEGUIR_PROCESO, AccionCuenta.REVERTIR_FINALIZACION);
            version++;
            desenlaceAplicado = true;
        }
        return new EstadoProceso(EstadoProceso.Avance.EXITOSO, true, List.of());
    }

    /**
     * Marca como resuelto el motivo indicado.
     *
     * @param incluirCabecera si {@code false}, solo se resuelve en las líneas
     * @return cuántos pendientes quedaron resueltos
     */
    public synchronized int resolverMotivo(long identificadorMotivo, boolean incluirCabecera) {
        int resueltos = 0;

        if (incluirCabecera) {
            var nuevos = new ArrayList<MotivoPendiente>(pendientesCabecera.size());
            for (var pendiente : pendientesCabecera) {
                if (pendiente.identificador() == identificadorMotivo && !pendiente.resuelto()) {
                    nuevos.add(marcarResuelto(pendiente));
                    resueltos++;
                } else {
                    nuevos.add(pendiente);
                }
            }
            pendientesCabecera = List.copyOf(nuevos);
        }

        // Mismo motivo que en resolverMotivosPorCodigo: el iterador de un
        // ConcurrentSkipListMap entrega entradas inmutables y `setValue` lanza
        // UnsupportedOperationException. Estaba así desde el principio y no
        // saltaba porque la resolución de líneas del simulador no se había
        // ejercitado nunca.
        for (var clave : lineas.keySet()) {
            var linea = lineas.get(clave);
            if (linea == null) continue;
            long coincidencias = linea.pendientes().stream()
                    .filter(p -> p.identificador() == identificadorMotivo && !p.resuelto())
                    .count();
            if (coincidencias == 0) continue;

            var nuevosPendientes = linea.pendientes().stream()
                    .map(p -> p.identificador() == identificadorMotivo && !p.resuelto()
                            ? marcarResuelto(p)
                            : p)
                    .toList();
            lineas.put(clave, conPendientes(linea, nuevosPendientes));
            resueltos += (int) coincidencias;
        }

        if (resueltos > 0) version++;
        return resueltos;
    }

    // ── Apoyo ────────────────────────────────────────────────────────────────

    private BigDecimal totalAutorizado() {
        return lineas.values().stream()
                .map(LineaCuenta::valorAutorizado)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal totalCubierto() {
        return lineas.values().stream()
                .map(LineaCuenta::valorCubierto)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Resuelve por <b>código</b> de motivo y a un solo nivel, como lo hace la
     * resolución conjunta del sistema de registro.
     *
     * <p>Dos diferencias deliberadas con {@link #resolverMotivo(long, boolean)},
     * que son las que hay entre las dos operaciones reales de OHI:
     * <ul>
     *   <li>coincide por {@code codigo()}, no por {@code identificador()}: el
     *       sistema de registro resuelve el motivo entero, con todas sus filas, y
     *       no una fila concreta;</li>
     *   <li>los niveles son <b>disjuntos</b>: a nivel cuenta no toca las líneas y
     *       a nivel línea no toca la cabecera.</li>
     * </ul>
     *
     * @return cuántos pendientes quedaron resueltos
     */
    public synchronized int resolverMotivosPorCodigo(Set<String> codigos, NivelPendiente nivel) {
        if (codigos == null || codigos.isEmpty()) return 0;
        int resueltos = 0;

        if (nivel == NivelPendiente.CABECERA) {
            var nuevos = new ArrayList<MotivoPendiente>(pendientesCabecera.size());
            for (var pendiente : pendientesCabecera) {
                if (codigos.contains(pendiente.codigo()) && !pendiente.resuelto()) {
                    nuevos.add(marcarResuelto(pendiente));
                    resueltos++;
                } else {
                    nuevos.add(pendiente);
                }
            }
            pendientesCabecera = List.copyOf(nuevos);
        } else {
            // `lineas.put(clave, …)` y no `entrada.setValue(…)`: el mapa es un
            // ConcurrentSkipListMap, cuyo iterador entrega entradas inmutables
            // (AbstractMap.SimpleImmutableEntry) y lanza UnsupportedOperationException
            // en setValue. Reemplazar por la clave sí está soportado, y el iterador
            // es débilmente consistente, así que escribir mientras se recorre es
            // seguro.
            for (var clave : lineas.keySet()) {
                var linea = lineas.get(clave);
                if (linea == null) continue;
                long coincidencias = linea.pendientes().stream()
                        .filter(p -> codigos.contains(p.codigo()) && !p.resuelto())
                        .count();
                if (coincidencias == 0) continue;

                var nuevosPendientes = linea.pendientes().stream()
                        .map(p -> codigos.contains(p.codigo()) && !p.resuelto()
                                ? marcarResuelto(p)
                                : p)
                        .toList();
                lineas.put(clave, conPendientes(linea, nuevosPendientes));
                resueltos += (int) coincidencias;
            }
        }

        if (resueltos > 0) version++;
        return resueltos;
    }

    /**
     * Aplica al desglose las altas y bajas de la edición.
     *
     * <p>Reproduce lo que hace el sistema de registro, no su mecánica: allí cada
     * elemento lleva un {@code op} y es él quien asigna el identificador. Aquí
     * basta con quitar los que se eliminan y añadir los nuevos con un
     * identificador propio, para que el perfil local pueda ejercitar la pantalla
     * de verdad. Sin esto, agregar y eliminar glosas «funcionaría» en local sin
     * cambiar nada, que es la peor forma de pasar una prueba.
     */
    private static List<DetalleGlosa> aplicarCambiosDeGlosa(List<DetalleGlosa> actuales,
                                                            EdicionLinea edicion) {
        if (!edicion.tocaGlosas()) return actuales;

        var bajas = edicion.glosas().stream()
                .filter(CambioGlosa::esBaja)
                .map(CambioGlosa::identificador)
                .collect(java.util.stream.Collectors.toSet());

        var resultado = new ArrayList<DetalleGlosa>(actuales.stream()
                .filter(g -> !bajas.contains(g.identificador()))
                .toList());

        long siguiente = actuales.stream().mapToLong(DetalleGlosa::identificador).max().orElse(0L);
        for (var alta : edicion.glosas()) {
            if (!alta.esAlta()) continue;
            resultado.add(new DetalleGlosa(++siguiente, alta.valor(), null,
                                           alta.generico(), alta.especifico(), alta.texto()));
        }
        return List.copyOf(resultado);
    }

    /**
     * Aplica a las novedades las altas y bajas de la edición.
     *
     * <p>Mismo criterio que {@link #aplicarCambiosDeGlosa}: reproduce el efecto,
     * no la mecánica del {@code op}. El alta se graba con origen
     * {@link Novedad#ORIGEN_MANUAL}, que es lo que hace la capa de integración
     * contra el sistema real, y con la severidad y el texto que el catálogo
     * simulado asigne al código.
     *
     * <p>La baja <b>no comprueba el origen</b>: de eso se ocupa el caso de uso,
     * que es común a los dos perfiles. Si se comprobara también aquí, el perfil
     * local pasaría pruebas que el real no pasa.
     */
    private static List<Novedad> aplicarCambiosDeNovedadDeCabecera(List<Novedad> actuales,
                                                         EdicionLinea edicion) {
        if (!edicion.tocaNovedades()) return actuales;
        return aplicarCambiosDeNovedadDeCabecera(actuales, edicion.novedades());
    }

    /**
     * El mismo aplicador, tomando la lista de cambios suelta: la cabecera no
     * tiene una {@code EdicionLinea} de la que sacarla.
     */
    private static List<Novedad> aplicarCambiosDeNovedadDeCabecera(List<Novedad> actuales,
                                                         List<CambioNovedad> cambios) {
        if (cambios == null || cambios.isEmpty()) return actuales;

        var bajas = cambios.stream()
                .filter(CambioNovedad::esBaja)
                .map(CambioNovedad::identificador)
                .collect(java.util.stream.Collectors.toSet());

        var resultado = new ArrayList<Novedad>(actuales.stream()
                .filter(n -> !bajas.contains(n.identificador()))
                .toList());

        long siguiente = actuales.stream().mapToLong(Novedad::identificador).max().orElse(0L);
        for (var alta : cambios) {
            if (!alta.esAlta()) continue;
            var plantilla = CatalogoSimulado.mensajePorCodigo(alta.codigoMensaje());
            resultado.add(new Novedad(++siguiente, alta.codigoMensaje(),
                                      plantilla.texto(), plantilla.severidad(),
                                      Novedad.ORIGEN_MANUAL,
                                      plantilla.claseGenerica(), plantilla.claseEspecifica(),
                                      "auditor.local", java.time.Instant.now(),
                                      false, alta.valores()));
        }
        return List.copyOf(resultado);
    }

    private static MotivoPendiente marcarResuelto(MotivoPendiente pendiente) {
        return new MotivoPendiente(pendiente.identificador(), pendiente.codigo(),
                pendiente.descripcion(), true, pendiente.soloAdjudicacion(),
                pendiente.nivel(), pendiente.referenciaLinea(), pendiente.numeroLinea(),
                new Version(pendiente.version().numero() + 1));
    }

    private static LineaCuenta conPendientes(LineaCuenta linea, List<MotivoPendiente> pendientes) {
        return new LineaCuenta(
                linea.referencia(), linea.codigoCuenta(), linea.numeroLinea(),
                linea.fechaInicio(), linea.fechaFin(),
                linea.codigoAfiliado(), linea.nombreAfiliado(),
                linea.codigoProcedimiento(), linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(), linea.valorAutorizado(), linea.unidadesAutorizadas(),
                linea.valorCubierto(), linea.unidadesCubiertas(),
                linea.valorCargado(), linea.unidadesCargadas(),
                linea.valorGlosado(), linea.observacionesGlosa(),
                linea.codigoAutorizacion(),
                linea.prestadorAtencionCodigo(), linea.prestadorAtencionNombre(),
                linea.conservarBeneficios(), linea.conservarTarifacion(),
                linea.beneficiosManuales(), linea.tarifacionManual(),
                linea.bloqueada(), linea.reemplazada(),
                linea.prestacion(), linea.convenio(), linea.otrosDatos(),
                linea.diagnosticos(), linea.glosas(),
                linea.novedades(), pendientes,
                new Version(linea.version().numero() + 1));
    }

    private static ResumenLinea aResumen(LineaCuenta linea) {
        return new ResumenLinea(
                linea.referencia(), linea.numeroLinea(), linea.fechaInicio(), linea.fechaFin(),
                linea.codigoAfiliado(), linea.nombreAfiliado(),
                linea.codigoProcedimiento(), linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(), linea.codigoAutorizacion(),
                linea.valorAutorizado(), linea.valorCubierto(), linea.valorGlosado(),
                linea.conservarBeneficios(), linea.conservarTarifacion(),
                linea.bloqueada(), linea.reemplazada(),
                (int) linea.pendientes().stream().filter(p -> !p.resuelto()).count(),
                linea.pendientes().stream().filter(p -> !p.resuelto()).toList(),
                linea.tieneNovedadBloqueante(), linea.version());
    }
}
