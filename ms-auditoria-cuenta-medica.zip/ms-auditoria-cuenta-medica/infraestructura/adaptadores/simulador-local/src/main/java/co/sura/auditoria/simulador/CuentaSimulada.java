package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.NavigableMap;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListMap;

/**
 * Estado mutable en memoria de una cuenta médica simulada.
 *
 * <p>Hace el papel que en los demás perfiles cumple OHI: es la autoridad sobre el
 * estado, las acciones disponibles, las versiones y el resultado del envío.
 * Todas las mutaciones están sincronizadas sobre la instancia; el perfil local
 * no busca rendimiento sino comportamiento reproducible.
 */
public final class CuentaSimulada {

    /** Porcentaje del valor autorizado que queda cubierto al recalcular en cascada. */
    private static final BigDecimal FACTOR_COBERTURA = new BigDecimal("0.90");

    private final CodigoCuenta codigo;
    private final LocalDate fechaInicio;
    private final LocalDate fechaFin;
    private final EstadoCuenta estadoInicial;
    private final Set<AccionCuenta> accionesIniciales;
    /** Marca la cuenta cuyo proceso de envío simulado termina en FALLIDO. */
    private final boolean elEnvioFalla;
    private final InformacionFacturacion informacionFacturacion;

    private final NavigableMap<Long, LineaCuenta> lineas = new ConcurrentSkipListMap<>();

    private EstadoCuenta estado;
    private Set<AccionCuenta> acciones;
    private long version;
    private List<MotivoPendiente> pendientesCabecera;

    private Proceso proceso;
    private boolean desenlaceAplicado;

    private record Proceso(String referencia, Instant inicio) {}

    CuentaSimulada(CodigoCuenta codigo, LocalDate fechaInicio, LocalDate fechaFin,
                   EstadoCuenta estado, Set<AccionCuenta> acciones, long version,
                   List<MotivoPendiente> pendientesCabecera, boolean elEnvioFalla,
                   InformacionFacturacion informacionFacturacion) {
        this.codigo                 = codigo;
        this.fechaInicio            = fechaInicio;
        this.fechaFin               = fechaFin;
        this.estadoInicial          = estado;
        this.accionesIniciales      = Set.copyOf(acciones);
        this.estado                 = estado;
        this.acciones               = Set.copyOf(acciones);
        this.version                = version;
        this.pendientesCabecera     = List.copyOf(pendientesCabecera);
        this.elEnvioFalla           = elEnvioFalla;
        this.informacionFacturacion = informacionFacturacion;
    }

    void agregarLinea(LineaCuenta linea) {
        lineas.put(linea.referencia().valor(), linea);
    }

    public CodigoCuenta codigo() {
        return codigo;
    }

    // ── Consultas ────────────────────────────────────────────────────────────

    public synchronized CuentaMedica cabecera() {
        return new CuentaMedica(codigo, estado, fechaInicio, fechaFin,
                totalAutorizado(), totalCubierto(), new Version(version),
                pendientesCabecera, informacionFacturacion);
    }

    /** Acciones disponibles, aparte de la cabecera igual que contra OHI. */
    public synchronized AccionesDisponibles accionesDisponibles() {
        return new AccionesDisponibles(acciones);
    }

    public synchronized LineaCuenta linea(long referencia) {
        return lineas.get(referencia);
    }

    public synchronized long cantidadLineas() {
        return lineas.size();
    }

    /**
     * Página keyset: devuelve las líneas con referencia estrictamente mayor al cursor.
     *
     * @param desde referencia de la última línea de la página anterior (0 = primera página)
     */
    public synchronized List<ResumenLinea> pagina(long desde, int tamano) {
        return lineas.tailMap(desde, false).values().stream()
                .limit(tamano)
                .map(CuentaSimulada::aResumen)
                .toList();
    }

    public synchronized List<ResumenLinea> todasLasLineas() {
        return lineas.values().stream().map(CuentaSimulada::aResumen).toList();
    }

    /** Pendientes sin resolver de cabecera y de líneas, en ese orden. */
    public synchronized List<MotivoPendiente> pendientesSinResolver() {
        var resultado = new ArrayList<MotivoPendiente>();
        pendientesCabecera.stream().filter(p -> !p.resuelto()).forEach(resultado::add);
        lineas.values().forEach(linea ->
                linea.pendientes().stream().filter(p -> !p.resuelto()).forEach(resultado::add));
        return List.copyOf(resultado);
    }

    // ── Comandos ─────────────────────────────────────────────────────────────

    /**
     * Aplica la edición y devuelve la línea recalculada.
     *
     * <p>El simulador vuelve a validar editabilidad y versión aunque el caso de uso
     * ya lo haya hecho: el sistema de registro es la autoridad, no el llamador.
     */
    public synchronized LineaCuenta aplicarEdicion(EdicionLinea edicion) {
        long referencia = edicion.referencia().valor();
        var actual = lineas.get(referencia);

        if (actual == null)
            throw ExcepcionDeDominio.de(new ErrorDeDominio.LineaNoEncontrada(referencia));

        if (!actual.esEditable())
            throw ExcepcionDeDominio.de(
                    new ErrorDeDominio.LineaNoEditable(referencia, actual.razonNoEditable()));

        if (!actual.version().coincideCon(edicion.versionEsperada()))
            throw ExcepcionDeDominio.de(new ErrorDeDominio.ModificacionConcurrente(
                    "linea:" + referencia, edicion.versionEsperada().numero()));

        var valorAutorizado     = edicion.valorAutorizado().orElse(actual.valorAutorizado());
        var unidadesAutorizadas = edicion.unidadesAutorizadas().orElse(actual.unidadesAutorizadas());
        var conservarBeneficios = edicion.conservarBeneficios().orElse(actual.conservarBeneficios());
        var conservarTarifacion = edicion.conservarTarifacion().orElse(actual.conservarTarifacion());
        var valorCargado        = edicion.valorCargado().orElse(actual.valorCargado());
        var unidadesCargadas    = edicion.unidadesCargadas().orElse(actual.unidadesCargadas());
        var valorGlosado        = edicion.valorGlosado().orElse(actual.valorGlosado());
        var observacionesGlosa  = edicion.observacionesGlosa().orElse(actual.observacionesGlosa());
        var codigoAutorizacion  = edicion.codigoAutorizacion().orElse(actual.codigoAutorizacion());
        var inicio              = edicion.fechaInicio().orElse(actual.fechaInicio());
        var fin                 = edicion.fechaFin().orElse(actual.fechaFin());

        // Los demás campos editables viven en los registros anidados, así que hay
        // que rearmarlos: un record no se modifica, se vuelve a construir.
        var prestacionActual = actual.prestacion();
        var prestacion = new Prestacion(
                prestacionActual.codigo(),
                prestacionActual.descripcion(),
                prestacionActual.catalogo(),
                edicion.codigoNoDefinido().orElse(prestacionActual.codigoNoDefinido()),
                edicion.codigoNoDefinidoDef().orElse(prestacionActual.codigoNoDefinidoDef()),
                edicion.descripcionRips().orElse(prestacionActual.descripcionRips()),
                prestacionActual.claseServicio(),
                prestacionActual.especialidad());

        var convenioActual = actual.convenio();
        var convenio = new DatosConvenio(
                convenioActual.codigoTarifarioIss2001(),
                convenioActual.codigoTarifarioIss2000(),
                convenioActual.codigoTarifarioSoat(),
                edicion.numeroContrato().orElse(convenioActual.numeroContrato()),
                edicion.homologoCups().orElse(convenioActual.homologoCups()),
                convenioActual.multiplesCupsHomologos(),
                edicion.codigoUnicoContratoSiifa().orElse(convenioActual.codigoUnicoContratoSiifa()),
                convenioActual.valorConvenido(),
                convenioActual.tarifaAplicada());

        var otrosActual = actual.otrosDatos();
        var otrosDatos = new OtrosDatosLinea(
                otrosActual.tipoSala(),
                otrosActual.viaDeAcceso(),
                otrosActual.unidadEstrategicaNegocio(),
                edicion.codigoSiniestro().orElse(otrosActual.codigoSiniestro()));

        var novedades         = actual.novedades();
        var valorCubierto     = actual.valorCubierto();
        var unidadesCubiertas = actual.unidadesCubiertas();

        if (edicion.modoRecalculo() == ModoRecalculo.EN_CASCADA) {
            // El recálculo en cascada readjudica: retira las novedades bloqueantes
            // y recalcula la cobertura sobre el nuevo valor autorizado.
            novedades = actual.novedades().stream()
                    .filter(n -> n.severidad() != Severidad.BLOQUEANTE)
                    .toList();
            valorCubierto     = valorAutorizado.multiply(FACTOR_COBERTURA).setScale(2, RoundingMode.HALF_UP);
            unidadesCubiertas = unidadesAutorizadas;
        }

        var actualizada = new LineaCuenta(
                actual.referencia(), actual.codigoCuenta(), actual.numeroLinea(),
                inicio, fin,
                actual.codigoAfiliado(), actual.nombreAfiliado(),
                actual.codigoProcedimiento(), actual.descripcionProcedimiento(),
                actual.catalogoProcedimiento(), valorAutorizado, unidadesAutorizadas,
                valorCubierto, unidadesCubiertas,
                valorCargado, unidadesCargadas,
                valorGlosado, observacionesGlosa,
                codigoAutorizacion,
                actual.prestadorAtencionCodigo(), actual.prestadorAtencionNombre(),
                conservarBeneficios, conservarTarifacion,
                actual.beneficiosManuales(), actual.tarifacionManual(),
                actual.bloqueada(), actual.reemplazada(),
                prestacion, convenio, otrosDatos,
                actual.diagnosticos(), actual.glosas(),
                novedades, actual.pendientes(),
                new Version(actual.version().numero() + 1));

        lineas.put(referencia, actualizada);
        version++;   // la cabecera cambia porque cambiaron sus totales
        return actualizada;
    }

    /**
     * Registra el inicio del proceso de envío y deja la cuenta en seguimiento.
     * Mientras el proceso corre, la única acción disponible es SEGUIR_PROCESO.
     */
    public synchronized TiqueteProceso iniciarEnvio(String referenciaSeguimiento) {
        proceso           = new Proceso(referenciaSeguimiento, Instant.now());
        desenlaceAplicado = false;
        estado            = EstadoCuenta.ENVIADA_A_PREPROCESO;
        acciones          = Set.of(AccionCuenta.SEGUIR_PROCESO);
        version++;
        return new TiqueteProceso(codigo, referenciaSeguimiento);
    }

    /**
     * Estado del proceso derivado del tiempo transcurrido desde el envío.
     * Al completarse aplica el desenlace sobre la cuenta: FINALIZADA si fue exitoso,
     * o el estado previo al envío si falló, para poder corregir y reintentar.
     */
    public synchronized EstadoProceso estadoProceso(Duration duracion) {
        if (proceso == null)
            return new EstadoProceso(EstadoProceso.Avance.NO_INICIADO, false, List.of());

        if (Duration.between(proceso.inicio(), Instant.now()).compareTo(duracion) < 0)
            return new EstadoProceso(EstadoProceso.Avance.EN_PROCESO, false, List.of());

        if (elEnvioFalla) {
            if (!desenlaceAplicado) {
                estado   = estadoInicial;
                acciones = accionesIniciales;
                version++;
                desenlaceAplicado = true;
            }
            return new EstadoProceso(EstadoProceso.Avance.FALLIDO, true, CatalogoSimulado.ERRORES_PROCESO);
        }

        if (!desenlaceAplicado) {
            estado   = EstadoCuenta.FINALIZADA;
            acciones = Set.of(AccionCuenta.SEGUIR_PROCESO, AccionCuenta.REVERTIR_FINALIZACION);
            version++;
            desenlaceAplicado = true;
        }
        return new EstadoProceso(EstadoProceso.Avance.EXITOSO, true, List.of());
    }

    /**
     * Marca como resuelto el motivo indicado.
     *
     * @param incluirCabecera si {@code false}, solo se resuelve en las líneas
     * @return cuántos pendientes quedaron resueltos
     */
    public synchronized int resolverMotivo(long identificadorMotivo, boolean incluirCabecera) {
        int resueltos = 0;

        if (incluirCabecera) {
            var nuevos = new ArrayList<MotivoPendiente>(pendientesCabecera.size());
            for (var pendiente : pendientesCabecera) {
                if (pendiente.identificador() == identificadorMotivo && !pendiente.resuelto()) {
                    nuevos.add(marcarResuelto(pendiente));
                    resueltos++;
                } else {
                    nuevos.add(pendiente);
                }
            }
            pendientesCabecera = List.copyOf(nuevos);
        }

        for (var entrada : lineas.entrySet()) {
            var linea = entrada.getValue();
            long coincidencias = linea.pendientes().stream()
                    .filter(p -> p.identificador() == identificadorMotivo && !p.resuelto())
                    .count();
            if (coincidencias == 0) continue;

            var nuevosPendientes = linea.pendientes().stream()
                    .map(p -> p.identificador() == identificadorMotivo && !p.resuelto()
                            ? marcarResuelto(p)
                            : p)
                    .toList();
            entrada.setValue(conPendientes(linea, nuevosPendientes));
            resueltos += (int) coincidencias;
        }

        if (resueltos > 0) version++;
        return resueltos;
    }

    // ── Apoyo ────────────────────────────────────────────────────────────────

    private BigDecimal totalAutorizado() {
        return lineas.values().stream()
                .map(LineaCuenta::valorAutorizado)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal totalCubierto() {
        return lineas.values().stream()
                .map(LineaCuenta::valorCubierto)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    private static MotivoPendiente marcarResuelto(MotivoPendiente pendiente) {
        return new MotivoPendiente(pendiente.identificador(), pendiente.codigo(),
                pendiente.descripcion(), true, pendiente.soloAdjudicacion(),
                pendiente.nivel(), pendiente.referenciaLinea(), pendiente.numeroLinea(),
                new Version(pendiente.version().numero() + 1));
    }

    private static LineaCuenta conPendientes(LineaCuenta linea, List<MotivoPendiente> pendientes) {
        return new LineaCuenta(
                linea.referencia(), linea.codigoCuenta(), linea.numeroLinea(),
                linea.fechaInicio(), linea.fechaFin(),
                linea.codigoAfiliado(), linea.nombreAfiliado(),
                linea.codigoProcedimiento(), linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(), linea.valorAutorizado(), linea.unidadesAutorizadas(),
                linea.valorCubierto(), linea.unidadesCubiertas(),
                linea.valorCargado(), linea.unidadesCargadas(),
                linea.valorGlosado(), linea.observacionesGlosa(),
                linea.codigoAutorizacion(),
                linea.prestadorAtencionCodigo(), linea.prestadorAtencionNombre(),
                linea.conservarBeneficios(), linea.conservarTarifacion(),
                linea.beneficiosManuales(), linea.tarifacionManual(),
                linea.bloqueada(), linea.reemplazada(),
                linea.prestacion(), linea.convenio(), linea.otrosDatos(),
                linea.diagnosticos(), linea.glosas(),
                linea.novedades(), pendientes,
                new Version(linea.version().numero() + 1));
    }

    private static ResumenLinea aResumen(LineaCuenta linea) {
        return new ResumenLinea(
                linea.referencia(), linea.numeroLinea(), linea.fechaInicio(), linea.fechaFin(),
                linea.codigoAfiliado(), linea.nombreAfiliado(),
                linea.codigoProcedimiento(), linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(),
                linea.valorAutorizado(), linea.valorCubierto(),
                linea.conservarBeneficios(), linea.conservarTarifacion(),
                linea.bloqueada(), linea.reemplazada(),
                (int) linea.pendientes().stream().filter(p -> !p.resuelto()).count(),
                linea.pendientes().stream().filter(p -> !p.resuelto()).toList(),
                linea.tieneNovedadBloqueante(), linea.version());
    }
}
