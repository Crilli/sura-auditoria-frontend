package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Publicador de eventos del perfil local: escribe en el log en vez de publicar en el bus.
 * Evita depender de RabbitMQ para levantar el servicio en un portátil.
 */
@Component
@Profile("local")
public class PublicadorEventosSimulado implements PublicadorEventosAuditoria {

    private static final Logger log = LoggerFactory.getLogger(PublicadorEventosSimulado.class);

    @Override
    public Mono<Void> publicar(EventoAuditoria evento) {
        return Mono.fromRunnable(() -> log.info(
                "Simulador · evento {} · cuenta {} · línea {} · autor {} · {}",
                evento.tipo(), evento.codigoCuenta(), evento.referenciaLinea(),
                evento.autor(), evento.detalle()));
    }
}
