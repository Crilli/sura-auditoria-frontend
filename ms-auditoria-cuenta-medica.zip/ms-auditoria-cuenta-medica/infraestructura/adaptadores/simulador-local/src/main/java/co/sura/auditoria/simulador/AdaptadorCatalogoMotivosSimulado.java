package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion.Ambito;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivos;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Catálogo de motivos del perfil local.
 *
 * <p>Códigos, descripciones y banderas reales del sistema de registro, no
 * inventados, y escogidos para que en local se puedan ejercitar los tres casos
 * que si no solo se ven contra el sistema real: uno que <b>deja las líneas
 * bloqueadas</b>, uno que <b>exige referencia de origen</b> y uno con
 * <b>permiso propio</b>. Y de los tres ámbitos, para que el filtro por tipo de
 * proceso se note.
 */
@Profile("local")
@Component
public class AdaptadorCatalogoMotivosSimulado implements PuertoCatalogoMotivos {

    private static final List<MotivoDesfinalizacion> MOTIVOS = List.of(
            new MotivoDesfinalizacion("PRORROGA", "Prorroga",
                    false, false, Ambito.AMBAS, "ClaimUnfinalization"),
            new MotivoDesfinalizacion("ANULACION", "ANULACIÓN",
                    false, false, Ambito.AMBAS, "RA_DESFINALIZA_ANULACION"),
            new MotivoDesfinalizacion("CORRECCION", "Corrección",
                    true, false, Ambito.CUENTA_MEDICA, "RA_DESFINALIZAR_CM_CORRECCION"),
            new MotivoDesfinalizacion("NOTA_CREDITO_BLOQUEO", "Nota crédito con Bloqueo",
                    true, false, Ambito.CUENTA_MEDICA, "RA_DESFINALIZAR_CM_NOTA_CREDITO_BLOQUEO"),
            new MotivoDesfinalizacion("CAMBIO_PRESTADOR", "Cambio de prestador",
                    false, false, Ambito.AUTORIZACION, "ClaimUnfinalization"),
            new MotivoDesfinalizacion("QA TEST", "QA TEST",
                    true, true, Ambito.AMBAS, "ClaimUnfinalization"));

    @Override
    public Mono<List<MotivoDesfinalizacion>> listar() {
        return Mono.just(MOTIVOS);
    }
}
