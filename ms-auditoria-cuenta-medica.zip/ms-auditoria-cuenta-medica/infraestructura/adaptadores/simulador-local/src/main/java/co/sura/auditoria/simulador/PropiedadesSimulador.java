package co.sura.auditoria.simulador;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;

/**
 * Parámetros del simulador local. Solo se enlazan bajo el perfil {@code local}.
 *
 * <p>El catálogo simulado es <em>determinista</em>: con los mismos parámetros se
 * obtienen exactamente las mismas cuentas, líneas, novedades y pendientes en cada
 * arranque. Eso permite escribir pruebas de cliente estables contra el perfil local.
 */
@ConfigurationProperties(prefix = "simulador.local")
public record PropiedadesSimulador(

        /** Cuántas cuentas médicas expone el simulador. */
        @DefaultValue("10") int cantidadCuentas,

        /** Mínimo de líneas por cuenta (inclusive). */
        @DefaultValue("400") int minimoLineas,

        /** Máximo de líneas por cuenta (inclusive). */
        @DefaultValue("500") int maximoLineas,

        /** Prefijo del código de negocio de la cuenta. */
        @DefaultValue("GT-") String prefijoCuenta,

        /** Consecutivo de la primera cuenta; las siguientes van sumando uno. */
        @DefaultValue("106586883036") long primerConsecutivo,

        /** Latencia artificial añadida a cada operación, para parecerse a una red real. */
        @DefaultValue("0ms") Duration latencia,

        /** Cuánto tarda el proceso de envío simulado en finalizar. */
        @DefaultValue("6s") Duration duracionProceso
) {
    public PropiedadesSimulador {
        if (cantidadCuentas <= 0)
            throw new IllegalArgumentException("simulador.local.cantidad-cuentas debe ser mayor que cero");
        if (minimoLineas <= 0)
            throw new IllegalArgumentException("simulador.local.minimo-lineas debe ser mayor que cero");
        if (maximoLineas < minimoLineas)
            throw new IllegalArgumentException(
                    "simulador.local.maximo-lineas (%d) no puede ser menor que minimo-lineas (%d)"
                            .formatted(maximoLineas, minimoLineas));
    }

    /** Cantidad de valores distintos que puede tomar el número de líneas de una cuenta. */
    public int rangoLineas() {
        return maximoLineas - minimoLineas + 1;
    }
}
