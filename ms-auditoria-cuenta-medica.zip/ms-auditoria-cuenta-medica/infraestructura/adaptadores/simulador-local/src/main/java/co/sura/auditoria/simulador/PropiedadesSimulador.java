package co.sura.auditoria.simulador;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;

/**
 * Parámetros del simulador local. Solo se enlazan bajo el perfil {@code local}.
 *
 * <p>El catálogo simulado es <em>determinista</em>: con los mismos parámetros se
 * obtienen exactamente las mismas cuentas, líneas, novedades y pendientes en cada
 * arranque. Eso permite escribir pruebas de cliente estables contra el perfil local.
 */
@ConfigurationProperties(prefix = "simulador.local")
public record PropiedadesSimulador(

        /** Cuántas cuentas médicas expone el simulador. */
        @DefaultValue("10") int cantidadCuentas,

        /** Mínimo de líneas por cuenta (inclusive). */
        @DefaultValue("400") int minimoLineas,

        /** Máximo de líneas por cuenta (inclusive). */
        @DefaultValue("500") int maximoLineas,

        /** Prefijo del código de negocio de la cuenta. */
        @DefaultValue("GT-") String prefijoCuenta,

        /** Consecutivo de la primera cuenta; las siguientes van sumando uno. */
        @DefaultValue("106586883036") long primerConsecutivo,

        /** Latencia artificial añadida a cada operación, para parecerse a una red real. */
        @DefaultValue("0ms") Duration latencia,

        /** Cuánto tarda el proceso de envío simulado en finalizar. */
        @DefaultValue("6s") Duration duracionProceso,

        /**
         * Código de motivo que la resolución conjunta <b>nunca</b> resuelve,
         * reportándolo como fallo. Vacío (lo normal) desactiva la palanca.
         *
         * <p>Existe porque el fallo parcial no se puede provocar de otra forma:
         * en el sistema de registro ocurre cuando otro auditor resuelve el motivo
         * entre que se lee el agregado y que se procesa la operación —una carrera
         * que no se reproduce en un simulador de un solo hilo—, y el caso de uso
         * descarta antes los motivos que no aplican. Sin esta palanca, el camino
         * que presenta «se resolvió en parte» quedaría escrito y nunca ejecutado,
         * justo el camino que evita dar por hecho lo que no se hizo.
         *
         * <p>No falsea nada: el motivo se reporta como no resuelto <em>y</em> no
         * se resuelve. Es el mismo desenlace que daría la carrera real.
         */
        @DefaultValue("") String motivoQueNoSeResuelve
) {
    public PropiedadesSimulador {
        if (cantidadCuentas <= 0)
            throw new IllegalArgumentException("simulador.local.cantidad-cuentas debe ser mayor que cero");
        if (minimoLineas <= 0)
            throw new IllegalArgumentException("simulador.local.minimo-lineas debe ser mayor que cero");
        if (maximoLineas < minimoLineas)
            throw new IllegalArgumentException(
                    "simulador.local.maximo-lineas (%d) no puede ser menor que minimo-lineas (%d)"
                            .formatted(maximoLineas, minimoLineas));
    }

    /** Cantidad de valores distintos que puede tomar el número de líneas de una cuenta. */
    public int rangoLineas() {
        return maximoLineas - minimoLineas + 1;
    }
}
