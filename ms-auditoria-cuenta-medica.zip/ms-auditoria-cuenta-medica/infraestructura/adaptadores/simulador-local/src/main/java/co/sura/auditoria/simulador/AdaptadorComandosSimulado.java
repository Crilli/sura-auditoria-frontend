package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Lado de comandos del simulador local (sustituye a {@code AdaptadorComandosOhi}).
 */
@Component
@Profile("local")
public class AdaptadorComandosSimulado implements PuertoComandosCuenta {

    private static final Logger log = LoggerFactory.getLogger(AdaptadorComandosSimulado.class);

    private final AlmacenSimulado almacen;

    public AdaptadorComandosSimulado(AlmacenSimulado almacen) {
        this.almacen = almacen;
    }

    @Override
    public Mono<CuentaMedica> aplicarCambiosDeNovedadDeCabecera(CodigoCuenta codigo, Version version,
                                                      List<CambioNovedad> cambios) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.exigirCuenta(codigo);
            var actualizada = cuenta.aplicarCambiosDeNovedadDeCabecera(cambios);
            log.debug("Simulador: novedades de cabecera de {} actualizadas a versión {}",
                    codigo.valor(), actualizada.version().numero());
            return actualizada;
        }));
    }

    @Override
    public Mono<CuentaMedica> ejecutarAccion(CodigoCuenta codigo, EjecucionAccion ejecucion) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.exigirCuenta(codigo);
            var actualizada = cuenta.ejecutarAccion(ejecucion);
            log.debug("Simulador: {} sobre {} · estado ahora {}",
                    ejecucion.accion(), codigo.valor(), actualizada.estado());
            return actualizada;
        }));
    }

    @Override
    public Mono<LineaCuenta> aplicarEdicionesDeLinea(CodigoCuenta codigo, Version versionCuenta,
                                                     List<EdicionLinea> ediciones) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            if (ediciones == null || ediciones.isEmpty())
                throw ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "No se recibió ninguna edición para aplicar"));

            var cuenta = almacen.exigirCuenta(codigo);
            LineaCuenta ultima = null;
            for (var edicion : ediciones) {
                ultima = cuenta.aplicarEdicion(edicion);
                log.debug("Simulador: línea {} de {} actualizada a versión {}",
                        edicion.referencia().valor(), codigo.valor(), ultima.version().numero());
            }
            return ultima;
        }));
    }

    @Override
    public Mono<TiqueteProceso> enviar(CodigoCuenta codigo, Version version, DecisionEnvio decision) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta   = almacen.exigirCuenta(codigo);
            var tiquete  = cuenta.iniciarEnvio(almacen.siguienteReferenciaSeguimiento());
            log.info("Simulador: cuenta {} enviada con decisión {} · tiquete {}",
                    codigo.valor(), decision.decision(), tiquete.referenciaSeguimiento());
            return tiquete;
        }));
    }
}
