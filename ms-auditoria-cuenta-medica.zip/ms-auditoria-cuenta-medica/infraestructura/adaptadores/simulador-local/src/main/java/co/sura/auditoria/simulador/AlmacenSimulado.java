package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Catálogo en memoria de cuentas simuladas. Es el sustituto de OHI bajo el perfil {@code local}.
 *
 * <p>Se construye una sola vez al arrancar y vive mientras viva el proceso: reiniciar el
 * servicio devuelve el catálogo a su estado inicial, que es la forma de «resetear» los datos.
 */
@Component
@Profile("local")
public class AlmacenSimulado {

    private static final Logger log = LoggerFactory.getLogger(AlmacenSimulado.class);

    private static final DateTimeFormatter FORMATO_TIQUETE = DateTimeFormatter.ofPattern("yyyy-MMdd");

    private final PropiedadesSimulador propiedades;
    private final Map<String, CuentaSimulada> cuentas;
    private final AtomicLong secuenciaProceso = new AtomicLong(177);

    public AlmacenSimulado(PropiedadesSimulador propiedades) {
        this.propiedades = propiedades;
        this.cuentas     = GeneradorCuentasSimuladas.generar(propiedades);

        log.warn("PERFIL LOCAL ACTIVO — no se consulta OHI. {} cuentas simuladas en memoria.",
                cuentas.size());
        cuentas.values().forEach(cuenta -> log.info(
                "  cuenta simulada {} · {} líneas · estado {} · {} pendientes sin resolver",
                cuenta.codigo().valor(), cuenta.cantidadLineas(),
                cuenta.cabecera().estado(), cuenta.pendientesSinResolver().size()));
    }

    public PropiedadesSimulador propiedades() {
        return propiedades;
    }

    /** @return la cuenta simulada, o {@code null} si el código no existe. */
    public CuentaSimulada cuenta(CodigoCuenta codigo) {
        return cuentas.get(codigo.valor());
    }

    /** @throws ExcepcionDeDominio con {@link ErrorDeDominio.CuentaNoEncontrada} si no existe. */
    public CuentaSimulada exigirCuenta(CodigoCuenta codigo) {
        var cuenta = cuentas.get(codigo.valor());
        if (cuenta == null)
            throw ExcepcionDeDominio.de(new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()));
        return cuenta;
    }

    public Collection<CuentaSimulada> todas() {
        return cuentas.values();
    }

    /** Referencia de seguimiento con la misma forma que la que devuelve OHI. */
    public String siguienteReferenciaSeguimiento() {
        return "PROC-%s-%06d".formatted(
                LocalDate.now().format(FORMATO_TIQUETE), secuenciaProceso.incrementAndGet());
    }

    // ── Simulación de red ────────────────────────────────────────────────────

    /** Aplica la latencia artificial configurada, si la hay. */
    public <T> Mono<T> conLatencia(Mono<T> origen) {
        var latencia = propiedades.latencia();
        return latencia.isZero() || latencia.isNegative() ? origen : origen.delaySubscription(latencia);
    }

    public <T> Flux<T> conLatencia(Flux<T> origen) {
        var latencia = propiedades.latencia();
        return latencia.isZero() || latencia.isNegative() ? origen : origen.delaySubscription(latencia);
    }
}
