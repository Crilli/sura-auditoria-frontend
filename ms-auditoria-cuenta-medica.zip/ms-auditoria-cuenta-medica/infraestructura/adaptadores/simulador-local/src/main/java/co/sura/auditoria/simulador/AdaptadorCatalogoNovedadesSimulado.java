package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Catálogo de novedades del perfil local.
 *
 * <p>Sirve la muestra de {@link CatalogoSimulado#CATALOGO_NOVEDADES}, que son
 * códigos y textos reales del sistema de registro. Así el selector de la pantalla
 * se puede ejercitar sin red, y con datos que se parecen a los de verdad: los dos
 * sistemas de codificación, las tres severidades y mensajes con y sin
 * clasificación normativa.
 */
@Profile("local")
@Component
public class AdaptadorCatalogoNovedadesSimulado implements PuertoCatalogoNovedades {

    @Override
    public Mono<List<MensajeCatalogo>> listar() {
        return Mono.just(CatalogoSimulado.CATALOGO_NOVEDADES.stream()
                .map(m -> new MensajeCatalogo(m.codigo(), m.texto(), m.severidad(),
                                              m.claseGenerica(), m.claseEspecifica(), false))
                .toList());
    }
}
