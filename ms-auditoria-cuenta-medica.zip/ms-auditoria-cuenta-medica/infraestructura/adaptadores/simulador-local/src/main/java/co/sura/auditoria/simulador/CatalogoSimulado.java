package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.Severidad;

import java.math.BigDecimal;
import java.util.List;

/**
 * Catálogos fijos con los que el generador arma las cuentas simuladas.
 * Los datos son ficticios: no corresponden a prestadores, afiliados ni tarifas reales.
 */
final class CatalogoSimulado {

    private CatalogoSimulado() {}

    record Procedimiento(String codigo, String descripcion, BigDecimal tarifa) {}

    record Prestador(String nit, String razonSocial) {}

    record PlantillaNovedad(String codigo, String descripcion, Severidad severidad, String origen) {}

    record PlantillaPendiente(String codigo, String descripcion, boolean soloAdjudicacion) {}

    /** El orden importa: el generador rota sobre esta lista de forma determinista. */
    static final List<Procedimiento> PROCEDIMIENTOS = List.of(
            new Procedimiento("890201", "Consulta de primera vez por medicina especializada", new BigDecimal("320000.00")),
            new Procedimiento("903841", "Resonancia magnética de columna lumbar",             new BigDecimal("1150000.00")),
            new Procedimiento("871121", "Radiografía de tórax",                               new BigDecimal("74500.00")),
            new Procedimiento("902210", "Hemograma tipo IV",                                  new BigDecimal("38900.00")),
            new Procedimiento("993501", "Terapia física integral",                            new BigDecimal("62400.00")),
            new Procedimiento("881434", "Ecografía abdominal total",                          new BigDecimal("196000.00")),
            new Procedimiento("395101", "Suministro de medicamento oncológico",               new BigDecimal("2480000.00")),
            new Procedimiento("861001", "Internación en habitación bipersonal",               new BigDecimal("540000.00")),
            new Procedimiento("904501", "Perfil lipídico",                                    new BigDecimal("54300.00")),
            new Procedimiento("120201", "Valoración por psicología clínica",                  new BigDecimal("118000.00")),
            new Procedimiento("871060", "Tomografía computarizada de cráneo",                 new BigDecimal("890000.00")),
            new Procedimiento("998401", "Traslado asistencial básico",                        new BigDecimal("215000.00")));

    /** NIT-sucursal ficticios, con el mismo formato que usa el sistema de registro real. */
    static final List<Prestador> PRESTADORES = List.of(
            new Prestador("900828394-6001", "IPS Simulada Central S.A.S."),
            new Prestador("811017994-5002", "Clínica Simulada del Norte S.A."),
            new Prestador("890903938-1003", "Hospital Simulado San Rafael"));

    /** Tipos de servicio de ejemplo para la ficha de facturación. */
    static final List<String> TIPOS_SERVICIO = List.of(
            "Ambulatorio", "Hospitalario", "Urgencias", "Consulta externa");

    static final List<PlantillaNovedad> NOVEDADES_BLOQUEANTES = List.of(
            new PlantillaNovedad("COB-114", "Procedimiento no incluido en el plan de beneficios vigente",
                    Severidad.BLOQUEANTE, "ADJUDICACION"),
            new PlantillaNovedad("COB-208", "El afiliado no tiene cobertura activa en la fecha de prestación",
                    Severidad.BLOQUEANTE, "ADJUDICACION"),
            new PlantillaNovedad("AUT-031", "La prestación requiere autorización previa y no la tiene",
                    Severidad.BLOQUEANTE, "AUTORIZACION"));

    static final List<PlantillaNovedad> NOVEDADES_ADVERTENCIA = List.of(
            new PlantillaNovedad("TAR-007", "Tarifa aplicada difiere del contrato del prestador",
                    Severidad.ADVERTENCIA, "TARIFACION"),
            new PlantillaNovedad("TAR-019", "Se aplicó tarifa manual sobre el valor contratado",
                    Severidad.ADVERTENCIA, "TARIFACION"),
            new PlantillaNovedad("LIM-042", "El consumo acumulado se acerca al límite anual del afiliado",
                    Severidad.ADVERTENCIA, "LIMITES"));

    static final List<PlantillaNovedad> NOVEDADES_INFORMATIVAS = List.of(
            new PlantillaNovedad("INF-001", "Prestación registrada por el prestador fuera del plazo habitual",
                    Severidad.INFORMATIVA, "DIGITACION"),
            new PlantillaNovedad("INF-014", "El afiliado cambió de plan durante el periodo de la cuenta",
                    Severidad.INFORMATIVA, "AFILIACION"));

    static final List<PlantillaPendiente> PENDIENTES_CABECERA = List.of(
            new PlantillaPendiente("PEN-COB", "Requiere validación de cobertura por auditoría médica", false),
            new PlantillaPendiente("PEN-DOC", "Soporte documental incompleto en la cuenta",            true),
            new PlantillaPendiente("PEN-CTO", "Contrato del prestador pendiente de verificación",      false));

    /**
     * Un motivo puesto <b>en los dos niveles</b>: en la cabecera y en las líneas.
     *
     * <p>Es el caso corriente en el sistema de registro —{@code MP_GLOSA_SIN_MOTIVO}
     * está así en producción— y es el único que ejercita de verdad la disyunción
     * de niveles: resolver «solo la cuenta» lo deja en las líneas y al revés, y
     * «donde aplique» tiene que emitir dos operaciones. Sin un motivo compartido
     * ningún escenario del simulador recorría ese camino.
     */
    static final PlantillaPendiente PENDIENTE_EN_AMBOS_NIVELES =
            new PlantillaPendiente("PEN-COB", "Requiere validación de cobertura por auditoría médica", false);

    static final List<PlantillaPendiente> PENDIENTES_LINEA = List.of(
            new PlantillaPendiente("PEN-LIN-COB", "Cobertura de la línea pendiente de validación",       false),
            new PlantillaPendiente("PEN-LIN-TAR", "Tarifa de la línea pendiente de revisión",            false),
            new PlantillaPendiente("PEN-LIN-ADJ", "Adjudicación manual pendiente sobre la línea",        true),
            PENDIENTE_EN_AMBOS_NIVELES);

    /** Errores que devuelve el proceso de envío cuando la cuenta simulada está marcada para fallar. */
    static final List<String> ERRORES_PROCESO = List.of(
            "La línea quedó bloqueada durante la adjudicación",
            "No fue posible recalcular el consumo de límites del afiliado");
}
