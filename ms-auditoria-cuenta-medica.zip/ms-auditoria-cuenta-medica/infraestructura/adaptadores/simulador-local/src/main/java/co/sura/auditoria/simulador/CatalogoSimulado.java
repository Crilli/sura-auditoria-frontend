package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.Severidad;

import java.math.BigDecimal;
import java.util.List;

/**
 * Catálogos fijos con los que el generador arma las cuentas simuladas.
 * Los datos son ficticios: no corresponden a prestadores, afiliados ni tarifas reales.
 */
final class CatalogoSimulado {

    private CatalogoSimulado() {}

    record Procedimiento(String codigo, String descripcion, BigDecimal tarifa) {}

    record Prestador(String nit, String razonSocial) {}

    /**
     * @param esDelSistema lo que OHI rotula «Específico de Sistema?»
     * @param valores      los datos que completan los marcadores de la
     *                     descripción, por índice
     */
    record PlantillaNovedad(String codigo, String descripcion, Severidad severidad, String origen,
                            boolean esDelSistema, java.util.Map<Integer, String> valores) {

        /** Sin marcadores ni marca de sistema, que es el caso corriente. */
        PlantillaNovedad(String codigo, String descripcion, Severidad severidad, String origen) {
            this(codigo, descripcion, severidad, origen, false, java.util.Map.of());
        }
    }

    record PlantillaPendiente(String codigo, String descripcion, boolean soloAdjudicacion) {}

    /** El orden importa: el generador rota sobre esta lista de forma determinista. */
    static final List<Procedimiento> PROCEDIMIENTOS = List.of(
            new Procedimiento("890201", "Consulta de primera vez por medicina especializada", new BigDecimal("320000.00")),
            new Procedimiento("903841", "Resonancia magnética de columna lumbar",             new BigDecimal("1150000.00")),
            new Procedimiento("871121", "Radiografía de tórax",                               new BigDecimal("74500.00")),
            new Procedimiento("902210", "Hemograma tipo IV",                                  new BigDecimal("38900.00")),
            new Procedimiento("993501", "Terapia física integral",                            new BigDecimal("62400.00")),
            new Procedimiento("881434", "Ecografía abdominal total",                          new BigDecimal("196000.00")),
            new Procedimiento("395101", "Suministro de medicamento oncológico",               new BigDecimal("2480000.00")),
            new Procedimiento("861001", "Internación en habitación bipersonal",               new BigDecimal("540000.00")),
            new Procedimiento("904501", "Perfil lipídico",                                    new BigDecimal("54300.00")),
            new Procedimiento("120201", "Valoración por psicología clínica",                  new BigDecimal("118000.00")),
            new Procedimiento("871060", "Tomografía computarizada de cráneo",                 new BigDecimal("890000.00")),
            new Procedimiento("998401", "Traslado asistencial básico",                        new BigDecimal("215000.00")));

    /** NIT-sucursal ficticios, con el mismo formato que usa el sistema de registro real. */
    static final List<Prestador> PRESTADORES = List.of(
            new Prestador("900828394-6001", "IPS Simulada Central S.A.S."),
            new Prestador("811017994-5002", "Clínica Simulada del Norte S.A."),
            new Prestador("890903938-1003", "Hospital Simulado San Rafael"));

    /** Tipos de servicio de ejemplo para la ficha de facturación. */
    static final List<String> TIPOS_SERVICIO = List.of(
            "Ambulatorio", "Hospitalario", "Urgencias", "Consulta externa");

    static final List<PlantillaNovedad> NOVEDADES_BLOQUEANTES = List.of(
            new PlantillaNovedad("COB-114", "Procedimiento no incluido en el plan de beneficios vigente",
                    Severidad.BLOQUEANTE, "ADJUDICACION"),
            new PlantillaNovedad("COB-208", "El afiliado no tiene cobertura activa en la fecha de prestación",
                    Severidad.BLOQUEANTE, "ADJUDICACION"),
            new PlantillaNovedad("AUT-031", "La prestación requiere autorización previa y no la tiene",
                    Severidad.BLOQUEANTE, "AUTORIZACION"));

    static final List<PlantillaNovedad> NOVEDADES_ADVERTENCIA = List.of(
            new PlantillaNovedad("TAR-007", "Tarifa aplicada difiere del contrato del prestador",
                    Severidad.ADVERTENCIA, "TARIFACION"),
            new PlantillaNovedad("TAR-019", "Se aplicó tarifa manual sobre el valor contratado",
                    Severidad.ADVERTENCIA, "TARIFACION"),
            new PlantillaNovedad("LIM-042", "El consumo acumulado se acerca al límite anual del afiliado",
                    Severidad.ADVERTENCIA, "LIMITES"));

    static final List<PlantillaNovedad> NOVEDADES_INFORMATIVAS = List.of(
            new PlantillaNovedad("INF-001", "Prestación registrada por el prestador fuera del plazo habitual",
                    Severidad.INFORMATIVA, "DIGITACION"),
            new PlantillaNovedad("INF-014", "El afiliado cambió de plan durante el periodo de la cuenta",
                    Severidad.INFORMATIVA, "AFILIACION"),
            // Las dos siguientes existen para que el perfil local enseñe lo que
            // antes solo se veía contra el sistema real: una novedad del motor
            // con marcadores **ya rellenos** —que es como llegan de verdad— y
            // una marcada como propia del sistema.
            new PlantillaNovedad("SURA-AUT-002",
                    "Autorización {2} encontrada y consumida. Autorización inicial: {1}",
                    Severidad.INFORMATIVA, "PRE PRICING",
                    false, java.util.Map.of(1, "AUT-55012", 2, "AUT-55012-3")),
            new PlantillaNovedad("CLA-FL-BENS-008",
                    "El motor no encontró beneficio aplicable para la prestación",
                    Severidad.INFORMATIVA, "BENEFITS",
                    true, java.util.Map.of()));

    /**
     * Un mensaje del catálogo de novedades, como lo publica el sistema de registro.
     *
     * @param generico  clasificación normativa de primer nivel; puede faltar
     * @param especifico de segundo nivel; puede faltar
     */
    record PlantillaMensaje(String codigo, String texto, Severidad severidad,
                            String generico, String genericoDescr,
                            String especifico, String especificoDescr) {

        Novedad.Clasificacion claseGenerica() {
            return generico == null ? null : new Novedad.Clasificacion(generico, genericoDescr);
        }

        Novedad.Clasificacion claseEspecifica() {
            return especifico == null ? null
                    : new Novedad.Clasificacion(especifico, especificoDescr);
        }
    }

    /**
     * Catálogo de mensajes que un auditor puede poner como novedad.
     *
     * <p><b>Son códigos y textos reales</b>, copiados del catálogo del sistema de
     * registro, no inventados: así lo que se prueba en el perfil local se parece
     * a lo que el auditor va a encontarse. La muestra está escogida para cubrir
     * lo que distingue a unos de otros:
     * <ul>
     *   <li>los <b>dos sistemas de codificación</b> que conviven allí: el
     *       numérico de la ley nueva ({@code 332-1}, con conceptos
     *       {@code 3 · Soportes}) y los propios con prefijo
     *       ({@code SURA-DYLO-L044}), que no traen conceptos;</li>
     *   <li>las <b>tres severidades</b>, porque de ellas depende que la pantalla
     *       avise de que la cuenta se va a frenar;</li>
     *   <li>mensajes <b>con y sin clasificación</b>, que es lo que obliga a la
     *       pantalla a aguantar que falte.</li>
     * </ul>
     *
     * <p>Es una muestra y no el catálogo entero: allí hay 631 ofrecibles.
     */
    static final List<PlantillaMensaje> CATALOGO_NOVEDADES = List.of(
            new PlantillaMensaje("332-1", "Existe ausencia total o parcial, inconsistencia, enmendaduras o ilegibilidad en los soportes de la factura que evidencien el detalle de cargos de los valores facturados.", Severidad.INFORMATIVA, "3", "Soportes", "32", "Detalle de cargos"),
            new PlantillaMensaje("229-1A", "Cuando en la factura se adicionan cobros de recargos no pactados previamente entre la entidad responsable del pago y el prestador de servicios de salud.", Severidad.INFORMATIVA, "2", "Tarifas", "29", "Recargos no pactados"),
            new PlantillaMensaje("120-2", "Los recaudos de bonos, váucheres o vales, que por acuerdo de voluntades efectuó el prestador de servicios, no se realizaron o quedaron mal liquidados.", Severidad.INFORMATIVA, "1", "Facturación", "20", "Recibo de pago compartido."),
            new PlantillaMensaje("403-1F", "El prestador factura por actividad, honorarios de ayudantía que fueron autorizados por Convenio Especial o que hacen parte de éste.", Severidad.INFORMATIVA, "4", "Autorizaciones", "03", "Honorarios médicos en procedimientos"),
            new PlantillaMensaje("338-1", "Existe ausencia total o parcial, inconsistencia, enmendaduras o ilegibilidad en la hoja de traslado o en los documentos de soporte del transporte.", Severidad.INFORMATIVA, "3", "Soportes", "38", "Hoja de traslado en ambulancia"),
            new PlantillaMensaje("TA0401", "Los cargos por honorarios de otro talento humano que interviene en la atención que vienen relacionados o justificados en soportes de cobro, presentan diferencias con los valores pactados o establecidos por la norma", Severidad.INFORMATIVA, "TA", "TARIFAS", "04N", "Honorarios otro talento humano que interviene en la atención"),
            new PlantillaMensaje("AU2103", "El número de la autorización registrado en la factura de venta en salud o RIPS no corresponde al servicio o tecnología prestada o facturada", Severidad.INFORMATIVA, "AU", "AUTORIZACIONES", "21N", "Número de autorización"),
            new PlantillaMensaje("849-7", "Devolución de factura por solicitud del prestador.", Severidad.BLOQUEANTE, "8", "Devoluciones", "49", "Factura no cumple requisitos legales"),
            new PlantillaMensaje("849-1", "Los servicios en la factura presentan errores en valor o suma según los conceptos facturados o con respecto al detalle de cargos", Severidad.BLOQUEANTE, "8", "Devoluciones", "49", "Factura no cumple requisitos legales"),
            new PlantillaMensaje("821-8", "No existe solicitud de autorización de servicios adicionales a la urgencia por no solicitud de la IPS (Falta Anexo 3 y/o 4 Res. 3047/2008)", Severidad.BLOQUEANTE, "8", "Devoluciones", "21", "Autorización principal no existe o no corresponde al prestador de servicios de salud"),
            new PlantillaMensaje("850-1", "Servicios ya cancelados por la Entidad Responsable de Pago.", Severidad.BLOQUEANTE, "8", "Devoluciones", "50", "Factura ya cancelada"),
            new PlantillaMensaje("SURA-DYLO-L044", "No existe el procedimiento CUPS", Severidad.BLOQUEANTE, null, null, null, null),
            new PlantillaMensaje("SURA-AU2103", "El número de la autorización registrado en la factura de venta en salud o RIPS no corresponde al servicio o tecnología prestada o facturada", Severidad.BLOQUEANTE, null, null, null, null),
            new PlantillaMensaje("NEGACION_010", "Negado por auditoría", Severidad.BLOQUEANTE, null, null, null, null),
            new PlantillaMensaje("SURA-LIM-001", "La prestación es permitida máximo 1 por día.", Severidad.NEGACION, null, null, null, null),
            // Dos con marcadores, para poder ejercitar en local el alta que pide
            // datos. Ojo a los índices del segundo: saltan del 1 al 4 y al 6,
            // que es como son de verdad en el catálogo.
            new PlantillaMensaje("SURA-AUT-002", "Autorización {2} encontrada y consumida. Autorización inicial: {1}", Severidad.INFORMATIVA, null, null, null, null),
            new PlantillaMensaje("SURA-AUT-022", "Autorización IVR {2} encontrada y consumida. Autorización inicial: {1}; Consumo: {0}; Restante: {6}; Fecha autorización: {4}", Severidad.INFORMATIVA, null, null, null, null));

    /**
     * El mensaje de un código, o uno improvisado si no está en la muestra.
     *
     * <p>No se cae ni devuelve nulo con un código desconocido: el perfil local
     * tiene una muestra de 15 y el real 631, así que es normal que llegue uno
     * que aquí no está, y que la pantalla no se rompa por eso es justo lo que
     * conviene probar.
     */
    static PlantillaMensaje mensajePorCodigo(String codigo) {
        return CATALOGO_NOVEDADES.stream()
                .filter(m -> m.codigo().equalsIgnoreCase(codigo))
                .findFirst()
                .orElseGet(() -> new PlantillaMensaje(codigo,
                        "(mensaje fuera de la muestra del catálogo simulado)",
                        Severidad.INFORMATIVA, null, null, null, null));
    }

    /**
     * Novedades que lleva la cabecera de una cuenta simulada.
     *
     * <p>Códigos y textos reales, y con el vocabulario que de verdad se usa en
     * cabecera —anulaciones y nota crédito—, que no es el de las líneas. Están
     * escogidas para que el perfil local pueda ejercitar los tres casos que si
     * no solo se ven contra el sistema real: una puesta a mano (que se puede
     * quitar), una del motor (que no), y una con huecos sin rellenar, que es el
     * defecto real que hay ahí fuera.
     */
    static final List<PlantillaNovedad> NOVEDADES_CABECERA = List.of(
            new PlantillaNovedad("ANULACION_005", "Anulado por solicitud del paciente",
                    Severidad.BLOQUEANTE, Novedad.ORIGEN_MANUAL),
            new PlantillaNovedad("SURA-RD-025", "Cuenta médica nueva ley de glosas",
                    Severidad.INFORMATIVA, "BENEFITS"),
            new PlantillaNovedad("SURA-AUT-002",
                    "Autorización {2} encontrada y consumida. Autorización inicial: {1}",
                    Severidad.INFORMATIVA, Novedad.ORIGEN_MANUAL));

    static final List<PlantillaPendiente> PENDIENTES_CABECERA = List.of(
            new PlantillaPendiente("PEN-COB", "Requiere validación de cobertura por auditoría médica", false),
            new PlantillaPendiente("PEN-DOC", "Soporte documental incompleto en la cuenta",            true),
            new PlantillaPendiente("PEN-CTO", "Contrato del prestador pendiente de verificación",      false));

    /**
     * Un motivo puesto <b>en los dos niveles</b>: en la cabecera y en las líneas.
     *
     * <p>Es el caso corriente en el sistema de registro —{@code MP_GLOSA_SIN_MOTIVO}
     * está así en producción— y es el único que ejercita de verdad la disyunción
     * de niveles: resolver «solo la cuenta» lo deja en las líneas y al revés, y
     * «donde aplique» tiene que emitir dos operaciones. Sin un motivo compartido
     * ningún escenario del simulador recorría ese camino.
     */
    static final PlantillaPendiente PENDIENTE_EN_AMBOS_NIVELES =
            new PlantillaPendiente("PEN-COB", "Requiere validación de cobertura por auditoría médica", false);

    static final List<PlantillaPendiente> PENDIENTES_LINEA = List.of(
            new PlantillaPendiente("PEN-LIN-COB", "Cobertura de la línea pendiente de validación",       false),
            new PlantillaPendiente("PEN-LIN-TAR", "Tarifa de la línea pendiente de revisión",            false),
            new PlantillaPendiente("PEN-LIN-ADJ", "Adjudicación manual pendiente sobre la línea",        true),
            PENDIENTE_EN_AMBOS_NIVELES);

    /** Errores que devuelve el proceso de envío cuando la cuenta simulada está marcada para fallar. */
    static final List<String> ERRORES_PROCESO = List.of(
            "La línea quedó bloqueada durante la adjudicación",
            "No fue posible recalcular el consumo de límites del afiliado");
}
