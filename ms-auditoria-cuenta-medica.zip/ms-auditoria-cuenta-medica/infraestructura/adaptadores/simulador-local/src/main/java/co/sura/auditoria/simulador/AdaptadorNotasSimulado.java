package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Notas del simulador local: quedan en el log en lugar de viajar a OHI.
 */
@Component
@Profile("local")
public class AdaptadorNotasSimulado implements PuertoNotas {

    private static final Logger log = LoggerFactory.getLogger(AdaptadorNotasSimulado.class);

    private final AlmacenSimulado almacen;

    public AdaptadorNotasSimulado(AlmacenSimulado almacen) {
        this.almacen = almacen;
    }

    @Override
    public Mono<Void> agregarNota(CodigoCuenta codigo, String autor, String texto) {
        return almacen.conLatencia(Mono.<Void>fromRunnable(() -> {
            almacen.exigirCuenta(codigo);   // valida que la cuenta exista, como haría OHI
            log.info("Simulador: nota en {} por {} → {}", codigo.valor(), autor, texto);
        }));
    }
}
