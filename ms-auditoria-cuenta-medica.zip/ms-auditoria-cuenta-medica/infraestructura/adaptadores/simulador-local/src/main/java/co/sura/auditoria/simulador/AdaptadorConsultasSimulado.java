package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Lado de consulta del simulador local (sustituye a {@code AdaptadorConsultasOhi}).
 */
@Component
@Profile("local")
public class AdaptadorConsultasSimulado implements PuertoConsultaCuentas {

    private final AlmacenSimulado almacen;

    public AdaptadorConsultasSimulado(AlmacenSimulado almacen) {
        this.almacen = almacen;
    }

    /** Vacío si la cuenta no existe: el caso de uso lo traduce a CUENTA_NO_ENCONTRADA. */
    @Override
    public Mono<CuentaMedica> buscarPorCodigo(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.cuenta(codigo);
            return cuenta == null ? null : cuenta.cabecera();
        }));
    }

    /**
     * Igual que el adaptador de OHI, en su propia consulta. Aquí no hay diferencia de
     * coste —el catálogo está en memoria—, pero se replica la forma para que el perfil
     * local ejerza el mismo flujo que producción.
     */
    @Override
    public Mono<AccionesDisponibles> consultarAccionesDisponibles(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.cuenta(codigo);
            return cuenta == null ? AccionesDisponibles.ninguna() : cuenta.accionesDisponibles();
        }));
    }

    @Override
    public Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                          int tamanoPagina, boolean incluirTotal) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta    = almacen.exigirCuenta(codigo);
            var elementos = cuenta.pagina(cursor.ultimaReferencia(), tamanoPagina);
            Long total    = incluirTotal ? cuenta.cantidadLineas() : null;

            return Pagina.construir(elementos, tamanoPagina, total,
                    resumen -> resumen.referencia().valor());
        }));
    }

    @Override
    public Mono<LineaCuenta> buscarDetalleLinea(CodigoCuenta codigo, ReferenciaLinea referencia) {
        return almacen.conLatencia(Mono.fromCallable(
                () -> almacen.exigirCuenta(codigo).linea(referencia.valor())));
    }

    @Override
    public Flux<ResumenLinea> recorrerTodasLasLineas(CodigoCuenta codigo, int tamanoPagina) {
        return almacen.conLatencia(Flux.defer(
                () -> Flux.fromIterable(almacen.exigirCuenta(codigo).todasLasLineas())));
    }

    @Override
    public Mono<EstadoProceso> consultarEstadoProceso(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> almacen.exigirCuenta(codigo)
                .estadoProceso(almacen.propiedades().duracionProceso())));
    }
}
