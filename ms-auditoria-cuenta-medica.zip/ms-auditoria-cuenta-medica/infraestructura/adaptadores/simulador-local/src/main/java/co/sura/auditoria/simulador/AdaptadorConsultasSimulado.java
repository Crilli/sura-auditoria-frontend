package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Lado de consulta del simulador local (sustituye a {@code AdaptadorConsultasOhi}).
 */
@Component
@Profile("local")
public class AdaptadorConsultasSimulado implements PuertoConsultaCuentas {

    private final AlmacenSimulado almacen;

    public AdaptadorConsultasSimulado(AlmacenSimulado almacen) {
        this.almacen = almacen;
    }

    /** Vacío si la cuenta no existe: el caso de uso lo traduce a CUENTA_NO_ENCONTRADA. */
    @Override
    public Mono<CuentaMedica> buscarPorCodigo(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.cuenta(codigo);
            return cuenta == null ? null : cuenta.cabecera();
        }));
    }

    /**
     * Igual que el adaptador de OHI, en su propia consulta. Aquí no hay diferencia de
     * coste —el catálogo está en memoria—, pero se replica la forma para que el perfil
     * local ejerza el mismo flujo que producción.
     */
    @Override
    public Mono<AccionesDisponibles> consultarAccionesDisponibles(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.cuenta(codigo);
            return cuenta == null ? AccionesDisponibles.ninguna() : cuenta.accionesDisponibles();
        }));
    }

    /**
     * Reproduce el contrato del listado filtrado sin reproducir su mecánica: aquí
     * las líneas caben en memoria, así que el filtro se aplica entero de una vez.
     *
     * <p>Lo que sí se respeta es lo que el cliente puede observar: el total solo
     * viaja en la primera página <b>y solo si el filtro se empuja entero</b>, igual
     * que contra el sistema de registro. Publicarlo también con un criterio local
     * haría que el perfil local pasara una prueba que el real no pasa.
     */
    @Override
    public Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                          int tamanoPagina, boolean incluirTotal,
                                                          FiltroLineas filtro) {
        var criterios = filtro == null ? FiltroLineas.NINGUNO : filtro;
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.exigirCuenta(codigo);

            var coincidentes = cuenta.todasLasLineas().stream()
                    .filter(l -> cumple(l, criterios))
                    .sorted(java.util.Comparator.comparingLong(l -> l.referencia().valor()))
                    .toList();

            var elementos = coincidentes.stream()
                    .filter(l -> l.referencia().valor() > cursor.ultimaReferencia())
                    .limit(tamanoPagina)
                    .toList();

            Long total = incluirTotal && criterios.seEmpujaEntero()
                    ? (long) coincidentes.size() : null;

            return Pagina.construir(elementos, tamanoPagina, total,
                    resumen -> resumen.referencia().valor());
        }));
    }

    /**
     * El filtro completo sobre una línea.
     *
     * <p>La mitad que el sistema de registro no sabe aplicar se delega en el
     * dominio ({@code cumpleLoQueNoSeEmpuja}), que es donde vive la regla; la otra
     * mitad se evalúa aquí porque contra OHI la resuelve la propia consulta.
     */
    private static boolean cumple(ResumenLinea linea, FiltroLineas filtro) {
        if (filtro.cedulaAfiliado() != null
                && !filtro.cedulaAfiliado().equalsIgnoreCase(linea.codigoAfiliado())) return false;
        if (filtro.desde() != null
                && (linea.fechaInicio() == null || linea.fechaInicio().isBefore(filtro.desde()))) return false;
        if (filtro.hasta() != null
                && (linea.fechaInicio() == null || linea.fechaInicio().isAfter(filtro.hasta()))) return false;
        if (filtro.codigoAutorizacion() != null
                && !empiezaPor(linea.codigoAutorizacion(), filtro.codigoAutorizacion())) return false;
        if (filtro.codigoPrestacion() != null
                && !empiezaPor(linea.codigoProcedimiento(), filtro.codigoPrestacion())) return false;
        return filtro.cumpleLoQueNoSeEmpuja(linea);
    }

    private static boolean empiezaPor(String valor, String prefijo) {
        return valor != null && valor.toUpperCase().startsWith(prefijo.toUpperCase());
    }

    @Override
    public Mono<ResumenFiltrosLineas> resumirFiltrosDeLineas(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var lineas = almacen.exigirCuenta(codigo).todasLasLineas();
            if (lineas.isEmpty()) return ResumenFiltrosLineas.vacio();

            var porAfiliado = new java.util.LinkedHashMap<String, Integer>();
            var nombres     = new java.util.LinkedHashMap<String, String>();
            var porCatalogo = new java.util.EnumMap<CatalogoPrestacion, Integer>(CatalogoPrestacion.class);
            java.time.LocalDate primera = null, ultima = null;
            java.math.BigDecimal glosaMaxima = null;
            int conGlosa = 0;

            for (var l : lineas) {
                if (l.codigoAfiliado() != null) {
                    porAfiliado.merge(l.codigoAfiliado(), 1, Integer::sum);
                    nombres.putIfAbsent(l.codigoAfiliado(), l.nombreAfiliado());
                }
                porCatalogo.merge(CatalogoPrestacion.de(l.catalogoProcedimiento()), 1, Integer::sum);
                if (l.fechaInicio() != null) {
                    if (primera == null || l.fechaInicio().isBefore(primera)) primera = l.fechaInicio();
                    if (ultima  == null || l.fechaInicio().isAfter(ultima))   ultima  = l.fechaInicio();
                }
                if (l.valorGlosado() != null && l.valorGlosado().signum() > 0) {
                    conGlosa++;
                    if (glosaMaxima == null || l.valorGlosado().compareTo(glosaMaxima) > 0) {
                        glosaMaxima = l.valorGlosado();
                    }
                }
            }

            return new ResumenFiltrosLineas(
                    porAfiliado.entrySet().stream()
                            .map(e -> new ResumenFiltrosLineas.AfiliadoConLineas(
                                    e.getKey(), nombres.get(e.getKey()), e.getValue()))
                            .sorted(java.util.Comparator
                                    .comparingInt(ResumenFiltrosLineas.AfiliadoConLineas::lineas).reversed())
                            .toList(),
                    porCatalogo.entrySet().stream()
                            .map(e -> new ResumenFiltrosLineas.CatalogoConLineas(e.getKey(), e.getValue()))
                            .sorted(java.util.Comparator
                                    .comparingInt(ResumenFiltrosLineas.CatalogoConLineas::lineas).reversed())
                            .toList(),
                    primera, ultima, glosaMaxima, conGlosa, lineas.size());
        }));
    }

    @Override
    public Mono<LineaCuenta> buscarDetalleLinea(CodigoCuenta codigo, ReferenciaLinea referencia) {
        return almacen.conLatencia(Mono.fromCallable(
                () -> almacen.exigirCuenta(codigo).linea(referencia.valor())));
    }

    @Override
    public Flux<ResumenLinea> recorrerTodasLasLineas(CodigoCuenta codigo, int tamanoPagina) {
        return almacen.conLatencia(Flux.defer(
                () -> Flux.fromIterable(almacen.exigirCuenta(codigo).todasLasLineas())));
    }

    @Override
    public Mono<EstadoProceso> consultarEstadoProceso(CodigoCuenta codigo) {
        return almacen.conLatencia(Mono.fromCallable(() -> almacen.exigirCuenta(codigo)
                .estadoProceso(almacen.propiedades().duracionProceso())));
    }
}
