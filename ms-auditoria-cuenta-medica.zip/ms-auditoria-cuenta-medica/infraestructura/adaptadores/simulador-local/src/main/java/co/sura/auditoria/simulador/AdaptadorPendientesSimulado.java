package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Gestión de pendientes del simulador local (sustituye a {@code AdaptadorPendientesOhi}).
 */
@Component
@Profile("local")
public class AdaptadorPendientesSimulado implements PuertoPendientes {

    private final AlmacenSimulado almacen;

    public AdaptadorPendientesSimulado(AlmacenSimulado almacen) {
        this.almacen = almacen;
    }

    @Override
    public Flux<MotivoPendiente> listarSinResolver(CodigoCuenta codigo) {
        return almacen.conLatencia(Flux.defer(
                () -> Flux.fromIterable(almacen.exigirCuenta(codigo).pendientesSinResolver())));
    }

    @Override
    public Mono<Void> resolverEnCuentaYLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, true);
    }

    @Override
    public Mono<Void> resolverSoloEnLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, false);
    }

    @Override
    public Mono<Void> resolverPendienteCabecera(long identificadorPendiente) {
        return resolverEnTodoElCatalogo(identificadorPendiente, true);
    }

    @Override
    public Mono<Void> resolverPendienteLinea(long identificadorPendiente) {
        return resolverEnTodoElCatalogo(identificadorPendiente, false);
    }

    private Mono<Void> resolver(CodigoCuenta codigo, long identificadorMotivo, boolean incluirCabecera) {
        return almacen.conLatencia(Mono.<Void>fromRunnable(() -> {
            int resueltos = almacen.exigirCuenta(codigo).resolverMotivo(identificadorMotivo, incluirCabecera);
            if (resueltos == 0) throw sinPendiente(identificadorMotivo, codigo.valor());
        }));
    }

    private Mono<Void> resolverEnTodoElCatalogo(long identificadorPendiente, boolean incluirCabecera) {
        return almacen.conLatencia(Mono.<Void>fromRunnable(() -> {
            int resueltos = almacen.todas().stream()
                    .mapToInt(cuenta -> cuenta.resolverMotivo(identificadorPendiente, incluirCabecera))
                    .sum();
            if (resueltos == 0) throw sinPendiente(identificadorPendiente, "cualquier cuenta");
        }));
    }

    /**
     * El catálogo de errores de dominio no tiene una variante «pendiente no encontrado»;
     * se reporta como solicitud inválida (400) para que el cliente corrija el identificador
     * en vez de creer que la resolución tuvo efecto.
     */
    private ExcepcionDeDominio sinPendiente(long identificador, String ambito) {
        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "No existe un pendiente sin resolver con identificador %d en %s"
                        .formatted(identificador, ambito)));
    }
}
