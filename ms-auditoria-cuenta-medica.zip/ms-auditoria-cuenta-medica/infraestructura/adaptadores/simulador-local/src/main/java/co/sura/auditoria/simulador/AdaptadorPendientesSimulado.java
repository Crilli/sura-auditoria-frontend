package co.sura.auditoria.simulador;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.Pagina;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Gestión de pendientes del simulador local (sustituye a {@code AdaptadorPendientesOhi}).
 */
@Component
@Profile("local")
public class AdaptadorPendientesSimulado implements PuertoPendientes {

    private final AlmacenSimulado almacen;

    public AdaptadorPendientesSimulado(AlmacenSimulado almacen) {
        this.almacen = almacen;
    }

    @Override
    public Flux<MotivoPendiente> listarSinResolver(CodigoCuenta codigo) {
        return almacen.conLatencia(Flux.defer(
                () -> Flux.fromIterable(almacen.exigirCuenta(codigo).pendientesSinResolver())));
    }

    /**
     * Reproduce la forma de la página de OHI sin reproducir su mecánica: aquí la
     * lista cabe en memoria, así que el keyset se simula cortando sobre ella.
     *
     * <p>Lo que sí se respeta es el contrato que ve el cliente: la cabecera va
     * como prefijo de la primera página consumiendo sus huecos, el cursor avanza
     * solo por la referencia de línea, y el total únicamente viaja en la primera.
     */
    @Override
    public Mono<PaginaPendientes> listarPaginado(CodigoCuenta codigo, Cursor cursor,
                                                 int tamanoPagina, boolean incluirTotal,
                                                 String codigoMotivo, FiltroBloqueo bloqueo) {
        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.exigirCuenta(codigo);
            var estado = cuenta.estado();
            // Mismo criterio que la ACL: el filtro de bloqueo se resuelve contra el
            // estado, no contra el motivo. Aquí cabe en memoria, así que en vez de
            // traducirlo a una condición de consulta se aplica la regla del dominio.
            var todos = cuenta.pendientesSinResolver().stream()
                    .filter(p -> codigoMotivo == null || codigoMotivo.equals(p.codigo()))
                    .filter(p -> switch (bloqueo) {
                        case TODOS          -> true;
                        case BLOQUEANTES    -> p.bloqueaEnvioEn(estado);
                        case NO_BLOQUEANTES -> !p.bloqueaEnvioEn(estado);
                    })
                    .toList();

            // El keyset avanza por el identificador del pendiente, no por la
            // referencia de la línea: ver la nota de AdaptadorPendientesOhi.componer.
            var cabecera = todos.stream().filter(p -> p.referenciaLinea() == null).toList();
            var lineas   = todos.stream().filter(p -> p.referenciaLinea() != null)
                    .sorted(java.util.Comparator.comparingLong(MotivoPendiente::identificador))
                    .toList();

            boolean primera = cursor.esPrimeraPagina();
            int huecos = primera ? Math.max(1, tamanoPagina - cabecera.size()) : tamanoPagina;

            var tramo = lineas.stream()
                    .filter(p -> primera || p.identificador() > cursor.ultimaReferencia())
                    .limit(huecos)
                    .toList();

            var pagina = Pagina.construir(tramo, huecos, null, MotivoPendiente::identificador);

            var elementos = new java.util.ArrayList<MotivoPendiente>();
            if (primera) elementos.addAll(cabecera);
            elementos.addAll(pagina.elementos());

            Long total = incluirTotal ? (long) todos.size() : null;
            return new PaginaPendientes(
                    new Pagina<>(List.copyOf(elementos), pagina.cursorSiguiente(),
                                 java.util.Optional.ofNullable(total),
                                 Math.max(tamanoPagina, elementos.size())),
                    estado);
        }));
    }

    @Override
    public Flux<ResumenMotivoPendiente> resumirMotivos(CodigoCuenta codigo) {
        return almacen.conLatencia(Flux.defer(() -> {
            var cuenta = almacen.exigirCuenta(codigo);
            var estado = cuenta.estado();
            var porCodigo = new java.util.LinkedHashMap<String, List<MotivoPendiente>>();
            for (var p : cuenta.pendientesSinResolver()) {
                porCodigo.computeIfAbsent(p.codigo(), c -> new java.util.ArrayList<>()).add(p);
            }
            return Flux.fromIterable(porCodigo.entrySet().stream()
                    .map(e -> new ResumenMotivoPendiente(
                            e.getKey(),
                            e.getValue().stream().map(MotivoPendiente::descripcion)
                                    .filter(java.util.Objects::nonNull).findFirst().orElse(null),
                            e.getValue().size(),
                            // Líneas distintas, no filas: un motivo repetido en la
                            // misma línea afecta a una sola.
                            (int) e.getValue().stream().map(MotivoPendiente::numeroLinea)
                                    .filter(java.util.Objects::nonNull).distinct().count(),
                            e.getValue().stream().anyMatch(p -> p.referenciaLinea() == null),
                            e.getValue().get(0).soloAdjudicacion(),
                            e.getValue().get(0).bloqueaEnvioEn(estado)))
                    .toList());
        }));
    }

    /**
     * Reproduce la resolución conjunta: por código de motivo, a un solo nivel y
     * con la posibilidad de salir parcial.
     *
     * <p>Lo de «parcial» no es adorno del simulador: en el sistema de registro es
     * el caso corriente —un motivo que otro auditor acababa de resolver, una
     * línea que ya no está— y el único sitio donde se reporta es la operación de
     * larga duración. Si aquí todo saliera siempre completo, el camino que trata
     * el fallo parcial no se podría ejercitar en ningún perfil, porque contra
     * producción no se escribe.
     *
     * <p>Lo que no se reproduce es la asincronía: aquí la operación ya terminó
     * cuando se contesta. La referencia que se devuelve es sintética y tiene la
     * forma de la real (un número) para que el cliente no distinga el perfil.
     */
    @Override
    public Mono<ResultadoResolucionMasiva> resolverMotivos(CodigoCuenta codigo,
                                                           java.util.Set<String> codigosMotivo,
                                                           NivelPendiente nivel) {
        if (codigosMotivo == null || codigosMotivo.isEmpty())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se indicó ningún motivo a resolver")));

        return almacen.conLatencia(Mono.fromCallable(() -> {
            var cuenta = almacen.exigirCuenta(codigo);

            // La palanca de fallo parcial: ese motivo se aparta antes de resolver,
            // así que se reporta como no resuelto y además no se resuelve.
            var vetado = almacen.propiedades().motivoQueNoSeResuelve();
            var aResolver = codigosMotivo.stream()
                    .filter(c -> vetado == null || vetado.isBlank() || !c.equals(vetado))
                    .collect(java.util.stream.Collectors.toCollection(java.util.LinkedHashSet::new));

            // Qué había antes, por motivo y al nivel pedido: es lo que permite
            // decir después qué no se pudo resolver.
            var antes = new java.util.LinkedHashMap<String, Long>();
            for (var pendiente : cuenta.pendientesSinResolver()) {
                if (!aResolver.contains(pendiente.codigo())) continue;
                if (pendiente.nivel() != nivel) continue;
                antes.merge(pendiente.codigo(), 1L, Long::sum);
            }

            cuenta.resolverMotivosPorCodigo(aResolver, nivel);

            var fallos = codigosMotivo.stream()
                    .filter(c -> !antes.containsKey(c))
                    .map(c -> new ResultadoResolucionMasiva.Fallo(
                            "CLA-IP-RPND-001", c,
                            c.equals(vetado)
                                ? "Otro auditor resolvió el motivo %s antes de que llegara esta operación"
                                        .formatted(c)
                                : "El motivo %s no tenía pendientes sin resolver %s"
                                        .formatted(c, nivel == NivelPendiente.CABECERA
                                                ? "en la cabecera de la cuenta"
                                                : "en las líneas")))
                    .toList();

            var referencia = String.valueOf(Math.abs(
                    (codigo.valor() + nivel.name() + codigosMotivo).hashCode()));

            return new ResultadoResolucionMasiva(
                    java.util.List.of(referencia),
                    fallos.isEmpty() ? ResultadoResolucionMasiva.Desenlace.COMPLETO
                                     : ResultadoResolucionMasiva.Desenlace.PARCIAL,
                    fallos);
        }));
    }

    @Override
    public Mono<Void> resolverEnCuentaYLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, true);
    }

    @Override
    public Mono<Void> resolverSoloEnLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, false);
    }

    @Override
    public Mono<Void> resolverPendienteCabecera(long identificadorPendiente) {
        return resolverEnTodoElCatalogo(identificadorPendiente, true);
    }

    @Override
    public Mono<Void> resolverPendienteLinea(long identificadorPendiente) {
        return resolverEnTodoElCatalogo(identificadorPendiente, false);
    }

    private Mono<Void> resolver(CodigoCuenta codigo, long identificadorMotivo, boolean incluirCabecera) {
        return almacen.conLatencia(Mono.<Void>fromRunnable(() -> {
            int resueltos = almacen.exigirCuenta(codigo).resolverMotivo(identificadorMotivo, incluirCabecera);
            if (resueltos == 0) throw sinPendiente(identificadorMotivo, codigo.valor());
        }));
    }

    private Mono<Void> resolverEnTodoElCatalogo(long identificadorPendiente, boolean incluirCabecera) {
        return almacen.conLatencia(Mono.<Void>fromRunnable(() -> {
            int resueltos = almacen.todas().stream()
                    .mapToInt(cuenta -> cuenta.resolverMotivo(identificadorPendiente, incluirCabecera))
                    .sum();
            if (resueltos == 0) throw sinPendiente(identificadorPendiente, "cualquier cuenta");
        }));
    }

    /**
     * El catálogo de errores de dominio no tiene una variante «pendiente no encontrado»;
     * se reporta como solicitud inválida (400) para que el cliente corrija el identificador
     * en vez de creer que la resolución tuvo efecto.
     */
    private ExcepcionDeDominio sinPendiente(long identificador, String ambito) {
        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "No existe un pendiente sin resolver con identificador %d en %s"
                        .formatted(identificador, ambito)));
    }
}
