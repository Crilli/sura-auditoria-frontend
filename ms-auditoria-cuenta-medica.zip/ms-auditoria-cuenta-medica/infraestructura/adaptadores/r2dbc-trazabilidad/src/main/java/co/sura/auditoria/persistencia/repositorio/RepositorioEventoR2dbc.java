package co.sura.auditoria.persistencia.repositorio;

import co.sura.auditoria.persistencia.entidad.EntidadEventoAuditoria;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;

import java.util.UUID;

public interface RepositorioEventoR2dbc extends R2dbcRepository<EntidadEventoAuditoria, UUID> {
    Flux<EntidadEventoAuditoria> findByCodigoCuentaOrderByOcurridoEnDesc(String codigoCuenta);
}
