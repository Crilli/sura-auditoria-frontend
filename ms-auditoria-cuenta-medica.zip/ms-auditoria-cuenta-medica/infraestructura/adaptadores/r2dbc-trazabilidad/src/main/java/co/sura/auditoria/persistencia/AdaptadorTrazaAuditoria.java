package co.sura.auditoria.persistencia;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.puertos.RepositorioTrazaAuditoria;
import co.sura.auditoria.persistencia.mapeo.MapeadorEventoAuditoria;
import co.sura.auditoria.persistencia.repositorio.RepositorioEventoR2dbc;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorTrazaAuditoria implements RepositorioTrazaAuditoria {

    private final RepositorioEventoR2dbc repositorio;

    public AdaptadorTrazaAuditoria(RepositorioEventoR2dbc repositorio) {
        this.repositorio = repositorio;
    }

    @Override
    public Mono<EventoAuditoria> guardar(EventoAuditoria evento) {
        var entidad = MapeadorEventoAuditoria.aEntidad(evento);
        // Usamos save que en Spring Data R2DBC hace un INSERT si no existe
        return repositorio.save(entidad)
                .map(MapeadorEventoAuditoria::aDominio);
    }

    @Override
    public Flux<EventoAuditoria> buscarPorCuenta(String codigoCuenta, int limite) {
        return repositorio.findByCodigoCuentaOrderByOcurridoEnDesc(codigoCuenta)
                .take(limite)
                .map(MapeadorEventoAuditoria::aDominio);
    }
}
