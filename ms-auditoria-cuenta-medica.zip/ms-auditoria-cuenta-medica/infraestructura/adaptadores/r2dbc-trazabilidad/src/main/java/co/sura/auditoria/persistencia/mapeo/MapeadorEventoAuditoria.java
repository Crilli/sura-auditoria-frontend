package co.sura.auditoria.persistencia.mapeo;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.auditoria.ResultadoEvento;
import co.sura.auditoria.modelo.auditoria.TipoEvento;
import co.sura.auditoria.persistencia.entidad.EntidadEventoAuditoria;

/**
 * Traduce entre el evento de dominio y la fila de la tabla.
 * Los enum del dominio se guardan por nombre para que la tabla sea legible
 * y no dependa del orden de declaración.
 */
public final class MapeadorEventoAuditoria {

    private MapeadorEventoAuditoria() {}

    public static EntidadEventoAuditoria aEntidad(EventoAuditoria evento) {
        var entidad = new EntidadEventoAuditoria();
        entidad.setIdentificador(evento.identificador());
        entidad.setCodigoCuenta(evento.codigoCuenta());
        entidad.setReferenciaLinea(evento.referenciaLinea());
        entidad.setTipo(evento.tipo() == null ? null : evento.tipo().name());
        entidad.setAutor(evento.autor());
        entidad.setDetalle(evento.detalle());
        entidad.setResultado(evento.resultado() == null ? null : evento.resultado().name());
        entidad.setCodigoError(evento.codigoError());
        entidad.setIdCorrelacion(evento.idCorrelacion());
        entidad.setOcurridoEn(evento.ocurridoEn());
        return entidad;
    }

    public static EventoAuditoria aDominio(EntidadEventoAuditoria entidad) {
        return new EventoAuditoria(
                entidad.getIdentificador(),
                entidad.getCodigoCuenta(),
                entidad.getReferenciaLinea(),
                entidad.getTipo() == null ? null : TipoEvento.valueOf(entidad.getTipo()),
                entidad.getAutor(),
                entidad.getDetalle(),
                entidad.getResultado() == null ? null : ResultadoEvento.valueOf(entidad.getResultado()),
                entidad.getCodigoError(),
                entidad.getIdCorrelacion(),
                entidad.getOcurridoEn());
    }
}
