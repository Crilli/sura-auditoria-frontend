package co.sura.auditoria.persistencia.entidad;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.UUID;

@Table("EVENTOS_AUDITORIA")
public class EntidadEventoAuditoria {

    @Id
    private UUID identificador;
    private String codigoCuenta;
    private Long referenciaLinea;
    private String tipo;
    private String autor;
    private String detalle;
    private String resultado;
    private String codigoError;
    private String idCorrelacion;
    private Instant ocurridoEn;

    // Getters y Setters

    public UUID getIdentificador() { return identificador; }
    public void setIdentificador(UUID identificador) { this.identificador = identificador; }

    public String getCodigoCuenta() { return codigoCuenta; }
    public void setCodigoCuenta(String codigoCuenta) { this.codigoCuenta = codigoCuenta; }

    public Long getReferenciaLinea() { return referenciaLinea; }
    public void setReferenciaLinea(Long referenciaLinea) { this.referenciaLinea = referenciaLinea; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public String getDetalle() { return detalle; }
    public void setDetalle(String detalle) { this.detalle = detalle; }

    public String getResultado() { return resultado; }
    public void setResultado(String resultado) { this.resultado = resultado; }

    public String getCodigoError() { return codigoError; }
    public void setCodigoError(String codigoError) { this.codigoError = codigoError; }

    public String getIdCorrelacion() { return idCorrelacion; }
    public void setIdCorrelacion(String idCorrelacion) { this.idCorrelacion = idCorrelacion; }

    public Instant getOcurridoEn() { return ocurridoEn; }
    public void setOcurridoEn(Instant ocurridoEn) { this.ocurridoEn = ocurridoEn; }
}
