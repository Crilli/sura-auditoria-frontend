package co.sura.auditoria.persistencia;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.auditoria.ResultadoEvento;
import co.sura.auditoria.modelo.auditoria.TipoEvento;
import co.sura.auditoria.persistencia.entidad.EntidadEventoAuditoria;
import co.sura.auditoria.persistencia.mapeo.MapeadorEventoAuditoria;
import co.sura.auditoria.persistencia.repositorio.RepositorioEventoR2dbc;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("Trazabilidad en base de datos")
class TrazabilidadTest {

    private static final UUID ID = UUID.randomUUID();
    private static final Instant CUANDO = Instant.parse("2026-08-21T11:04:05Z");

    private static EventoAuditoria completo() {
        return new EventoAuditoria(ID, "CM-108800618430", 148111592284L,
                TipoEvento.LINEA_GUARDADA, "auditor", "detalle",
                ResultadoEvento.EXITOSO, null, "corr-1", CUANDO);
    }

    @Nested
    @DisplayName("MapeadorEventoAuditoria")
    class Mapeador {

        @Test
        @DisplayName("el viaje de ida y vuelta conserva el evento entero")
        void laIdaYVueltaConservaElEvento() {
            var original = completo();

            var recuperado = MapeadorEventoAuditoria.aDominio(
                    MapeadorEventoAuditoria.aEntidad(original));

            assertThat(recuperado).isEqualTo(original);
        }

        @Test
        @DisplayName("los enumerados se guardan por su nombre, no por su ordinal")
        void losEnumeradosSeGuardanPorNombre() {
            // Por ordinal, insertar un valor nuevo en medio del enum corrompería
            // en silencio todo el histórico ya guardado.
            var entidad = MapeadorEventoAuditoria.aEntidad(completo());

            assertThat(entidad.getTipo()).isEqualTo("LINEA_GUARDADA");
            assertThat(entidad.getResultado()).isEqualTo("EXITOSO");
        }

        @Test
        @DisplayName("un tipo o un resultado nulos no revientan en ninguna dirección")
        void losNulosNoRevientan() {
            var sinEnums = new EventoAuditoria(ID, "CM-1", null, null, "autor", "d",
                    null, null, null, CUANDO);

            var entidad = MapeadorEventoAuditoria.aEntidad(sinEnums);
            assertThat(entidad.getTipo()).isNull();
            assertThat(entidad.getResultado()).isNull();

            assertThat(MapeadorEventoAuditoria.aDominio(entidad)).isEqualTo(sinEnums);
        }

        @Test
        @DisplayName("un evento de cabecera guarda la referencia de línea en null")
        void unEventoDeCabeceraGuardaLineaNula() {
            var deCabecera = EventoAuditoria.cuentaEnviada("CM-1", "ACEPTAR", "autor");

            assertThat(MapeadorEventoAuditoria.aEntidad(deCabecera).getReferenciaLinea())
                    .isNull();
        }

        @Test
        @DisplayName("el instante se conserva sin perder precisión")
        void elInstanteSeConserva() {
            var preciso = Instant.parse("2026-08-21T11:04:05.728Z");
            var evento = new EventoAuditoria(ID, "CM-1", null, TipoEvento.CUENTA_CONSULTADA,
                    "autor", "d", ResultadoEvento.EXITOSO, null, null, preciso);

            assertThat(MapeadorEventoAuditoria.aDominio(
                    MapeadorEventoAuditoria.aEntidad(evento)).ocurridoEn())
                    .isEqualTo(preciso);
        }
    }

    @Nested
    @DisplayName("AdaptadorTrazaAuditoria")
    class Adaptador {

        @Mock RepositorioEventoR2dbc repositorio;
        @InjectMocks AdaptadorTrazaAuditoria adaptador;

        @Test
        @DisplayName("al guardar, lo que vuelve es lo que la base confirmó, no lo que se mandó")
        void alGuardarVuelveLoQueLaBaseConfirmo() {
            var entidadGuardada = MapeadorEventoAuditoria.aEntidad(completo());
            when(repositorio.save(any())).thenReturn(Mono.just(entidadGuardada));

            StepVerifier.create(adaptador.guardar(completo()))
                    .expectNext(completo())
                    .verifyComplete();

            var captor = ArgumentCaptor.forClass(EntidadEventoAuditoria.class);
            verify(repositorio).save(captor.capture());
            assertThat(captor.getValue().getCodigoCuenta()).isEqualTo("CM-108800618430");
        }

        @Test
        @DisplayName("al buscar por cuenta, el límite recorta de verdad")
        void elLimiteRecorta() {
            when(repositorio.findByCodigoCuentaOrderByOcurridoEnDesc("CM-1"))
                    .thenReturn(Flux.just(
                            MapeadorEventoAuditoria.aEntidad(completo()),
                            MapeadorEventoAuditoria.aEntidad(completo()),
                            MapeadorEventoAuditoria.aEntidad(completo())));

            StepVerifier.create(adaptador.buscarPorCuenta("CM-1", 2))
                    .expectNextCount(2)
                    .verifyComplete();
        }

        @Test
        @DisplayName("una cuenta sin traza devuelve un flujo vacío, no un error")
        void sinTrazaDevuelveFlujoVacio() {
            when(repositorio.findByCodigoCuentaOrderByOcurridoEnDesc("CM-1"))
                    .thenReturn(Flux.empty());

            StepVerifier.create(adaptador.buscarPorCuenta("CM-1", 10)).verifyComplete();
        }

        @Test
        @DisplayName("un error de la base se propaga: perder la traza en silencio no vale")
        void unErrorDeLaBaseSePropaga() {
            var caida = new IllegalStateException("conexión perdida");
            when(repositorio.save(any())).thenReturn(Mono.error(caida));

            StepVerifier.create(adaptador.guardar(completo()))
                    .expectErrorMatches(e -> e == caida)
                    .verify();
        }
    }
}
