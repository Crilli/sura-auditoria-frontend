package co.sura.auditoria.eventos;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorPublicadorEventos implements PublicadorEventosAuditoria {

    private static final Logger log = LoggerFactory.getLogger(AdaptadorPublicadorEventos.class);
    private static final String BINDING_NAME = "eventosAuditoria-out-0";

    private final StreamBridge streamBridge;

    public AdaptadorPublicadorEventos(StreamBridge streamBridge) {
        this.streamBridge = streamBridge;
    }

    @Override
    public Mono<Void> publicar(EventoAuditoria evento) {
        return Mono.fromRunnable(() -> {
            try {
                var mensaje = MessageBuilder.withPayload(evento)
                        // Headers para enrutamiento o correlación
                        .setHeader("tipoEvento", evento.tipo())
                        .setHeader("idCorrelacion", evento.idCorrelacion())
                        .build();

                boolean enviado = streamBridge.send(BINDING_NAME, mensaje);
                if (!enviado) {
                    log.warn("El bus no aceptó el evento de auditoría {}", evento.identificador());
                } else {
                    log.debug("Evento de auditoría {} publicado", evento.identificador());
                }
            } catch (Exception e) {
                // Según ADR, la traza NUNCA hace fallar el caso de uso
                log.error("Excepción al publicar evento de auditoría {}: {}", 
                          evento.identificador(), e.getMessage());
            }
        });
    }
}
