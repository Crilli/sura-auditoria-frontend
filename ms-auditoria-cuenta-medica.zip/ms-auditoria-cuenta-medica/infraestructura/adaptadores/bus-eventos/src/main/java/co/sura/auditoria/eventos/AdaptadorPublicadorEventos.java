package co.sura.auditoria.eventos;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

/**
 * Publica la traza de auditoría en el bus.
 *
 * <h3>Por qué esto no corre en el hilo que llama</h3>
 * {@link StreamBridge#send(String, Object)} es la API <b>síncrona</b> de Spring Cloud
 * Stream: contra el broker puede esperar al canal, a los <i>publisher confirms</i> o al
 * reintento del binder. Y {@code Mono.fromRunnable} ejecuta su bloque en el hilo que se
 * suscribe, que en WebFlux es un hilo del event loop de Netty — tantos como núcleos, dos
 * o cuatro en un contenedor corriente.
 *
 * <p>Sin el {@code subscribeOn} de abajo, un broker lento se comía esos pocos hilos y el
 * servicio dejaba de responder <b>también a las consultas</b>, que no tienen nada que ver
 * con el bus. Es justo el fallo que los circuit breakers segmentados de la ACL evitan para
 * OHI y que aquí quedaba sin contener.
 *
 * <p>{@code boundedElastic} es el planificador pensado para envolver llamadas bloqueantes:
 * crece bajo demanda y está acotado, así que una saturación del broker se traduce en
 * trazas encoladas y nunca en un servidor que no acepta peticiones.
 */
@Component
public class AdaptadorPublicadorEventos implements PublicadorEventosAuditoria {

    private static final Logger log = LoggerFactory.getLogger(AdaptadorPublicadorEventos.class);
    private static final String BINDING_NAME = "eventosAuditoria-out-0";

    private final Scheduler planificador;

    private final StreamBridge streamBridge;

    /**
     * El que usa Spring. La anotación **no es decorativa**: desde que existe el segundo
     * constructor hay dos candidatos, y con dos candidatos sin anotar Spring deja de elegir
     * y se va al constructor vacío, que no existe. El síntoma es un arranque roto con
     * «No default constructor found» que no menciona ni el planificador ni las pruebas.
     */
    @Autowired
    public AdaptadorPublicadorEventos(StreamBridge streamBridge) {
        this(streamBridge, Schedulers.boundedElastic());
    }

    /** Deja inyectar el planificador para poder comprobarlo en una prueba. */
    AdaptadorPublicadorEventos(StreamBridge streamBridge, Scheduler planificador) {
        this.streamBridge = streamBridge;
        this.planificador = planificador;
    }

    @Override
    public Mono<Void> publicar(EventoAuditoria evento) {
        return Mono.fromRunnable(() -> {
            try {
                var mensaje = MessageBuilder.withPayload(evento)
                        // Headers para enrutamiento o correlación
                        .setHeader("tipoEvento", evento.tipo())
                        .setHeader("idCorrelacion", evento.idCorrelacion())
                        .build();

                boolean enviado = streamBridge.send(BINDING_NAME, mensaje);
                if (!enviado) {
                    log.warn("El bus no aceptó el evento de auditoría {}", evento.identificador());
                } else {
                    log.debug("Evento de auditoría {} publicado", evento.identificador());
                }
            } catch (Exception e) {
                // Según ADR, la traza NUNCA hace fallar el caso de uso
                log.error("Excepción al publicar evento de auditoría {}: {}",
                          evento.identificador(), e.getMessage());
            }
        }).subscribeOn(planificador).then();
    }
}
