package co.sura.auditoria.eventos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.auditoria.TipoEvento;
import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.messaging.Message;
import reactor.core.scheduler.Schedulers;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("AdaptadorPublicadorEventos")
class AdaptadorPublicadorEventosTest {

    private static final String BINDING = "eventosAuditoria-out-0";

    @Mock StreamBridge streamBridge;

    /**
     * Para lo que no es el planificador se usa {@code immediate}: así las aserciones son
     * deterministas y no dependen de una espera. Que el planificador real saque el envío
     * del hilo que llama se comprueba aparte, en {@link FueraDelHiloQueLlama}.
     */
    private AdaptadorPublicadorEventos adaptadorDeterminista() {
        return new AdaptadorPublicadorEventos(streamBridge, Schedulers.immediate());
    }

    private static EventoAuditoria evento() {
        return EventoAuditoria.accionEjecutada("CM-108800618430", "ENVIAR", "auditor");
    }

    @Test
    @DisplayName("publica en el binding de auditoría")
    void publicaEnElBindingDeAuditoria() {
        when(streamBridge.send(eq(BINDING), any(Message.class))).thenReturn(true);

        StepVerifier.create(adaptadorDeterminista().publicar(evento())).verifyComplete();

        verify(streamBridge).send(eq(BINDING), any(Message.class));
    }

    @Test
    @DisplayName("el mensaje lleva el tipo de evento en una cabecera, para poder enrutarlo")
    void elMensajeLlevaElTipoEnCabecera() {
        when(streamBridge.send(eq(BINDING), any(Message.class))).thenReturn(true);
        var unEvento = evento();

        StepVerifier.create(adaptadorDeterminista().publicar(unEvento)).verifyComplete();

        var captor = ArgumentCaptor.forClass(Message.class);
        verify(streamBridge).send(eq(BINDING), captor.capture());
        assertThat(captor.getValue().getHeaders())
                .containsEntry("tipoEvento", TipoEvento.ACCION_EJECUTADA);
        assertThat(captor.getValue().getPayload()).isEqualTo(unEvento);
    }

    @Test
    @DisplayName("si el bus RECHAZA el mensaje, el flujo igual se completa sin error")
    void siElBusRechazaElFlujoSeCompleta() {
        // La traza no puede tumbar el comando que ya se aplicó en OHI.
        when(streamBridge.send(eq(BINDING), any(Message.class))).thenReturn(false);

        StepVerifier.create(adaptadorDeterminista().publicar(evento())).verifyComplete();
    }

    @Test
    @DisplayName("si el bus LANZA una excepción, tampoco se propaga")
    void siElBusLanzaTampocoSePropaga() {
        when(streamBridge.send(eq(BINDING), any(Message.class)))
                .thenThrow(new IllegalStateException("broker caído"));

        StepVerifier.create(adaptadorDeterminista().publicar(evento())).verifyComplete();
    }

    @Test
    @DisplayName("es perezoso: no toca el bus hasta que alguien se suscribe")
    void esPerezoso() {
        adaptadorDeterminista().publicar(evento());

        verify(streamBridge, never()).send(any(), any(Message.class));
    }

    @Nested
    @DisplayName("el envío sale del hilo que llama")
    class FueraDelHiloQueLlama {

        /**
         * La razón de ser del {@code subscribeOn}: {@code StreamBridge.send} es síncrono y,
         * sin él, se ejecutaba en el event loop de Netty. Un broker lento dejaba al servicio
         * sin hilos para atender ni siquiera las consultas.
         */
        @Test
        @DisplayName("el envío NO ocurre en el hilo del suscriptor, sino en boundedElastic")
        void elEnvioNoOcurreEnElHiloDelSuscriptor() throws Exception {
            var hiloDelEnvio = new AtomicReference<String>();
            var enviado = new CountDownLatch(1);
            when(streamBridge.send(eq(BINDING), any(Message.class))).thenAnswer(invocacion -> {
                hiloDelEnvio.set(Thread.currentThread().getName());
                enviado.countDown();
                return true;
            });

            // El adaptador de producción, con su planificador real.
            var adaptador = new AdaptadorPublicadorEventos(streamBridge);
            var hiloQueLlama = Thread.currentThread().getName();

            adaptador.publicar(evento()).subscribe();

            assertThat(enviado.await(5, TimeUnit.SECONDS))
                    .as("el envío debería haber ocurrido")
                    .isTrue();
            assertThat(hiloDelEnvio.get())
                    .as("si coincide con el hilo que llama, el subscribeOn se perdió")
                    .isNotEqualTo(hiloQueLlama)
                    .startsWith("boundedElastic-");
        }

        @Test
        @DisplayName("quien publica no espera al broker: devuelve antes de que el envío acabe")
        void quienPublicaNoEsperaAlBroker() throws Exception {
            // Un broker que tarda: el hilo que llama no debe quedarse esperándolo.
            var liberar = new CountDownLatch(1);
            var entroAlEnvio = new CountDownLatch(1);
            when(streamBridge.send(eq(BINDING), any(Message.class))).thenAnswer(invocacion -> {
                entroAlEnvio.countDown();
                liberar.await(5, TimeUnit.SECONDS);
                return true;
            });

            var adaptador = new AdaptadorPublicadorEventos(streamBridge);

            var antes = System.nanoTime();
            adaptador.publicar(evento()).subscribe();
            var tardanza = Duration.ofNanos(System.nanoTime() - antes);

            assertThat(entroAlEnvio.await(5, TimeUnit.SECONDS)).isTrue();
            assertThat(tardanza)
                    .as("suscribirse no debe costar lo que cuesta el broker")
                    .isLessThan(Duration.ofSeconds(1));

            liberar.countDown();
        }
    }
    @Nested
    @DisplayName("el constructor que usa Spring")
    class ElConstructorQueUsaSpring {

        /**
         * Esta prueba existe por un arranque roto, no por gusto. Al escribirle pruebas a esta
         * clase se le añadió un segundo constructor —el que deja inyectar el planificador— y
         * con dos candidatos sin anotar Spring deja de elegir: se va al constructor vacío, no
         * lo encuentra y la aplicación no levanta. El error que se lee es «No default
         * constructor found», que no menciona ni el planificador ni las pruebas, así que
         * cuesta relacionarlo con su causa.
         */
        @Test
        @DisplayName("hay exactamente uno anotado: con dos candidatos sin anotar, Spring no arranca")
        void hayExactamenteUnoAnotado() {
            var constructores = AdaptadorPublicadorEventos.class.getDeclaredConstructors();
            var anotados = java.util.Arrays.stream(constructores)
                    .filter(c -> c.isAnnotationPresent(
                            org.springframework.beans.factory.annotation.Autowired.class))
                    .toList();

            assertThat(constructores).hasSizeGreaterThan(1);
            assertThat(anotados)
                    .as("con varios constructores, exactamente uno lleva @Autowired")
                    .hasSize(1);
            assertThat(anotados.get(0).getParameterTypes())
                    .as("el que Spring debe usar es el de un solo argumento")
                    .containsExactly(StreamBridge.class);
        }
    }

}
