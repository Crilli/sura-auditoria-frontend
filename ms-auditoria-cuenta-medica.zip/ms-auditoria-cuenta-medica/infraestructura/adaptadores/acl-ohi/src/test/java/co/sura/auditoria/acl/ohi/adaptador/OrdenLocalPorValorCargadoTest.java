package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import co.sura.auditoria.modelo.cuenta.OrdenLineas;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * El orden por valor cargado, que es el único que el servicio resuelve en casa.
 *
 * <p>Hasta el 2026-10-21 el valor cargado nunca llegaba nulo —un importe ausente se leía como
 * cero—, así que nadie vio que el orden descendente invertía también el «nulos al final» y los
 * subía al principio. Desde ese día un importe que OHI no trae viaja nulo, y esta prueba fija que
 * la línea sin importe va al final en los dos sentidos.
 */
@DisplayName("Orden local por valor cargado")
class OrdenLocalPorValorCargadoTest {

    private static ResumenLinea linea(int numero, String cargado) {
        return new ResumenLinea(new ReferenciaLinea(numero), numero, LocalDate.of(2026, 1, 1),
                LocalDate.of(2026, 1, 1), "CC1", null, "890201", null, "CUPS", null,
                null, null, null, false, false, false, false, 0, List.of(), false, List.of(),
                new Version(1L), cargado == null ? null : new BigDecimal(cargado),
                null, null, null, null, null);
    }

    private static List<Integer> ordenar(OrdenLineas.Sentido sentido) {
        return Stream.of(linea(1, "900"), linea(2, null), linea(3, "1000"), linea(4, "800"))
                .sorted(AdaptadorConsultasOhi.comparadorDe(
                        new OrdenLineas(OrdenLineas.Campo.VALOR_CARGADO, sentido)))
                .map(ResumenLinea::numeroLinea)
                .toList();
    }

    @Test
    @DisplayName("ascendente: de menor a mayor, y la línea sin valor cargado al final")
    void ascendente() {
        assertThat(ordenar(OrdenLineas.Sentido.ASCENDENTE)).containsExactly(4, 1, 3, 2);
    }

    @Test
    @DisplayName("descendente: de mayor a menor, y la línea sin valor cargado sigue al final")
    void descendente() {
        assertThat(ordenar(OrdenLineas.Sentido.DESCENDENTE)).containsExactly(3, 1, 4, 2);
    }

    @Test
    @DisplayName("un orden que resuelve el sistema de registro no tiene comparador aquí")
    void otroCampoEsUnErrorDeProgramacion() {
        assertThatThrownBy(() -> AdaptadorConsultasOhi.comparadorDe(
                new OrdenLineas(OrdenLineas.Campo.NUMERO_LINEA, OrdenLineas.Sentido.ASCENDENTE)))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("NUMERO_LINEA");
    }
}
