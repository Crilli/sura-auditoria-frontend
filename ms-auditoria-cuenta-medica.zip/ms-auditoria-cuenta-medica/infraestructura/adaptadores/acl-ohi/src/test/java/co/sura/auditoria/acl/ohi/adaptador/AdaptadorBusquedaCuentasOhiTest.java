package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.CuerpoEnviado;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroCuentas;
import co.sura.auditoria.modelo.cuenta.VersionCuenta;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * El buscador contra el sistema de registro.
 *
 * <p>Lo que se fija aquí son las dos condiciones que no pide nadie y sin las cuales el
 * resultado miente sin dar error: el tipo de proceso {@code C} en la búsqueda —sin él, el 85 %
 * de la lista serían reservas— y {@code reversal = false} en el histórico —sin él, cada
 * versión sale dos veces—.
 *
 * <p>Los códigos y facturas son de prueba; ningún dato identifica a una persona.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AdaptadorBusquedaCuentasOhi")
class AdaptadorBusquedaCuentasOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-57944424433");

    @Mock ExchangeFunction intercambio;
    @Mock ConfiguracionResiliencia resiliencia;
    @Mock AdaptadorPrestadoresOhi prestadores;
    @Captor ArgumentCaptor<ClientRequest> peticion;

    private AdaptadorBusquedaCuentasOhi adaptador;

    @BeforeEach
    void montar() {
        var webClient = WebClient.builder()
                .baseUrl("https://ohi.example/api")
                .exchangeFunction(intercambio)
                .build();
        org.mockito.Mockito.lenient()
                .when(resiliencia.<Object>paraConsultaPacienteMono()).thenReturn(Function.identity());
        adaptador = new AdaptadorBusquedaCuentasOhi(webClient, resiliencia,
                                                    new TraductorErrores(new ObjectMapper()),
                                                    prestadores);
    }

    private void ohiResponde(String cuerpo) {
        when(intercambio.exchange(any())).thenReturn(Mono.just(ClientResponse.create(HttpStatus.OK)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .body(cuerpo).build()));
    }

    private String enviado() {
        verify(intercambio).exchange(peticion.capture());
        return CuerpoEnviado.de(peticion.getValue());
    }

    private static String cuenta(String codigo, String estado, String nit) {
        return """
            {"code": "%s", "status": "%s", "numeroFactura": "JONATHAN201",
             "receiptDate": "2026-10-01", "valorFactura": 8800000,
             "claimantProvider": {"code": "%s"}}
            """.formatted(codigo, estado, nit);
    }

    // ── Búsqueda ─────────────────────────────────────────────────────────────

    @Test
    @Tag("BUS-12")
    @DisplayName("el tipo de proceso C viaja siempre, aunque el auditor no lo pida")
    void siempreFiltraCuentasMedicas() {
        ohiResponde("{\"items\": [], \"totalResults\": 0}");
        when(prestadores.nombresPorCodigo(any())).thenReturn(Mono.just(Map.of()));

        StepVerifier.create(adaptador.buscar(new FiltroCuentas("JONATHAN201", null), 0, 25))
                .assertNext(p -> assertThat(p.elementos()).isEmpty())
                .verifyComplete();

        var cuerpo = enviado();
        assertThat(cuerpo).contains("processType.eq('C')");
        assertThat(cuerpo).contains("numeroFactura.eq('JONATHAN201')");
        assertThat(cuerpo).contains("receiptDate desc");
    }

    @Test
    @Tag("BUS-05")
    @DisplayName("el radicado se busca por prefijo")
    void radicadoPorPrefijo() {
        ohiResponde("{\"items\": []}");
        when(prestadores.nombresPorCodigo(any())).thenReturn(Mono.just(Map.of()));

        adaptador.buscar(new FiltroCuentas(null, "CM-9442"), 0, 25).block();

        var cuerpo = enviado();
        assertThat(cuerpo).contains("processType.eq('C')");
        // Sin distinguir mayúsculas: quien teclea «cm-9442» busca lo mismo.
        assertThat(cuerpo).contains("code.likeic('CM-9442%')");
        // La factura se proyecta, pero no filtra si no se pidió.
        assertThat(cuerpo).doesNotContain("numeroFactura.eq");
    }

    @Test
    @Tag("BUS-17")
    @DisplayName("cada fila sale con la razón social, pedida una sola vez para toda la página")
    void conRazonSocial() {
        ohiResponde("{\"items\": [" + cuenta("CM-1", "MANUAL ADJUDICATION", "800000000") + ","
                    + cuenta("CM-2", "FINALIZED", "800000000") + ","
                    + cuenta("CM-3", "ESTADO NUEVO", "900000000") + "], \"totalResults\": 3}");
        when(prestadores.nombresPorCodigo(any())).thenReturn(Mono.just(
                Map.of("800000000", "Prestador uno", "900000000", "Prestador dos")));

        StepVerifier.create(adaptador.buscar(new FiltroCuentas("JONATHAN201", null), 0, 25))
                .assertNext(p -> {
                    assertThat(p.elementos()).hasSize(3);
                    var primera = p.elementos().get(0);
                    assertThat(primera.prestadorNit()).isEqualTo("800000000");
                    assertThat(primera.prestadorNombre()).isEqualTo("Prestador uno");
                    assertThat(primera.valorFactura()).isEqualByComparingTo("8800000");
                    assertThat(primera.estado()).isEqualTo(EstadoCuenta.ADJUDICACION_MANUAL);
                    // BUS-19: lo que el diccionario no traduce se enseña con su literal.
                    assertThat(p.elementos().get(2).estadoLegible()).isEqualTo("ESTADO NUEVO");
                    assertThat(p.total()).contains(3L);
                    assertThat(p.hayMas()).isFalse();
                })
                .verifyComplete();

        // Dos NIT distintos, una sola consulta al padrón con los dos.
        verify(prestadores).nombresPorCodigo(List.of("800000000", "900000000"));
    }

    @Test
    @Tag("BUS-17")
    @DisplayName("si el padrón no responde, la lista sale igual, con el NIT y sin nombre")
    void sinPadron() {
        ohiResponde("{\"items\": [" + cuenta("CM-1", "FINALIZED", "800000000") + "]}");
        when(prestadores.nombresPorCodigo(any())).thenReturn(Mono.empty());

        StepVerifier.create(adaptador.buscar(new FiltroCuentas("JONATHAN201", null), 0, 1))
                .assertNext(p -> {
                    assertThat(p.elementos()).singleElement().satisfies(r -> {
                        assertThat(r.prestadorNit()).isEqualTo("800000000");
                        assertThat(r.prestadorNombre()).isNull();
                    });
                    // Sin total ni hasMore, una página llena se toma como «puede haber más».
                    assertThat(p.hayMas()).isTrue();
                })
                .verifyComplete();
    }

    @Test
    @Tag("BUS-01")
    @DisplayName("hasMore del sistema de registro manda sobre el cálculo")
    void hasMoreManda() {
        ohiResponde("{\"items\": [" + cuenta("CM-1", "FINALIZED", "800000000")
                    + "], \"hasMore\": true, \"totalResults\": 1}");
        when(prestadores.nombresPorCodigo(any())).thenReturn(Mono.just(Map.of()));

        StepVerifier.create(adaptador.buscar(new FiltroCuentas("JONATHAN201", null), 0, 25))
                .assertNext(p -> assertThat(p.hayMas()).isTrue())
                .verifyComplete();
    }

    @Test
    @Tag("BUS-01")
    @DisplayName("con total y sin hasMore, hay más si no se ha llegado al total")
    void hayMasPorTotal() {
        ohiResponde("{\"items\": [" + cuenta("CM-1", "FINALIZED", "800000000")
                    + "], \"totalResults\": 30}");
        when(prestadores.nombresPorCodigo(any())).thenReturn(Mono.just(Map.of()));

        StepVerifier.create(adaptador.buscar(new FiltroCuentas("JONATHAN201", null), 25, 25))
                .assertNext(p -> assertThat(p.hayMas()).isTrue())
                .verifyComplete();
    }

    // ── Versiones ───────────────────────────────────────────────────────────

    private static String version(String codigo, int numero, String valor, String estados) {
        return """
            {"code": "%s", "version": %d, "reversal": false, "entryDate": "2026-09-0%d",
             "valorFactura": %s, "ctrStatusHistoryList": [%s]}
            """.formatted(codigo, numero, numero, valor, estados);
    }

    private static String estado(String nombre, String fecha) {
        return "{\"status\": \"%s\", \"statusDateTime\": {\"value\": \"%s\"}}".formatted(nombre, fecha);
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("pide el histórico por códigos y sin las gemelas de reversión")
    void sinGemelas() {
        ohiResponde("{\"items\": [" + version("CM-57944424433", 1, "4000001", "") + "]}");

        adaptador.versionesDe(List.of(CODIGO, CODIGO)).block();

        var cuerpo = enviado();
        assertThat(cuerpo).contains("reversal.eq(false)");
        assertThat(cuerpo).contains("CM-57944424433");
        assertThat(peticion.getValue().url().getPath()).endsWith("/generic/ctrclaims/search");
    }

    @Test
    @Tag("BUS-13")
    @Tag("BUS-19")
    @DisplayName("el estado de cada versión es el de la fecha más reciente, no el primero de la lista")
    void estadoMasReciente() {
        // Llegan desordenados: el primero de la lista es el más antiguo… o no.
        ohiResponde("{\"items\": [" + version("CM-57944424433", 3, "8800000",
                estado("Finalizado", "2026-09-09T10:00:00-05:00") + ","
                + estado("Pendiente", "2026-09-03T10:00:00-05:00") + ","
                + "{\"status\": \"SinFecha\"}") + "]}");

        StepVerifier.create(adaptador.versionesDe(List.of(CODIGO)))
                .assertNext(versiones -> assertThat(versiones).singleElement().satisfies(v -> {
                    assertThat(v.numero()).isEqualTo(3);
                    assertThat(v.valor()).isEqualByComparingTo(new BigDecimal("8800000"));
                    // Traducido al nombre del dominio, el mismo que lleva la cuenta (BUS-19).
                    assertThat(v.estado()).isEqualTo("FINALIZADA");
                    assertThat(v.estadoDesde()).isNotNull();
                }))
                .verifyComplete();
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("una versión sin historia de estados sale sin estado, no revienta")
    void versionSinEstados() {
        ohiResponde("{\"items\": [{\"code\": \"CM-57944424433\", \"version\": null}]}");

        StepVerifier.create(adaptador.versionesDe(List.of(CODIGO)))
                .assertNext(versiones -> assertThat(versiones).singleElement().satisfies(v -> {
                    assertThat(v.numero()).isZero();
                    assertThat(v.estado()).isNull();
                    assertThat(v.estadoDesde()).isNull();
                }))
                .verifyComplete();
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("una cuenta sin transmitir: cero versiones, no un error")
    void sinTransmitir() {
        ohiResponde("{\"items\": []}");

        StepVerifier.create(adaptador.versionesDe(List.of(CODIGO)))
                .assertNext(v -> assertThat(v).isEmpty())
                .verifyComplete();
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("sin códigos no se pregunta")
    void sinCodigos() {
        StepVerifier.create(adaptador.versionesDe(List.of()))
                .assertNext(v -> assertThat(v).isEmpty()).verifyComplete();
        verifyNoInteractions(intercambio);
    }

    private static ClientResponse respuesta(String cuerpo) {
        return ClientResponse.create(HttpStatus.OK)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .body(cuerpo).build();
    }

    /** Un lote de filas de histórico con ids consecutivos desde {@code desde}. */
    private static String lote(long desde, int cuantas) {
        var filas = new StringBuilder();
        for (int i = 0; i < cuantas; i++) {
            if (i > 0) filas.append(',');
            filas.append("{\"id\": ").append(desde + i)
                 .append(", \"code\": \"CM-57944424433\", \"version\": 1}");
        }
        return "{\"items\": [" + filas + "]}";
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("un lote lleno no es el final: sigue por keyset hasta una vuelta incompleta")
    void sigueTrasUnLoteLleno() {
        // El sistema de registro corta en 200 sin decir que hay más. Quedarse ahí dejaría a las
        // últimas cuentas de la página con versiones de menos, y nada lo avisaría.
        when(intercambio.exchange(any())).thenReturn(
                Mono.just(respuesta(lote(1, 200))), Mono.just(respuesta(lote(201, 5))));

        StepVerifier.create(adaptador.versionesDe(List.of(CODIGO)))
                .assertNext(v -> assertThat(v).hasSize(205))
                .verifyComplete();

        verify(intercambio, org.mockito.Mockito.times(2)).exchange(peticion.capture());
        var cuerpos = peticion.getAllValues().stream().map(CuerpoEnviado::de).toList();
        assertThat(cuerpos.get(0)).doesNotContain("id.gt").contains("id asc");
        // El avance va por id y el orden también, o se pierden filas debajo del corte.
        assertThat(cuerpos.get(1)).contains("id.gt(200)").contains("id asc")
                                  .contains("reversal.eq(false)");
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("si el cursor no avanza, corta en vez de dar vueltas sobre el mismo lote")
    void cursorQueNoAvanza() {
        // Doscientas filas sin id: no hay por dónde seguir.
        var filas = new StringBuilder();
        for (int i = 1; i <= 200; i++) {
            if (i > 1) filas.append(',');
            filas.append("{\"code\": \"CM-").append(i).append("\", \"version\": 1}");
        }
        ohiResponde("{\"items\": [" + filas + "]}");

        StepVerifier.create(adaptador.versionesDe(List.of(CODIGO)))
                .assertNext(v -> assertThat(v).hasSize(200))
                .verifyComplete();
        verify(intercambio, org.mockito.Mockito.times(1)).exchange(any());
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("el recorrido tiene freno: tras diez vueltas entrega lo leído")
    void frenoDelRecorrido() {
        var vuelta = new java.util.concurrent.atomic.AtomicLong();
        when(intercambio.exchange(any())).thenAnswer(i ->
                Mono.just(respuesta(lote(vuelta.getAndIncrement() * 200 + 1, 200))));

        StepVerifier.create(adaptador.versionesDe(List.of(CODIGO)))
                .assertNext(v -> assertThat(v).hasSize(2000))
                .verifyComplete();
        verify(intercambio, org.mockito.Mockito.times(10)).exchange(any());
    }

    // ── Foto de una versión ─────────────────────────────────────────────────

    @Test
    @Tag("BUS-20")
    @Tag("BUS-19")
    @DisplayName("la foto pide esa versión exacta, sin su gemela, y ordena su historia")
    void foto() {
        ohiResponde("""
            {"items": [{"code": "CM-57944424433", "version": 2, "entryDate": "2026-09-02",
              "numeroFactura": "JONATHAN201", "claimantName": "Prestador de prueba",
              "valorFactura": 6000000, "totalClaimedAmount": 6000000,
              "totalAllowedAmount": 5000000, "totalCoveredAmount": 5000000,
              "totalValorGlosado": 1000000, "totalValorNotasCredito": 0,
              "ctrStatusHistoryList": [%s, %s, {"status": "SinFecha"}]}]}
            """.formatted(estado("Finalizado", "2026-09-05T10:00:00-05:00"),
                          estado("Pendiente", "2026-09-02T10:00:00-05:00")));

        StepVerifier.create(adaptador.fotoDeVersion(CODIGO, 2))
                .assertNext(f -> {
                    assertThat(f.numero()).isEqualTo(2);
                    assertThat(f.valorFactura()).isEqualByComparingTo("6000000");
                    assertThat(f.totalGlosado()).isEqualByComparingTo("1000000");
                    assertThat(f.historial()).extracting(e -> e.estado())
                            .containsExactly("ADJUDICACION_MANUAL", "FINALIZADA");
                    assertThat(f.estadoActual()).isEqualTo("FINALIZADA");
                })
                .verifyComplete();

        var cuerpo = enviado();
        assertThat(cuerpo).contains("code.eq('CM-57944424433')");
        assertThat(cuerpo).contains("version.eq(2)");
        assertThat(cuerpo).contains("reversal.eq(false)");
    }

    @Test
    @Tag("BUS-20")
    @Tag("BUS-19")
    @DisplayName("la foto de una versión trae solo su vuelta, aunque el histórico sea acumulativo")
    void fotoSoloSuVuelta() {
        // Como lo publica OHI: la V3 lleva toda la historia de la cuenta, con tres «Finalizado»,
        // y desordenada. Lo de la V3 es lo que viene después del cierre de la V2.
        ohiResponde("""
            {"items": [{"code": "CM-57944424433", "version": 3,
              "ctrStatusHistoryList": [%s, %s, %s, %s, %s, %s, %s, %s]}]}
            """.formatted(
                estado("Finalizado", "2026-09-09T12:00:00-05:00"),       // cierre de la V3
                estado("Inicial", "2026-09-01T10:00:00-05:00"),          // V1
                estado("Cambiar", "2026-09-04T09:00:00-05:00"),          // V2
                estado("Finalizado", "2026-09-02T10:00:00-05:00"),       // cierre de la V1
                estado("Pendiente", "2026-09-08T10:00:00-05:00"),        // V3
                estado("Finalizado", "2026-09-05T08:00:00-05:00"),       // cierre de la V2
                estado("Cambiar", "2026-09-07T09:00:00-05:00"),          // V3
                estado("Aprobación Hecha", "2026-09-09T11:00:00-05:00")));

        StepVerifier.create(adaptador.fotoDeVersion(CODIGO, 3))
                .assertNext(f -> {
                    assertThat(f.historial()).extracting(e -> e.estado()).containsExactly(
                            "MODIFICACION", "ADJUDICACION_MANUAL", "ADJUDICACION_COMPLETA", "FINALIZADA");
                    assertThat(f.estadoActual()).isEqualTo("FINALIZADA");
                })
                .verifyComplete();
    }

    @Test
    @Tag("BUS-20")
    @DisplayName("una foto sin historia ni número no revienta")
    void fotoMinima() {
        ohiResponde("{\"items\": [{\"code\": \"CM-57944424433\"}]}");

        StepVerifier.create(adaptador.fotoDeVersion(CODIGO, 2))
                .assertNext(f -> {
                    assertThat(f.numero()).isZero();
                    assertThat(f.historial()).isEmpty();
                })
                .verifyComplete();
    }

    @Test
    @Tag("BUS-20")
    @DisplayName("una versión que no existe llega vacía, para que el caso de uso la nombre")
    void fotoQueNoExiste() {
        ohiResponde("{\"items\": []}");

        StepVerifier.create(adaptador.fotoDeVersion(CODIGO, 7)).verifyComplete();
        verify(prestadores, never()).nombresPorCodigo(any());
    }
}
