package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * Las cachés de los tres catálogos (OPE-04).
 *
 * <p>Lo que se fija es lo que {@code Mono.cache(Duration)} hacía mal: guardar también el error
 * y la lista vacía durante toda la vigencia. Un fallo pasajero de la primera carga dejaba
 * media hora sin catálogo —y sin altas de novedad, acciones con motivo ni altas de
 * pendiente— en esa réplica.
 */
@DisplayName("Cachés de catálogo")
class CachesDeCatalogoTest {

    private static final String CON_UNO = """
            {"items": [{"id": 1, "code": "UNO", "message": "Texto", "descr": "Texto",
                        "severity": "F", "system": false}]}
            """;
    private static final String VACIO = "{\"items\": []}";

    /** Un adaptador de catálogo, armado sobre un intercambio simulado. */
    record Catalogo(String nombre, Function<WebClient, Supplier<Mono<? extends List<?>>>> armar) {
        @Override public String toString() { return nombre; }
    }

    static Stream<Arguments> catalogos() {
        var resiliencia = mock(ConfiguracionResiliencia.class);
        when(resiliencia.<Object>paraConsultasMono()).thenReturn(Function.identity());
        var traductor = new TraductorErrores(new ObjectMapper());
        return Stream.of(
                Arguments.of(new Catalogo("novedades", web -> {
                    var a = new AdaptadorCatalogoNovedadesOhi(web, resiliencia, traductor);
                    return a::listar;
                })),
                Arguments.of(new Catalogo("motivos de desfinalización", web -> {
                    var a = new AdaptadorCatalogoMotivosOhi(web, resiliencia, traductor);
                    return a::listar;
                })),
                Arguments.of(new Catalogo("motivos de pendiente", web -> {
                    var a = new AdaptadorCatalogoMotivosPendienteOhi(web, resiliencia, traductor);
                    return a::listar;
                })));
    }

    private static Mono<ClientResponse> responde(HttpStatus estado, String cuerpo) {
        return Mono.just(ClientResponse.create(estado)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .body(cuerpo).build());
    }

    private static WebClient sobre(ExchangeFunction intercambio) {
        return WebClient.builder().baseUrl("https://ohi.example/api")
                .exchangeFunction(intercambio).build();
    }

    @ParameterizedTest(name = "{0}: un fallo de la primera carga no se queda guardado")
    @MethodSource("catalogos")
    @Tag("OPE-04")
    void elErrorNoSeGuarda(Catalogo catalogo) {
        var intercambio = mock(ExchangeFunction.class);
        when(intercambio.exchange(any())).thenReturn(
                responde(HttpStatus.SERVICE_UNAVAILABLE, "{}"), responde(HttpStatus.OK, CON_UNO));
        var listar = catalogo.armar().apply(sobre(intercambio));

        StepVerifier.create(listar.get()).expectError().verify();
        StepVerifier.create(listar.get())
                .assertNext(lista -> assertThat(lista).hasSize(1))
                .verifyComplete();

        verify(intercambio, times(2)).exchange(any());
    }

    @ParameterizedTest(name = "{0}: una lista vacía tampoco se guarda")
    @MethodSource("catalogos")
    @Tag("OPE-04")
    void elVacioNoSeGuarda(Catalogo catalogo) {
        var intercambio = mock(ExchangeFunction.class);
        when(intercambio.exchange(any())).thenReturn(
                responde(HttpStatus.OK, VACIO), responde(HttpStatus.OK, CON_UNO));
        var listar = catalogo.armar().apply(sobre(intercambio));

        StepVerifier.create(listar.get()).assertNext(l -> assertThat(l).isEmpty()).verifyComplete();
        StepVerifier.create(listar.get()).assertNext(l -> assertThat(l).hasSize(1)).verifyComplete();

        verify(intercambio, times(2)).exchange(any());
    }

    @ParameterizedTest(name = "{0}: cargado bien, se sirve de la caché y las peticiones a la vez comparten la carga")
    @MethodSource("catalogos")
    @Tag("OPE-04")
    void loBuenoSeGuardaYSeComparte(Catalogo catalogo) {
        var intercambio = mock(ExchangeFunction.class);
        when(intercambio.exchange(any())).thenReturn(responde(HttpStatus.OK, CON_UNO));
        var listar = catalogo.armar().apply(sobre(intercambio));

        // Dos a la vez y una después: una sola consulta al sistema de registro.
        StepVerifier.create(Mono.zip(listar.get(), listar.get()))
                .assertNext(par -> assertThat(par.getT1()).isEqualTo(par.getT2()))
                .verifyComplete();
        StepVerifier.create(listar.get()).assertNext(l -> assertThat(l).hasSize(1)).verifyComplete();

        verify(intercambio, times(1)).exchange(any());
    }
}
