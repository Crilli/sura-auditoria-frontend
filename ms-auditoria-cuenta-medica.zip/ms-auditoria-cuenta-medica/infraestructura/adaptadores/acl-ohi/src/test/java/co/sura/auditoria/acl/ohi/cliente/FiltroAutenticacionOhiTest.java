package co.sura.auditoria.acl.ohi.cliente;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * El caso del token caducado, que el estándar de pruebas del ecosistema declara obligatorio
 * para todo lo que hable con OHI y que no estaba cubierto.
 *
 * <p>No es un caso teórico: el 2026-10-17 un servicio levantado a las 07:31 empezó a devolver
 * 401 a los 68 minutos y no se recuperó hasta que lo reiniciaron, mientras las mismas
 * credenciales obtenían un token sin problema desde fuera. Lo que faltaba no era afinar la
 * caducidad de la caché sino hacerle caso al 401.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("FiltroAutenticacionOhi")
class FiltroAutenticacionOhiTest {

    @Mock ProveedorTokenOhi proveedor;
    @Mock ExchangeFunction intercambio;

    private static ClientResponse respuesta(HttpStatus estado, String cuerpo) {
        return ClientResponse.create(estado)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .body(cuerpo)
                .build();
    }

    /** Un cliente con el filtro puesto, igual que lo monta la configuración real. */
    private WebClient clienteCon() {
        return WebClient.builder()
                .baseUrl("https://ohi.example/api")
                .filter(new FiltroAutenticacionOhi(proveedor))
                .exchangeFunction(intercambio)
                .build();
    }

    private Mono<String> pedirAlgo() {
        return clienteCon().get().uri("/generic/claims/search").retrieve().bodyToMono(String.class);
    }

    @Test
    @DisplayName("el camino normal: un token, una llamada, y el token viaja como Bearer")
    void elCaminoNormal() {
        when(proveedor.obtenerToken()).thenReturn(Mono.just("token-bueno"));
        when(intercambio.exchange(any())).thenReturn(Mono.just(respuesta(HttpStatus.OK, "{}")));

        StepVerifier.create(pedirAlgo()).expectNext("{}").verifyComplete();

        var captor = ArgumentCaptor.forClass(ClientRequest.class);
        verify(intercambio).exchange(captor.capture());
        assertThat(captor.getValue().headers().getFirst(HttpHeaders.AUTHORIZATION))
                .isEqualTo("Bearer token-bueno");
        verify(proveedor, never()).olvidarToken();
    }

    @Test
    @DisplayName("ante un 401 descarta el token, pide otro y reintenta: la llamada acaba bien")
    void anteUn401RenuevaYReintenta() {
        // Primero el token viejo, que OHI rechaza; después el nuevo, que acepta.
        when(proveedor.obtenerToken())
                .thenReturn(Mono.just("token-viejo"))
                .thenReturn(Mono.just("token-nuevo"));
        when(intercambio.exchange(any()))
                .thenReturn(Mono.just(respuesta(HttpStatus.UNAUTHORIZED, "401 Authorization Required")))
                .thenReturn(Mono.just(respuesta(HttpStatus.OK, "{\"items\":[]}")));

        StepVerifier.create(pedirAlgo()).expectNext("{\"items\":[]}").verifyComplete();

        verify(proveedor).olvidarToken();

        var captor = ArgumentCaptor.forClass(ClientRequest.class);
        verify(intercambio, times(2)).exchange(captor.capture());
        var enviados = captor.getAllValues().stream()
                .map(p -> p.headers().getFirst(HttpHeaders.AUTHORIZATION))
                .toList();
        assertThat(enviados)
                .as("el segundo intento no puede repetir el token que acaban de rechazar")
                .containsExactly("Bearer token-viejo", "Bearer token-nuevo");
    }

    @Test
    @DisplayName("el orden importa: primero se olvida el token y después se pide el nuevo")
    void primeroOlvidaDespuesPide() {
        // Si se pidiera antes de olvidar, la caché devolvería el mismo token rechazado y el
        // reintento sería idéntico al intento fallido: parecería un arreglo y no lo sería.
        var traza = new ArrayList<String>();
        when(proveedor.obtenerToken()).thenAnswer(i -> {
            traza.add("pedir");
            return Mono.just("token-" + traza.size());
        });
        org.mockito.Mockito.doAnswer(i -> {
            traza.add("olvidar");
            return null;
        }).when(proveedor).olvidarToken();
        when(intercambio.exchange(any()))
                .thenReturn(Mono.just(respuesta(HttpStatus.UNAUTHORIZED, "no")))
                .thenReturn(Mono.just(respuesta(HttpStatus.OK, "{}")));

        StepVerifier.create(pedirAlgo()).expectNext("{}").verifyComplete();

        assertThat(traza).containsExactly("pedir", "olvidar", "pedir");
    }

    @Test
    @DisplayName("si el segundo intento también es 401, se devuelve y no se insiste")
    void siElSegundoTambienEs401NoSeInsiste() {
        // Un 401 con token recién pedido no es un token caducado: son credenciales,
        // permisos o el gateway. Reintentar otra vez solo multiplica las llamadas.
        when(proveedor.obtenerToken()).thenReturn(Mono.just("da-igual"));
        when(intercambio.exchange(any()))
                .thenReturn(Mono.just(respuesta(HttpStatus.UNAUTHORIZED, "no")))
                .thenReturn(Mono.just(respuesta(HttpStatus.UNAUTHORIZED, "tampoco")));

        StepVerifier.create(clienteCon().get().uri("/x").exchangeToMono(
                        r -> Mono.just(r.statusCode().value())))
                .expectNext(401)
                .verifyComplete();

        verify(intercambio, times(2)).exchange(any());
        verify(proveedor, times(1)).olvidarToken();
    }

    @Test
    @DisplayName("un error que no es 401 se devuelve tal cual, sin tocar el token")
    void unErrorQueNoEs401NoTocaElToken() {
        when(proveedor.obtenerToken()).thenReturn(Mono.just("token-bueno"));
        when(intercambio.exchange(any()))
                .thenReturn(Mono.just(respuesta(HttpStatus.INTERNAL_SERVER_ERROR, "{}")));

        StepVerifier.create(clienteCon().get().uri("/x").exchangeToMono(
                        r -> Mono.just(r.statusCode().value())))
                .expectNext(500)
                .verifyComplete();

        verify(proveedor, never()).olvidarToken();
        verify(intercambio, times(1)).exchange(any());
    }

    @Test
    @DisplayName("un 204 no se confunde con un rechazo: pasa sin reintento")
    void un204PasaSinReintento() {
        // OHI usa el 204 para «ninguna coincidencia», que es la respuesta más común de todas.
        when(proveedor.obtenerToken()).thenReturn(Mono.just("token-bueno"));
        when(intercambio.exchange(any()))
                .thenReturn(Mono.just(ClientResponse.create(HttpStatus.NO_CONTENT).build()));

        StepVerifier.create(clienteCon().get().uri("/x").exchangeToMono(
                        r -> Mono.just(r.statusCode().value())))
                .expectNext(204)
                .verifyComplete();

        verify(proveedor, never()).olvidarToken();
        verify(intercambio, times(1)).exchange(any());
    }

    @Test
    @DisplayName("el reintento conserva el método, la ruta y las cabeceras de la petición")
    void elReintentoConservaLaPeticion() {
        when(proveedor.obtenerToken())
                .thenReturn(Mono.just("viejo")).thenReturn(Mono.just("nuevo"));
        when(intercambio.exchange(any()))
                .thenReturn(Mono.just(respuesta(HttpStatus.UNAUTHORIZED, "no")))
                .thenReturn(Mono.just(respuesta(HttpStatus.OK, "{}")));

        StepVerifier.create(clienteCon().post()
                        .uri("/generic/claims/search")
                        .header("X-Ohi-App-Id", "CLA")
                        .bodyValue("{\"resource\":{}}")
                        .retrieve().bodyToMono(String.class))
                .expectNext("{}").verifyComplete();

        var captor = ArgumentCaptor.forClass(ClientRequest.class);
        verify(intercambio, times(2)).exchange(captor.capture());
        List<ClientRequest> peticiones = captor.getAllValues();
        assertThat(peticiones.get(1).method()).isEqualTo(peticiones.get(0).method());
        assertThat(peticiones.get(1).url()).isEqualTo(peticiones.get(0).url());
        assertThat(peticiones.get(1).headers().getFirst("X-Ohi-App-Id")).isEqualTo("CLA");
    }
}
