package co.sura.auditoria.acl.ohi.cliente;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * El tope de conexiones de cada pool (OPE-10).
 *
 * <p>Resuelve las expresiones tal como están escritas en las anotaciones de los dos clientes, para que
 * un cambio en una de ellas —el nombre de la propiedad o su valor por omisión— se note aquí.
 */
@DisplayName("ConfiguracionClienteOhi — topes de conexión")
class TopesDeConexionOhiTest {

    private static String expresionDelTope(String bean) {
        Method metodo = Arrays.stream(ConfiguracionClienteOhi.class.getMethods())
                .filter(m -> m.getName().equals(bean) && m.getReturnType() == WebClient.class)
                .findFirst().orElseThrow();
        return Arrays.stream(metodo.getParameters())
                .filter(p -> p.getType() == int.class)
                .map(p -> p.getAnnotation(Value.class).value())
                .findFirst().orElseThrow();
    }

    private static int resolver(String bean, Map<String, Object> propiedades) {
        var entorno = new StandardEnvironment();
        entorno.getPropertySources().addFirst(new MapPropertySource("prueba", propiedades));
        return Integer.parseInt(entorno.resolveRequiredPlaceholders(expresionDelTope(bean)));
    }

    @Test
    @Tag("OPE-10")
    @DisplayName("cada pool toma su propio tope")
    void cadaPoolSuTope() {
        var reparto = Map.<String, Object>of(
                "integraciones.ohi.pool.maximo-conexiones-general", "15",
                "integraciones.ohi.pool.maximo-conexiones-operaciones-largas", "45",
                "integraciones.ohi.pool.maximo-conexiones", "30");

        assertThat(resolver("clienteOhi", reparto)).isEqualTo(15);
        assertThat(resolver("clienteOhiOperacionesLargas", reparto)).isEqualTo(45);
    }

    @Test
    @Tag("OPE-10")
    @DisplayName("sin topes propios, los dos siguen en el valor común de antes")
    void porOmisionElComun() {
        var comun = Map.<String, Object>of("integraciones.ohi.pool.maximo-conexiones", "25");

        assertThat(resolver("clienteOhi", comun)).isEqualTo(25);
        assertThat(resolver("clienteOhiOperacionesLargas", comun)).isEqualTo(25);
        assertThat(resolver("clienteOhi", Map.of())).isEqualTo(30);
        assertThat(resolver("clienteOhiOperacionesLargas", Map.of())).isEqualTo(30);
    }
}
