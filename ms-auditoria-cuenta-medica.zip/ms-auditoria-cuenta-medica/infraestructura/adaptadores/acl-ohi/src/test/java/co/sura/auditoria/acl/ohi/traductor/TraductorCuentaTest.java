package co.sura.auditoria.acl.ohi.traductor;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.externo.OhiClaimItem;
import co.sura.auditoria.acl.ohi.externo.OhiClaseServicio;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem.OhiMessageRef;
import co.sura.auditoria.acl.ohi.externo.OhiMonto;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("TraductorCuenta")
class TraductorCuentaTest {

    private final TraductorCuenta traductor =
            new TraductorCuenta(new TraductorPendiente(), new TraductorNovedad());

    /**
     * Cada importe con una cifra distinta —cargado 1000, convenido 900, autorizado 800, glosado
     * 100, factura 38222—. Con la misma cifra en todos, como estaba antes, un cruce entre dos
     * campos pasaba en verde; con cifras distintas cualquier cruce rompe una aserción.
     *
     * @param convenido  {@code totalAllowedAmount}
     * @param autorizado {@code totalCoveredAmount}
     * @param cargado    {@code totalClaimedAmount}
     */
    private static OhiClaimItem claim(OhiMonto convenido, OhiMonto autorizado,
                                      OhiMonto cargado, OhiClaseServicio clase,
                                      OhiFlexCode atep, OhiFlexCode multicore,
                                      OhiFlexCode pendienteManual) {
        return new OhiClaimItem(108800618430L, "CM-108800618430", "FINALIZED",
                LocalDate.of(2026, 8, 11), LocalDate.of(2026, 8, 11),
                convenido, autorizado, cargado,
                null, null, null,
                "FVE170775", LocalDate.of(2026, 8, 21), LocalDate.of(2026, 8, 11),
                LocalDate.of(2026, 9, 20), null, null,
                new BigDecimal("38222"), new BigDecimal("38222"),
                new BigDecimal("100"), BigDecimal.ZERO,
                clase, "000032580660", atep, multicore, pendienteManual,
                "internas", "externas", null, 3L, List.of());
    }

    private static OhiClaimItem completo() {
        return claim(new OhiMonto("COP", new BigDecimal("900")),
                new OhiMonto("COP", new BigDecimal("800")),
                new OhiMonto("COP", new BigDecimal("1000")),
                new OhiClaseServicio("1", "Ambulatorio", "AMBULATORIO"),
                new OhiFlexCode("N", "No"), new OhiFlexCode("N", "No"),
                new OhiFlexCode("S", "Sí"));
    }

    @Nested
    @DisplayName("cabecera")
    class Cabecera {

        @Test
        @DisplayName("traduce código, estado y versión")
        void traduceCodigoEstadoYVersion() {
            var cuenta = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null);

            assertThat(cuenta.codigo().valor()).isEqualTo("CM-108800618430");
            assertThat(cuenta.estado()).isEqualTo(EstadoCuenta.FINALIZADA);
            assertThat(cuenta.version().numero()).isEqualTo(3L);
            assertThat(cuenta.fechaInicio()).isEqualTo(LocalDate.of(2026, 8, 11));
        }

        @Test
        @Tag("ENC-12")
        @Tag("ENC-13")
        @DisplayName("[ENC-12][ENC-13] cada total sale de su campo: convenido = totalAllowedAmount, "
                + "autorizado = totalCoveredAmount, cargado = totalClaimedAmount")
        void cadaTotalSaleDeSuCampo() {
            // La tabla que fijó negocio el 2026-10-21. Hasta entonces el convenido se publicaba
            // como «autorizado» y el autorizado como «cubierto».
            var cuenta = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null);

            assertThat(cuenta.totalConvenido()).isEqualByComparingTo("900");
            assertThat(cuenta.totalAutorizado()).isEqualByComparingTo("800");
            assertThat(cuenta.informacionFacturacion().totalCargado()).isEqualByComparingTo("1000");
            assertThat(cuenta.informacionFacturacion().totalValorGlosado())
                    .isEqualByComparingTo("100");
        }

        @Test
        @Tag("ENC-12")
        @Tag("ENC-13")
        @DisplayName("[ENC-12][ENC-13] un total ausente viaja nulo, no cero")
        void unTotalAusenteViajaNulo() {
            // Antes se leía como cero y la pantalla pintaba «$0» donde OHI no dijo nada. Un
            // total que falta no es un total de cero: viaja nulo y la pantalla pinta una raya.
            var sinMontos = claim(null, null, null, null, null, null, null);

            var cuenta = traductor.aDominio(sinMontos, List.of(), List.of(), null, null, null, null);

            assertThat(cuenta.totalConvenido()).isNull();
            assertThat(cuenta.totalAutorizado()).isNull();
            assertThat(cuenta.informacionFacturacion().totalCargado()).isNull();
        }

        @Test
        @Tag("ENC-12")
        @DisplayName("[ENC-12] un monto con value nulo también viaja nulo")
        void unMontoConValorNuloViajaNulo() {
            var conValorNulo = claim(new OhiMonto("COP", null), new OhiMonto("COP", null),
                    new OhiMonto("COP", null), null, null, null, null);

            var cuenta = traductor.aDominio(conValorNulo, List.of(), List.of(), null, null, null, null);

            assertThat(cuenta.totalConvenido()).isNull();
            assertThat(cuenta.totalAutorizado()).isNull();
            assertThat(cuenta.informacionFacturacion().totalCargado()).isNull();
        }

        @Test
        @Tag("ENC-13")
        @DisplayName("[ENC-13] un total en cero se conserva como cero: solo la ausencia es nula")
        void unTotalEnCeroSeConservaComoCero() {
            // La madre de un large claim en proceso trae el convenido y el autorizado en 0: eso
            // sí es un dato, y no puede confundirse con «no vino».
            var enCero = claim(new OhiMonto("COP", BigDecimal.ZERO),
                    new OhiMonto("COP", BigDecimal.ZERO), null, null, null, null, null);

            var cuenta = traductor.aDominio(enCero, List.of(), List.of(), null, null, null, null);

            assertThat(cuenta.totalConvenido()).isEqualByComparingTo(BigDecimal.ZERO);
            assertThat(cuenta.totalAutorizado()).isEqualByComparingTo(BigDecimal.ZERO);
        }

        @Test
        @DisplayName("un estado que OHI no publica en el diccionario cae en DESCONOCIDO")
        void unEstadoDesconocidoDegrada() {
            var raro = new OhiClaimItem(1L, "CM-1", "ESTADO_NUEVO", null, null,
                    null, null, null, null, null, null, null, null, null, null, null,
                    null, null, null, null, null, null, null, null, null, null,
                    null, null, null, 1L, List.of());

            assertThat(traductor.aDominio(raro, List.of(), List.of(), null, null, null, null).estado())
                    .isEqualTo(EstadoCuenta.DESCONOCIDO);
        }
    }

    @Nested
    @DisplayName("información de facturación")
    class Facturacion {

        @Test
        @DisplayName("el número de radicado es el código de la cuenta, no un campo aparte")
        void elRadicadoEsElCodigoDeLaCuenta() {
            var f = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion();

            assertThat(f.numeroRadicado()).isEqualTo("CM-108800618430");
            assertThat(f.numeroFactura()).isEqualTo("FVE170775");
        }

        @Test
        @Tag("ENC-01")
        @Tag("ENC-23")
        @DisplayName("los NIT y las razones sociales entran por parámetro: OHI no los trae en la cabecera")
        void losNitEntranPorParametro() {
            var f = traductor.aDominio(completo(), List.of(), List.of(),
                    "9000114361", "CLINICA ABC",
                    "8110078325-001", "IPS QUE COBRA").informacionFacturacion();

            assertThat(f.prestadorFacturacionNit()).isEqualTo("9000114361");
            assertThat(f.prestadorFacturacionNombre()).isEqualTo("CLINICA ABC");
            assertThat(f.pagarAPrestadorNit()).isEqualTo("8110078325-001");
            assertThat(f.pagarAPrestadorNombre()).isEqualTo("IPS QUE COBRA");
        }

        @Test
        @Tag("ENC-01")
        @Tag("ENC-23")
        @DisplayName("un prestador que el padrón no conoce deja el nombre en nulo y conserva el NIT")
        void unPrestadorDesconocidoDejaElNombreEnNulo() {
            // El nombre sale de una consulta aparte al padrón: que falte no puede costar la
            // cabecera entera. El NIT viene de la cuenta y siempre está.
            var f = traductor.aDominio(completo(), List.of(), List.of(),
                    "9000114361", null, "9000114361", null).informacionFacturacion();

            assertThat(f.prestadorFacturacionNit()).isEqualTo("9000114361");
            assertThat(f.prestadorFacturacionNombre()).isNull();
            assertThat(f.pagarAPrestadorNombre()).isNull();
        }

        @Test
        @Tag("ENC-16")
        @DisplayName("la clase de servicio prefiere el tipo de servicio sobre el descriptor")
        void laClaseDeServicioPrefiereElTipo() {
            var f = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion();

            assertThat(f.tipoServicio()).isEqualTo("AMBULATORIO");
        }

        @Test
        @Tag("ENC-16")
        @DisplayName("sin tipo de servicio se queda con el descriptor")
        void sinTipoUsaElDescriptor() {
            var conDescriptor = claim(null, null, null,
                    new OhiClaseServicio("1", "Ambulatorio", null), null, null, null);

            assertThat(traductor.aDominio(conDescriptor, List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion().tipoServicio()).isEqualTo("Ambulatorio");
        }

        @Test
        @DisplayName("sin descriptor ni tipo se queda con el valor crudo")
        void sinDescriptorUsaElValor() {
            var soloValor = claim(null, null, null,
                    new OhiClaseServicio("1", null, null), null, null, null);

            assertThat(traductor.aDominio(soloValor, List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion().tipoServicio()).isEqualTo("1");
        }

        @Test
        @DisplayName("las marcas flexcode viajan como su texto legible")
        void lasMarcasViajanComoTexto() {
            var f = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion();

            assertThat(f.marcaRadicadoAtep()).isEqualTo("No");
            assertThat(f.marcaMulticore()).isEqualTo("No");
            assertThat(f.marcaPendienteManual()).isEqualTo("Sí");
        }

        @Test
        @DisplayName("el total cobrado sale del monto envuelto, no del valor suelto")
        void elTotalCargadoSaleDelMonto() {
            assertThat(traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion().totalCargado()).isEqualByComparingTo("1000");
        }

        @Test
        @DisplayName("las observaciones internas y externas se conservan por separado")
        void lasObservacionesSeConservan() {
            var f = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null)
                    .informacionFacturacion();

            assertThat(f.observacionesInternas()).isEqualTo("internas");
            assertThat(f.observacionesExternas()).isEqualTo("externas");
        }
    }

    @Nested
    @DisplayName("colecciones")
    class Colecciones {

        @Test
        @DisplayName("los pendientes se traducen como de cabecera")
        void losPendientesSeTraducenComoCabecera() {
            var pendiente = new OhiPendReasonItem(42L,
                    new OhiPendReasonItem.OhiPendReasonRef("7", "AUD01", "Auditoría", true),
                    false, null, 2L);

            var cuenta = traductor.aDominio(completo(), List.of(pendiente), List.of(), null, null, null, null);

            assertThat(cuenta.pendientesCabecera()).singleElement().satisfies(p -> {
                assertThat(p.codigo()).isEqualTo("AUD01");
                assertThat(p.nivel()).isEqualTo(
                        co.sura.auditoria.modelo.cuenta.NivelPendiente.CABECERA);
                assertThat(p.referenciaLinea()).isNull();
            });
            assertThat(cuenta.tienePendientesSinResolver()).isTrue();
        }

        @Test
        @DisplayName("las novedades se traducen con su texto resuelto")
        void lasNovedadesSeTraducen() {
            var novedad = new OhiMessageItem(9L,
                    new OhiMessageRef("ANULACION_010", "F", "Anulada por {0}"),
                    "MANUAL", null, null, "duplicidad",
                    null, null, null, null, null, null, null, null, null);

            var cuenta = traductor.aDominio(completo(), List.of(), List.of(novedad), null, null, null, null);

            assertThat(cuenta.novedades()).singleElement().satisfies(n -> {
                assertThat(n.codigo()).isEqualTo("ANULACION_010");
                assertThat(n.textoResuelto()).isEqualTo("Anulada por duplicidad");
            });
        }

        @Test
        @DisplayName("sin pendientes ni novedades, las listas quedan vacías")
        void sinColeccionesQuedanVacias() {
            var cuenta = traductor.aDominio(completo(), List.of(), List.of(), null, null, null, null);

            assertThat(cuenta.pendientesCabecera()).isEmpty();
            assertThat(cuenta.novedades()).isEmpty();
            assertThat(cuenta.tienePendientesSinResolver()).isFalse();
        }
    }
}
