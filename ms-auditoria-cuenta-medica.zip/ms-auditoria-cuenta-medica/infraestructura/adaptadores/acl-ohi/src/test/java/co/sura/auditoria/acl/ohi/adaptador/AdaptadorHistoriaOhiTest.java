package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.CuerpoEnviado;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.HitoCuenta;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * La historia de la cuenta, unida de los dos recursos que la guardan.
 *
 * <p>Lo que estas pruebas fijan es el detalle que no se adivina y que el sistema de registro
 * no castiga: <b>cada recurso fecha sus filas con un nombre distinto</b> —{@code dateTime} en
 * el historial de estados y {@code creationDate} en las desfinalizaciones—. Como la proyección
 * no se valida, pedir el nombre equivocado devuelve las filas <b>sin fecha</b>, y entonces la
 * historia sale ordenada por nada. No falla: miente.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AdaptadorHistoriaOhi")
class AdaptadorHistoriaOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-117897397334");

    @Mock ExchangeFunction intercambio;
    @Mock ConfiguracionResiliencia resiliencia;
    @Captor ArgumentCaptor<ClientRequest> peticionCaptor;

    private AdaptadorHistoriaOhi adaptador;
    private final List<String> respuestas = new ArrayList<>();

    @BeforeEach
    void montar() {
        var webClient = WebClient.builder()
                .baseUrl("https://ohi.example/api")
                .exchangeFunction(intercambio)
                .build();
        org.mockito.Mockito.lenient()
                .when(resiliencia.<Object>paraConsultasMono()).thenReturn(Function.identity());
        adaptador = new AdaptadorHistoriaOhi(webClient, resiliencia,
                                             new TraductorErrores(new ObjectMapper()));
    }

    /**
     * Responde por ruta y no por turno: las dos consultas salen a la vez y el orden en que
     * llegan no está garantizado, así que encadenar respuestas haría la prueba intermitente.
     */
    private void ohiResponde(String estados, String desfinalizaciones) {
        when(intercambio.exchange(any())).thenAnswer(invocacion -> {
            ClientRequest peticion = invocacion.getArgument(0);
            var cuerpo = peticion.url().getPath().contains("claimunfinalizereasons")
                    ? desfinalizaciones : estados;
            respuestas.add(cuerpo);
            return Mono.just(ClientResponse.create(HttpStatus.OK)
                    .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                    .body(cuerpo).build());
        });
    }

    private static final String SIN_FILAS = "{\"items\": []}";

    private static String estados(String... filas) {
        return "{\"items\": [" + String.join(",", filas) + "]}";
    }

    private static String cambio(String id, String estado, String fecha, String autor) {
        return """
            {"id": "%s", "status": "%s", "dateTime": {"value": "%s"},
             "createdByUserName": "%s"}
            """.formatted(id, estado, fecha, autor);
    }

    private static String desfinalizacion(String id, String codigo, String texto,
                                          String fecha, String autor) {
        return """
            {"items": [{"id": "%s",
               "unfinalizeReason": {"code": "%s", "descr": "%s"},
               "creationDate": {"value": "%s"},
               "createdByUserName": "%s"}]}
            """.formatted(id, codigo, texto, fecha, autor);
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("une los dos recursos y los ordena por fecha, no por recurso")
    void uneLosDosYOrdenaPorFecha() {
        // La desfinalización es posterior a los dos cambios de estado, así que tiene que
        // salir la última aunque venga de la otra consulta.
        ohiResponde(
                estados(cambio("1", "INITIAL", "2026-10-15T11:43:29-05:00", "Internal System User"),
                        cambio("2", "FINALIZED", "2026-10-16T09:00:00-05:00", "carlpase")),
                desfinalizacion("9", "PRORROGA", "Prorroga",
                                "2026-10-17T16:28:34-05:00", "auditor"));

        StepVerifier.create(adaptador.consultar(CODIGO).collectList())
                .assertNext(hitos -> {
                    assertThat(hitos).hasSize(3);
                    assertThat(hitos.get(2).tipo()).isEqualTo(HitoCuenta.Tipo.DESFINALIZACION);
                    assertThat(hitos.get(2).etiqueta()).isEqualTo("PRORROGA");
                    assertThat(hitos.get(2).detalle()).isEqualTo("Prorroga");
                })
                .verifyComplete();
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("cada consulta pide SU nombre de fecha: dateTime y creationDate")
    void cadaConsultaPideSuNombreDeFecha() {
        // Si se pidiera el mismo en las dos, una de ellas volvería sin fecha y la historia
        // quedaría ordenada por nada. El sistema de registro no avisa de eso.
        ohiResponde(SIN_FILAS, SIN_FILAS);

        StepVerifier.create(adaptador.consultar(CODIGO).collectList())
                .expectNextCount(1).verifyComplete();

        verify(intercambio, org.mockito.Mockito.times(2)).exchange(peticionCaptor.capture());
        var cuerpos = peticionCaptor.getAllValues().stream().map(CuerpoEnviado::de).toList();

        var deEstados = cuerpos.stream().filter(c -> c.contains("claim.code")).toList();
        assertThat(deEstados).hasSize(2);
        assertThat(cuerpos.stream().anyMatch(c -> c.contains("dateTime"))).isTrue();
        assertThat(cuerpos.stream().anyMatch(c -> c.contains("creationDate"))).isTrue();
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("un estado que el diccionario no traduce se enseña tal cual, no como DESCONOCIDO")
    void unEstadoSinTraduccionSeEnsenaTalCual() {
        // En una historia, un nombre feo informa y un hueco engaña: «DESCONOCIDO» repetido
        // tres veces no deja reconstruir por dónde pasó la cuenta.
        ohiResponde(estados(cambio("1", "ESTADO_QUE_NO_EXISTE", "2026-10-15T11:43:29-05:00", "x")),
                    SIN_FILAS);

        StepVerifier.create(adaptador.consultar(CODIGO).collectList())
                .assertNext(hitos -> assertThat(hitos).singleElement()
                        .satisfies(h -> assertThat(h.etiqueta()).isEqualTo("ESTADO_QUE_NO_EXISTE")))
                .verifyComplete();
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("una cuenta sin historia devuelve cero hitos, no un error")
    void sinHistoriaCeroHitos() {
        ohiResponde(SIN_FILAS, SIN_FILAS);

        StepVerifier.create(adaptador.consultar(CODIGO))
                .verifyComplete();
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("marca quién lo hizo: el motor o una persona")
    void marcaQuienLoHizo() {
        ohiResponde(estados(
                cambio("1", "INITIAL", "2026-10-15T11:43:29-05:00", "Internal System User"),
                cambio("2", "CHANGE", "2026-10-15T12:00:00-05:00", "carlpase")), SIN_FILAS);

        StepVerifier.create(adaptador.consultar(CODIGO).collectList())
                .assertNext(hitos -> {
                    assertThat(hitos.get(0).loHizoElSistema()).isTrue();
                    assertThat(hitos.get(1).loHizoElSistema()).isFalse();
                })
                .verifyComplete();
    }
}
