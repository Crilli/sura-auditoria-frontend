package co.sura.auditoria.acl.ohi.traductor;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.externo.OhiClaimLineItem;
import co.sura.auditoria.acl.ohi.externo.OhiMonto;
import co.sura.auditoria.acl.ohi.externo.OhiPricingClause;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.EdicionLinea;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * El traductor de la línea viva: de qué campo de OHI sale cada importe y a cuál se escribe.
 *
 * <p>No existía. El mapeo {@code allowed*}/{@code covered*} de la línea viva no lo comprobaba
 * nadie, y por eso la inversión de nombres que corrigió la decisión de negocio del 2026-10-21
 * —convenido = {@code allowedAmount}, autorizado = {@code coveredAmount}, cargado =
 * {@code claimedAmount}, glosado = {@code valorGlosado}— pudo vivir en todas las capas sin que
 * fallara una prueba.
 *
 * <p>Cada importe lleva una cifra distinta —cargado 1000, convenido 900, autorizado 800, glosado
 * 100, tarifa de contrato 950— y cada cantidad otra —cargadas 4, convenidas 3, autorizadas 2—:
 * con la misma cifra en todos, un cruce entre dos campos pasaría en verde.
 *
 * <p>Las líneas se leen de JSON con la forma en que las publica {@code /generic/claimlines}, y no
 * construyendo el record a mano: así la prueba fija también los nombres de OHI. Ningún dato
 * identifica a una persona.
 */
@DisplayName("TraductorLinea")
class TraductorLineaTest {

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final CodigoCuenta CUENTA = new CodigoCuenta("CM-94421");

    private final TraductorLinea traductor =
            new TraductorLinea(new TraductorNovedad(), new TraductorPendiente());

    /** Una línea aprobada, con los cuatro importes y las tres cantidades. */
    private static final String APROBADA = """
            {
              "id": 135280, "sequence": 7,
              "procedure": {"code": "890201", "descr": "Consulta de prueba",
                            "flexCodeDefinitionCode": "CUPS"},
              "claimedAmount": {"currency": "COP", "value": 1000},
              "claimedNumberOfUnits": 4,
              "allowedAmount": {"currency": "COP", "value": 900},
              "allowedNumberOfUnits": 3,
              "coveredAmount": {"currency": "COP", "value": 800},
              "coveredNumberOfUnits": 2,
              "valorGlosado": 100,
              "keepBenefits": false, "keepPricing": true, "locked": false, "replaced": false,
              "objectVersionNumber": 5
            }""";

    /**
     * Una línea negada: el sistema de registro no publica el convenido —medido: ninguna de las
     * 60 líneas de CM-29939061906 V8 lo trae— y el autorizado llega en cero. Tampoco trae el
     * cargado, y el monto del IVA llega con su objeto pero sin valor.
     */
    private static final String NEGADA = """
            {
              "id": 135281, "sequence": 8,
              "coveredAmount": {"currency": "COP", "value": 0},
              "coveredNumberOfUnits": 0,
              "claimedAmount": {"currency": "COP"},
              "objectVersionNumber": 2
            }""";

    private static OhiClaimLineItem linea(String json) throws Exception {
        return JSON.readValue(json, OhiClaimLineItem.class);
    }

    private static OhiPricingClause clausula(int secuencia, String importe, String texto) {
        return new OhiPricingClause((long) secuencia, secuencia,
                new OhiMonto("COP", new BigDecimal(importe)),
                new OhiPricingClause.OhiProviderPricingClauseRef(String.valueOf(secuencia), texto),
                new OhiPricingClause.OhiClaimLineRefSimple(135280L));
    }

    private LineaCuenta detalle(String json, List<OhiPricingClause> clausulas) throws Exception {
        return traductor.aDetalle(linea(json), CUENTA, null, List.of(), List.of(),
                Map.of(), Map.of(), clausulas, null);
    }

    @Nested
    @DisplayName("grilla (aResumen)")
    class Grilla {

        @Test
        @Tag("GRID-10")
        @Tag("GRID-11")
        @DisplayName("[GRID-10][GRID-11] el valor y la cantidad convenidos salen de allowedAmount y allowedNumberOfUnits")
        void elConvenidoSaleDeAllowed() throws Exception {
            ResumenLinea r = traductor.aResumen(linea(APROBADA), null);

            assertThat(r.valorConvenido()).isEqualByComparingTo("900");
            assertThat(r.unidadesConvenidas()).isEqualByComparingTo("3");
        }

        @Test
        @Tag("GRID-12")
        @Tag("GRID-13")
        @DisplayName("[GRID-12][GRID-13] el valor y la cantidad autorizados salen de coveredAmount y coveredNumberOfUnits")
        void elAutorizadoSaleDeCovered() throws Exception {
            ResumenLinea r = traductor.aResumen(linea(APROBADA), null);

            assertThat(r.valorAutorizado()).isEqualByComparingTo("800");
            // Nueva en la grilla: hasta el 2026-10-21 la cantidad que se pintaba como
            // autorizada era la convenida.
            assertThat(r.unidadesAutorizadas()).isEqualByComparingTo("2");
        }

        @Test
        @Tag("GRID-10")
        @Tag("GRID-12")
        @DisplayName("[GRID-10][GRID-12] cargado y glosado no se cruzan con convenido ni autorizado")
        void cargadoYGlosadoEnSuSitio() throws Exception {
            ResumenLinea r = traductor.aResumen(linea(APROBADA), null);

            assertThat(r.valorCargado()).isEqualByComparingTo("1000");
            assertThat(r.unidadesCargadas()).isEqualByComparingTo("4");
            assertThat(r.valorGlosado()).isEqualByComparingTo("100");
        }

        @Test
        @Tag("GRID-13")
        @Tag("GRID-10")
        @Tag("GRID-12")
        @DisplayName("[GRID-13] la proyección de la grilla pide cada importe y cada cantidad que se leen")
        void laProyeccionPideCadaImporte() {
            // OHI no valida `fields`: lo que no se pide llega ausente con un 200. Hasta el
            // 2026-10-21 la grilla no pedía coveredNumberOfUnits, y la cantidad autorizada habría
            // salido en raya en todas las líneas sin que nada fallara.
            var pedidos = List.of(co.sura.auditoria.acl.ohi.consulta.CamposOhi.RESUMEN_LINEA
                    .split(","));

            assertThat(pedidos).contains(
                    "claimedAmount", "claimedNumberOfUnits",
                    "allowedAmount", "allowedNumberOfUnits",
                    "coveredAmount", "coveredNumberOfUnits",
                    "valorGlosado");
        }

        @Test
        @Tag("GRID-10")
        @Tag("GRID-11")
        @Tag("GRID-12")
        @DisplayName("[GRID-10][GRID-11][GRID-12] en la línea negada el convenido es nulo, no cero, y el autorizado cero")
        void laNegadaTraeConvenidoNulo() throws Exception {
            ResumenLinea r = traductor.aResumen(linea(NEGADA), null);

            assertThat(r.valorConvenido()).isNull();
            assertThat(r.unidadesConvenidas()).isNull();
            assertThat(r.valorAutorizado()).isEqualByComparingTo("0");
            assertThat(r.unidadesAutorizadas()).isEqualByComparingTo("0");
            // El monto con su objeto pero sin «value» tampoco es un cero.
            assertThat(r.valorCargado()).isNull();
        }
    }

    @Nested
    @DisplayName("detalle (aDetalle)")
    class Detalle {

        @Test
        @Tag("LIN-07")
        @Tag("LIN-08")
        @DisplayName("[LIN-07][LIN-08] el valor y la cantidad convenidos salen de allowedAmount y allowedNumberOfUnits")
        void elConvenidoSaleDeAllowed() throws Exception {
            var d = detalle(APROBADA, List.of());

            assertThat(d.valorConvenido()).isEqualByComparingTo("900");
            assertThat(d.unidadesConvenidas()).isEqualByComparingTo("3");
        }

        @Test
        @Tag("LIN-09")
        @Tag("LIN-10")
        @DisplayName("[LIN-09][LIN-10] el valor y la cantidad autorizados salen de coveredAmount y coveredNumberOfUnits")
        void elAutorizadoSaleDeCovered() throws Exception {
            var d = detalle(APROBADA, List.of());

            assertThat(d.valorAutorizado()).isEqualByComparingTo("800");
            assertThat(d.unidadesAutorizadas()).isEqualByComparingTo("2");
            assertThat(d.valorCargado()).isEqualByComparingTo("1000");
            assertThat(d.unidadesCargadas()).isEqualByComparingTo("4");
            assertThat(d.valorGlosado()).isEqualByComparingTo("100");
        }

        @Test
        @Tag("LIN-07")
        @DisplayName("[LIN-07] la cláusula de contrato es la tarifa de contrato, no el convenido")
        void laClausulaEsLaTarifaDeContrato() throws Exception {
            // 950 de contrato y −50 de regla: el neto, 900, es el allowedAmount de la línea. La
            // tarifa de contrato es el punto de partida, y se publica con su propio nombre para
            // que el detalle no lleve dos «convenido» con cifras distintas.
            var d = detalle(APROBADA, List.of(
                    clausula(2, "-50", "REGLA_CUENTA_MEDICA"),
                    clausula(1, "950", "Prestador 1 Propuesta 1 Manual tarifario SOAT")));

            assertThat(d.convenio().valorTarifaContrato()).isEqualByComparingTo("950");
            assertThat(d.convenio().tarifaAplicada())
                    .isEqualTo("Prestador 1 Propuesta 1 Manual tarifario SOAT");
            assertThat(d.valorConvenido()).isEqualByComparingTo("900");
        }

        @Test
        @Tag("LIN-07")
        @DisplayName("[LIN-07] sin cláusula de contrato la tarifa de contrato es nula y el convenido sigue")
        void sinClausulaLaTarifaEsNula() throws Exception {
            var d = detalle(APROBADA, List.of(clausula(1, "-50", "RM_AJUSTE")));

            assertThat(d.convenio().valorTarifaContrato()).isNull();
            assertThat(d.valorConvenido()).isEqualByComparingTo("900");
        }

        @Test
        @Tag("LIN-07")
        @Tag("LIN-08")
        @Tag("LIN-09")
        @DisplayName("[LIN-07][LIN-08][LIN-09] en la línea negada el convenido es nulo, no cero, y el autorizado cero")
        void laNegadaTraeConvenidoNulo() throws Exception {
            var d = detalle(NEGADA, List.of());

            assertThat(d.valorConvenido()).isNull();
            assertThat(d.unidadesConvenidas()).isNull();
            assertThat(d.valorAutorizado()).isEqualByComparingTo("0");
            assertThat(d.valorCargado()).isNull();
        }
    }

    @Nested
    @DisplayName("escritura (desdeEdicion)")
    class Escritura {

        private static EdicionLinea conConvenido(String valor, String unidades) {
            return new EdicionLinea(new ReferenciaLinea(135280L), new Version(5L),
                    Optional.of(new BigDecimal(valor)), Optional.of(new BigDecimal(unidades)),
                    Optional.empty(), Optional.empty(), Optional.empty(),
                    Optional.of(new BigDecimal("1000")), Optional.of(new BigDecimal("4")),
                    Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                    Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                    Optional.empty(), Optional.empty(), Optional.empty(),
                    List.of(), List.of(), ModoRecalculo.AISLADO);
        }

        @Test
        @Tag("GRID-18")
        @Tag("LIN-07")
        @Tag("LIN-08")
        @DisplayName("[GRID-18][LIN-07] el valor y las unidades convenidas se escriben en allowedAmount y allowedNumberOfUnits")
        void elConvenidoSeEscribeEnAllowed() {
            var parche = traductor.desdeEdicion(conConvenido("900", "3"));

            assertThat(parche.allowedAmount()).isEqualTo(new OhiMonto("COP", new BigDecimal("900")));
            assertThat(parche.allowedNumberOfUnits()).isEqualByComparingTo("3");
            assertThat(parche.claimedAmount().value()).isEqualByComparingTo("1000");
            assertThat(parche.claimedNumberOfUnits()).isEqualByComparingTo("4");
        }

        @Test
        @Tag("GRID-18")
        @Tag("LIN-09")
        @DisplayName("[GRID-18][LIN-09] el parche serializado no lleva nada del autorizado")
        void elParcheNoLlevaElAutorizado() throws Exception {
            var json = JSON.writeValueAsString(traductor.desdeEdicion(conConvenido("900", "3")));

            assertThat(json).contains("\"allowedAmount\"").contains("\"allowedNumberOfUnits\"")
                    .doesNotContain("coveredAmount").doesNotContain("coveredNumberOfUnits");
        }
    }
}
