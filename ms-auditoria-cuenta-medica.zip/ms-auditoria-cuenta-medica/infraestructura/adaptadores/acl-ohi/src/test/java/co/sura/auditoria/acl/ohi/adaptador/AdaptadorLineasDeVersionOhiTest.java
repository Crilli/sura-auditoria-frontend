package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.CuerpoEnviado;
import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion;
import co.sura.auditoria.modelo.cuenta.Severidad;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.RecordComponent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.IntStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * Las líneas de una versión contra el sistema de registro (BUS-21).
 *
 * <p>Lo que se fija aquí son las trampas medidas en UAT el 2026-10-21 que no dan error: sin
 * {@code ctrClaim.reversal.eq(false)} entran las líneas de la gemela de reversión con los
 * importes negados; los importes son números planos y leídos con el tipo de la línea viva
 * quedan en nulo; y un 204 significa tres cosas distintas —versión inexistente, versión sin
 * líneas, página más allá del final— que la pantalla tiene que distinguir.
 *
 * <p>Los cuerpos imitan los de UAT (CM-29939061906 V8, CM-4146 V6 y V7) con los datos de
 * personas sustituidos: ningún documento ni apellido de aquí es real.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AdaptadorLineasDeVersionOhi")
class AdaptadorLineasDeVersionOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-29939061906");

    @Mock ExchangeFunction intercambio;
    @Mock ConfiguracionResiliencia resiliencia;
    @Captor ArgumentCaptor<ClientRequest> peticion;

    private AdaptadorLineasDeVersionOhi adaptador;

    /** Los cuerpos servidos, en orden; {@code null} es un 204 sin cuerpo. */
    private final List<String> servidas = new ArrayList<>();

    @BeforeEach
    void montar() {
        var webClient = WebClient.builder()
                .baseUrl("https://ohi.example/api")
                .exchangeFunction(intercambio)
                .build();
        org.mockito.Mockito.lenient()
                .when(resiliencia.<Object>paraConsultaPacienteMono()).thenReturn(Function.identity());
        adaptador = new AdaptadorLineasDeVersionOhi(webClient, resiliencia,
                                                    new TraductorErrores(new ObjectMapper()));
    }

    /** Las respuestas de OHI en el orden en que se piden; {@code null} es un 204. */
    private void ohiResponde(String... cuerpos) {
        var guion = Arrays.asList(cuerpos);
        when(intercambio.exchange(any())).thenAnswer(invocacion -> {
            var turno = servidas.size();
            var cuerpo = turno < guion.size() ? guion.get(turno) : guion.get(guion.size() - 1);
            servidas.add(cuerpo);
            if (cuerpo == null) {
                return Mono.just(ClientResponse.create(HttpStatus.NO_CONTENT).build());
            }
            return Mono.just(ClientResponse.create(HttpStatus.OK)
                    .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                    .body(cuerpo).build());
        });
    }

    private List<ClientRequest> peticiones() {
        verify(intercambio, times(servidas.size())).exchange(peticion.capture());
        return peticion.getAllValues();
    }

    /** Una línea con lo que publica la proyección de la grilla. */
    private static String linea(int secuencia, String estado, String importesYMas) {
        return """
            {"sequence": %d, "status": "%s", "startDate": "2025-07-01",
             "procedureCode": "890701", "procedureCodeDef": "CUPS",
             "procedureDescription": "CONSULTA DE URGENCIAS POR MEDICINA GENERAL",
             "servicedEntityCode": "CC0000000001", "servicedEntityName": "Apellido",
             "authorizationCode": "4142", "serviceProvCode": "800000000-001",
             "serviceProvName": "Prestador de prueba",
             "createdByUserName": "Internal System User"%s}
            """.formatted(secuencia, estado, importesYMas.isEmpty() ? "" : ", " + importesYMas);
    }

    private static String pagina(Long total, Boolean hayMas, String... lineas) {
        return "{\"items\": [" + String.join(",", lineas) + "]"
             + (total == null ? "" : ", \"totalResults\": " + total)
             + (hayMas == null ? "" : ", \"hasMore\": " + hayMas) + "}";
    }

    private static final String VERSION_EXISTE = "{\"items\": [{\"id\": \"31220810482\"}]}";

    /**
     * Los campos que la petición pidió a OHI, uno a uno.
     *
     * <p>Se comparan nombres enteros y no trozos del cuerpo: {@code allowedAmount} está dentro de
     * {@code allowedAmountCurrency}, y un {@code contains} sobre el texto daría por pedido un
     * campo que no lo está.
     */
    private static Set<String> camposPedidos(String cuerpo) throws Exception {
        var campos = new ObjectMapper().readTree(cuerpo)
                .path("resourceRepresentation").path("fields").asText();
        return Set.of(campos.split("\\|"));
    }

    private static Set<String> deLaProyeccion(String proyeccion) {
        return Set.of(proyeccion.split(","));
    }

    @Nested
    @DisplayName("la página de líneas")
    class Pagina {

        @Test
        @Tag("BUS-21")
        @DisplayName("pide esa versión sin su gemela de reversión, en orden de línea y desde la posición")
        void pideLaVersionSinSuGemelaEnOrdenYDesdeLaPosicion() throws Exception {
            ohiResponde(pagina(60L, true, linea(127, "Negado", "\"claimedAmount\": 64400")));

            adaptador.lineasDeVersion(CODIGO, 8, 25, 25).block();

            var enviada = peticiones().get(0);
            assertThat(enviada.url().getPath()).endsWith("/generic/ctrclaimlines/search");
            var cuerpo = CuerpoEnviado.de(enviada);
            // Sin el reversal salen 120 líneas en vez de 60: las de la gemela, negadas (BUS-21.2).
            assertThat(cuerpo).contains("ctrClaim.code.eq('CM-29939061906')")
                              .contains("ctrClaim.version.eq(8)")
                              .contains("ctrClaim.reversal.eq(false)")
                              .contains("\"orderBy\":\"sequence asc\"")
                              .contains("\"offset\":25")
                              .contains("\"limit\":25")
                              .contains("\"totalResults\":true");
            // La proyección solo se respeta con defaultoverride y separada por barras.
            assertThat(cuerpo).contains("\"defaultoverride\":\"true\"")
                              .contains("claimedAmount|claimedNumberOfUnits")
                              .contains("detallesGlosa.valorGlosa")
                              // La grilla no pide lo que pesa: eso es del detalle.
                              .doesNotContain("ctrClaimLineMessageList");
            // BUS-21.1: cada importe de la grilla, pedido por su nombre. Con defaultoverride lo
            // que no se pide no llega, y la columna saldría en raya en todas las líneas sin error.
            assertThat(camposPedidos(cuerpo)).contains(
                    "claimedAmount", "allowedAmount", "coveredAmount", "valorGlosado",
                    "montoIVACalculado", "porcentajeIVA",
                    "claimedNumberOfUnits", "allowedNumberOfUnits", "coveredNumberOfUnits",
                    "startDate", "endDate", "status", "sequence");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("los importes planos llegan con su valor, y el que falta es nulo, no cero")
        void importesPlanosConSuValor() {
            // Como los publica ctrclaimlines: números sueltos con la moneda aparte. Leídos con el
            // tipo de claimlines ({currency, value}) quedarían todos en nulo sin un error.
            ohiResponde(pagina(60L, true,
                    linea(1, "Aprobado", """
                        "claimedAmount": 69959.5, "claimedAmountCurrency": "COP",
                        "claimedNumberOfUnits": 1, "allowedAmount": 70959.5,
                        "allowedAmountCurrency": "COP", "allowedNumberOfUnits": 1,
                        "coveredAmount": 70960, "coveredNumberOfUnits": 1,
                        "valorGlosado": 6999, "montoIVACalculado": 1900, "porcentajeIVA": 19,
                        "endDate": "2025-07-02"
                        """),
                    // Negada: el sistema de registro no publica el valor convenido
                    // (allowedAmount); el autorizado (coveredAmount) sí, en cero.
                    linea(127, "Negado", "\"claimedAmount\": 64400, \"coveredAmount\": 0")));

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 8, 0, 25))
                    .assertNext(p -> {
                        assertThat(p.elementos()).extracting(LineaDeVersion::numeroLinea)
                                .containsExactly(1, 127);
                        var aprobada = p.elementos().get(0);
                        assertThat(aprobada.estado()).isEqualTo("APROBADA");
                        assertThat(aprobada.valorCargado()).isEqualByComparingTo("69959.5");
                        assertThat(aprobada.valorConvenido()).isEqualByComparingTo("70959.5");
                        assertThat(aprobada.valorAutorizado()).isEqualByComparingTo("70960");
                        assertThat(aprobada.unidadesCargadas()).isEqualByComparingTo("1");
                        assertThat(aprobada.valorGlosado()).isEqualByComparingTo("6999");
                        assertThat(aprobada.valorIva()).isEqualByComparingTo("1900");
                        assertThat(aprobada.porcentajeIva()).isEqualByComparingTo("19");
                        assertThat(aprobada.fechaInicio()).isEqualTo(LocalDate.of(2025, 7, 1));
                        assertThat(aprobada.fechaFin()).isEqualTo(LocalDate.of(2025, 7, 2));
                        assertThat(aprobada.codigoProcedimiento()).isEqualTo("890701");
                        assertThat(aprobada.catalogoProcedimiento()).isEqualTo("CUPS");
                        assertThat(aprobada.codigoAfiliado()).isEqualTo("CC0000000001");
                        assertThat(aprobada.prestadorNombre()).isEqualTo("Prestador de prueba");

                        var negada = p.elementos().get(1);
                        assertThat(negada.estado()).isEqualTo("NEGADA");
                        assertThat(negada.valorAutorizado()).isEqualByComparingTo("0");
                        // BUS-21.3: ausente es nulo —la pantalla pinta una raya—, nunca cero.
                        assertThat(negada.valorConvenido()).isNull();
                        assertThat(negada.valorGlosado()).isNull();
                        assertThat(negada.glosas()).isEmpty();
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("el desglose de glosa llega ordenado por su secuencia, que viene como cadena")
        void desgloseDeGlosa() {
            ohiResponde(pagina(4L, false, linea(2, "Negado", """
                "valorGlosado": 133069,
                "detallesGlosa": [
                  {"id": "15964865322", "numeroSecuencia": "1", "codigoGlosa": "423-1",
                   "valorGlosa": 100000, "descripcionGenerico": "Autorizaciones",
                   "descripcionEspecifico": "Procedimiento o actividad", "texto": "No autorizada",
                   "descripcionTipoGlosa": "Manual"},
                  {"id": "15964865321", "numeroSecuencia": "0", "codigoGlosa": "223-1A",
                   "valorGlosa": 33069, "codigoNotaCredito": "123", "valorNotaCredito": 3700}]
                """)));

            StepVerifier.create(adaptador.lineasDeVersion(new CodigoCuenta("CM-4146"), 7, 0, 25))
                    .assertNext(p -> assertThat(p.elementos()).singleElement().satisfies(l -> {
                        assertThat(l.glosas()).extracting(LineaDeVersion.GlosaDeVersion::codigo)
                                .containsExactly("223-1A", "423-1");
                        var primera = l.glosas().get(0);
                        assertThat(primera.secuencia()).isZero();
                        assertThat(primera.valor()).isEqualByComparingTo("33069");
                        assertThat(primera.codigoNotaCredito()).isEqualTo("123");
                        assertThat(primera.valorNotaCredito()).isEqualByComparingTo("3700");
                        var segunda = l.glosas().get(1);
                        assertThat(segunda.concepto()).isEqualTo("Autorizaciones");
                        assertThat(segunda.conceptoEspecifico()).isEqualTo("Procedimiento o actividad");
                        assertThat(segunda.texto()).isEqualTo("No autorizada");
                        assertThat(segunda.tipo()).isEqualTo("Manual");
                        assertThat(segunda.valorNotaCredito()).isNull();
                    }))
                    .verifyComplete();
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("publica el total y si hay más tal como los da el sistema de registro")
        void totalYHayMas() {
            ohiResponde(pagina(60L, true, linea(1, "Negado", "")));

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 8, 0, 25))
                    .assertNext(p -> {
                        assertThat(p.total()).contains(60L);
                        assertThat(p.totalPaginas()).contains(3L);
                        assertThat(p.hayMas()).isTrue();
                        assertThat(p.desplazamiento()).isZero();
                        assertThat(p.tamanoPagina()).isEqualTo(25);
                    })
                    .verifyComplete();
            assertThat(servidas).hasSize(1);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("BUS-21.4: la última página trae lo que queda, sin más detrás y con el mismo total")
        void ultimaPagina() {
            // CM-29939061906 V8 tiene 60 líneas: la tercera página de 25 empieza en la 50 y trae 10.
            var diez = IntStream.range(0, 10)
                    .mapToObj(i -> linea(200 + i, "Negado", "")).toArray(String[]::new);
            ohiResponde(pagina(60L, false, diez));

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 8, 50, 25))
                    .assertNext(p -> {
                        assertThat(p.elementos()).hasSize(10);
                        assertThat(p.hayMas()).isFalse();
                        assertThat(p.total()).contains(60L);
                        assertThat(p.totalPaginas()).contains(3L);
                        assertThat(p.desplazamiento()).isEqualTo(50);
                        assertThat(p.numeroDePagina()).isEqualTo(2);
                        // Lo recorrido hasta aquí más lo de esta página es el total publicado.
                        assertThat((long) p.desplazamiento() + p.elementos().size()).isEqualTo(60L);
                    })
                    .verifyComplete();
            // Con filas en la página no hace falta preguntar el total aparte.
            assertThat(servidas).hasSize(1);
            assertThat(CuerpoEnviado.de(peticiones().get(0))).contains("\"offset\":50");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("un estado que no conoce se publica tal cual, y sin estado sigue sin estado")
        void estadoDesconocido() {
            ohiResponde(pagina(2L, false,
                    linea(1, "Suspendido", ""),
                    "{\"sequence\": 2}"));

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 8, 0, 25))
                    .assertNext(p -> assertThat(p.elementos()).extracting(LineaDeVersion::estado)
                            .containsExactly("Suspendido", null))
                    .verifyComplete();
        }
    }

    @Nested
    @DisplayName("un 204 en la página")
    class SinFilas {

        @Test
        @Tag("BUS-21")
        @DisplayName("versión que no existe: llega vacía, para que el caso de uso la nombre")
        void versionQueNoExiste() {
            ohiResponde(null, null);

            StepVerifier.create(adaptador.lineasDeVersion(new CodigoCuenta("CM-4146"), 99, 0, 25))
                    .verifyComplete();

            // Se preguntó al histórico, por la fila de la versión y sin su gemela.
            var pedidas = peticiones();
            assertThat(pedidas).hasSize(2);
            assertThat(pedidas.get(1).url().getPath()).endsWith("/generic/ctrclaims/search");
            assertThat(CuerpoEnviado.de(pedidas.get(1)))
                    .contains("code.eq('CM-4146')").contains("version.eq(99)")
                    .contains("reversal.eq(false)").doesNotContain("ctrClaim.");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("versión que existe sin líneas: una página vacía con total cero, no un error")
        void versionSinLineas() {
            // Las madres de large claim: versiones con importes y ninguna línea (148 en UAT).
            ohiResponde(null, VERSION_EXISTE);

            StepVerifier.create(adaptador.lineasDeVersion(new CodigoCuenta("CM-8790"), 1, 0, 25))
                    .assertNext(p -> {
                        assertThat(p.elementos()).isEmpty();
                        assertThat(p.total()).contains(0L);
                        assertThat(p.hayMas()).isFalse();
                    })
                    .verifyComplete();
            assertThat(servidas).hasSize(2);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("más allá del final no es una versión vacía: pregunta el total aparte")
        void masAllaDelFinal() {
            // Medido: offset 60 sobre las 60 líneas de CM-29939061906 V8 da 204 sin cuerpo.
            ohiResponde(null, pagina(60L, true, "{\"id\": \"44093511586\"}"));

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 8, 75, 25))
                    .assertNext(p -> {
                        assertThat(p.elementos()).isEmpty();
                        assertThat(p.total()).contains(60L);
                        assertThat(p.hayMas()).isFalse();
                        assertThat(p.desplazamiento()).isEqualTo(75);
                    })
                    .verifyComplete();

            // La del total es de una fila, a la misma versión; el histórico no hace falta.
            var pedidas = peticiones();
            assertThat(pedidas).hasSize(2);
            assertThat(pedidas.get(1).url().getPath()).endsWith("/generic/ctrclaimlines/search");
            assertThat(CuerpoEnviado.de(pedidas.get(1)))
                    .contains("ctrClaim.reversal.eq(false)").contains("\"limit\":1")
                    .contains("\"totalResults\":true");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("más allá del final de una versión que no existe sigue siendo inexistente")
        void masAllaDelFinalDeUnaVersionQueNoExiste() {
            ohiResponde(null, null, null);

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 99, 25, 25)).verifyComplete();
            assertThat(servidas).hasSize(3);
        }
    }

    @Nested
    @DisplayName("una línea abierta")
    class Detalle {

        private static final String DETALLE_CM_4146 = """
            {"items": [{"sequence": 1, "status": "Negado", "startDate": "2022-09-01",
              "procedureCode": "870107", "procedureCodeDef": "CUPS",
              "claimedAmount": 29069, "allowedAmount": 29069, "coveredAmount": 0,
              "valorGlosado": 29069,
              "codeTariffISS2001": "39145", "homologoCups": "870107",
              "codigoTipoSala": "6", "codigoViaAcceso": "84", "descripcionViaAcceso": "NO APLICA",
              "datosAdicionalesSiniestro": {"UEN": "ARL"},
              "ctrClaimLineMessageList": [%s],
              "ctrClaimLineDiagnosisList": [
                {"sequence": 2, "code": "S080", "description": "AVULSION DEL CUERO CABELLUDO",
                 "typeDescription": "Otro tipo de diagnóstico"},
                {"sequence": 1, "code": "S099",
                 "description": "TRAUMATISMO DE LA CABEZA, NO ESPECIFICADO",
                 "typeDescription": "Diagnóstico principal"}],
              "ctrClaimLineProviderPricingClauseList": [
                {"sequence": 2, "amount": -9689.16, "methodRuleCode": "RVI_CUENTAS_MEDICAS",
                 "providerPricingClauseDescr": "REGLA_CUENTA_MEDICA"},
                {"sequence": 1, "amount": 38758.16, "methodRuleCode": "ISS2000_COP",
                 "providerPricingClauseDescr": "Manual tarifario ISS2000"}]}]}
            """;

        private static String novedad(String codigo, String severidad, String texto,
                                       String origen, boolean anulada) {
            return """
                {"code": "%s", "severity": "%s", "messageText": "%s", "origin": "%s",
                 "overturned": %b}
                """.formatted(codigo, severidad, texto, origen, anulada);
        }

        private static String novedadesComoEnUat() {
            // Medido en la línea 1 de CM-4146 V6: la 223-1A doce veces, idéntica.
            var repetida = novedad("223-1A", "I", "El valor facturado no corresponde", "MANUAL", false);
            var todas = new ArrayList<String>();
            todas.add(novedad("SURA-AUT-006", "F", "Autorización 4142 encontrada y negada",
                              "RESERVATION", false));
            for (int i = 0; i < 12; i++) todas.add(repetida);
            todas.add(novedad("423-1", "I", "No autorizada", "MANUAL", false));
            // La misma 223-1A, pero anulada: es otra novedad, no una repetición.
            todas.add(novedad("223-1A", "I", "El valor facturado no corresponde", "MANUAL", true));
            return String.join(",", todas);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("pide esa línea de esa versión, sin la gemela, con novedades y diagnósticos")
        void pideEsaLineaDeEsaVersion() throws Exception {
            ohiResponde(DETALLE_CM_4146.formatted(novedadesComoEnUat()));

            adaptador.detalleDeLinea(new CodigoCuenta("CM-4146"), 7, 1).block();

            var cuerpo = CuerpoEnviado.de(peticiones().get(0));
            assertThat(cuerpo).contains("ctrClaim.code.eq('CM-4146')")
                              .contains("ctrClaim.version.eq(7)")
                              .contains("ctrClaim.reversal.eq(false)")
                              .contains("sequence.eq(1)")
                              .contains("ctrClaimLineMessageList.messageText")
                              .contains("ctrClaimLineDiagnosisList.typeDescription")
                              .contains("ctrClaimLineProviderPricingClauseList.amount")
                              .contains("datosAdicionalesSiniestro.UEN");
            // BUS-21.5: el convenio y la atención, por su nombre; y los importes de la fila,
            // que el detalle repite.
            assertThat(camposPedidos(cuerpo)).contains(
                    "codeTariffISS2000", "codeTariffISS2001", "codeTariffSOAT", "homologoCups",
                    "codigoTipoSala", "descripcionTipoSala", "codigoViaAcceso",
                    "descripcionViaAcceso", "allowedAmount", "coveredAmount", "valorGlosado")
                    // La foto de producción no tiene número de contrato: ver CamposOhi.
                    .doesNotContain("numeroContrato");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("agrupa las novedades repetidas y dice cuántas eran")
        void agrupaLasNovedadesRepetidas() {
            ohiResponde(DETALLE_CM_4146.formatted(novedadesComoEnUat()));

            StepVerifier.create(adaptador.detalleDeLinea(new CodigoCuenta("CM-4146"), 6, 1))
                    .assertNext(d -> {
                        assertThat(d.novedades()).extracting(
                                        DetalleLineaDeVersion.NovedadDeVersion::codigo,
                                        DetalleLineaDeVersion.NovedadDeVersion::repeticiones,
                                        DetalleLineaDeVersion.NovedadDeVersion::anulada)
                                .containsExactly(
                                        org.assertj.core.groups.Tuple.tuple("SURA-AUT-006", 1, false),
                                        org.assertj.core.groups.Tuple.tuple("223-1A", 12, false),
                                        org.assertj.core.groups.Tuple.tuple("423-1", 1, false),
                                        org.assertj.core.groups.Tuple.tuple("223-1A", 1, true));
                        var primera = d.novedades().get(0);
                        // La severidad de una letra, traducida como en la línea viva.
                        assertThat(primera.severidad()).isEqualTo(Severidad.BLOQUEANTE);
                        assertThat(primera.texto()).isEqualTo("Autorización 4142 encontrada y negada");
                        assertThat(primera.origen()).isEqualTo("RESERVATION");
                        assertThat(d.novedades().get(1).severidad()).isEqualTo(Severidad.INFORMATIVA);
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("trae diagnósticos y cláusulas en su orden, convenio y atención de entonces")
        void diagnosticosConvenioYAtencion() {
            ohiResponde(DETALLE_CM_4146.formatted(""));

            StepVerifier.create(adaptador.detalleDeLinea(new CodigoCuenta("CM-4146"), 7, 1))
                    .assertNext(d -> {
                        assertThat(d.linea().numeroLinea()).isEqualTo(1);
                        assertThat(d.linea().estado()).isEqualTo("NEGADA");
                        assertThat(d.linea().valorConvenido()).isEqualByComparingTo("29069");
                        assertThat(d.novedades()).isEmpty();
                        assertThat(d.diagnosticos())
                                .extracting(DetalleLineaDeVersion.DiagnosticoDeVersion::codigo)
                                .containsExactly("S099", "S080");
                        assertThat(d.diagnosticos().get(0).tipo()).isEqualTo("Diagnóstico principal");

                        var convenio = d.convenio();
                        assertThat(convenio.tarifaIss2001()).isEqualTo("39145");
                        assertThat(convenio.tarifaIss2000()).isNull();
                        assertThat(convenio.homologoCups()).isEqualTo("870107");
                        assertThat(convenio.clausulas())
                                .extracting(DetalleLineaDeVersion.ClausulaDeVersion::regla)
                                .containsExactly("ISS2000_COP", "RVI_CUENTAS_MEDICAS");
                        assertThat(convenio.clausulas().get(1).monto())
                                .isEqualByComparingTo("-9689.16");

                        // Sin descripción de sala se queda el código; la vía trae las dos.
                        assertThat(d.atencion().tipoSala()).isEqualTo("6");
                        assertThat(d.atencion().viaAcceso()).isEqualTo("NO APLICA");
                        assertThat(d.atencion().uen()).isEqualTo("ARL");
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("una línea que esa versión no tiene llega vacía, sin preguntar nada más")
        void lineaQueNoEsta() {
            ohiResponde((String) null);

            StepVerifier.create(adaptador.detalleDeLinea(CODIGO, 8, 2)).verifyComplete();
            // Si es la versión o la línea lo averigua el caso de uso, y solo entonces.
            assertThat(servidas).hasSize(1);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("sin convenio ni atención, los dos llegan vacíos y no nulos")
        void sinConvenioNiAtencion() {
            ohiResponde("{\"items\": [{\"sequence\": 3}]}");

            StepVerifier.create(adaptador.detalleDeLinea(CODIGO, 8, 3))
                    .assertNext(d -> {
                        assertThat(d.convenio().clausulas()).isEmpty();
                        assertThat(d.convenio().homologoCups()).isNull();
                        assertThat(d.convenio().tarifaSoat()).isNull();
                        assertThat(d.atencion().uen()).isNull();
                        assertThat(d.diagnosticos()).isEmpty();
                    })
                    .verifyComplete();
        }
    }

    /**
     * La proyección contra lo que de verdad se lee.
     *
     * <p>Con {@code defaultoverride} OHI devuelve solo lo que se pide, y no valida {@code fields}:
     * un campo que el contrato externo lee y la proyección no pide llega ausente, con un 200, y
     * acaba en raya en todas las líneas. Es la trampa de BUS-21.3 por otra puerta, y ninguna de
     * las pruebas de arriba la ve, porque el simulacro sirve el campo se pida o no.
     */
    @Nested
    @DisplayName("la proyección")
    class Proyeccion {

        /**
         * Los nombres JSON que lee un record externo, con su prefijo si va anidado: una lista de
         * records o un record se piden por sus subcampos ({@code detallesGlosa.valorGlosa},
         * {@code datosAdicionalesSiniestro.UEN}).
         */
        private static Set<String> camposQueLee(Class<?> externo, String prefijo) {
            var campos = new LinkedHashSet<String>();
            for (RecordComponent componente : externo.getRecordComponents()) {
                var nombre = prefijo + nombreJson(componente);
                var tipo = componente.getType();
                if (List.class.isAssignableFrom(tipo)) {
                    var elemento = (Class<?>) ((ParameterizedType) componente.getGenericType())
                            .getActualTypeArguments()[0];
                    if (elemento.isRecord()) {
                        campos.addAll(camposQueLee(elemento, nombre + "."));
                        continue;
                    }
                } else if (tipo.isRecord()) {
                    campos.addAll(camposQueLee(tipo, nombre + "."));
                    continue;
                }
                campos.add(nombre);
            }
            return campos;
        }

        /**
         * El de {@code @JsonProperty} si lo tiene, como lo lee Jackson. La anotación no admite
         * componentes de record, así que Java la deja en el accesor y no en el componente.
         */
        private static String nombreJson(RecordComponent componente) {
            var anotacion = componente.getAccessor().getAnnotation(JsonProperty.class);
            return anotacion == null || anotacion.value().isEmpty()
                    ? componente.getName() : anotacion.value();
        }

        /**
         * Una línea como la serviría OHI con esa proyección: sin los campos no pedidos, y las
         * colecciones y registros anidados solo con los subcampos pedidos.
         */
        private static String soloLoPedido(String linea, String proyeccion) throws Exception {
            var pedidos = deLaProyeccion(proyeccion);
            var mapper = new ObjectMapper();
            var completa = mapper.readTree(linea);
            var servida = mapper.createObjectNode();
            completa.fieldNames().forEachRemaining(nombre -> {
                var valor = completa.get(nombre);
                var anidadoPedido = pedidos.stream().anyMatch(p -> p.startsWith(nombre + "."));
                if (pedidos.contains(nombre)) {
                    servida.set(nombre, valor);
                } else if (anidadoPedido && valor.isArray()) {
                    var elementos = servida.putArray(nombre);
                    valor.forEach(e -> elementos.add(subcampos(mapper, e, nombre, pedidos)));
                } else if (anidadoPedido && valor.isObject()) {
                    servida.set(nombre, subcampos(mapper, valor, nombre, pedidos));
                }
            });
            return servida.toString();
        }

        private static ObjectNode subcampos(ObjectMapper mapper, JsonNode objeto, String prefijo,
                                            Set<String> pedidos) {
            var recortado = mapper.createObjectNode();
            objeto.fieldNames().forEachRemaining(sub -> {
                if (pedidos.contains(prefijo + "." + sub)) recortado.set(sub, objeto.get(sub));
            });
            return recortado;
        }

        /** Una línea con todos los datos que la grilla y el detalle saben leer; nada personal. */
        private static final String LINEA_COMPLETA = """
            {"sequence": 3, "status": "Aprobado", "startDate": "2025-07-01",
             "endDate": "2025-07-02", "procedureCode": "890701", "procedureCodeDef": "CUPS",
             "procedureDescription": "CONSULTA DE URGENCIAS POR MEDICINA GENERAL",
             "servicedEntityCode": "CC0000000001", "servicedEntityName": "Apellido",
             "authorizationCode": "4142", "serviceProvCode": "800000000-001",
             "serviceProvName": "Prestador de prueba",
             "claimedAmount": 77958, "claimedNumberOfUnits": 1,
             "allowedAmount": 70000, "allowedNumberOfUnits": 1,
             "coveredAmount": 65000, "coveredNumberOfUnits": 1,
             "valorGlosado": 7958, "montoIVACalculado": 1900, "porcentajeIVA": 19,
             "detallesGlosa": [
               {"numeroSecuencia": "0", "codigoGlosa": "223-1A", "valorGlosa": 7958,
                "codigoNotaCredito": "123", "valorNotaCredito": 3700,
                "descripcionGenerico": "Tarifas", "descripcionEspecifico": "Diferencia en valores",
                "texto": "Texto de la glosa", "descripcionTipoGlosa": "Manual"}],
             "codeTariffISS2000": "25100", "homologoCups": "870107",
             "datosAdicionalesSiniestro": {"UEN": "ARL"},
             "ctrClaimLineMessageList": [
               {"code": "223-1A", "severity": "I", "messageText": "Texto", "origin": "MANUAL",
                "overturned": false}]}
            """;

        @Test
        @Tag("BUS-21")
        @DisplayName("todo lo que lee el contrato externo de la línea está en la proyección del detalle")
        void todoLoQueSeLeeSePideEnElDetalle() {
            var leidos = camposQueLee(AdaptadorLineasDeVersionOhi.OhiLineaDeVersion.class, "");

            // Que el recorrido ve de verdad los anidados y los nombres de @JsonProperty.
            assertThat(leidos).contains("allowedAmount", "montoIVACalculado",
                                        "detallesGlosa.valorGlosa", "datosAdicionalesSiniestro.UEN",
                                        "ctrClaimLineMessageList.overturned",
                                        "ctrClaimLineProviderPricingClauseList.amount");
            assertThat(deLaProyeccion(CamposOhi.DETALLE_LINEA_VERSION)).containsAll(leidos);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("BUS-21.1: con solo lo que pide la grilla, ningún dato de la fila queda en nulo")
        void laGrillaLlegaEnteraConSuProyeccion() throws Exception {
            var servida = soloLoPedido(LINEA_COMPLETA, CamposOhi.LINEA_VERSION);
            // El recorte es de verdad: lo del detalle no le llega a la grilla.
            assertThat(servida).doesNotContain("codeTariffISS2000").doesNotContain("UEN")
                               .doesNotContain("ctrClaimLineMessageList");
            ohiResponde(pagina(1L, false, servida));

            StepVerifier.create(adaptador.lineasDeVersion(CODIGO, 8, 0, 25))
                    .assertNext(p -> {
                        var fila = p.elementos().get(0);
                        for (var componente : LineaDeVersion.class.getRecordComponents()) {
                            assertThat(valorDe(componente, fila))
                                    .as("la grilla no pide lo que lee %s", componente.getName())
                                    .isNotNull();
                        }
                        assertThat(fila.glosas()).singleElement().satisfies(glosa -> {
                            for (var componente : LineaDeVersion.GlosaDeVersion.class
                                    .getRecordComponents()) {
                                assertThat(valorDe(componente, glosa))
                                        .as("la grilla no pide lo que lee la glosa en %s",
                                            componente.getName())
                                        .isNotNull();
                            }
                        });
                        assertThat(fila.valorConvenido()).isEqualByComparingTo("70000");
                        assertThat(fila.valorAutorizado()).isEqualByComparingTo("65000");
                        assertThat(fila.valorIva()).isEqualByComparingTo("1900");
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("no pide el número de contrato, que la foto de producción no guarda")
        void noPideElNumeroDeContrato() {
            // Consultada el 2026-10-21 la metadata de producción de ctrclaimlines: no trae
            // numeroContrato ni IUM (UAT sí). Pedirlo daría un 200 y un contrato siempre vacío.
            assertThat(deLaProyeccion(CamposOhi.DETALLE_LINEA_VERSION))
                    .doesNotContain("numeroContrato", "IUM");
            assertThat(camposQueLee(AdaptadorLineasDeVersionOhi.OhiLineaDeVersion.class, ""))
                    .doesNotContain("numeroContrato", "IUM");
        }

        private static Object valorDe(RecordComponent componente, Object registro) {
            try {
                return componente.getAccessor().invoke(registro);
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    @Nested
    @DisplayName("si la versión existe")
    class ExisteVersion {

        @Test
        @Tag("BUS-21")
        @DisplayName("pregunta al histórico por el id de la fila no reversa")
        void existe() {
            ohiResponde(VERSION_EXISTE);

            StepVerifier.create(adaptador.existeVersion(CODIGO, 8)).expectNext(true).verifyComplete();

            var cuerpo = CuerpoEnviado.de(peticiones().get(0));
            assertThat(cuerpo).contains("code.eq('CM-29939061906')").contains("version.eq(8)")
                              .contains("reversal.eq(false)").contains("\"fields\":\"id\"");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("un 204 del histórico es que no existe")
        void noExiste() {
            ohiResponde((String) null);

            StepVerifier.create(adaptador.existeVersion(CODIGO, 9)).expectNext(false).verifyComplete();
        }
    }
}
