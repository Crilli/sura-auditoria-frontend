package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.CuerpoEnviado;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace;
import co.sura.auditoria.modelo.cuenta.UbicacionMotivo;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * La resolución masiva contra un sistema de registro simulado (OPE-06, OPE-07).
 *
 * <p>Las respuestas imitan las medidas en el entorno de pruebas el 2026-10-17: el 201 con
 * {@code Location}, la actividad con su {@code status} y el 204 sin cuerpo cuando una búsqueda
 * no encuentra nada. Ningún dato identifica a una persona.
 */
@DisplayName("AdaptadorPendientesOhi — resolución masiva")
class AdaptadorResolucionMasivaOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-94421");

    /** Lo que responde el sistema de registro, por ruta y en orden. */
    private interface Respuestas { Mono<ClientResponse> para(ClientRequest peticion); }

    private final List<ClientRequest> peticiones = Collections.synchronizedList(new ArrayList<>());
    private AdaptadorPendientesOhi adaptador;
    private Respuestas respuestas;
    private final co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi agregados =
            new co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi();

    @BeforeEach
    void montar() {
        ExchangeFunction intercambio = peticion -> {
            peticiones.add(peticion);
            return respuestas.para(peticion);
        };
        var web = WebClient.builder().baseUrl("https://ohi.example/api").exchangeFunction(intercambio).build();
        var resiliencia = mock(ConfiguracionResiliencia.class);
        when(resiliencia.<Object>paraConsultaPacienteMono()).thenReturn(Function.identity());
        when(resiliencia.<Object>paraComandosMono()).thenReturn(Function.identity());
        ResolutorIdentidadOhi.BuscadorPorCodigo buscador = codigo -> Mono.just(94421L);
        adaptador = new AdaptadorPendientesOhi(web, web, resiliencia, new TraductorErrores(new ObjectMapper()),
                new TraductorPendiente(), new ResolutorIdentidadOhi(), buscador, agregados);
    }

    private static Mono<ClientResponse> json(String cuerpo) {
        return Mono.just(ClientResponse.create(HttpStatus.OK)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE).body(cuerpo).build());
    }

    private static Mono<ClientResponse> sinFilas() {
        return Mono.just(ClientResponse.create(HttpStatus.NO_CONTENT).build());
    }

    private static String actividad(String estado, String tipo) {
        return """
            {"status": "%s", "level": "GL", "type": "%s", "workId": "2214360298"}
            """.formatted(estado, tipo);
    }

    // ── Seguimiento ──────────────────────────────────────────────────────────

    @ParameterizedTest(name = "«{0}» no se pregunta al sistema de registro")
    @ValueSource(strings = {"abc", "12/../activities", "", "1234567890123456789012"})
    @Tag("OPE-06")
    void referenciaInvalida(String referencia) {
        respuestas = p -> Mono.error(new AssertionError("no debía salir ninguna petición"));

        StepVerifier.create(adaptador.consultarResolucion(CODIGO, referencia))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class))
                .verify();
        assertThat(peticiones).isEmpty();
    }

    @Test
    @Tag("OPE-06")
    @DisplayName("una operación que no es una resolución de pendientes se rechaza")
    void otraOperacion() {
        respuestas = p -> json(actividad("CO", "IMPORT_CLAIMS"));

        StepVerifier.create(adaptador.consultarResolucion(CODIGO, "2214360298"))
                .expectErrorSatisfies(e -> assertThat(((ErrorDeDominio.DecisionEnvioInvalida)
                        ((ExcepcionDeDominio) e).error()).detalle()).contains("no es una resolución de pendientes"))
                .verify();
    }

    @Test
    @Tag("OPE-06")
    @DisplayName("en proceso es EN_CURSO, con una sola lectura y sin esperar")
    void enProceso() {
        respuestas = p -> json(actividad("IP", "RESOLVE_PEND"));

        StepVerifier.create(adaptador.consultarResolucion(CODIGO, "2214360298"))
                .assertNext(r -> {
                    assertThat(r.desenlace()).isEqualTo(Desenlace.EN_CURSO);
                    assertThat(r.referencias()).containsExactly("2214360298");
                })
                .verifyComplete();
        assertThat(peticiones).singleElement()
                .satisfies(p -> assertThat(p.url().getPath()).endsWith("/activities/2214360298"));
    }

    @Test
    @Tag("OPE-06")
    @DisplayName("terminada limpia es COMPLETO")
    void completa() {
        respuestas = p -> json(actividad("CO", "RESOLVE_PEND"));

        StepVerifier.create(adaptador.consultarResolucion(CODIGO, "2214360298"))
                .assertNext(r -> assertThat(r.desenlace()).isEqualTo(Desenlace.COMPLETO))
                .verifyComplete();
    }

    @Test
    @Tag("OPE-06")
    @DisplayName("terminada con errores de negocio es PARCIAL y trae los fallos de las actividades hijas")
    void conErrores() {
        respuestas = p -> p.url().getPath().endsWith("/activitymessages/search")
                ? json("""
                    {"items": [
                      {"id": "1", "message": {"code": "ACT-FL-DAFI-001", "severity": "I", "message": "fichero"}},
                      {"id": "2", "message": {"code": "CLA-IP-RPND-004", "severity": "F",
                                              "message": "El pendiente {0} ya estaba resuelto"},
                       "value0": "MP_APOYO_ANALISTA_MOS"}]}
                    """)
                : json(actividad("CB", "RESOLVE_PEND"));

        StepVerifier.create(adaptador.consultarResolucion(CODIGO, "2214360298"))
                .assertNext(r -> {
                    assertThat(r.desenlace()).isEqualTo(Desenlace.PARCIAL);
                    assertThat(r.fallos()).singleElement().satisfies(f -> {
                        assertThat(f.codigo()).isEqualTo("CLA-IP-RPND-004");
                        assertThat(f.detalle()).isEqualTo("El pendiente MP_APOYO_ANALISTA_MOS ya estaba resuelto");
                    });
                })
                .verifyComplete();
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("al ver terminada una resolución, olvida los agregados guardados de la cuenta")
    void alTerminarInvalida() {
        var cargas = new java.util.concurrent.atomic.AtomicInteger();
        java.util.function.Supplier<Mono<String>> cargar = () -> Mono.fromCallable(() -> "v" + cargas.incrementAndGet());
        agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.MOTIVOS_PENDIENTES,
                          CODIGO, cargar).block();
        respuestas = p -> json(actividad("CO", "RESOLVE_PEND"));

        StepVerifier.create(adaptador.consultarResolucion(CODIGO, "2214360298"))
                .assertNext(r -> assertThat(r.desenlace()).isEqualTo(Desenlace.COMPLETO))
                .verifyComplete();

        agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.MOTIVOS_PENDIENTES,
                          CODIGO, cargar).block();
        assertThat(cargas).hasValue(2);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("mientras sigue en curso, lo guardado se conserva")
    void enCursoNoInvalida() {
        var cargas = new java.util.concurrent.atomic.AtomicInteger();
        java.util.function.Supplier<Mono<String>> cargar = () -> Mono.fromCallable(() -> "v" + cargas.incrementAndGet());
        agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.ACCIONES, CODIGO, cargar).block();
        respuestas = p -> json(actividad("IP", "RESOLVE_PEND"));

        adaptador.consultarResolucion(CODIGO, "2214360298").block();

        agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.ACCIONES, CODIGO, cargar).block();
        assertThat(cargas).hasValue(1);
    }

    // ── Lanzar con espera corta ──────────────────────────────────────────────

    @Test
    @Tag("OPE-06")
    @DisplayName("lanzar espera unos pocos sondeos y, si no termina, devuelve EN_CURSO con la referencia")
    void esperaCorta() {
        respuestas = p -> p.url().getPath().endsWith("/claims/resolvependreasons")
                ? Mono.just(ClientResponse.create(HttpStatus.CREATED)
                        .header("Location", "https://ohi.example/api/activities/2214360298").build())
                : json(actividad("IP", "RESOLVE_PEND"));

        StepVerifier.create(adaptador.resolverMotivos(CODIGO, Set.of("MP_CM_ANALISIS_INTEGRAL"),
                                                      NivelPendiente.CABECERA))
                .assertNext(r -> {
                    assertThat(r.desenlace()).isEqualTo(Desenlace.EN_CURSO);
                    assertThat(r.referencias()).containsExactly("2214360298");
                })
                .verifyComplete();

        // El POST y, como mucho, cuatro lecturas: la primera y tres sondeos de un segundo.
        var lecturas = peticiones.stream().filter(p -> p.url().getPath().contains("/activities/")).count();
        assertThat(lecturas).isBetween(1L, 4L);
    }

    // ── Ubicar motivos ───────────────────────────────────────────────────────

    @Test
    @Tag("OPE-07")
    @DisplayName("dos consultas de existencia por motivo, y solo salen los que la cuenta tiene")
    void ubicaLosMotivos() {
        respuestas = p -> {
            var cuerpo = CuerpoEnviado.de(p);
            var deLinea = p.url().getPath().contains("claimlinependreasons");
            if (cuerpo.contains("'MP_A'") && !deLinea) return json("{\"items\": [{\"id\": \"1\"}]}");
            if (cuerpo.contains("'MP_B'") && deLinea)  return json("{\"items\": [{\"id\": \"2\"}]}");
            return sinFilas();
        };

        StepVerifier.create(adaptador.ubicarMotivos(CODIGO, new java.util.LinkedHashSet<>(
                        List.of("MP_A", "MP_B", "MP_NINGUNO"))))
                .assertNext(mapa -> {
                    assertThat(mapa).containsOnlyKeys("MP_A", "MP_B");
                    assertThat(mapa.get("MP_A")).isEqualTo(new UbicacionMotivo("MP_A", true, false));
                    assertThat(mapa.get("MP_B")).isEqualTo(new UbicacionMotivo("MP_B", false, true));
                })
                .verifyComplete();

        assertThat(peticiones).hasSize(6);
        var cuerpos = peticiones.stream().map(CuerpoEnviado::de).toList();
        assertThat(cuerpos).allSatisfy(c -> assertThat(c).contains("resolved.eq(false)")
                                                       .contains("\"limit\":1"));
        assertThat(cuerpos).anySatisfy(c -> assertThat(c).contains("claim.id.eq(94421)"));
        assertThat(cuerpos).anySatisfy(c -> assertThat(c).contains("claimLine.claim.id.eq(94421)"));
    }

    @Test
    @Tag("OPE-07")
    @DisplayName("un código con comillas no rompe la consulta: va escapado")
    void escapaElCodigo() {
        respuestas = p -> sinFilas();

        StepVerifier.create(adaptador.ubicarMotivos(CODIGO, Set.of("X').or.id.gt(0")))
                .assertNext(mapa -> assertThat(mapa).isEmpty())
                .verifyComplete();
        assertThat(peticiones.stream().map(CuerpoEnviado::de))
                .noneSatisfy(c -> assertThat(c).contains("'X').or.id.gt(0'"));
    }

    @Test
    @Tag("OPE-07")
    @DisplayName("sin motivos no se pregunta nada")
    void sinMotivos() {
        respuestas = p -> Mono.error(new AssertionError("no debía salir ninguna petición"));

        StepVerifier.create(adaptador.ubicarMotivos(CODIGO, Set.of()))
                .assertNext(mapa -> assertThat(mapa).isEmpty()).verifyComplete();
        StepVerifier.create(adaptador.ubicarMotivos(CODIGO, null))
                .assertNext(mapa -> assertThat(mapa).isEmpty()).verifyComplete();
        assertThat(peticiones).isEmpty();
    }

    @Test
    @Tag("OPE-07")
    @DisplayName("una cuenta que no existe es CuentaNoEncontrada, no una lista vacía")
    void cuentaInexistente() {
        respuestas = p -> sinFilas();
        var web = WebClient.builder().baseUrl("https://ohi.example/api")
                .exchangeFunction(p -> respuestas.para(p)).build();
        var resiliencia = mock(ConfiguracionResiliencia.class);
        when(resiliencia.<Object>paraConsultaPacienteMono()).thenReturn(Function.identity());
        var sinCuenta = new AdaptadorPendientesOhi(web, web, resiliencia, new TraductorErrores(new ObjectMapper()),
                new TraductorPendiente(), new ResolutorIdentidadOhi(), codigo -> Mono.empty(),
                new co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi());

        StepVerifier.create(sinCuenta.ubicarMotivos(new CodigoCuenta("CM-NO-EXISTE"), Set.of("MP_A")))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.CuentaNoEncontrada.class))
                .verify();
    }

    // ── Lo guardado de la cuenta (OPE-09) ────────────────────────────────────

    /** Una cuenta sin pendientes en un estado que el diccionario conoce, o con el estado caído. */
    private Respuestas cuentaSinPendientes(boolean estadoCaido) {
        return p -> {
            var ruta = p.url().getPath();
            if (ruta.endsWith("/generic/claims/search")) {
                return estadoCaido
                        ? Mono.just(ClientResponse.create(HttpStatus.SERVICE_UNAVAILABLE).build())
                        : json("""
                            {"items": [{"id": 94421, "status": "MANUAL ADJUDICATION"}]}
                            """);
            }
            return sinFilas();
        };
    }

    private long peticionesA(String ruta) {
        return peticiones.stream().filter(p -> p.url().getPath().endsWith(ruta)).count();
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("el resumen de motivos se guarda: la segunda apertura no recorre los pendientes")
    void motivosGuardados() {
        respuestas = cuentaSinPendientes(false);

        adaptador.resumirMotivos(CODIGO).collectList().block();
        var trasLaPrimera = peticiones.size();
        adaptador.resumirMotivos(CODIGO).collectList().block();

        assertThat(trasLaPrimera).isEqualTo(3);
        assertThat(peticiones).hasSize(trasLaPrimera);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("unos motivos calculados con el estado desconocido se pintan, pero no se guardan")
    void motivosConEstadoDesconocidoNoSeGuardan() {
        respuestas = cuentaSinPendientes(true);

        StepVerifier.create(adaptador.resumirMotivos(CODIGO).collectList())
                .assertNext(motivos -> assertThat(motivos).isEmpty())
                .verifyComplete();
        adaptador.resumirMotivos(CODIGO).collectList().block();

        assertThat(peticionesA("/generic/claimpendreasons/search")).isEqualTo(2);
        assertThat(peticionesA("/generic/claims/search")).isEqualTo(2);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("invalidar la cuenta olvida también su estado, aunque el comando viviera en otro adaptador")
    void invalidarOlvidaElEstado() {
        respuestas = cuentaSinPendientes(false);
        adaptador.resumirMotivos(CODIGO).collectList().block();
        adaptador.estadoDeLaCuenta(94421L).block();
        assertThat(peticionesA("/generic/claims/search")).isEqualTo(1);

        agregados.invalidar(CODIGO);
        adaptador.estadoDeLaCuenta(94421L).block();
        assertThat(peticionesA("/generic/claims/search")).isEqualTo(2);

        agregados.invalidarTodo();
        adaptador.estadoDeLaCuenta(94421L).block();
        assertThat(peticionesA("/generic/claims/search")).isEqualTo(3);
    }
}
