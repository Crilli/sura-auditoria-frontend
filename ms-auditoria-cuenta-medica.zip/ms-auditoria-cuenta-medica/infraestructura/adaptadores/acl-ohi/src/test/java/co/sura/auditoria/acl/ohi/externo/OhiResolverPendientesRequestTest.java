package co.sura.auditoria.acl.ohi.externo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * El cuerpo de la resolución conjunta, y el detalle que decide si acota o no.
 *
 * <p>{@code claimLineList} <b>ausente</b> significa «todas las líneas aplicables». Lo dice el
 * propio contrato del sistema de registro y lo repite el javadoc del record. Así que la
 * diferencia entre acotar y no acotar es un {@code null} frente a una lista, y una lista
 * vacía caería del lado equivocado sin que nada fallara.
 */
@DisplayName("OhiResolverPendientesRequest")
class OhiResolverPendientesRequestTest {

    private static final long ID_CUENTA = 35343660784L;

    @Test
    @Tag("F2-12")
    @DisplayName("sin líneas, claimLineList va nulo: alcanza toda la cuenta")
    void sinLineasAlcanzaTodaLaCuenta() {
        var cuerpo = OhiResolverPendientesRequest.deCuentaCompleta(
                ID_CUENTA, Set.of("MP_EVALUAR_UEN"), "claim line");

        assertThat(cuerpo.claimList()).singleElement()
                .satisfies(cuenta -> {
                    assertThat(cuenta.id()).isEqualTo("35343660784");
                    assertThat(cuenta.claimLineList()).isNull();
                });
    }

    @Test
    @Tag("F2-12")
    @DisplayName("con líneas, viajan sus identificadores y solo esos")
    void conLineasViajanSusIdentificadores() {
        var cuerpo = OhiResolverPendientesRequest.deLineas(
                ID_CUENTA, Set.of("MP_EVALUAR_UEN"), "claim line", List.of(46_000_000_001L, 46_000_000_002L));

        assertThat(cuerpo.claimList()).singleElement()
                .satisfies(cuenta -> assertThat(cuenta.claimLineList())
                        .extracting(OhiResolverPendientesRequest.ReferenciaLinea::id)
                        .containsExactly("46000000001", "46000000002"));
    }

    @Test
    @Tag("F2-12")
    @DisplayName("una lista vacía NO viaja vacía: viaja nula, que es lo que el contrato entiende")
    void unaListaVaciaNoViajaVacia() {
        // Si viajara vacía, el sistema de registro la leería como «sin acotar» y resolvería
        // en toda la cuenta. El error sería silencioso y del peor tipo: un 200 que hizo más
        // de lo que se pidió, y la resolución no se deshace.
        var cuerpo = OhiResolverPendientesRequest.deLineas(
                ID_CUENTA, Set.of("MP_EVALUAR_UEN"), "claim line", List.of());

        assertThat(cuerpo.claimList().get(0).claimLineList()).isNull();
    }

    @Test
    @Tag("F2-12")
    @DisplayName("los motivos viajan por código, no por identificador")
    void losMotivosViajanPorCodigo() {
        var cuerpo = OhiResolverPendientesRequest.deLineas(
                ID_CUENTA, List.of("MP_EVALUAR_UEN", "MP_FATAL_SIN_GLOSA"), "claim line", null);

        assertThat(cuerpo.pendReasonCodeList())
                .extracting(OhiResolverPendientesRequest.CodigoMotivo::code)
                .containsExactly("MP_EVALUAR_UEN", "MP_FATAL_SIN_GLOSA");
        assertThat(cuerpo.level()).isEqualTo("claim line");
    }
}
