package co.sura.auditoria.acl.ohi.cliente;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Duration;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("PropiedadesOhi")
class PropiedadesOhiTest {

    private static final String URL = "https://prod.sura.ohi.ocs.oraclecloud.com/prod/claims/api";
    private static final String TOKEN_URL = "https://idcs.identity.oraclecloud.com/oauth2/v1/token/";

    private static PropiedadesOhi.Timeouts timeouts() {
        return new PropiedadesOhi.Timeouts(Duration.ofSeconds(5), Duration.ofSeconds(30),
                Duration.ofSeconds(30), null);
    }

    private static PropiedadesOhi completas() {
        return new PropiedadesOhi(URL, TOKEN_URL, "cliente", "secreto", "scope", timeouts());
    }

    @Test
    @DisplayName("con todas las propiedades se construye sin quejarse")
    void conTodasSeConstruye() {
        assertThatCode(PropiedadesOhiTest::completas).doesNotThrowAnyException();
    }

    @Nested
    @DisplayName("propiedades obligatorias")
    class Obligatorias {

        @ParameterizedTest(name = "falta url-base [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        @DisplayName("sin url-base no arranca")
        void sinUrlBaseNoArranca(String vacio) {
            assertThatThrownBy(() -> new PropiedadesOhi(vacio, TOKEN_URL, "c", "s", "sc",
                    timeouts()))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("integraciones.ohi.url-base");
        }

        @ParameterizedTest(name = "falta {0}")
        @CsvSource({
                "integraciones.ohi.token-url",
                "integraciones.ohi.client-id",
                "integraciones.ohi.client-secret",
                "integraciones.ohi.scope"
        })
        @DisplayName("el mensaje nombra exactamente la propiedad que falta")
        void elMensajeNombraLaPropiedadQueFalta(String propiedad) {
            var sinTokenUrl = propiedad.endsWith("token-url");
            var sinClientId = propiedad.endsWith("client-id");
            var sinSecret = propiedad.endsWith("client-secret");
            var sinScope = propiedad.endsWith("scope");

            assertThatThrownBy(() -> new PropiedadesOhi(URL,
                    sinTokenUrl ? null : TOKEN_URL,
                    sinClientId ? null : "c",
                    sinSecret ? null : "s",
                    sinScope ? null : "sc",
                    timeouts()))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining(propiedad);
        }
    }

    @Nested
    @DisplayName("marcadores sin resolver")
    class MarcadoresSinResolver {

        @Test
        @DisplayName("un ${VAR} sin resolver se rechaza: si no, viajaría como contraseña")
        void unMarcadorSinResolverSeRechaza() {
            // El binder de @ConfigurationProperties resuelve con
            // ignoreUnresolvablePlaceholders=true, así que una variable ausente deja
            // el literal y el fallo saldría tarde, como un 401 de IDCS.
            assertThatThrownBy(() -> new PropiedadesOhi(URL, TOKEN_URL, "c",
                    "${OHI_CLIENT_SECRET_PROD}", "sc", timeouts()))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("quedó sin resolver");
        }

        @Test
        @DisplayName("el mensaje dice qué variable de entorno exportar")
        void elMensajeDiceQueVariableExportar() {
            assertThatThrownBy(() -> new PropiedadesOhi(URL, TOKEN_URL, "c",
                    "${OHI_CLIENT_SECRET_PROD}", "sc", timeouts()))
                    .hasMessageContaining("OHI_CLIENT_SECRET_PROD");
        }

        @Test
        @DisplayName("con valor por omisión, la variable a exportar se nombra sin el default")
        void conValorPorOmisionNombraSoloLaVariable() {
            // El mensaje repite el marcador entero para que se vea qué llegó, pero
            // la variable que manda exportar es solo la parte anterior a los dos puntos.
            assertThatThrownBy(() -> new PropiedadesOhi(URL, TOKEN_URL, "c",
                    "${OHI_SECRET:unDefault}", "sc", timeouts()))
                    .hasMessageContaining("variable de entorno OHI_SECRET ")
                    .hasMessageNotContaining("variable de entorno OHI_SECRET:unDefault");
        }

        @Test
        @DisplayName("un valor que solo CONTIENE ${...} pero no empieza así, se acepta")
        void unValorQueSoloContieneElMarcadorSeAcepta() {
            // La comprobación es de marcador completo, no de subcadena: una contraseña
            // legítima puede contener llaves.
            assertThatCode(() -> new PropiedadesOhi(URL, TOKEN_URL, "c", "pre${X}post", "sc",
                    timeouts())).doesNotThrowAnyException();
        }
    }

    @Nested
    @DisplayName("timeouts")
    class Timeouts {

        @Test
        @DisplayName("el de resolución de pendiente cae a 25 s cuando no se configura")
        void elDeResolucionCaeA25Segundos() {
            var sinResolucion = new PropiedadesOhi.Timeouts(Duration.ofSeconds(5),
                    Duration.ofSeconds(30), Duration.ofSeconds(30), null);

            assertThat(sinResolucion.resolucionPendiente()).isEqualTo(Duration.ofSeconds(25));
        }

        @Test
        @DisplayName("un valor configurado se respeta")
        void unValorConfiguradoSeRespeta() {
            var configurado = new PropiedadesOhi.Timeouts(Duration.ofSeconds(5),
                    Duration.ofSeconds(30), Duration.ofSeconds(30), Duration.ofSeconds(90));

            assertThat(configurado.resolucionPendiente()).isEqualTo(Duration.ofSeconds(90));
        }
    }

    @Test
    @DisplayName("ya no está acotada por perfil: desde que no hay simulador, siempre aplica")
    void yaNoEstaAcotadaPorPerfil() {
        // Llevaba @Profile("!local") para que el simulador la sustituyera. Retirado
        // el simulador, acotarla dejaría la configuración de OHI sin enlazar en algún
        // perfil, y el fallo saldría tarde, como un 401 de IDCS.
        assertThat(PropiedadesOhi.class.getAnnotation(
                org.springframework.context.annotation.Profile.class)).isNull();
    }
}
