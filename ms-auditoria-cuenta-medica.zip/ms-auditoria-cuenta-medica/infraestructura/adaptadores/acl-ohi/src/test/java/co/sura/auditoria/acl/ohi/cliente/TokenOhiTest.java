package co.sura.auditoria.acl.ohi.cliente;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("Token de OHI")
class TokenOhiTest {

    private static final String TOKEN_URL =
            "https://idcs-fc4a28e7.identity.oraclecloud.com/oauth2/v1/token/";

    @Mock ExchangeFunction intercambio;
    @Captor ArgumentCaptor<ClientRequest> peticionCaptor;

    private static PropiedadesOhi propiedades() {
        return new PropiedadesOhi("https://ohi.example/api", TOKEN_URL,
                "d29d344485ea49f9b50b0c42cb4cd708", "elSecreto",
                "https://ohi.example/urn::ohi-components-apis",
                new PropiedadesOhi.Timeouts(Duration.ofSeconds(5), Duration.ofSeconds(30),
                        Duration.ofSeconds(30), null));
    }

    private ProveedorTokenOhi proveedor() {
        var builder = WebClient.builder().exchangeFunction(intercambio);
        return new ProveedorTokenOhi(builder, propiedades());
    }

    private void idcsResponde(String cuerpoJson) {
        when(intercambio.exchange(any())).thenReturn(Mono.just(
                ClientResponse.create(HttpStatus.OK)
                        .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                        .body(cuerpoJson)
                        .build()));
    }

    @Nested
    @DisplayName("ProveedorTokenOhi")
    class Proveedor {

        @Test
        @DisplayName("devuelve el access_token del cuerpo que entrega IDCS")
        void devuelveElAccessToken() {
            idcsResponde("""
                         {"access_token":"eyJhbGc.ABC","token_type":"Bearer","expires_in":3600}
                         """);

            StepVerifier.create(proveedor().obtenerToken())
                    .expectNext("eyJhbGc.ABC")
                    .verifyComplete();
        }

        @Test
        @DisplayName("se autentica con Basic, que es lo que IDCS espera; el secreto no va en el cuerpo")
        void seAutenticaConBasic() {
            idcsResponde("{\"access_token\":\"t\",\"token_type\":\"Bearer\",\"expires_in\":3600}");

            StepVerifier.create(proveedor().obtenerToken()).expectNextCount(1).verifyComplete();

            verify(intercambio).exchange(peticionCaptor.capture());
            var esperado = "Basic " + Base64.getEncoder().encodeToString(
                    "d29d344485ea49f9b50b0c42cb4cd708:elSecreto".getBytes(StandardCharsets.UTF_8));
            assertThat(peticionCaptor.getValue().headers().getFirst(HttpHeaders.AUTHORIZATION))
                    .isEqualTo(esperado);
        }

        @Test
        @DisplayName("la petición va como formulario, no como JSON")
        void laPeticionVaComoFormulario() {
            idcsResponde("{\"access_token\":\"t\",\"token_type\":\"Bearer\",\"expires_in\":3600}");

            StepVerifier.create(proveedor().obtenerToken()).expectNextCount(1).verifyComplete();

            verify(intercambio).exchange(peticionCaptor.capture());
            assertThat(peticionCaptor.getValue().headers().getContentType())
                    .isEqualTo(MediaType.APPLICATION_FORM_URLENCODED);
            assertThat(peticionCaptor.getValue().method().name()).isEqualTo("POST");
        }

        @Test
        @DisplayName("apunta a la URL de token configurada, no a la base de OHI")
        void apuntaALaUrlDeToken() {
            idcsResponde("{\"access_token\":\"t\",\"token_type\":\"Bearer\",\"expires_in\":3600}");

            StepVerifier.create(proveedor().obtenerToken()).expectNextCount(1).verifyComplete();

            verify(intercambio).exchange(peticionCaptor.capture());
            assertThat(peticionCaptor.getValue().url().toString()).isEqualTo(TOKEN_URL);
        }

        @Test
        @DisplayName("un fallo de IDCS se propaga: sin token no hay nada que hacer")
        void unFalloDeIdcsSePropaga() {
            when(intercambio.exchange(any())).thenReturn(Mono.just(
                    ClientResponse.create(HttpStatus.UNAUTHORIZED).body("{}").build()));

            StepVerifier.create(proveedor().obtenerToken())
                    .expectError()
                    .verify();
        }

        @Test
        @DisplayName("el cuerpo de IDCS se deserializa con sus tres campos")
        void elCuerpoSeDeserializaEntero() {
            var respuesta = new ProveedorTokenOhi.TokenResponse("abc", "Bearer", 3600);

            assertThat(respuesta.access_token()).isEqualTo("abc");
            assertThat(respuesta.token_type()).isEqualTo("Bearer");
            assertThat(respuesta.expires_in()).isEqualTo(3600);
        }
    }

    @Nested
    @DisplayName("ConfiguracionCacheToken")
    class CacheDelToken {

        @Test
        @DisplayName("crea la caché con el nombre que anota el proveedor")
        void creaLaCacheConElNombreQueAnotaElProveedor() {
            var gestor = new ConfiguracionCacheToken().cacheManager(Duration.ofMinutes(50));

            assertThat(gestor.getCache(ConfiguracionCacheToken.CACHE_TOKEN)).isNotNull();
            assertThat(ConfiguracionCacheToken.CACHE_TOKEN).isEqualTo("tokenOhi");
        }

        @Test
        @DisplayName("va en modo asíncrono, imprescindible para cachear un Mono")
        void vaEnModoAsincrono() {
            // Sin asyncCacheMode, Spring guardaría el Mono sin suscribir y cada lector
            // recibiría un publicador ya consumido. Se comprueba por contraste con un
            // gestor corriente: en modo asíncrono Caffeine entrega la vista síncrona de
            // una caché asíncrona, que es una implementación distinta de la normal.
            var delProyecto = new ConfiguracionCacheToken().cacheManager(Duration.ofMinutes(50))
                    .getCache(ConfiguracionCacheToken.CACHE_TOKEN).getNativeCache();
            var corriente = new CaffeineCacheManager(ConfiguracionCacheToken.CACHE_TOKEN)
                    .getCache(ConfiguracionCacheToken.CACHE_TOKEN).getNativeCache();

            assertThat(delProyecto.getClass()).isNotEqualTo(corriente.getClass());
            assertThat(delProyecto.getClass().getName()).contains("Async");
        }

        @Test
        @DisplayName("la expiración configurada se respeta")
        void laExpiracionSeRespeta() {
            assertThat(new ConfiguracionCacheToken().cacheManager(Duration.ofMinutes(10)))
                    .isNotNull();
        }
    }
}
