package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.acl.ohi.traductor.TraductorNovedad;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.CambioGlosa;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EdicionLinea;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * Los comandos contra el sistema de registro (OPE-11, OPE-09). Ningún dato identifica a una
 * persona.
 */
@DisplayName("AdaptadorComandosOhi")
class AdaptadorComandosOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-94421");
    private static final ReferenciaLinea LINEA = new ReferenciaLinea(135280L);

    /** Qué cliente recibió cada petición: «general» o «paciente». */
    private final List<String> salidas = Collections.synchronizedList(new ArrayList<>());
    /** Las peticiones tal como salieron, para poder leer el cuerpo con {@code CuerpoEnviado}. */
    private final List<org.springframework.web.reactive.function.client.ClientRequest> peticiones =
            Collections.synchronizedList(new ArrayList<>());
    private HttpStatus respuestaDeOhi = HttpStatus.OK;

    private final PuertoConsultaCuentas consultas = mock(PuertoConsultaCuentas.class);
    private final CacheDeAgregadosOhi agregados = new CacheDeAgregadosOhi();
    private AdaptadorComandosOhi adaptador;

    private WebClient cliente(String nombre) {
        return WebClient.builder().baseUrl("https://ohi.example/api")
                .exchangeFunction(peticion -> {
                    salidas.add(nombre);
                    peticiones.add(peticion);
                    return Mono.just(ClientResponse.create(respuestaDeOhi)
                            .header("Content-Type", MediaType.APPLICATION_JSON_VALUE).body("{}").build());
                }).build();
    }

    @BeforeEach
    void montar() {
        var resiliencia = mock(ConfiguracionResiliencia.class);
        when(resiliencia.<Object>paraComandosMono()).thenReturn(Function.identity());
        when(resiliencia.<Object>paraEnvioMono()).thenReturn(Function.identity());
        ResolutorIdentidadOhi.BuscadorPorCodigo buscador = codigo -> Mono.just(94421L);
        adaptador = new AdaptadorComandosOhi(cliente("general"), cliente("paciente"), resiliencia,
                new TraductorErrores(new ObjectMapper()),
                new TraductorLinea(new TraductorNovedad(), new TraductorPendiente()),
                new ResolutorIdentidadOhi(), consultas, buscador, agregados);
    }

    private static EdicionLinea edicion(ModoRecalculo modo) {
        return EdicionLinea.soloCambiosDeColeccion(LINEA, new Version(3L),
                List.of(CambioGlosa.agregar("TAR01", "G", "E", new BigDecimal("1500"), "texto")),
                List.of(), modo);
    }

    /**
     * El valor convenido escribe allowedAmount, y el autorizado no viaja.
     *
     * <p>Es la prueba que faltaba para que un cruce se notara: hasta el 2026-10-21 el campo del
     * comando que escribía allowedAmount se llamaba «valorAutorizado», y ese nombre pasó ese día
     * a significar coveredAmount. Si alguien reconectara el nombre nuevo al campo de OHI viejo
     * —o al revés—, todas las demás pruebas seguirían en verde. Cifras distintas en cada importe
     * (cargado 1000, convenido 900) para que un intercambio no pase.
     *
     * <p>También contesta la mitad «valor convenido» de BUS-F1-10 —sí se escribe desde la
     * aplicación—; la otra mitad, la UEN, sigue sin escribirse y no tiene prueba que la afirme.
     */
    @Test
    @Tag("GRID-18")
    @Tag("LIN-07")
    @Tag("LIN-08")
    @Tag("BUS-F1-10")
    @DisplayName("[GRID-18][LIN-07][BUS-F1-10] el PATCH lleva el valor convenido en allowedAmount y nada de coveredAmount")
    void elPatchEscribeElConvenidoEnAllowedAmount() throws Exception {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.just(mock(LineaCuenta.class)));
        var edicion = new EdicionLinea(LINEA, new Version(3L),
                java.util.Optional.of(new BigDecimal("900")),   // valorConvenido
                java.util.Optional.of(new BigDecimal("2")),     // unidadesConvenidas
                java.util.Optional.empty(), java.util.Optional.empty(), java.util.Optional.empty(),
                java.util.Optional.of(new BigDecimal("1000")),  // valorCargado
                java.util.Optional.of(new BigDecimal("3")),     // unidadesCargadas
                java.util.Optional.empty(), java.util.Optional.empty(), java.util.Optional.empty(),
                java.util.Optional.empty(), java.util.Optional.empty(), java.util.Optional.empty(),
                java.util.Optional.empty(), java.util.Optional.empty(), java.util.Optional.empty(),
                java.util.Optional.empty(), java.util.Optional.empty(),
                List.of(), List.of(), ModoRecalculo.AISLADO);

        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion)).block();

        assertThat(peticiones).singleElement().satisfies(p ->
                assertThat(p.method().name()).isEqualTo("PATCH"));
        var cuerpo = co.sura.auditoria.acl.ohi.CuerpoEnviado.de(peticiones.get(0));
        var linea = new ObjectMapper().readTree(cuerpo).path("claimLineList").get(0);
        assertThat(linea.path("allowedAmount").path("value").decimalValue())
                .isEqualByComparingTo("900");
        assertThat(linea.path("allowedAmount").path("currency").asText()).isEqualTo("COP");
        assertThat(linea.path("allowedNumberOfUnits").decimalValue()).isEqualByComparingTo("2");
        assertThat(linea.path("claimedAmount").path("value").decimalValue())
                .isEqualByComparingTo("1000");
        assertThat(linea.path("claimedNumberOfUnits").decimalValue()).isEqualByComparingTo("3");
        // El autorizado lo calcula el motor: ni el importe ni la cantidad pueden salir.
        assertThat(cuerpo).doesNotContain("coveredAmount").doesNotContain("coveredNumberOfUnits");
    }

    private static ExcepcionDeDominio caida() {
        return ExcepcionDeDominio.de(new ErrorDeDominio.SistemaRegistroNoDisponible("corte"));
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("el guardado en cascada va por el cliente de operaciones largas; el aislado, por el general")
    void clienteSegunElModo() {
        var linea = mock(LineaCuenta.class);
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.just(linea));

        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion(ModoRecalculo.EN_CASCADA))).block();
        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion(ModoRecalculo.AISLADO))).block();

        assertThat(salidas).containsExactly("paciente", "general");
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("las acciones van por el cliente de operaciones largas")
    void accionesPorElPaciente() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(mock(CuentaMedica.class)));

        adaptador.ejecutarAccion(CODIGO, EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION)).block();

        assertThat(salidas).containsExactly("paciente");
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("si la relectura falla una vez por un corte, se reintenta y el auditor recibe la línea")
    void relecturaReintentada() {
        var linea = mock(LineaCuenta.class);
        when(consultas.buscarDetalleLinea(CODIGO, LINEA))
                .thenReturn(Mono.error(caida()))
                .thenReturn(Mono.just(linea));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectNext(linea).verifyComplete();
        verify(consultas, times(2)).buscarDetalleLinea(CODIGO, LINEA);
        // El PATCH salió una sola vez: lo que se repite es la lectura, no la escritura.
        assertThat(salidas).hasSize(1);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("si la relectura sigue fallando, el error dice que el cambio se aplicó")
    void aplicadoSinRelectura() {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.error(caida()));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> {
                    var error = ((ExcepcionDeDominio) e).error();
                    assertThat(error).isInstanceOf(ErrorDeDominio.AplicadoSinRelectura.class);
                    assertThat(((ErrorDeDominio.AplicadoSinRelectura) error).recurso()).isEqualTo("linea:135280");
                })
                .verify();
        assertThat(salidas).hasSize(1);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("un error del propio comando sale tal cual: no se disfraza de «aplicado»")
    void errorDelComandoTalCual() {
        respuestaDeOhi = HttpStatus.CONFLICT;

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.ModificacionConcurrente.class))
                .verify();
        verify(consultas, times(0)).buscarDetalleLinea(any(), any());
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("un comando invalida lo guardado de la cuenta, aunque haya fallado")
    void comandoInvalida() {
        var cargas = new java.util.concurrent.atomic.AtomicInteger();
        java.util.function.Supplier<Mono<String>> cargar = () -> Mono.fromCallable(() -> "v" + cargas.incrementAndGet());
        agregados.obtener(CacheDeAgregadosOhi.Agregado.ACCIONES, CODIGO, cargar).block();
        respuestaDeOhi = HttpStatus.CONFLICT;

        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion(ModoRecalculo.AISLADO)))
                .onErrorResume(e -> Mono.empty()).block();

        agregados.obtener(CacheDeAgregadosOhi.Agregado.ACCIONES, CODIGO, cargar).block();
        assertThat(cargas).hasValue(2);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("una relectura que no encuentra la línea tampoco dice que el cambio no se aplicara")
    void relecturaVacia() {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.empty());

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.AplicadoSinRelectura.class))
                .verify();
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("una relectura rechazada por exceso de peticiones no se repite: no es un corte")
    void relecturaConExcesoNoSeRepite() {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.error(
                new co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi(
                        new ErrorDeDominio.SistemaRegistroNoDisponible("demasiadas peticiones"), 429)));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.AplicadoSinRelectura.class))
                .verify();
        verify(consultas, times(1)).buscarDetalleLinea(CODIGO, LINEA);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("una relectura con un 5xx del sistema de registro sí se repite")
    void relecturaCon5xxSeRepite() {
        var linea = mock(LineaCuenta.class);
        when(consultas.buscarDetalleLinea(CODIGO, LINEA))
                .thenReturn(Mono.error(new co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi(
                        new ErrorDeDominio.SistemaRegistroNoDisponible("502"), 502)))
                .thenReturn(Mono.just(linea));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectNext(linea).verifyComplete();
    }
}
