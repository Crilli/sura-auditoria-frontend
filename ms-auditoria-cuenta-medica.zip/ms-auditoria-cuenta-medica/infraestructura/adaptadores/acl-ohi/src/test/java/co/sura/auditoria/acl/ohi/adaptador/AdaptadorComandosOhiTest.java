package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.acl.ohi.traductor.TraductorNovedad;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.CambioGlosa;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EdicionLinea;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * Los comandos contra el sistema de registro (OPE-11, OPE-09). Ningún dato identifica a una
 * persona.
 */
@DisplayName("AdaptadorComandosOhi")
class AdaptadorComandosOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-94421");
    private static final ReferenciaLinea LINEA = new ReferenciaLinea(135280L);

    /** Qué cliente recibió cada petición: «general» o «paciente». */
    private final List<String> salidas = Collections.synchronizedList(new ArrayList<>());
    private HttpStatus respuestaDeOhi = HttpStatus.OK;

    private final PuertoConsultaCuentas consultas = mock(PuertoConsultaCuentas.class);
    private final CacheDeAgregadosOhi agregados = new CacheDeAgregadosOhi();
    private AdaptadorComandosOhi adaptador;

    private WebClient cliente(String nombre) {
        return WebClient.builder().baseUrl("https://ohi.example/api")
                .exchangeFunction(peticion -> {
                    salidas.add(nombre);
                    return Mono.just(ClientResponse.create(respuestaDeOhi)
                            .header("Content-Type", MediaType.APPLICATION_JSON_VALUE).body("{}").build());
                }).build();
    }

    @BeforeEach
    void montar() {
        var resiliencia = mock(ConfiguracionResiliencia.class);
        when(resiliencia.<Object>paraComandosMono()).thenReturn(Function.identity());
        when(resiliencia.<Object>paraEnvioMono()).thenReturn(Function.identity());
        ResolutorIdentidadOhi.BuscadorPorCodigo buscador = codigo -> Mono.just(94421L);
        adaptador = new AdaptadorComandosOhi(cliente("general"), cliente("paciente"), resiliencia,
                new TraductorErrores(new ObjectMapper()),
                new TraductorLinea(new TraductorNovedad(), new TraductorPendiente()),
                new ResolutorIdentidadOhi(), consultas, buscador, agregados);
    }

    private static EdicionLinea edicion(ModoRecalculo modo) {
        return EdicionLinea.soloCambiosDeColeccion(LINEA, new Version(3L),
                List.of(CambioGlosa.agregar("TAR01", "G", "E", new BigDecimal("1500"), "texto")),
                List.of(), modo);
    }

    private static ExcepcionDeDominio caida() {
        return ExcepcionDeDominio.de(new ErrorDeDominio.SistemaRegistroNoDisponible("corte"));
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("el guardado en cascada va por el cliente de operaciones largas; el aislado, por el general")
    void clienteSegunElModo() {
        var linea = mock(LineaCuenta.class);
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.just(linea));

        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion(ModoRecalculo.EN_CASCADA))).block();
        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion(ModoRecalculo.AISLADO))).block();

        assertThat(salidas).containsExactly("paciente", "general");
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("las acciones van por el cliente de operaciones largas")
    void accionesPorElPaciente() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(mock(CuentaMedica.class)));

        adaptador.ejecutarAccion(CODIGO, EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION)).block();

        assertThat(salidas).containsExactly("paciente");
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("si la relectura falla una vez por un corte, se reintenta y el auditor recibe la línea")
    void relecturaReintentada() {
        var linea = mock(LineaCuenta.class);
        when(consultas.buscarDetalleLinea(CODIGO, LINEA))
                .thenReturn(Mono.error(caida()))
                .thenReturn(Mono.just(linea));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectNext(linea).verifyComplete();
        verify(consultas, times(2)).buscarDetalleLinea(CODIGO, LINEA);
        // El PATCH salió una sola vez: lo que se repite es la lectura, no la escritura.
        assertThat(salidas).hasSize(1);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("si la relectura sigue fallando, el error dice que el cambio se aplicó")
    void aplicadoSinRelectura() {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.error(caida()));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> {
                    var error = ((ExcepcionDeDominio) e).error();
                    assertThat(error).isInstanceOf(ErrorDeDominio.AplicadoSinRelectura.class);
                    assertThat(((ErrorDeDominio.AplicadoSinRelectura) error).recurso()).isEqualTo("linea:135280");
                })
                .verify();
        assertThat(salidas).hasSize(1);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("un error del propio comando sale tal cual: no se disfraza de «aplicado»")
    void errorDelComandoTalCual() {
        respuestaDeOhi = HttpStatus.CONFLICT;

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.ModificacionConcurrente.class))
                .verify();
        verify(consultas, times(0)).buscarDetalleLinea(any(), any());
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("un comando invalida lo guardado de la cuenta, aunque haya fallado")
    void comandoInvalida() {
        var cargas = new java.util.concurrent.atomic.AtomicInteger();
        java.util.function.Supplier<Mono<String>> cargar = () -> Mono.fromCallable(() -> "v" + cargas.incrementAndGet());
        agregados.obtener(CacheDeAgregadosOhi.Agregado.ACCIONES, CODIGO, cargar).block();
        respuestaDeOhi = HttpStatus.CONFLICT;

        adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L), List.of(edicion(ModoRecalculo.AISLADO)))
                .onErrorResume(e -> Mono.empty()).block();

        agregados.obtener(CacheDeAgregadosOhi.Agregado.ACCIONES, CODIGO, cargar).block();
        assertThat(cargas).hasValue(2);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("una relectura que no encuentra la línea tampoco dice que el cambio no se aplicara")
    void relecturaVacia() {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.empty());

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.AplicadoSinRelectura.class))
                .verify();
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("una relectura rechazada por exceso de peticiones no se repite: no es un corte")
    void relecturaConExcesoNoSeRepite() {
        when(consultas.buscarDetalleLinea(CODIGO, LINEA)).thenReturn(Mono.error(
                new co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi(
                        new ErrorDeDominio.SistemaRegistroNoDisponible("demasiadas peticiones"), 429)));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                        .isInstanceOf(ErrorDeDominio.AplicadoSinRelectura.class))
                .verify();
        verify(consultas, times(1)).buscarDetalleLinea(CODIGO, LINEA);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("una relectura con un 5xx del sistema de registro sí se repite")
    void relecturaCon5xxSeRepite() {
        var linea = mock(LineaCuenta.class);
        when(consultas.buscarDetalleLinea(CODIGO, LINEA))
                .thenReturn(Mono.error(new co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi(
                        new ErrorDeDominio.SistemaRegistroNoDisponible("502"), 502)))
                .thenReturn(Mono.just(linea));

        StepVerifier.create(adaptador.aplicarEdicionesDeLinea(CODIGO, new Version(26L),
                        List.of(edicion(ModoRecalculo.AISLADO))))
                .expectNext(linea).verifyComplete();
    }
}
