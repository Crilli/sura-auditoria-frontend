package co.sura.auditoria.acl.ohi.consulta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

@DisplayName("SolicitudBusqueda")
class SolicitudBusquedaTest {

    @Nested
    @DisplayName("defaultoverride")
    class DefaultOverride {

        @Test
        @DisplayName("toda búsqueda proyectada lo lleva en true, o OHI ignora fields")
        void todaBusquedaProyectadaLoLleva() {
            // Sin defaultoverride, OHI devuelve la representación por defecto y
            // campos como numeroFactura llegan nulos aunque tengan valor.
            assertThat(SolicitudBusqueda.de("code.eq('CM-1')", "id,code", "id", 50, true)
                    .resourceRepresentation().defaultoverride()).isEqualTo("true");
            assertThat(SolicitudBusqueda.unica("code.eq('CM-1')", "id")
                    .resourceRepresentation().defaultoverride()).isEqualTo("true");
            assertThat(SolicitudBusqueda.cabecera("code.eq('CM-1')", "id")
                    .resourceRepresentation().defaultoverride()).isEqualTo("true");
        }

        @Test
        @DisplayName("la búsqueda de solo enlaces NO lo lleva: ahí sí se quiere la representación por defecto")
        void laDeSoloEnlacesNoLoLleva() {
            var soloEnlaces = SolicitudBusqueda.soloEnlaces("code.eq('CM-1')");

            assertThat(soloEnlaces.resourceRepresentation().defaultoverride()).isNull();
            assertThat(soloEnlaces.resourceRepresentation().excludereferenceresources())
                    .isEqualTo("true");
        }
    }

    @Nested
    @DisplayName("proyección")
    class Proyeccion {

        @Test
        @DisplayName("los campos se separan con barra vertical, no con coma")
        void losCamposSeSeparanConBarra() {
            assertThat(SolicitudBusqueda.de("q", "id,code,numeroFactura", null, 10, false)
                    .resourceRepresentation().fields())
                    .isEqualTo("id|code|numeroFactura");
        }

        @Test
        @DisplayName("un solo campo viaja tal cual")
        void unSoloCampoViajaTalCual() {
            assertThat(SolicitudBusqueda.de("q", "id", null, 10, false)
                    .resourceRepresentation().fields()).isEqualTo("id");
        }

        @Test
        @DisplayName("sin campos, la proyección va nula y no como cadena vacía")
        void sinCamposLaProyeccionVaNula() {
            assertThat(SolicitudBusqueda.de("q", null, null, 10, false)
                    .resourceRepresentation().fields()).isNull();
        }
    }

    @Nested
    @DisplayName("límite de 200")
    class LimiteDe200 {

        @ParameterizedTest(name = "{0} se limita a {1}")
        @CsvSource({
                "1,    1",
                "50,   50",
                "199,  199",
                "200,  200",
                "201,  200",
                "5000, 200"
        })
        @DisplayName("nunca se pide por encima del tope que OHI trunca en silencio")
        void nuncaPorEncimaDelTope(int deseado, int esperado) {
            assertThat(SolicitudBusqueda.limitarAlMaximo(deseado)).isEqualTo(esperado);
        }

        @ParameterizedTest(name = "{0} sube a 1")
        @CsvSource({"0, 1", "-1, 1", "-100, 1"})
        @DisplayName("cero y negativos suben a 1: pedir cero filas no tiene sentido")
        void ceroYNegativosSubenAUno(int deseado, int esperado) {
            assertThat(SolicitudBusqueda.limitarAlMaximo(deseado)).isEqualTo(esperado);
        }

        @Test
        @DisplayName("el tope documentado es 200")
        void elTopeDocumentadoEs200() {
            assertThat(SolicitudBusqueda.LIMITE_MAXIMO).isEqualTo(200);
        }
    }

    @Nested
    @DisplayName("desplazamiento")
    class Desplazamiento {

        @Test
        @DisplayName("desplazada() pone el offset en resource, junto al límite y al total")
        void desplazadaPoneElOffsetEnResource() {
            var solicitud = SolicitudBusqueda.desplazada(
                    "claim.id.eq(35343660784)", "id,sequence", "sequence asc", 4025, 25, true);

            assertThat(solicitud.resource().offset()).isEqualTo(4025);
            assertThat(solicitud.resource().limit()).isEqualTo(25);
            assertThat(solicitud.resource().totalResults()).isTrue();
            assertThat(solicitud.resource().orderBy()).isEqualTo("sequence asc");
        }

        @Test
        @DisplayName("el desplazamiento no se recorta por el tope de 200: ese tope es del límite")
        void elDesplazamientoNoSeRecorta() {
            // Comprobado contra el sistema de registro: offset=4025 sobre una
            // cuenta de 4.063 líneas devuelve sus filas, y el total que acompaña
            // es el verdadero. Recortarlo aquí dejaría inalcanzable la última
            // página de cualquier cuenta grande.
            var solicitud = SolicitudBusqueda.desplazada("q", "id", "sequence asc",
                    100_000, 25, true);

            assertThat(solicitud.resource().offset()).isEqualTo(100_000);
        }

        @Test
        @DisplayName("una búsqueda sin desplazamiento lo deja nulo, y así no viaja en el cuerpo")
        void unaBusquedaSinDesplazamientoLoDejaNulo() {
            assertThat(SolicitudBusqueda.de("q", "id", null, 10, false).resource().offset())
                    .isNull();
            assertThat(SolicitudBusqueda.unica("q", "id").resource().offset()).isNull();
            assertThat(SolicitudBusqueda.cabecera("q", "id").resource().offset()).isNull();
            assertThat(SolicitudBusqueda.soloEnlaces("q").resource().offset()).isNull();
        }

        @Test
        @DisplayName("los nulos del sobre no se serializan")
        void losNulosDelSobreNoSeSerializan() throws Exception {
            // Es lo que impide que, por haber añadido offset al sobre, todas las
            // búsquedas del servicio empiecen a mandar "offset": null.
            var json = new com.fasterxml.jackson.databind.ObjectMapper()
                    .writeValueAsString(SolicitudBusqueda.unica("code.eq('CM-1')", "id"));

            assertThat(json).doesNotContain("null");
            assertThat(json).contains("\"q\":\"code.eq('CM-1')\"");
        }

        @Test
        @DisplayName("un desplazamiento de cero sí se serializa: es una posición, no una ausencia")
        void unDesplazamientoDeCeroSiSeSerializa() throws Exception {
            var json = new com.fasterxml.jackson.databind.ObjectMapper()
                    .writeValueAsString(SolicitudBusqueda.desplazada("q", "id", "sequence asc",
                            0, 25, true));

            assertThat(json).contains("\"offset\":0");
        }
    }

    @Nested
    @DisplayName("formas de búsqueda")
    class FormasDeBusqueda {

        @Test
        @DisplayName("de() conserva consulta, orden, límite y total")
        void deConservaTodo() {
            var solicitud = SolicitudBusqueda.de("code.eq('CM-1')", "id", "id", 50, true);

            assertThat(solicitud.resource().q()).isEqualTo("code.eq('CM-1')");
            assertThat(solicitud.resource().orderBy()).isEqualTo("id");
            assertThat(solicitud.resource().limit()).isEqualTo(50);
            assertThat(solicitud.resource().totalResults()).isTrue();
        }

        @Test
        @DisplayName("unica() pide una sola fila y no pide total")
        void unicaPideUnaSolaFila() {
            var solicitud = SolicitudBusqueda.unica("code.eq('CM-1')", "id");

            assertThat(solicitud.resource().limit()).isEqualTo(1);
            assertThat(solicitud.resource().totalResults()).isFalse();
            assertThat(solicitud.resource().orderBy()).isNull();
        }

        @Test
        @DisplayName("cabecera() se comporta igual que unica()")
        void cabeceraSeComportaIgualQueUnica() {
            var cabecera = SolicitudBusqueda.cabecera("q", "id");
            var unica = SolicitudBusqueda.unica("q", "id");

            assertThat(cabecera.resource()).isEqualTo(unica.resource());
        }

        @Test
        @DisplayName("soloEnlaces() proyecta únicamente el id")
        void soloEnlacesProyectaSoloElId() {
            var solicitud = SolicitudBusqueda.soloEnlaces("code.eq('CM-1')");

            assertThat(solicitud.resource().fields()).isEqualTo(CamposOhi.SOLO_ID);
            assertThat(solicitud.resource().limit()).isEqualTo(1);
        }

        @Test
        @DisplayName("el campo fields del resource va nulo salvo en soloEnlaces: la proyección va aparte")
        void elFieldsDelResourceVaNuloSalvoEnSoloEnlaces() {
            assertThat(SolicitudBusqueda.de("q", "id", null, 10, false).resource().fields())
                    .isNull();
            assertThat(SolicitudBusqueda.soloEnlaces("q").resource().fields()).isNotNull();
        }
    }
}
