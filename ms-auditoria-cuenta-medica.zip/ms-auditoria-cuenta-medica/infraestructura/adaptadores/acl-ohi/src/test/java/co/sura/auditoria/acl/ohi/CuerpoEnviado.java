package co.sura.auditoria.acl.ohi;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import org.reactivestreams.Publisher;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.reactive.ClientHttpRequest;
import org.springframework.http.codec.HttpMessageWriter;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * Qué cuerpo salió de verdad en una petición capturada del {@code WebClient}.
 *
 * <h3>Por qué hace falta esto</h3>
 * {@link ClientRequest#body()} no es el JSON: es un {@code BodyInserter}, una
 * promesa de escribirlo. Para verlo hay que darle dónde escribir, y lo habitual
 * es el {@code MockClientHttpRequest} de {@code spring-test}, que <b>no está en
 * el classpath</b> de este proyecto. Añadir la dependencia solo para esto sería
 * una decisión de arquitectura de pasada, así que en su lugar hay aquí un
 * destino en memoria: son cuarenta líneas, no se usan en producción y sirven a
 * cualquier prueba que necesite afirmar sobre el cuerpo.
 *
 * <p>Y hace falta de verdad: el sobre de las búsquedas de OHI es justo donde
 * duelen sus trampas —la proyección solo se aplica junto a
 * {@code defaultoverride}, y los parámetros puestos en el objeto equivocado se
 * ignoran sin error— así que una prueba que no mire el cuerpo no las ve.
 */
public final class CuerpoEnviado {

    private static final List<HttpMessageWriter<?>> ESCRITORES =
            ExchangeStrategies.withDefaults().messageWriters();

    private CuerpoEnviado() {}

    /** El JSON que la petición habría puesto en el cable. */
    public static String de(ClientRequest peticion) {
        var destino = new DestinoEnMemoria();
        StepVerifier.create(peticion.body().insert(destino, new ContextoSinServidor()))
                .verifyComplete();
        return destino.texto();
    }

    private static final class ContextoSinServidor implements BodyInserter.Context {
        @Override public List<HttpMessageWriter<?>> messageWriters() { return ESCRITORES; }
        @Override public Optional<ServerHttpRequest> serverRequest() { return Optional.empty(); }
        @Override public Map<String, Object> hints() { return Map.of(); }
    }

    private static final class DestinoEnMemoria implements ClientHttpRequest {

        private final DataBufferFactory fabrica = new DefaultDataBufferFactory();
        private final HttpHeaders cabeceras = new HttpHeaders();
        private final MultiValueMap<String, HttpCookie> galletas = new LinkedMultiValueMap<>();
        private final List<byte[]> trozos = new ArrayList<>();

        String texto() {
            var total = new java.io.ByteArrayOutputStream();
            trozos.forEach(total::writeBytes);
            return total.toString(java.nio.charset.StandardCharsets.UTF_8);
        }

        @Override public Mono<Void> writeWith(Publisher<? extends DataBuffer> cuerpo) {
            return Flux.from(cuerpo).doOnNext(b -> {
                var bytes = new byte[b.readableByteCount()];
                b.read(bytes);
                trozos.add(bytes);
            }).then();
        }

        @Override public Mono<Void> writeAndFlushWith(
                Publisher<? extends Publisher<? extends DataBuffer>> cuerpo) {
            return Flux.from(cuerpo).concatMap(this::writeWith).then();
        }

        @Override public Mono<Void> setComplete() { return Mono.empty(); }
        @Override public DataBufferFactory bufferFactory() { return fabrica; }
        @Override public void beforeCommit(Supplier<? extends Mono<Void>> accion) { }
        @Override public boolean isCommitted() { return false; }
        @Override public HttpHeaders getHeaders() { return cabeceras; }
        @Override public MultiValueMap<String, HttpCookie> getCookies() { return galletas; }
        @Override public HttpMethod getMethod() { return HttpMethod.POST; }
        @Override public URI getURI() { return URI.create("https://ohi.invalido/api"); }
        @Override public Map<String, Object> getAttributes() { return Map.of(); }

        @SuppressWarnings("unchecked")
        @Override public <T> T getNativeRequest() { return (T) this; }
    }
}
