package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

/**
 * Las notas de la cuenta, mientras OHI no publique cómo crearlas.
 *
 * <p>Lo que importa fijar es la ausencia: este adaptador ya no tiene cliente HTTP con el que
 * llamar, así que la llamada a {@code /generic/claimnotes} —que da 404 y sumaba un fallo al
 * circuito de comandos en cada resolución— no puede volver sin que esta prueba cambie.
 */
@DisplayName("AdaptadorNotasOhi")
class AdaptadorNotasOhiTest {

    @Test
    @Tag("OPE-02")
    @DisplayName("agregar una nota termina sin llamar al sistema de registro y sin error")
    void noLlamaAlSistemaDeRegistro() {
        // Se construye sin WebClient: si volviera a necesitarlo, esto dejaría de compilar.
        var adaptador = new AdaptadorNotasOhi();

        StepVerifier.create(adaptador.agregarNota(new CodigoCuenta("CM-94421"), "auditor",
                                                  "Resolución masiva de 2 motivos"))
                .verifyComplete();
    }
}
