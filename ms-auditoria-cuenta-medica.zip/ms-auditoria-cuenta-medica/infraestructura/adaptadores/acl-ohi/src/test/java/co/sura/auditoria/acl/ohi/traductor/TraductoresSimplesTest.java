package co.sura.auditoria.acl.ohi.traductor;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.externo.OhiAccionRequest;
import co.sura.auditoria.acl.ohi.externo.OhiLink;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.acl.ohi.externo.OhiStatusResponse;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("Traductores de estado, pendiente y acciones")
class TraductoresSimplesTest {

    @Nested
    @DisplayName("TraductorEstadoProceso")
    class EstadoDelProceso {

        private final TraductorEstadoProceso traductor = new TraductorEstadoProceso();

        @Test
        @DisplayName("traduce avance y finalización")
        void traduceAvanceYFinalizacion() {
            var externo = new OhiStatusResponse("succeeded", true, "FINALIZED", List.of());

            var dominio = traductor.aDominio(externo);

            assertThat(dominio.avance()).isEqualTo(EstadoProceso.Avance.EXITOSO);
            assertThat(dominio.finalizado()).isTrue();
            assertThat(dominio.errores()).isEmpty();
        }

        @Test
        @DisplayName("un completed nulo se lee como NO finalizado, no revienta")
        void unCompletedNuloSeLeeComoNoFinalizado() {
            var externo = new OhiStatusResponse("processing", null, null, null);

            assertThat(traductor.aDominio(externo).finalizado()).isFalse();
        }

        @Test
        @DisplayName("sin progress el avance cae en NO_INICIADO")
        void sinProgressElAvanceCaeEnNoIniciado() {
            // Antes de la guarda de nulo en DiccionarioOhi, esto lanzaba NullPointerException.
            var externo = new OhiStatusResponse(null, false, null, null);

            assertThat(traductor.aDominio(externo).avance())
                    .isEqualTo(EstadoProceso.Avance.NO_INICIADO);
        }

        @Test
        @DisplayName("una lista de errores nula se traduce a vacía")
        void unaListaDeErroresNulaSeTraduceAVacia() {
            var externo = new OhiStatusResponse("failed", true, null, null);

            assertThat(traductor.aDominio(externo).errores()).isEmpty();
        }

        @Test
        @DisplayName("recoge el detalle de cada error que OHI reporta")
        void recogeElDetalleDeCadaError() {
            var externo = new OhiStatusResponse("failed", true, null, List.of(
                    new OhiStatusResponse.OhiClaimErrorDetail("falta prestador", null, null),
                    new OhiStatusResponse.OhiClaimErrorDetail("falta UEN", null, null)));

            assertThat(traductor.aDominio(externo).errores())
                    .containsExactly("falta prestador", "falta UEN");
        }
    }

    @Nested
    @DisplayName("TraductorPendiente")
    class Pendiente {

        private final TraductorPendiente traductor = new TraductorPendiente();

        private static OhiPendReasonItem item(Boolean resuelto, Boolean soloAdjudicacion,
                                              OhiPendReasonItem.OhiClaimLineRef linea,
                                              Long version) {
            return new OhiPendReasonItem(42L,
                    new OhiPendReasonItem.OhiPendReasonRef("7", "AUD01", "Auditoría médica",
                            soloAdjudicacion),
                    resuelto, linea, version);
        }

        @Test
        @DisplayName("el de cabecera no lleva referencia de línea ni número")
        void elDeCabeceraNoLlevaLinea() {
            var dominio = traductor.aDominioCabecera(item(false, true, null, 3L));

            assertThat(dominio.nivel()).isEqualTo(NivelPendiente.CABECERA);
            assertThat(dominio.referenciaLinea()).isNull();
            assertThat(dominio.numeroLinea()).isNull();
            assertThat(dominio.identificador()).isEqualTo(42L);
            assertThat(dominio.codigo()).isEqualTo("AUD01");
            assertThat(dominio.soloAdjudicacion()).isTrue();
        }

        @Test
        @DisplayName("el de línea lleva su referencia y su número de secuencia")
        void elDeLineaLlevaReferenciaYNumero() {
            var linea = new OhiPendReasonItem.OhiClaimLineRef(148111592284L, 3);

            var dominio = traductor.aDominioLinea(item(false, false, linea, 1L));

            assertThat(dominio.nivel()).isEqualTo(NivelPendiente.LINEA);
            assertThat(dominio.referenciaLinea().valor()).isEqualTo(148111592284L);
            assertThat(dominio.numeroLinea()).isEqualTo(3);
        }

        @Test
        @DisplayName("un pendiente de línea sin claimLine no revienta: queda sin referencia")
        void unPendienteDeLineaSinClaimLineNoRevienta() {
            var dominio = traductor.aDominioLinea(item(false, false, null, 1L));

            assertThat(dominio.referenciaLinea()).isNull();
            assertThat(dominio.numeroLinea()).isNull();
        }

        @Test
        @DisplayName("resolved y adjudicationOnly nulos se leen como falso")
        void losBooleanosNulosSeLeenComoFalso() {
            var dominio = traductor.aDominioCabecera(item(null, null, null, 1L));

            assertThat(dominio.resuelto()).isFalse();
            assertThat(dominio.soloAdjudicacion()).isFalse();
        }

        @Test
        @DisplayName("una versión nula se traduce a cero, no a null")
        void unaVersionNulaSeTraduceACero() {
            assertThat(traductor.aDominioCabecera(item(false, false, null, null))
                    .version().numero()).isZero();
        }
    }

    @Nested
    @DisplayName("TraductorAcciones")
    class Acciones {

        private final TraductorAcciones traductor = new TraductorAcciones();

        @Test
        @DisplayName("convierte los enlaces de OHI en las acciones que el auditor puede ejecutar")
        void convierteLosEnlacesEnAcciones() {
            var enlaces = List.of(
                    new OhiLink("claim:submit", "/x", "POST"),
                    new OhiLink("claim:cancel", "/y", "POST"));

            assertThat(traductor.aDominio(enlaces).acciones())
                    .containsExactlyInAnyOrder(AccionCuenta.ENVIAR, AccionCuenta.ANULAR);
        }

        @Test
        @DisplayName("descarta en silencio las relaciones que no son acciones")
        void descartaLasRelacionesQueNoSonAcciones() {
            var enlaces = List.of(
                    new OhiLink("canonical", "/x", "GET"),
                    new OhiLink("claim:submit", "/y", "POST"),
                    new OhiLink("claim:inventada", "/z", "POST"));

            assertThat(traductor.aDominio(enlaces).acciones())
                    .containsExactly(AccionCuenta.ENVIAR);
        }

        @Test
        @DisplayName("sin enlaces no hay ninguna acción disponible")
        void sinEnlacesNoHayAcciones() {
            assertThat(traductor.aDominio(null).acciones()).isEmpty();
            assertThat(traductor.aDominio(List.of()).acciones()).isEmpty();
        }

        @Test
        @DisplayName("el cuerpo de anular lleva el mensaje y los motivos")
        void elCuerpoDeAnularLlevaMensajeYMotivos() {
            var ejecucion = EjecucionAccion.anular(List.of("M1"), "REF-1", "ANULACION_010");

            var cuerpo = (OhiAccionRequest.Anular) TraductorAcciones.cuerpoDe(ejecucion);

            assertThat(cuerpo.cancelReasonMessageCode()).isEqualTo("ANULACION_010");
            assertThat(cuerpo.claimUnfinalizeReasonList()).hasSize(1);
            assertThat(cuerpo.claimUnfinalizeReasonList().get(0).unfinalizeReason().code())
                    .isEqualTo("M1");
            assertThat(cuerpo.claimUnfinalizeReasonList().get(0).sourceReference())
                    .isEqualTo("REF-1");
        }

        @Test
        @DisplayName("el cuerpo de desfinalizar lleva solo los motivos")
        void elCuerpoDeDesfinalizarLlevaSoloMotivos() {
            var ejecucion = EjecucionAccion.conMotivos(AccionCuenta.REVERTIR_FINALIZACION,
                    List.of("M1", "M2"), null);

            var cuerpo = (OhiAccionRequest.Desfinalizar) TraductorAcciones.cuerpoDe(ejecucion);

            assertThat(cuerpo.claimUnfinalizeReasonList()).hasSize(2);
        }

        @Test
        @DisplayName("una referencia en blanco no viaja: se omite en vez de mandar vacío")
        void unaReferenciaEnBlancoNoViaja() {
            var ejecucion = EjecucionAccion.conMotivos(AccionCuenta.REVERTIR_FINALIZACION,
                    List.of("M1"), "   ");

            var cuerpo = (OhiAccionRequest.Desfinalizar) TraductorAcciones.cuerpoDe(ejecucion);

            assertThat(cuerpo.claimUnfinalizeReasonList().get(0).sourceReference()).isNull();
        }

        @Test
        @DisplayName("el cuerpo de desbloquear lleva los identificadores de línea")
        void elCuerpoDeDesbloquearLlevaLasLineas() {
            var cuerpo = (OhiAccionRequest.DesbloquearLineas)
                    TraductorAcciones.cuerpoDe(EjecucionAccion.desbloquear(List.of(1L, 2L)));

            assertThat(cuerpo.claimLineIdList()).containsExactly(1L, 2L);
        }

        @Test
        @DisplayName("desbloquear sin líneas no manda cuerpo: un POST vacío es mejor que uno falso")
        void desbloquearSinLineasNoMandaCuerpo() {
            assertThat(TraductorAcciones.cuerpoDe(EjecucionAccion.desbloquear(List.of())))
                    .isNull();
        }

        @Test
        @DisplayName("las acciones sin cuerpo propio no mandan nada")
        void lasAccionesSinCuerpoPropioNoMandanNada() {
            assertThat(TraductorAcciones.cuerpoDe(
                    EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION))).isNull();
            assertThat(TraductorAcciones.cuerpoDe(
                    EjecucionAccion.simple(AccionCuenta.DESHACER_REEMPLAZOS))).isNull();
        }
    }
}
