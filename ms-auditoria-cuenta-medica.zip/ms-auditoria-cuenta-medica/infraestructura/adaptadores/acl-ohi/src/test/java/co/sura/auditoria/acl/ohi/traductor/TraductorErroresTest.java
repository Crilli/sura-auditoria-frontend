package co.sura.auditoria.acl.ohi.traductor;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.test.StepVerifier;

/**
 * Se construye un {@link ClientResponse} con cuerpo JSON real para que la prueba
 * ejercite el decodificador, que es donde se manifiestan las rarezas de OHI.
 */
@DisplayName("TraductorErrores")
class TraductorErroresTest {

    private final TraductorErrores traductor = new TraductorErrores(new ObjectMapper());

    private static ClientResponse respuesta(HttpStatus estado, String cuerpoJson) {
        return ClientResponse.create(estado)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .body(cuerpoJson)
                .build();
    }

    private static String conCodigo(String codigo) {
        return """
               {"o:errorDetails":[{"o:errorCode":"%s","title":"CM-108800618430"}]}
               """.formatted(codigo);
    }

    private ErrorDeDominio traducir(ClientResponse respuesta) {
        var resultado = new ErrorDeDominio[1];
        StepVerifier.create(traductor.traducir(respuesta))
                .assertNext(error -> {
                    assertThat(error).isInstanceOf(ExcepcionDeDominio.class);
                    resultado[0] = ((ExcepcionDeDominio) error).error();
                })
                .verifyComplete();
        return resultado[0];
    }

    @Nested
    @DisplayName("códigos de negocio de OHI")
    class CodigosDeNegocio {

        @Test
        @DisplayName("CLA-CLAI-035 es que hay pendientes vivos que frenan el envío")
        void pendientesBloqueanEnvio() {
            assertThat(traducir(respuesta(HttpStatus.CONFLICT, conCodigo("CLA-CLAI-035"))))
                    .isInstanceOf(ErrorDeDominio.PendientesBloqueanEnvio.class);
        }

        @ParameterizedTest(name = "{0} es falta de permisos")
        @ValueSource(strings = {"CLA-IP-CLAI-023", "CLA-IP-RPND-006"})
        @DisplayName("los códigos de privilegio se traducen a SinPermiso")
        void losCodigosDePrivilegio(String codigo) {
            var error = traducir(respuesta(HttpStatus.FORBIDDEN, conCodigo(codigo)));

            assertThat(error).isInstanceOf(ErrorDeDominio.SinPermiso.class);
            assertThat(((ErrorDeDominio.SinPermiso) error).detalle())
                    .contains("No se aplicó ningún cambio");
        }

        @Test
        @DisplayName("CLA-IP-RPND-002 es que la cuenta no existe")
        void cuentaNoEncontrada() {
            assertThat(traducir(respuesta(HttpStatus.NOT_FOUND, conCodigo("CLA-IP-RPND-002"))))
                    .isInstanceOf(ErrorDeDominio.CuentaNoEncontrada.class);
        }

        @ParameterizedTest(name = "{0} impide la acción")
        @ValueSource(strings = {"CLA-IP-CLAI-024", "CLA-IP-SUBC-001"})
        @DisplayName("los códigos que impiden enviar se traducen a AccionNoDisponible")
        void losCodigosQueImpidenEnviar(String codigo) {
            assertThat(traducir(respuesta(HttpStatus.CONFLICT, conCodigo(codigo))))
                    .isInstanceOf(ErrorDeDominio.AccionNoDisponible.class);
        }

        @ParameterizedTest(name = "{0} -> «{1}»")
        @CsvSource({
                "CLA-IP-SBMT-001, Denegar exige el código de una novedad bloqueante",
                "CLA-IP-SBMT-002, El código de novedad bloqueante no existe",
                "CLA-IP-SBMT-003, Al aceptar solo se admiten novedades informativas",
                "CLA-IP-SBMT-004, El código de novedad es desconocido"
        })
        @DisplayName("los códigos de envío se traducen a un mensaje en español")
        void losCodigosDeEnvioSeTraducenAEspanol(String codigo, String mensaje) {
            var error = traducir(respuesta(HttpStatus.BAD_REQUEST, conCodigo(codigo)));

            assertThat(error).isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .isEqualTo(mensaje);
        }
    }

    @Nested
    @DisplayName("cuando no hay código conocido, manda el estado HTTP")
    class PorEstadoHttp {

        @Test
        @DisplayName("403 que menciona «authorized limit» es límite de aprobación excedido")
        void limiteDeAprobacion() {
            var cuerpo = """
                         {"detail":"User exceeds authorized limit for this claim"}
                         """;

            assertThat(traducir(respuesta(HttpStatus.FORBIDDEN, cuerpo)))
                    .isInstanceOf(ErrorDeDominio.LimiteAprobacionExcedido.class);
        }

        @Test
        @DisplayName("403 corriente es falta de permisos")
        void prohibidoCorriente() {
            assertThat(traducir(respuesta(HttpStatus.FORBIDDEN, "{\"detail\":\"nope\"}")))
                    .isInstanceOf(ErrorDeDominio.SinPermiso.class);
        }

        @Test
        @DisplayName("409 es modificación concurrente")
        void conflictoEsModificacionConcurrente() {
            assertThat(traducir(respuesta(HttpStatus.CONFLICT, "{}")))
                    .isInstanceOf(ErrorDeDominio.ModificacionConcurrente.class);
        }

        @Test
        @DisplayName("404 lleva el sujeto en el detalle cuando OHI lo da")
        void noEncontradoLlevaElSujeto() {
            var cuerpo = "{\"detail\":\"CM-108800618430\"}";

            var error = traducir(respuesta(HttpStatus.NOT_FOUND, cuerpo));

            assertThat(error).isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("CM-108800618430");
        }

        @Test
        @DisplayName("404 sin sujeto no deja dos puntos colgando")
        void noEncontradoSinSujetoNoDejaDosPuntos() {
            var error = traducir(respuesta(HttpStatus.NOT_FOUND, "{}"));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .doesNotEndWith(": ");
        }

        @Test
        @DisplayName("un 500 se traduce a que el sistema de registro no está disponible")
        void errorDeServidor() {
            var error = traducir(respuesta(HttpStatus.INTERNAL_SERVER_ERROR, "{}"));

            assertThat(error).isInstanceOf(ErrorDeDominio.SistemaRegistroNoDisponible.class);
            assertThat(((ErrorDeDominio.SistemaRegistroNoDisponible) error).detalle())
                    .contains("500");
        }
    }

    @Nested
    @DisplayName("cuerpos que no se pueden interpretar")
    class CuerposIlegibles {

        @Test
        @DisplayName("un cuerpo vacío no revienta: cae al mapeo por estado")
        void unCuerpoVacioNoRevienta() {
            assertThat(traducir(respuesta(HttpStatus.INTERNAL_SERVER_ERROR, "")))
                    .isInstanceOf(ErrorDeDominio.SistemaRegistroNoDisponible.class);
        }

        @Test
        @DisplayName("un cuerpo que no es JSON se registra y cae al mapeo por estado")
        void unCuerpoQueNoEsJsonNoRevienta() {
            var html = "<html><body>502 Bad Gateway</body></html>";

            assertThat(traducir(respuesta(HttpStatus.BAD_GATEWAY, html)))
                    .isInstanceOf(ErrorDeDominio.SistemaRegistroNoDisponible.class);
        }

        @Test
        @DisplayName("un JSON sin o:errorDetails cae al mapeo por estado")
        void unJsonSinDetallesCaeAlMapeoPorEstado() {
            assertThat(traducir(respuesta(HttpStatus.CONFLICT, "{\"title\":\"algo\"}")))
                    .isInstanceOf(ErrorDeDominio.ModificacionConcurrente.class);
        }
    }

    @Nested
    @DisplayName("el código HTTP viaja con el error")
    class CodigoHttp {

        @org.junit.jupiter.api.Tag("OPE-01")
        @ParameterizedTest(name = "{0} sigue siendo un error de dominio y recuerda el código")
        @ValueSource(ints = {409, 404, 503})
        void recuerdaElCodigo(int codigo) {
            // El circuito necesita el código para no contar como caída un 409; el resto del
            // servicio sigue viendo una ExcepcionDeDominio y no nota la diferencia.
            StepVerifier.create(traductor.traducir(respuesta(HttpStatus.valueOf(codigo), "{}")))
                    .assertNext(error -> {
                        assertThat(error).isInstanceOf(ExcepcionDeDominio.class)
                                         .isInstanceOf(RespuestaDeErrorOhi.class);
                        assertThat(((RespuestaDeErrorOhi) error).estadoHttp()).isEqualTo(codigo);
                        assertThat(error).hasToString(
                                "respuesta HTTP " + codigo + " del sistema de registro");
                    })
                    .verifyComplete();
        }
    }
}
