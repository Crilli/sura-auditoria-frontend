package co.sura.auditoria.acl.ohi.cache;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Sinks;
import reactor.test.StepVerifier;

/** La caché de agregados por cuenta (OPE-09). */
@DisplayName("CacheDeAgregadosOhi")
class CacheDeAgregadosOhiTest {

    private static final CodigoCuenta CUENTA = new CodigoCuenta("CM-56747409660");
    private static final CodigoCuenta OTRA = new CodigoCuenta("CM-94421");

    private final CacheDeAgregadosOhi cache = new CacheDeAgregadosOhi();
    private final AtomicInteger cargas = new AtomicInteger();

    private Mono<String> cargar(String valor) {
        return Mono.fromCallable(() -> { cargas.incrementAndGet(); return valor; });
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("dentro de la vigencia, la segunda petición no vuelve a cargar")
    void segundaPeticionDeLaCache() {
        StepVerifier.create(cache.obtener(Agregado.FILTROS_LINEAS, CUENTA, () -> cargar("a"))).expectNext("a").verifyComplete();
        StepVerifier.create(cache.obtener(Agregado.FILTROS_LINEAS, CUENTA, () -> cargar("b"))).expectNext("a").verifyComplete();

        assertThat(cargas).hasValue(1);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("cada agregado y cada cuenta tienen su propia entrada")
    void entradasSeparadas() {
        cache.obtener(Agregado.FILTROS_LINEAS, CUENTA, () -> cargar("filtros")).block();
        cache.obtener(Agregado.MOTIVOS_PENDIENTES, CUENTA, () -> cargar("motivos")).block();
        cache.obtener(Agregado.FILTROS_LINEAS, OTRA, () -> cargar("filtros otra")).block();

        assertThat(cargas).hasValue(3);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("las peticiones simultáneas comparten una sola carga, y cancelar una no cancela las demás")
    void cargaCompartida() {
        var resultado = Sinks.<String>one();
        var carga = Mono.defer(() -> { cargas.incrementAndGet(); return resultado.asMono(); });

        var primera = cache.obtener(Agregado.ACCIONES, CUENTA, () -> carga).subscribe();
        var segunda = StepVerifier.create(cache.obtener(Agregado.ACCIONES, CUENTA, () -> carga))
                .expectNext("listo").expectComplete().verifyLater();

        // El primero se va (cambió de pestaña) antes de que termine la carga.
        primera.dispose();
        resultado.tryEmitValue("listo");

        segunda.verify(Duration.ofSeconds(2));
        assertThat(cargas).hasValue(1);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("invalidar una cuenta obliga a volver a cargar sus agregados, y no toca los de otra")
    void invalidarCuenta() {
        cache.obtener(Agregado.MOTIVOS_PENDIENTES, CUENTA, () -> cargar("viejo")).block();
        cache.obtener(Agregado.MOTIVOS_PENDIENTES, OTRA, () -> cargar("otra")).block();

        cache.invalidar(CUENTA);

        StepVerifier.create(cache.obtener(Agregado.MOTIVOS_PENDIENTES, CUENTA, () -> cargar("nuevo")))
                .expectNext("nuevo").verifyComplete();
        StepVerifier.create(cache.obtener(Agregado.MOTIVOS_PENDIENTES, OTRA, () -> cargar("x")))
                .expectNext("otra").verifyComplete();
        assertThat(cargas).hasValue(3);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("invalidar todo vacía todas las cuentas")
    void invalidarTodo() {
        cache.obtener(Agregado.ACCIONES, CUENTA, () -> cargar("a")).block();
        cache.obtener(Agregado.ACCIONES, OTRA, () -> cargar("b")).block();

        cache.invalidarTodo();

        cache.obtener(Agregado.ACCIONES, CUENTA, () -> cargar("a2")).block();
        cache.obtener(Agregado.ACCIONES, OTRA, () -> cargar("b2")).block();
        assertThat(cargas).hasValue(4);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("un error no se guarda: la siguiente petición vuelve a cargar")
    void elErrorNoSeGuarda() {
        StepVerifier.create(cache.obtener(Agregado.FILTROS_LINEAS, CUENTA,
                        () -> Mono.<String>error(new IllegalStateException("OHI caído"))))
                .expectErrorMessage("OHI caído").verify();

        StepVerifier.create(cache.obtener(Agregado.FILTROS_LINEAS, CUENTA, () -> cargar("bien")))
                .expectNext("bien").verifyComplete();
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("un vacío no se guarda y llega como vacío")
    void elVacioNoSeGuarda() {
        StepVerifier.create(cache.obtener(Agregado.ACCIONES, CUENTA, Mono::<String>empty)).verifyComplete();
        StepVerifier.create(cache.obtener(Agregado.ACCIONES, CUENTA, () -> cargar("algo")))
                .expectNext("algo").verifyComplete();
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("pasada la vigencia se vuelve a cargar")
    void caducidad() throws InterruptedException {
        var corta = new CacheDeAgregadosOhi(Duration.ofMillis(50), 10);
        corta.obtener(Agregado.FILTROS_LINEAS, CUENTA, () -> cargar("a")).block();
        Thread.sleep(120);
        corta.obtener(Agregado.FILTROS_LINEAS, CUENTA, () -> cargar("b")).block();

        assertThat(cargas).hasValue(2);
        assertThat(corta.cacheNativa()).isNotNull();
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("un comando que no acabó limpio invalida ahora y otra vez pasada la vigencia; uno limpio, solo ahora")
    void invalidarTrasComando() throws InterruptedException {
        var corta = new CacheDeAgregadosOhi(Duration.ofMillis(60), 10);
        var invalidaciones = new java.util.concurrent.CopyOnWriteArrayList<CodigoCuenta>();
        corta.alInvalidar(invalidaciones::add, () -> { });

        corta.invalidarTrasComando(CUENTA, reactor.core.publisher.SignalType.ON_COMPLETE);
        corta.invalidarTrasComando(OTRA, reactor.core.publisher.SignalType.ON_ERROR);
        assertThat(invalidaciones).containsExactly(CUENTA, OTRA);

        // Un error o una cancelación no dicen que OHI no lo aplicara: lo que llegue a leerse
        // mientras tanto se descarta otra vez cuando OHI ya ha tenido tiempo de terminar.
        Thread.sleep(200);
        assertThat(invalidaciones).containsExactly(CUENTA, OTRA, OTRA);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("invalidar todo avisa a quien guarda cosas por su lado")
    void invalidarTodoAvisa() {
        var vaciados = new AtomicInteger();
        cache.alInvalidar(c -> { }, vaciados::incrementAndGet);

        cache.invalidarTodo();

        assertThat(vaciados).hasValue(1);
    }
}
