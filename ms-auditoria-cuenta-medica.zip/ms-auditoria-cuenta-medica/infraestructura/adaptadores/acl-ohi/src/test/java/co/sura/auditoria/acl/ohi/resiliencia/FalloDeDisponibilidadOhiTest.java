package co.sura.auditoria.acl.ohi.resiliencia;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.util.concurrent.TimeoutException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import io.netty.handler.timeout.ReadTimeoutException;
import org.springframework.core.io.buffer.DataBufferLimitException;
import reactor.netty.http.client.PrematureCloseException;
import reactor.netty.internal.shaded.reactor.pool.PoolAcquirePendingLimitException;
import reactor.netty.internal.shaded.reactor.pool.PoolAcquireTimeoutException;

/**
 * Qué cuenta como caída del sistema de registro (OPE-01).
 *
 * <p>Las excepciones del pool son las reales de Reactor Netty, no imitaciones: el predicado
 * las reconoce por nombre porque viven en un paquete sombreado, y esta prueba es la que
 * avisaría si cambiaran de nombre.
 */
@DisplayName("FalloDeDisponibilidadOhi")
class FalloDeDisponibilidadOhiTest {

    private final FalloDeDisponibilidadOhi esCaida = new FalloDeDisponibilidadOhi();

    private static RespuestaDeErrorOhi respuesta(int estado) {
        return new RespuestaDeErrorOhi(new ErrorDeDominio.ModificacionConcurrente("cuenta", -1), estado);
    }

    private static WebClientRequestException transporte(Throwable causa) {
        return new WebClientRequestException(causa, HttpMethod.POST,
                URI.create("https://ohi.example/api/claims/search"), new HttpHeaders());
    }

    @ParameterizedTest(name = "OHI respondió {0}: es una respuesta, no una caída")
    @ValueSource(ints = {400, 403, 404, 409, 412, 422})
    @Tag("OPE-01")
    void lasRespuestasDeNegocioNoCuentan(int estado) {
        assertThat(esCaida.test(respuesta(estado))).isFalse();
    }

    @ParameterizedTest(name = "OHI respondió {0}: cuenta como caída")
    @ValueSource(ints = {429, 500, 502, 503, 504})
    @Tag("OPE-01")
    void cincoXxYElFrenoCuentan(int estado) {
        assertThat(esCaida.test(respuesta(estado))).isTrue();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("un error del dominio que no vino de una respuesta HTTP no cuenta")
    void errorDeDominioSinRespuesta() {
        assertThat(esCaida.test(ExcepcionDeDominio.de(
                new ErrorDeDominio.DecisionEnvioInvalida("sin motivo")))).isFalse();
        assertThat(esCaida.test(new IllegalStateException("fallo de programación"))).isFalse();
        assertThat(esCaida.test(null)).isFalse();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("el transporte sí cuenta: conexión cortada, timeout del operador, E/S")
    void elTransporteCuenta() {
        assertThat(esCaida.test(transporte(new IOException("Connection reset by peer")))).isTrue();
        assertThat(esCaida.test(new TimeoutException("Did not observe any item"))).isTrue();
        assertThat(esCaida.test(new IOException("Broken pipe"))).isTrue();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("una respuesta cruda de WebClient se juzga por su código, igual que la traducida")
    void respuestaCruda() {
        assertThat(esCaida.test(WebClientResponseException.create(
                503, "Service Unavailable", null, null, null))).isTrue();
        assertThat(esCaida.test(WebClientResponseException.create(
                404, "Not Found", null, null, null))).isFalse();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("la cola del pool llena o vencida es saturación propia y no cuenta")
    void laSaturacionDelPoolNoCuenta() {
        // Llegan envueltas en WebClientRequestException, que por sí sola sí contaría: es la
        // causa la que decide. Y el timeout del pool es un TimeoutException, que también.
        assertThat(esCaida.test(transporte(new PoolAcquirePendingLimitException(60)))).isFalse();
        assertThat(esCaida.test(transporte(new PoolAcquireTimeoutException(Duration.ofSeconds(10)))))
                .isFalse();
        assertThat(esCaida.test(new PoolAcquireTimeoutException(Duration.ofSeconds(10)))).isFalse();
    }

    private static WebClientResponseException respuestaCon(int estado, Throwable causa) {
        var respuesta = WebClientResponseException.create(estado, "estado", null, null, null);
        respuesta.initCause(causa);
        return respuesta;
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("un corte a mitad del cuerpo de un 200 es transporte, aunque WebClient lo entregue como «200»")
    void corteAMitadDelCuerpo() {
        assertThat(esCaida.test(respuestaCon(200, PrematureCloseException.TEST_EXCEPTION))).isTrue();
        assertThat(esCaida.test(respuestaCon(200, ReadTimeoutException.INSTANCE))).isTrue();
        assertThat(FalloDeDisponibilidadOhi.esTransporte(respuestaCon(200, ReadTimeoutException.INSTANCE))).isTrue();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("un 200 que falló por otra cosa —el cuerpo demasiado grande— no es una caída")
    void doscientosPorOtraCosa() {
        assertThat(esCaida.test(respuestaCon(200, new DataBufferLimitException("4MB")))).isFalse();
        assertThat(esCaida.test(WebClientResponseException.create(200, "OK", null, null, null))).isFalse();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("el timeout de lectura de Netty suelto también es transporte")
    void timeoutDeNettySuelto() {
        assertThat(esCaida.test(ReadTimeoutException.INSTANCE)).isTrue();
        assertThat(FalloDeDisponibilidadOhi.esTransporte(null)).isFalse();
        assertThat(FalloDeDisponibilidadOhi.esTransporte(respuestaCon(503, ReadTimeoutException.INSTANCE)))
                .as("un 5xx es una respuesta, no un fallo de transporte").isFalse();
        assertThat(FalloDeDisponibilidadOhi.esTransporte(transporte(new PoolAcquirePendingLimitException(60))))
                .isFalse();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("la saturación del pool es lo que el circuito ignora; lo demás, no")
    void elCircuitoIgnoraSoloLaSaturacion() {
        var ignorar = new SaturacionDelPoolOhi();

        assertThat(ignorar.test(transporte(new PoolAcquirePendingLimitException(60)))).isTrue();
        assertThat(ignorar.test(new PoolAcquireTimeoutException(Duration.ofSeconds(10)))).isTrue();
        assertThat(ignorar.test(transporte(new IOException("Connection reset")))).isFalse();
        assertThat(ignorar.test(respuesta(409))).isFalse();
        assertThat(ignorar.test(null)).isFalse();
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("se reintentan las caídas, pero no el 429: pide justo lo contrario")
    void elReintentoNoInsisteConUn429() {
        var reintentable = new ReintentableOhi();

        assertThat(reintentable.test(respuesta(503))).isTrue();
        assertThat(reintentable.test(transporte(new IOException("Connection reset")))).isTrue();
        assertThat(reintentable.test(respuesta(429))).isFalse();
        assertThat(reintentable.test(WebClientResponseException.create(429, "Too Many", null, null, null))).isFalse();
        assertThat(reintentable.test(respuesta(404))).isFalse();
        assertThat(reintentable.test(transporte(new PoolAcquirePendingLimitException(60)))).isFalse();
    }
}
