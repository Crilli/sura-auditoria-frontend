package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorAcciones;
import co.sura.auditoria.acl.ohi.traductor.TraductorCuenta;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorEstadoProceso;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.acl.ohi.traductor.TraductorNovedad;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/** Lo que la consulta del proceso de envío hace con lo guardado de la cuenta (OPE-09). */
@DisplayName("AdaptadorConsultasOhi — lo guardado de la cuenta")
class AdaptadorConsultasOhiCacheTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-94421");

    private final TraductorEstadoProceso traductorProceso = mock(TraductorEstadoProceso.class);
    private final CacheDeAgregadosOhi agregados = new CacheDeAgregadosOhi();
    private final List<CodigoCuenta> invalidadas = new CopyOnWriteArrayList<>();
    private AdaptadorConsultasOhi adaptador;

    @BeforeEach
    void montar() {
        var web = WebClient.builder().baseUrl("https://ohi.example/api")
                .exchangeFunction(p -> Mono.just(ClientResponse.create(HttpStatus.OK)
                        .header("Content-Type", MediaType.APPLICATION_JSON_VALUE).body("{}").build()))
                .build();
        var resiliencia = mock(ConfiguracionResiliencia.class);
        when(resiliencia.<Object>paraConsultasMono()).thenReturn(Function.identity());
        var resolutor = new ResolutorIdentidadOhi();
        resolutor.cacheNativa().put(CODIGO.valor(), 94421L);
        adaptador = new AdaptadorConsultasOhi(web, resiliencia, new TraductorErrores(new ObjectMapper()),
                mock(TraductorCuenta.class), new TraductorLinea(new TraductorNovedad(), new TraductorPendiente()),
                new TraductorPendiente(), traductorProceso, mock(AdaptadorPendientesOhi.class),
                mock(AdaptadorNovedadesOhi.class), mock(AdaptadorAfiliadosOhi.class),
                mock(AdaptadorPrestadoresOhi.class), resolutor, mock(TraductorAcciones.class), web, agregados);
        agregados.alInvalidar(invalidadas::add, () -> { });
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("un envío que termina descarta lo guardado: el proceso movió la cuenta después del comando")
    void envioTerminadoInvalida() {
        when(traductorProceso.aDominio(any()))
                .thenReturn(new EstadoProceso(EstadoProceso.Avance.EXITOSO, true, List.of()));

        StepVerifier.create(adaptador.consultarEstadoProceso(CODIGO))
                .assertNext(e -> assertThat(e.finalizado()).isTrue()).verifyComplete();
        assertThat(invalidadas).containsExactly(CODIGO);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("mientras el envío sigue en curso, lo guardado se queda")
    void envioEnCursoNoInvalida() {
        when(traductorProceso.aDominio(any()))
                .thenReturn(new EstadoProceso(EstadoProceso.Avance.EN_PROCESO, false, List.of()));

        adaptador.consultarEstadoProceso(CODIGO).block();
        assertThat(invalidadas).isEmpty();
    }
}
