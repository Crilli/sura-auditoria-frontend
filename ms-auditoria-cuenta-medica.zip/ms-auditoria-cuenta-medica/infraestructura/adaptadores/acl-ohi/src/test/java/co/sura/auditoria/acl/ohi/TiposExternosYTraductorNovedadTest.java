package co.sura.auditoria.acl.ohi;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiInstante;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem.OhiMessageRef;
import co.sura.auditoria.acl.ohi.traductor.TraductorNovedad;
import co.sura.auditoria.modelo.cuenta.Severidad;
import java.time.Instant;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("Tipos externos de OHI y traducción de novedades")
class TiposExternosYTraductorNovedadTest {

    @Nested
    @DisplayName("OhiInstante")
    class Instante {

        @Test
        @DisplayName("convierte una marca con desfase horario a instante")
        void convierteUnaMarcaConDesfase() {
            assertThat(OhiInstante.aInstante(new OhiInstante("2026-08-21T11:04:05.728-05:00")))
                    .isEqualTo(Instant.parse("2026-08-21T16:04:05.728Z"));
        }

        @ParameterizedTest(name = "[{0}] -> null")
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        @DisplayName("una marca vacía o en blanco da null, no revienta")
        void unaMarcaVaciaDaNull(String valor) {
            assertThat(OhiInstante.aInstante(new OhiInstante(valor))).isNull();
        }

        @Test
        @DisplayName("un envoltorio nulo da null")
        void unEnvoltorioNuloDaNull() {
            assertThat(OhiInstante.aInstante(null)).isNull();
        }

        @Test
        @DisplayName("una marca mal formada degrada a null en vez de tumbar la consulta")
        void unaMarcaMalFormadaDegradaANull() {
            // Un formato inesperado de OHI no debe impedir que el auditor vea la cuenta;
            // se pierde la fecha, no la pantalla.
            assertThat(OhiInstante.aInstante(new OhiInstante("21/08/2026"))).isNull();
        }
    }

    @Nested
    @DisplayName("OhiFlexCode")
    class FlexCode {

        @Test
        @DisplayName("prefiere el descriptor, que es lo legible")
        void prefiereElDescriptor() {
            assertThat(OhiFlexCode.textoDe(new OhiFlexCode("31", "CALI"))).isEqualTo("CALI");
        }

        @Test
        @DisplayName("sin descriptor se queda con el valor crudo antes que no decir nada")
        void sinDescriptorUsaElValor() {
            assertThat(OhiFlexCode.textoDe(new OhiFlexCode("31", null))).isEqualTo("31");
        }

        @Test
        @DisplayName("un flexcode nulo da null")
        void unFlexCodeNuloDaNull() {
            assertThat(OhiFlexCode.textoDe(null)).isNull();
        }
    }

    @Nested
    @DisplayName("OhiMessageItem")
    class MessageItem {

        private static OhiMessageItem conValores(String... diez) {
            return new OhiMessageItem(1L, null, "MANUAL", null, null,
                    diez[0], diez[1], diez[2], diez[3], diez[4],
                    diez[5], diez[6], diez[7], diez[8], diez[9]);
        }

        @Test
        @DisplayName("los diez valores sueltos se indexan por su posición")
        void losDiezValoresSeIndexan() {
            var item = conValores("a", null, "c", null, null, null, null, null, null, "j");

            assertThat(item.valoresPorIndice())
                    .containsExactlyInAnyOrderEntriesOf(
                            java.util.Map.of(0, "a", 2, "c", 9, "j"));
        }

        @Test
        @DisplayName("los índices son dispersos: se omite lo que viene vacío")
        void losIndicesSonDispersos() {
            // Medido en el catálogo: SURA-AUT-002 usa solo el 1 y el 2.
            var item = conValores(null, "uno", "dos", null, null, null, null, null, null, null);

            assertThat(item.valoresPorIndice()).containsOnlyKeys(1, 2);
        }

        @Test
        @DisplayName("un valor en blanco cuenta como ausente")
        void unValorEnBlancoCuentaComoAusente() {
            var item = conValores("   ", "real", null, null, null, null, null, null, null, null);

            assertThat(item.valoresPorIndice()).containsOnlyKeys(1);
        }

        @Test
        @DisplayName("sin ningún valor el mapa queda vacío, no nulo")
        void sinValoresElMapaQuedaVacio() {
            assertThat(new OhiMessageItem(1L, null, "MANUAL").valoresPorIndice()).isEmpty();
        }

        @Test
        @DisplayName("el mapa que sale es inmutable")
        void elMapaQueSaleEsInmutable() {
            var mapa = conValores("a", null, null, null, null, null, null, null, null, null)
                    .valoresPorIndice();

            org.assertj.core.api.Assertions
                    .assertThatThrownBy(() -> mapa.put(5, "x"))
                    .isInstanceOf(UnsupportedOperationException.class);
        }

        @Test
        @DisplayName("el constructor corto deja los diez valores y la traza en nulo")
        void elConstructorCortoDejaLoDemasNulo() {
            var corto = new OhiMessageItem(7L, new OhiMessageRef("332-1", "I", "texto"), "MANUAL");

            assertThat(corto.id()).isEqualTo(7L);
            assertThat(corto.origin()).isEqualTo("MANUAL");
            assertThat(corto.createdByUserName()).isNull();
            assertThat(corto.creationDate()).isNull();
            assertThat(corto.value0()).isNull();
        }

        @Test
        @DisplayName("el constructor corto de la referencia deja la clasificación en nulo")
        void elConstructorCortoDeLaReferencia() {
            var ref = new OhiMessageRef("332-1", "F", "Procedimiento no autorizado");

            assertThat(ref.code()).isEqualTo("332-1");
            assertThat(ref.severity()).isEqualTo("F");
            assertThat(ref.descripcion()).isEqualTo("Procedimiento no autorizado");
            assertThat(ref.conceptoGenerico()).isNull();
            assertThat(ref.system()).isNull();
        }
    }

    @Nested
    @DisplayName("TraductorNovedad")
    class Traductor {

        private final TraductorNovedad traductor = new TraductorNovedad();

        @Test
        @DisplayName("traduce código, severidad, origen, autor y fecha")
        void traduceLoEsencial() {
            var externo = new OhiMessageItem(9L,
                    new OhiMessageRef("SURA-AUT-002", "I", "Autorización {2} consumida",
                            new OhiFlexCode("G", "Tarifas"), new OhiFlexCode("E", "Ayudas"),
                            Boolean.FALSE),
                    "MANUAL", "auditor", new OhiInstante("2026-08-21T11:04:05-05:00"),
                    null, null, "104409176961", null, null, null, null, null, null, null);

            var novedad = traductor.aDominio(externo);

            assertThat(novedad.identificador()).isEqualTo(9L);
            assertThat(novedad.codigo()).isEqualTo("SURA-AUT-002");
            assertThat(novedad.severidad()).isEqualTo(Severidad.INFORMATIVA);
            assertThat(novedad.origen()).isEqualTo("MANUAL");
            assertThat(novedad.autor()).isEqualTo("auditor");
            assertThat(novedad.fecha()).isEqualTo(Instant.parse("2026-08-21T16:04:05Z"));
            assertThat(novedad.esDelSistema()).isFalse();
        }

        @Test
        @DisplayName("la clasificación se traduce con su código y su descriptor")
        void laClasificacionSeTraduce() {
            var externo = new OhiMessageItem(1L,
                    new OhiMessageRef("A", "I", "t", new OhiFlexCode("208", "Tarifas"),
                            null, Boolean.TRUE),
                    "MANUAL");

            var novedad = traductor.aDominio(externo);

            assertThat(novedad.generico().codigo()).isEqualTo("208");
            assertThat(novedad.generico().descripcion()).isEqualTo("Tarifas");
            assertThat(novedad.especifico()).isNull();
            assertThat(novedad.esDelSistema()).isTrue();
        }

        @Test
        @DisplayName("los valores llegan indexados y el texto se puede resolver")
        void losValoresLleganIndexados() {
            var externo = new OhiMessageItem(1L,
                    new OhiMessageRef("A", "I", "Autorización {2} consumida"),
                    "MANUAL", null, null,
                    null, null, "99073568971", null, null, null, null, null, null, null);

            var novedad = traductor.aDominio(externo);

            assertThat(novedad.valores()).containsEntry(2, "99073568971");
            assertThat(novedad.textoResuelto()).isEqualTo("Autorización 99073568971 consumida");
        }

        @Test
        @DisplayName("una novedad SIN mensaje en el catálogo no se pierde: se marca y se conserva")
        void unaNovedadSinMensajeSeConserva() {
            // Perderla sería peor que mostrarla incompleta: el auditor vería menos
            // novedades de las que la cuenta tiene.
            var huerfana = new OhiMessageItem(42L, null, "PRICING");

            var novedad = traductor.aDominio(huerfana);

            assertThat(novedad.identificador()).isEqualTo(42L);
            assertThat(novedad.codigo()).isNull();
            assertThat(novedad.descripcion()).isEqualTo("(novedad sin mensaje en el catálogo)");
            assertThat(novedad.severidad()).isEqualTo(Severidad.DESCONOCIDA);
            assertThat(novedad.origen()).isEqualTo("PRICING");
        }

        @Test
        @DisplayName("una severidad que no reconoce degrada a DESCONOCIDA")
        void unaSeveridadDesconocidaDegrada() {
            var externo = new OhiMessageItem(1L,
                    new OhiMessageRef("A", "WARNING", "t"), "MANUAL");

            assertThat(traductor.aDominio(externo).severidad()).isEqualTo(Severidad.DESCONOCIDA);
        }

        @Test
        @DisplayName("un system nulo se lee como «no es del sistema»")
        void unSystemNuloSeLeeComoFalso() {
            var externo = new OhiMessageItem(1L,
                    new OhiMessageRef("A", "I", "t", null, null, null), "MANUAL");

            assertThat(traductor.aDominio(externo).esDelSistema()).isFalse();
        }
    }

    @Nested
    @DisplayName("CamposOhi")
    class Campos {

        @Test
        @DisplayName("las proyecciones se escriben separadas por coma; la barra la pone la solicitud")
        void seEscribenSeparadasPorComa() {
            assertThat(CamposOhi.CABECERA_CUENTA).contains(",").doesNotContain("|");
            assertThat(CamposOhi.DETALLE_LINEA).contains(",").doesNotContain("|");
        }

        @Test
        @DisplayName("toda proyección incluye el id, que es lo que gobierna el keyset")
        void todaProyeccionIncluyeElId() {
            for (var campos : java.util.List.of(
                    CamposOhi.CABECERA_CUENTA, CamposOhi.RESUMEN_LINEA, CamposOhi.DETALLE_LINEA,
                    CamposOhi.AFILIADO, CamposOhi.PRESTADOR, CamposOhi.CLAUSULA_TARIFA,
                    CamposOhi.PENDIENTE_CABECERA, CamposOhi.PENDIENTE_LINEA,
                    CamposOhi.NOVEDAD_LINEA, CamposOhi.NOVEDAD_CUENTA,
                    CamposOhi.MENSAJE_CATALOGO, CamposOhi.RESUMEN_PARA_FILTROS,
                    CamposOhi.MENSAJE_ACTIVIDAD, CamposOhi.SOLO_ID)) {
                assertThat(campos.split(",")).as("proyección %s", campos).contains("id");
            }
        }

        @Test
        @DisplayName("las proyecciones de cuenta y línea piden la versión, para el cerrojo optimista")
        void piden_laVersion() {
            assertThat(CamposOhi.CABECERA_CUENTA).contains("objectVersionNumber");
            assertThat(CamposOhi.RESUMEN_LINEA).contains("objectVersionNumber");
            assertThat(CamposOhi.DETALLE_LINEA).contains("objectVersionNumber");
            assertThat(CamposOhi.PENDIENTE_CABECERA).contains("objectVersionNumber");
        }

        @Test
        @DisplayName("las novedades piden los diez valores, porque OHI no los interpola")
        void lasNovedadesPidenLosDiezValores() {
            for (int i = 0; i < 10; i++) {
                assertThat(CamposOhi.NOVEDAD_LINEA).contains("value" + i);
                assertThat(CamposOhi.NOVEDAD_CUENTA).contains("value" + i);
            }
        }

        @Test
        @DisplayName("la proyección del pendiente de línea añade la línea a la de cabecera")
        void laDeLineaAnadeLaLinea() {
            assertThat(CamposOhi.PENDIENTE_LINEA)
                    .contains("claimLine.id").contains("claimLine.sequence");
            assertThat(CamposOhi.PENDIENTE_CABECERA).doesNotContain("claimLine");
        }

        @Test
        @DisplayName("ninguna proyección pide expand, que OHI no necesita y encarece")
        void ningunaPideExpand() {
            for (var campos : java.util.List.of(
                    CamposOhi.CABECERA_CUENTA, CamposOhi.RESUMEN_LINEA, CamposOhi.DETALLE_LINEA,
                    CamposOhi.NOVEDAD_LINEA, CamposOhi.MENSAJE_CATALOGO)) {
                assertThat(campos).doesNotContain("expand");
            }
        }

        @Test
        @DisplayName("SOLO_ID es exactamente el id, sin nada más")
        void soloIdEsExactamenteElId() {
            assertThat(CamposOhi.SOLO_ID).isEqualTo("id");
        }
    }
}
