package co.sura.auditoria.acl.ohi.adaptador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.CuerpoEnviado;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorAcciones;
import co.sura.auditoria.acl.ohi.traductor.TraductorCuenta;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorEstadoProceso;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.acl.ohi.traductor.TraductorNovedad;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.CatalogoPrestacion;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * El listado de líneas por desplazamiento, contra una {@link ExchangeFunction}
 * simulada que devuelve <b>cuerpos JSON reales</b>: así la prueba ejercita el
 * decodificador de Jackson y el codificador del sobre, que es donde se
 * manifiestan las trampas del sistema de registro.
 *
 * <p>Los cuerpos de respuesta son los que se midieron contra el entorno de
 * pruebas sobre {@code CM-35343660784} (212 líneas): {@code totalResults}
 * verdadero en cualquier posición, {@code hasMore} publicado y cierto, y
 * <b>204 sin cuerpo</b> cuando el desplazamiento llega al final.
 *
 * <p>Lo que no se cubre aquí, por estar cubierto en su sitio: la renovación del
 * token caducado, que no vive en este adaptador sino en el filtro de
 * autenticación del cliente ({@code TokenOhiTest}).
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AdaptadorConsultasOhi: líneas por desplazamiento")
class AdaptadorLineasDesplazadasOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-35343660784");
    private static final long ID_CUENTA = 35343660784L;

    @Mock ExchangeFunction intercambio;
    @Mock ConfiguracionResiliencia resiliencia;
    @Mock AdaptadorPendientesOhi adaptadorPendientes;
    @Mock AdaptadorNovedadesOhi adaptadorNovedades;
    @Mock AdaptadorAfiliadosOhi adaptadorAfiliados;
    @Mock AdaptadorPrestadoresOhi adaptadorPrestadores;
    @Mock TraductorCuenta traductorCuenta;
    @Mock TraductorEstadoProceso traductorProceso;
    @Mock TraductorAcciones traductorAcciones;

    @Captor ArgumentCaptor<ClientRequest> peticionCaptor;

    private AdaptadorConsultasOhi adaptador;

    /** Las peticiones que se han ido respondiendo, en orden. */
    private final List<String> respuestas = new ArrayList<>();

    @BeforeEach
    void montarAdaptador() {
        var webClient = WebClient.builder()
                .baseUrl("https://ohi.example/api")
                .exchangeFunction(intercambio)
                .build();

        lenient().when(resiliencia.<Object>paraConsultaPacienteMono())
                 .thenReturn(Function.identity());
        lenient().when(adaptadorPendientes.buscarDeLineas(anyList()))
                 .thenReturn(Mono.just(List.of()));
        lenient().when(adaptadorNovedades.buscarDeLineas(anyList()))
                 .thenReturn(Mono.just(List.of()));
        lenient().when(adaptadorAfiliados.nombresPorId(anyCollection()))
                 .thenReturn(Mono.just(Map.of()));

        adaptador = new AdaptadorConsultasOhi(
                webClient, resiliencia, new TraductorErrores(new ObjectMapper()),
                traductorCuenta,
                new TraductorLinea(new TraductorNovedad(), new TraductorPendiente()),
                new TraductorPendiente(), traductorProceso,
                adaptadorPendientes, adaptadorNovedades, adaptadorAfiliados,
                adaptadorPrestadores, new ResolutorIdentidadOhi(), traductorAcciones,
                webClient, new co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi());
    }

    // ─── montaje de respuestas ──────────────────────────────────────────────

    /** Una fila de línea tal como la proyecta el resumen de la grilla. */
    private static String fila(long id, int secuencia) {
        return """
                {"id": "%d", "sequence": %d,
                 "startDate": "2026-08-01", "endDate": "2026-08-01",
                 "procedure": {"id": "1", "code": "873206",
                               "flexCodeDefinitionCode": "CUPS", "descr": "Prestación"},
                 "person": {"id": "9", "code": "CC1"},
                 "authorizationCode": "AUT1",
                 "allowedAmount": {"amount": 100, "currency": "COP"},
                 "coveredAmount": {"amount": 100, "currency": "COP"},
                 "valorGlosado": 0,
                 "keepBenefits": false, "keepPricing": false,
                 "locked": false, "replaced": false,
                 "objectVersionNumber": 3}
                """.formatted(id, secuencia);
    }

    private static String paginaDe(int desde, int cuantas, long total, boolean hayMas) {
        var filas = new ArrayList<String>();
        for (int i = 0; i < cuantas; i++) {
            filas.add(fila(46_000_000_000L + desde + i, desde + i + 1));
        }
        return """
                {"items": [%s], "totalResults": %d, "hasMore": %b,
                 "count": %d, "offset": %d, "limit": 25}
                """.formatted(String.join(",", filas), total, hayMas, cuantas, desde);
    }

    /**
     * El guion de respuestas: la primera petición es siempre la de la cabecera
     * —el adaptador resuelve el código a id técnico antes de pedir líneas— y las
     * siguientes son las que diga la prueba.
     */
    private void ohiResponde(String... cuerposDeLineas) {
        var guion = new ArrayList<String>();
        guion.add("""
                {"items": [{"id": "%d", "code": "CM-35343660784"}], "totalResults": 1}
                """.formatted(ID_CUENTA));
        guion.addAll(java.util.Arrays.asList(cuerposDeLineas));

        when(intercambio.exchange(any())).thenAnswer(invocacion -> {
            int turno = respuestas.size();
            var cuerpo = turno < guion.size() ? guion.get(turno) : guion.get(guion.size() - 1);
            respuestas.add(cuerpo);
            if (cuerpo == null) {
                return Mono.just(ClientResponse.create(HttpStatus.NO_CONTENT).build());
            }
            return Mono.just(ClientResponse.create(HttpStatus.OK)
                    .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                    .body(cuerpo).build());
        });
    }

    private List<ClientRequest> peticiones() {
        verify(intercambio, times(respuestas.size())).exchange(peticionCaptor.capture());
        return peticionCaptor.getAllValues();
    }

    /** El cuerpo de la petición de líneas (la segunda; la primera es la cabecera). */
    private String cuerpoDeLineas() {
        return CuerpoEnviado.de(peticiones().get(1));
    }

    // ─── lo que se le pide al sistema de registro ───────────────────────────

    @Nested
    @DisplayName("el sobre que se envía")
    class ElSobre {

        @Test
        @Tag("F3-FIL-00")
        @DisplayName("el desplazamiento y el límite van dentro de resource")
        void elDesplazamientoVaDentroDeResource() {
            ohiResponde(paginaDe(200, 12, 212L, false));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 200, 25, FiltroLineas.NINGUNO, null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas())
                    .contains("\"offset\":200")
                    .contains("\"limit\":25")
                    .contains("\"totalResults\":true");
        }

        @Test
        @Tag("F3-ORD-01")
        @DisplayName("ordena por sequence, nunca por id: es el orden que lee el auditor")
        void ordenaPorSequenceNuncaPorId() {
            // Medido: por id las cinco primeras filas de la cuenta mayor son las
            // secuencias 2106, 2477, 2805, 2143 y 2681. Paginar por id reparte
            // las líneas en páginas sin relación con lo que se está revisando.
            ohiResponde(paginaDe(0, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas())
                    .contains("\"orderBy\":\"sequence asc\"")
                    .doesNotContain("\"orderBy\":\"id asc\"");
        }

        @Test
        @DisplayName("la proyección viaja en resourceRepresentation y con defaultoverride")
        void laProyeccionViajaConDefaultoverride() {
            // Sin defaultoverride el sistema de registro ignora `fields` y
            // devuelve el recurso entero: la consulta funciona y tarda diez veces
            // más. Y `fields` dentro de `resource` tampoco se aplica.
            ohiResponde(paginaDe(0, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .expectNextCount(1).verifyComplete();

            var cuerpo = cuerpoDeLineas();
            assertThat(cuerpo).contains("\"resourceRepresentation\"")
                              .contains("\"defaultoverride\":\"true\"")
                              .contains("sequence");
            var resource = cuerpo.substring(cuerpo.indexOf("\"resource\""));
            assertThat(resource).doesNotContain("defaultoverride");
        }

        @Test
        @DisplayName("una consulta sin desplazamiento no manda offset en nulo")
        void unaConsultaSinDesplazamientoNoMandaOffsetEnNulo() {
            // La petición de la cabecera no pagina. Al añadir `offset` al sobre
            // empezó a viajar en nulo en todas las búsquedas del servicio; la
            // exclusión de nulos es lo que lo evita.
            ohiResponde(paginaDe(0, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .expectNextCount(1).verifyComplete();

            assertThat(CuerpoEnviado.de(peticiones().get(0))).doesNotContain("offset");
        }
    }

    // ─── lo que se entiende de la respuesta ─────────────────────────────────

    @Nested
    @DisplayName("lo que se entiende de la respuesta")
    class LaRespuesta {

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("el total que acompaña a una página profunda es el verdadero, no el de la primera")
        void elTotalDeUnaPaginaProfundaEsElVerdadero() {
            ohiResponde(paginaDe(200, 12, 212L, false));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 200, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> {
                        assertThat(pagina.elementos()).hasSize(12);
                        assertThat(pagina.desplazamiento()).isEqualTo(200);
                        assertThat(pagina.total()).contains(212L);
                        assertThat(pagina.totalPaginas()).contains(9L);
                        assertThat(pagina.numeroDePagina()).isEqualTo(8);
                    })
                    .verifyComplete();
        }

        @Test
        @DisplayName("hayMas sale de hasMore: en la última página corta el avance")
        void hayMasSaleDeHasMore() {
            ohiResponde(paginaDe(200, 12, 212L, false));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 200, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> assertThat(pagina.hayMas()).isFalse())
                    .verifyComplete();
        }

        @Test
        @DisplayName("una página llena en medio de la cuenta dice que hay más")
        void unaPaginaLlenaEnMedioDiceQueHayMas() {
            ohiResponde(paginaDe(100, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 100, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> assertThat(pagina.hayMas()).isTrue())
                    .verifyComplete();
        }

        @Test
        @DisplayName("si faltara hasMore, hayMas se deduce del total")
        void siFaltaraHasMoreSeDeduceDelTotal() {
            // Hoy el sistema de registro lo publica. Esta es la red por si deja
            // de hacerlo: sin ella, una respuesta sin `hasMore` desactivaría
            // «siguiente» en la primera página de una cuenta de 212 líneas.
            ohiResponde("""
                    {"items": [%s], "totalResults": 212}
                    """.formatted(fila(46_000_000_001L, 1)));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> assertThat(pagina.hayMas()).isTrue())
                    .verifyComplete();
        }

        @Test
        @DisplayName("un 204 en el principio es una cuenta sin líneas, no un error")
        void un204EnElPrincipioEsUnaCuentaSinLineas() {
            ohiResponde((String) null);

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> {
                        assertThat(pagina.elementos()).isEmpty();
                        assertThat(pagina.hayMas()).isFalse();
                        assertThat(pagina.total()).contains(0L);
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("un 204 más allá del final NO dice que la cuenta esté vacía: "
                   + "pregunta el total aparte")
        void un204MasAllaDelFinalNoDiceQueLaCuentaEsteVacia() {
            // El fallo silencioso que esto evita: el sistema de registro responde
            // 204 sin cuerpo a un desplazamiento que ya pasó del final, así que no
            // hay total ni hasMore. Darlo por «cero líneas» enseñaría una cuenta
            // de 212 como vacía, con una sola página. Es alcanzable: basta que al
            // auditor le borren líneas con la última página abierta.
            ohiResponde(null, """
                    {"items": [{"id": "46000000001"}], "totalResults": 212, "hasMore": true}
                    """);

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 300, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> {
                        assertThat(pagina.elementos()).isEmpty();
                        assertThat(pagina.total()).contains(212L);
                        assertThat(pagina.totalPaginas()).contains(9L);
                        assertThat(pagina.hayMas()).isFalse();
                    })
                    .verifyComplete();

            // Tres peticiones: cabecera, la página vacía, y la del total.
            assertThat(respuestas).hasSize(3);
        }

        @Test
        @DisplayName("las filas llegan traducidas en el orden en que vinieron")
        void lasFilasLleganTraducidasEnOrden() {
            // Importa el orden, no solo el contenido: lo que la grilla pinta es
            // esta lista tal cual.
            ohiResponde(paginaDe(100, 3, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 100, 25, FiltroLineas.NINGUNO, null))
                    .assertNext(pagina -> assertThat(pagina.elementos())
                            .extracting(l -> l.numeroLinea())
                            .containsExactly(101, 102, 103))
                    .verifyComplete();
        }

        @Test
        @DisplayName("si la proyección pierde objectVersionNumber, el listado falla a la vista "
                   + "en vez de inventar una versión")
        void siFaltaLaVersionElListadoFalla() {
            // Caso de campo ausente: el sistema de registro no valida `fields`, así
            // que un nombre mal escrito devuelve 200 sin esa columna. Aquí la
            // versión es la que después viaja en el PATCH para el bloqueo
            // optimista: aceptar un nulo y mandar un cero haría que la escritura
            // se rechazara —o peor, que pisara otra— sin que nadie supiera por qué.
            // Que reviente al leer es el comportamiento querido, no un descuido.
            ohiResponde("""
                    {"items": [{"id": "46000000001", "sequence": 1}],
                     "totalResults": 212, "hasMore": true}
                    """);

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .expectError(NullPointerException.class)
                    .verify();
        }

        @Test
        @DisplayName("un error del sistema de registro llega como error de dominio")
        void unErrorLlegaComoErrorDeDominio() {
            when(intercambio.exchange(any())).thenReturn(Mono.just(
                    ClientResponse.create(HttpStatus.INTERNAL_SERVER_ERROR)
                            .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                            .body("{\"message\": \"algo se rompió dentro\"}")
                            .build()));
            respuestas.add("error");

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .expectError(ExcepcionDeDominio.class)
                    .verify();
        }
    }

    // ─── la línea siguiente ─────────────────────────────────────────────────

    @Nested
    @DisplayName("la línea siguiente")
    class LineaSiguiente {

        /** Aquí el guion es: secuencia de la actual, cabecera, la siguiente. */
        private void ohiRespondeParaSiguiente(String... cuerpos) {
            var guion = new java.util.ArrayList<String>(java.util.Arrays.asList(cuerpos));
            when(intercambio.exchange(any())).thenAnswer(invocacion -> {
                int turno = respuestas.size();
                var cuerpo = turno < guion.size() ? guion.get(turno) : null;
                respuestas.add(cuerpo == null ? "vacío" : cuerpo);
                if (cuerpo == null) {
                    return Mono.just(ClientResponse.create(HttpStatus.NO_CONTENT).build());
                }
                return Mono.just(ClientResponse.create(HttpStatus.OK)
                        .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                        .body(cuerpo).build());
            });
        }

        @Test
        @DisplayName("busca por número de línea mayor, no por identificador mayor")
        void buscaPorNumeroDeLineaMayor() {
            // Es el arreglo de fondo: el avance iba por identificador, y por
            // identificador la línea que sigue a la 1 puede ser la 2.106.
            ohiRespondeParaSiguiente(
                    "{\"items\": [{\"id\": \"46000000100\", \"sequence\": 101}]}",
                    "{\"items\": [{\"id\": \"35343660784\", \"code\": \"CM-35343660784\"}]}",
                    """
                    {"items": [%s], "hasMore": true}
                    """.formatted(fila(46_000_000_101L, 102)));

            StepVerifier.create(adaptador.buscarLineaSiguiente(
                            CODIGO, new co.sura.auditoria.modelo.cuenta.ReferenciaLinea(
                                    46_000_000_100L)))
                    .assertNext(linea -> assertThat(linea.numeroLinea()).isEqualTo(102))
                    .verifyComplete();

            var cuerpo = CuerpoEnviado.de(peticiones().get(2));
            assertThat(cuerpo).contains("sequence.gt(101)")
                              .contains("\"orderBy\":\"sequence asc\"")
                              .contains("\"limit\":1");
        }

        @Test
        @DisplayName("la última línea de la cuenta devuelve vacío, no un error")
        void laUltimaDevuelveVacio() {
            ohiRespondeParaSiguiente(
                    "{\"items\": [{\"id\": \"46000000212\", \"sequence\": 213}]}",
                    "{\"items\": [{\"id\": \"35343660784\", \"code\": \"CM-35343660784\"}]}",
                    null);

            StepVerifier.create(adaptador.buscarLineaSiguiente(
                            CODIGO, new co.sura.auditoria.modelo.cuenta.ReferenciaLinea(
                                    46_000_000_212L)))
                    .verifyComplete();
        }

        @Test
        @DisplayName("una referencia que no existe devuelve vacío sin preguntar por la siguiente")
        void unaReferenciaInexistenteDevuelveVacio() {
            ohiRespondeParaSiguiente((String) null);

            StepVerifier.create(adaptador.buscarLineaSiguiente(
                            CODIGO, new co.sura.auditoria.modelo.cuenta.ReferenciaLinea(1L)))
                    .verifyComplete();

            assertThat(respuestas).hasSize(1);
        }
    }

    // ─── el camino que descarta aquí ────────────────────────────────────────

    @Nested
    @DisplayName("con un criterio que el sistema de registro no sabe aplicar")
    class FiltradoAqui {

        private static final FiltroLineas POR_CATALOGO = new FiltroLineas(
                null, null, null, null, null, null, CatalogoPrestacion.CUPS, null, null,
                false, null, co.sura.auditoria.modelo.cuenta.FiltroBloqueo.TODOS, null);

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("no publica total, aunque el sistema de registro lo haya dado")
        void noPublicaTotalAunqueOhiLoHayaDado() {
            // El total que él devuelve cuenta las filas de antes de descartar:
            // publicarlo prometería páginas que no existen.
            ohiResponde(paginaDe(0, 3, 212L, false));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, POR_CATALOGO, null))
                    .assertNext(pagina -> {
                        assertThat(pagina.totalEsDeFiar()).isFalse();
                        assertThat(pagina.totalPaginas()).isEmpty();
                    })
                    .verifyComplete();
        }

        @Test
        @DisplayName("trae por lotes del tamaño máximo, no del de la página")
        void traePorLotesDelTamanoMaximo() {
            ohiResponde(paginaDe(0, 3, 212L, false));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, POR_CATALOGO, null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas()).contains("\"limit\":200");
        }

        @Test
        @DisplayName("el criterio local no viaja en la consulta: se aplica aquí")
        void elCriterioLocalNoViajaEnLaConsulta() {
            // El catálogo sí está en la proyección —hace falta traerlo para poder
            // descartar— pero no en `q`: el sistema de registro no sabe filtrar
            // por él, y mandárselo da un error del motor de consultas.
            ohiResponde(paginaDe(0, 3, 212L, false));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, POR_CATALOGO, null))
                    .expectNextCount(1).verifyComplete();

            var cuerpo = cuerpoDeLineas();
            assertThat(cuerpo).contains("\"q\":\"claim.id.eq(35343660784)\"");
            assertThat(cuerpo.substring(cuerpo.indexOf("\"q\"")))
                    .doesNotContain("flexCodeDefinitionCode");
        }
    }
    // ─── los criterios que viven en una colección hija ──────────────────────

    /**
     * Estos tres criterios <b>sí</b> se empujan, y el proyecto creyó lo contrario.
     *
     * <p>La nota que había decía que filtrar {@code claimlines} por su colección de mensajes
     * devolvía la cuenta entera —212 de 212 con el mensaje en 199— y que por eso había que
     * resolverlo en dos consultas. Era un error de medición: la verdad de referencia se había
     * leído con {@code limit=200} sobre 823 filas de mensaje, así que el conteo por código salía
     * truncado. Repetida con recorrido por clave el 17-oct-2026, el filtro acierta los cinco
     * códigos de {@code CM-35343660784} y los seis motivos de pendiente, uno a uno.
     *
     * <p>Lo que estas pruebas fijan es la <b>consulta que viaja</b>, porque es donde se pierde
     * la exactitud: un {@code resolved} que falte, o un {@code isnotnull()} en vez de
     * {@code id.gt(0)}, no fallan en voz alta.
     */
    @Nested
    @DisplayName("filtros sobre colecciones hijas de la línea")
    class ColeccionesHijas {

        private static FiltroLineas filtro(boolean conNovedad, String motivo,
                                           co.sura.auditoria.modelo.cuenta.FiltroBloqueo bloqueo,
                                           co.sura.auditoria.modelo.cuenta.EstadoCuenta estado) {
            var pedido = new FiltroLineas(null, null, null, null, null, null, null, null, null,
                                          conNovedad, motivo, bloqueo, null);
            return estado == null ? pedido : pedido.resueltoEn(estado);
        }

        @Test
        @Tag("F3-NOV-01")
        @DisplayName("«con novedad» viaja como id.gt(0), porque isnotnull() da 500")
        void conNovedadViajaComoIdMayorQueCero() {
            ohiResponde(paginaDe(0, 25, 199L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(true, null, co.sura.auditoria.modelo.cuenta.FiltroBloqueo.TODOS, null),
                            null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas())
                    .contains("claim.id.eq(35343660784).and.claimLineMessageList.id.gt(0)")
                    .doesNotContain("isnotnull");
        }

        @Test
        @Tag("F3-NOV-01")
        @DisplayName("al empujarse conserva el total del servidor: no degrada la paginación")
        void alEmpujarseConservaElTotal() {
            // Es la diferencia con el catálogo y el techo de la glosa, y la razón por la que
            // merecía la pena volver a medir: con dos consultas y recorrido local no habría total.
            ohiResponde(paginaDe(0, 25, 199L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(true, null, co.sura.auditoria.modelo.cuenta.FiltroBloqueo.TODOS, null),
                            null))
                    .assertNext(pagina -> {
                        assertThat(pagina.totalEsDeFiar()).isTrue();
                        assertThat(pagina.total()).contains(199L);
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("el motivo viaja con su resolved: sin él casaría con motivos ya resueltos")
        void elMotivoViajaConSuResolved() {
            // Medido contra la cuenta 54546131436: con resolved.eq(false) devuelve 90 líneas,
            // sin la condición devuelve 200. Las dos condiciones caen sobre la misma fila hija,
            // que es justo lo que hace que «este motivo, sin resolver» signifique eso.
            ohiResponde(paginaDe(0, 25, 90L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(false, "MP_FATAL_SIN_GLOSA",
                                   co.sura.auditoria.modelo.cuenta.FiltroBloqueo.TODOS, null),
                            null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas())
                    .contains("claimLinePendReasonList.pendReason.code.eq('MP_FATAL_SIN_GLOSA')")
                    .contains("claimLinePendReasonList.resolved.eq(false)");
        }

        @Test
        @Tag("F2-06")
        @DisplayName("«bloqueantes» fuera de adjudicación manual exige adjudicationOnly=false")
        void bloqueantesFueraDeAdjudicacionManual() {
            ohiResponde(paginaDe(0, 25, 42L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(false, null,
                                   co.sura.auditoria.modelo.cuenta.FiltroBloqueo.BLOQUEANTES,
                                   co.sura.auditoria.modelo.cuenta.EstadoCuenta.MODIFICACION),
                            null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas())
                    .contains("claimLinePendReasonList.pendReason.adjudicationOnly.eq(false)")
                    .contains("claimLinePendReasonList.resolved.eq(false)");
        }

        @Test
        @Tag("F2-06")
        @DisplayName("en adjudicación manual «bloqueantes» no añade condición: allí bloquea todo")
        void enAdjudicacionManualNoAnadeCondicion() {
            ohiResponde(paginaDe(0, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(false, null,
                                   co.sura.auditoria.modelo.cuenta.FiltroBloqueo.BLOQUEANTES,
                                   co.sura.auditoria.modelo.cuenta.EstadoCuenta.ADJUDICACION_MANUAL),
                            null))
                    .expectNextCount(1).verifyComplete();

            assertThat(cuerpoDeLineas()).doesNotContain("adjudicationOnly");
        }

        @Test
        @Tag("F2-06")
        @DisplayName("«no bloqueantes» en adjudicación manual no se le pregunta: no puede casar")
        void noBloqueantesEnAdjudicacionManualNoSePregunta() {
            // Sin predicado que lo exprese, la consulta devolvería justo lo contrario de lo
            // pedido. Así que la página sale vacía y con total cero, sin gastar la llamada.
            ohiResponde(paginaDe(0, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(false, null,
                                   co.sura.auditoria.modelo.cuenta.FiltroBloqueo.NO_BLOQUEANTES,
                                   co.sura.auditoria.modelo.cuenta.EstadoCuenta.ADJUDICACION_MANUAL),
                            null))
                    .assertNext(pagina -> {
                        assertThat(pagina.elementos()).isEmpty();
                        assertThat(pagina.total()).contains(0L);
                        assertThat(pagina.hayMas()).isFalse();
                    })
                    .verifyComplete();

            // Solo la resolución del código de cuenta: nunca se pidió la página de líneas.
            assertThat(peticiones()).hasSize(1);
        }

        @Test
        @Tag("F2-06")
        @DisplayName("pedir bloqueo resuelve el estado de la cuenta una vez, y no si no se pide")
        void pideElEstadoSoloCuandoHaceFalta() {
            when(adaptadorPendientes.estadoDeLaCuenta(ID_CUENTA))
                    .thenReturn(Mono.just(co.sura.auditoria.modelo.cuenta.EstadoCuenta.MODIFICACION));
            ohiResponde(paginaDe(0, 25, 42L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25,
                            filtro(false, null,
                                   co.sura.auditoria.modelo.cuenta.FiltroBloqueo.BLOQUEANTES, null),
                            null))
                    .expectNextCount(1).verifyComplete();

            verify(adaptadorPendientes).estadoDeLaCuenta(ID_CUENTA);
            assertThat(cuerpoDeLineas()).contains("adjudicationOnly.eq(false)");
        }

        @Test
        @Tag("F3-NOV-01")
        @DisplayName("sin filtro de bloqueo no se consulta el estado: cuesta una llamada")
        void sinBloqueoNoConsultaElEstado() {
            ohiResponde(paginaDe(0, 25, 212L, true));

            StepVerifier.create(adaptador.listarResumenLineasPorDesplazamiento(
                            CODIGO, 0, 25, FiltroLineas.NINGUNO, null))
                    .expectNextCount(1).verifyComplete();

            verify(adaptadorPendientes, org.mockito.Mockito.never()).estadoDeLaCuenta(anyLong());
        }
    }
}
