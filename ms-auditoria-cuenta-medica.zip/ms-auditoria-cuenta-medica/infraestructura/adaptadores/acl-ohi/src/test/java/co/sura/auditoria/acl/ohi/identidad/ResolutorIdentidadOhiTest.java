package co.sura.auditoria.acl.ohi.identidad;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ResolutorIdentidadOhi")
class ResolutorIdentidadOhiTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final CodigoCuenta OTRO = new CodigoCuenta("CM-107129871547");

    @Mock ResolutorIdentidadOhi.BuscadorPorCodigo buscador;

    private ResolutorIdentidadOhi resolutor;

    @BeforeEach
    void nuevoResolutor() {
        resolutor = new ResolutorIdentidadOhi();
    }

    @Test
    @DisplayName("la primera vez pregunta al buscador externo")
    void laPrimeraVezPreguntaAlBuscador() {
        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.just(108800618430L));

        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNext(108800618430L)
                .verifyComplete();

        verify(buscador).buscar("CM-108800618430");
    }

    @Test
    @DisplayName("la segunda vez sale de la caché y NO vuelve a preguntar")
    void laSegundaVezSaleDeLaCache() {
        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.just(108800618430L));

        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNextCount(1).verifyComplete();
        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNext(108800618430L).verifyComplete();

        verify(buscador, times(1)).buscar("CM-108800618430");
        verifyNoMoreInteractions(buscador);
    }

    @Test
    @DisplayName("cada código se cachea por separado")
    void cadaCodigoSeCacheaPorSeparado() {
        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.just(1L));
        when(buscador.buscar("CM-107129871547")).thenReturn(Mono.just(2L));

        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNext(1L).verifyComplete();
        StepVerifier.create(resolutor.resolverParaCuenta(OTRO, buscador))
                .expectNext(2L).verifyComplete();

        verify(buscador).buscar("CM-108800618430");
        verify(buscador).buscar("CM-107129871547");
    }

    @Test
    @DisplayName("invalidar obliga a volver a preguntar")
    void invalidarObligaAVolverAPreguntar() {
        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.just(1L));

        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNextCount(1).verifyComplete();
        resolutor.invalidar(CODIGO);
        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNextCount(1).verifyComplete();

        verify(buscador, times(2)).buscar("CM-108800618430");
    }

    @Test
    @DisplayName("invalidar un código que no está cacheado no rompe nada")
    void invalidarUnCodigoNoCacheadoNoRompe() {
        resolutor.invalidar(CODIGO);   // nunca se resolvió

        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.just(1L));
        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNext(1L).verifyComplete();
    }

    @Test
    @DisplayName("un buscador que no encuentra nada no cachea: el vacío no se memoriza")
    void unVacioNoSeCachea() {
        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.empty());

        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador)).verifyComplete();
        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador)).verifyComplete();

        // Si el vacío se cacheara, la cuenta quedaría marcada como inexistente
        // durante diez minutos aunque apareciera un segundo después.
        verify(buscador, times(2)).buscar("CM-108800618430");
    }

    @Test
    @DisplayName("un error tampoco se cachea")
    void unErrorNoSeCachea() {
        when(buscador.buscar("CM-108800618430"))
                .thenReturn(Mono.error(new IllegalStateException("OHI caído")))
                .thenReturn(Mono.just(1L));

        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .verifyError(IllegalStateException.class);
        StepVerifier.create(resolutor.resolverParaCuenta(CODIGO, buscador))
                .expectNext(1L).verifyComplete();
    }

    @Test
    @DisplayName("la caché se dimensiona por configuración, no cableada")
    void laCacheSeDimensionaPorConfiguracion() {
        // El dimensionamiento es el arreglo: con 500 entradas, una prueba de carga sobre
        // miles de cuentas desfondaba la caché y duplicaba el tráfico contra OHI.
        var apretado = new ResolutorIdentidadOhi(2L, java.time.Duration.ofHours(2));
        when(buscador.buscar(org.mockito.ArgumentMatchers.anyString()))
                .thenAnswer(i -> Mono.just(1L));

        for (int i = 0; i < 50; i++) {
            apretado.resolverParaCuenta(new CodigoCuenta("CM-" + i), buscador).block();
        }
        apretado.cacheNativa().cleanUp();

        assertThat(apretado.cacheNativa().estimatedSize())
                .as("con maximumSize=2 la caché no puede retener las 50")
                .isLessThanOrEqualTo(2L);
    }

    @Test
    @DisplayName("el constructor por omisión deja sitio de sobra: 50.000 entradas")
    void elConstructorPorOmisionDejaSitioDeSobra() {
        when(buscador.buscar(org.mockito.ArgumentMatchers.anyString()))
                .thenAnswer(i -> Mono.just(1L));

        for (int i = 0; i < 2_000; i++) {
            resolutor.resolverParaCuenta(new CodigoCuenta("CM-" + i), buscador).block();
        }
        resolutor.cacheNativa().cleanUp();

        assertThat(resolutor.cacheNativa().estimatedSize())
                .as("2.000 cuentas distintas deberían caber sin desalojar nada")
                .isEqualTo(2_000L);
    }

    @Test
    @DisplayName("la caché publica estadísticas, que es lo que enlaza Micrometer")
    void laCachePublicaEstadisticas() {
        when(buscador.buscar("CM-108800618430")).thenReturn(Mono.just(1L));

        resolutor.resolverParaCuenta(CODIGO, buscador).block();   // fallo
        resolutor.resolverParaCuenta(CODIGO, buscador).block();   // acierto

        var estadisticas = resolutor.cacheNativa().stats();
        assertThat(estadisticas.missCount()).isEqualTo(1L);
        assertThat(estadisticas.hitCount()).isEqualTo(1L);
    }

    @Test
    @DisplayName("para un pendiente, el identificador de dominio es el mismo de OHI")
    void paraUnPendienteElIdentificadorEsElMismo() {
        assertThat(resolutor.resolverParaPendiente(4242L)).isEqualTo(4242L);
    }
}
