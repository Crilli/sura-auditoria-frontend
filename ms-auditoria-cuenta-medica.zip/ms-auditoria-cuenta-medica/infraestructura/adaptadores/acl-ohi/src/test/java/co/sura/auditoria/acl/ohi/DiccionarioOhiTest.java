package co.sura.auditoria.acl.ohi;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.DecisionEnvio;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.Severidad;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("DiccionarioOhi")
class DiccionarioOhiTest {

    @Nested
    @DisplayName("estados de cuenta")
    class Estados {

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({
                "INITIAL,                      INICIAL",
                "ENTRY,                        DIGITACION",
                "CHANGE,                       MODIFICACION",
                "MANUAL PRICING,               TARIFACION_MANUAL",
                "MANUAL BENEFITS,              BENEFICIOS_MANUALES",
                "MANUAL ADJUDICATION,          ADJUDICACION_MANUAL",
                "MANUAL PRICING ADJUDICATION,  TARIFACION_ADJUDICACION_MANUAL",
                "PRICING DONE,                 TARIFACION_COMPLETA",
                "BENEFITS DONE,                BENEFICIOS_COMPLETOS",
                "ADJUDICATION DONE,            ADJUDICACION_COMPLETA",
                "PRICING ADJUDICATION DONE,    TARIFACION_ADJUDICACION_COMPLETA",
                "PRICING FINALIZED,            TARIFACION_FINALIZADA",
                "SENT OUT FOR PREPROCESSING,   ENVIADA_A_PREPROCESO",
                "SENT OUT FOR PRICING,         ENVIADA_A_TARIFACION",
                "FINALIZED,                    FINALIZADA",
                "IN PROCESS,                   EN_PROCESO"
        })
        @DisplayName("traduce el estado tal como OHI lo almacena, con espacios incluidos")
        void traduceLosEstadosConEspacios(String externo, EstadoCuenta esperado) {
            // Ojo: en `q` los valores llevan espacio («MANUAL ADJUDICATION»), mientras que
            // en groupBy OHI los devuelve pegados («ManualAdjudication»). Aquí manda el de `q`.
            assertThat(DiccionarioOhi.aEstado(externo)).isEqualTo(esperado);
        }

        @ParameterizedTest(name = "[{0}] -> ANULADA")
        @ValueSource(strings = {"CANCELLED", "CANCELED"})
        @DisplayName("acepta las dos grafías de «anulada», la británica y la americana")
        void aceptaLasDosGrafiasDeAnulada(String externo) {
            assertThat(DiccionarioOhi.aEstado(externo)).isEqualTo(EstadoCuenta.ANULADA);
        }

        @ParameterizedTest(name = "[{0}] -> FINALIZADA")
        @ValueSource(strings = {"finalized", "Finalized", "  FINALIZED  "})
        @DisplayName("no distingue mayúsculas ni respeta espacios de alrededor")
        void noDistingueMayusculasNiEspacios(String externo) {
            assertThat(DiccionarioOhi.aEstado(externo)).isEqualTo(EstadoCuenta.FINALIZADA);
        }

        @ParameterizedTest(name = "[{0}] -> DESCONOCIDO")
        @NullAndEmptySource
        @ValueSource(strings = {"  ", "ManualAdjudication", "ESTADO_NUEVO"})
        @DisplayName("lo que no conoce degrada a DESCONOCIDO en vez de fallar")
        void loDesconocidoDegrada(String externo) {
            // «ManualAdjudication» es la forma de groupBy: pegar eso en q da 204,
            // y aquí tiene que caer en DESCONOCIDO, no colarse como válido.
            assertThat(DiccionarioOhi.aEstado(externo)).isEqualTo(EstadoCuenta.DESCONOCIDO);
        }
    }

    @Nested
    @DisplayName("estados del histórico de versiones")
    class EstadosDelHistorico {

        // Las doce parejas medidas el 2026-10-19 en UAT, casando cada sello del histórico con
        // su fila de claimstatushistory al milisegundo. Ninguna discrepó.
        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({
                "Inicial,                    INICIAL",
                "Entrada,                    DIGITACION",
                "Cambiar,                    MODIFICACION",
                "Valorización Manual,        TARIFACION_MANUAL",
                "Beneficios Manual,          BENEFICIOS_MANUALES",
                "Pendiente,                  ADJUDICACION_MANUAL",
                "Adjud. Valorización Manual, TARIFACION_ADJUDICACION_MANUAL",
                "Valorización Hecha,         TARIFACION_COMPLETA",
                "Beneficios Hecho,           BENEFICIOS_COMPLETOS",
                "Aprobación Hecha,           ADJUDICACION_COMPLETA",
                "Adjud. Valorización Hecha,  TARIFACION_ADJUDICACION_COMPLETA",
                "Finalizado,                 FINALIZADA"
        })
        @Tag("BUS-19")
        @DisplayName("la palabra en español del histórico es el mismo estado que el de la cuenta")
        void traduceElEspanolDeOhi(String externo, EstadoCuenta esperado) {
            assertThat(DiccionarioOhi.aEstadoDelHistorico(externo)).isEqualTo(esperado);
            assertThat(DiccionarioOhi.estadoDelHistoricoLegible(externo)).isEqualTo(esperado.name());
        }

        @Test
        @Tag("BUS-19")
        @DisplayName("«Pendiente» es la adjudicación manual, no un motivo de pendiente")
        void pendienteEsAdjudicacionManual() {
            assertThat(DiccionarioOhi.aEstadoDelHistorico("Pendiente"))
                    .isEqualTo(DiccionarioOhi.aEstado("MANUAL ADJUDICATION"));
        }

        @ParameterizedTest(name = "[{0}] -> FINALIZADA")
        @ValueSource(strings = {"finalizado", "FINALIZADO", "  Finalizado  "})
        @Tag("BUS-19")
        @DisplayName("no distingue mayúsculas ni respeta espacios de alrededor")
        void noDistingueMayusculas(String externo) {
            assertThat(DiccionarioOhi.aEstadoDelHistorico(externo)).isEqualTo(EstadoCuenta.FINALIZADA);
        }

        @Test
        @Tag("BUS-19")
        @DisplayName("lo que no conoce se publica tal cual, y sin estado sigue sin estado")
        void loDesconocidoSePublicaTalCual() {
            assertThat(DiccionarioOhi.estadoDelHistoricoLegible("Estado Nuevo")).isEqualTo("Estado Nuevo");
            // El inglés de claims no es el vocabulario del histórico: no se cuela por aquí.
            assertThat(DiccionarioOhi.aEstadoDelHistorico("FINALIZED")).isEqualTo(EstadoCuenta.DESCONOCIDO);
            assertThat(DiccionarioOhi.estadoDelHistoricoLegible(null)).isNull();
        }
    }

    @Nested
    @DisplayName("acciones")
    class Acciones {

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({
                "claim:submit,               ENVIAR",
                "claim:status,               SEGUIR_PROCESO",
                "claim:resolvepend,          RESOLVER_PENDIENTE",
                "claim:resolveclaimlinepend, RESOLVER_PENDIENTE_LINEA",
                "claim:tochange,             DEVOLVER_A_MODIFICACION",
                "claim:tomanualbenefits,     DEVOLVER_A_BENEFICIOS_MANUALES",
                "claim:tomanualpricing,      DEVOLVER_A_TARIFACION_MANUAL",
                "claim:unfinalize,           REVERTIR_FINALIZACION",
                "claim:unlocklines,          DESBLOQUEAR_LINEAS",
                "claim:undolinereplacements, DESHACER_REEMPLAZOS",
                "claim:cancel,               ANULAR"
        })
        @DisplayName("traduce la relación del enlace a la acción de dominio")
        void traduceLaRelacionALaAccion(String relacion, AccionCuenta esperada) {
            assertThat(DiccionarioOhi.aAccion(relacion)).contains(esperada);
        }

        @ParameterizedTest(name = "[{0}] no es una acción")
        @ValueSource(strings = {"canonical", "self", "claim:desconocida", "CLAIM:SUBMIT"})
        @DisplayName("una relación que no es una acción se descarta, y distingue mayúsculas")
        void unaRelacionQueNoEsAccionSeDescarta(String relacion) {
            assertThat(DiccionarioOhi.aAccion(relacion)).isEmpty();
        }

        @ParameterizedTest
        @EnumSource(AccionCuenta.class)
        @DisplayName("la ida y la vuelta son coherentes para todas las acciones")
        void laIdaYLaVueltaSonCoherentes(AccionCuenta accion) {
            assertThat(DiccionarioOhi.relacionDe(accion))
                    .hasValueSatisfying(relacion ->
                            assertThat(DiccionarioOhi.aAccion(relacion)).contains(accion));
        }
    }

    @Nested
    @DisplayName("operaciones ejecutables")
    class Operaciones {

        @ParameterizedTest(name = "{0} -> {1}")
        @CsvSource({
                "ANULAR,                         cancel",
                "REVERTIR_FINALIZACION,          unfinalize",
                "DEVOLVER_A_MODIFICACION,        tochange",
                "DEVOLVER_A_BENEFICIOS_MANUALES, tomanualbenefits",
                "DEVOLVER_A_TARIFACION_MANUAL,   tomanualpricing",
                "DESBLOQUEAR_LINEAS,             unlocklines",
                "DESHACER_REEMPLAZOS,            undolinereplacements"
        })
        @DisplayName("las que se ejecutan como acción dan su segmento de ruta")
        void lasEjecutablesDanSuSegmento(AccionCuenta accion, String operacion) {
            assertThat(DiccionarioOhi.seEjecutaComoAccion(accion)).isTrue();
            assertThat(DiccionarioOhi.operacionDe(accion)).isEqualTo(operacion);
        }

        @ParameterizedTest(name = "{0} NO va por esa vía")
        @EnumSource(value = AccionCuenta.class,
                names = {"ENVIAR", "SEGUIR_PROCESO", "RESOLVER_PENDIENTE",
                         "RESOLVER_PENDIENTE_LINEA"})
        @DisplayName("enviar, seguir y resolver tienen su propio endpoint, no el genérico")
        void lasQueTienenEndpointPropioNoVanPorAhi(AccionCuenta accion) {
            assertThat(DiccionarioOhi.seEjecutaComoAccion(accion)).isFalse();
            assertThatThrownBy(() -> DiccionarioOhi.operacionDe(accion))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("no se ejecuta por la vía de las acciones");
        }
    }

    @Nested
    @DisplayName("severidad")
    class SeveridadDeNovedad {

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({"I, INFORMATIVA", "F, BLOQUEANTE", "D, NEGACION"})
        @DisplayName("OHI usa las letras I, F y D, no las palabras completas")
        void ohiUsaLasLetras(String externa, Severidad esperada) {
            assertThat(DiccionarioOhi.aSeveridad(externa)).isEqualTo(esperada);
        }

        @ParameterizedTest(name = "[{0}] -> DESCONOCIDA")
        @NullAndEmptySource
        @ValueSource(strings = {"INFO", "WARNING", "FATAL", "X"})
        @DisplayName("las palabras completas NO son válidas: caen en DESCONOCIDA")
        void lasPalabrasCompletasNoSonValidas(String externa) {
            // Asumir INFO/WARNING/FATAL dejaba toda novedad en DESCONOCIDA; esta
            // prueba fija que el contrato real son las letras.
            assertThat(DiccionarioOhi.aSeveridad(externa)).isEqualTo(Severidad.DESCONOCIDA);
        }

        @ParameterizedTest(name = "[{0}] también se reconoce")
        @ValueSource(strings = {"i", "f", "  d  "})
        @DisplayName("no distingue mayúsculas ni espacios")
        void noDistingueMayusculasNiEspacios(String externa) {
            assertThat(DiccionarioOhi.aSeveridad(externa)).isNotEqualTo(Severidad.DESCONOCIDA);
        }
    }

    @Nested
    @DisplayName("avance del proceso")
    class Avance {

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({
                "notStarted, NO_INICIADO",
                "processing, EN_PROCESO",
                "succeeded,  EXITOSO",
                "failed,     FALLIDO"
        })
        @DisplayName("traduce los cuatro avances que publica OHI")
        void traduceLosCuatroAvances(String externo, EstadoProceso.Avance esperado) {
            assertThat(DiccionarioOhi.aAvance(externo)).isEqualTo(esperado);
        }

        @ParameterizedTest(name = "[{0}] -> NO_INICIADO")
        @ValueSource(strings = {"NOTSTARTED", "Processing", "otro"})
        @DisplayName("aquí SÍ distingue mayúsculas, y lo desconocido cae en NO_INICIADO")
        void aquiSiDistingueMayusculas(String externo) {
            assertThat(DiccionarioOhi.aAvance(externo))
                    .isEqualTo(EstadoProceso.Avance.NO_INICIADO);
        }

        @Test
        @DisplayName("un avance nulo también cae en NO_INICIADO")
        void unAvanceNuloCaeEnNoIniciado() {
            assertThat(DiccionarioOhi.aAvance(null))
                    .isEqualTo(EstadoProceso.Avance.NO_INICIADO);
        }
    }

    @Nested
    @DisplayName("indicadores Y/N")
    class Indicadores {

        @Test
        @DisplayName("se escriben como Y y N, que es lo que ctrclaims espera")
        void seEscribenComoYN() {
            assertThat(DiccionarioOhi.desdeIndicador(true)).isEqualTo("Y");
            assertThat(DiccionarioOhi.desdeIndicador(false)).isEqualTo("N");
        }

        @ParameterizedTest(name = "[{0}] se lee como verdadero")
        @ValueSource(strings = {"Y", "y"})
        @DisplayName("solo Y es verdadero, sin distinguir mayúsculas")
        void soloYEsVerdadero(String valor) {
            assertThat(DiccionarioOhi.aIndicador(valor)).isTrue();
        }

        @ParameterizedTest(name = "[{0}] se lee como falso")
        @NullAndEmptySource
        @ValueSource(strings = {"N", "n", "true", "1", "S"})
        @DisplayName("cualquier otra cosa es falso, incluidos null, «true» y «S»")
        void cualquierOtraCosaEsFalso(String valor) {
            assertThat(DiccionarioOhi.aIndicador(valor)).isFalse();
        }

        @Test
        @DisplayName("la sobrecarga de Boolean trata el nulo como falso")
        void laSobrecargaDeBooleanTrataNuloComoFalso() {
            assertThat(DiccionarioOhi.aIndicador((Boolean) null)).isFalse();
            assertThat(DiccionarioOhi.aIndicador(Boolean.TRUE)).isTrue();
            assertThat(DiccionarioOhi.aIndicador(Boolean.FALSE)).isFalse();
        }
    }

    @Nested
    @DisplayName("otras conversiones de salida")
    class OtrasConversiones {

        @Test
        @DisplayName("la decisión de envío va como accept o deny")
        void laDecisionVaComoAcceptODeny() {
            assertThat(DiccionarioOhi.desdeDecision(DecisionEnvio.Decision.ACEPTAR))
                    .isEqualTo("accept");
            assertThat(DiccionarioOhi.desdeDecision(DecisionEnvio.Decision.DENEGAR))
                    .isEqualTo("deny");
        }

        @Test
        @DisplayName("el modo de recálculo viaja como booleano en texto, no como etiqueta")
        void elModoDeRecalculoViajaComoBooleano() {
            assertThat(DiccionarioOhi.desdeModoRecalculo(ModoRecalculo.EN_CASCADA))
                    .isEqualTo("true");
            assertThat(DiccionarioOhi.desdeModoRecalculo(ModoRecalculo.AISLADO))
                    .isEqualTo("false");
        }

        @Test
        @DisplayName("el nivel del pendiente va como «claim» o «claim line», con espacio")
        void elNivelVaComoClaimOClaimLine() {
            assertThat(DiccionarioOhi.desdeNivelPendiente(NivelPendiente.CABECERA))
                    .isEqualTo("claim");
            assertThat(DiccionarioOhi.desdeNivelPendiente(NivelPendiente.LINEA))
                    .isEqualTo("claim line");
        }

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({"C, CUENTA_MEDICA", "R, AUTORIZACION", "A, AMBAS", "c, CUENTA_MEDICA"})
        @DisplayName("el ámbito del motivo de desfinalización se lee de una letra")
        void elAmbitoSeLeeDeUnaLetra(String externo, MotivoDesfinalizacion.Ambito esperado) {
            assertThat(DiccionarioOhi.aAmbitoDeMotivo(externo)).isEqualTo(esperado);
        }

        @ParameterizedTest(name = "[{0}] -> DESCONOCIDO")
        @NullAndEmptySource
        @ValueSource(strings = {"X", "CUENTA"})
        @DisplayName("un ámbito que no reconoce degrada a DESCONOCIDO")
        void unAmbitoDesconocidoDegrada(String externo) {
            assertThat(DiccionarioOhi.aAmbitoDeMotivo(externo))
                    .isEqualTo(MotivoDesfinalizacion.Ambito.DESCONOCIDO);
        }
    }

    @Nested
    @DisplayName("explicación de los fallos de resolución")
    class ExplicacionDeFallos {

        @ParameterizedTest(name = "{0}")
        @CsvSource(delimiter = '|', value = {
                "CLA-IP-RPND-001 | El motivo no existe en el catálogo",
                "CLA-IP-RPND-002 | La cuenta no existe o ya no está disponible",
                "CLA-IP-RPND-003 | La línea no existe o ya no está disponible",
                "CLA-IP-RPND-004 | La línea no pertenece a esta cuenta",
                "CLA-IP-RPND-006 | No tiene permiso sobre alguno de los motivos",
                "CLA-IP-RPND-007 | El nivel de resolución no es válido",
                "CLA-IP-RPND-008 | No se indicó ningún motivo",
                "CLA-IP-RPND-009 | No se indicó ninguna cuenta"
        })
        @DisplayName("cada código conocido tiene su explicación en español")
        void cadaCodigoTieneSuExplicacion(String codigo, String explicacion) {
            assertThat(DiccionarioOhi.explicacionDeFalloDeResolucion(codigo))
                    .isEqualTo(explicacion);
        }

        @Test
        @DisplayName("el de gran cuantía explica por qué no se puede resolver por línea")
        void elDeGranCuantiaExplicaElPorQue() {
            assertThat(DiccionarioOhi.explicacionDeFalloDeResolucion("CLA-IP-RPND-005"))
                    .contains("gran cuantía");
        }

        @Test
        @DisplayName("un código desconocido se devuelve dentro del mensaje, sin tragárselo")
        void unCodigoDesconocidoSeDevuelveEnElMensaje() {
            assertThat(DiccionarioOhi.explicacionDeFalloDeResolucion("CLA-XX-999"))
                    .contains("CLA-XX-999");
        }

        @Test
        @DisplayName("un código nulo no revienta")
        void unCodigoNuloNoRevienta() {
            assertThat(DiccionarioOhi.explicacionDeFalloDeResolucion(null)).isNotBlank();
        }
    }
}
