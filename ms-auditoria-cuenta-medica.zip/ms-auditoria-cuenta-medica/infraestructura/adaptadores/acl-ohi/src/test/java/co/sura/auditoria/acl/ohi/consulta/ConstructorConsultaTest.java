package co.sura.auditoria.acl.ohi.consulta;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("ConstructorConsulta")
class ConstructorConsultaTest {

    @Nested
    @DisplayName("igualdad")
    class Igualdad {

        @Test
        @DisplayName("un texto va entre comillas simples")
        void unTextoVaEntreComillas() {
            assertThat(ConstructorConsulta.igual("code", "CM-108800618430").construir())
                    .isEqualTo("code.eq('CM-108800618430')");
        }

        @Test
        @DisplayName("un número va SIN comillas")
        void unNumeroVaSinComillas() {
            assertThat(ConstructorConsulta.igual("id", 148111592284L).construir())
                    .isEqualTo("id.eq(148111592284)");
        }

        @Test
        @DisplayName("un booleano va sin comillas: con comillas OHI devuelve el conjunto contrario")
        void unBooleanoVaSinComillas() {
            // Medido en OHI: cualquier cadena se convierte a false en silencio,
            // así que eq("Y") y eq("N") devuelven lo mismo.
            assertThat(ConstructorConsulta.igual("reversal", false).construir())
                    .isEqualTo("reversal.eq(false)");
            assertThat(ConstructorConsulta.igual("reversal", true).construir())
                    .isEqualTo("reversal.eq(true)");
        }
    }

    @Nested
    @DisplayName("escapado")
    class Escapado {

        @Test
        @DisplayName("una comilla simple se duplica, que es como se escapa en OHI")
        void unaComillaSimpleSeDuplica() {
            assertThat(ConstructorConsulta.igual("nombre", "O'Brien").construir())
                    .isEqualTo("nombre.eq('O''Brien')");
        }

        @Test
        @DisplayName("un intento de romper la expresión queda neutralizado")
        void unIntentoDeRomperLaExpresionQuedaNeutralizado() {
            var consulta = ConstructorConsulta.igual("code", "x').or.(id.gt(0").construir();

            // La comilla que cerraría el literal queda duplicada: no abre una cláusula nueva.
            assertThat(consulta).isEqualTo("code.eq('x'').or.(id.gt(0')");
        }

        @Test
        @DisplayName("en un prefijo también se escapan los comodines % y _")
        void enUnPrefijoSeEscapanLosComodines() {
            var consulta = ConstructorConsulta.igual("code", "CM-1")
                    .yEmpiezaPor("descr", "50%_x").construir();

            assertThat(consulta).endsWith(".and.descr.likeic('50\\%\\_x%')");
        }
    }

    @Nested
    @DisplayName("listas")
    class Listas {

        @Test
        @DisplayName("in() de textos entrecomilla cada elemento")
        void inDeTextosEntrecomillaCadaElemento() {
            assertThat(ConstructorConsulta.contenidoEn("code", List.of("A", "B", "C")).construir())
                    .isEqualTo("code.in('A','B','C')");
        }

        @Test
        @DisplayName("in() de identificadores va sin comillas")
        void inDeIdentificadoresVaSinComillas() {
            assertThat(ConstructorConsulta.contenidoEnIds("id", List.of(1L, 2L)).construir())
                    .isEqualTo("id.in(1,2)");
        }

        @Test
        @DisplayName("una lista de un solo elemento no lleva coma suelta")
        void unaListaDeUnElementoNoLlevaComaSuelta() {
            assertThat(ConstructorConsulta.contenidoEn("code", List.of("A")).construir())
                    .isEqualTo("code.in('A')");
        }

        @Test
        @DisplayName("los textos de una lista también se escapan")
        void losTextosDeUnaListaTambienSeEscapan() {
            assertThat(ConstructorConsulta.contenidoEn("n", List.of("O'B")).construir())
                    .isEqualTo("n.in('O''B')");
        }
    }

    @Nested
    @DisplayName("composición")
    class Composicion {

        @Test
        @DisplayName("y() encadena con .and.")
        void yEncadenaConAnd() {
            var consulta = ConstructorConsulta.igual("code", "CM-1")
                    .y(ConstructorConsulta.igual("reversal", false)).construir();

            assertThat(consulta).isEqualTo("code.eq('CM-1').and.reversal.eq(false)");
        }

        @Test
        @DisplayName("o() agrupa la alternativa entre paréntesis, para no alterar la precedencia")
        void oAgrupaEntreParentesis() {
            var consulta = ConstructorConsulta.igual("a", "1")
                    .o(ConstructorConsulta.igual("b", "2")).construir();

            assertThat(consulta).isEqualTo("a.eq('1').or.(b.eq('2'))");
        }

        @Test
        @DisplayName("el keyset se arma con gt sobre el mismo campo que ordena")
        void elKeysetSeArmaConGt() {
            var consulta = ConstructorConsulta.igual("claim.code", "CM-1")
                    .yMayorQue("id", 148111592284L).construir();

            assertThat(consulta).isEqualTo("claim.code.eq('CM-1').and.id.gt(148111592284)");
        }

        @Test
        @DisplayName("se encadenan varios criterios en el orden en que se piden")
        void seEncadenanVariosCriterios() {
            var consulta = ConstructorConsulta.igual("claim.code", "CM-1")
                    .yIgual("person.code", "CC1")
                    .yDesde("startDate", "2026-01-01")
                    .yHasta("startDate", "2026-02-01")
                    .yMenorQue("id", 500L)
                    .construir();

            assertThat(consulta).isEqualTo(
                    "claim.code.eq('CM-1')"
                  + ".and.person.code.eq('CC1')"
                  + ".and.startDate.gte('2026-01-01')"
                  + ".and.startDate.lte('2026-02-01')"
                  + ".and.id.lt(500)");
        }

        @Test
        @DisplayName("la comparación sin caja usa eqic, no eq")
        void laComparacionSinCajaUsaEqic() {
            assertThat(ConstructorConsulta.igual("a", "1").yIgualSinCaja("b", "Cups").construir())
                    .endsWith(".and.b.eqic('Cups')");
        }

        @Test
        @DisplayName("yIgual con booleano no entrecomilla")
        void yIgualConBooleanoNoEntrecomilla() {
            assertThat(ConstructorConsulta.igual("a", "1").yIgual("reversal", false).construir())
                    .endsWith(".and.reversal.eq(false)");
        }

        @Test
        @DisplayName("yContenidoEn añade un in() encadenado")
        void yContenidoEnAnadeUnInEncadenado() {
            assertThat(ConstructorConsulta.igual("a", "1")
                    .yContenidoEn("code", List.of("X", "Y")).construir())
                    .endsWith(".and.code.in('X','Y')");
        }
    }

    @Test
    @DisplayName("solo usa operadores que OHI acepta: ni ge, ni le, ni ne, que dan 500")
    void soloUsaOperadoresQueOhiAcepta() {
        var consulta = ConstructorConsulta.igual("a", "1")
                .yDesde("f", "2026-01-01").yHasta("f", "2026-02-01")
                .yMayorQue("id", 1L).yMenorQue("id", 9L)
                .construir();

        assertThat(consulta)
                .contains(".gte(").contains(".lte(").contains(".gt(").contains(".lt(")
                .doesNotContain(".ge(").doesNotContain(".le(").doesNotContain(".ne(");
    }
}
