package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Parche de una línea dentro del PATCH de la cuenta.
 *
 * <p>Los nombres y los tipos son los de la definición {@code claimline} de
 * {@code GET /claimsupdate/definition}, que es el contrato de <em>escritura</em> y
 * no coincide campo por campo con el de consulta: los importes viajan como objeto
 * con moneda y valor ({@link OhiMonto}) mientras que las unidades y el valor
 * glosado son escalares.
 *
 * <p>Se serializa sin nulos a propósito. El criterio del comando de dominio es que
 * un campo ausente significa «no tocar», y la única forma de decírselo a OHI es no
 * mandar la propiedad: una propiedad presente en nulo es una orden de borrar el
 * valor que ya está guardado. Sin esto, un parche que solo cambia las observaciones
 * de glosa viajaría con el resto de los campos en nulo.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record OhiLinePatch(
        Long id,
        String op,                  // add | replace | remove
        Long objectVersionNumber,

        // ── importes y cantidades ──────────────────────────────────────────
        OhiMonto claimedAmount,
        BigDecimal claimedNumberOfUnits,
        OhiMonto allowedAmount,
        BigDecimal allowedNumberOfUnits,
        BigDecimal valorGlosado,
        /** Máximo 1000 caracteres según el contrato de /claimsupdate. */
        String observacionesGlosa,

        // ── atención ───────────────────────────────────────────────────────
        /** Máximo 30 caracteres. */
        String authorizationCode,
        LocalDate startDate,
        LocalDate endDate,

        // ── prestación ─────────────────────────────────────────────────────
        /** Máximo 30 caracteres. */
        String prestacionCodigoNoDefinido,
        /** Máximo 30 caracteres. */
        String prestacionCodigoNoDefinidoDef,
        /** Máximo 100 caracteres. */
        String archivoRIPSDescrPrestacion,

        // ── convenio ───────────────────────────────────────────────────────
        /** Máximo 30 caracteres. */
        String numeroContrato,
        /** Máximo 30 caracteres. */
        String homologoCups,
        /** Máximo 300 caracteres. */
        String codigoUnicoContratoSIIFA,

        // ── siniestro ──────────────────────────────────────────────────────
        /** Máximo 20 caracteres. */
        String codigoSiniestro,

        Boolean keepBenefits,
        Boolean keepPricing) {}
