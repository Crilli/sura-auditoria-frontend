package co.sura.auditoria.acl.ohi.cliente;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

/**
 * Propiedades de configuración para la integración con Oracle Health Insurance.
 */
@ConfigurationProperties(prefix = "integraciones.ohi")
public record PropiedadesOhi(
        String urlBase,
        String tokenUrl,
        String clientId,
        String clientSecret,
        String scope,
        Timeouts timeouts
) {
    /**
     * Corta el arranque si falta configuración obligatoria.
     *
     * <p>No basta con declarar {@code ${OHI_CLIENT_SECRET_PROD}} sin valor por
     * omisión: a diferencia de {@code @Value}, el binder de
     * {@code @ConfigurationProperties} resuelve los marcadores con
     * {@code ignoreUnresolvablePlaceholders = true}, así que una variable de
     * entorno ausente no explota — deja el literal {@code ${...}} como valor, el
     * contexto arranca normal y el fallo aparece más tarde, como un 401 de IDCS
     * difícil de diagnosticar. Peor aún: ese literal viaja como contraseña en el
     * header Basic. Verificado en el proyecto hermano {@code idcs_deleteUsers}.
     *
     * <p>Va en el constructor compacto y no en un {@code @PostConstruct} porque
     * un record se enlaza por constructor: aquí es donde el binder entrega los
     * valores ya resueltos, y lanzar corta el arranque en el sitio.
     */
    public PropiedadesOhi {
        exigir("integraciones.ohi.url-base",      urlBase);
        exigir("integraciones.ohi.token-url",     tokenUrl);
        exigir("integraciones.ohi.client-id",     clientId);
        exigir("integraciones.ohi.client-secret", clientSecret);
        exigir("integraciones.ohi.scope",         scope);
    }

    /**
     * Exige que la propiedad tenga un valor real: ni vacío, ni el marcador
     * {@code ${VARIABLE}} que queda cuando la variable de entorno no está
     * definida (que {@code @NotBlank} no detectaría, porque el literal no está
     * en blanco).
     */
    private static void exigir(String propiedad, String valor) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalStateException(
                    "Falta la propiedad obligatoria '" + propiedad + "'. "
                    + "Defínala en el perfil activo o expórtela como variable de entorno.");
        }
        if (valor.startsWith("${") && valor.endsWith("}")) {
            throw new IllegalStateException(
                    "La propiedad '" + propiedad + "' quedó sin resolver: " + valor
                    + ". Exporte la variable de entorno " + nombreVariable(valor)
                    + " antes de arrancar (ver .env.ejemplo).");
        }
    }

    /** Extrae {@code VARIABLE} de un marcador {@code ${VARIABLE}} o {@code ${VARIABLE:defecto}}. */
    private static String nombreVariable(String marcador) {
        var contenido = marcador.substring(2, marcador.length() - 1);
        var separador = contenido.indexOf(':');
        return separador < 0 ? contenido : contenido.substring(0, separador);
    }

    public record Timeouts(
            Duration conexion,
            Duration lectura,
            Duration escritura,
            /**
             * Timeout de lectura para las operaciones que se sabe que exceden el
             * general. Dos casos conocidos, ambos verificados en producción:
             * <ul>
             *   <li>Resolver un pendiente dispara readjudicación en OHI, no solo una
             *       lectura.</li>
             *   <li>La búsqueda de cabecera ({@code claims/search}) trae un payload
             *       pequeño ({@code excludereferenceresources=true}), pero OHI debe
             *       resolver igual todas las relaciones de la cuenta antes de
             *       excluirlas: en cuentas con mucho volumen relacionado eso cuesta
             *       más que una lectura normal. Verificado con la cuenta
             *       CM-55181980659: 7,1 s reales contra los 5 s del timeout general,
             *       causando un 503 sistemático.</li>
             * </ul>
             * Se aplica vía un {@code WebClient} separado
             * ({@code clienteOhiOperacionesLargas}) con su propio pool y su propio
             * {@code ReadTimeoutHandler}: un timeout por-petición sobre el cliente
             * general no basta, porque el handler ya instalado en el canal —fijo al
             * timeout general— corta la conexión primero, sin importar qué valor se
             * pida para esa petición puntual.
             * Con valor por omisión propio para no exigir cambiar el YAML existente.
             */
            Duration resolucionPendiente
    ) {
        public Timeouts {
            if (resolucionPendiente == null) resolucionPendiente = Duration.ofSeconds(25);
        }
    }
}
