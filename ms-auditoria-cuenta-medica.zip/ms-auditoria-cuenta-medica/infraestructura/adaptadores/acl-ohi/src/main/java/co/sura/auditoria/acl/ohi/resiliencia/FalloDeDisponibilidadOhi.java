package co.sura.auditoria.acl.ohi.resiliencia;

import co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi;
import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.function.Predicate;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

/**
 * Qué cuenta como caída del sistema de registro para los circuit breakers (OPE-01).
 *
 * <h3>Lo que había</h3>
 * Ningún predicado: Resilience4j registra por omisión <b>cualquier</b> excepción. Y como el
 * traductor de errores actúa antes que el circuito, al circuito le llegaban como fallos un
 * 409 de versión, un 422 de línea rechazada, un 403 de permisos, el GEN-ORA-00001 de un
 * pendiente repetido o el 404 de un recurso inexistente. Son respuestas: OHI está bien y
 * contestó. Pero con ventanas de 5 a 20 llamadas compartidas por todos los usuarios de la
 * réplica, unos pocos conflictos de un auditor abrían el circuito y los demás recibían 503.
 *
 * <h3>Lo que cuenta ahora</h3>
 * <ul>
 *   <li>el transporte: timeouts de conexión o de lectura, conexión rechazada o cortada,
 *       también cuando el corte llega a mitad del cuerpo de una respuesta 2xx —WebClient lo
 *       entrega entonces como una {@link WebClientResponseException} con el código de la
 *       respuesta y el corte como causa, y juzgarla por el código diría «200, todo bien»—;</li>
 *   <li>una respuesta 5xx, o un 429: OHI pidiendo que se baje el ritmo es justo cuando el
 *       circuito debe abrir y dejar de insistir.</li>
 * </ul>
 *
 * <h3>Lo que no cuenta</h3>
 * La cola del pool de conexiones propio llena o vencida: es saturación de esta réplica, no de
 * OHI. Pero «no contar» no basta, porque para Resilience4j eso es un éxito: el circuito la
 * <b>ignora</b> con {@link SaturacionDelPoolOhi}. Aquí devuelve {@code false} para que tampoco
 * se reintente: reintentarla solo vuelve a meter la petición en la misma cola.
 *
 * <p>Se declara por nombre de clase en {@code application.yml}: Resilience4j la instancia con
 * su constructor sin argumentos.
 */
public class FalloDeDisponibilidadOhi implements Predicate<Throwable> {

    @Override
    public boolean test(Throwable error) {
        if (error == null || SaturacionDelPoolOhi.es(error)) return false;

        if (error instanceof RespuestaDeErrorOhi respuesta) return esCaida(respuesta.estadoHttp());
        if (error instanceof WebClientResponseException respuesta) {
            return respuesta.getStatusCode().isError()
                    ? esCaida(respuesta.getStatusCode().value())
                    : causaDeTransporte(respuesta.getCause());
        }
        return esTransporte(error);
    }

    /**
     * Si es un fallo de transporte: la petición no obtuvo respuesta entera.
     *
     * <p>Lo usa también {@code ConfiguracionResiliencia} para responder 503 y no 500.
     */
    static boolean esTransporte(Throwable error) {
        if (error == null || SaturacionDelPoolOhi.es(error)) return false;
        if (error instanceof WebClientResponseException respuesta)
            return !respuesta.getStatusCode().isError() && causaDeTransporte(respuesta.getCause());
        return error instanceof WebClientRequestException || causaDeTransporte(error);
    }

    private static boolean causaDeTransporte(Throwable error) {
        for (var causa = error; causa != null; causa = causa.getCause() == causa ? null : causa.getCause()) {
            if (causa instanceof IOException
                || causa instanceof TimeoutException
                || causa instanceof io.netty.handler.timeout.TimeoutException) return true;
        }
        return false;
    }

    static boolean esCaida(int estado) {
        return estado >= 500 || estado == 429;
    }
}
