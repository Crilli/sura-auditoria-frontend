package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;

/**
 * Un elemento de {@code detallesGlosa} dentro del parche de una línea.
 *
 * <p>Los nombres y los límites son los de la definición {@code claimline} de
 * {@code GET /claimsupdate/definition}, leída contra UAT el 14-oct-2026.
 *
 * <p><b>{@code op} es lo que distingue el alta de la baja</b>, con el mismo
 * vocabulario que ya usa {@link OhiLinePatch}: {@code add}, {@code replace} y
 * {@code remove}. Está marcado {@code x-oi-insertable: false} en el contrato, es
 * decir, es un atributo de la operación y no un dato de la glosa.
 *
 * <p>Dos cosas aprendidas probando contra UAT:
 * <ul>
 *   <li><b>{@code numeroSecuencia} es obligatorio en el alta.</b> Sin él, el
 *       sistema de registro responde {@code 422 COD-FCFU-101} («El campo "Número
 *       Secuencia" es obligatorio») y no aplica nada;</li>
 *   <li>los datos reales traen {@code codigoGlosa} y las dos descripciones, pero
 *       <b>{@code conceptoGenerico} y {@code conceptoEspecifico} llegan siempre
 *       vacíos</b>. Por eso no se envían: escribir campos que nadie rellena ni
 *       lee solo añade superficie que mantener.</li>
 * </ul>
 *
 * <p>Se serializa sin nulos, por lo mismo que {@link OhiLinePatch}: una
 * propiedad presente en nulo es una orden de borrar lo guardado.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record OhiDetalleGlosaPatch(
        String op,
        /** Solo en la baja: identifica cuál se quita. */
        String id,
        /** Obligatorio en el alta. Máximo 2 caracteres. */
        String numeroSecuencia,
        /** El causal. Máximo 30. */
        String codigoGlosa,
        BigDecimal valorGlosa,
        /** Máximo 100. */
        String descripcionGenerico,
        /** Máximo 1000. */
        String descripcionEspecifico,
        /** Máximo 1000. */
        String texto) {

    /** Alta: sin id, con los datos de la glosa. */
    public static OhiDetalleGlosaPatch alta(String numeroSecuencia, String codigoGlosa,
                                            BigDecimal valor, String generico,
                                            String especifico, String texto) {
        return new OhiDetalleGlosaPatch("add", null, numeroSecuencia, codigoGlosa,
                                        valor, generico, especifico, texto);
    }

    /**
     * Baja: solo la operación y el identificador.
     *
     * <p>Nada más, a propósito. Mandar también los datos de la glosa invita a
     * que el sistema de registro los interprete como una modificación previa al
     * borrado, y lo que se quiere es quitarla tal como está.
     */
    public static OhiDetalleGlosaPatch baja(long identificador) {
        return new OhiDetalleGlosaPatch("remove", String.valueOf(identificador),
                                        null, null, null, null, null, null);
    }
}
