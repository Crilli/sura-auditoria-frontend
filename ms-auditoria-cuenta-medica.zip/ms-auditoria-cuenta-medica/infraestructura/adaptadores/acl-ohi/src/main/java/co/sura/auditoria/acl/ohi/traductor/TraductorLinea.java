package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiMonto;
import co.sura.auditoria.acl.ohi.externo.OhiPricingClause;
import co.sura.auditoria.acl.ohi.externo.OhiReferencia;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiClaimLineItem;
import co.sura.auditoria.acl.ohi.externo.OhiDetalleGlosaPatch;
import co.sura.auditoria.acl.ohi.externo.OhiLinePatch;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem;
import co.sura.auditoria.acl.ohi.externo.OhiNovedadPatch;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.modelo.cuenta.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** Traduce líneas OHI (claimLine) al modelo de dominio y viceversa. */
@Component
public class TraductorLinea {

    /** Moneda de la instalación de OHI. Los importes de salida deben declararla. */
    private static final String MONEDA = "COP";


    private final TraductorNovedad   traductorNovedad;
    private final TraductorPendiente traductorPendiente;

    public TraductorLinea(TraductorNovedad traductorNovedad,
                          TraductorPendiente traductorPendiente) {
        this.traductorNovedad   = traductorNovedad;
        this.traductorPendiente = traductorPendiente;
    }

    /**
     * Traduce al resumen liviano (para la grilla).
     *
     * @param afiliadoDeRespaldo el de la cabecera; solo se usa si la línea no
     *                           trae el suyo, porque OHI lo publica en uno u otro
     *                           sitio según la cuenta
     */
    public ResumenLinea aResumen(OhiClaimLineItem externo, String afiliadoDeRespaldo) {
        return aResumen(externo, afiliadoDeRespaldo, null);
    }

    /**
     * Igual que {@link #aResumen(OhiClaimLineItem, String)} pero con el nombre del
     * afiliado ya resuelto.
     *
     * @param nombresAfiliado mapa {@code person.id} → nombre, de
     *                        {@code AdaptadorAfiliadosOhi}; puede venir incompleto
     */
    public ResumenLinea aResumen(OhiClaimLineItem externo, String afiliadoDeRespaldo,
                                 Map<String, String> nombresAfiliado) {
        return new ResumenLinea(
                new ReferenciaLinea(externo.id()),
                externo.sequence() == null ? 0 : externo.sequence(),
                externo.startDate(),
                externo.endDate(),
                afiliadoDe(externo, afiliadoDeRespaldo),
                nombreAfiliadoDe(externo, nombresAfiliado),
                OhiReferencia.codigoDe(externo.procedure()),
                OhiReferencia.descripcionDe(externo.procedure()),
                OhiReferencia.catalogoDe(externo.procedure()),
                externo.authorizationCode(),
                // Convenido = allowedAmount y autorizado = coveredAmount: la tabla que fijó
                // negocio el 2026-10-21. Hasta entonces este par salía como «autorizado» y
                // «cubierto». Lo que OHI no trae viaja nulo, no cero: ver OhiMonto.valorONulo.
                OhiMonto.valorONulo(externo.allowedAmount()),
                OhiMonto.valorONulo(externo.coveredAmount()),
                externo.valorGlosado(),
                DiccionarioOhi.aIndicador(externo.keepBenefits()),
                DiccionarioOhi.aIndicador(externo.keepPricing()),
                DiccionarioOhi.aIndicador(externo.locked()),
                DiccionarioOhi.aIndicador(externo.replaced()),
                0,          // contador y listas se completan en el adaptador,
                List.of(),  // que es quien consulta pendientes y novedades de la página
                false,
                List.of(),
                new Version(externo.objectVersionNumber()),
                OhiMonto.valorONulo(externo.claimedAmount()),
                externo.claimedNumberOfUnits(),
                externo.allowedNumberOfUnits(),
                externo.montoIVACalculado(),
                externo.porcentajeIVA(),
                // La cantidad autorizada, pareja del valor autorizado. Tiene que estar también
                // en CamposOhi.RESUMEN_LINEA: OHI no valida `fields` y, si no se pide, llega
                // ausente con un 200 y la grilla pintaría «—» en todas las líneas.
                externo.coveredNumberOfUnits());
    }

    /**
     * Traduce las novedades de una línea al dominio.
     *
     * <p>Está aquí, y no duplicado en el adaptador, porque la severidad tiene que pasar por
     * el mismo diccionario en los dos caminos: el chip de la grilla estuvo apagado durante
     * meses porque un sitio comparaba con «FATAL» y OHI manda «F».
     */
    public List<Novedad> aNovedades(List<OhiMessageItem> externas) {
        return externas.stream().map(traductorNovedad::aDominio).toList();
    }

    /** Traduce al detalle completo de la línea. */
    public LineaCuenta aDetalle(OhiClaimLineItem externo, CodigoCuenta codigoCuenta,
                                String afiliadoDeRespaldo,
                                List<OhiMessageItem> novedades,
                                List<OhiPendReasonItem> pendientes) {
        return aDetalle(externo, codigoCuenta, afiliadoDeRespaldo, novedades, pendientes,
                        null, null, List.of(), null);
    }

    /** Ver {@link #aResumen(OhiClaimLineItem, String, Map)} sobre {@code nombresAfiliado}. */
    public LineaCuenta aDetalle(OhiClaimLineItem externo, CodigoCuenta codigoCuenta,
                                String afiliadoDeRespaldo,
                                List<OhiMessageItem> novedades,
                                List<OhiPendReasonItem> pendientes,
                                Map<String, String> nombresAfiliado,
                                Map<String, String> nombresPrestador,
                                List<OhiPricingClause> clausulas,
                                co.sura.auditoria.modelo.cuenta.EstadoCuenta estadoCuenta) {
        return new LineaCuenta(
                new ReferenciaLinea(externo.id()),
                codigoCuenta,
                externo.sequence() == null ? 0 : externo.sequence(),
                externo.startDate(),
                externo.endDate(),
                afiliadoDe(externo, afiliadoDeRespaldo),
                nombreAfiliadoDe(externo, nombresAfiliado),
                OhiReferencia.codigoDe(externo.procedure()),
                OhiReferencia.descripcionDe(externo.procedure()),
                OhiReferencia.catalogoDe(externo.procedure()),
                // Convenido (allowed*) y autorizado (covered*): ver la nota de aResumen.
                OhiMonto.valorONulo(externo.allowedAmount()),
                externo.allowedNumberOfUnits(),
                OhiMonto.valorONulo(externo.coveredAmount()),
                externo.coveredNumberOfUnits(),
                OhiMonto.valorONulo(externo.claimedAmount()),
                externo.claimedNumberOfUnits(),
                externo.valorGlosado(),
                externo.observacionesGlosa(),
                externo.authorizationCode(),
                OhiReferencia.codigoDe(externo.serviceProvider()),
                nombrePrestadorDe(externo, nombresPrestador),
                DiccionarioOhi.aIndicador(externo.keepBenefits()),
                DiccionarioOhi.aIndicador(externo.keepPricing()),
                DiccionarioOhi.aIndicador(externo.manualBenefits()),
                DiccionarioOhi.aIndicador(externo.manualPricing()),
                DiccionarioOhi.aIndicador(externo.locked()),
                DiccionarioOhi.aIndicador(externo.replaced()),
                prestacionDe(externo),
                convenioDe(externo, clausulas),
                otrosDatosDe(externo),
                diagnosticosDe(externo),
                glosasDe(externo),
                novedades.stream().map(traductorNovedad::aDominio).toList(),
                pendientes.stream().map(traductorPendiente::aDominioLinea).toList(),
                estadoCuenta,
                new Version(externo.objectVersionNumber()));
    }

    /**
     * Afiliado de la línea, con respaldo en el de la cabecera.
     *
     * <p>OHI publica {@code person} en la línea en unas cuentas y en la cabecera
     * en otras. Verificado con dos cuentas reales: {@code CM-87979974627} lo trae
     * por línea (y difiere entre ellas) y {@code 108368099932} solo en la cabecera.
     */
    private String afiliadoDe(OhiClaimLineItem externo, String afiliadoDeRespaldo) {
        var propio = OhiReferencia.codigoDe(externo.person());
        return propio != null ? propio : afiliadoDeRespaldo;
    }

    /**
     * Nombre del afiliado de la línea, si se pudo resolver contra el padrón.
     *
     * <p>Se busca por {@code person.id} porque es la clave del padrón; el
     * {@code code} es el documento y sirve para mostrar, no para resolver.
     * Devuelve {@code null} sin ruido cuando no hay mapa o el afiliado no está
     * en él: el nombre adorna y su ausencia no debe romper la línea.
     */
    private String nombreAfiliadoDe(OhiClaimLineItem externo, Map<String, String> nombres) {
        if (nombres == null || nombres.isEmpty()) return null;
        var id = OhiReferencia.identificadorDe(externo.person());
        return id == null ? null : nombres.get(id);
    }

    /**
     * Nombre del prestador de atención. {@code serviceProviderName} de la línea
     * llega siempre vacío, así que se resuelve aparte contra el padrón; si no
     * está, se deja el código solo y la pantalla sigue siendo legible.
     */
    private String nombrePrestadorDe(OhiClaimLineItem e, Map<String, String> nombres) {
        if (nombres == null || nombres.isEmpty()) return e.serviceProviderName();
        var cod = OhiReferencia.codigoDe(e.serviceProvider());
        if (cod == null) return e.serviceProviderName();
        return nombres.getOrDefault(cod, e.serviceProviderName());
    }

    private Prestacion prestacionDe(OhiClaimLineItem e) {
        return new Prestacion(
                OhiReferencia.codigoDe(e.procedure()),
                OhiReferencia.descripcionDe(e.procedure()),
                OhiReferencia.catalogoDe(e.procedure()),
                e.prestacionCodigoNoDefinido(),
                e.prestacionCodigoNoDefinidoDef(),
                e.archivoRIPSDescrPrestacion(),
                OhiFlexCode.textoDe(e.claseServicio()),
                OhiReferencia.descripcionDe(e.serviceSpecialty()) != null
                        ? OhiReferencia.descripcionDe(e.serviceSpecialty())
                        : OhiReferencia.codigoDe(e.serviceSpecialty()));
    }

    private DatosConvenio convenioDe(OhiClaimLineItem e, List<OhiPricingClause> clausulas) {
        // La tarifa de contrato es la cláusula del contrato, no la de regla: las de regla son
        // los ajustes que la llevan hasta el valor convenido (allowedAmount). No es el
        // convenido, y por eso se publica como valorTarifaContrato y no con ese nombre.
        var contrato = (clausulas == null ? List.<OhiPricingClause>of() : clausulas).stream()
                .filter(OhiPricingClause::esDeContrato)
                .min(java.util.Comparator.comparingInt(
                        c -> c.sequence() == null ? Integer.MAX_VALUE : c.sequence()))
                .orElse(null);
        return new DatosConvenio(
                OhiFlexCode.textoDe(e.codeTariffISS2001()),
                OhiFlexCode.textoDe(e.codeTariffISS2000()),
                OhiFlexCode.textoDe(e.codeTariffSOAT()),
                e.numeroContrato(),
                e.homologoCups(),
                OhiFlexCode.textoDe(e.multiplesCupsHomologos()),
                e.codigoUnicoContratoSIIFA(),
                contrato == null ? null : OhiMonto.valorONulo(contrato.amount()),
                contrato == null ? null : contrato.providerPricingClause().descr());
    }

    private OtrosDatosLinea otrosDatosDe(OhiClaimLineItem e) {
        return new OtrosDatosLinea(
                OhiFlexCode.textoDe(e.tipoSala()),
                OhiFlexCode.textoDe(e.viaDeAcceso()),
                e.datosAdicionalesSiniestro() == null ? null : e.datosAdicionalesSiniestro().uen(),
                e.codigoSiniestro());
    }

    /**
     * Diagnósticos de la línea, ordenados por secuencia: el principal primero,
     * que es como los lee el auditor.
     */
    private List<DiagnosticoLinea> diagnosticosDe(OhiClaimLineItem e) {
        if (e.claimLineDiagnosisList() == null) return List.of();
        return e.claimLineDiagnosisList().stream()
                .map(d -> new DiagnosticoLinea(
                        d.sequence() == null ? 0 : d.sequence(),
                        OhiReferencia.codigoDe(d.diagnosisType()),
                        OhiReferencia.descripcionDe(d.diagnosisType()),
                        OhiReferencia.codigoDe(d.diagnosis()),
                        OhiReferencia.descripcionDe(d.diagnosis())))
                .sorted(java.util.Comparator.comparingInt(DiagnosticoLinea::secuencia))
                .toList();
    }

    private List<DetalleGlosa> glosasDe(OhiClaimLineItem e) {
        if (e.detallesGlosa() == null) return List.of();
        return e.detallesGlosa().stream()
                .map(g -> new DetalleGlosa(
                        g.id() == null ? 0L : g.id(),
                        g.codigoGlosa(),
                        g.valorGlosa(),
                        g.codigoNotaCredito(),
                        g.valorNotaCredito(),
                        g.descripcionGenerico(),
                        g.descripcionEspecifico(),
                        g.texto()))
                .toList();
    }

    /**
     * Traduce el comando de edición de dominio al parche de OHI.
     *
     * <p>Los campos que la edición no trae se dejan en nulo y {@link OhiLinePatch}
     * los omite al serializar, que es cómo se le dice a OHI «no toques esto».
     *
     * <p>El valor convenido escribe {@code allowedAmount}, igual que antes del 2026-10-21; lo
     * que cambió ese día es su nombre, que era «valorAutorizado». El autorizado
     * ({@code coveredAmount}) no tiene a dónde ir: {@link OhiLinePatch} no lo lleva porque el
     * contrato de escritura no lo acepta —lo calcula el motor de coberturas—.
     */
    public OhiLinePatch desdeEdicion(EdicionLinea edicion) {
        return new OhiLinePatch(
                edicion.referencia().valor(),
                "replace",
                edicion.versionEsperada().numero(),
                edicion.valorCargado().map(TraductorLinea::aMonto).orElse(null),
                edicion.unidadesCargadas().orElse(null),
                edicion.valorConvenido().map(TraductorLinea::aMonto).orElse(null),
                edicion.unidadesConvenidas().orElse(null),
                edicion.valorGlosado().orElse(null),
                edicion.observacionesGlosa().orElse(null),
                edicion.codigoAutorizacion().orElse(null),
                edicion.fechaInicio().orElse(null),
                edicion.fechaFin().orElse(null),
                edicion.codigoNoDefinido().orElse(null),
                edicion.codigoNoDefinidoDef().orElse(null),
                edicion.descripcionRips().orElse(null),
                edicion.numeroContrato().orElse(null),
                edicion.homologoCups().orElse(null),
                edicion.codigoUnicoContratoSiifa().orElse(null),
                edicion.codigoSiniestro().orElse(null),
                edicion.conservarBeneficios().orElse(null),
                edicion.conservarTarifacion().orElse(null),
                glosasDesde(edicion),
                novedadesDesde(edicion));
    }

    /**
     * Traduce las altas y bajas del desglose, o {@code null} si no hay ninguna.
     *
     * <p>{@code null} y no lista vacía: ver la nota de {@code OhiLinePatch}.
     *
     * <p>El número de secuencia de un alta se asigna aquí, correlativo dentro del
     * parche. El contrato lo exige —sin él el sistema de registro responde 422—
     * y admite dos caracteres, así que a partir de cien glosas en un mismo
     * parche dejaría de ser único; con el desglose de una línea eso no pasa, y
     * si pasara el propio sistema de registro lo rechazaría en vez de guardar
     * algo incoherente.
     */
    private static java.util.List<OhiDetalleGlosaPatch> glosasDesde(EdicionLinea edicion) {
        if (!edicion.tocaGlosas()) return null;

        var patches = new java.util.ArrayList<OhiDetalleGlosaPatch>(edicion.glosas().size());
        int secuencia = 0;
        for (var cambio : edicion.glosas()) {
            patches.add(cambio.esBaja()
                    ? OhiDetalleGlosaPatch.baja(cambio.identificador())
                    : OhiDetalleGlosaPatch.alta(String.valueOf(secuencia++), cambio.codigoGlosa(),
                                                cambio.valor(), cambio.generico(),
                                                cambio.especifico(), cambio.texto()));
        }
        return java.util.List.copyOf(patches);
    }

    /**
     * Traduce las altas y bajas de novedad, o {@code null} si no hay ninguna.
     *
     * <p>Más corto que {@link #glosasDesde}: no hay número de secuencia que
     * asignar, porque el contrato de la novedad no lo pide. Lo que sí viaja son
     * los datos que completan los marcadores del texto; el texto en sí y la
     * severidad son del mensaje del catálogo y no se mandan.
     */
    private static java.util.List<OhiNovedadPatch> novedadesDesde(EdicionLinea edicion) {
        if (!edicion.tocaNovedades()) return null;

        return edicion.novedades().stream()
                .map(cambio -> cambio.esBaja()
                        ? OhiNovedadPatch.baja(cambio.identificador())
                        : OhiNovedadPatch.alta(cambio.codigoMensaje(), cambio.valores()))
                .toList();
    }

    /** Envuelve un importe del dominio en la forma que exige OHI al escribir. */
    private static OhiMonto aMonto(java.math.BigDecimal valor) {
        return new OhiMonto(MONEDA, valor);
    }
}
