package co.sura.auditoria.acl.ohi.resiliencia;

import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.reactor.circuitbreaker.operator.CircuitBreakerOperator;
import io.github.resilience4j.reactor.retry.RetryOperator;
import io.github.resilience4j.retry.RetryRegistry;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.Function;
import org.springframework.context.annotation.Profile;

/**
 * Centraliza los operadores de Resilience4j para las llamadas reactivas a OHI.
 *
 * <p>Expone métodos transformadores {@code applyResilience} que se inyectan
 * en los flujos con {@code .transform(...)}.
 */
@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Configuration
public class ConfiguracionResiliencia {

    private final CircuitBreakerRegistry circuitBreakers;
    private final RetryRegistry          retries;

    public ConfiguracionResiliencia(CircuitBreakerRegistry circuitBreakers,
                                    RetryRegistry retries) {
        this.circuitBreakers = circuitBreakers;
        this.retries         = retries;
    }

    // ── Consultas (Idempotentes, seguras de reintentar) ──────────────────────

    public <T> Function<Mono<T>, Mono<T>> paraConsultasMono() {
        var cb = circuitBreakers.circuitBreaker("ohiConsultas");
        var rt = retries.retry("ohiConsultas");
        return mono -> traducirFalloDeComunicacion(mono
                .transformDeferred(RetryOperator.of(rt))
                .transformDeferred(CircuitBreakerOperator.of(cb)));
    }

    public <T> Function<Flux<T>, Flux<T>> paraConsultasFlux() {
        var cb = circuitBreakers.circuitBreaker("ohiConsultas");
        var rt = retries.retry("ohiConsultas");
        return flux -> traducirFalloDeComunicacion(flux
                .transformDeferred(RetryOperator.of(rt))
                .transformDeferred(CircuitBreakerOperator.of(cb)));
    }

    // ── Comandos (NO Idempotentes, NUNCA se reintentan por ADR-004) ──────────

    public <T> Function<Mono<T>, Mono<T>> paraComandosMono() {
        var cb = circuitBreakers.circuitBreaker("ohiComandos");
        return mono -> traducirFalloDeComunicacion(
                mono.transformDeferred(CircuitBreakerOperator.of(cb)));
    }

    // ── Consultas con latencia sabida-larga (sin reintento) ───────────────────

    /**
     * Para consultas que ya se sabe que pueden exceder el timeout de lectura
     * normal —hoy solo la búsqueda de cabecera de cuenta, vía el cliente de
     * operaciones largas—. Deliberadamente <b>sin</b> {@link RetryOperator}.
     *
     * <p>El retry sirve para fallos <em>transitorios</em> (un blip de red); aquí el
     * problema es latencia <em>sostenida y predecible</em> de OHI para ciertas
     * cuentas con mucho volumen relacionado. Reintentar tres veces una operación
     * que consistentemente tarda cerca del límite no aumenta la probabilidad de
     * éxito — solo multiplica por tres la espera del usuario. Verificado en
     * producción con CM-55181980659: con retry, 3×~5 s de timeout (15 s) o
     * 3×~22 s (66 s) según qué timeout tuviera activo; sin retry, un único
     * intento con margen suficiente.
     */
    public <T> Function<Mono<T>, Mono<T>> paraConsultaPacienteMono() {
        var cb = circuitBreakers.circuitBreaker("ohiConsultas");
        return mono -> traducirFalloDeComunicacion(
                mono.transformDeferred(CircuitBreakerOperator.of(cb)));
    }

    // ── Envío asíncrono (Diferente perfil de carga) ──────────────────────────

    public <T> Function<Mono<T>, Mono<T>> paraEnvioMono() {
        var cb = circuitBreakers.circuitBreaker("ohiEnvio");
        return mono -> traducirFalloDeComunicacion(
                mono.transformDeferred(CircuitBreakerOperator.of(cb)));
    }

    // ── Traducción de fallos de comunicación ──────────────────────────────────

    /**
     * Traduce los fallos de <em>transporte</em> hacia OHI a
     * {@link ErrorDeDominio.SistemaRegistroNoDisponible}.
     *
     * <p>Dos casos, ninguno con respuesta HTTP que traducir:
     * <ul>
     *   <li>{@link WebClientRequestException} — la petición nunca obtuvo respuesta:
     *       timeout de conexión o de lectura, conexión rechazada, DNS. Cubre el caso
     *       observado en producción de un timeout de lectura tras agotar los
     *       reintentos configurados para {@code ohiConsultas}.</li>
     *   <li>{@link CallNotPermittedException} — el circuit breaker está abierto:
     *       semánticamente es exactamente «el sistema de registro no está disponible».</li>
     * </ul>
     *
     * <p>{@link TraductorErrores} sigue siendo el único traductor de respuestas HTTP
     * de error ({@code onStatus}); este método cubre el caso complementario en el que
     * OHI nunca llegó a responder. Sin esto, {@code AtributosErrorGlobal} no reconoce
     * la excepción cruda y la reporta como {@code 500 ERROR_INTERNO} en vez del
     * {@code 503 SISTEMA_REGISTRO_NO_DISPONIBLE} que le corresponde.
     */
    private <T> Mono<T> traducirFalloDeComunicacion(Mono<T> mono) {
        return mono.onErrorMap(this::esFalloDeComunicacion, this::aExcepcionDeDominio);
    }

    private <T> Flux<T> traducirFalloDeComunicacion(Flux<T> flux) {
        return flux.onErrorMap(this::esFalloDeComunicacion, this::aExcepcionDeDominio);
    }

    private boolean esFalloDeComunicacion(Throwable error) {
        return error instanceof WebClientRequestException
            || error instanceof CallNotPermittedException;
    }

    private ExcepcionDeDominio aExcepcionDeDominio(Throwable error) {
        var detalle = error instanceof CallNotPermittedException
                ? "El circuito hacia el sistema de registro está abierto por fallos previos"
                : "No fue posible comunicarse con el sistema de registro: " + error.getMessage();
        return ExcepcionDeDominio.de(new ErrorDeDominio.SistemaRegistroNoDisponible(detalle));
    }
}
