package co.sura.auditoria.acl.ohi.externo;

import java.util.List;

/**
 * Una operación de larga duración de OHI, tal como la devuelve
 * {@code GET /activities/{id}} —la dirección que llega en la cabecera
 * {@code Location} de las peticiones que OHI procesa en segundo plano.
 *
 * <p>Respuesta real de producción:
 * <pre>
 * { "status": "CO", "level": "GL", "type": "RESOLVE_PEND", "workId": "2172213713",
 *   "links": [ {"rel":"operator:messages"}, {"rel":"self"}, {"rel":"file"} ] }
 * </pre>
 *
 * <p>El {@code status} es el dato que importa, y su dominio lo publica OHI en
 * {@code /generic/activities/definition} ({@code ActivityStatus}) <b>con los
 * significados ya en español</b>:
 *
 * <table border="1">
 *   <caption>ActivityStatus</caption>
 *   <tr><th>código</th><th>significado</th></tr>
 *   <tr><td>{@code IN}</td><td>Inicial</td></tr>
 *   <tr><td>{@code QD}</td><td>Queued</td></tr>
 *   <tr><td>{@code IP}</td><td>En Proceso</td></tr>
 *   <tr><td>{@code CO}</td><td>Completado</td></tr>
 *   <tr><td>{@code CB}</td><td>Completado con Errores de Negocio</td></tr>
 *   <tr><td>{@code CT}</td><td>Completado con Errores Técnicos</td></tr>
 *   <tr><td>{@code BE}</td><td>Error de Negocio</td></tr>
 *   <tr><td>{@code TE}</td><td>Error Técnico</td></tr>
 * </table>
 *
 * <p>La distinción entre {@code CO} y {@code CB}/{@code CT} es la que permite no
 * mentir: las tres son «terminó», pero solo la primera es «terminó y salió
 * todo». Medido el 12-oct-2026 sobre las 32.661 operaciones {@code RESOLVE_PEND}
 * que ya existen en producción: 32.642 {@code CO}, 11 {@code CB}, 2 {@code CT} y
 * 6 {@code TE}.
 */
public record OhiActividad(String status, String level, String type,
                           String workId, List<OhiLink> links) {

    /** Si la operación ya terminó, salga como salga. */
    public boolean terminada() {
        return switch (status == null ? "" : status) {
            case "CO", "CB", "CT", "BE", "TE" -> true;
            default -> false;   // IN, QD, IP, y cualquier estado que OHI añada
        };
    }

    /** Si terminó sin nada que reportar. */
    public boolean limpia() {
        return "CO".equals(status);
    }

    /** Si no llegó a aplicar nada: los dos estados de error sin «Completado». */
    public boolean fallida() {
        return "BE".equals(status) || "TE".equals(status);
    }

    /** El identificador de la operación, que es el que sirve para rastrearla. */
    public String referencia() {
        return workId;
    }
}
