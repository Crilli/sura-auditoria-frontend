package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Catálogo de mensajes que un auditor puede poner como novedad.
 *
 * <p>Lee {@code /generic/messages}, que es <b>la autoridad</b> sobre el texto, la
 * severidad y la clasificación normativa de cada código. A diferencia de las
 * glosas —donde no hay catálogo y el proyecto arrastra una lista escrita a
 * mano— aquí el dato viene del sistema de registro.
 *
 * <h3>El recorrido completo, y por qué no basta una llamada</h3>
 * Son más de 200 registros, y OHI <b>corta en 200 sin avisar</b>: devuelve la
 * página y no dice que hay más. Así que se recorre por keyset con
 * {@code id.gt(cursor)} y {@code orderBy id asc}, igual que el resto de los
 * recorridos largos de este adaptador.
 *
 * <h3>Lo que se filtra</h3>
 * Todo en la consulta, que es lo que OHI sabe hacer: activo, no obsoleto y no
 * propio del sistema. Tres condiciones que reducen 2.029 a <b>696</b>, y
 * empujarlas evita traerse el 66% del catálogo para tirarlo.
 *
 * <p>Antes se descartaban además, ya aquí, los 65 cuyo texto lleva marcadores.
 * <b>Ya no:</b> entran, porque la pantalla pide sus datos al dar de alta. Medido
 * contra el entorno de pruebas, 86 de las novedades manuales que usan esos
 * mensajes las puso una persona con nombre, no la integración, así que
 * excluirlos le quitaba al auditor mensajes que ya usaba.
 *
 * <h3>Se guarda en memoria</h3>
 * El catálogo es global y cambia de higos a brevas, pero el caso de uso lo
 * consulta en cada guardado que ponga una novedad. Sin caché, eso serían cuatro
 * llamadas a OHI por guardado.
 */
@Component
public class AdaptadorCatalogoNovedadesOhi implements PuertoCatalogoNovedades {

    /** Lo que admite OHI por página. Pedir más responde 422. */
    private static final int LOTE = SolicitudBusqueda.LIMITE_MAXIMO;

    /**
     * Tope de páginas del recorrido. Con 696 elegibles sobran cuatro; se deja
     * holgura para que el catálogo pueda crecer, pero acotado, para que un
     * cursor que no avance no se convierta en un bucle contra OHI.
     */
    private static final int MAXIMO_LOTES = 20;

    /**
     * Cuánto se conserva el catálogo antes de volver a pedirlo.
     *
     * <p>Media hora: si alguien da de alta un código nuevo en el sistema de
     * registro, tardará como mucho eso en poder usarse, y a cambio los guardados
     * no pagan una lectura del catálogo cada uno.
     */
    private static final Duration VIGENCIA = Duration.ofMinutes(30);

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;

    /**
     * El catálogo ya recorrido. Solo se guarda si trae algo: ni una lista vacía ni un error
     * se quedan pegados media hora por una primera lectura que falló.
     */
    private final Mono<List<MensajeCatalogo>> cache;

    public AdaptadorCatalogoNovedadesOhi(WebClient webClient,
                                         ConfiguracionResiliencia resiliencia,
                                         TraductorErrores traductorErrores) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.cache = Mono.defer(this::recorrer)
                // Solo se guarda un catálogo con algo: un error o una lista vacía se olvidan al
                // momento y la siguiente petición vuelve a preguntar. Con cache(VIGENCIA) a
                // secas, Reactor guardaba también el error 30 minutos (OPE-04).
                .cache(lista -> lista.isEmpty() ? Duration.ZERO : VIGENCIA,
                       error -> Duration.ZERO,
                       () -> Duration.ZERO);
    }

    @Override
    public Mono<List<MensajeCatalogo>> listar() {
        return cache;
    }

    /** Recorre el catálogo entero por keyset y se queda con lo ofrecible. */
    private Mono<List<MensajeCatalogo>> recorrer() {
        return siguienteLote(0L, new ArrayList<>(), 0);
    }

    private Mono<List<MensajeCatalogo>> siguienteLote(long cursor,
                                                      List<MensajeCatalogo> acumulado,
                                                      int lote) {
        if (lote >= MAXIMO_LOTES) return Mono.just(List.copyOf(acumulado));

        var consulta = ConstructorConsulta.igual("active", true)
                .y(ConstructorConsulta.igual("obsolete", false))
                .y(ConstructorConsulta.igual("system", false))
                .yMayorQue("id", cursor)
                .construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.MENSAJE_CATALOGO,
                                             "id asc", LOTE, false);

        return webClient.post()
                .uri("/generic/messages/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiMensaje>>() {})
                .transform(resiliencia.paraConsultasMono())
                .flatMap(respuesta -> {
                    if (respuesta.isEmpty()) return Mono.just(List.copyOf(acumulado));

                    var items = respuesta.items();
                    // Aquí ya no se descarta nada: los 65 mensajes que llevan
                    // marcadores en el texto entran al catálogo, porque la
                    // pantalla pide también sus datos. Ver MensajeCatalogo.
                    items.stream()
                            .map(AdaptadorCatalogoNovedadesOhi::aDominio)
                            .forEach(acumulado::add);

                    if (items.size() < LOTE) return Mono.just(List.copyOf(acumulado));

                    var ultimo = items.get(items.size() - 1).id();
                    // Si el cursor no avanza se corta: es la única forma de que
                    // el recorrido no se quede dando vueltas sobre el mismo lote.
                    if (ultimo == null || ultimo <= cursor) {
                        return Mono.just(List.copyOf(acumulado));
                    }
                    return siguienteLote(ultimo, acumulado, lote + 1);
                })
                .defaultIfEmpty(List.copyOf(acumulado));
    }

    private static MensajeCatalogo aDominio(OhiMensaje externo) {
        return new MensajeCatalogo(
                externo.code(),
                externo.message(),
                DiccionarioOhi.aSeveridad(externo.severity()),
                aClasificacion(externo.conceptoGenerico()),
                aClasificacion(externo.conceptoEspecifico()),
                Boolean.TRUE.equals(externo.system()));
    }

    private static Novedad.Clasificacion aClasificacion(OhiFlexCode flex) {
        if (flex == null) return null;
        return new Novedad.Clasificacion(flex.value(), flex.descriptor());
    }

    /**
     * Un mensaje del catálogo tal como lo publica OHI.
     *
     * <p>{@code message} es <b>el texto</b>, no un objeto anidado: la misma
     * trampa de nombre que en {@code OhiMessageItem.OhiMessageRef}.
     */
    private record OhiMensaje(Long id,
                              String code,
                              String message,
                              String severity,
                              Boolean system,
                              Boolean active,
                              Boolean obsolete,
                              OhiFlexCode conceptoGenerico,
                              OhiFlexCode conceptoEspecifico) {}
}
