package co.sura.auditoria.acl.ohi.externo;

/** Link HATEOAS publicado por OHI Claims. */
public record OhiLink(String rel, String href, String httpMethod) {}
