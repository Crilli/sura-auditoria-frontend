package co.sura.auditoria.acl.ohi.cache;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import com.github.benmanes.caffeine.cache.AsyncCache;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Los agregados caros de una cuenta, guardados un rato corto (OPE-09).
 *
 * <h3>Por qué</h3>
 * Medido el 2026-10-17 en UAT abriendo cuentas como el frontend: unas 15 llamadas a OHI por
 * apertura, y con 20 usuarios el pool de conexiones se llenaba y salían 503. Filtros y motivos
 * recorren la cuenta entera y se recalculaban en cada apertura y para cada usuario —en la cuenta
 * de 4.063 líneas de producción son 21 y 20 consultas—, y las acciones obligan a OHI a
 * materializar la cuenta completa (8-11 s allí). Lo mismo pedido tres veces seguidas por el
 * mismo auditor, o por dos a la vez, costaba tres veces lo mismo.
 *
 * <h3>Las tres reglas</h3>
 * <ul>
 *   <li><b>Corta vida</b>: {@code vigencia} (30 s por omisión). Es la cota de lo desfasado que
 *       puede verse un agregado por un cambio hecho desde otra réplica o desde el propio OHI.</li>
 *   <li><b>Una sola carga</b>: las peticiones simultáneas de la misma cuenta esperan a la misma.
 *       Si una se cancela —el auditor cambia de pestaña— las demás siguen recibiendo el
 *       resultado: la carga no se cancela con ella.</li>
 *   <li><b>Se invalida con cada comando</b> sobre la cuenta, haya ido bien o mal —un error de
 *       transporte no dice que OHI no lo aplicara—; otra vez pasada una vigencia si no terminó
 *       bien o si OHI sigue trabajando en segundo plano (envío, resolución en curso); y cuando
 *       el seguimiento ve terminar una resolución o un envío. Una carga que empezó antes del
 *       comando entrega su resultado a quien la esperaba, pero no queda guardada.</li>
 * </ul>
 *
 * <p>Un error o un vacío no se guardan: Caffeine descarta los futuros que fallan o terminan
 * en {@code null}, y la siguiente petición vuelve a preguntar.
 *
 * <p>Lo que <b>no</b> se guarda aquí, a propósito: la cabecera —lleva la versión con la que se
 * escribe— y las páginas de líneas, que cambian con el filtro y el orden.
 */
@Component
public class CacheDeAgregadosOhi {

    /** Lo que se guarda. Cada uno tiene su propia entrada por cuenta. */
    public enum Agregado { FILTROS_LINEAS, MOTIVOS_PENDIENTES, ACCIONES }

    private record Clave(Agregado agregado, String cuenta) {}

    private final AsyncCache<Clave, Object> cache;
    private final Duration vigencia;
    private final java.util.List<java.util.function.Consumer<CodigoCuenta>> alInvalidarCuenta =
            new java.util.concurrent.CopyOnWriteArrayList<>();
    private final java.util.List<Runnable> alInvalidarTodo = new java.util.concurrent.CopyOnWriteArrayList<>();

    @Autowired
    public CacheDeAgregadosOhi(
            @Value("${integraciones.ohi.cache-agregados.vigencia:30s}") Duration vigencia,
            @Value("${integraciones.ohi.cache-agregados.maximo-entradas:3000}") long maximoEntradas) {
        this.vigencia = vigencia;
        this.cache = Caffeine.newBuilder()
                .expireAfterWrite(vigencia)
                .maximumSize(maximoEntradas)
                .recordStats()
                .buildAsync();
    }

    /** Con los valores por omisión: 30 s y 3.000 entradas. */
    public CacheDeAgregadosOhi() {
        this(Duration.ofSeconds(30), 3000);
    }

    /**
     * El agregado de la cuenta: el guardado si sigue vigente, el que se está cargando si ya hay
     * una carga en curso, o una carga nueva.
     */
    @SuppressWarnings("unchecked")
    public <T> Mono<T> obtener(Agregado agregado, CodigoCuenta codigo, Supplier<Mono<T>> cargar) {
        var clave = new Clave(agregado, codigo.valor());
        // suppressCancel = true: cancelar a un suscriptor no cancela la carga compartida.
        return Mono.fromFuture(() -> (CompletableFuture<T>) cache.get(clave,
                (k, ejecutor) -> cargar.get().map(valor -> (Object) valor).toFuture()), true);
    }

    /** Descarta todo lo guardado de una cuenta, y avisa a quien guarde algo más de ella. */
    public void invalidar(CodigoCuenta codigo) {
        for (var agregado : Agregado.values()) {
            cache.synchronous().invalidate(new Clave(agregado, codigo.valor()));
        }
        alInvalidarCuenta.forEach(oyente -> oyente.accept(codigo));
    }

    /** Descarta un solo agregado de una cuenta: para releerlo fresco sin tocar los demás. */
    public void invalidar(Agregado agregado, CodigoCuenta codigo) {
        cache.synchronous().invalidate(new Clave(agregado, codigo.valor()));
    }

    /**
     * Lo que hay que hacer cuando termina un comando sobre la cuenta.
     *
     * <p>Se invalida en el momento y, si el comando no terminó bien —error, timeout o
     * cancelación—, otra vez pasada una vigencia: OHI puede seguir aplicándolo después de que
     * el cliente cortara, y una lectura hecha en ese hueco guardaría el estado de antes. Lo
     * encontró la revisión de las Fases 1 y 2.
     */
    public void invalidarTrasComando(CodigoCuenta codigo, reactor.core.publisher.SignalType senal) {
        invalidar(codigo);
        if (senal != reactor.core.publisher.SignalType.ON_COMPLETE) invalidarMasTarde(codigo);
    }

    /**
     * Vuelve a invalidar la cuenta pasada una vigencia. Para lo que OHI termina en segundo plano:
     * el envío, una resolución que sigue en curso o un comando que el cliente dejó de esperar.
     */
    public void invalidarMasTarde(CodigoCuenta codigo) {
        Mono.delay(vigencia).subscribe(x -> invalidar(codigo));
    }

    /**
     * Para quien guarde algo más de una cuenta —el estado, por ejemplo— y tenga que olvidarlo a
     * la vez que los agregados: así un comando que solo conoce esta caché lo invalida todo.
     */
    public void alInvalidar(java.util.function.Consumer<CodigoCuenta> porCuenta, Runnable todo) {
        alInvalidarCuenta.add(porCuenta);
        alInvalidarTodo.add(todo);
    }

    /**
     * Descarta todo. Para los comandos que solo conocen un identificador de fila y no la cuenta:
     * son raros, y vaciar de más solo cuesta recargar.
     */
    public void invalidarTodo() {
        cache.synchronous().invalidateAll();
        alInvalidarTodo.forEach(Runnable::run);
    }

    /** Para publicar sus estadísticas en Micrometer desde la capa de aplicación. */
    public Cache<?, ?> cacheNativa() {
        return cache.synchronous();
    }
}
