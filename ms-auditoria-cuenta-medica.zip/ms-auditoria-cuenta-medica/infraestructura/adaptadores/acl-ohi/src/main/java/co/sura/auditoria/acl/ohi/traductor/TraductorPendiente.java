package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.modelo.cuenta.*;
import org.springframework.stereotype.Component;

/** Traduce pendientes OHI (claimPendReason / claimLinePendReason) al modelo de dominio. */
@Component
public class TraductorPendiente {

    /** Traduce un pendiente de cabecera (claimpendreasons). */
    public MotivoPendiente aDominioCabecera(OhiPendReasonItem externo) {
        return new MotivoPendiente(
                externo.id(),
                externo.pendReason().code(),
                externo.pendReason().descripcion(),
                Boolean.TRUE.equals(externo.resolved()),
                Boolean.TRUE.equals(externo.pendReason().soloAdjudicacion()),
                NivelPendiente.CABECERA,
                null,   // nivel CABECERA no tiene referencia de línea
                null,
                new Version(externo.objectVersionNumber() != null ? externo.objectVersionNumber() : 0L));
    }

    /** Traduce un pendiente de línea (claimlinependreasons). */
    public MotivoPendiente aDominioLinea(OhiPendReasonItem externo) {
        ReferenciaLinea refLinea = externo.claimLine() != null
                ? new ReferenciaLinea(externo.claimLine().id())
                : null;

        return new MotivoPendiente(
                externo.id(),
                externo.pendReason().code(),
                externo.pendReason().descripcion(),
                Boolean.TRUE.equals(externo.resolved()),
                Boolean.TRUE.equals(externo.pendReason().soloAdjudicacion()),
                NivelPendiente.LINEA,
                refLinea,
                externo.claimLine() == null ? null : externo.claimLine().numeroLinea(),
                new Version(externo.objectVersionNumber() != null ? externo.objectVersionNumber() : 0L));
    }
}
