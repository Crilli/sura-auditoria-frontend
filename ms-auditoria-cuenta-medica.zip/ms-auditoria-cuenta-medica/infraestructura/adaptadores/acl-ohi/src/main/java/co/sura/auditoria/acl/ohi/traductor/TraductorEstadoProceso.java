package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiStatusResponse;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/** Traduce la respuesta del estado de proceso OHI al modelo de dominio. */
@Component
public class TraductorEstadoProceso {

    public EstadoProceso aDominio(OhiStatusResponse externo) {
        var errores = externo.claimErrorDetails() == null
                ? List.<String>of()
                : externo.claimErrorDetails().stream()
                        .map(OhiStatusResponse.OhiClaimErrorDetail::detail)
                        .collect(Collectors.toList());

        return new EstadoProceso(
                DiccionarioOhi.aAvance(externo.progress()),
                Boolean.TRUE.equals(externo.completed()),
                errores);
    }
}
