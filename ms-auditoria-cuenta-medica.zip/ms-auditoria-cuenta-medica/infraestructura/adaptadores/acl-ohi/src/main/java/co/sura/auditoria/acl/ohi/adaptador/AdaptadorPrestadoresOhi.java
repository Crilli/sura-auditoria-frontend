package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiProviderItem;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Nombres de los prestadores.
 *
 * <p>La línea trae {@code serviceProvider.code} (el NIT con sucursal) pero
 * {@code serviceProviderName} llega <b>siempre vacío</b> —medido sobre 200
 * líneas: 0 de 200—, así que el nombre hay que resolverlo contra
 * {@code /generic/providers}. Se resuelve por lote y se cachea: una cuenta
 * suele repetir el mismo prestador en todas sus líneas.
 *
 * <p><b>El nombre es decorativo: si no se puede resolver, la pantalla se pinta
 * igual.</b> Cualquier fallo aquí devuelve un mapa vacío en vez de propagar el
 * error, para que un problema del padrón no deje al auditor sin su grilla de
 * líneas, que es lo que de verdad necesita para trabajar.
 *
 * <p>Medido en producción: un lote de 25 afiliados (una página de la grilla)
 * tarda ~0,45 s, y uno de 200 ~0,53 s.
 */
@Component
public class AdaptadorPrestadoresOhi {

    private static final Logger log = LoggerFactory.getLogger(AdaptadorPrestadoresOhi.class);

    /** Tope de valores que admite un {@code in(...)} de OHI. */
    private static final int TAMANO_LOTE = 200;

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final Cache<String, String> nombres;

    public AdaptadorPrestadoresOhi(WebClient webClient,
                                 ConfiguracionResiliencia resiliencia,
                                 TraductorErrores traductorErrores,
                                 @Value("${integraciones.ohi.cache-prestadores.expiracion:30m}")
                                 Duration expiracion,
                                 @Value("${integraciones.ohi.cache-prestadores.maximo:20000}")
                                 long maximo) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.nombres = Caffeine.newBuilder()
                .expireAfterWrite(expiracion)
                .maximumSize(maximo)
                .build();
    }

    /**
     * Nombres de los prestadores indicados, por su código (NIT con sucursal).
     *
     * @param codigos códigos de {@code serviceProvider.code}; admite nulos y repetidos
     * @return mapa código → nombre. Sin entrada para los que OHI no resuelva
     */
    public Mono<Map<String, String>> nombresPorCodigo(Collection<String> idsAfiliado) {
        if (idsAfiliado == null || idsAfiliado.isEmpty()) return Mono.just(Map.of());

        var resueltos = new HashMap<String, String>();
        var pendientes = new ArrayList<String>();
        idsAfiliado.stream().filter(id -> id != null && !id.isBlank()).distinct().forEach(id -> {
            var enCache = nombres.getIfPresent(id);
            if (enCache != null) resueltos.put(id, enCache);
            else pendientes.add(id);
        });
        if (pendientes.isEmpty()) return Mono.just(Map.copyOf(resueltos));

        return Flux.fromIterable(enLotes(pendientes))
                .concatMap(this::buscarLote)
                .reduce(resueltos, (acumulado, lote) -> {
                    acumulado.putAll(lote);
                    return acumulado;
                })
                .map(Map::copyOf);
    }

    private Mono<HashMap<String, String>> buscarLote(List<String> ids) {
        var consulta = ConstructorConsulta.contenidoEn("code", ids).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PRESTADOR, null,
                                             SolicitudBusqueda.limitarAlMaximo(ids.size()), false);

        return webClient.post()
                .uri("/generic/providers/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiProviderItem>>() {})
                // OHI responde 204 sin cuerpo cuando la búsqueda no tiene resultados.
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .transform(resiliencia.paraConsultasMono())
                .map(respuesta -> {
                    var lote = new HashMap<String, String>();
                    if (respuesta.isEmpty()) return lote;
                    for (var prestador : respuesta.items()) {
                        if (prestador.code() != null && prestador.name() != null) {
                            lote.put(prestador.code(), prestador.name());
                            nombres.put(prestador.code(), prestador.name());
                        }
                    }
                    return lote;
                })
                // El nombre adorna; la grilla tiene que pintarse aunque el padrón falle.
                .onErrorResume(error -> {
                    log.warn("No se pudo resolver el nombre de {} prestadores: {}",
                             ids.size(), error.toString());
                    return Mono.just(new HashMap<String, String>());
                });
    }

    private static List<List<String>> enLotes(List<String> ids) {
        var lotes = new ArrayList<List<String>>();
        for (int i = 0; i < ids.size(); i += TAMANO_LOTE) {
            lotes.add(ids.subList(i, Math.min(i + TAMANO_LOTE, ids.size())));
        }
        return lotes;
    }
}
