package co.sura.auditoria.acl.ohi.externo;

import java.util.List;

/** Estado del proceso de envío en OHI. */
public record OhiStatusResponse(
        String progress,
        Boolean completed,
        String status,
        List<OhiClaimErrorDetail> claimErrorDetails) {

    public record OhiClaimErrorDetail(String detail, String instance, List<OhiLink> links) {}
}
