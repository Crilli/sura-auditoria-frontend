package co.sura.auditoria.acl.ohi.cliente;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;

/**
 * Pone el token en cada llamada a OHI y, si OHI lo rechaza, lo renueva y reintenta
 * <b>una sola vez</b>.
 *
 * <h3>Por qué el reintento no es un adorno</h3>
 * El token de IDCS vive 3.600 s y aquí se guarda 50 min para no apurarlo. Pero la ventana
 * nominal y la real no coinciden: medido el 2026-10-17, un servicio levantado a las 07:31 y
 * ocioso respondió <b>401 a los 68 minutos</b> a todas las peticiones, y siguió haciéndolo
 * hasta que se reinició —mientras las mismas credenciales, desde fuera, obtenían un token sin
 * problema—. Con la caché por tiempo como única defensa, cualquier desajuste entre el reloj
 * de la caché y el de IDCS deja el servicio inútil hasta que alguien lo note y lo reinicie.
 *
 * <p>La defensa correcta no es afinar el tiempo sino <b>creerle al sistema de registro</b>: si
 * contesta 401, el token que teníamos no vale, se tira y se pide otro. Es lo que el estándar
 * de pruebas del ecosistema exige comprobar desde el principio (el caso del token caducado) y
 * lo único que no dependía de acertar con una duración.
 *
 * <h3>Una vez, y solo una</h3>
 * Si el segundo intento también sale 401, el problema no es el token —credenciales revocadas,
 * permisos, el gateway— y reintentar otra vez solo multiplica las llamadas y retrasa el
 * diagnóstico. El segundo 401 se devuelve tal cual para que el traductor de errores lo
 * convierta en el error de dominio que corresponda.
 */
public class FiltroAutenticacionOhi implements ExchangeFilterFunction {

    private static final Logger log = LoggerFactory.getLogger(FiltroAutenticacionOhi.class);
    private static final int NO_AUTORIZADO = 401;

    private final ProveedorTokenOhi proveedor;

    public FiltroAutenticacionOhi(ProveedorTokenOhi proveedor) {
        this.proveedor = proveedor;
    }

    @Override
    public Mono<ClientResponse> filter(ClientRequest peticion, ExchangeFunction siguiente) {
        return enviarConToken(peticion, siguiente)
                .flatMap(respuesta -> esRechazoDeToken(respuesta)
                        ? reintentarConTokenNuevo(peticion, siguiente, respuesta)
                        : Mono.just(respuesta));
    }

    /**
     * El {@code defer} no es decorativo: sin él, {@code obtenerToken()} se ejecuta al
     * <b>construir</b> la cadena del reintento, o sea antes de que corra el olvido, y el
     * segundo intento sale con el mismo token que acaban de rechazar. Parecería un arreglo
     * y no lo sería. Lo comprueba {@code primeroOlvidaDespuesPide}.
     */
    private Mono<ClientResponse> enviarConToken(ClientRequest peticion, ExchangeFunction siguiente) {
        return Mono.defer(() -> proveedor.obtenerToken()
                .map(token -> ClientRequest.from(peticion)
                        .headers(cabeceras -> cabeceras.setBearerAuth(token))
                        .build())
                .flatMap(siguiente::exchange));
    }

    /**
     * Suelta el cuerpo del 401 antes de descartarlo: una respuesta cuyo cuerpo no se consume
     * deja la conexión retenida en el pool, y con un pool de 30 conexiones eso se nota.
     */
    private Mono<ClientResponse> reintentarConTokenNuevo(ClientRequest peticion,
                                                         ExchangeFunction siguiente,
                                                         ClientResponse rechazada) {
        log.warn("OHI rechazó el token en {} {}. Se renueva y se reintenta una vez.",
                 peticion.method(), peticion.url().getPath());

        return rechazada.releaseBody()
                .then(Mono.fromRunnable(proveedor::olvidarToken))
                .then(enviarConToken(peticion, siguiente));
    }

    private static boolean esRechazoDeToken(ClientResponse respuesta) {
        return respuesta.statusCode().value() == NO_AUTORIZADO;
    }
}
