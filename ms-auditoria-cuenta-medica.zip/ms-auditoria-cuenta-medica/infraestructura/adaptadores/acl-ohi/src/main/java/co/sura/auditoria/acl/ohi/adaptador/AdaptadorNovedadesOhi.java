package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.context.annotation.Profile;

/**
 * Adaptador interno para consultar novedades (messages) de OHI.
 * No implementa un puerto directo, es consumido por AdaptadorConsultasOhi.
 */
@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorNovedadesOhi {

    /** Tope defensivo de novedades por línea al pedir las de una página. */
    private static final int MAXIMO_NOVEDADES_POR_LINEA = 30;

    private final WebClient webClient;
    /** Mismo cliente paciente usado en toda la ruta de líneas; ver AdaptadorConsultasOhi. */
    private final WebClient clientePaciente;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;

    public AdaptadorNovedadesOhi(WebClient webClient,
                                 @org.springframework.beans.factory.annotation.Qualifier(
                                         co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
                                 WebClient clientePaciente,
                                 ConfiguracionResiliencia resiliencia,
                                 TraductorErrores traductorErrores) {
        this.webClient = webClient;
        this.clientePaciente = clientePaciente;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
    }

    public record NovedadLocalDTO(long idLinea, OhiMessageItem mensaje) {}

    /**
     * Novedades de un conjunto concreto de líneas.
     *
     * <p>Acotado a los identificadores de la página, por la misma razón que en
     * los pendientes: traer las de la cuenta completa en cada página es trabajo
     * que se descarta de inmediato.
     */
    public Mono<List<NovedadLocalDTO>> buscarDeLineas(List<Long> idsLinea) {
        if (idsLinea == null || idsLinea.isEmpty()) return Mono.just(List.of());

        var consulta = ConstructorConsulta.contenidoEnIds("claimLine.id", idsLinea).construir();
        // Para asociar la novedad a la línea requerimos 'claimLine.id' en los campos
        var campos = CamposOhi.NOVEDAD_LINEA + ",claimLine.id";
        var solicitud = SolicitudBusqueda.de(consulta, campos, null,
                                             SolicitudBusqueda.limitarAlMaximo(
                                                 idsLinea.size() * MAXIMO_NOVEDADES_POR_LINEA), false);

        return clientePaciente.post()
                .uri("/generic/claimlinemessages/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiMessageLocal>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<NovedadLocalDTO>of() : r.items().stream()
                        .map(i -> new NovedadLocalDTO(
                                i.claimLine() != null ? i.claimLine().id() : 0,
                                new OhiMessageItem(i.id(), i.message(), i.origin())))
                        .collect(Collectors.toList()))
                .defaultIfEmpty(List.of());
    }

    public Mono<List<OhiMessageItem>> buscarDeLinea(long idLinea) {
        var consulta = ConstructorConsulta.igual("claimLine.id", idLinea).construir();
        // `unica` limita a un registro: una línea puede acumular varias novedades.
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.NOVEDAD_LINEA,
                                             null, MAXIMO_NOVEDADES_POR_LINEA, false);

        return clientePaciente.post()
                .uri("/generic/claimlinemessages/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiMessageItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiMessageItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    // DTO interno para capturar claimLine.id
    private record OhiMessageLocal(Long id, OhiMessageItem.OhiMessageRef message, String origin, LineRef claimLine) {
        record LineRef(Long id) {}
    }
}
