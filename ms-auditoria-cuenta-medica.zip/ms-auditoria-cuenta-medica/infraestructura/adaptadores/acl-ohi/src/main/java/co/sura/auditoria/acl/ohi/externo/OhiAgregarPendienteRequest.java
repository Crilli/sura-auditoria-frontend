package co.sura.auditoria.acl.ohi.externo;

import java.util.List;

/**
 * Cuerpo de {@code POST /claims/addpendreason}.
 *
 * <p>La forma está tomada de lo que publica el propio servicio
 * ({@code /claims/addpendreason/definition} y su {@code /create-form}, leídos el 2026-10-17
 * en el entorno de pruebas) y comprobada con una llamada real.
 *
 * <h3>En qué se parece a su hermano y en qué no</h3>
 * Es casi igual que {@link OhiResolverPendientesRequest}: mismo {@code level}, mismo
 * {@code claimList} con {@code claimLineList} para acotar. Tres diferencias medidas:
 * <ul>
 *   <li>el motivo va en <b>singular</b> ({@code pendReasonCode}), no en lista: se añade uno
 *       por llamada;</li>
 *   <li>responde <b>204 y sin {@code Location}</b>, no 201 con una operación de larga
 *       duración. Es síncrono: cuando vuelve, el pendiente ya está puesto;</li>
 *   <li>y por lo mismo no hay actividad que sondear ni fallo parcial que leer después.</li>
 * </ul>
 *
 * <p>El alcance se comprobó de verdad: añadido {@code MP_VALIDAR_INFORMACION} a <b>una</b>
 * línea de una cuenta de nueve, los pendientes sin resolver pasaron de 5 a 6 y el nuevo
 * quedó exactamente en esa línea.
 */
public record OhiAgregarPendienteRequest(String pendReasonCode,
                                         String level,
                                         List<CuentaConLineas> claimList) {

    public record CuentaConLineas(String id, List<ReferenciaLinea> claimLineList) {}

    public record ReferenciaLinea(String id) {}

    /**
     * Alta de un motivo, acotada o no.
     *
     * <p>{@code identificadoresDeLinea} nulo o vacío produce {@code claimLineList = null}, que
     * es como se pide «todas las líneas aplicables». Misma regla y mismo peligro que en la
     * resolución: una lista vacía alcanzaría la cuenta entera sin decirlo.
     */
    public static OhiAgregarPendienteRequest de(long idCuenta, String codigoMotivo, String nivel,
                                                java.util.Collection<Long> identificadoresDeLinea) {
        var lineas = identificadoresDeLinea == null || identificadoresDeLinea.isEmpty()
                ? null
                : identificadoresDeLinea.stream()
                        .map(id -> new ReferenciaLinea(String.valueOf(id)))
                        .toList();
        return new OhiAgregarPendienteRequest(
                codigoMotivo, nivel,
                List.of(new CuentaConLineas(String.valueOf(idCuenta), lineas)));
    }
}
