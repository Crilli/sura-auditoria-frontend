package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion.AtencionDeVersion;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion.ClausulaDeVersion;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion.ConvenioDeVersion;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion.DiagnosticoDeVersion;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion.NovedadDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion.GlosaDeVersion;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.puertos.PuertoLineasDeVersion;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.Function;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * Las líneas de una versión de la cuenta, sobre {@code /generic/ctrclaimlines} (BUS-21).
 *
 * <h3>Cómo se pide una versión</h3>
 * Por la versión de su fila de cabecera, sin pasar por ella: {@code ctrClaim.code},
 * {@code ctrClaim.version} y <b>{@code ctrClaim.reversal.eq(false)}</b>. Medido el 2026-10-21 en
 * UAT sobre CM-29939061906 V8: con las tres condiciones salen sus 60 líneas; sin la tercera, 120,
 * porque entran las de su gemela de reversión con los importes en negativo —una suma daría cero—;
 * y con el código solo, 960, las de las dieciséis filas del histórico. Por el {@code ctrClaim.id}
 * de la fila también funciona, pero obligaría a buscarlo antes y cuesta lo mismo (0,42 s frente a
 * 0,48 s de mediana).
 *
 * <h3>Por desplazamiento, y en el orden del número de línea</h3>
 * {@code sequence asc}, como la grilla viva: en las 38.983 líneas de versión de UAT no hay dos con
 * la misma secuencia en una versión ni ninguna sin ella. La foto no cambia nunca
 * ({@code objectVersionNumber} 1 en todas las muestras), así que paginar por posición es seguro.
 *
 * <h3>Un 204 no dice por qué</h3>
 * Ninguna fila es lo mismo para OHI en tres casos que para el auditor son distintos: la versión
 * no existe, existe sin líneas —las madres de large claim: 148 versiones así en UAT, ninguna con
 * líneas—, o la página está más allá del final. Para no confundirlos, cuando una página sale vacía
 * se pregunta lo justo: el total si no es la primera, y si el total es cero, si la versión está
 * en el histórico. Son consultas de una fila y solo en ese caso.
 */
@Component
public class AdaptadorLineasDeVersionOhi implements PuertoLineasDeVersion {

    /** Como la grilla viva. Ver {@code AdaptadorConsultasOhi.ORDEN_POR_LINEA}. */
    private static final String ORDEN_POR_LINEA = "sequence asc";

    private final WebClient clientePaciente;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;

    public AdaptadorLineasDeVersionOhi(
            @Qualifier(co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
            WebClient clientePaciente,
            ConfiguracionResiliencia resiliencia,
            TraductorErrores traductorErrores) {
        this.clientePaciente = clientePaciente;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
    }

    // ── Las líneas de la versión ────────────────────────────────────────────

    @Override
    public Mono<PaginaDesplazada<LineaDeVersion>> lineasDeVersion(CodigoCuenta codigo, int numero,
                                                                  int desplazamiento,
                                                                  int tamanoPagina) {
        var desde = Math.max(0, desplazamiento);
        var tamano = SolicitudBusqueda.limitarAlMaximo(tamanoPagina);
        var consulta = deLaVersion(codigo, numero).construir();
        var solicitud = SolicitudBusqueda.desplazada(
                consulta, CamposOhi.LINEA_VERSION, ORDEN_POR_LINEA, desde, tamano, true);

        return buscarLineas(solicitud)
                .flatMap(respuesta -> {
                    var filas = respuesta.isEmpty() ? List.<OhiLineaDeVersion>of() : respuesta.items();
                    if (!filas.isEmpty()) {
                        return Mono.just(PaginaDesplazada.deOhi(
                                filas.stream().map(AdaptadorLineasDeVersionOhi::aLinea).toList(),
                                desde, tamano, respuesta.totalResults(),
                                respuesta.hayMas(desde, filas.size(), tamano)));
                    }
                    return paginaVacia(codigo, numero, consulta, desde, tamano);
                });
    }

    /**
     * Una página sin filas: más allá del final, versión sin líneas, o versión que no existe.
     *
     * <p>En la primera página no hay «más allá»: el total sería cero, así que se pregunta
     * directamente si la versión está. En las demás, primero el total —lo normal es que el
     * auditor haya llegado por un enlace a una página que ya no existe— y solo si es cero, la
     * versión.
     */
    private Mono<PaginaDesplazada<LineaDeVersion>> paginaVacia(CodigoCuenta codigo, int numero,
                                                               String consulta, int desde,
                                                               int tamano) {
        var total = desde > 0 ? totalDe(consulta) : Mono.just(0L);
        return total.flatMap(t -> t > 0
                ? Mono.just(PaginaDesplazada.<LineaDeVersion>deOhi(List.of(), desde, tamano, t, false))
                : existeVersion(codigo, numero).flatMap(existe -> existe
                        ? Mono.just(PaginaDesplazada.<LineaDeVersion>deOhi(List.of(), desde, tamano, 0L, false))
                        : Mono.empty()));
    }

    /** Cuántas líneas tiene la versión, sin traérselas. */
    private Mono<Long> totalDe(String consulta) {
        return buscarLineas(SolicitudBusqueda.desplazada(
                        consulta, CamposOhi.SOLO_ID, ORDEN_POR_LINEA, 0, 1, true))
                .map(r -> r.totalResults() == null ? 0L : r.totalResults());
    }

    // ── Una línea abierta ───────────────────────────────────────────────────

    @Override
    public Mono<DetalleLineaDeVersion> detalleDeLinea(CodigoCuenta codigo, int numero,
                                                      int numeroLinea) {
        var consulta = deLaVersion(codigo, numero).yIgual("sequence", numeroLinea).construir();
        return buscarLineas(SolicitudBusqueda.unica(consulta, CamposOhi.DETALLE_LINEA_VERSION))
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .map(AdaptadorLineasDeVersionOhi::aDetalle);
    }

    // ── Si la versión existe ────────────────────────────────────────────────

    /**
     * La misma pregunta que la foto de la versión ({@code AdaptadorBusquedaCuentasOhi}), pero
     * solo por el identificador: no hace falta traerse su cabecera para saber que está.
     */
    @Override
    public Mono<Boolean> existeVersion(CodigoCuenta codigo, int numero) {
        var consulta = ConstructorConsulta.igual("code", codigo.valor())
                .yIgual("version", numero)
                .yIgual("reversal", false)
                .construir();

        return clientePaciente.post()
                .uri("/generic/ctrclaims/search")
                .bodyValue(SolicitudBusqueda.unica(consulta, CamposOhi.SOLO_ID))
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiSoloId>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> !r.isEmpty())
                .defaultIfEmpty(false);
    }

    // ── Llamadas ────────────────────────────────────────────────────────────

    /**
     * Las tres condiciones que identifican una versión, vistas desde sus líneas.
     *
     * <p>{@code ctrclaimlines} no tiene {@code reversal} propio: lo tiene su cabecera, y sin él
     * entrarían las líneas de la gemela de reversión con los importes negados (BUS-21.2).
     */
    private static ConstructorConsulta deLaVersion(CodigoCuenta codigo, int numero) {
        return ConstructorConsulta.igual("ctrClaim.code", codigo.valor())
                .yIgual("ctrClaim.version", numero)
                .yIgual("ctrClaim.reversal", false);
    }

    /** Un 204 —ninguna fila— llega como respuesta vacía, no como Mono vacío. */
    private Mono<OhiSearchResponse<OhiLineaDeVersion>> buscarLineas(SolicitudBusqueda solicitud) {
        return clientePaciente.post()
                .uri("/generic/ctrclaimlines/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiLineaDeVersion>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .defaultIfEmpty(OhiSearchResponse.vacio());
    }

    // ── Traducción ──────────────────────────────────────────────────────────

    static LineaDeVersion aLinea(OhiLineaDeVersion l) {
        return new LineaDeVersion(
                l.sequence() == null ? 0 : l.sequence(),
                DiccionarioOhi.estadoDeLineaDeVersionLegible(l.status()),
                l.startDate(), l.endDate(),
                l.procedureCode(), l.procedureDescription(), l.procedureCodeDef(),
                l.servicedEntityCode(), l.servicedEntityName(),
                l.authorizationCode(),
                l.serviceProvCode(), l.serviceProvName(),
                l.claimedAmount(), l.claimedNumberOfUnits(),
                // El mismo mapeo que la línea viva (TraductorLinea), para que foto y cuenta se
                // comparen columna a columna: allowed* → convenido, covered* → autorizado, la
                // tabla que fijó negocio el 2026-10-21. Aquí son números planos, así que lo que
                // falta ya llegaba nulo; desde ese día la línea viva hace lo mismo.
                l.allowedAmount(), l.allowedNumberOfUnits(),
                l.coveredAmount(), l.coveredNumberOfUnits(),
                l.valorGlosado(),
                l.montoIVACalculado(), l.porcentajeIVA(),
                lista(l.detallesGlosa(), AdaptadorLineasDeVersionOhi::aGlosa));
    }

    private static GlosaDeVersion aGlosa(OhiGlosaDeVersion g) {
        return new GlosaDeVersion(
                entero(g.numeroSecuencia()), g.codigoGlosa(), g.valorGlosa(),
                g.codigoNotaCredito(), g.valorNotaCredito(),
                g.descripcionGenerico(), g.descripcionEspecifico(), g.texto(),
                g.descripcionTipoGlosa());
    }

    static DetalleLineaDeVersion aDetalle(OhiLineaDeVersion l) {
        var diagnosticos = lista(l.ctrClaimLineDiagnosisList(), d -> new DiagnosticoDeVersion(
                        d.sequence(), d.code(), d.description(), d.typeDescription()))
                .stream()
                .sorted(Comparator.comparing(DiagnosticoDeVersion::secuencia,
                                             Comparator.nullsLast(Comparator.naturalOrder())))
                .toList();

        var clausulas = lista(l.ctrClaimLineProviderPricingClauseList(), c -> c).stream()
                .sorted(Comparator.comparing(OhiClausulaDeVersion::sequence,
                                             Comparator.nullsLast(Comparator.naturalOrder())))
                .map(c -> new ClausulaDeVersion(c.amount(), c.providerPricingClauseDescr(),
                                                c.methodRuleCode()))
                .toList();

        return new DetalleLineaDeVersion(
                aLinea(l),
                agrupadas(lista(l.ctrClaimLineMessageList(), n -> n)),
                diagnosticos,
                new ConvenioDeVersion(l.codeTariffISS2000(), l.codeTariffISS2001(),
                                      l.codeTariffSOAT(), l.homologoCups(), clausulas),
                new AtencionDeVersion(
                        // La descripción es lo que se lee («No Aplica»); el código («6») solo si
                        // no hay descripción, que es mejor que nada.
                        primeroConTexto(l.descripcionTipoSala(), l.codigoTipoSala()),
                        primeroConTexto(l.descripcionViaAcceso(), l.codigoViaAcceso()),
                        l.datosAdicionalesSiniestro() == null ? null
                                : l.datosAdicionalesSiniestro().uen()));
    }

    /**
     * Las novedades sin sus repeticiones.
     *
     * <p>El sistema de registro guarda novedades idénticas varias veces —medido el 2026-10-21: en
     * la línea 1 de CM-4146 V6, la 223-1A doce veces—. Se agrupan por código, texto y anulación
     * en el orden en que aparece la primera de cada grupo, y se cuenta cuántas eran. La severidad
     * y el origen son los de la primera: con el mismo código y texto, el catálogo da la misma
     * severidad.
     */
    static List<NovedadDeVersion> agrupadas(List<OhiNovedadDeVersion> novedades) {
        record Clave(String codigo, String texto, boolean anulada) {}
        var grupos = new LinkedHashMap<Clave, NovedadDeVersion>();
        for (var n : novedades) {
            var anulada = DiccionarioOhi.aIndicador(n.overturned());
            grupos.merge(new Clave(n.code(), n.messageText(), anulada),
                         new NovedadDeVersion(n.code(), DiccionarioOhi.aSeveridad(n.severity()),
                                              n.messageText(), n.origin(), anulada, 1),
                         (primera, otra) -> new NovedadDeVersion(
                                 primera.codigo(), primera.severidad(), primera.texto(),
                                 primera.origen(), primera.anulada(),
                                 primera.repeticiones() + 1));
        }
        return List.copyOf(grupos.values());
    }

    private static <A, B> List<B> lista(List<A> externos, Function<A, B> traducir) {
        if (externos == null) return List.of();
        return externos.stream().filter(java.util.Objects::nonNull).map(traducir).toList();
    }

    /** {@code numeroSecuencia} llega como cadena: medido, «0» y «1». Lo que no es número, nulo. */
    private static Integer entero(String valor) {
        if (valor == null || valor.isBlank()) return null;
        try {
            return Integer.valueOf(valor.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String primeroConTexto(String preferido, String alternativo) {
        return preferido != null && !preferido.isBlank() ? preferido : alternativo;
    }

    // ── Contrato externo ────────────────────────────────────────────────────

    /**
     * Una fila de {@code ctrclaimlines} tal como la publica OHI con las proyecciones
     * {@link CamposOhi#LINEA_VERSION} y {@link CamposOhi#DETALLE_LINEA_VERSION}.
     *
     * <p><b>No es {@code OhiClaimLineItem}</b> aunque los nombres coincidan: allí los importes
     * son {@code {currency, value}} y aquí números planos. Decodificar esta fila con aquel tipo
     * dejaría todos los importes en nulo sin un solo error.
     */
    record OhiLineaDeVersion(
            Integer sequence, String status, LocalDate startDate, LocalDate endDate,
            String procedureCode, String procedureDescription, String procedureCodeDef,
            String servicedEntityCode, String servicedEntityName,
            String authorizationCode, String serviceProvCode, String serviceProvName,
            BigDecimal claimedAmount, BigDecimal claimedNumberOfUnits,
            BigDecimal allowedAmount, BigDecimal allowedNumberOfUnits,
            BigDecimal coveredAmount, BigDecimal coveredNumberOfUnits,
            BigDecimal valorGlosado,
            @JsonProperty("montoIVACalculado") BigDecimal montoIVACalculado,
            @JsonProperty("porcentajeIVA") BigDecimal porcentajeIVA,
            List<OhiGlosaDeVersion> detallesGlosa,
            @JsonProperty("codeTariffISS2000") String codeTariffISS2000,
            @JsonProperty("codeTariffISS2001") String codeTariffISS2001,
            @JsonProperty("codeTariffSOAT") String codeTariffSOAT,
            // Sin numeroContrato: la foto de producción no lo tiene (ver CamposOhi).
            String homologoCups,
            String codigoTipoSala, String descripcionTipoSala,
            String codigoViaAcceso, String descripcionViaAcceso,
            OhiDatosSiniestro datosAdicionalesSiniestro,
            List<OhiNovedadDeVersion> ctrClaimLineMessageList,
            List<OhiDiagnosticoDeVersion> ctrClaimLineDiagnosisList,
            List<OhiClausulaDeVersion> ctrClaimLineProviderPricingClauseList) {}

    /** {@code numeroSecuencia} es una cadena de hasta dos caracteres en su definición. */
    record OhiGlosaDeVersion(String numeroSecuencia, String codigoGlosa, BigDecimal valorGlosa,
                             String codigoNotaCredito, BigDecimal valorNotaCredito,
                             String descripcionGenerico, String descripcionEspecifico,
                             String texto, String descripcionTipoGlosa) {}

    /** {@code overturned} es un booleano JSON —su definición lo declara así—, no «Y»/«N». */
    record OhiNovedadDeVersion(String code, String severity, String messageText, String origin,
                               Boolean overturned) {}

    record OhiDiagnosticoDeVersion(Integer sequence, String code, String description,
                                   String typeDescription) {}

    record OhiClausulaDeVersion(Integer sequence, BigDecimal amount,
                                String providerPricingClauseDescr, String methodRuleCode) {}

    /** El campo se llama {@code UEN}, en mayúsculas: con el nombre en minúsculas no se leería. */
    record OhiDatosSiniestro(@JsonProperty("UEN") String uen) {}

    private record OhiSoloId(String id) {}
}
