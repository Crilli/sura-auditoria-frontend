package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiClaimItem;
import co.sura.auditoria.acl.ohi.externo.OhiInstante;
import co.sura.auditoria.acl.ohi.externo.OhiReferencia;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroCuentas;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ResumenCuenta;
import co.sura.auditoria.modelo.cuenta.VersionCuenta;
import co.sura.auditoria.modelo.puertos.PuertoBusquedaCuentas;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * La búsqueda de cuentas médicas y sus versiones.
 *
 * <h3>El filtro que nadie pide y siempre viaja</h3>
 * {@code processType.eq('C')}. El universo del sistema de registro no son cuentas médicas sino
 * cuentas <b>y reservas</b>, y las reservas son mayoría: medido el 2026-10-17, 11.395 frente a
 * 66.223, el 85 %. Sin esta condición la lista sería casi toda reservas y nada lo avisaría.
 *
 * <h3>Las versiones van por otro recurso, y en dos pasos</h3>
 * Viven en {@code ctrclaims}, que es el histórico de lo transmitido. Y <b>no se puede filtrar
 * allí por número de factura</b> —medido: responde 500 {@code GEN-PROC-ERR}— así que el camino
 * es: buscar las cuentas en {@code claims} por lo que el auditor tecleó, y preguntar al
 * histórico por los códigos que salieron.
 */
@Component
public class AdaptadorBusquedaCuentasOhi implements PuertoBusquedaCuentas {

    /**
     * Cuántas filas de histórico se traen por vuelta.
     *
     * <p>Una página de 25 cuentas con tres versiones cada una son unas 75 filas, pero el
     * buscador admite páginas de 50 y una cuenta puede tener decenas de versiones. El sistema
     * de registro corta en 200 <b>sin avisar</b> de que hay más, así que no basta con pedir el
     * máximo: se recorre por keyset hasta que una vuelta llega incompleta.
     */
    private static final int LOTE_VERSIONES = SolicitudBusqueda.LIMITE_MAXIMO;

    /**
     * Freno del recorrido: diez vueltas son 2.000 versiones para una página de cuentas, muy por
     * encima de lo medido. Si se alcanza, se entrega lo leído y se deja dicho en el log.
     */
    private static final int MAXIMO_VUELTAS_VERSIONES = 10;

    private static final org.slf4j.Logger log =
            org.slf4j.LoggerFactory.getLogger(AdaptadorBusquedaCuentasOhi.class);

    private final WebClient clientePaciente;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final AdaptadorPrestadoresOhi adaptadorPrestadores;

    public AdaptadorBusquedaCuentasOhi(
            @org.springframework.beans.factory.annotation.Qualifier(
                    co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
            WebClient clientePaciente,
            ConfiguracionResiliencia resiliencia,
            TraductorErrores traductorErrores,
            AdaptadorPrestadoresOhi adaptadorPrestadores) {
        this.clientePaciente = clientePaciente;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.adaptadorPrestadores = adaptadorPrestadores;
    }

    @Override
    public Mono<PaginaDesplazada<ResumenCuenta>> buscar(FiltroCuentas filtro, int desplazamiento,
                                                        int tamanoPagina) {
        var desde = Math.max(0, desplazamiento);
        var tamano = SolicitudBusqueda.limitarAlMaximo(tamanoPagina);

        // El tipo de proceso va primero y siempre. Ver el javadoc de la clase.
        var constructor = ConstructorConsulta.igual("processType", "C");
        if (filtro.numeroFactura() != null)
            constructor.yIgual("numeroFactura", filtro.numeroFactura());
        if (filtro.radicado() != null)
            constructor.yEmpiezaPor("code", filtro.radicado());

        var solicitud = SolicitudBusqueda.desplazada(
                constructor.construir(), CamposOhi.RESUMEN_CUENTA,
                // Por fecha de radicación descendente: lo que se busca suele ser lo reciente.
                "receiptDate desc", desde, tamano, true);

        return clientePaciente.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .flatMap(respuesta -> conNombresDePrestador(respuesta, desde, tamano));
    }

    /**
     * Resuelve la razón social de los prestadores de la página, en una sola consulta.
     *
     * <p>Lo normal es que una página repita pocos prestadores distintos, así que pedirlos por
     * lote es una llamada en vez de veinticinco. Si el padrón no responde, la lista sale con el
     * NIT y sin nombre: es peor de leer, pero sigue siendo la lista.
     */
    private Mono<PaginaDesplazada<ResumenCuenta>> conNombresDePrestador(
            OhiSearchResponse<OhiClaimItem> respuesta, int desde, int tamano) {

        var items = respuesta.items() == null ? List.<OhiClaimItem>of() : respuesta.items();
        var nits = items.stream()
                .map(i -> OhiReferencia.codigoDe(i.claimantProvider()))
                .filter(java.util.Objects::nonNull)
                .distinct()
                .toList();

        return adaptadorPrestadores.nombresPorCodigo(nits)
                .defaultIfEmpty(java.util.Map.of())
                .map(nombres -> PaginaDesplazada.deOhi(
                        items.stream().map(i -> aResumen(i, nombres)).toList(),
                        desde, tamano, respuesta.totalResults(),
                        respuesta.hayMas(desde, items.size(), tamano)));
    }

    private static ResumenCuenta aResumen(OhiClaimItem externo,
                                          java.util.Map<String, String> nombres) {
        var nit = OhiReferencia.codigoDe(externo.claimantProvider());
        return new ResumenCuenta(
                new CodigoCuenta(externo.code()),
                externo.numeroFactura(),
                externo.receiptDate(),
                nit,
                nit == null ? null : nombres.get(nit),
                externo.valorFactura(),
                DiccionarioOhi.aEstado(externo.status()),
                externo.status());
    }

    // ── Versiones ───────────────────────────────────────────────────────────

    @Override
    public Mono<List<VersionCuenta>> versionesDe(List<CodigoCuenta> codigos) {
        if (codigos == null || codigos.isEmpty()) return Mono.just(List.of());
        var valores = codigos.stream().map(CodigoCuenta::valor).distinct().toList();
        return siguienteVuelta(valores, 0L, new java.util.ArrayList<>(), 0);
    }

    /**
     * Una vuelta del recorrido por keyset.
     *
     * <p>El avance va por {@code id} y el orden también: si se ordenara por número de versión y
     * se avanzara por id, las filas cuyo id no crece en el mismo sentido quedarían debajo del
     * corte sin haberse leído nunca. El orden de las versiones lo pone quien las pinta.
     */
    private Mono<List<VersionCuenta>> siguienteVuelta(List<String> codigos, long cursor,
                                                      List<VersionCuenta> acumulado, int vuelta) {
        if (vuelta >= MAXIMO_VUELTAS_VERSIONES) {
            log.warn("Se alcanzaron {} vueltas leyendo versiones de {} cuenta(s): se entregan las "
                     + "{} leídas y puede haber más", vuelta, codigos.size(), acumulado.size());
            return Mono.just(List.copyOf(acumulado));
        }

        var constructor = ConstructorConsulta.contenidoEn("code", codigos)
                // Sin esto, cada versión vendría dos veces —ella y su gemela de reversión— y
                // la pantalla enseñaría cinco versiones donde hay tres.
                .yIgual("reversal", false);
        if (cursor > 0) constructor.yMayorQue("id", cursor);

        var solicitud = SolicitudBusqueda.de(
                constructor.construir(), CamposOhi.VERSION_CUENTA,
                "id asc", LOTE_VERSIONES, false);

        return clientePaciente.post()
                .uri("/generic/ctrclaims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiVersion>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> {
                    var filas = r.isEmpty() ? List.<OhiVersion>of() : r.items();
                    filas.stream().map(AdaptadorBusquedaCuentasOhi::aVersion).forEach(acumulado::add);
                    if (filas.size() < LOTE_VERSIONES) return Mono.just(List.copyOf(acumulado));

                    var ultimo = filas.get(filas.size() - 1).id();
                    // Si el cursor no avanza se corta: es la única forma de no dar vueltas
                    // sobre el mismo lote.
                    if (ultimo == null || ultimo <= cursor) return Mono.just(List.copyOf(acumulado));
                    return siguienteVuelta(codigos, ultimo, acumulado, vuelta + 1);
                })
                .defaultIfEmpty(List.copyOf(acumulado));
    }

    @Override
    public Mono<co.sura.auditoria.modelo.cuenta.FotoVersion> fotoDeVersion(CodigoCuenta codigo,
                                                                         int numero) {
        var consulta = ConstructorConsulta.igual("code", codigo.valor())
                .yIgual("version", numero)
                // La gemela de reversión tiene el mismo código y número: sin esto podría
                // salir ella, con sus importes en negativo o anulados.
                .yIgual("reversal", false)
                .construir();
        var solicitud = SolicitudBusqueda.unica(consulta, CamposOhi.FOTO_VERSION);

        return clientePaciente.post()
                .uri("/generic/ctrclaims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiFoto>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .map(AdaptadorBusquedaCuentasOhi::aFoto);
    }

    private static co.sura.auditoria.modelo.cuenta.FotoVersion aFoto(OhiFoto f) {
        var historial = f.ctrStatusHistoryList() == null
                ? List.<co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion>of()
                : f.ctrStatusHistoryList().stream()
                        .filter(e -> e.statusDateTime() != null)
                        // Traducido como el de la cuenta: el histórico escribe en el español de
                        // OHI («Pendiente») y la cuenta en el del dominio (ADJUDICACION_MANUAL).
                        .map(e -> new co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion(
                                DiccionarioOhi.estadoDelHistoricoLegible(e.status()),
                                OhiInstante.aInstante(e.statusDateTime())))
                        // Llegan desordenadas: se ordenan para que la última sea la actual.
                        .sorted(Comparator.comparing(
                                co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion::desde,
                                Comparator.nullsFirst(Comparator.naturalOrder())))
                        .toList();
        return new co.sura.auditoria.modelo.cuenta.FotoVersion(
                new CodigoCuenta(f.code()), f.version() == null ? 0 : f.version(),
                f.entryDate(), f.numeroFactura(), f.claimantName(), f.valorFactura(),
                f.totalClaimedAmount(), f.totalAllowedAmount(), f.totalCoveredAmount(),
                f.totalValorGlosado(), f.totalValorNotasCredito(), soloEstaVuelta(historial));
    }

    /**
     * Los estados de <b>esta</b> versión: lo que hay después del cierre de la anterior.
     *
     * <p>{@code ctrStatusHistoryList} es <b>acumulativo</b>: la versión N trae toda la historia de
     * la cuenta hasta su finalización, con N «Finalizado» —medido el 2026-10-19 en UAT, versión a
     * versión, sobre CM-29939061906 (V1…V8: 1…8) y CM-56540612898 (V1…V6: 1…6)—. Publicarlo
     * entero bajo «por dónde pasó esta versión» enseñaba ocho finalizaciones y estados del día de
     * la radicación como si fueran de la V8. La vuelta de esta versión empieza justo después del
     * penúltimo «Finalizado», que es el cierre de la anterior. Con uno o ninguno —la V1, o una
     * foto sin cierre— no hay nada que quitar.
     */
    static List<co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion> soloEstaVuelta(
            List<co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion> historial) {
        var finalizada = co.sura.auditoria.modelo.cuenta.EstadoCuenta.FINALIZADA.name();
        int cierres = 0, cierreAnterior = -1, ultimoCierre = -1;
        for (int i = 0; i < historial.size(); i++) {
            if (finalizada.equals(historial.get(i).estado())) {
                cierres++;
                cierreAnterior = ultimoCierre;
                ultimoCierre = i;
            }
        }
        return cierres < 2 ? historial : historial.subList(cierreAnterior + 1, historial.size());
    }

    /** La foto tal como la publica {@code ctrclaims}: importes como números planos. */
    private record OhiFoto(Long id, String code, Integer version, LocalDate entryDate,
                           String numeroFactura, String claimantName, BigDecimal valorFactura,
                           BigDecimal totalClaimedAmount, BigDecimal totalAllowedAmount,
                           BigDecimal totalCoveredAmount, BigDecimal totalValorGlosado,
                           BigDecimal totalValorNotasCredito,
                           List<OhiEstadoVersion> ctrStatusHistoryList) {}

    private static VersionCuenta aVersion(OhiVersion externa) {
        var ultimo = ultimoEstado(externa.ctrStatusHistoryList());
        return new VersionCuenta(
                new CodigoCuenta(externa.code()),
                externa.version() == null ? 0 : externa.version(),
                externa.entryDate(),
                externa.valorFactura(),
                ultimo == null ? null : DiccionarioOhi.estadoDelHistoricoLegible(ultimo.status()),
                ultimo == null ? null : OhiInstante.aInstante(ultimo.statusDateTime()));
    }

    /**
     * El estado de la versión: el de la fecha más reciente.
     *
     * <p>La lista <b>no viene ordenada</b> —medido: la primera entrada de una versión era de
     * seis días después que la tercera— así que tomar la primera daría un estado cualquiera de
     * la historia de esa versión en vez del actual.
     */
    private static OhiEstadoVersion ultimoEstado(List<OhiEstadoVersion> historia) {
        if (historia == null) return null;
        return historia.stream()
                .filter(e -> e.statusDateTime() != null)
                .max(Comparator.comparing(e -> OhiInstante.aInstante(e.statusDateTime()),
                                          Comparator.nullsFirst(Comparator.naturalOrder())))
                .orElse(null);
    }

    /**
     * Una fila del histórico.
     *
     * <p>Los nombres están en español porque así los publica el sistema de registro: son
     * extensiones de SURA. Y el estado de aquí también viene en español —«Finalizado»,
     * «Pendiente»— mientras que el de {@code claims} viene en inglés. Es el mismo estado
     * escrito de dos formas, y por eso se traduce con otra tabla
     * ({@link DiccionarioOhi#estadoDelHistoricoLegible}) hasta el mismo nombre del dominio.
     */
    private record OhiVersion(Long id, String code, Integer version, Boolean reversal,
                              LocalDate entryDate, BigDecimal valorFactura,
                              @JsonProperty("ctrStatusHistoryList")
                              List<OhiEstadoVersion> ctrStatusHistoryList) {}

    private record OhiEstadoVersion(String status, OhiInstante statusDateTime) {}
}
