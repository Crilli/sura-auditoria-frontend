package co.sura.auditoria.acl.ohi.externo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Representación de una cuenta (claim) en OHI.
 *
 * <p>Los nombres y las formas corresponden a lo que devuelve realmente
 * {@code POST /generic/claims/search}: los importes principales son objetos con
 * moneda ({@code {"currency":"COP","value":…}}), pero los campos de facturación
 * ({@code valorFactura}, {@code valorTotalFactura}, {@code totalValorGlosado},
 * {@code valorNotaCredito}) son escalares numéricos planos — así los declara
 * {@code /generic/claims/metadata}, a diferencia de los totales de auditoría.
 *
 * <p>OHI publica el afiliado ({@code person}) en la línea en unas cuentas y en la
 * cabecera en otras. Se lee primero el de la línea —una misma cuenta puede agrupar
 * líneas de personas distintas— y el de aquí sirve de respaldo.
 *
 * <p>Los campos de facturación (radicado, factura, marcas, observaciones) son
 * extensiones propias de la instalación de SURA, confirmadas contra
 * {@code /generic/claims/metadata}; no forman parte del OHI de base.
 */
public record OhiClaimItem(
        Long id,
        String code,
        String status,
        LocalDate startDate,
        LocalDate endDate,
        OhiMonto totalAllowedAmount,
        OhiMonto totalCoveredAmount,
        OhiMonto totalClaimedAmount,
        /** Afiliado a nivel de cuenta. Respaldo cuando la línea no lo trae. */
        OhiReferencia person,

        // ── Facturación y radicación (extensión SURA) ───────────────────────
        /** Prestador que radica la factura. Su {@code code} trae el NIT-sucursal. */
        OhiReferencia claimantProvider,
        /** Prestador al que se le paga; puede diferir de {@code claimantProvider}. */
        OhiReferencia paymentReceiverProvider,
        String numeroFactura,
        /** Fecha de radicación de la cuenta ante el pagador. */
        LocalDate receiptDate,
        LocalDate fechaEmisionFactura,
        LocalDate fechaVencimiento,
        LocalDate fechaIngresoAtencion,
        LocalDate fechaEgresoAtencion,
        BigDecimal valorFactura,
        BigDecimal valorTotalFactura,
        BigDecimal totalValorGlosado,
        BigDecimal valorNotaCredito,
        OhiClaseServicio claseServicio,
        String acuseRecibido,
        OhiFlexCode radicadoATEP,
        OhiFlexCode multicore,
        OhiFlexCode pendienteManual,
        String internalRemarks,
        String externalRemarks,

        Long objectVersionNumber,
        List<OhiLink> links) {}
