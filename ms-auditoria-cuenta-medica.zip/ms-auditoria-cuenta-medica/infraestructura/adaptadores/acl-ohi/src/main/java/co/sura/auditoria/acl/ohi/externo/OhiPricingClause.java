package co.sura.auditoria.acl.ohi.externo;

/**
 * Cláusula de tarifación aplicada a una línea
 * ({@code /generic/claimlineproviderpricingclauses}).
 *
 * <p>Una línea suele tener dos: la del <b>contrato</b> con el prestador, que es
 * la tarifa de contrato, y una o varias de <b>regla</b> que la ajustan. La suma de
 * todas da el valor convenido ({@code allowedAmount}).
 *
 * <p>Ejemplo real (línea 152384759531 de CM-109427947186): la cláusula 1 es
 * «Prestador 8200011814 Propuesta 5 versión 1 Manual tarifario SOAT Porcentaje
 * 100.0» por 100.969,72 y la 2 es {@code REGLA_CUENTA_MEDICA} por −21.891,72;
 * el neto, 79.078, es el valor convenido. En la foto de CM-4146 pasa lo mismo:
 * 38.758,16 − 9.689,16 = 29.069, que es exactamente su {@code allowedAmount}.
 * Hasta el 2026-10-21 este comentario llamaba «autorizado» a ese neto; negocio fijó
 * entonces que el autorizado es {@code coveredAmount}, lo que reconoce la cobertura.
 */
public record OhiPricingClause(Long id,
                               Integer sequence,
                               OhiMonto amount,
                               OhiProviderPricingClauseRef providerPricingClause,
                               OhiClaimLineRefSimple claimLine) {

    public record OhiProviderPricingClauseRef(String id, String descr) {}
    public record OhiClaimLineRefSimple(Long id) {}

    /**
     * {@code true} si es la cláusula del contrato y no un ajuste de regla.
     *
     * <p>OHI no marca la diferencia con un campo: se lee del texto. Las de
     * regla empiezan por {@code REGLA_}, {@code RM_} o {@code RA_}; las de
     * contrato nombran al prestador y su manual tarifario.
     */
    public boolean esDeContrato() {
        var d = providerPricingClause == null ? null : providerPricingClause.descr();
        if (d == null || d.isBlank()) return false;
        var t = d.trim().toUpperCase();
        return !(t.startsWith("REGLA_") || t.startsWith("RM_") || t.startsWith("RA_"));
    }
}
