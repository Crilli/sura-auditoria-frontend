package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Un elemento de {@code claimLineMessageList} dentro del parche de una línea.
 *
 * <p><b>Ojo con dónde está el contrato de esto.</b> Los demás DTO de parche de
 * este paquete citan {@code GET /claimsupdate/definition}, pero allí la
 * definición {@code claimlinemessage} <b>no tiene la propiedad {@code message}</b>
 * y en su lugar publica un {@code code} y un {@code tecMessageSeverity}. El que
 * manda es el genérico ({@code GET /generic/claimlinemessages/definition}),
 * porque este proyecto escribe con {@code PATCH /generic/claims/{id}}. Quien
 * venga a mirar al sitio de siempre no va a encontrar el campo, de ahí el aviso.
 *
 * <p>Comprobado contra UAT el 15-oct-2026 sobre la línea {@code 84054990788}:
 * <ul>
 *   <li>el alta mínima es <b>{@code op}, {@code origin} y {@code message}</b>, y
 *       devuelve {@code 200}. La referencia al catálogo vale <b>tanto por
 *       {@code id} como por {@code code}</b>: se eligió el código, que es el que
 *       el auditor reconoce y la normativa cita;</li>
 *   <li>un código que no existe se rechaza con
 *       {@code 422 GEN-HTTP-002} nombrando lo que no encontró, así que no hace
 *       falta validar la existencia antes de mandarlo;</li>
 *   <li><b>{@code severity} no es un campo de esto.</b> La interfaz de OHI lo
 *       manda —se ve en el cuerpo que genera— y OHI lo ignora: la severidad es
 *       del mensaje del catálogo. Lo mismo vale para el {@code rowId},
 *       {@code _id} y {@code _rowId} que aparecen en ese cuerpo: son andamiaje
 *       de su propio componente de tabla;</li>
 *   <li><b>no hay {@code numeroSecuencia}</b>, al contrario que en
 *       {@link OhiDetalleGlosaPatch}, donde omitirlo daba
 *       {@code 422 COD-FCFU-101};</li>
 *   <li>la novedad <b>sobrevive al recálculo</b> ({@code reprocess=true}), así
 *       que ponerla y recalcular pueden viajar en el mismo parche;</li>
 *   <li>los <b>«Valor 0»…«Valor 9»</b> se escriben y se guardan, pero OHI
 *       <b>no los sustituye</b> al devolver el mensaje, y tampoco comprueba que
 *       estén: acepta igual una plantilla con marcadores sin rellenar. Los dos
 *       frenos están en el caso de uso.</li>
 * </ul>
 *
 * <p>Se serializa sin nulos por lo mismo que {@link OhiLinePatch}.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record OhiNovedadPatch(
        String op,
        /** Solo en la baja: identifica cuál se quita. */
        String id,
        /** Solo en el alta. Ver {@link #ORIGEN_MANUAL}. */
        String origin,
        /** Solo en el alta: la referencia al catálogo. */
        Mensaje message,

        // ── Los datos que completan el texto ───────────────────────────────
        //
        // OHI los rotula «Valor 0»…«Valor 9» y son los que sustituyen los
        // marcadores {0}..{9} de la plantilla del mensaje. **Él no los
        // sustituye**: al leer devuelve la plantilla con las llaves y estos
        // valores aparte, así que componer el texto es cosa de quien lo pinta.
        //
        // Diez campos sueltos y no una lista porque así los publica OHI. Cada
        // uno admite 300 caracteres; pasarse da 422 GEN-ORA-12899.
        String value0, String value1, String value2, String value3, String value4,
        String value5, String value6, String value7, String value8, String value9) {

    /**
     * El origen que marca lo que puso una persona.
     *
     * <p>Es una constante de este DTO y no un parámetro: los otros catorce
     * valores del vocabulario de OHI son etapas de su motor, y dejar que el
     * valor llegue de fuera permitiría grabar una novedad que aparenta haberla
     * levantado el sistema.
     */
    public static final String ORIGEN_MANUAL = "MANUAL";

    /** Referencia al mensaje del catálogo, por código. */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Mensaje(String code) {}

    /**
     * Alta: el origen, el código del mensaje y los datos que completan su texto.
     *
     * @param valores por índice de marcador. Los que no estén viajan nulos y
     *     {@code @JsonInclude(NON_NULL)} los deja fuera del cuerpo
     */
    public static OhiNovedadPatch alta(String codigoMensaje,
                                       java.util.Map<Integer, String> valores) {
        var v = valores == null ? java.util.Map.<Integer, String>of() : valores;
        return new OhiNovedadPatch("add", null, ORIGEN_MANUAL, new Mensaje(codigoMensaje),
                v.get(0), v.get(1), v.get(2), v.get(3), v.get(4),
                v.get(5), v.get(6), v.get(7), v.get(8), v.get(9));
    }

    /**
     * Baja: solo la operación y el identificador.
     *
     * <p>Sin {@code origin}, aunque la definición lo marque obligatorio: en la
     * baja se comprobó que sobra, y mandarlo invita a que el sistema de registro
     * lo lea como una modificación previa al borrado.
     */
    public static OhiNovedadPatch baja(long identificador) {
        return new OhiNovedadPatch("remove", String.valueOf(identificador), null, null,
                null, null, null, null, null, null, null, null, null, null);
    }
}
