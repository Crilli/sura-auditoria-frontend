package co.sura.auditoria.acl.ohi.cliente;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Proveedor del token OAuth2 (Client Credentials) para autenticarse contra OHI.
 *
 * <p>El método {@code obtenerToken()} está cacheado. Caffeine se encarga de
 * la expiración (configurada en el YAML un poco antes del TTL real del token).
 */
@Component
public class ProveedorTokenOhi {

    private static final Logger log = LoggerFactory.getLogger(ProveedorTokenOhi.class);

    private final WebClient webClient;
    private final PropiedadesOhi propiedades;
    private final String basicAuthHeader;

    public ProveedorTokenOhi(WebClient.Builder builder, PropiedadesOhi propiedades) {
        this.propiedades = propiedades;
        this.webClient = builder.baseUrl(propiedades.tokenUrl()).build();

        var credenciales = propiedades.clientId() + ":" + propiedades.clientSecret();
        this.basicAuthHeader = "Basic " + Base64.getEncoder().encodeToString(
                credenciales.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Obtiene el Bearer token (de la caché si está disponible).
     * @return el token JWT para los encabezados de autorización.
     */
    @Cacheable("tokenOhi")
    public Mono<String> obtenerToken() {
        log.debug("Solicitando nuevo token OAuth2 a OHI");

        var formData = new LinkedMultiValueMap<String, String>();
        formData.add("grant_type", "client_credentials");
        formData.add("scope", propiedades.scope());

        return webClient.post()
                .header(HttpHeaders.AUTHORIZATION, basicAuthHeader)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(BodyInserters.fromFormData(formData))
                .retrieve()
                .bodyToMono(TokenResponse.class)
                .map(TokenResponse::access_token)
                .doOnNext(t -> log.debug("Token obtenido exitosamente"));
    }

    /**
     * Tira el token guardado para que la próxima llamada pida uno nuevo.
     *
     * <p>Lo invoca {@link FiltroAutenticacionOhi} cuando OHI responde 401, que es la única
     * señal fiable de que el token ya no sirve: la caducidad por tiempo es una estimación y
     * se ha visto fallar —un servicio ocioso empezó a recibir 401 a los 68 minutos y no se
     * recuperó solo—.
     *
     * <p>Se vacía la caché entera y no una clave porque solo hay un token: el método no lleva
     * argumentos, así que su clave es la única que existe.
     */
    @CacheEvict(value = "tokenOhi", allEntries = true)
    public void olvidarToken() {
        log.info("Token de OHI descartado: el sistema de registro lo rechazó");
    }

    record TokenResponse(String access_token, String token_type, int expires_in) {}
}
