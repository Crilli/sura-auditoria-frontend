package co.sura.auditoria.acl.ohi.consulta;

/**
 * Cuerpo del POST /generic/{recurso}/search.
 *
 * <p>El contrato de OHI ({@code GET /generic/claims/metadata}, esquema
 * {@code searchresource}) tiene <b>dos</b> objetos de primer nivel:
 * <ul>
 *   <li>{@code resource} — qué se busca: {@code q}, {@code limit}, {@code orderBy}…</li>
 *   <li>{@code resourceRepresentation} — cómo se quiere la respuesta:
 *       {@code defaultoverride}, {@code excludereferenceresources}, {@code excludelinks},
 *       {@code fields}…</li>
 * </ul>
 *
 * <p>Enviar los parámetros de representación dentro de {@code resource} no produce
 * ningún error: OHI simplemente los ignora, y devuelve el recurso completo.
 * <b>Eso incluye a {@code resource.fields}</b>: la proyección solo se respeta en
 * {@code resourceRepresentation}, y solo junto a {@code defaultoverride} — ver
 * {@link #proyectada}.
 */
public record SolicitudBusqueda(ResourceRepresentation resourceRepresentation, Resource resource) {

    public record Resource(String q, String fields, String orderBy,
                           Integer limit, Boolean totalResults) {}

    /**
     * Controla la forma de la respuesta. Un {@code null} deja el valor por omisión de OHI.
     *
     * <p>El contrato admite además {@code aliases}, {@code expand} y {@code response},
     * que no se envían a propósito. {@code aliases} ({@code person^p|referralProvider^rp})
     * se probó junto a la proyección y no aporta: no añade campos ni recupera los
     * {@code links}. Para las referencias sirve {@code person.id}, que es lo que se usa.
     *
     * <p><b>{@code expand} en particular no debe activarse.</b> Su valor por omisión ya
     * es conservador —se midió que omitirlo, {@code "none"} y {@code "self"} dan tiempos
     * indistinguibles: medianas de 8,55 / 8,99 / 9,71 s sobre {@code CM-55181980659}, con
     * una dispersión interna de ±2 s que se come la diferencia—. En cambio
     * {@code expand="all"} es una mina: la misma consulta no terminó en 90 s y llevaba
     * 35 MB descargados.
     */
    public record ResourceRepresentation(String defaultoverride,
                                         String excludereferenceresources,
                                         String excludelinks,
                                         String fields) {}

    /**
     * Representación de la consulta que existe solo para leer los enlaces HATEOAS.
     *
     * <p>Sin {@code defaultoverride}: es justo lo que los borra. A cambio OHI
     * materializa su proyección por omisión y la consulta cuesta ~8 s, así que esta
     * representación se reserva para {@code consultarAccionesDisponibles} y nunca se
     * usa para pintar. {@code excludereferenceresources} evita al menos arrastrar
     * {@code claimLineList} en el cuerpo: 3 KB en vez de 717 KB, aunque el tiempo no
     * baje.
     */
    private static final ResourceRepresentation SOLO_ENLACES =
            new ResourceRepresentation(null, "true", null, null);

    /**
     * Máximo de registros por consulta que acepta OHI. Pedir más responde
     * {@code 422 GEN-HTTP-015: Valor de límite "N" no puede ser mayor que "200"}.
     */
    public static final int LIMITE_MAXIMO = 200;

    /** Ajusta un límite deseado al máximo que admite el servicio. */
    public static int limitarAlMaximo(int deseado) {
        return Math.min(Math.max(deseado, 1), LIMITE_MAXIMO);
    }

    /**
     * Representación que pide a OHI devolver <b>solo</b> los campos proyectados.
     *
     * <p>{@code defaultoverride=true} es lo que hace que la proyección se respete de
     * verdad. Sin él, OHI ignora {@code fields} y materializa su conjunto por omisión,
     * que es de dónde sale el coste: medido contra {@code CM-55181980659} en PDN, la
     * misma consulta pasa de 8–11 s a <b>~0,12 s</b>, y de 194 KB a 14 KB en las líneas.
     *
     * <p>Ese 0,12 s es con la conexión ya abierta, que es el caso real: el
     * {@code WebClient} de {@code ConfiguracionClienteOhi} tiene pool. Midiéndolo con
     * un {@code curl} por llamada sube a ~0,3 s, pero la diferencia es el handshake
     * TLS, no el servicio.
     *
     * <p>Los mismos parámetros se pueden enviar como parámetros del media type en el
     * {@code Accept} ({@code application/json;defaultoverride=true;fields=…}) en vez de
     * en el cuerpo. Se comprobó que da byte por byte lo mismo y el mismo tiempo; se
     * mantiene en el cuerpo porque queda tipado en este record.
     *
     * <p>Además corrige una pérdida silenciosa: hoy los campos anidados no llegan.
     * {@code pendReason} se recibe como <code>{id, links}</code> pese a pedirse
     * {@code pendReason.code}, así que {@code TraductorPendiente} viene leyendo
     * {@code null}. Con la proyección activa llega <code>{code: "MP_…"}</code>.
     *
     * <p><b>El separador es {@code |}, no la coma.</b> Con comas OHI acepta la
     * petición y devuelve una respuesta vacía de campos, sin error.
     *
     * <p><b>Coste: se pierden los {@code links}.</b> Ningún ajuste los recupera —se
     * probó pedirlos en {@code fields}, {@code excludelinks=false} y los valores de
     * {@code response}—, así que quien necesite los enlaces debe usar
     * {@link #soloEnlaces}, no esta representación.
     */
    private static ResourceRepresentation proyectada(String campos) {
        return new ResourceRepresentation("true", null, null, aProyeccion(campos));
    }

    /**
     * Traduce la lista separada por comas de {@link CamposOhi} al formato que espera
     * {@code resourceRepresentation.fields}.
     */
    private static String aProyeccion(String campos) {
        return campos == null ? null : campos.replace(",", "|");
    }

    public static SolicitudBusqueda de(String consulta, String campos, String orden,
                                       int limite, boolean incluirTotal) {
        return new SolicitudBusqueda(proyectada(campos),
                new Resource(consulta, null, orden, limite, incluirTotal));
    }

    public static SolicitudBusqueda unica(String consulta, String campos) {
        return new SolicitudBusqueda(proyectada(campos),
                new Resource(consulta, null, null, 1, false));
    }

    /**
     * Cabecera de la cuenta: solo los campos que la interfaz pinta.
     *
     * <p>Usa la proyección, así que <b>no trae los enlaces HATEOAS</b> y por tanto
     * tampoco las acciones disponibles. Es deliberado: esas se piden aparte con
     * {@link #soloEnlaces}, para que el pintado no espere por ellas. Medido sobre
     * {@code CM-55181980659}: ~8 s antes, ~0,12 s ahora.
     */
    public static SolicitudBusqueda cabecera(String consulta, String campos) {
        return new SolicitudBusqueda(proyectada(campos),
                new Resource(consulta, null, null, 1, false));
    }

    /**
     * Consulta cuyo único propósito es leer los enlaces HATEOAS de la cuenta.
     *
     * <p>No proyecta —no puede: la proyección es lo que elimina los enlaces— así que
     * paga los ~8 s de la representación completa. Va aislada para que ese coste no
     * caiga sobre la cabecera. Ver {@link #SOLO_ENLACES}.
     */
    public static SolicitudBusqueda soloEnlaces(String consulta) {
        return new SolicitudBusqueda(SOLO_ENLACES,
                new Resource(consulta, CamposOhi.SOLO_ID, null, 1, false));
    }
}
