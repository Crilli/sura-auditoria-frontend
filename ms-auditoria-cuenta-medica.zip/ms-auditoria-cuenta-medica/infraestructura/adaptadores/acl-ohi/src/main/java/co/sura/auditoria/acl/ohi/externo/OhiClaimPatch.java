package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Cuerpo del PATCH sobre /generic/claims/{id}.
 *
 * <p><b>La colección se llama {@code claimLineList}, no {@code claimLines}.</b>
 * Lo publica así el contrato de escritura de OHI
 * ({@code GET /claimsupdate/definition}, definición {@code claim}: sus ocho
 * colecciones son claimLineList, claimDiagnosisList, claimMessageList,
 * claimPendReasonList, claimSubmitHistoryList, claimTagActionList,
 * claimUnfinalizeReasonList y respuestaGlosa) y también la consulta genérica.
 * Con el nombre anterior OHI recibía un campo que no conoce y los parches de
 * línea no llegaban a aplicarse.
 */
public record OhiClaimPatch(
        Long objectVersionNumber,
        @JsonProperty("claimLineList") List<OhiLinePatch> lineas) {}
