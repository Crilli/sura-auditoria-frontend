package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Cuerpo del PATCH sobre /generic/claims/{id}.
 *
 * <p><b>La colección se llama {@code claimLineList}, no {@code claimLines}.</b>
 * Lo publica así el contrato de escritura de OHI
 * ({@code GET /claimsupdate/definition}, definición {@code claim}: sus ocho
 * colecciones son claimLineList, claimDiagnosisList, claimMessageList,
 * claimPendReasonList, claimSubmitHistoryList, claimTagActionList,
 * claimUnfinalizeReasonList y respuestaGlosa) y también la consulta genérica.
 * Con el nombre anterior OHI recibía un campo que no conoce y los parches de
 * línea no llegaban a aplicarse.
 */
@com.fasterxml.jackson.annotation.JsonInclude(
        com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
public record OhiClaimPatch(
        Long objectVersionNumber,
        @JsonProperty("claimLineList") List<OhiLinePatch> lineas,
        /**
         * Novedades de la <b>cabecera</b>, cada una con su {@code op}.
         *
         * <p>Cuelga de la cuenta y no de la línea: es la colección hermana de
         * {@code claimLineMessageList}, con la misma forma y el mismo catálogo.
         * Comprobado contra el entorno de pruebas: un alta con
         * {@code {"op":"add","origin":"MANUAL","message":{"code":…}}} responde
         * 200 y sube la versión de la cuenta.
         *
         * <p>{@code null} —y nunca lista vacía— cuando el parche no las toca.
         */
        @JsonProperty("claimMessageList") List<OhiNovedadPatch> novedades) {

    /** Parche que solo toca líneas. */
    public static OhiClaimPatch deLineas(Long version, List<OhiLinePatch> lineas) {
        return new OhiClaimPatch(version, lineas, null);
    }

    /** Parche que solo toca las novedades de la cabecera. */
    public static OhiClaimPatch deNovedades(Long version, List<OhiNovedadPatch> novedades) {
        return new OhiClaimPatch(version, null, novedades);
    }
}
