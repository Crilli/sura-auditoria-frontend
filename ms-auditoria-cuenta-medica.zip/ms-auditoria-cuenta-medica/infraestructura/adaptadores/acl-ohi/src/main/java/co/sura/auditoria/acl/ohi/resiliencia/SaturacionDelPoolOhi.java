package co.sura.auditoria.acl.ohi.resiliencia;

import java.util.Set;
import java.util.function.Predicate;

/**
 * La cola del pool de conexiones propio, llena o vencida: lo que los circuit breakers deben
 * <b>ignorar</b> (OPE-01).
 *
 * <h3>Ignorar, no «no contar»</h3>
 * En Resilience4j lo que no se registra como fallo <em>cuenta como éxito</em>: solo sale de la
 * ventana lo que acepta {@code ignoreExceptionPredicate}. Con OHI colgado, las 30 conexiones
 * quedan retenidas hasta el timeout y casi toda la demanda acaba en la cola del pool; si esos
 * rechazos sumaran éxitos, la tasa de fallos se diluiría por debajo del umbral y el circuito no
 * abriría nunca, justo cuando más falta hace. Encontrado en la revisión adversarial de la Fase 0.
 *
 * <p>Las dos excepciones viven en un paquete sombreado de Reactor Netty, así que se reconocen
 * por nombre en la cadena de causas y no por tipo. Se declara en {@code application.yml} como
 * {@code ignoreExceptionPredicate}; Resilience4j la instancia con su constructor sin argumentos.
 */
public class SaturacionDelPoolOhi implements Predicate<Throwable> {

    private static final Set<String> SATURACION_DEL_POOL = Set.of(
            "PoolAcquirePendingLimitException", "PoolAcquireTimeoutException");

    @Override
    public boolean test(Throwable error) {
        return es(error);
    }

    /** Si el error, o alguna de sus causas, es la cola del pool llena o vencida. */
    static boolean es(Throwable error) {
        for (var causa = error; causa != null; causa = causa.getCause() == causa ? null : causa.getCause()) {
            if (SATURACION_DEL_POOL.contains(causa.getClass().getSimpleName())) return true;
        }
        return false;
    }
}
