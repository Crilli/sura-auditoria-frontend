package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Novedad (claimLineMessage) en OHI.
 *
 * <p>{@code message} <b>puede llegar nulo</b>: en UAT hay novedades manuales de
 * 2025 cuyo mensaje del catálogo ya no se resuelve. Ver {@code TraductorNovedad}.
 *
 * @param createdByUserName quién la creó. Llega sin pedirlo, pero se proyecta
 *                          igual para no depender de eso
 * @param creationDate      cuándo. Viene envuelto, como todas las marcas de
 *                          tiempo de OHI: {@code {"value": "..."}}
 */
public record OhiMessageItem(Long id,
                             OhiMessageRef message,
                             String origin,
                             String createdByUserName,
                             OhiInstante creationDate,
                             String value0, String value1, String value2, String value3,
                             String value4, String value5, String value6, String value7,
                             String value8, String value9) {

    /** Constructor reducido para los sitios que solo leen lo que se pinta. */
    public OhiMessageItem(Long id, OhiMessageRef message, String origin) {
        this(id, message, origin, null, null,
             null, null, null, null, null, null, null, null, null, null);
    }

    /**
     * Los «Valor 0»…«Valor 9» recogidos por índice, saltando los que no vienen.
     *
     * <p>OHI los publica como diez campos sueltos; el dominio los quiere como un
     * mapa porque lo que le importa es qué marcador completa cada uno.
     */
    public java.util.Map<Integer, String> valoresPorIndice() {
        var sueltos = new String[] { value0, value1, value2, value3, value4,
                                     value5, value6, value7, value8, value9 };
        var mapa = new java.util.LinkedHashMap<Integer, String>();
        for (int i = 0; i < sueltos.length; i++) {
            if (sueltos[i] != null && !sueltos[i].isBlank()) mapa.put(i, sueltos[i]);
        }
        return java.util.Map.copyOf(mapa);
    }

    /**
     * Referencia al mensaje del catálogo.
     *
     * <p><b>El texto del mensaje viene en {@code message}</b>, no en
     * {@code description}: el catálogo {@code /generic/messages} lo publica así
     * (p.ej. {@code {"code":"SURA-INFO-02","severity":"I","message":"Cuenta Médica
     * con Glosa Total"}}). Con el nombre antiguo la proyección lo descartaba sin
     * dar error y la novedad llegaba sin texto.
     *
     * <p>{@code severity} es <b>un solo carácter</b> —{@code I}, {@code F} o
     * {@code D}— y no las palabras que se supusieron al principio. Ver la nota
     * del mapa de severidades en {@code DiccionarioOhi}.
     *
     * @param conceptoGenerico  clasificación normativa de primer nivel. Flex code
     *                          con {@code value} y {@code descriptor}; llega vacío
     *                          en muchos mensajes
     * @param conceptoEspecifico de segundo nivel, igual de opcional
     */
    public record OhiMessageRef(String code,
                                String severity,
                                @JsonProperty("message") String descripcion,
                                OhiFlexCode conceptoGenerico,
                                OhiFlexCode conceptoEspecifico,
                                /**
                                 * Lo que OHI rotula «Específico de Sistema?».
                                 * Puede venir nulo si no se proyecta.
                                 */
                                Boolean system) {

        /** Constructor reducido: sin los conceptos, que no siempre se proyectan. */
        public OhiMessageRef(String code, String severity, String descripcion) {
            this(code, severity, descripcion, null, null, null);
        }
    }
}
