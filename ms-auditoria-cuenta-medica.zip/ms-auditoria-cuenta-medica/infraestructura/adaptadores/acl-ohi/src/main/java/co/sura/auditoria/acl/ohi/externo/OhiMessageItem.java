package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

/** Novedad (claimLineMessage) en OHI. */
public record OhiMessageItem(Long id, OhiMessageRef message, String origin) {

    /**
     * Referencia al mensaje del catálogo.
     *
     * <p><b>El texto del mensaje viene en {@code message}</b>, no en
     * {@code description}: el catálogo {@code /generic/messages} lo publica así
     * (p.ej. {@code {"code":"SURA-INFO-02","severity":"I","message":"Cuenta Médica
     * con Glosa Total"}}). Con el nombre antiguo la proyección lo descartaba sin
     * dar error y la novedad llegaba sin texto.
     */
    public record OhiMessageRef(String code, String severity,
                                @JsonProperty("message") String descripcion) {}
}
