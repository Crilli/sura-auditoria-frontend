package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiInstante;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.HitoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoHistoriaCuenta;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * La historia de una cuenta, unida de los dos recursos que la guardan.
 *
 * <h3>Dos recursos y dos nombres distintos para la misma idea</h3>
 * Medido el 2026-10-17 contra producción, leyendo cada {@code /definition}:
 * <ul>
 *   <li>{@code claimstatushistory} fecha sus filas en <b>{@code dateTime}</b>;</li>
 *   <li>{@code claimunfinalizereasons} las fecha en <b>{@code creationDate}</b>.</li>
 * </ul>
 * No hay un nombre común. Y como el sistema de registro <b>no valida</b> la proyección, pedir
 * el nombre equivocado no da error: devuelve la fila sin fecha, y la historia sale ordenada
 * por nada. Por eso cada consulta pide el suyo y está escrito aquí.
 *
 * <p>Las dos se piden a la vez porque son independientes, y se ordenan al unirlas: lo que la
 * pantalla enseña es una secuencia, y que cada recurso venga ordenado por su lado no dice nada
 * del orden entre ellos.
 */
@Component
public class AdaptadorHistoriaOhi implements PuertoHistoriaCuenta {

    /**
     * Tope de hitos por cuenta.
     *
     * <p>Medido: 2,6 millones de cambios de estado en producción, unos 9,6 por cuenta, y la
     * cuenta más movida de la muestra tenía 49. El tope es holgura, no recorte; existe para
     * que una cuenta patológica no se traiga media tabla a la pantalla.
     *
     * <p>Y si se alcanza, lo que se pierde es lo <b>más antiguo</b>: las dos consultas piden
     * {@code id desc}. Con {@code id asc} el corte de 200 —que el sistema de registro hace sin
     * avisar— se quedaba con el principio de la historia y tiraba justo el final, que es lo
     * que se mira: en qué estado está la cuenta y desde cuándo. En UAT hay cuentas con 67
     * versiones, unas 400 transiciones. El orden de la pantalla lo pone {@link #consultar},
     * que ordena por fecha al unir.
     */
    private static final int MAXIMO = 200;

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;

    public AdaptadorHistoriaOhi(WebClient webClient, ConfiguracionResiliencia resiliencia,
                                TraductorErrores traductorErrores) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
    }

    @Override
    public Flux<HitoCuenta> consultar(CodigoCuenta codigo) {
        return Mono.zip(cambiosDeEstado(codigo), desfinalizaciones(codigo))
                .flatMapIterable(tupla -> {
                    var todos = new java.util.ArrayList<HitoCuenta>(tupla.getT1());
                    todos.addAll(tupla.getT2());
                    todos.sort(Comparator.comparing(HitoCuenta::ocurridoEn,
                            Comparator.nullsLast(Comparator.naturalOrder())));
                    return todos;
                });
    }

    /** Los cambios de estado. Fecha en {@code dateTime}; ver el javadoc de la clase. */
    private Mono<List<HitoCuenta>> cambiosDeEstado(CodigoCuenta codigo) {
        var consulta = ConstructorConsulta.igual("claim.code", codigo.valor()).construir();
        var solicitud = SolicitudBusqueda.de(
                consulta, "id,status,dateTime,createdByUserName", "id desc", MAXIMO, false);

        return webClient.post()
                .uri("/generic/claimstatushistory/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiCambioDeEstado>>() {})
                .transform(resiliencia.paraConsultasMono())
                .map(r -> r.isEmpty() ? List.<HitoCuenta>of() : r.items().stream()
                        .map(AdaptadorHistoriaOhi::aHitoDeEstado)
                        .toList())
                .defaultIfEmpty(List.of());
    }

    /**
     * Las desfinalizaciones, con su motivo.
     *
     * <p>Van aparte porque el historial de estados <b>no guarda el motivo</b>: con solo aquél,
     * la historia enseña que la cuenta se desfinalizó y no por qué, que es justo lo que el
     * auditor necesita saber.
     *
     * <p>Fecha en {@code creationDate}, no en {@code dateTime}.
     */
    private Mono<List<HitoCuenta>> desfinalizaciones(CodigoCuenta codigo) {
        var consulta = ConstructorConsulta.igual("claim.code", codigo.valor()).construir();
        var solicitud = SolicitudBusqueda.de(
                consulta,
                "id,unfinalizeReason.code,unfinalizeReason.descr,creationDate,createdByUserName",
                "id desc", MAXIMO, false);

        return webClient.post()
                .uri("/generic/claimunfinalizereasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiDesfinalizacion>>() {})
                .transform(resiliencia.paraConsultasMono())
                .map(r -> r.isEmpty() ? List.<HitoCuenta>of() : r.items().stream()
                        .map(AdaptadorHistoriaOhi::aHitoDeDesfinalizacion)
                        .toList())
                .defaultIfEmpty(List.of());
    }

    /**
     * Un cambio de estado.
     *
     * <p>El estado se traduce con el diccionario, pero si no lo conoce <b>se enseña el literal
     * del sistema de registro</b> en vez de «DESCONOCIDO»: en una historia, un nombre feo
     * informa y un hueco engaña.
     */
    private static HitoCuenta aHitoDeEstado(OhiCambioDeEstado e) {
        var traducido = DiccionarioOhi.aEstado(e.status());
        var etiqueta = traducido == co.sura.auditoria.modelo.cuenta.EstadoCuenta.DESCONOCIDO
                ? e.status()
                : traducido.name();
        return new HitoCuenta(HitoCuenta.Tipo.CAMBIO_DE_ESTADO, etiqueta, null,
                              e.createdByUserName(), instanteDe(e.dateTime()));
    }

    private static HitoCuenta aHitoDeDesfinalizacion(OhiDesfinalizacion d) {
        var motivo = d.unfinalizeReason();
        return new HitoCuenta(
                HitoCuenta.Tipo.DESFINALIZACION,
                motivo == null ? null : motivo.code(),
                motivo == null ? null : motivo.descripcion(),
                d.createdByUserName(), instanteDe(d.creationDate()));
    }

    private static Instant instanteDe(OhiInstante instante) {
        return OhiInstante.aInstante(instante);
    }

    private record OhiCambioDeEstado(Long id, String status, OhiInstante dateTime,
                                     String createdByUserName) {}

    private record OhiDesfinalizacion(Long id, MotivoRef unfinalizeReason,
                                      OhiInstante creationDate, String createdByUserName) {
        record MotivoRef(String code, @JsonProperty("descr") String descripcion) {}
    }
}
