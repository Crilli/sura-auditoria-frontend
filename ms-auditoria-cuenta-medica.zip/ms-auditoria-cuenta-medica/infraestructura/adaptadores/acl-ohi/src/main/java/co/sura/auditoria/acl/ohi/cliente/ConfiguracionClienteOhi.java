package co.sura.auditoria.acl.ohi.cliente;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.util.unit.DataSize;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.springframework.context.annotation.Profile;

/**
 * Configuración del WebClient reactivo para OHI con su propio pool de conexiones
 * y filtro de inyección del Bearer Token (OAuth2).
 */
@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Configuration
public class ConfiguracionClienteOhi {

    /** Nombre del bean para calificar la inyección del cliente paciente. */
    public static final String CLIENTE_OPERACIONES_LARGAS = "clienteOhiOperacionesLargas";

    @Bean
    @Primary
    public WebClient clienteOhi(WebClient.Builder builder,
                                PropiedadesOhi propiedades,
                                ProveedorTokenOhi proveedorToken,
                                @Value("${integraciones.ohi.maximo-respuesta:8MB}") DataSize maximoRespuesta) {
        return construirCliente(builder, propiedades, proveedorToken, maximoRespuesta,
                "ohi-pool", propiedades.timeouts().lectura());
    }

    /**
     * Cliente para las operaciones que exceden el timeout general de lectura
     * (ver {@link PropiedadesOhi.Timeouts#resolucionPendiente()}).
     *
     * <p>Pool de conexiones y {@code ReadTimeoutHandler} propios y separados del
     * cliente general: un timeout por-petición sobre el cliente compartido no
     * basta, porque el {@code ReadTimeoutHandler} ya instalado en el canal —fijo al
     * abrir la conexión, en {@code doOnConnected}— corta primero sin importar qué
     * se pida para esa petición puntual. Verificado en producción: el override por
     * petición seguía cortando a los ~5 s del timeout general, no a los 25 s
     * pedidos.
     */
    @Bean(CLIENTE_OPERACIONES_LARGAS)
    public WebClient clienteOhiOperacionesLargas(WebClient.Builder builder,
                                                  PropiedadesOhi propiedades,
                                                  ProveedorTokenOhi proveedorToken,
                                                  @Value("${integraciones.ohi.maximo-respuesta:8MB}") DataSize maximoRespuesta) {
        return construirCliente(builder, propiedades, proveedorToken, maximoRespuesta,
                "ohi-pool-operaciones-largas", propiedades.timeouts().resolucionPendiente());
    }

    private WebClient construirCliente(WebClient.Builder builder, PropiedadesOhi propiedades,
                                       ProveedorTokenOhi proveedorToken, DataSize maximoRespuesta,
                                       String nombrePool, Duration timeoutLectura) {

        var connectionProvider = ConnectionProvider.builder(nombrePool)
                .maxConnections(50)
                .pendingAcquireTimeout(Duration.ofSeconds(10))
                .maxIdleTime(Duration.ofSeconds(20))
                .build();

        var httpClient = HttpClient.create(connectionProvider)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS,
                        (int) propiedades.timeouts().conexion().toMillis())
                .doOnConnected(conn -> conn
                        .addHandlerLast(new ReadTimeoutHandler(
                                timeoutLectura.toMillis(), TimeUnit.MILLISECONDS))
                        .addHandlerLast(new WriteTimeoutHandler(
                                propiedades.timeouts().escritura().toMillis(), TimeUnit.MILLISECONDS)));

        // OHI devuelve la cuenta completa —con toda su lista de líneas— aunque solo
        // se pida la cabecera: no admite proyección ni exclusión de campos. Una
        // cuenta de 1.500 líneas ronda los 280 KB y revienta el tope de 256 KB que
        // WebFlux aplica por omisión, con un DataBufferLimitException que llega al
        // cliente como 500. Aquí se eleva ese tope solo para el cliente de OHI.
        var estrategias = ExchangeStrategies.builder()
                .codecs(config -> config.defaultCodecs()
                        .maxInMemorySize((int) maximoRespuesta.toBytes()))
                .build();

        return builder
                .baseUrl(propiedades.urlBase())
                .exchangeStrategies(estrategias)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .filter(inyectarToken(proveedorToken))
                // Default a JSON para no repetir en cada llamada
                .defaultHeader(HttpHeaders.CONTENT_TYPE, "application/json")
                .build();
    }

    private ExchangeFilterFunction inyectarToken(ProveedorTokenOhi proveedor) {
        return (request, next) -> proveedor.obtenerToken()
                .map(token -> org.springframework.web.reactive.function.client.ClientRequest
                        .from(request)
                        .headers(headers -> headers.setBearerAuth(token))
                        .build())
                .flatMap(next::exchange);
    }
}
