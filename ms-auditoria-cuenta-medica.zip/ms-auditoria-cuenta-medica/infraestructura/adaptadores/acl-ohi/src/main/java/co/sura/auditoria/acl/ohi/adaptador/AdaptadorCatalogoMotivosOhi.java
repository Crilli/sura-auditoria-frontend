package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivos;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

/**
 * Catálogo de motivos de desfinalización y anulación.
 *
 * <p>Son dieciséis en el entorno de pruebas, así que cabe entero en una
 * consulta y se guarda en memoria: lo consulta cada anulación y cada reversión
 * de finalización, y cambia de higos a brevas.
 *
 * <p><b>El ámbito se proyecta anidado.</b> {@code tipoProceso} es un código
 * dinámico, de los que no se pueden filtrar en la consulta: se pide
 * {@code tipoProceso.value} y se separa aquí. Lo mismo con el permiso, que
 * llega vacío si se pide a secas.
 */
@Component
public class AdaptadorCatalogoMotivosOhi implements PuertoCatalogoMotivos {

    /** Media hora, por lo mismo que el catálogo de novedades. */
    private static final Duration VIGENCIA = Duration.ofMinutes(30);

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final Mono<List<MotivoDesfinalizacion>> cache;

    public AdaptadorCatalogoMotivosOhi(WebClient webClient,
                                       ConfiguracionResiliencia resiliencia,
                                       TraductorErrores traductorErrores) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.cache = Mono.defer(this::leer)
                // Solo se guarda un catálogo con algo: un error o una lista vacía se olvidan al
                // momento y la siguiente petición vuelve a preguntar. Con cache(VIGENCIA) a
                // secas, Reactor guardaba también el error 30 minutos (OPE-04).
                .cache(lista -> lista.isEmpty() ? Duration.ZERO : VIGENCIA,
                       error -> Duration.ZERO,
                       () -> Duration.ZERO);
    }

    @Override
    public Mono<List<MotivoDesfinalizacion>> listar() {
        return cache;
    }

    private Mono<List<MotivoDesfinalizacion>> leer() {
        var consulta = ConstructorConsulta.igual("id", 0L).construir()
                .replace("id.eq(0)", "id.neq(null)");
        var campos = String.join(",",
                "id", "code", "descr", "lockClaimLines", "sourceReferenceMandatory",
                "accessRestriction.code", "tipoProceso.value");
        var solicitud = SolicitudBusqueda.de(consulta, campos, "code asc",
                                             SolicitudBusqueda.LIMITE_MAXIMO, false);

        return webClient.post()
                .uri("/generic/unfinalizereasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiMotivo>>() {})
                .transform(resiliencia.paraConsultasMono())
                .map(r -> r.isEmpty() ? List.<MotivoDesfinalizacion>of()
                        : r.items().stream().map(AdaptadorCatalogoMotivosOhi::aDominio).toList())
                .defaultIfEmpty(List.of());
    }

    private static MotivoDesfinalizacion aDominio(OhiMotivo externo) {
        return new MotivoDesfinalizacion(
                externo.code(),
                externo.descr(),
                Boolean.TRUE.equals(externo.lockClaimLines()),
                Boolean.TRUE.equals(externo.sourceReferenceMandatory()),
                DiccionarioOhi.aAmbitoDeMotivo(
                        externo.tipoProceso() == null ? null : externo.tipoProceso().value()),
                externo.accessRestriction() == null ? null : externo.accessRestriction().code());
    }

    private record OhiMotivo(String code,
                             String descr,
                             Boolean lockClaimLines,
                             Boolean sourceReferenceMandatory,
                             Restriccion accessRestriction,
                             OhiFlexCode tipoProceso) {
        record Restriccion(String code) {}
    }
}
