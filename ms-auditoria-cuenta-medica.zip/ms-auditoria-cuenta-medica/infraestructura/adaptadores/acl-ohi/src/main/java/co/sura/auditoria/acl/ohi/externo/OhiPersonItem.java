package co.sura.auditoria.acl.ohi.externo;

/**
 * Afiliado (person) en OHI.
 *
 * <p>OHI reparte el nombre colombiano en cuatro campos y los nombra de una forma
 * que engaña: {@code name} <b>no</b> es el nombre completo sino el primer
 * apellido, y {@code middleName} es el segundo apellido, no el segundo nombre.
 * Verificado contra producción con casos reales:
 * {@code {firstName:"JUAN", secondName:"CARLOS", name:"RONCANCIO", middleName:"CHAVES"}}
 * es «JUAN CARLOS RONCANCIO CHAVES».
 *
 * <p>Cobertura medida sobre 200 afiliados: {@code firstName} y {@code name} al
 * 100%, {@code secondName} 61%, {@code middleName} 85%. {@code namePartner} e
 * {@code initials} están siempre vacíos y por eso no se traen.
 */
public record OhiPersonItem(
        String id,
        String code,
        String firstName,
        String secondName,
        String name,
        String middleName) {

    /**
     * Nombre completo en el orden en que se lee en Colombia: nombres y después
     * apellidos. Omite las partes ausentes sin dejar espacios dobles.
     *
     * @return el nombre, o {@code null} si OHI no publicó ninguna parte
     */
    public String nombreCompleto() {
        var partes = new StringBuilder();
        for (var parte : new String[]{firstName, secondName, name, middleName}) {
            if (parte == null || parte.isBlank()) continue;
            if (partes.length() > 0) partes.append(' ');
            partes.append(parte.trim());
        }
        return partes.isEmpty() ? null : partes.toString();
    }
}
