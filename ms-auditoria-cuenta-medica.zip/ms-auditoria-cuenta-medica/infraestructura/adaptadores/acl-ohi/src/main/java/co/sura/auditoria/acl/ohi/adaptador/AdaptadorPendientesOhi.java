package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiActividad;
import co.sura.auditoria.acl.ohi.externo.OhiMensajeActividad;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.acl.ohi.externo.OhiAgregarPendienteRequest;
import co.sura.auditoria.acl.ohi.externo.OhiResolverPendientesRequest;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.Pagina;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import org.springframework.context.annotation.Lazy;

@Component
public class AdaptadorPendientesOhi implements PuertoPendientes {

    private static final org.slf4j.Logger log =
            org.slf4j.LoggerFactory.getLogger(AdaptadorPendientesOhi.class);

    private final WebClient webClient;
    /** Cliente con más margen de lectura, usado solo para resolver pendientes. */
    private final WebClient clientePaciente;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final TraductorPendiente traductorPendiente;
    /** Tope defensivo de pendientes por línea al pedir los de una página. */
    private static final int MAXIMO_PENDIENTES_POR_LINEA = 20;

    /**
     * Tope defensivo del recorrido completo de una cuenta. No es un límite de
     * negocio: es el freno para que una cuenta anómala no pagine indefinidamente.
     *
     * <p>La mayor medida en producción el 11-oct-2026 es CM-55181980659, con
     * <b>3.504 pendientes de línea</b> (3.507 con los de cabecera). El margen
     * hasta este tope es de 1,4x, no holgado: una cuenta un 43% mayor lo toca.
     * Por eso el recorrido avisa cuando lo alcanza en vez de recortar en
     * silencio — una lista truncada es indistinguible de una completa, que es
     * justo el fallo que este cambio vino a cerrar.
     */
    private static final int MAXIMO_PENDIENTES_POR_CUENTA = 5_000;

    /**
     * Estado de la cuenta, cacheado un minuto.
     *
     * <p>Hace falta en cada página y en el agregado, porque es lo que decide qué
     * bloquea, y pedirlo cada vez añade una consulta a OHI sobre otra que ya
     * cuesta media página: medido, 0,4 s de los 0,8 s que tarda una página de 25.
     * A diferencia del identificador —que no cambia nunca y por eso
     * {@code ResolutorIdentidadOhi} lo guarda diez minutos— el estado sí cambia:
     * resolver un pendiente mueve la cuenta, así que {@code resolver(...)}
     * invalida esta entrada además del plazo.
     *
     * <p>El minuto <b>no</b> cubre un recorrido completo: CM-55181980659 tiene 141
     * páginas y pasar de la primera a la última lleva más. Si el estado cambia a
     * mitad, las páginas posteriores se filtran con otro criterio que las
     * anteriores y el recorrido sale incoherente. Se asume: el coste de
     * equivocarse es un rótulo desfasado o una página de más o de menos, nunca una
     * escritura, y alargar el plazo solo cambiaría el momento en que ocurre.
     */
    private final com.github.benmanes.caffeine.cache.Cache<Long, EstadoCuenta> estados =
            com.github.benmanes.caffeine.cache.Caffeine.newBuilder()
                    .maximumSize(200)
                    .expireAfterWrite(java.time.Duration.ofMinutes(1))
                    .build();



    private final ResolutorIdentidadOhi resolutor;
    /**
     * Resolver de identidad. Lo implementa {@code AdaptadorConsultasOhi}, que a su
     * vez depende de este adaptador para traer los pendientes de la cuenta: la
     * referencia es perezosa para romper ese ciclo en el contenedor.
     */
    private final ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo;
    private final co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi agregados;

    public AdaptadorPendientesOhi(WebClient webClient,
                                  @org.springframework.beans.factory.annotation.Qualifier(
                                          co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
                                  WebClient clientePaciente,
                                  ConfiguracionResiliencia resiliencia,
                                  TraductorErrores traductorErrores,
                                  TraductorPendiente traductorPendiente,
                                  ResolutorIdentidadOhi resolutor,
                                  @Lazy ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo,
                                  co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi agregados) {
        this.webClient = webClient;
        this.clientePaciente = clientePaciente;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.traductorPendiente = traductorPendiente;
        this.resolutor = resolutor;
        this.buscadorPorCodigo = buscadorPorCodigo;
        this.agregados = agregados;
        // El estado de la cuenta se olvida a la vez que sus agregados: los comandos que viven
        // en AdaptadorComandosOhi solo conocen la caché de agregados (revisión de las Fases 1 y 2).
        agregados.alInvalidar(this::olvidarEstado, estados::invalidateAll);
    }

    /** Olvida el estado guardado de una cuenta, si se sabe su identificador sin preguntar a OHI. */
    private void olvidarEstado(CodigoCuenta codigo) {
        var id = resolutor.cacheNativa().getIfPresent(codigo.valor());
        if (id != null) estados.invalidate(id);
    }

    // ── Queries Internas (usadas por AdaptadorConsultasOhi) ───────────────

    /**
     * Se ejecuta siempre dentro del mismo flujo que {@code buscarItem()}
     * (constructor de {@code buscarPorCodigo}): por eso usa el mismo cliente
     * paciente y sin retry. Verificado en producción con CM-55181980659, que
     * excede el timeout general no solo en {@code claims/search} sino también
     * aquí — el volumen alto de esa cuenta afecta cualquier consulta relacionada,
     * no solo la cabecera propiamente dicha.
     */
    public Mono<List<OhiPendReasonItem>> buscarDeCabecera(long idCuenta) {
        var consulta = ConstructorConsulta.igual("claim.id", idCuenta).construir();
        // `unica` limita a un registro: aquí se necesitan todos los de la cabecera.
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_CABECERA,
                                             null, SolicitudBusqueda.LIMITE_MAXIMO, false);

        return clientePaciente.post()
                .uri("/generic/claimpendreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    /**
     * Pendientes de un conjunto concreto de líneas.
     *
     * <p>Se consulta por los identificadores de la página en curso y no por la
     * cuenta entera: una cuenta con cientos de líneas traía todos sus pendientes
     * en cada salto de página, aunque solo se pintaran veinticinco.
     */
    public Mono<List<OhiPendReasonItem>> buscarDeLineas(List<Long> idsLinea) {
        if (idsLinea == null || idsLinea.isEmpty()) return Mono.just(List.of());

        var consulta = ConstructorConsulta.contenidoEnIds("claimLine.id", idsLinea).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_LINEA,
                                             null, SolicitudBusqueda.limitarAlMaximo(
                                                 idsLinea.size() * MAXIMO_PENDIENTES_POR_LINEA), false);

        // Mismo cliente paciente que el resto de la ruta de líneas: ver
        // AdaptadorConsultasOhi.listarResumenLineas().
        return clientePaciente.post()
                .uri("/generic/claimlinependreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    /**
     * Pendientes de todas las líneas de la cuenta.
     *
     * <p>La usa el listado de pendientes, que por definición los necesita todos.
     * Para enriquecer una página de la grilla use {@link #buscarDeLineas(List)},
     * que solo trae los de las líneas visibles.
     *
     * <p><b>Pagina</b>: {@code LIMITE_MAXIMO} es 200 y es un tope duro de OHI, no
     * el tamaño de la respuesta. Una sola llamada devolvía exactamente 200 filas y
     * se daban por todas: medido en producción, CM-55181980659 tiene 203 pendientes
     * en las 200 primeras filas y CM-100234713388 corta igual. Se recorren las
     * páginas con el mismo keyset por {@code id} que {@code listarResumenLineas}
     * —filtro {@code id.gt} y {@code orderBy id asc}, que han de coincidir— porque
     * el filtro por motivo del listado cuenta sobre lo que llega: con la lista
     * cortada decía «88 líneas» de un motivo que tenía más, y los motivos que solo
     * aparecían pasada la fila 200 no salían siquiera en el selector.
     */
    /**
     * Recorre las páginas de pendientes de línea sin resolver de toda la cuenta.
     *
     * <p>El {@code resolved} va dentro de la consulta y no en un {@code filter}
     * posterior: con el filtro fuera, cada página de 200 gasta huecos en filas
     * resueltas y el recorrido entrega menos de lo que cree.
     */
    private Flux<OhiPendReasonItem> recorrerLineasSinResolver(long idCuenta) {
        var recorridas = new java.util.concurrent.atomic.AtomicInteger();

        return paginaDeLineas(idCuenta, 0L, SolicitudBusqueda.LIMITE_MAXIMO, null, null, false)
                .expand(pagina -> cursorSiguiente(pagina.items())
                        .map(desde -> paginaDeLineas(idCuenta, desde,
                                                     SolicitudBusqueda.LIMITE_MAXIMO, null, null, false))
                        .orElse(Mono.empty()))
                .flatMapIterable(OhiSearchResponse::items)
                .take(MAXIMO_PENDIENTES_POR_CUENTA)
                .doOnNext(x -> recorridas.incrementAndGet())
                .doOnComplete(() -> {
                    if (recorridas.get() >= MAXIMO_PENDIENTES_POR_CUENTA) {
                        log.warn("La cuenta {} tiene al menos {} pendientes de línea y se alcanzó el "
                                 + "tope del recorrido: el agregado de motivos y el conteo de la "
                                 + "pantalla salen incompletos", idCuenta, MAXIMO_PENDIENTES_POR_CUENTA);
                    }
                });
    }

    /**
     * Corte para pedir la página siguiente, o vacío si esta es la última.
     *
     * <p>Una página incompleta cierra el recorrido. Un id nulo o que no avanza
     * también: sin eso el keyset volvería a pedir la misma página indefinidamente.
     */
    private static java.util.Optional<Long> cursorSiguiente(List<OhiPendReasonItem> pagina) {
        if (pagina.size() < SolicitudBusqueda.LIMITE_MAXIMO) return java.util.Optional.empty();
        var ultimo = pagina.get(pagina.size() - 1).id();
        return ultimo == null || ultimo <= 0 ? java.util.Optional.empty() : java.util.Optional.of(ultimo);
    }

    /**
     * Una página de pendientes de línea <b>sin resolver</b>, tal cual la devuelve
     * OHI: se conserva la envoltura porque de ella sale {@code totalResults}.
     *
     * <p>{@code desdeId} es el corte del keyset —0 en la primera página, el último
     * id devuelto en las siguientes— y el {@code orderBy} es ese mismo campo. Ver
     * la nota de {@code AdaptadorConsultasOhi.listarResumenLineas} sobre lo que
     * pasa cuando el orden y el avance divergen.
     *
     * <p><b>{@code incluirTotal} solo en la primera página.</b> El total que
     * devuelve OHI es el de las filas que cumplen la {@code q}, y el {@code id.gt}
     * forma parte de la {@code q}: medido contra CM-55181980659, la primera página
     * responde 3.504 y la segunda 3.479. Pedirlo en cada salto haría encoger el
     * número de páginas conforme se avanza.
     */
    private Mono<OhiSearchResponse<OhiPendReasonItem>> paginaDeLineas(
            long idCuenta, long desdeId, int limite, String codigoMotivo,
            Boolean soloAdjudicacion, boolean incluirTotal) {
        return paginaDeLineas(idCuenta, desdeId, limite, codigoMotivo, soloAdjudicacion,
                              incluirTotal, false);
    }

    private Mono<OhiSearchResponse<OhiPendReasonItem>> paginaDeLineas(
            long idCuenta, long desdeId, int limite, String codigoMotivo,
            Boolean soloAdjudicacion, boolean incluirTotal, boolean incluirResueltos) {

        var constructor = ConstructorConsulta.igual("claimLine.claim.id", idCuenta);
        // El «sin resolver» sigue yendo DENTRO de la consulta y no en un filter posterior:
        // con el filtro fuera, cada página de 200 gasta huecos en filas resueltas y el
        // recorrido entrega menos de lo que cree. Cuando se piden los resueltos, lo que se
        // hace es no poner la condición, no traerlo todo y descartar.
        if (!incluirResueltos) constructor.yIgual("resolved", false);
        if (codigoMotivo != null)     constructor.yIgual("pendReason.code", codigoMotivo);
        // `adjudicationOnly` es filtrable y no trae nulos: comprobado el 12-oct-2026
        // en los dos recursos y en el catálogo entero (233 motivos, 205 false /
        // 28 true / 0 nulos), con los totales cuadrando base = false + true.
        if (soloAdjudicacion != null) constructor.yIgual("pendReason.adjudicationOnly", soloAdjudicacion);
        if (desdeId > 0)              constructor.yMayorQue("id", desdeId);

        var solicitud = SolicitudBusqueda.de(constructor.construir(), CamposOhi.PENDIENTE_LINEA,
                                             "id asc", limite, incluirTotal);

        return clientePaciente.post()
                .uri("/generic/claimlinependreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                // OHI responde 204 sin cuerpo cuando no hay resultados: sin esto el
                // Mono queda vacío y arrastra a toda la cadena. Pasa en cada cuenta
                // cuyo total es múltiplo exacto del límite, porque la última página
                // sale llena y hay que pedir una más para descubrir que ya no hay.
                .defaultIfEmpty(OhiSearchResponse.vacio());
    }


    /**
     * Pendientes <b>sin resolver</b> de la cabecera, opcionalmente de un solo motivo.
     *
     * <p>Va aparte de {@link #buscarDeCabecera(long)} —que los trae todos, resueltos
     * incluidos, porque de ahí sale el contador de la ficha de la cuenta— y empuja
     * {@code resolved} a OHI en vez de filtrarlo en memoria. Al paginar eso deja de
     * ser un detalle: con el filtro en memoria la página sale coja, porque OHI ya
     * contó las filas resueltas dentro del límite que se le pidió.
     *
     * <p>No pagina: lo medido en producción son de 1 a 3 pendientes de cabecera por
     * cuenta y el tope de OHI es 200. Si alguna vez pasara de ahí, el prefijo se
     * truncaría en silencio — el mismo riesgo que documenta
     * {@link #recorrerLineasSinResolver(long)}, aquí a dos órdenes de magnitud de
     * distancia.
     */
    private Mono<List<OhiPendReasonItem>> cabeceraSinResolver(long idCuenta, String codigoMotivo,
                                                              Boolean soloAdjudicacion) {
        return cabecera(idCuenta, codigoMotivo, soloAdjudicacion, false);
    }

    /** Los de cabecera, con o sin los ya resueltos. Ver {@code paginaDeLineas}. */
    private Mono<List<OhiPendReasonItem>> cabecera(long idCuenta, String codigoMotivo,
                                                   Boolean soloAdjudicacion,
                                                   boolean incluirResueltos) {
        var constructor = ConstructorConsulta.igual("claim.id", idCuenta);
        if (!incluirResueltos) constructor.yIgual("resolved", false);
        if (codigoMotivo != null)     constructor.yIgual("pendReason.code", codigoMotivo);
        if (soloAdjudicacion != null) constructor.yIgual("pendReason.adjudicationOnly", soloAdjudicacion);

        var solicitud = SolicitudBusqueda.de(constructor.construir(), CamposOhi.PENDIENTE_CABECERA,
                                             "id asc", SolicitudBusqueda.LIMITE_MAXIMO, false);

        return clientePaciente.post()
                .uri("/generic/claimpendreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                .defaultIfEmpty(List.of());
    }

    /**
     * Estado actual de la cuenta, con la proyección más estrecha posible.
     *
     * <p><b>Ojo con los estados que el diccionario no mapea.</b> Llegan como
     * {@code DESCONOCIDO}, y {@code EstadoCuenta.bloqueaPendiente} los trata
     * entonces como un estado corriente: bloquea lo que no sea de sola
     * adjudicación. No es un criterio prudente, es el mismo de siempre — y pesa,
     * porque {@code IN PROCESS} <b>no está en el diccionario</b> y era el 26% de
     * una muestra de 120 cuentas grandes vivas el 12-oct-2026 (31 de 120, frente
     * a 53 en {@code MANUAL ADJUDICATION} y 20 en {@code CHANGE}). Mientras no se
     * decida a qué estado del dominio corresponde, el veredicto de bloqueo de esas
     * cuentas descansa en ese valor por omisión.
     *
     * <p>Si la consulta falla se sigue con {@code DESCONOCIDO} en vez de tumbar el
     * listado: el estado solo decide un rótulo y el filtro, y quedarse sin ver los
     * pendientes es peor que verlos con la marca puesta por omisión.
     */
    /**
     * El estado de la cuenta, con caché.
     *
     * <p>Es público porque lo necesita también el listado de líneas: su filtro «solo
     * bloqueantes» depende del par motivo-estado, no del motivo. Compartir este método
     * —y su caché— evita que las dos pantallas puedan discrepar sobre si un pendiente
     * frena la cuenta, que es justo lo que {@link EstadoCuenta#bloqueaPendiente} existe
     * para impedir.
     */
    public Mono<EstadoCuenta> estadoDeLaCuenta(long idCuenta) {
        var cacheado = estados.getIfPresent(idCuenta);
        if (cacheado != null) return Mono.just(cacheado);

        var solicitud = SolicitudBusqueda.unica(
                ConstructorConsulta.igual("id", idCuenta).construir(), "id,status");

        return clientePaciente.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiEstadoItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.first().map(OhiEstadoItem::status)
                           .map(DiccionarioOhi::aEstado)
                           .orElse(EstadoCuenta.DESCONOCIDO))
                .defaultIfEmpty(EstadoCuenta.DESCONOCIDO)
                .doOnNext(estado -> estados.put(idCuenta, estado))
                .onErrorResume(e -> {
                    log.warn("No se pudo leer el estado de la cuenta {}: se sigue con DESCONOCIDO, "
                             + "así que la marca de «bloqueante» puede no ser la correcta", idCuenta, e);
                    return Mono.just(EstadoCuenta.DESCONOCIDO);
                });
    }

    /** Lo mínimo de la cabecera para saber qué bloquea. */
    private record OhiEstadoItem(Long id, String status) {}

    public Mono<List<OhiPendReasonItem>> buscarDeLinea(long idLinea) {
        var consulta = ConstructorConsulta.igual("claimLine.id", idLinea).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_LINEA,
                                             null, MAXIMO_PENDIENTES_POR_LINEA, false);

        return clientePaciente.post()
                .uri("/generic/claimlinependreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    // ── PuertoPendientes ──────────────────────────────────────────────────

    @Override
    public Flux<MotivoPendiente> listarSinResolver(CodigoCuenta codigo) {
        // El «sin resolver» lo aplica OHI, no un filter de aquí: con el filtro en
        // memoria la consulta de cabecera gastaba parte de su tope de 200 en filas
        // ya resueltas, y el recorrido de líneas lo mismo en cada página.
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMapMany(idCuenta -> Flux.concat(
                        cabeceraSinResolver(idCuenta, null, null)
                                .flatMapIterable(l -> l).map(traductorPendiente::aDominioCabecera),
                        recorrerLineasSinResolver(idCuenta).map(traductorPendiente::aDominioLinea)
                ));
    }

    @Override
    public Mono<PaginaPendientes> listarPaginado(CodigoCuenta codigo, Cursor cursor,
                                                 int tamanoPagina, boolean incluirTotal,
                                                 String codigoMotivo, FiltroBloqueo bloqueo) {
        return listarPaginado(codigo, cursor, tamanoPagina, incluirTotal, codigoMotivo,
                              bloqueo, false);
    }

    @Override
    public Mono<PaginaPendientes> listarPaginado(CodigoCuenta codigo, Cursor cursor,
                                                 int tamanoPagina, boolean incluirTotal,
                                                 String codigoMotivo, FiltroBloqueo bloqueo,
                                                 boolean incluirResueltos) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> estadoDeLaCuenta(idCuenta).flatMap(estado -> {
                    // Un filtro que en este estado no puede casar con nada no se le
                    // pregunta a OHI: sin predicado que lo exprese, la consulta
                    // devolvería justo lo contrario de lo que se pidió.
                    if (bloqueo.vacioPorDefinicionEn(estado)) {
                        return Mono.just(new PaginaPendientes(
                                new Pagina<>(List.of(), java.util.Optional.empty(),
                                             java.util.Optional.of(0L), tamanoPagina),
                                estado));
                    }

                    var soloAdjudicacion = bloqueo.soloAdjudicacionExigida(estado).orElse(null);

                    var pagina = cursor.esPrimeraPagina()
                            ? primeraPagina(idCuenta, tamanoPagina, incluirTotal, codigoMotivo,
                                            soloAdjudicacion, incluirResueltos)
                            : paginaSiguiente(idCuenta, cursor.ultimaReferencia(), tamanoPagina,
                                              codigoMotivo, soloAdjudicacion, incluirResueltos);

                    return pagina.map(p -> new PaginaPendientes(p, estado));
                }));
    }

    /**
     * La primera página lleva los pendientes de cabecera como prefijo y rellena el
     * resto del tamaño con los de línea, de modo que mide lo mismo que las demás y
     * {@code ceil(total / tamaño)} sigue siendo el número real de páginas.
     *
     * <p>Se pide al menos un pendiente de línea aunque la cabecera se haya comido
     * el tamaño entero —caso que no se ha visto nunca: lo medido es de 1 a 3 de
     * cabecera frente a un tamaño de 25—. Sin esa fila no habría de dónde sacar el
     * cursor, y el recorrido se quedaría atascado en la primera página.
     */
    private Mono<Pagina<MotivoPendiente>> primeraPagina(long idCuenta, int tamanoPagina,
                                                        boolean incluirTotal, String codigoMotivo,
                                                        Boolean soloAdjudicacion,
                                                        boolean incluirResueltos) {
        return cabecera(idCuenta, codigoMotivo, soloAdjudicacion, incluirResueltos).flatMap(cabecera -> {
            int huecos = Math.max(1, tamanoPagina - cabecera.size());

            return paginaDeLineas(idCuenta, 0L, huecos, codigoMotivo, soloAdjudicacion,
                                  incluirTotal, incluirResueltos)
                    .map(respuesta -> {
                        Long total = incluirTotal
                                ? cabecera.size() + totalDe(respuesta, respuesta.items().size())
                                : null;
                        return componer(cabecera, respuesta.items(), huecos, tamanoPagina, total);
                    });
        });
    }

    /** De la segunda en adelante solo hay pendientes de línea: el cursor es suyo. */
    private Mono<Pagina<MotivoPendiente>> paginaSiguiente(long idCuenta, long desdeId,
                                                          int tamanoPagina, String codigoMotivo,
                                                          Boolean soloAdjudicacion,
                                                          boolean incluirResueltos) {
        return paginaDeLineas(idCuenta, desdeId, tamanoPagina, codigoMotivo, soloAdjudicacion,
                              false, incluirResueltos)
                .map(respuesta -> componer(List.of(), respuesta.items(),
                                           tamanoPagina, tamanoPagina, null));
    }

    /**
     * Arma la página a partir de sus dos mitades.
     *
     * <p>El cursor se calcula <b>solo sobre las filas de línea</b> y contra los
     * huecos que se pidieron para ellas, no contra el tamaño de la página: los
     * identificadores de {@code claimpendreasons} y {@code claimlinependreasons}
     * viven en espacios distintos y meterlos en el mismo {@code max()} daría un
     * corte que no significa nada en el recurso por el que se avanza. Que hoy los
     * de cabecera sean numéricamente menores es casualidad medida, no contrato.
     *
     * <p>Y se calcula sobre {@code identificador} —el id de la fila en
     * {@code claimlinependreasons}—, no sobre {@code referenciaLinea}, que es el
     * id de la línea. Son dos cosas distintas y el keyset avanza por la primera:
     * con la segunda, verificado contra CM-55181980659, el cursor salía
     * 67.287.459.004 cuando los ids de pendiente rondan 637.886.965.329, así que
     * {@code id.gt} no descartaba nada y la página 2 repetía la 1 indefinidamente.
     *
     * <p>Tampoco se usa {@code Pagina.vacia}: fija el total en 0, y aquí una parte
     * vacía es lo normal —un motivo solo de cabecera deja sin filas la mitad de
     * líneas— así que el cliente lo leería como «esta cuenta no tiene pendientes».
     */
    private Pagina<MotivoPendiente> componer(List<OhiPendReasonItem> cabecera,
                                             List<OhiPendReasonItem> lineas,
                                             int huecosDeLinea, int tamanoPagina, Long total) {
        var soloLineas = Pagina.construir(
                lineas.stream().map(traductorPendiente::aDominioLinea).toList(),
                huecosDeLinea, null, MotivoPendiente::identificador);

        var elementos = new java.util.ArrayList<MotivoPendiente>(cabecera.size() + lineas.size());
        cabecera.stream().map(traductorPendiente::aDominioCabecera).forEach(elementos::add);
        elementos.addAll(soloLineas.elementos());

        // Se declara el tamaño realmente servido, no el pedido: cuando el prefijo
        // de cabecera es mayor o igual que el tamaño —solo alcanzable pidiendo
        // tamano 1, 2 o 3, porque lo medido son de 1 a 3 de cabecera— la página 1
        // se pasa del tamaño para poder llevar la fila de línea de la que sale el
        // cursor. Decir `tamanoPagina` ahí sería mentir, y quien calcule el rango
        // como (página-1)*tamaño pintaría «1–1 de 8» sobre tres filas.
        return new Pagina<>(List.copyOf(elementos), soloLineas.cursorSiguiente(),
                            java.util.Optional.ofNullable(total),
                            Math.max(tamanoPagina, elementos.size()));
    }

    /**
     * El total que publica OHI, con la página ya traída como respaldo.
     *
     * <p>{@code totalResults} viene nulo si la respuesta llegó sin él; devolver 0
     * en ese caso diría «no hay pendientes» con la tabla llena, así que se tira de
     * lo que sí se sabe: las filas que acaban de llegar.
     */
    private static long totalDe(OhiSearchResponse<OhiPendReasonItem> respuesta, int respaldo) {
        return respuesta.totalResults() == null ? respaldo : respuesta.totalResults();
    }

    @Override
    public Flux<ResumenMotivoPendiente> resumirMotivos(CodigoCuenta codigo) {
        // Recorre todos los pendientes de la cuenta: se guarda un rato por cuenta y cualquier
        // comando sobre ella lo invalida (OPE-09).
        return agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.MOTIVOS_PENDIENTES,
                                 codigo, () -> motivosSinCache(codigo))
                .onErrorResume(MotivosSinGuardar.class, sinGuardar -> Mono.just(sinGuardar.motivos))
                .flatMapMany(Flux::fromIterable);
    }

    /**
     * Lleva unos motivos calculados con el estado DESCONOCIDO —porque la consulta del estado
     * falló—: sirven para pintar, pero no para guardarlos 30 s, porque «bloquea» saldría mal
     * todo ese rato. La caché descarta las cargas que fallan y {@link #resumirMotivos} lo deshace.
     * Sin traza: no es un fallo.
     */
    private static final class MotivosSinGuardar extends RuntimeException {
        private final transient List<ResumenMotivoPendiente> motivos;
        MotivosSinGuardar(List<ResumenMotivoPendiente> motivos) {
            super("motivos calculados con el estado desconocido", null, false, false);
            this.motivos = motivos;
        }
    }

    private Mono<List<ResumenMotivoPendiente>> motivosSinCache(CodigoCuenta codigo) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                // El vacío del resolutor significa «esa cuenta no existe», y hay que
                // convertirlo aquí: más abajo ya no se distingue de «existe y no
                // tiene pendientes», que es un caso legítimo y debe dar lista vacía.
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
                // La cuenta se resuelve una sola vez y el estado se pide a la par
                // del recorrido, no después: `zipWith` se suscribe a los dos, y el
                // recorrido de 18 consultas tapa de sobra la del estado.
                .flatMap(idCuenta ->
                        Flux.concat(cabeceraSinResolver(idCuenta, null, null).flatMapIterable(l -> l),
                                    recorrerLineasSinResolver(idCuenta))
                            .collectList()
                            .zipWith(estadoDeLaCuenta(idCuenta))
                            .flatMap(par -> {
                                var motivos = agruparPorMotivo(par.getT1(), par.getT2());
                                return par.getT2() == EstadoCuenta.DESCONOCIDO
                                        ? Mono.<List<ResumenMotivoPendiente>>error(new MotivosSinGuardar(motivos))
                                        : Mono.just(motivos);
                            }));
    }

    /**
     * Agrupa los pendientes de la cuenta por código de motivo.
     *
     * <p>Se cuentan líneas <b>distintas</b> y no filas: un motivo con seis
     * pendientes sobre la misma línea afecta a una, y rotularlo «6 líneas»
     * mandaría al auditor a buscar cinco que no existen. La descripción se toma de
     * la primera fila que traiga texto, porque el catálogo la publica por motivo y
     * no por fila, pero nada garantiza que llegue en todas.
     */
    private static List<ResumenMotivoPendiente> agruparPorMotivo(List<OhiPendReasonItem> filas,
                                                                 EstadoCuenta estado) {
        var porCodigo = new java.util.LinkedHashMap<String, Acumulador>();

        for (var fila : filas) {
            if (fila.pendReason() == null || fila.pendReason().code() == null) continue;
            var acumulador = porCodigo.computeIfAbsent(fila.pendReason().code(), c -> new Acumulador());
            acumulador.contar(fila);
        }

        return porCodigo.entrySet().stream()
                .map(e -> e.getValue().aResumen(e.getKey(), estado))
                .toList();
    }

    /** Cuenta de un motivo mientras se recorre la cuenta. */
    private static final class Acumulador {
        private String descripcion;
        private int sinResolver;
        private boolean enCabecera;
        private boolean soloAdjudicacion;
        /**
         * Líneas distintas, contadas por <b>identificador</b> y no por número de
         * línea.
         *
         * <p>El número es de presentación y puede faltar; el identificador es la
         * identidad y siempre viene. Contando por número, una fila sin él se
         * sumaba a {@code sinResolver} pero no aquí, así que
         * {@code lineasAfectadas} podía quedar por debajo del real. En la muestra
         * de 200 filas de producción del 12-oct-2026 todas traían los dos, de
         * modo que hoy no cambia ninguna cifra; se cuenta por el id porque el
         * número que sale de aquí es el que el auditor confirma antes de una
         * resolución irreversible, y ahí una cuenta corta es lo peor que puede
         * salir.
         */
        private final java.util.Set<Long> lineas = new java.util.HashSet<>();

        void contar(OhiPendReasonItem fila) {
            sinResolver++;
            if (descripcion == null) descripcion = fila.pendReason().descripcion();
            // Es propiedad del motivo en el catálogo, igual en todas sus filas:
            // basta con quedarse con el de cualquiera.
            soloAdjudicacion = Boolean.TRUE.equals(fila.pendReason().soloAdjudicacion());
            if (fila.claimLine() == null) {
                enCabecera = true;
            } else if (fila.claimLine().id() != null) {
                lineas.add(fila.claimLine().id());
            }
        }

        ResumenMotivoPendiente aResumen(String codigo, EstadoCuenta estado) {
            return new ResumenMotivoPendiente(codigo, descripcion, sinResolver, lineas.size(),
                                              enCabecera, soloAdjudicacion,
                                              estado.bloqueaPendiente(soloAdjudicacion));
        }
    }

    // ── Resolución conjunta de varios motivos ─────────────────────────────

    /**
     * Pausa entre sondeos de la operación de larga duración.
     *
     * <p>Un segundo porque las operaciones {@code RESOLVE_PEND} que ya hay en
     * producción —creadas por los usuarios del propio sistema de registro, no por
     * este servicio— tardan del orden de 5 s de principio a fin: medida leída de
     * sus {@code creationDate} y {@code processStopDateTime}, no de una ejecución
     * nuestra, que contra producción no se puede hacer. Sondear más a menudo solo
     * añade consultas, y menos a menudo redondea la espera hacia arriba sin
     * motivo.
     */
    private static final java.time.Duration PAUSA_ENTRE_SONDEOS = java.time.Duration.ofSeconds(1);

    /**
     * Cuántas veces se vuelve a preguntar antes de contestar «sigue en curso»: unos tres
     * segundos de espera como mucho (OPE-06).
     *
     * <p>Eran doce, y con los dos niveles la petición del auditor llegaba a 30-45 s ocupando
     * conexiones del pool y con la pantalla parada. Ahora la espera es corta a propósito: si
     * la operación ya terminó —las de una cuenta pequeña tardan unos 5 s, a veces menos—, el
     * auditor recibe el desenlace en la misma respuesta; si no, recibe la referencia y la
     * pantalla la sigue con {@link #consultarResolucion(CodigoCuenta, String)}, sin bloquear a nadie.
     *
     * <p>No es un tope del sistema de registro —la operación va a terminar igual— sino del
     * tiempo que esta llamada está dispuesta a ocupar.
     */
    private static final int MAXIMO_SONDEOS = 3;

    /**
     * Cuántos motivos se comprueban a la vez al validar una resolución: dos consultas por
     * motivo, así que ocho conexiones como mucho (OPE-07). El tope no es de OHI sino de este
     * servicio, que comparte el pool con las pantallas de todos los auditores.
     */
    private static final int MOTIVOS_A_LA_VEZ = 4;

    /** Las referencias de operación de OHI son números: lo demás no se pregunta. */
    private static final java.util.regex.Pattern REFERENCIA = java.util.regex.Pattern.compile("\\d{1,19}");

    /**
     * {@inheritDoc}
     *
     * <p>Usa {@code POST /claims/resolvependreasons}, el recurso que acepta
     * varios motivos a la vez. Tres consecuencias que no tiene la ruta
     * individual:
     * <ul>
     *   <li>los motivos van por <b>código</b>, así que no hay que traducir
     *       identificadores de fila a identificadores de catálogo;</li>
     *   <li>la respuesta es un {@code 201} con la cabecera {@code Location}: OHI
     *       no resuelve en la respuesta, abre una operación de larga duración.
     *       Aquí se espera a que termine y se resume, para que quien llama reciba
     *       un desenlace y no un «aceptado» que no dice nada;</li>
     *   <li>un fallo parcial no viaja en el código HTTP. Hay que leer los
     *       mensajes de la operación.</li>
     * </ul>
     */
    @Override
    public Mono<ResultadoResolucionMasiva> resolverMotivos(CodigoCuenta codigo,
                                                           java.util.Set<String> codigosMotivo,
                                                           co.sura.auditoria.modelo.cuenta.NivelPendiente nivel) {
        return resolverMotivos(codigo, codigosMotivo, nivel,
                               co.sura.auditoria.modelo.cuenta.SeleccionLineas.TODAS);
    }

    @Override
    public Mono<ResultadoResolucionMasiva> resolverMotivos(CodigoCuenta codigo,
                                                           java.util.Set<String> codigosMotivo,
                                                           co.sura.auditoria.modelo.cuenta.NivelPendiente nivel,
                                                           co.sura.auditoria.modelo.cuenta.SeleccionLineas seleccion) {
        if (codigosMotivo == null || codigosMotivo.isEmpty())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se indicó ningún motivo a resolver")));

        var nivelOhi = DiccionarioOhi.desdeNivelPendiente(nivel);

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
                // Resolver mueve la cuenta de estado, y el estado es lo que decide
                // qué bloquea. Se invalida dos veces a propósito: antes, para que
                // nadie siga leyendo el de ahora; y después, porque mientras la
                // operación corre cualquier consulta vuelve a cachear el estado
                // viejo y lo dejaría vigente un minuto más allá del cambio.
                .doOnNext(estados::invalidate)
                .flatMap(idCuenta -> emitirResolucion(idCuenta, codigosMotivo, nivelOhi,
                                                      alcance(seleccion, nivel))
                        .flatMap(this::esperarYResumir)
                        .doOnSuccess(resultado -> estados.invalidate(idCuenta)))
                // Si sigue en curso, OHI la termina en segundo plano: se vuelve a invalidar
                // pasada una vigencia aunque nadie la siga.
                .doOnNext(resultado -> {
                    if (resultado.desenlace() == ResultadoResolucionMasiva.Desenlace.EN_CURSO)
                        agregados.invalidarMasTarde(codigo);
                })
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal));
    }

    /**
     * {@inheritDoc}
     *
     * <p>Una sola lectura de {@code GET /activities/{id}} y, si terminó con errores, de sus
     * mensajes: lo mismo que hace la espera corta de la resolución, pero sin esperar.
     *
     * <p>Se comprueba que la operación sea una resolución de pendientes. La referencia llega
     * del cliente, y sin esa comprobación este endpoint serviría para leer el estado de
     * cualquier operación de larga duración del sistema de registro.
     *
     * <p><b>No</b> se comprueba que la operación sea de esa cuenta: la actividad de OHI no
     * publica el claim. Hoy da igual —todo auditor puede ver todas las cuentas—, pero si llega
     * la autorización por cuenta habrá que firmar las referencias (p. ej. un HMAC de cuenta y
     * referencia, sin estado) y rechazar aquí las que no casen. Por lo mismo, al terminar se
     * invalida lo guardado de la cuenta de la ruta, que es la que el cliente dice estar mirando.
     */
    @Override
    public Mono<ResultadoResolucionMasiva> consultarResolucion(CodigoCuenta codigo, String referencia) {
        if (referencia == null || !REFERENCIA.matcher(referencia).matches())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "«" + referencia + "» no es una referencia de operación del sistema de registro")));

        return consultarActividad(referencia).flatMap(actividad -> {
            if (!"RESOLVE_PEND".equals(actividad.type()))
                return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "La operación " + referencia + " no es una resolución de pendientes")));
            return resumir(referencia, actividad)
                    .flatMap(resultado -> resultado.desenlace() == ResultadoResolucionMasiva.Desenlace.EN_CURSO
                            ? Mono.just(resultado)
                            : alTerminar(codigo).thenReturn(resultado));
        });
    }

    /**
     * Lo que hay que olvidar cuando una resolución termina: los agregados guardados de la
     * cuenta y su estado. Se invalidaron al lanzarla, pero mientras corría cualquier lectura
     * pudo volver a guardar lo de antes (OPE-09).
     */
    private Mono<Void> alTerminar(CodigoCuenta codigo) {
        agregados.invalidar(codigo);
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .doOnNext(estados::invalidate)
                .then()
                .onErrorResume(e -> Mono.empty());
    }

    /**
     * {@inheritDoc}
     *
     * <p>Por cada motivo, dos consultas con {@code limit 1}: una a los pendientes de cabecera
     * y otra a los de línea, las dos con {@code resolved = false} y el código del motivo.
     * Medido el 2026-10-17: {@code pendReason.code.eq} filtra bien en los dos recursos, unos
     * 0,4 s por consulta, y lo resuelto no sale. Sustituye al recorrido de la cuenta entera,
     * que además cortaba en {@value #MAXIMO_PENDIENTES_POR_CUENTA} filas y podía dar por
     * desconocido un motivo que sí estaba.
     */
    @Override
    public Mono<java.util.Map<String, co.sura.auditoria.modelo.cuenta.UbicacionMotivo>> ubicarMotivos(
            CodigoCuenta codigo, java.util.Set<String> codigosMotivo) {
        if (codigosMotivo == null || codigosMotivo.isEmpty()) return Mono.just(java.util.Map.of());

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
                .flatMap(idCuenta -> Flux.fromIterable(codigosMotivo)
                        .flatMap(motivo -> Mono.zip(
                                        hayPendienteSinResolver("/generic/claimpendreasons/search",
                                                                "claim.id", idCuenta, motivo),
                                        hayPendienteSinResolver("/generic/claimlinependreasons/search",
                                                                "claimLine.claim.id", idCuenta, motivo))
                                        .map(t -> new co.sura.auditoria.modelo.cuenta.UbicacionMotivo(
                                                motivo, t.getT1(), t.getT2())),
                                 MOTIVOS_A_LA_VEZ)
                        .filter(co.sura.auditoria.modelo.cuenta.UbicacionMotivo::existe)
                        .collectMap(co.sura.auditoria.modelo.cuenta.UbicacionMotivo::codigo,
                                    u -> u, java.util.LinkedHashMap::new));
    }

    private Mono<Boolean> hayPendienteSinResolver(String ruta, String campoCuenta, long idCuenta,
                                                  String motivo) {
        var consulta = ConstructorConsulta.igual(campoCuenta, idCuenta)
                .yIgual("resolved", false)
                .yIgual("pendReason.code", motivo)
                .construir();
        var solicitud = SolicitudBusqueda.de(consulta, "id", null, 1, false);

        return clientePaciente.post()
                .uri(ruta)
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(respuesta -> !respuesta.isEmpty())
                // OHI responde 204 sin cuerpo cuando no hay ninguna fila.
                .defaultIfEmpty(false);
    }

    /**
     * Pone un motivo de pendiente, acotado o no.
     *
     * <p>Síncrono, al contrario que la resolución: medido el 2026-10-17, responde <b>204 sin
     * {@code Location}</b> y el pendiente ya está puesto. Así que aquí no hay actividad que
     * sondear ni desenlace que resumir.
     *
     * <p>Se invalida el estado de la cuenta como en la resolución, y por lo mismo: poner un
     * pendiente puede cambiar qué bloquea, y el estado cacheado se quedaría obsoleto.
     */
    @Override
    public Mono<Void> agregarMotivo(CodigoCuenta codigo, String codigoMotivo,
                                    co.sura.auditoria.modelo.cuenta.NivelPendiente nivel,
                                    co.sura.auditoria.modelo.cuenta.SeleccionLineas seleccion) {
        if (codigoMotivo == null || codigoMotivo.isBlank())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se indicó qué motivo de pendiente agregar")));

        var nivelOhi = DiccionarioOhi.desdeNivelPendiente(nivel);

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
                .doOnNext(estados::invalidate)
                .flatMap(idCuenta -> {
                    var lineas = alcance(seleccion, nivel);
                    log.info("Alta de pendiente {} en la cuenta {} a nivel '{}'{}",
                             codigoMotivo, idCuenta, nivelOhi,
                             lineas == null ? ", en toda la cuenta"
                                            : ", acotada a " + lineas.size() + " línea(s)");

                    return clientePaciente.post()
                            .uri("/claims/addpendreason")
                            .bodyValue(OhiAgregarPendienteRequest.de(
                                    idCuenta, codigoMotivo, nivelOhi, lineas))
                            .retrieve()
                            .onStatus(s -> s.isError(), traductorErrores::traducir)
                            .toBodilessEntity()
                            .transform(resiliencia.paraComandosMono())
                            .doOnSuccess(x -> estados.invalidate(idCuenta))
                            .then();
                })
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal));
    }

    /**
     * Qué líneas viajan en el cuerpo, o {@code null} para no acotar.
     *
     * <p>Acotar solo tiene sentido a nivel de línea: un pendiente de cabecera no pertenece a
     * ninguna, y mandar {@code claimLineList} con {@code level="claim"} es una combinación
     * que el sistema de registro no rechaza pero tampoco cumple —ignorarla en silencio es
     * peor que no mandarla—. Así que a nivel de cabecera se descarta el alcance aquí.
     */
    private static java.util.List<Long> alcance(
            co.sura.auditoria.modelo.cuenta.SeleccionLineas seleccion,
            co.sura.auditoria.modelo.cuenta.NivelPendiente nivel) {
        if (seleccion == null || seleccion.esTodaLaCuenta()) return null;
        if (nivel == co.sura.auditoria.modelo.cuenta.NivelPendiente.CABECERA) {
            log.warn("Se pidió acotar a {} línea(s) una resolución de CABECERA: se ignora el "
                     + "alcance, porque un pendiente de cabecera no pertenece a ninguna línea",
                     seleccion.cuantas());
            return null;
        }
        return seleccion.identificadores();
    }

    /**
     * Lanza la operación y devuelve su identificador, leído de {@code Location}.
     *
     * <p>Sin cuerpo que interpretar: la respuesta del {@code 201} viene vacía y
     * lo único que trae es la dirección de la operación. Si esa cabecera no
     * llegara, el contrato se habría roto y callarlo dejaría al auditor con un
     * éxito que nadie puede verificar.
     */
    private Mono<String> emitirResolucion(long idCuenta, java.util.Set<String> codigos,
                                          String nivelOhi, java.util.List<Long> lineas) {
        var cuerpo = OhiResolverPendientesRequest.deLineas(idCuenta, codigos, nivelOhi, lineas);

        log.info("Resolución conjunta en la cuenta {}: {} motivo(s) a nivel '{}'{}",
                 idCuenta, codigos.size(), nivelOhi,
                 lineas == null ? ", en toda la cuenta" : ", acotada a " + lineas.size() + " línea(s)");

        return clientePaciente.post()
                .uri("/claims/resolvependreasons")
                .bodyValue(cuerpo)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .toBodilessEntity()
                .transform(resiliencia.paraComandosMono())
                .flatMap(respuesta -> {
                    var destino = respuesta.getHeaders().getLocation();
                    if (destino == null)
                        return Mono.error(ExcepcionDeDominio.de(
                                new ErrorDeDominio.SistemaRegistroNoDisponible(
                                        "El sistema de registro aceptó la resolución pero no indicó "
                                      + "dónde seguirla, así que no se puede confirmar su resultado")));
                    return Mono.just(ultimoSegmento(destino.getPath()));
                });
    }

    /**
     * Espera a que la operación termine —o se cansa— y traduce el desenlace.
     *
     * <p><b>Un fallo aquí no es un fallo de la resolución.</b> Cuando se llega a
     * este punto el {@code POST} ya se aceptó y la operación está corriendo en el
     * sistema de registro; si además se cae el sondeo —un timeout, el circuito
     * abierto, un 5xx de la consulta— propagar el error diría «no se aplicó
     * nada», que es falso y además invita a repetir una operación que no es
     * idempotente y que ya está en marcha. Lo que se sabe de verdad es que se
     * emitió y no se pudo confirmar: eso es exactamente {@code EN_CURSO}, con la
     * referencia para poder rastrearla.
     */
    private Mono<ResultadoResolucionMasiva> esperarYResumir(String referencia) {
        return sondear(referencia, MAXIMO_SONDEOS)
                .flatMap(actividad -> resumir(referencia, actividad))
                .onErrorResume(e -> {
                    log.warn("La resolución conjunta {} se emitió pero no se pudo confirmar: {}",
                             referencia, e.toString());
                    return Mono.just(enCurso(referencia));
                });
    }

    /** Se emitió y todavía no se sabe en qué acabó. Ni éxito ni fracaso. */
    private static ResultadoResolucionMasiva enCurso(String referencia) {
        return new ResultadoResolucionMasiva(
                List.of(referencia), ResultadoResolucionMasiva.Desenlace.EN_CURSO, List.of());
    }

    /**
     * Pregunta por la operación hasta que termine o hasta agotar los sondeos.
     *
     * <p>Siempre emite la última lectura, terminada o no: así el resumen puede
     * distinguir «terminó mal» de «todavía no se sabe», que para el auditor son
     * cosas muy distintas.
     */
    private Mono<OhiActividad> sondear(String referencia, int sondeosRestantes) {
        return consultarActividad(referencia).flatMap(actividad -> {
            if (actividad.terminada() || sondeosRestantes <= 0) return Mono.just(actividad);
            return Mono.delay(PAUSA_ENTRE_SONDEOS)
                    .then(Mono.defer(() -> sondear(referencia, sondeosRestantes - 1)));
        });
    }

    /**
     * El estado de la operación. Se consulta por la ruta que publica OHI en el
     * {@code Location}, que no está bajo {@code /generic}.
     */
    private Mono<OhiActividad> consultarActividad(String referencia) {
        return clientePaciente.get()
                .uri("/activities/{id}", referencia)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(OhiActividad.class)
                .transform(resiliencia.paraConsultaPacienteMono());
    }

    /**
     * Traduce el estado final de la operación al desenlace del dominio.
     *
     * <p>Los tres estados «Completado…» de OHI son todos «terminó», pero solo
     * {@code CO} es «terminó y salió todo». Para {@code CB} y {@code CT} hay que
     * ir a los mensajes: son los fallos parciales, que no aparecen por ninguna
     * otra parte.
     */
    private Mono<ResultadoResolucionMasiva> resumir(String referencia, OhiActividad actividad) {
        if (!actividad.terminada()) {
            // DEBUG y no INFO: el seguimiento de la pantalla pregunta cada pocos segundos.
            log.debug("La resolución conjunta {} sigue en curso (estado {})",
                      referencia, actividad.status());
            return Mono.just(enCurso(referencia));
        }

        if (actividad.limpia()) return Mono.just(ResultadoResolucionMasiva.completo(referencia));

        log.warn("La resolución conjunta {} terminó en estado {}", referencia, actividad.status());

        return fallosDe(referencia).map(fallos -> new ResultadoResolucionMasiva(
                List.of(referencia),
                actividad.fallida() ? ResultadoResolucionMasiva.Desenlace.FALLIDO
                                    : ResultadoResolucionMasiva.Desenlace.PARCIAL,
                fallos.isEmpty() ? List.of(sinDetalle(actividad)) : fallos));
    }

    /**
     * Los fallos que reportó la operación, ya redactados.
     *
     * <p>Se buscan también por {@code rootActivityId} porque la operación padre
     * reparte el trabajo en actividades hijas y es la hija la que reporta el
     * fallo: con solo {@code activity.id} se leería el informativo del padre y se
     * concluiría que no hubo ninguno. La consulta es la que OHI publica en el
     * enlace {@code operator:messages} de la propia operación.
     *
     * <p>Si la consulta de mensajes falla, no se tumba la llamada: la resolución
     * ya se aplicó y el desenlace que se conoce —parcial o fallido— sigue siendo
     * cierto aunque no se pueda detallar. Se devuelve sin detalle en vez de
     * convertir un «salió a medias» en un error de sistema.
     */
    private Mono<List<ResultadoResolucionMasiva.Fallo>> fallosDe(String referencia) {
        long id;
        try {
            id = Long.parseLong(referencia);
        } catch (NumberFormatException e) {
            return Mono.just(List.of());
        }

        var consulta = ConstructorConsulta.igual("activity.id", id)
                .o(ConstructorConsulta.igual("activity.rootActivityId", id))
                .construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.MENSAJE_ACTIVIDAD, null,
                                             SolicitudBusqueda.LIMITE_MAXIMO, false);

        return clientePaciente.post()
                .uri("/generic/activitymessages/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiMensajeActividad>>() {})
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(respuesta -> respuesta.items() == null ? List.<OhiMensajeActividad>of()
                                                            : respuesta.items())
                .map(mensajes -> mensajes.stream()
                        .filter(m -> !m.esRuido())
                        .filter(AdaptadorPendientesOhi::esFallo)
                        .map(AdaptadorPendientesOhi::aFallo)
                        .distinct()
                        .toList())
                .onErrorResume(e -> {
                    log.warn("No se pudieron leer los mensajes de la resolución {}: {}",
                             referencia, e.getMessage());
                    return Mono.just(List.of());
                });
    }

    /** Solo los fatales son fallos; los informativos son la mecánica de OHI. */
    private static boolean esFallo(OhiMensajeActividad mensaje) {
        var severidad = mensaje.message() == null ? null : mensaje.message().severity();
        return severidad == null || "F".equals(severidad) || "D".equals(severidad);
    }

    /**
     * Redacta el fallo para el auditor.
     *
     * <p>El texto del catálogo viene con marcadores ({@code "Claim Line {0} is
     * unknown"}) y el valor que los rellena llega aparte, en {@code value0}. Se
     * sustituye aquí: dejar el {@code {0}} a la vista haría el mensaje inútil.
     */
    private static ResultadoResolucionMasiva.Fallo aFallo(OhiMensajeActividad mensaje) {
        var plantilla = mensaje.message() == null ? null : mensaje.message().descripcion();
        var texto = plantilla == null || plantilla.isBlank()
                ? DiccionarioOhi.explicacionDeFalloDeResolucion(mensaje.codigo())
                : plantilla.replace("{0}", mensaje.elemento())
                           .replace("{1}", mensaje.value1() == null ? "" : mensaje.value1());
        return new ResultadoResolucionMasiva.Fallo(mensaje.codigo(), mensaje.elemento(), texto);
    }

    /** Lo que se puede decir cuando OHI marca errores pero no publica ninguno. */
    private static ResultadoResolucionMasiva.Fallo sinDetalle(OhiActividad actividad) {
        return new ResultadoResolucionMasiva.Fallo(
                "SIN_DETALLE", "",
                "El sistema de registro marcó la operación como «" + actividad.status()
              + "» pero no publicó ningún mensaje que lo explique. Vuelva a cargar los "
              + "pendientes para ver qué quedó sin resolver.");
    }

    /** El identificador que cierra una ruta como {@code /prod/claims/api/activities/123}. */
    private static String ultimoSegmento(String ruta) {
        if (ruta == null || ruta.isBlank()) return "";
        var limpia = ruta.endsWith("/") ? ruta.substring(0, ruta.length() - 1) : ruta;
        return limpia.substring(limpia.lastIndexOf('/') + 1);
    }

    @Override
    public Mono<Void> resolverEnCuentaYLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, "resolvepend")
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal));
    }

    @Override
    public Mono<Void> resolverSoloEnLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, "resolveclaimlinepend")
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal));
    }

    /**
     * Ejecuta la resolución contra OHI.
     *
     * <p>Dos detalles del contrato real, tomados de los enlaces HATEOAS que
     * publica la propia cuenta ({@code claim:resolvepend}):
     * <ul>
     *   <li>el recurso vive fuera de {@code /generic};</li>
     *   <li>el motivo va como segmento de la ruta, no como parámetro de consulta.</li>
     * </ul>
     */
    private Mono<Void> resolver(CodigoCuenta codigo, long identificadorPendiente, String accion) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .doOnNext(estados::invalidate)
                .flatMap(idCuenta -> idDelMotivo(identificadorPendiente)
                        .flatMap(idMotivo -> clientePaciente.post()
                                .uri("/claims/{idCuenta}/{accion}/{idMotivo}",
                                     idCuenta, accion, idMotivo)
                                // Esta llamada dispara readjudicación en OHI; el timeout
                                // general de lectura (pensado para consultas) le queda corto.
                                // Se usa el cliente de operaciones largas, con su propio
                                // pool y su propio ReadTimeoutHandler: un override de
                                // responseTimeout por petición sobre el cliente general no
                                // basta, porque el handler ya instalado en el canal corta
                                // primero (verificado en producción).
                                .retrieve()
                                .onStatus(s -> s.isError(), traductorErrores::traducir)
                                .bodyToMono(Void.class)
                                .transform(resiliencia.paraComandosMono())));
    }

    /**
     * Traduce el identificador que conoce el dominio al que espera OHI.
     *
     * <p>El listado de pendientes entrega el id de la <em>fila</em>
     * (claimpendreason / claimlinependreason), que es único y sirve para
     * identificar cada pendiente en la interfaz. Las rutas de resolución, en
     * cambio, esperan el id del <em>motivo</em> del catálogo. Aquí se hace esa
     * traducción, que es justamente lo que corresponde a la ACL.
     *
     * <p>Se busca primero entre los pendientes de cabecera y luego entre los de
     * línea. Si no aparece en ninguno, se usa el valor recibido tal cual: puede
     * que quien llama ya conozca el id del motivo.
     */
    private Mono<Long> idDelMotivo(long identificadorPendiente) {
        return buscarFila("/generic/claimpendreasons/search", identificadorPendiente)
                .switchIfEmpty(buscarFila("/generic/claimlinependreasons/search", identificadorPendiente))
                .defaultIfEmpty(identificadorPendiente);
    }

    private Mono<Long> buscarFila(String recurso, long identificadorPendiente) {
        var consulta = ConstructorConsulta.igual("id", identificadorPendiente).construir();
        var solicitud = SolicitudBusqueda.unica(consulta, "id,pendReason.id");

        return clientePaciente.post()
                .uri(recurso)
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first()
                        .map(OhiPendReasonItem::pendReason)
                        .filter(motivo -> motivo != null && motivo.id() != null)
                        .map(motivo -> Mono.just(Long.parseLong(motivo.id())))
                        .orElse(Mono.empty()));
    }

    @Override
    public Mono<Void> resolverPendienteCabecera(long identificadorPendiente) {
        return webClient.patch()
                .uri("/generic/claimpendreasons/{id}?resolve=true", identificadorPendiente)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(Void.class)
                .transform(resiliencia.paraComandosMono())
                // Solo se conoce la fila, no la cuenta: se vacía todo, que es raro y solo cuesta recargar.
                .doFinally(senal -> agregados.invalidarTodo());
    }

    @Override
    public Mono<Void> resolverPendienteLinea(long identificadorPendiente) {
        return webClient.patch()
                .uri("/generic/claimlinependreasons/{id}?resolve=true", identificadorPendiente)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(Void.class)
                .transform(resiliencia.paraComandosMono())
                .doFinally(senal -> agregados.invalidarTodo());
    }
}
