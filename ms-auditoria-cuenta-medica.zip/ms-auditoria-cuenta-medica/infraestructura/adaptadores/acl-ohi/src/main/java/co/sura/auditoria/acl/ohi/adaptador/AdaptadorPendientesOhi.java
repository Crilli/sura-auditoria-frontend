package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorPendientesOhi implements PuertoPendientes {

    private final WebClient webClient;
    /** Cliente con más margen de lectura, usado solo para resolver pendientes. */
    private final WebClient clientePaciente;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final TraductorPendiente traductorPendiente;
    /** Tope defensivo de pendientes por línea al pedir los de una página. */
    private static final int MAXIMO_PENDIENTES_POR_LINEA = 20;



    private final ResolutorIdentidadOhi resolutor;
    /**
     * Resolver de identidad. Lo implementa {@code AdaptadorConsultasOhi}, que a su
     * vez depende de este adaptador para traer los pendientes de la cuenta: la
     * referencia es perezosa para romper ese ciclo en el contenedor.
     */
    private final ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo;

    public AdaptadorPendientesOhi(WebClient webClient,
                                  @org.springframework.beans.factory.annotation.Qualifier(
                                          co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
                                  WebClient clientePaciente,
                                  ConfiguracionResiliencia resiliencia,
                                  TraductorErrores traductorErrores,
                                  TraductorPendiente traductorPendiente,
                                  ResolutorIdentidadOhi resolutor,
                                  @Lazy ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo) {
        this.webClient = webClient;
        this.clientePaciente = clientePaciente;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.traductorPendiente = traductorPendiente;
        this.resolutor = resolutor;
        this.buscadorPorCodigo = buscadorPorCodigo;
    }

    // ── Queries Internas (usadas por AdaptadorConsultasOhi) ───────────────

    /**
     * Se ejecuta siempre dentro del mismo flujo que {@code buscarItem()}
     * (constructor de {@code buscarPorCodigo}): por eso usa el mismo cliente
     * paciente y sin retry. Verificado en producción con CM-55181980659, que
     * excede el timeout general no solo en {@code claims/search} sino también
     * aquí — el volumen alto de esa cuenta afecta cualquier consulta relacionada,
     * no solo la cabecera propiamente dicha.
     */
    public Mono<List<OhiPendReasonItem>> buscarDeCabecera(long idCuenta) {
        var consulta = ConstructorConsulta.igual("claim.id", idCuenta).construir();
        // `unica` limita a un registro: aquí se necesitan todos los de la cabecera.
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_CABECERA,
                                             null, SolicitudBusqueda.LIMITE_MAXIMO, false);

        return clientePaciente.post()
                .uri("/generic/claimpendreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    /**
     * Pendientes de un conjunto concreto de líneas.
     *
     * <p>Se consulta por los identificadores de la página en curso y no por la
     * cuenta entera: una cuenta con cientos de líneas traía todos sus pendientes
     * en cada salto de página, aunque solo se pintaran veinticinco.
     */
    public Mono<List<OhiPendReasonItem>> buscarDeLineas(List<Long> idsLinea) {
        if (idsLinea == null || idsLinea.isEmpty()) return Mono.just(List.of());

        var consulta = ConstructorConsulta.contenidoEnIds("claimLine.id", idsLinea).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_LINEA,
                                             null, SolicitudBusqueda.limitarAlMaximo(
                                                 idsLinea.size() * MAXIMO_PENDIENTES_POR_LINEA), false);

        // Mismo cliente paciente que el resto de la ruta de líneas: ver
        // AdaptadorConsultasOhi.listarResumenLineas().
        return clientePaciente.post()
                .uri("/generic/claimlinependreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    /**
     * Pendientes de todas las líneas de la cuenta.
     *
     * <p>La usa el listado de pendientes, que por definición los necesita todos.
     * Para enriquecer una página de la grilla use {@link #buscarDeLineas(List)},
     * que solo trae los de las líneas visibles.
     */
    public Mono<List<OhiPendReasonItem>> buscarDeLineasDeLaCuenta(long idCuenta) {
        var consulta = ConstructorConsulta.igual("claimLine.claim.id", idCuenta).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_LINEA,
                                             null, SolicitudBusqueda.LIMITE_MAXIMO, false);

        return clientePaciente.post()
                .uri("/generic/claimlinependreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                .defaultIfEmpty(List.of());
    }

    public Mono<List<OhiPendReasonItem>> buscarDeLinea(long idLinea) {
        var consulta = ConstructorConsulta.igual("claimLine.id", idLinea).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.PENDIENTE_LINEA,
                                             null, MAXIMO_PENDIENTES_POR_LINEA, false);

        return clientePaciente.post()
                .uri("/generic/claimlinependreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .map(r -> r.isEmpty() ? List.<OhiPendReasonItem>of() : r.items())
                // OHI responde 204 sin cuerpo cuando no hay resultados:
                // sin esto el Mono queda vacío y arrastra a toda la cadena.
                .defaultIfEmpty(List.of());
    }

    // ── PuertoPendientes ──────────────────────────────────────────────────

    @Override
    public Flux<MotivoPendiente> listarSinResolver(CodigoCuenta codigo) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMapMany(idCuenta -> Flux.concat(
                        buscarDeCabecera(idCuenta).flatMapIterable(l -> l).map(traductorPendiente::aDominioCabecera),
                        buscarDeLineasDeLaCuenta(idCuenta).flatMapIterable(l -> l).map(traductorPendiente::aDominioLinea)
                ))
                .filter(p -> !p.resuelto());
    }

    @Override
    public Mono<Void> resolverEnCuentaYLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, "resolvepend");
    }

    @Override
    public Mono<Void> resolverSoloEnLineas(CodigoCuenta codigo, long identificadorMotivo) {
        return resolver(codigo, identificadorMotivo, "resolveclaimlinepend");
    }

    /**
     * Ejecuta la resolución contra OHI.
     *
     * <p>Dos detalles del contrato real, tomados de los enlaces HATEOAS que
     * publica la propia cuenta ({@code claim:resolvepend}):
     * <ul>
     *   <li>el recurso vive fuera de {@code /generic};</li>
     *   <li>el motivo va como segmento de la ruta, no como parámetro de consulta.</li>
     * </ul>
     */
    private Mono<Void> resolver(CodigoCuenta codigo, long identificadorPendiente, String accion) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> idDelMotivo(identificadorPendiente)
                        .flatMap(idMotivo -> clientePaciente.post()
                                .uri("/claims/{idCuenta}/{accion}/{idMotivo}",
                                     idCuenta, accion, idMotivo)
                                // Esta llamada dispara readjudicación en OHI; el timeout
                                // general de lectura (pensado para consultas) le queda corto.
                                // Se usa el cliente de operaciones largas, con su propio
                                // pool y su propio ReadTimeoutHandler: un override de
                                // responseTimeout por petición sobre el cliente general no
                                // basta, porque el handler ya instalado en el canal corta
                                // primero (verificado en producción).
                                .retrieve()
                                .onStatus(s -> s.isError(), traductorErrores::traducir)
                                .bodyToMono(Void.class)
                                .transform(resiliencia.paraComandosMono())));
    }

    /**
     * Traduce el identificador que conoce el dominio al que espera OHI.
     *
     * <p>El listado de pendientes entrega el id de la <em>fila</em>
     * (claimpendreason / claimlinependreason), que es único y sirve para
     * identificar cada pendiente en la interfaz. Las rutas de resolución, en
     * cambio, esperan el id del <em>motivo</em> del catálogo. Aquí se hace esa
     * traducción, que es justamente lo que corresponde a la ACL.
     *
     * <p>Se busca primero entre los pendientes de cabecera y luego entre los de
     * línea. Si no aparece en ninguno, se usa el valor recibido tal cual: puede
     * que quien llama ya conozca el id del motivo.
     */
    private Mono<Long> idDelMotivo(long identificadorPendiente) {
        return buscarFila("/generic/claimpendreasons/search", identificadorPendiente)
                .switchIfEmpty(buscarFila("/generic/claimlinependreasons/search", identificadorPendiente))
                .defaultIfEmpty(identificadorPendiente);
    }

    private Mono<Long> buscarFila(String recurso, long identificadorPendiente) {
        var consulta = ConstructorConsulta.igual("id", identificadorPendiente).construir();
        var solicitud = SolicitudBusqueda.unica(consulta, "id,pendReason");

        return clientePaciente.post()
                .uri(recurso)
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPendReasonItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first()
                        .map(OhiPendReasonItem::pendReason)
                        .filter(motivo -> motivo != null && motivo.id() != null)
                        .map(motivo -> Mono.just(Long.parseLong(motivo.id())))
                        .orElse(Mono.empty()));
    }

    @Override
    public Mono<Void> resolverPendienteCabecera(long identificadorPendiente) {
        return webClient.patch()
                .uri("/generic/claimpendreasons/{id}?resolve=true", identificadorPendiente)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(Void.class)
                .transform(resiliencia.paraComandosMono());
    }

    @Override
    public Mono<Void> resolverPendienteLinea(long identificadorPendiente) {
        return webClient.patch()
                .uri("/generic/claimlinependreasons/{id}?resolve=true", identificadorPendiente)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(Void.class)
                .transform(resiliencia.paraComandosMono());
    }
}
