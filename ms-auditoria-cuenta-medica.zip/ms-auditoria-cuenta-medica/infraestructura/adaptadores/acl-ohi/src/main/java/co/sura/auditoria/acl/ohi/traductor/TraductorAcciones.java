package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiLink;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Traduce los link relations publicados por OHI en capacidades del dominio.
 *
 * <p>Esta es la única interpretación autorizada de los enlaces HATEOAS.
 * El dominio nunca deduce capacidades del estado de la cuenta (ADR-003).
 */
@Component
public class TraductorAcciones {

    public AccionesDisponibles aDominio(List<OhiLink> enlaces) {
        if (enlaces == null || enlaces.isEmpty())
            return AccionesDisponibles.ninguna();

        var acciones = enlaces.stream()
                .map(OhiLink::rel)
                .map(DiccionarioOhi::aAccion)
                .flatMap(Optional::stream)
                .collect(Collectors.toUnmodifiableSet());

        return new AccionesDisponibles(acciones);
    }
}
