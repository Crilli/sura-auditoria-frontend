package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiAccionRequest;
import co.sura.auditoria.acl.ohi.externo.OhiLink;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Traduce los link relations publicados por OHI en capacidades del dominio.
 *
 * <p>Esta es la única interpretación autorizada de los enlaces HATEOAS.
 * El dominio nunca deduce capacidades del estado de la cuenta (ADR-003).
 */
@Component
public class TraductorAcciones {

    public AccionesDisponibles aDominio(List<OhiLink> enlaces) {
        if (enlaces == null || enlaces.isEmpty())
            return AccionesDisponibles.ninguna();

        var acciones = enlaces.stream()
                .map(OhiLink::rel)
                .map(DiccionarioOhi::aAccion)
                .flatMap(Optional::stream)
                .collect(Collectors.toUnmodifiableSet());

        return new AccionesDisponibles(acciones);
    }

    /**
     * El cuerpo que lleva cada acción, o {@code null} si no lleva ninguno.
     *
     * <p>Seis de las nueve no llevan nada: son transiciones de estado a secas.
     * Las dos que piden motivos comparten el mismo catálogo, y el desbloqueo de
     * líneas lleva una lista que solo se manda si el auditor eligió unas
     * concretas —sin ella el sistema de registro las desbloquea todas, que es
     * justo lo que se quiere cuando no eligió—.
     */
    public static Object cuerpoDe(EjecucionAccion ejecucion) {
        var motivos = ejecucion.motivos().stream()
                .map(c -> OhiAccionRequest.Motivo.de(c, ejecucion.referencia()))
                .toList();

        return switch (ejecucion.accion()) {
            case ANULAR -> new OhiAccionRequest.Anular(
                    ejecucion.codigoMensajeAnulacion(), motivos, null);
            case REVERTIR_FINALIZACION -> new OhiAccionRequest.Desfinalizar(motivos);
            case DESBLOQUEAR_LINEAS -> ejecucion.lineas().isEmpty()
                    ? null
                    : new OhiAccionRequest.DesbloquearLineas(ejecucion.lineas());
            default -> null;
        };
    }
}