package co.sura.auditoria.acl.ohi.identidad;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Duration;

/**
 * Resuelve el identificador técnico interno de OHI (Long id) a partir del
 * código de negocio de la cuenta médica.
 *
 * <p>El identificador técnico <em>nunca</em> sale de la ACL.
 *
 * <p>El proveedor de búsqueda se inyecta como {@code Mono<Long>} lambdas para
 * evitar la dependencia circular entre ResolutorIdentidadOhi y AdaptadorConsultasOhi.
 *
 * <h3>Por qué la caché es grande y dura</h3>
 * <b>Toda</b> operación del API empieza por aquí: los adaptadores la invocan entre una y
 * cinco veces por petición, y cada fallo de caché es <b>una llamada más a OHI</b>. Con las
 * 500 entradas y los 10 minutos que tenía antes, un recorrido de miles de cuentas —que es
 * exactamente lo que hace una prueba de carga realista— desfondaba la caché y <b>duplicaba
 * el tráfico contra OHI</b>.
 *
 * <p>Lo venenoso era cómo se manifestaba: con pocos usuarios y pocas cuentas la caché iba
 * caliente y todo parecía bien; a partir de cierto volumen de datos la latencia se duplicaba
 * de golpe sin que nada en el código hubiera cambiado.
 *
 * <p>Agrandarla es barato y seguro. Barato porque cada entrada es un código y un
 * {@code Long}: 50.000 entradas rondan los 5 MB. Seguro porque <b>la relación código → id
 * es inmutable en OHI</b>, así que una entrada vieja nunca es una entrada equivocada; si la
 * cuenta desaparece, la llamada siguiente falla con 404 y el dominio ya lo traduce.
 *
 * <p><b>Ojo con el escalado horizontal:</b> esta caché vive en el proceso. Cada réplica
 * arranca con la suya vacía, así que añadir réplicas <em>no</em> mejora la tasa de acierto;
 * la reparte. Por eso importa que el tamaño por réplica sea holgado, y por eso se publica
 * la estadística: ver la tasa de acierto durante la prueba de carga es lo único que
 * demuestra que esto funciona.
 */
@Component
public class ResolutorIdentidadOhi {

    private final Cache<String, Long> cache;

    public ResolutorIdentidadOhi(
            @Value("${integraciones.ohi.cache-identidad.maximo-entradas:50000}") long maximoEntradas,
            @Value("${integraciones.ohi.cache-identidad.expiracion:2h}") Duration expiracion) {
        this.cache = Caffeine.newBuilder()
                .maximumSize(maximoEntradas)
                .expireAfterWrite(expiracion)
                .recordStats()          // lo consume el enlace con Micrometer en servicio-app
                .build();
    }

    /** Valores por omisión; es el que usan las pruebas que no miden el dimensionamiento. */
    public ResolutorIdentidadOhi() {
        this(50_000L, Duration.ofHours(2));
    }

    /**
     * Resuelve el ID de OHI de la cuenta a partir de su código de negocio.
     *
     * @param codigo          código de negocio de la cuenta
     * @param buscadorExterno función que consulta OHI por código y devuelve el ID
     */
    public Mono<Long> resolverParaCuenta(CodigoCuenta codigo,
                                         BuscadorPorCodigo buscadorExterno) {
        var cached = cache.getIfPresent(codigo.valor());
        if (cached != null) return Mono.just(cached);

        return buscadorExterno.buscar(codigo.valor())
                .doOnNext(id -> cache.put(codigo.valor(), id));
    }

    /**
     * Resuelve el ID de OHI de un pendiente dado su ID de dominio.
     * Los pendientes tienen el mismo ID en dominio y en OHI,
     * pero se mantiene la abstracción por consistencia.
     */
    public long resolverParaPendiente(long idDominio) {
        return idDominio;  // el ID de dominio coincide con el de OHI para pendientes
    }

    /** Invalida la entrada del caché para forzar una nueva búsqueda. */
    public void invalidar(CodigoCuenta codigo) {
        cache.invalidate(codigo.valor());
    }

    /**
     * La caché por debajo, para que la capa de aplicación le enganche las métricas.
     *
     * <p>Se expone la caché y no un resumen propio a propósito: así el enlace con Micrometer
     * publica todo lo que Caffeine ya mide (aciertos, fallos, desalojos, carga) sin que este
     * módulo tenga que depender de Micrometer.
     */
    public Cache<String, Long> cacheNativa() {
        return cache;
    }

    @FunctionalInterface
    public interface BuscadorPorCodigo {
        Mono<Long> buscar(String codigoNegocio);
    }
}
