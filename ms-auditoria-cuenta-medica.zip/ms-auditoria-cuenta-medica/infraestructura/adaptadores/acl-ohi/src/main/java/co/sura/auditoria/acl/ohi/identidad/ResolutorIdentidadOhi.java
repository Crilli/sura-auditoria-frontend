package co.sura.auditoria.acl.ohi.identidad;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Optional;
import org.springframework.context.annotation.Profile;

/**
 * Resuelve el identificador técnico interno de OHI (Long id) a partir del
 * código de negocio de la cuenta médica.
 *
 * <p>El identificador técnico <em>nunca</em> sale de la ACL.
 * El caché reduce las llamadas de búsqueda repetidas al sistema de registro.
 *
 * <p>El proveedor de búsqueda se inyecta como {@code Mono<Long>} lambdas para
 * evitar la dependencia circular entre ResolutorIdentidadOhi y AdaptadorConsultasOhi.
 */
@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class ResolutorIdentidadOhi {

    private final Cache<String, Long> cache = Caffeine.newBuilder()
            .maximumSize(500)
            .expireAfterWrite(Duration.ofMinutes(10))
            .recordStats()
            .build();

    /**
     * Resuelve el ID de OHI de la cuenta a partir de su código de negocio.
     *
     * @param codigo          código de negocio de la cuenta
     * @param buscadorExterno función que consulta OHI por código y devuelve el ID
     */
    public Mono<Long> resolverParaCuenta(CodigoCuenta codigo,
                                         BuscadorPorCodigo buscadorExterno) {
        var cached = cache.getIfPresent(codigo.valor());
        if (cached != null) return Mono.just(cached);

        return buscadorExterno.buscar(codigo.valor())
                .doOnNext(id -> cache.put(codigo.valor(), id));
    }

    /**
     * Resuelve el ID de OHI de un pendiente dado su ID de dominio.
     * Los pendientes tienen el mismo ID en dominio y en OHI,
     * pero se mantiene la abstracción por consistencia.
     */
    public long resolverParaPendiente(long idDominio) {
        return idDominio;  // el ID de dominio coincide con el de OHI para pendientes
    }

    /** Invalida la entrada del caché para forzar una nueva búsqueda. */
    public void invalidar(CodigoCuenta codigo) {
        cache.invalidate(codigo.valor());
    }

    @FunctionalInterface
    public interface BuscadorPorCodigo {
        Mono<Long> buscar(String codigoNegocio);
    }
}
