package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiClaimItem;
import co.sura.auditoria.acl.ohi.externo.OhiClaimLineItem;
import co.sura.auditoria.acl.ohi.externo.OhiPricingClause;
import co.sura.auditoria.acl.ohi.externo.OhiReferencia;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.externo.OhiStatusResponse;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorAcciones;
import co.sura.auditoria.acl.ohi.traductor.TraductorCuenta;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorEstadoProceso;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;

import java.util.List;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorConsultasOhi implements PuertoConsultaCuentas, ResolutorIdentidadOhi.BuscadorPorCodigo {

    private static final org.slf4j.Logger log =
            org.slf4j.LoggerFactory.getLogger(AdaptadorConsultasOhi.class);

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final TraductorCuenta traductorCuenta;
    private final TraductorLinea traductorLinea;
    private final TraductorPendiente traductorPendiente;
    private final TraductorEstadoProceso traductorProceso;
    private final AdaptadorPendientesOhi adaptadorPendientes;
    private final AdaptadorNovedadesOhi adaptadorNovedades;
    private final AdaptadorAfiliadosOhi adaptadorAfiliados;
    private final AdaptadorPrestadoresOhi adaptadorPrestadores;
    private final ResolutorIdentidadOhi resolutor;
    private final WebClient clientePaciente;
    private final TraductorAcciones traductorAcciones;

    public AdaptadorConsultasOhi(WebClient webClient,
                                 ConfiguracionResiliencia resiliencia,
                                 TraductorErrores traductorErrores,
                                 TraductorCuenta traductorCuenta,
                                 TraductorLinea traductorLinea,
                                 TraductorPendiente traductorPendiente,
                                 TraductorEstadoProceso traductorProceso,
                                 AdaptadorPendientesOhi adaptadorPendientes,
                                 AdaptadorNovedadesOhi adaptadorNovedades,
                                 AdaptadorAfiliadosOhi adaptadorAfiliados,
                                 AdaptadorPrestadoresOhi adaptadorPrestadores,
                                 ResolutorIdentidadOhi resolutor,
                                 TraductorAcciones traductorAcciones,
                                 @org.springframework.beans.factory.annotation.Qualifier(
                                         co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
                                 WebClient clientePaciente) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.traductorCuenta = traductorCuenta;
        this.traductorLinea = traductorLinea;
        this.traductorPendiente = traductorPendiente;
        this.traductorProceso = traductorProceso;
        this.adaptadorPendientes = adaptadorPendientes;
        this.adaptadorNovedades = adaptadorNovedades;
        this.adaptadorAfiliados = adaptadorAfiliados;
        this.adaptadorPrestadores = adaptadorPrestadores;
        this.resolutor = resolutor;
        this.clientePaciente = clientePaciente;
        this.traductorAcciones = traductorAcciones;
    }

    // ── ResolutorIdentidadOhi.BuscadorPorCodigo ──────────────────────────────

    @Override
    public Mono<Long> buscar(String codigoNegocio) {
        return buscarItem(codigoNegocio).map(OhiClaimItem::id);
    }

    /**
     * Cabecera de la cuenta por su código de negocio.
     *
     * <p>Se pide con la representación de solo cabecera: OHI adjunta la cuenta
     * entera si no se le indica lo contrario, y de una cuenta grande eso son
     * cientos de kilobytes de líneas que aquí no se usan.
     */
    /**
     * Cabecera de la cuenta por su código de negocio.
     *
     * <p>Usa el cliente de operaciones largas, no el general: el payload de
     * salida es pequeño ({@code excludereferenceresources=true}), pero OHI debe
     * resolver igual todas las relaciones de la cuenta antes de excluirlas, y en
     * cuentas con mucho volumen relacionado eso excede el timeout de una lectura
     * normal. Ver {@link PropiedadesOhi.Timeouts#resolucionPendiente()}.
     */
    private Mono<OhiClaimItem> buscarItem(String codigoNegocio) {
        var consulta = ConstructorConsulta.igual("code", codigoNegocio).construir();
        var solicitud = SolicitudBusqueda.cabecera(consulta, CamposOhi.CABECERA_CUENTA);

        return webClient.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                // Sin retry: ver ConfiguracionResiliencia.paraConsultaPacienteMono().
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()));
    }

    // ── PuertoConsultaCuentas ────────────────────────────────────────────────

    @Override
    public Mono<CuentaMedica> buscarPorCodigo(CodigoCuenta codigo) {
        return buscarItem(codigo.valor())
                // Si la cuenta existe, se solicitan sus pendientes de cabecera y las
                // referencias (prestadores) que buscarItem() no puede traer — ver
                // referenciasDeLaCabecera().
                // Las novedades entran como una pata más de la misma zip: van en
                // paralelo con los pendientes y las referencias, así que no
                // añaden latencia a la cabecera.
                .flatMap(item -> Mono.zip(
                                adaptadorPendientes.buscarDeCabecera(item.id()),
                                referenciasDeLaCabecera(codigo),
                                adaptadorNovedades.buscarDeCabecera(item.id()))
                        .map(tupla -> {
                            var referencias = tupla.getT2();
                            return traductorCuenta.aDominio(item, tupla.getT1(), tupla.getT3(),
                                    nuloSiVacio(referencias.prestadorFacturacion()),
                                    nuloSiVacio(referencias.pagarAPrestador()));
                        }));
    }

    /**
     * Acciones disponibles, en su propia consulta.
     *
     * <p>Aislada de {@link #buscarPorCodigo} a propósito. OHI solo publica las
     * capacidades como enlaces HATEOAS de la representación completa del claim, y esa
     * representación es la cara: ~8 s contra los ~0,12 s de la cabecera proyectada.
     * Mientras estuvieron juntas, pintar la cabecera costaba lo que costaba lo más
     * lento de las dos.
     *
     * <p>Va por el cliente paciente: es exactamente el perfil de latencia para el que
     * existe. Se proyecta {@code id} —lo mínimo— porque los enlaces llegan igual y no
     * dependen de {@code fields}.
     *
     * <p>Cuenta inexistente devuelve {@code ninguna()}, no vacío: el contrato del
     * puerto dice que sobre una cuenta que no existe no se puede hacer nada, y así
     * quien llama no tiene que distinguir dos casos que llevan a lo mismo.
     */
    @Override
    public Mono<AccionesDisponibles> consultarAccionesDisponibles(CodigoCuenta codigo) {
        var consulta  = ConstructorConsulta.igual("code", codigo.valor()).construir();
        var solicitud = SolicitudBusqueda.soloEnlaces(consulta);

        return clientePaciente.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .map(item -> traductorAcciones.aDominio(item.links()))
                .defaultIfEmpty(AccionesDisponibles.ninguna());
    }

    /** Atajo sin filtro, para los recorridos internos. No está en el puerto. */
    private Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                           int tamanoPagina, boolean incluirTotal) {
        return listarResumenLineas(codigo, cursor, tamanoPagina, incluirTotal, FiltroLineas.NINGUNO);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Dos caminos, y la frontera la pone el sistema de registro:
     * <ul>
     *   <li><b>el filtro se empuja entero</b> — una sola consulta, su total vale,
     *       nada que descartar. Es el caso de cédula, fechas, autorización y
     *       código de prestación;</li>
     *   <li><b>queda algo que él no sabe filtrar</b> —el catálogo de la
     *       prestación o el valor glosado— y entonces hay que traer de más e ir
     *       descartando hasta llenar la página. Ver {@link #paginaFiltradaAqui}.</li>
     * </ul>
     */
    @Override
    public Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                          int tamanoPagina, boolean incluirTotal,
                                                          FiltroLineas filtro) {
        var criterios = filtro == null ? FiltroLineas.NINGUNO : filtro;

        // El id se resuelve por el caché del resolutor: al paginar no se vuelve a
        // buscar la cabecera en OHI, que es trabajo repetido en cada salto de página.
        return resolutor.resolverParaCuenta(codigo, this)
                .flatMap(idCuenta -> criterios.seEmpujaEntero()
                        ? paginaDeOhi(idCuenta, cursor.ultimaReferencia(), cursor.esPrimeraPagina(),
                                      tamanoPagina, criterios, incluirTotal)
                              .flatMap(respuesta -> enriquecerResumenes(respuesta, codigo, tamanoPagina))
                        : paginaFiltradaAqui(idCuenta, codigo, cursor, tamanoPagina, criterios));
    }

    /**
     * Una página tal cual la devuelve el sistema de registro, con lo que él sabe
     * filtrar ya puesto en la consulta.
     */
    private Mono<OhiSearchResponse<OhiClaimLineItem>> paginaDeOhi(
            long idCuenta, long desdeId, boolean primeraPagina,
            int limite, FiltroLineas filtro, boolean incluirTotal) {
        return paginaDeOhi(idCuenta, desdeId, primeraPagina, limite, filtro, incluirTotal,
                           CamposOhi.RESUMEN_LINEA);
    }

    private Mono<OhiSearchResponse<OhiClaimLineItem>> paginaDeOhi(
            long idCuenta, long desdeId, boolean primeraPagina,
            int limite, FiltroLineas filtro, boolean incluirTotal, String proyeccion) {

        var constructor = ConstructorConsulta.igual("claim.id", idCuenta);
        if (!primeraPagina) constructor.yMayorQue("id", desdeId);
        aplicarLoQueSeEmpuja(constructor, filtro);

        var solicitud = SolicitudBusqueda.de(
                constructor.construir(),
                proyeccion,
                // El avance del keyset filtra por "id" (arriba): el orderBy
                // de la consulta a OHI debe coincidir con ese mismo campo o
                // la paginación pierde filas. Se probó "sequence asc" aquí:
                // con cuentas donde el id de línea y el numeroLinea no se
                // mueven en el mismo sentido (líneas reemplazadas), una página
                // reportó cursorSiguiente=null habiendo recorrido menos de un
                // 10% del total — las demás líneas quedaban permanentemente
                // por debajo del corte del cursor sin haberse mostrado nunca.
                // El orden por numeroLinea se aplica en enriquecerResumenes,
                // dentro de cada página ya traída, que es seguro porque no
                // toca el filtro de avance.
                "id asc",
                limite,
                incluirTotal);

        // Mismo cliente paciente que buscarItem(): esta cuenta demostró
        // exceder el timeout general no solo en la cabecera, sino en
        // cualquier consulta relacionada con su volumen de líneas.
        return clientePaciente.post()
                .uri("/generic/claimlines/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimLineItem>>() {})
                // OHI responde 204 sin cuerpo cuando la búsqueda no tiene
                // resultados. En cuentas cuyo total es múltiplo exacto del
                // tamaño de página (verificado con una de 1500 líneas y
                // páginas de 25), la última página sale llena y hace falta
                // pedir una más para descubrir que ya no hay: esa es la que
                // golpea este 204. Sin defaultIfEmpty, el Mono quedaba vacío
                // y el endpoint respondía 200 sin cuerpo en vez de la página
                // vacía que espera el cliente para cerrar la paginación.
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .transform(resiliencia.paraConsultaPacienteMono());
    }

    /**
     * Traduce al lenguaje de consulta de OHI los criterios que él acepta.
     *
     * <p>Los operadores están verificados contra producción el 13-oct-2026 sobre
     * una cuenta de 4.063 líneas, y las cuentas reconcilian:
     * {@code startDate.gte('2025-10-03')} da 3.774 y {@code lte} del mismo día
     * 431; los 142 de ese día se cuentan en los dos, y 3.774 + 431 − 142 = 4.063.
     *
     * <p>Se usan las variantes que ignoran mayúsculas ({@code eqic},
     * {@code likeic}) para lo que teclea el auditor: en el sistema de registro
     * las cédulas van como {@code CC43973184}, y exigirle esa caja es hacerle
     * fallar la búsqueda por un detalle que no tiene por qué conocer.
     */
    private static void aplicarLoQueSeEmpuja(ConstructorConsulta constructor, FiltroLineas filtro) {
        if (filtro.cedulaAfiliado() != null)
            constructor.yIgualSinCaja("person.code", filtro.cedulaAfiliado());
        if (filtro.desde() != null)
            constructor.yDesde("startDate", filtro.desde().toString());
        if (filtro.hasta() != null)
            constructor.yHasta("startDate", filtro.hasta().toString());
        if (filtro.codigoAutorizacion() != null)
            constructor.yEmpiezaPor("authorizationCode", filtro.codigoAutorizacion());
        if (filtro.codigoPrestacion() != null)
            constructor.yEmpiezaPor("procedure.code", filtro.codigoPrestacion());
    }

    /** Cuántas filas se le piden al sistema de registro por vuelta del recorrido. */
    private static final int LOTE_FILTRADO_LOCAL = SolicitudBusqueda.LIMITE_MAXIMO;

    /**
     * Cuántas vueltas se admiten para llenar <b>una</b> página.
     *
     * <p>Veinte lotes de 200 son 4.000 líneas, que cubren de una vez la cuenta
     * mayor medida en producción (4.063). El tope no es un límite de negocio sino
     * el freno para que un criterio muy selectivo —«glosadas por más de un
     * millón» en una cuenta sin glosas— no convierta una petición en un recorrido
     * indefinido. Al agotarse se devuelve lo encontrado con su cursor, de modo
     * que «siguiente» continúa donde se quedó: nunca se recorta en silencio.
     */
    private static final int MAXIMO_LOTES_POR_PAGINA = 20;

    /**
     * Una página cuando hay criterios que el sistema de registro no sabe aplicar.
     *
     * <p>Pide lotes grandes desde el cursor, descarta sobre la fila cruda lo que
     * no cumple y repite hasta llenar la página. Tres decisiones que importan:
     *
     * <ul>
     *   <li><b>se descarta antes de enriquecer.</b> Los dos criterios locales
     *       —catálogo y valor glosado— ya vienen en la proyección del resumen, así
     *       que la decisión no cuesta ninguna consulta; enriquecer primero
     *       significaría pedir pendientes y novedades de filas que se van a tirar;</li>
     *   <li><b>el cursor avanza por la última fila examinada</b>, no por la última
     *       que cumplió. Como se deja de mirar justo al llenar la página, son la
     *       misma, y así la página siguiente no vuelve a examinar lo ya descartado;</li>
     *   <li><b>no se publica total.</b> El del sistema de registro cuenta lo de
     *       antes de descartar: sería mayor que lo que el auditor puede ver, y un
     *       paginador construido sobre él ofrecería páginas vacías.</li>
     * </ul>
     */
    private Mono<Pagina<ResumenLinea>> paginaFiltradaAqui(long idCuenta, CodigoCuenta codigo,
                                                          Cursor cursor, int tamanoPagina,
                                                          FiltroLineas filtro) {
        var acumuladas = new java.util.ArrayList<OhiClaimLineItem>(tamanoPagina);
        var estado = new RecorridoLocal(cursor.ultimaReferencia(), cursor.esPrimeraPagina());

        return Mono.defer(() -> siguienteLote(idCuenta, filtro, estado))
                .expand(respuesta -> {
                    // Acumular aquí y no en un map aparte mantiene una sola pasada
                    // por lote; `expand` garantiza que no hay concurrencia.
                    int examinados = 0;
                    for (var item : respuesta.items()) {
                        // En cuanto la página se llena se deja de mirar, y con ello
                        // de avanzar el cursor. Seguir recorriendo el resto del lote
                        // movería `ultimoExaminado` por delante de filas que nadie
                        // llegó a evaluar, y la página siguiente empezaría después
                        // de ellas: se perderían sin aparecer en ninguna página.
                        // Medido: con el cursor avanzando hasta el final del lote,
                        // recorrer un catálogo de 1.409 líneas devolvía 484.
                        if (acumuladas.size() >= tamanoPagina) break;
                        examinados++;
                        estado.ultimoExaminado = item.id();
                        if (filtro.cumpleLoQueNoSeEmpuja(provisional(item))) {
                            acumuladas.add(item);
                        }
                    }
                    estado.lotes++;
                    // «Agotado» exige las dos cosas: que el sistema de registro
                    // haya devuelto menos de un lote —no queda nada detrás— y que
                    // se haya mirado el lote entero. Si la página se llenó a mitad
                    // del último lote, su cola sigue sin examinar: darla por
                    // agotada cerraba la paginación y se perdían esas filas.
                    // Medido: con la condición a medias, un catálogo de 1.409
                    // líneas devolvía 1.400.
                    estado.agotado = respuesta.items().size() < LOTE_FILTRADO_LOCAL
                                  && examinados == respuesta.items().size();
                    boolean suficiente = acumuladas.size() >= tamanoPagina;
                    if (estado.agotado || suficiente || estado.lotes >= MAXIMO_LOTES_POR_PAGINA) {
                        if (!estado.agotado && !suficiente) {
                            log.warn("La cuenta {} agotó los {} lotes buscando {} líneas que "
                                   + "cumplieran el filtro local; se devuelven {} y se deja "
                                   + "cursor para continuar",
                                     codigo.valor(), MAXIMO_LOTES_POR_PAGINA, tamanoPagina,
                                     acumuladas.size());
                        }
                        return Mono.empty();
                    }
                    estado.primeraPagina = false;
                    return siguienteLote(idCuenta, filtro, estado);
                })
                .then(Mono.defer(() -> enriquecerResumenes(
                        List.copyOf(acumuladas), null, codigo, tamanoPagina,
                        // El cursor NO puede salir de la regla general —«página
                        // corta, se acabó»—: aquí una página sale corta también
                        // cuando se agotaron los lotes buscando filas que
                        // cumplieran, y entonces sí quedan líneas por mirar.
                        // Cerrar la paginación ahí le diría al auditor «no hay
                        // más» sobre una cuenta a medio recorrer. Y avanza por la
                        // última fila EXAMINADA, no por la última conservada, para
                        // no volver a examinar lo ya descartado.
                        estado.agotado ? java.util.Optional.<Cursor>empty()
                                       : java.util.Optional.of(new Cursor(estado.ultimoExaminado)))));
    }


    /**
     * Cuántas líneas se recorren como mucho al calcular con qué se puede filtrar.
     *
     * <p>Mismo criterio que el recorrido de pendientes: no es un límite de
     * negocio sino el freno para que una cuenta anómala no recorra sin fin. La
     * mayor medida en producción el 13-oct-2026 tiene 4.063 líneas, así que el
     * margen es de 2,5x; al tocarlo se avisa en el log y el resumen sale con lo
     * contado hasta ahí, nunca recortado en silencio.
     */
    private static final int MAXIMO_LINEAS_RESUMIDAS = 10_000;

    /**
     * {@inheritDoc}
     *
     * <p>Recorre la cuenta en lotes de 200 con la proyección estrecha —ni
     * pendientes, ni novedades, ni nombres— y agrega sobre la marcha. Es el mismo
     * patrón del agregado de motivos pendientes y cuesta lo mismo: en la cuenta
     * mayor, unas 21 consultas.
     *
     * <p>Los nombres de los afiliados se resuelven <b>al final y de una vez</b>,
     * con los identificadores distintos que hayan salido: lo normal es que sea
     * uno, así que es una consulta más, no una por línea.
     */
    @Override
    public Mono<ResumenFiltrosLineas> resumirFiltrosDeLineas(CodigoCuenta codigo) {
        return resolutor.resolverParaCuenta(codigo, this)
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
                .flatMap(idCuenta -> {
                    var acumulador = new AcumuladorDeFiltros();
                    var estado = new RecorridoLocal(0L, true);

                    return Mono.defer(() -> paginaDeOhi(idCuenta, estado.ultimoExaminado,
                                                        estado.primeraPagina, LOTE_FILTRADO_LOCAL,
                                                        FiltroLineas.NINGUNO, false,
                                                        CamposOhi.RESUMEN_PARA_FILTROS))
                            .expand(respuesta -> {
                                for (var item : respuesta.items()) {
                                    estado.ultimoExaminado = item.id();
                                    acumulador.contar(item);
                                }
                                boolean agotado = respuesta.items().size() < LOTE_FILTRADO_LOCAL;
                                if (agotado || acumulador.lineas >= MAXIMO_LINEAS_RESUMIDAS) {
                                    if (!agotado) {
                                        log.warn("La cuenta {} superó las {} líneas al resumir sus "
                                               + "filtros; las opciones salen de las contadas",
                                                 codigo.valor(), MAXIMO_LINEAS_RESUMIDAS);
                                    }
                                    return Mono.empty();
                                }
                                estado.primeraPagina = false;
                                return paginaDeOhi(idCuenta, estado.ultimoExaminado, false,
                                                   LOTE_FILTRADO_LOCAL, FiltroLineas.NINGUNO, false,
                                                   CamposOhi.RESUMEN_PARA_FILTROS);
                            })
                            .then(Mono.defer(() ->
                                    adaptadorAfiliados.nombresPorId(acumulador.idsDeAfiliado())
                                            .map(acumulador::aResumen)));
                });
    }

    /**
     * Va contando lo que hace falta para poblar los filtros, en una sola pasada.
     *
     * <p>Agrupa por lo que el auditor va a elegir, no por lo que trae la fila: los
     * diecisiete códigos de catálogo propio de prestador que hay en producción
     * colapsan en un solo {@code PROPIO}, que es lo que se puede ofrecer como
     * opción. Ver {@link CatalogoPrestacion}.
     */
    private static final class AcumuladorDeFiltros {
        private final java.util.Map<String, int[]> porAfiliado = new java.util.LinkedHashMap<>();
        private final java.util.Map<String, String> idPorCedula = new java.util.LinkedHashMap<>();
        private final java.util.Map<CatalogoPrestacion, int[]> porCatalogo =
                new java.util.EnumMap<>(CatalogoPrestacion.class);
        private java.time.LocalDate primera;
        private java.time.LocalDate ultima;
        private java.math.BigDecimal glosaMaxima;
        private int conGlosa;
        private int lineas;

        void contar(OhiClaimLineItem item) {
            lineas++;

            var cedula = OhiReferencia.codigoDe(item.person());
            if (cedula != null) {
                porAfiliado.computeIfAbsent(cedula, c -> new int[1])[0]++;
                var id = OhiReferencia.identificadorDe(item.person());
                if (id != null) idPorCedula.putIfAbsent(cedula, id);
            }

            porCatalogo.computeIfAbsent(
                    CatalogoPrestacion.de(OhiReferencia.catalogoDe(item.procedure())),
                    c -> new int[1])[0]++;

            if (item.startDate() != null) {
                if (primera == null || item.startDate().isBefore(primera)) primera = item.startDate();
                if (ultima == null || item.startDate().isAfter(ultima))    ultima  = item.startDate();
            }

            var glosa = item.valorGlosado();
            if (glosa != null && glosa.signum() > 0) {
                conGlosa++;
                if (glosaMaxima == null || glosa.compareTo(glosaMaxima) > 0) glosaMaxima = glosa;
            }
        }

        List<String> idsDeAfiliado() {
            return List.copyOf(idPorCedula.values());
        }

        ResumenFiltrosLineas aResumen(java.util.Map<String, String> nombresPorId) {
            var afiliados = porAfiliado.entrySet().stream()
                    .map(e -> new ResumenFiltrosLineas.AfiliadoConLineas(
                            e.getKey(), nombresPorId.get(idPorCedula.get(e.getKey())),
                            e.getValue()[0]))
                    // De mayor a menor: con varios afiliados, el que más líneas
                    // aporta es por donde se empieza a auditar.
                    .sorted(java.util.Comparator
                            .comparingInt(ResumenFiltrosLineas.AfiliadoConLineas::lineas).reversed()
                            .thenComparing(ResumenFiltrosLineas.AfiliadoConLineas::cedula))
                    .toList();

            var catalogos = porCatalogo.entrySet().stream()
                    .map(e -> new ResumenFiltrosLineas.CatalogoConLineas(e.getKey(), e.getValue()[0]))
                    .sorted(java.util.Comparator
                            .comparingInt(ResumenFiltrosLineas.CatalogoConLineas::lineas).reversed())
                    .toList();

            return new ResumenFiltrosLineas(afiliados, catalogos, primera, ultima,
                                            glosaMaxima, conGlosa, lineas);
        }
    }

    /** Estado mutable del recorrido; vive solo dentro de una petición. */
    private static final class RecorridoLocal {
        private long ultimoExaminado;
        private boolean primeraPagina;
        private int lotes;
        /** La última consulta vino corta: ya no quedan líneas por examinar. */
        private boolean agotado;

        RecorridoLocal(long desde, boolean primeraPagina) {
            this.ultimoExaminado = desde;
            this.primeraPagina   = primeraPagina;
        }
    }

    private Mono<OhiSearchResponse<OhiClaimLineItem>> siguienteLote(
            long idCuenta, FiltroLineas filtro, RecorridoLocal estado) {
        return paginaDeOhi(idCuenta, estado.ultimoExaminado, estado.primeraPagina,
                           LOTE_FILTRADO_LOCAL, filtro, false);
    }

    /**
     * Traducción provisional, solo para decidir si la fila entra.
     *
     * <p>Sin afiliado de respaldo ni nombres: los criterios locales miran el
     * catálogo de la prestación y el valor glosado, que vienen en la propia fila.
     * Las que entren se vuelven a traducir ya enriquecidas. Es trabajo de CPU
     * sobre doscientas filas, no una consulta más.
     */
    private ResumenLinea provisional(OhiClaimLineItem item) {
        return traductorLinea.aResumen(item, null, java.util.Map.of());
    }

    private Mono<Pagina<ResumenLinea>> enriquecerResumenes(
            OhiSearchResponse<OhiClaimLineItem> respuesta, CodigoCuenta codigo, int tamano) {
        return enriquecerResumenes(respuesta.items() == null ? List.of() : respuesta.items(),
                                   respuesta.totalResults(), codigo, tamano);
    }

    /**
     * Completa las líneas con sus pendientes, novedades y nombres de afiliado.
     *
     * <p>Recibe la lista y el total por separado, y no la respuesta de OHI,
     * porque con un filtro que el sistema de registro no sabe aplicar las dos
     * cosas dejan de coincidir: las filas que se publican son un subconjunto de
     * las que llegaron, y el total que él devolvió cuenta las de antes de
     * descartar. En ese caso llega {@code null} y la página sale sin total.
     *
     * <p>Se enriquecen <b>solo las que van a salir</b>: el filtrado local se hace
     * antes, sobre la fila cruda, para no pagar consultas de pendientes y
     * novedades por líneas que se van a descartar.
     */
    private Mono<Pagina<ResumenLinea>> enriquecerResumenes(
            List<OhiClaimLineItem> items, Long total, CodigoCuenta codigo, int tamano) {
        return enriquecerResumenes(items, total, codigo, tamano, null);
    }

    /**
     * @param cursorImpuesto cuando no es {@code null}, sustituye al cursor que
     *                       deduciría {@link Pagina#construir}. Lo usa el
     *                       recorrido local, donde «página corta» no significa
     *                       «se acabó».
     */
    private Mono<Pagina<ResumenLinea>> enriquecerResumenes(
            List<OhiClaimLineItem> items, Long total, CodigoCuenta codigo, int tamano,
            java.util.Optional<Cursor> cursorImpuesto) {

        if (items.isEmpty()) {
            return Mono.just(cursorImpuesto == null || cursorImpuesto.isEmpty()
                    ? Pagina.vacia(tamano)
                    : new Pagina<>(List.of(), cursorImpuesto, java.util.Optional.empty(), tamano));
        }

        // Solo se piden los pendientes y novedades de las líneas de esta página.
        var idsDeLaPagina = items.stream().map(OhiClaimLineItem::id).toList();

        // Una sola consulta al padrón por página, con los afiliados distintos que
        // aparecen en ella: lo normal es que una cuenta repita el mismo en todas
        // sus líneas, así que casi siempre es un único identificador.
        var idsAfiliado = items.stream()
                .map(item -> OhiReferencia.identificadorDe(item.person()))
                .filter(java.util.Objects::nonNull)
                .distinct()
                .toList();

        return Mono.zip(adaptadorPendientes.buscarDeLineas(idsDeLaPagina),
                        adaptadorNovedades.buscarDeLineas(idsDeLaPagina),
                        afiliadoDeRespaldo(items, codigo),
                        adaptadorAfiliados.nombresPorId(idsAfiliado))
                .map(tupla -> {
                    var pendientes = tupla.getT1();
                    var novedades = tupla.getT2();
                    var afiliadoDeLaCuenta = tupla.getT3().isEmpty() ? null : tupla.getT3();
                    var nombresAfiliado = tupla.getT4();

                    var lineasResumen = items.stream().map(item -> {
                        var pendientesDeLaLinea = pendientes.stream()
                                .filter(p -> !Boolean.TRUE.equals(p.resolved())
                                          && p.claimLine() != null
                                          && p.claimLine().id().equals(item.id()))
                                .map(traductorPendiente::aDominioLinea)
                                .toList();
                        // La severidad se traduce con el diccionario y no comparándola
                        // aquí con un literal. Esta línea decía
                        // `"FATAL".equalsIgnoreCase(...)` y OHI no envía «FATAL» sino
                        // «F», así que el chip de la grilla nunca se encendía. Es la
                        // misma equivocación que había en DiccionarioOhi.SEVERIDADES,
                        // escrita dos veces en sitios distintos: por eso ahora las dos
                        // pasan por el mismo sitio, y arreglar una arregla las dos.
                        var tieneBloqueante = novedades.stream()
                                .anyMatch(n -> n.idLinea() == item.id()
                                            && n.mensaje().message() != null
                                            && DiccionarioOhi
                                                    .aSeveridad(n.mensaje().message().severity())
                                                    .frenaLaCuenta());

                        var r = traductorLinea.aResumen(item, afiliadoDeLaCuenta, nombresAfiliado);
                        return new ResumenLinea(r.referencia(), r.numeroLinea(), r.fechaInicio(),
                                r.fechaFin(), r.codigoAfiliado(), r.nombreAfiliado(),
                                r.codigoProcedimiento(), r.descripcionProcedimiento(),
                                r.catalogoProcedimiento(), r.codigoAutorizacion(),
                                r.valorAutorizado(), r.valorCubierto(), r.valorGlosado(),
                                r.conservarBeneficios(),
                                r.conservarTarifacion(), r.bloqueada(), r.reemplazada(),
                                pendientesDeLaLinea.size(), pendientesDeLaLinea,
                                tieneBloqueante, r.version());
                    }).toList();

                    // Orden de presentación pedido: numeroLinea ascendente dentro de
                    // la página. Seguro porque Pagina.construir ya no asume que el
                    // último elemento de la lista trae la referencia máxima (usa el
                    // máximo real del conjunto para calcular el cursor siguiente).
                    var ordenadas = lineasResumen.stream()
                            .sorted(java.util.Comparator.comparingInt(ResumenLinea::numeroLinea))
                            .toList();

                    var pagina = Pagina.construir(ordenadas, tamano, total,
                                                  r -> r.referencia().valor());
                    return cursorImpuesto == null
                            ? pagina
                            : new Pagina<>(pagina.elementos(), cursorImpuesto,
                                           pagina.totalRegistros(), pagina.tamanoPagina());
                });
    }

    /**
     * Las tres referencias de la cabecera que {@link #buscarItem} no puede traer:
     * el afiliado y los dos prestadores de facturación.
     *
     * <p>{@code SolicitudBusqueda.cabecera(...)} activa
     * {@code excludereferenceresources=true} para no arrastrar {@code claimLineList}
     * completa en cuentas grandes. Se confirmó contra OHI que ese parámetro no
     * distingue entre listas y referencias simples: descarta {@code person},
     * {@code claimantProvider} y {@code paymentReceiverProvider} igual, aunque
     * estén pedidos en {@code fields}. La única forma de obtenerlos es una segunda
     * consulta sin esa exclusión — liviana, porque solo pide estos tres campos.
     */
    private record ReferenciasCabecera(String afiliado, String prestadorFacturacion, String pagarAPrestador) {
        static final ReferenciasCabecera VACIA = new ReferenciasCabecera("", "", "");
    }

    /** {@code person.id}: ver la nota de {@link CamposOhi#RESUMEN_LINEA}. */
    private static final String CAMPOS_REFERENCIAS_CABECERA =
            "person.id,claimantProvider,paymentReceiverProvider";

    /**
     * Afiliado de la cabecera, y solo cuando hace falta.
     *
     * <p>Si todas las líneas de la página traen el suyo no se consulta la cuenta:
     * es una llamada a OHI que se evita en el caso habitual. La cadena vacía hace
     * de «sin dato», porque {@code Mono.zip} no admite nulos.
     */
    private Mono<String> afiliadoDeRespaldo(List<OhiClaimLineItem> items, CodigoCuenta codigo) {
        boolean algunaSinAfiliado = items.stream().anyMatch(i -> i.person() == null);
        return algunaSinAfiliado
                ? referenciasDeLaCabecera(codigo).map(ReferenciasCabecera::afiliado)
                : Mono.just("");
    }

    /**
     * Las tres referencias de la cabecera. Ver {@link ReferenciasCabecera}.
     *
     * <p>A diferencia del afiliado (que a veces ya viene en la línea), el
     * prestador de facturación nunca lo trae {@link #buscarItem}: aquí se pide
     * siempre que se necesite, no condicionalmente.
     */
    private Mono<ReferenciasCabecera> referenciasDeLaCabecera(CodigoCuenta codigo) {
        var consulta = ConstructorConsulta.igual("code", codigo.valor()).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CAMPOS_REFERENCIAS_CABECERA, null, 1, false);

        return clientePaciente.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .map(cuenta -> new ReferenciasCabecera(
                        vacioSiNulo(OhiReferencia.codigoDe(cuenta.person())),
                        vacioSiNulo(OhiReferencia.codigoDe(cuenta.claimantProvider())),
                        vacioSiNulo(OhiReferencia.codigoDe(cuenta.paymentReceiverProvider()))))
                .defaultIfEmpty(ReferenciasCabecera.VACIA);
    }

    private static String vacioSiNulo(String valor) {
        return valor == null ? "" : valor;
    }

    /** Inverso de {@link #vacioSiNulo}: la cadena vacía de "sin dato" vuelve a ser {@code null}. */
    private static String nuloSiVacio(String valor) {
        return (valor == null || valor.isEmpty()) ? null : valor;
    }

    @Override
    public Mono<LineaCuenta> buscarDetalleLinea(CodigoCuenta codigo, ReferenciaLinea referencia) {
        var consulta = ConstructorConsulta.igual("id", referencia.valor()).construir();
        var solicitud = SolicitudBusqueda.unica(consulta, CamposOhi.DETALLE_LINEA);

        return clientePaciente.post()
                .uri("/generic/claimlines/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimLineItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .flatMap(item ->
                        Mono.zip(adaptadorPendientes.buscarDeLinea(item.id()),
                                 adaptadorNovedades.buscarDeLinea(item.id()),
                                 afiliadoDeRespaldoDeLinea(item, codigo),
                                 adaptadorAfiliados.nombresPorId(
                                         java.util.stream.Stream
                                                 .ofNullable(OhiReferencia.identificadorDe(item.person()))
                                                 .toList()),
                                 adaptadorPrestadores.nombresPorCodigo(
                                         java.util.stream.Stream
                                                 .ofNullable(OhiReferencia.codigoDe(item.serviceProvider()))
                                                 .toList()),
                                 clausulasDeTarifa(item.id()))
                        .map(tupla -> traductorLinea.aDetalle(
                                item, codigo,
                                tupla.getT3().isEmpty() ? null : tupla.getT3(),
                                tupla.getT2(), tupla.getT1(),
                                tupla.getT4(), tupla.getT5(), tupla.getT6()))
                );
    }

    /**
     * Cláusulas de tarifación de la línea, de donde sale el valor convenido.
     *
     * <p>Es una consulta aparte —la tarifa pactada no es un campo de la línea—
     * y solo se hace al abrir el detalle, nunca al pintar la grilla. Si falla,
     * se devuelve vacío: el resto del detalle vale igual sin ella.
     */
    private Mono<java.util.List<OhiPricingClause>> clausulasDeTarifa(long idLinea) {
        var consulta = ConstructorConsulta.igual("claimLine.id", idLinea).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.CLAUSULA_TARIFA, null, 20, false);

        return webClient.post()
                .uri("/generic/claimlineproviderpricingclauses/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPricingClause>>() {})
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .transform(resiliencia.paraConsultasMono())
                .map(r -> r.isEmpty() ? java.util.List.<OhiPricingClause>of() : r.items())
                .onErrorResume(e -> Mono.just(java.util.List.of()));
    }

    /** Igual que {@link #afiliadoDeRespaldo}, para una sola línea. */
    private Mono<String> afiliadoDeRespaldoDeLinea(OhiClaimLineItem linea, CodigoCuenta codigo) {
        return linea.person() != null
                ? Mono.just("")
                : referenciasDeLaCabecera(codigo).map(ReferenciasCabecera::afiliado);
    }

    @Override
    public Flux<ResumenLinea> recorrerTodasLasLineas(CodigoCuenta codigo, int tamanoPagina) {
        return listarResumenLineas(codigo, Cursor.PRIMERA_PAGINA, tamanoPagina, false)
                .expand(pagina -> pagina.cursorSiguiente()
                        .map(cursor -> listarResumenLineas(codigo, cursor, tamanoPagina, false))
                        .orElse(Mono.empty()))
                .flatMapIterable(Pagina::elementos);
    }

    @Override
    public Mono<EstadoProceso> consultarEstadoProceso(CodigoCuenta codigo) {
        return resolutor.resolverParaCuenta(codigo, this)
                .flatMap(id -> webClient.get()
                        // OHI publica este recurso fuera de /generic; así lo declara el rel claim:status
                        .uri("/claims/{id}/status", id)
                        .retrieve()
                        .onStatus(s -> s.isError(), traductorErrores::traducir)
                        .bodyToMono(OhiStatusResponse.class)
                        .transform(resiliencia.paraConsultasMono())
                        .map(traductorProceso::aDominio));
    }
}
