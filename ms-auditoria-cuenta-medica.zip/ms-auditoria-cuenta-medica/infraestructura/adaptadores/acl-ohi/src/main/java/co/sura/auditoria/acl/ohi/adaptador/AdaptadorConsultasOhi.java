package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiClaimItem;
import co.sura.auditoria.acl.ohi.externo.OhiClaimLineItem;
import co.sura.auditoria.acl.ohi.externo.OhiPricingClause;
import co.sura.auditoria.acl.ohi.externo.OhiReferencia;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.externo.OhiStatusResponse;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorAcciones;
import co.sura.auditoria.acl.ohi.traductor.TraductorCuenta;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorEstadoProceso;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.acl.ohi.traductor.TraductorPendiente;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorConsultasOhi implements PuertoConsultaCuentas, ResolutorIdentidadOhi.BuscadorPorCodigo {

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final TraductorCuenta traductorCuenta;
    private final TraductorLinea traductorLinea;
    private final TraductorPendiente traductorPendiente;
    private final TraductorEstadoProceso traductorProceso;
    private final AdaptadorPendientesOhi adaptadorPendientes;
    private final AdaptadorNovedadesOhi adaptadorNovedades;
    private final AdaptadorAfiliadosOhi adaptadorAfiliados;
    private final AdaptadorPrestadoresOhi adaptadorPrestadores;
    private final ResolutorIdentidadOhi resolutor;
    private final WebClient clientePaciente;
    private final TraductorAcciones traductorAcciones;

    public AdaptadorConsultasOhi(WebClient webClient,
                                 ConfiguracionResiliencia resiliencia,
                                 TraductorErrores traductorErrores,
                                 TraductorCuenta traductorCuenta,
                                 TraductorLinea traductorLinea,
                                 TraductorPendiente traductorPendiente,
                                 TraductorEstadoProceso traductorProceso,
                                 AdaptadorPendientesOhi adaptadorPendientes,
                                 AdaptadorNovedadesOhi adaptadorNovedades,
                                 AdaptadorAfiliadosOhi adaptadorAfiliados,
                                 AdaptadorPrestadoresOhi adaptadorPrestadores,
                                 ResolutorIdentidadOhi resolutor,
                                 TraductorAcciones traductorAcciones,
                                 @org.springframework.beans.factory.annotation.Qualifier(
                                         co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
                                 WebClient clientePaciente) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.traductorCuenta = traductorCuenta;
        this.traductorLinea = traductorLinea;
        this.traductorPendiente = traductorPendiente;
        this.traductorProceso = traductorProceso;
        this.adaptadorPendientes = adaptadorPendientes;
        this.adaptadorNovedades = adaptadorNovedades;
        this.adaptadorAfiliados = adaptadorAfiliados;
        this.adaptadorPrestadores = adaptadorPrestadores;
        this.resolutor = resolutor;
        this.clientePaciente = clientePaciente;
        this.traductorAcciones = traductorAcciones;
    }

    // ── ResolutorIdentidadOhi.BuscadorPorCodigo ──────────────────────────────

    @Override
    public Mono<Long> buscar(String codigoNegocio) {
        return buscarItem(codigoNegocio).map(OhiClaimItem::id);
    }

    /**
     * Cabecera de la cuenta por su código de negocio.
     *
     * <p>Se pide con la representación de solo cabecera: OHI adjunta la cuenta
     * entera si no se le indica lo contrario, y de una cuenta grande eso son
     * cientos de kilobytes de líneas que aquí no se usan.
     */
    /**
     * Cabecera de la cuenta por su código de negocio.
     *
     * <p>Usa el cliente de operaciones largas, no el general: el payload de
     * salida es pequeño ({@code excludereferenceresources=true}), pero OHI debe
     * resolver igual todas las relaciones de la cuenta antes de excluirlas, y en
     * cuentas con mucho volumen relacionado eso excede el timeout de una lectura
     * normal. Ver {@link PropiedadesOhi.Timeouts#resolucionPendiente()}.
     */
    private Mono<OhiClaimItem> buscarItem(String codigoNegocio) {
        var consulta = ConstructorConsulta.igual("code", codigoNegocio).construir();
        var solicitud = SolicitudBusqueda.cabecera(consulta, CamposOhi.CABECERA_CUENTA);

        return webClient.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                // Sin retry: ver ConfiguracionResiliencia.paraConsultaPacienteMono().
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()));
    }

    // ── PuertoConsultaCuentas ────────────────────────────────────────────────

    @Override
    public Mono<CuentaMedica> buscarPorCodigo(CodigoCuenta codigo) {
        return buscarItem(codigo.valor())
                // Si la cuenta existe, se solicitan sus pendientes de cabecera y las
                // referencias (prestadores) que buscarItem() no puede traer — ver
                // referenciasDeLaCabecera().
                .flatMap(item -> Mono.zip(
                                adaptadorPendientes.buscarDeCabecera(item.id()),
                                referenciasDeLaCabecera(codigo))
                        .map(tupla -> {
                            var referencias = tupla.getT2();
                            return traductorCuenta.aDominio(item, tupla.getT1(),
                                    nuloSiVacio(referencias.prestadorFacturacion()),
                                    nuloSiVacio(referencias.pagarAPrestador()));
                        }));
    }

    /**
     * Acciones disponibles, en su propia consulta.
     *
     * <p>Aislada de {@link #buscarPorCodigo} a propósito. OHI solo publica las
     * capacidades como enlaces HATEOAS de la representación completa del claim, y esa
     * representación es la cara: ~8 s contra los ~0,12 s de la cabecera proyectada.
     * Mientras estuvieron juntas, pintar la cabecera costaba lo que costaba lo más
     * lento de las dos.
     *
     * <p>Va por el cliente paciente: es exactamente el perfil de latencia para el que
     * existe. Se proyecta {@code id} —lo mínimo— porque los enlaces llegan igual y no
     * dependen de {@code fields}.
     *
     * <p>Cuenta inexistente devuelve {@code ninguna()}, no vacío: el contrato del
     * puerto dice que sobre una cuenta que no existe no se puede hacer nada, y así
     * quien llama no tiene que distinguir dos casos que llevan a lo mismo.
     */
    @Override
    public Mono<AccionesDisponibles> consultarAccionesDisponibles(CodigoCuenta codigo) {
        var consulta  = ConstructorConsulta.igual("code", codigo.valor()).construir();
        var solicitud = SolicitudBusqueda.soloEnlaces(consulta);

        return clientePaciente.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .map(item -> traductorAcciones.aDominio(item.links()))
                .defaultIfEmpty(AccionesDisponibles.ninguna());
    }

    @Override
    public Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                          int tamanoPagina, boolean incluirTotal) {
        // El id se resuelve por el caché del resolutor: al paginar no se vuelve a
        // buscar la cabecera en OHI, que es trabajo repetido en cada salto de página.
        return resolutor.resolverParaCuenta(codigo, this)
                .flatMap(idCuenta -> {
                    var constructor = ConstructorConsulta.igual("claim.id", idCuenta);
                    if (!cursor.esPrimeraPagina()) {
                        constructor.yMayorQue("id", cursor.ultimaReferencia());
                    }

                    var solicitud = SolicitudBusqueda.de(
                            constructor.construir(),
                            CamposOhi.RESUMEN_LINEA,
                            // El avance del keyset filtra por "id" (arriba): el orderBy
                            // de la consulta a OHI debe coincidir con ese mismo campo o
                            // la paginación pierde filas. Se probó "sequence asc" aquí:
                            // con cuentas donde el id de línea y el numeroLinea no se
                            // mueven en el mismo sentido (líneas reemplazadas), una página
                            // reportó cursorSiguiente=null habiendo recorrido menos de un
                            // 10% del total — las demás líneas quedaban permanentemente
                            // por debajo del corte del cursor sin haberse mostrado nunca.
                            // El orden por numeroLinea se aplica en enriquecerResumenes,
                            // dentro de cada página ya traída, que es seguro porque no
                            // toca el filtro de avance.
                            "id asc",
                            tamanoPagina,
                            incluirTotal);

                    // Mismo cliente paciente que buscarItem(): esta cuenta demostró
                    // exceder el timeout general no solo en la cabecera, sino en
                    // cualquier consulta relacionada con su volumen de líneas.
                    return clientePaciente.post()
                            .uri("/generic/claimlines/search")
                            .bodyValue(solicitud)
                            .retrieve()
                            .onStatus(s -> s.isError(), traductorErrores::traducir)
                            .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimLineItem>>() {})
                            // OHI responde 204 sin cuerpo cuando la búsqueda no tiene
                            // resultados. En cuentas cuyo total es múltiplo exacto del
                            // tamaño de página (verificado con una de 1500 líneas y
                            // páginas de 25), la última página sale llena y hace falta
                            // pedir una más para descubrir que ya no hay: esa es la que
                            // golpea este 204. Sin defaultIfEmpty, el Mono quedaba vacío
                            // y el endpoint respondía 200 sin cuerpo en vez de la página
                            // vacía que espera el cliente para cerrar la paginación.
                            .defaultIfEmpty(OhiSearchResponse.vacio())
                            .transform(resiliencia.paraConsultaPacienteMono())
                            .flatMap(respuesta -> enriquecerResumenes(respuesta, codigo, tamanoPagina));
                });
    }

    private Mono<Pagina<ResumenLinea>> enriquecerResumenes(
            OhiSearchResponse<OhiClaimLineItem> respuesta, CodigoCuenta codigo, int tamano) {

        if (respuesta.isEmpty()) return Mono.just(Pagina.vacia(tamano));

        // Solo se piden los pendientes y novedades de las líneas de esta página.
        var idsDeLaPagina = respuesta.items().stream().map(OhiClaimLineItem::id).toList();

        // Una sola consulta al padrón por página, con los afiliados distintos que
        // aparecen en ella: lo normal es que una cuenta repita el mismo en todas
        // sus líneas, así que casi siempre es un único identificador.
        var idsAfiliado = respuesta.items().stream()
                .map(item -> OhiReferencia.identificadorDe(item.person()))
                .filter(java.util.Objects::nonNull)
                .distinct()
                .toList();

        return Mono.zip(adaptadorPendientes.buscarDeLineas(idsDeLaPagina),
                        adaptadorNovedades.buscarDeLineas(idsDeLaPagina),
                        afiliadoDeRespaldo(respuesta, codigo),
                        adaptadorAfiliados.nombresPorId(idsAfiliado))
                .map(tupla -> {
                    var pendientes = tupla.getT1();
                    var novedades = tupla.getT2();
                    var afiliadoDeLaCuenta = tupla.getT3().isEmpty() ? null : tupla.getT3();
                    var nombresAfiliado = tupla.getT4();

                    var lineasResumen = respuesta.items().stream().map(item -> {
                        var pendientesDeLaLinea = pendientes.stream()
                                .filter(p -> !Boolean.TRUE.equals(p.resolved())
                                          && p.claimLine() != null
                                          && p.claimLine().id().equals(item.id()))
                                .map(traductorPendiente::aDominioLinea)
                                .toList();
                        var tieneBloqueante = novedades.stream()
                                .anyMatch(n -> n.idLinea() == item.id()
                                            && "FATAL".equalsIgnoreCase(n.mensaje().message().severity()));

                        var r = traductorLinea.aResumen(item, afiliadoDeLaCuenta, nombresAfiliado);
                        return new ResumenLinea(r.referencia(), r.numeroLinea(), r.fechaInicio(),
                                r.fechaFin(), r.codigoAfiliado(), r.nombreAfiliado(),
                                r.codigoProcedimiento(), r.descripcionProcedimiento(),
                                r.catalogoProcedimiento(),
                                r.valorAutorizado(), r.valorCubierto(), r.conservarBeneficios(),
                                r.conservarTarifacion(), r.bloqueada(), r.reemplazada(),
                                pendientesDeLaLinea.size(), pendientesDeLaLinea,
                                tieneBloqueante, r.version());
                    }).toList();

                    // Orden de presentación pedido: numeroLinea ascendente dentro de
                    // la página. Seguro porque Pagina.construir ya no asume que el
                    // último elemento de la lista trae la referencia máxima (usa el
                    // máximo real del conjunto para calcular el cursor siguiente).
                    var ordenadas = lineasResumen.stream()
                            .sorted(java.util.Comparator.comparingInt(ResumenLinea::numeroLinea))
                            .toList();

                    return Pagina.construir(ordenadas, tamano, respuesta.totalResults(),
                                            r -> r.referencia().valor());
                });
    }

    /**
     * Las tres referencias de la cabecera que {@link #buscarItem} no puede traer:
     * el afiliado y los dos prestadores de facturación.
     *
     * <p>{@code SolicitudBusqueda.cabecera(...)} activa
     * {@code excludereferenceresources=true} para no arrastrar {@code claimLineList}
     * completa en cuentas grandes. Se confirmó contra OHI que ese parámetro no
     * distingue entre listas y referencias simples: descarta {@code person},
     * {@code claimantProvider} y {@code paymentReceiverProvider} igual, aunque
     * estén pedidos en {@code fields}. La única forma de obtenerlos es una segunda
     * consulta sin esa exclusión — liviana, porque solo pide estos tres campos.
     */
    private record ReferenciasCabecera(String afiliado, String prestadorFacturacion, String pagarAPrestador) {
        static final ReferenciasCabecera VACIA = new ReferenciasCabecera("", "", "");
    }

    /** {@code person.id}: ver la nota de {@link CamposOhi#RESUMEN_LINEA}. */
    private static final String CAMPOS_REFERENCIAS_CABECERA =
            "person.id,claimantProvider,paymentReceiverProvider";

    /**
     * Afiliado de la cabecera, y solo cuando hace falta.
     *
     * <p>Si todas las líneas de la página traen el suyo no se consulta la cuenta:
     * es una llamada a OHI que se evita en el caso habitual. La cadena vacía hace
     * de «sin dato», porque {@code Mono.zip} no admite nulos.
     */
    private Mono<String> afiliadoDeRespaldo(OhiSearchResponse<OhiClaimLineItem> respuesta,
                                            CodigoCuenta codigo) {
        boolean algunaSinAfiliado = respuesta.items().stream().anyMatch(i -> i.person() == null);
        return algunaSinAfiliado
                ? referenciasDeLaCabecera(codigo).map(ReferenciasCabecera::afiliado)
                : Mono.just("");
    }

    /**
     * Las tres referencias de la cabecera. Ver {@link ReferenciasCabecera}.
     *
     * <p>A diferencia del afiliado (que a veces ya viene en la línea), el
     * prestador de facturación nunca lo trae {@link #buscarItem}: aquí se pide
     * siempre que se necesite, no condicionalmente.
     */
    private Mono<ReferenciasCabecera> referenciasDeLaCabecera(CodigoCuenta codigo) {
        var consulta = ConstructorConsulta.igual("code", codigo.valor()).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CAMPOS_REFERENCIAS_CABECERA, null, 1, false);

        return clientePaciente.post()
                .uri("/generic/claims/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .map(cuenta -> new ReferenciasCabecera(
                        vacioSiNulo(OhiReferencia.codigoDe(cuenta.person())),
                        vacioSiNulo(OhiReferencia.codigoDe(cuenta.claimantProvider())),
                        vacioSiNulo(OhiReferencia.codigoDe(cuenta.paymentReceiverProvider()))))
                .defaultIfEmpty(ReferenciasCabecera.VACIA);
    }

    private static String vacioSiNulo(String valor) {
        return valor == null ? "" : valor;
    }

    /** Inverso de {@link #vacioSiNulo}: la cadena vacía de "sin dato" vuelve a ser {@code null}. */
    private static String nuloSiVacio(String valor) {
        return (valor == null || valor.isEmpty()) ? null : valor;
    }

    @Override
    public Mono<LineaCuenta> buscarDetalleLinea(CodigoCuenta codigo, ReferenciaLinea referencia) {
        var consulta = ConstructorConsulta.igual("id", referencia.valor()).construir();
        var solicitud = SolicitudBusqueda.unica(consulta, CamposOhi.DETALLE_LINEA);

        return clientePaciente.post()
                .uri("/generic/claimlines/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiClaimLineItem>>() {})
                .transform(resiliencia.paraConsultaPacienteMono())
                .flatMap(r -> r.first().map(Mono::just).orElse(Mono.empty()))
                .flatMap(item ->
                        Mono.zip(adaptadorPendientes.buscarDeLinea(item.id()),
                                 adaptadorNovedades.buscarDeLinea(item.id()),
                                 afiliadoDeRespaldoDeLinea(item, codigo),
                                 adaptadorAfiliados.nombresPorId(
                                         java.util.stream.Stream
                                                 .ofNullable(OhiReferencia.identificadorDe(item.person()))
                                                 .toList()),
                                 adaptadorPrestadores.nombresPorCodigo(
                                         java.util.stream.Stream
                                                 .ofNullable(OhiReferencia.codigoDe(item.serviceProvider()))
                                                 .toList()),
                                 clausulasDeTarifa(item.id()))
                        .map(tupla -> traductorLinea.aDetalle(
                                item, codigo,
                                tupla.getT3().isEmpty() ? null : tupla.getT3(),
                                tupla.getT2(), tupla.getT1(),
                                tupla.getT4(), tupla.getT5(), tupla.getT6()))
                );
    }

    /**
     * Cláusulas de tarifación de la línea, de donde sale el valor convenido.
     *
     * <p>Es una consulta aparte —la tarifa pactada no es un campo de la línea—
     * y solo se hace al abrir el detalle, nunca al pintar la grilla. Si falla,
     * se devuelve vacío: el resto del detalle vale igual sin ella.
     */
    private Mono<java.util.List<OhiPricingClause>> clausulasDeTarifa(long idLinea) {
        var consulta = ConstructorConsulta.igual("claimLine.id", idLinea).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.CLAUSULA_TARIFA, null, 20, false);

        return webClient.post()
                .uri("/generic/claimlineproviderpricingclauses/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPricingClause>>() {})
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .transform(resiliencia.paraConsultasMono())
                .map(r -> r.isEmpty() ? java.util.List.<OhiPricingClause>of() : r.items())
                .onErrorResume(e -> Mono.just(java.util.List.of()));
    }

    /** Igual que {@link #afiliadoDeRespaldo}, para una sola línea. */
    private Mono<String> afiliadoDeRespaldoDeLinea(OhiClaimLineItem linea, CodigoCuenta codigo) {
        return linea.person() != null
                ? Mono.just("")
                : referenciasDeLaCabecera(codigo).map(ReferenciasCabecera::afiliado);
    }

    @Override
    public Flux<ResumenLinea> recorrerTodasLasLineas(CodigoCuenta codigo, int tamanoPagina) {
        return listarResumenLineas(codigo, Cursor.PRIMERA_PAGINA, tamanoPagina, false)
                .expand(pagina -> pagina.cursorSiguiente()
                        .map(cursor -> listarResumenLineas(codigo, cursor, tamanoPagina, false))
                        .orElse(Mono.empty()))
                .flatMapIterable(Pagina::elementos);
    }

    @Override
    public Mono<EstadoProceso> consultarEstadoProceso(CodigoCuenta codigo) {
        return resolutor.resolverParaCuenta(codigo, this)
                .flatMap(id -> webClient.get()
                        // OHI publica este recurso fuera de /generic; así lo declara el rel claim:status
                        .uri("/claims/{id}/status", id)
                        .retrieve()
                        .onStatus(s -> s.isError(), traductorErrores::traducir)
                        .bodyToMono(OhiStatusResponse.class)
                        .transform(resiliencia.paraConsultasMono())
                        .map(traductorProceso::aDominio));
    }
}
