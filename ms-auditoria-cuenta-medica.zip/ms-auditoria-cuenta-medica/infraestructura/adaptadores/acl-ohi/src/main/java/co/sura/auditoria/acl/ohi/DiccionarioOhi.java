package co.sura.auditoria.acl.ohi;

import co.sura.auditoria.modelo.cuenta.*;

import java.util.Map;
import java.util.Optional;

/**
 * Diccionario de traducción entre el lenguaje del dominio (español) y el
 * vocabulario de Oracle Health Insurance (inglés).
 *
 * <p>Esta clase es la <b>ÚNICA</b> autorizada a contener literales del vocabulario externo.
 * Cualquier término de OHI que aparezca fuera de este paquete es un defecto de arquitectura
 * detectado por la prueba {@code PruebaArquitecturaTest}.
 *
 * <p>Referencia: §9.1 del documento de arquitectura v2.
 */
public final class DiccionarioOhi {

    // ── Estados ────────────────────────────────────────────────────────────────
    private static final Map<String, EstadoCuenta> ESTADOS = Map.ofEntries(
        Map.entry("INITIAL",                      EstadoCuenta.INICIAL),
        Map.entry("ENTRY",                        EstadoCuenta.DIGITACION),
        Map.entry("CHANGE",                       EstadoCuenta.MODIFICACION),
        Map.entry("MANUAL PRICING",               EstadoCuenta.TARIFACION_MANUAL),
        Map.entry("MANUAL BENEFITS",              EstadoCuenta.BENEFICIOS_MANUALES),
        Map.entry("MANUAL ADJUDICATION",          EstadoCuenta.ADJUDICACION_MANUAL),
        Map.entry("MANUAL PRICING ADJUDICATION",  EstadoCuenta.TARIFACION_ADJUDICACION_MANUAL),
        Map.entry("PRICING DONE",                 EstadoCuenta.TARIFACION_COMPLETA),
        Map.entry("BENEFITS DONE",                EstadoCuenta.BENEFICIOS_COMPLETOS),
        Map.entry("ADJUDICATION DONE",            EstadoCuenta.ADJUDICACION_COMPLETA),
        Map.entry("PRICING ADJUDICATION DONE",    EstadoCuenta.TARIFACION_ADJUDICACION_COMPLETA),
        Map.entry("PRICING FINALIZED",            EstadoCuenta.TARIFACION_FINALIZADA),
        Map.entry("SENT OUT FOR PREPROCESSING",   EstadoCuenta.ENVIADA_A_PREPROCESO),
        Map.entry("SENT OUT FOR PRICING",         EstadoCuenta.ENVIADA_A_TARIFACION),
        Map.entry("FINALIZED",                    EstadoCuenta.FINALIZADA),
        // Los dos que faltaban y caían en DESCONOCIDO. «IN PROCESS» son 137
        // cuentas en el entorno de pruebas y 38 en producción; «CANCELLED» es
        // el estado en el que deja una anulación, y es terminal.
        Map.entry("IN PROCESS",                   EstadoCuenta.EN_PROCESO),
        Map.entry("CANCELLED",                    EstadoCuenta.ANULADA),
        Map.entry("CANCELED",                     EstadoCuenta.ANULADA));

    // ── Acciones (link relations de OHI) ────────────────────────────────────────
    private static final Map<String, AccionCuenta> ACCIONES = Map.ofEntries(
        Map.entry("claim:submit",               AccionCuenta.ENVIAR),
        Map.entry("claim:status",               AccionCuenta.SEGUIR_PROCESO),
        Map.entry("claim:resolvepend",          AccionCuenta.RESOLVER_PENDIENTE),
        Map.entry("claim:resolveclaimlinepend", AccionCuenta.RESOLVER_PENDIENTE_LINEA),
        Map.entry("claim:tochange",             AccionCuenta.DEVOLVER_A_MODIFICACION),
        Map.entry("claim:tomanualbenefits",     AccionCuenta.DEVOLVER_A_BENEFICIOS_MANUALES),
        Map.entry("claim:tomanualpricing",      AccionCuenta.DEVOLVER_A_TARIFACION_MANUAL),
        Map.entry("claim:unfinalize",           AccionCuenta.REVERTIR_FINALIZACION),
        Map.entry("claim:unlocklines",          AccionCuenta.DESBLOQUEAR_LINEAS),
        Map.entry("claim:undolinereplacements", AccionCuenta.DESHACER_REEMPLAZOS),
        Map.entry("claim:cancel",               AccionCuenta.ANULAR));

    // ── Relación inversa AccionCuenta → rel externo ──────────────────────────────
    private static final Map<AccionCuenta, String> RELACIONES = Map.ofEntries(
        Map.entry(AccionCuenta.ENVIAR,                       "claim:submit"),
        Map.entry(AccionCuenta.SEGUIR_PROCESO,               "claim:status"),
        Map.entry(AccionCuenta.RESOLVER_PENDIENTE,           "claim:resolvepend"),
        Map.entry(AccionCuenta.RESOLVER_PENDIENTE_LINEA,     "claim:resolveclaimlinepend"),
        Map.entry(AccionCuenta.DEVOLVER_A_MODIFICACION,      "claim:tochange"),
        Map.entry(AccionCuenta.DEVOLVER_A_BENEFICIOS_MANUALES, "claim:tomanualbenefits"),
        Map.entry(AccionCuenta.DEVOLVER_A_TARIFACION_MANUAL, "claim:tomanualpricing"),
        Map.entry(AccionCuenta.REVERTIR_FINALIZACION,        "claim:unfinalize"),
        Map.entry(AccionCuenta.DESBLOQUEAR_LINEAS,           "claim:unlocklines"),
        Map.entry(AccionCuenta.DESHACER_REEMPLAZOS,          "claim:undolinereplacements"),
        Map.entry(AccionCuenta.ANULAR,                       "claim:cancel"));

    // ── Severidades ──────────────────────────────────────────────────────────────
    //
    // OHI publica `severity` como un enum de **un carácter**: la definición de
    // /generic/messages lo declara `maxLength: 1` con los valores ["I","F","D"] y
    // los significados ["Informativo","Fatal","Negar"].
    //
    // Antes aquí ponía "INFO"/"WARNING"/"FATAL", que no es lo que llega nunca. El
    // efecto no era un error visible sino el peor silencio posible: `aSeveridad`
    // caía siempre en DESCONOCIDA, así que `tieneNovedadBloqueante()` devolvía
    // `false` para todas las líneas y el chip «⚠ Bloqueada» de la grilla no se
    // encendía jamás. Medido contra UAT, de los 631 mensajes que un auditor puede
    // elegir hay 201 fatales y 2 de negación: un tercio del catálogo frena la
    // cuenta y la pantalla lo daba todo por bueno.
    //
    // No hay cuarto valor: "WARNING" no existe en OHI, y por eso
    // Severidad.ADVERTENCIA se queda sin origen real (ver su javadoc).
    private static final Map<String, Severidad> SEVERIDADES = Map.of(
        "I", Severidad.INFORMATIVA,
        "F", Severidad.BLOQUEANTE,
        "D", Severidad.NEGACION);

    // ── Avance del proceso ───────────────────────────────────────────────────────
    private static final Map<String, EstadoProceso.Avance> AVANCES = Map.of(
        "notStarted", EstadoProceso.Avance.NO_INICIADO,
        "processing", EstadoProceso.Avance.EN_PROCESO,
        "succeeded",  EstadoProceso.Avance.EXITOSO,
        "failed",     EstadoProceso.Avance.FALLIDO);

    // ── Métodos de traducción ────────────────────────────────────────────────────

    public static EstadoCuenta aEstado(String externo) {
        if (externo == null) return EstadoCuenta.DESCONOCIDO;
        return ESTADOS.getOrDefault(externo.trim().toUpperCase(), EstadoCuenta.DESCONOCIDO);
    }

    public static Optional<AccionCuenta> aAccion(String relacion) {
        return Optional.ofNullable(ACCIONES.get(relacion));
    }

    /**
     * El nombre de la operación en la ruta, para las acciones que se ejecutan.
     *
     * <p>Va aparte de {@link #RELACIONES} aunque se parezca: aquello son los
     * enlaces que OHI publica —{@code claim:cancel}— y esto el último segmento
     * de la URL —{@code cancel}—. Coinciden hoy quitando el prefijo, pero son
     * dos vocabularios suyos distintos y unirlos ataría la ruta al nombre del
     * enlace.
     *
     * <p>No están las once: {@code ENVIAR} tiene su propio método porque es
     * asíncrona, {@code SEGUIR_PROCESO} es de lectura y las dos de pendientes
     * las resuelve {@code AdaptadorPendientesOhi}, que necesita además el
     * identificador del motivo.
     */
    private static final Map<AccionCuenta, String> OPERACIONES = Map.of(
        AccionCuenta.ANULAR,                         "cancel",
        AccionCuenta.REVERTIR_FINALIZACION,          "unfinalize",
        AccionCuenta.DEVOLVER_A_MODIFICACION,        "tochange",
        AccionCuenta.DEVOLVER_A_BENEFICIOS_MANUALES, "tomanualbenefits",
        AccionCuenta.DEVOLVER_A_TARIFACION_MANUAL,   "tomanualpricing",
        AccionCuenta.DESBLOQUEAR_LINEAS,             "unlocklines",
        AccionCuenta.DESHACER_REEMPLAZOS,            "undolinereplacements");

    /** @throws IllegalArgumentException si la acción no se ejecuta por esta vía. */
    public static String operacionDe(AccionCuenta accion) {
        var operacion = OPERACIONES.get(accion);
        if (operacion == null) {
            throw new IllegalArgumentException(
                    "%s no se ejecuta por la vía de las acciones de la cuenta".formatted(accion));
        }
        return operacion;
    }

    /** @return si la acción se puede ejecutar con el comando genérico de acciones. */
    public static boolean seEjecutaComoAccion(AccionCuenta accion) {
        return OPERACIONES.containsKey(accion);
    }

    /**
     * El ámbito del motivo, tal como lo publica el sistema de registro: un solo
     * carácter en un código dinámico.
     */
    public static MotivoDesfinalizacion.Ambito aAmbitoDeMotivo(String externo) {
        if (externo == null) return MotivoDesfinalizacion.Ambito.DESCONOCIDO;
        return switch (externo.trim().toUpperCase()) {
            case "C" -> MotivoDesfinalizacion.Ambito.CUENTA_MEDICA;
            case "R" -> MotivoDesfinalizacion.Ambito.AUTORIZACION;
            case "A" -> MotivoDesfinalizacion.Ambito.AMBAS;
            default  -> MotivoDesfinalizacion.Ambito.DESCONOCIDO;
        };
    }

    public static Optional<String> relacionDe(AccionCuenta accion) {
        return Optional.ofNullable(RELACIONES.get(accion));
    }

    public static Severidad aSeveridad(String externa) {
        if (externa == null) return Severidad.DESCONOCIDA;
        return SEVERIDADES.getOrDefault(externa.trim().toUpperCase(), Severidad.DESCONOCIDA);
    }

    public static EstadoProceso.Avance aAvance(String externo) {
        return AVANCES.getOrDefault(externo, EstadoProceso.Avance.NO_INICIADO);
    }

    // ── Traducción de salida (dominio → OHI) ────────────────────────────────────

    /** Convierte un boolean de dominio al indicador "Y"/"N" de OHI. */
    public static String desdeIndicador(boolean valor) { return valor ? "Y" : "N"; }

    /** Convierte el indicador "Y"/"N" de OHI a boolean de dominio. */
    public static boolean aIndicador(String valor) { return "Y".equalsIgnoreCase(valor); }

    /**
     * Indicador booleano de OHI. Las entidades de claims los devuelven como
     * booleanos JSON, no como "Y"/"N"; ausente se interpreta como falso.
     */
    public static boolean aIndicador(Boolean valor) { return Boolean.TRUE.equals(valor); }

    /** Convierte la decisión de envío al parámetro {@code action} de OHI. */
    public static String desdeDecision(DecisionEnvio.Decision decision) {
        return decision == DecisionEnvio.Decision.ACEPTAR ? "accept" : "deny";
    }

    /** El modo de recálculo se materializa en el encabezado HTTP {@code reprocess}. */
    public static String desdeModoRecalculo(ModoRecalculo modo) {
        return String.valueOf(modo == ModoRecalculo.EN_CASCADA);
    }

    /**
     * El nivel al que resolver, en el vocabulario del sistema de registro.
     *
     * <p>Son los dos únicos valores que admite el campo {@code level} de la
     * resolución conjunta —{@code CLA-IP-RPND-007}: «Level can only be either
     * claim or claim line»—, en minúsculas y con el espacio. Vive aquí y no en el
     * record de la petición porque esta clase es, por el contrato que proclama su
     * propio javadoc, el único sitio autorizado a contener literales de OHI.
     */
    public static String desdeNivelPendiente(NivelPendiente nivel) {
        return nivel == NivelPendiente.CABECERA ? "claim" : "claim line";
    }

    /**
     * Por qué el sistema de registro no pudo resolver un motivo, en español.
     *
     * <p>Es el catálogo {@code CLA-IP-RPND-00x} de la resolución conjunta. Solo
     * se usa de respaldo: el mensaje que llega en la propia operación ya trae el
     * texto del catálogo de OHI y es más específico, porque viene con el
     * elemento concreto rellenado. Esto cubre el caso en que el texto no llegue.
     *
     * <p>Ninguno de estos es un error del auditor salvo los dos últimos: que un
     * motivo ya estuviera resuelto o que una línea haya dejado de existir es lo
     * que pasa cuando dos personas trabajan la misma cuenta.
     */
    public static String explicacionDeFalloDeResolucion(String codigo) {
        return switch (codigo == null ? "" : codigo) {
            case "CLA-IP-RPND-001" -> "El motivo no existe en el catálogo";
            case "CLA-IP-RPND-002" -> "La cuenta no existe o ya no está disponible";
            case "CLA-IP-RPND-003" -> "La línea no existe o ya no está disponible";
            case "CLA-IP-RPND-004" -> "La línea no pertenece a esta cuenta";
            case "CLA-IP-RPND-005" -> "No se puede resolver a nivel de línea: "
                                    + "la cuenta es de gran cuantía";
            case "CLA-IP-RPND-006" -> "No tiene permiso sobre alguno de los motivos";
            case "CLA-IP-RPND-007" -> "El nivel de resolución no es válido";
            case "CLA-IP-RPND-008" -> "No se indicó ningún motivo";
            case "CLA-IP-RPND-009" -> "No se indicó ninguna cuenta";
            default -> "El sistema de registro lo rechazó con el código " + codigo;
        };
    }

    private DiccionarioOhi() {}
}
