package co.sura.auditoria.acl.ohi;

import co.sura.auditoria.modelo.cuenta.*;

import java.util.Map;
import java.util.Optional;

/**
 * Diccionario de traducción entre el lenguaje del dominio (español) y el
 * vocabulario de Oracle Health Insurance (inglés).
 *
 * <p>Esta clase es la <b>ÚNICA</b> autorizada a contener literales del vocabulario externo.
 * Cualquier término de OHI que aparezca fuera de este paquete es un defecto de arquitectura
 * detectado por la prueba {@code PruebaArquitecturaTest}.
 *
 * <p>Referencia: §9.1 del documento de arquitectura v2.
 */
public final class DiccionarioOhi {

    // ── Estados ────────────────────────────────────────────────────────────────
    private static final Map<String, EstadoCuenta> ESTADOS = Map.ofEntries(
        Map.entry("INITIAL",                      EstadoCuenta.INICIAL),
        Map.entry("ENTRY",                        EstadoCuenta.DIGITACION),
        Map.entry("CHANGE",                       EstadoCuenta.MODIFICACION),
        Map.entry("MANUAL PRICING",               EstadoCuenta.TARIFACION_MANUAL),
        Map.entry("MANUAL BENEFITS",              EstadoCuenta.BENEFICIOS_MANUALES),
        Map.entry("MANUAL ADJUDICATION",          EstadoCuenta.ADJUDICACION_MANUAL),
        Map.entry("MANUAL PRICING ADJUDICATION",  EstadoCuenta.TARIFACION_ADJUDICACION_MANUAL),
        Map.entry("PRICING DONE",                 EstadoCuenta.TARIFACION_COMPLETA),
        Map.entry("BENEFITS DONE",                EstadoCuenta.BENEFICIOS_COMPLETOS),
        Map.entry("ADJUDICATION DONE",            EstadoCuenta.ADJUDICACION_COMPLETA),
        Map.entry("PRICING ADJUDICATION DONE",    EstadoCuenta.TARIFACION_ADJUDICACION_COMPLETA),
        Map.entry("PRICING FINALIZED",            EstadoCuenta.TARIFACION_FINALIZADA),
        Map.entry("SENT OUT FOR PREPROCESSING",   EstadoCuenta.ENVIADA_A_PREPROCESO),
        Map.entry("SENT OUT FOR PRICING",         EstadoCuenta.ENVIADA_A_TARIFACION),
        Map.entry("FINALIZED",                    EstadoCuenta.FINALIZADA));

    // ── Acciones (link relations de OHI) ────────────────────────────────────────
    private static final Map<String, AccionCuenta> ACCIONES = Map.ofEntries(
        Map.entry("claim:submit",               AccionCuenta.ENVIAR),
        Map.entry("claim:status",               AccionCuenta.SEGUIR_PROCESO),
        Map.entry("claim:resolvepend",          AccionCuenta.RESOLVER_PENDIENTE),
        Map.entry("claim:resolveclaimlinepend", AccionCuenta.RESOLVER_PENDIENTE_LINEA),
        Map.entry("claim:tochange",             AccionCuenta.DEVOLVER_A_MODIFICACION),
        Map.entry("claim:tomanualbenefits",     AccionCuenta.DEVOLVER_A_BENEFICIOS_MANUALES),
        Map.entry("claim:tomanualpricing",      AccionCuenta.DEVOLVER_A_TARIFACION_MANUAL),
        Map.entry("claim:unfinalize",           AccionCuenta.REVERTIR_FINALIZACION),
        Map.entry("claim:unlocklines",          AccionCuenta.DESBLOQUEAR_LINEAS),
        Map.entry("claim:undolinereplacements", AccionCuenta.DESHACER_REEMPLAZOS),
        Map.entry("claim:cancel",               AccionCuenta.ANULAR));

    // ── Relación inversa AccionCuenta → rel externo ──────────────────────────────
    private static final Map<AccionCuenta, String> RELACIONES = Map.ofEntries(
        Map.entry(AccionCuenta.ENVIAR,                       "claim:submit"),
        Map.entry(AccionCuenta.SEGUIR_PROCESO,               "claim:status"),
        Map.entry(AccionCuenta.RESOLVER_PENDIENTE,           "claim:resolvepend"),
        Map.entry(AccionCuenta.RESOLVER_PENDIENTE_LINEA,     "claim:resolveclaimlinepend"),
        Map.entry(AccionCuenta.DEVOLVER_A_MODIFICACION,      "claim:tochange"),
        Map.entry(AccionCuenta.DEVOLVER_A_BENEFICIOS_MANUALES, "claim:tomanualbenefits"),
        Map.entry(AccionCuenta.DEVOLVER_A_TARIFACION_MANUAL, "claim:tomanualpricing"),
        Map.entry(AccionCuenta.REVERTIR_FINALIZACION,        "claim:unfinalize"),
        Map.entry(AccionCuenta.DESBLOQUEAR_LINEAS,           "claim:unlocklines"),
        Map.entry(AccionCuenta.DESHACER_REEMPLAZOS,          "claim:undolinereplacements"),
        Map.entry(AccionCuenta.ANULAR,                       "claim:cancel"));

    // ── Severidades ──────────────────────────────────────────────────────────────
    private static final Map<String, Severidad> SEVERIDADES = Map.of(
        "INFO",    Severidad.INFORMATIVA,
        "WARNING", Severidad.ADVERTENCIA,
        "FATAL",   Severidad.BLOQUEANTE);

    // ── Avance del proceso ───────────────────────────────────────────────────────
    private static final Map<String, EstadoProceso.Avance> AVANCES = Map.of(
        "notStarted", EstadoProceso.Avance.NO_INICIADO,
        "processing", EstadoProceso.Avance.EN_PROCESO,
        "succeeded",  EstadoProceso.Avance.EXITOSO,
        "failed",     EstadoProceso.Avance.FALLIDO);

    // ── Métodos de traducción ────────────────────────────────────────────────────

    public static EstadoCuenta aEstado(String externo) {
        if (externo == null) return EstadoCuenta.DESCONOCIDO;
        return ESTADOS.getOrDefault(externo.trim().toUpperCase(), EstadoCuenta.DESCONOCIDO);
    }

    public static Optional<AccionCuenta> aAccion(String relacion) {
        return Optional.ofNullable(ACCIONES.get(relacion));
    }

    public static Optional<String> relacionDe(AccionCuenta accion) {
        return Optional.ofNullable(RELACIONES.get(accion));
    }

    public static Severidad aSeveridad(String externa) {
        if (externa == null) return Severidad.DESCONOCIDA;
        return SEVERIDADES.getOrDefault(externa.trim().toUpperCase(), Severidad.DESCONOCIDA);
    }

    public static EstadoProceso.Avance aAvance(String externo) {
        return AVANCES.getOrDefault(externo, EstadoProceso.Avance.NO_INICIADO);
    }

    // ── Traducción de salida (dominio → OHI) ────────────────────────────────────

    /** Convierte un boolean de dominio al indicador "Y"/"N" de OHI. */
    public static String desdeIndicador(boolean valor) { return valor ? "Y" : "N"; }

    /** Convierte el indicador "Y"/"N" de OHI a boolean de dominio. */
    public static boolean aIndicador(String valor) { return "Y".equalsIgnoreCase(valor); }

    /**
     * Indicador booleano de OHI. Las entidades de claims los devuelven como
     * booleanos JSON, no como "Y"/"N"; ausente se interpreta como falso.
     */
    public static boolean aIndicador(Boolean valor) { return Boolean.TRUE.equals(valor); }

    /** Convierte la decisión de envío al parámetro {@code action} de OHI. */
    public static String desdeDecision(DecisionEnvio.Decision decision) {
        return decision == DecisionEnvio.Decision.ACEPTAR ? "accept" : "deny";
    }

    /** El modo de recálculo se materializa en el encabezado HTTP {@code reprocess}. */
    public static String desdeModoRecalculo(ModoRecalculo modo) {
        return String.valueOf(modo == ModoRecalculo.EN_CASCADA);
    }

    private DiccionarioOhi() {}
}
