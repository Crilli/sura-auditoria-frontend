package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorNotasOhi implements PuertoNotas {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AdaptadorNotasOhi.class);

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final ResolutorIdentidadOhi resolutor;
    private final ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo;

    public AdaptadorNotasOhi(WebClient webClient,
                             ConfiguracionResiliencia resiliencia,
                             TraductorErrores traductorErrores,
                             ResolutorIdentidadOhi resolutor,
                             ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.resolutor = resolutor;
        this.buscadorPorCodigo = buscadorPorCodigo;
    }

    @Override
    public Mono<Void> agregarNota(CodigoCuenta codigo, String autor, String texto) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> {
                    var body = Map.of(
                            "claim", Map.of("id", idCuenta),
                            "text", texto
                            // El autor generalmente se toma del token, pero si OHI requiere un campo:
                            // "author", autor
                    );

                    return webClient.post()
                            .uri("/generic/claimnotes")
                            .bodyValue(body)
                            .retrieve()
                            .onStatus(s -> s.isError(), traductorErrores::traducir)
                            .bodyToMono(Void.class)
                            .transform(resiliencia.paraComandosMono())
                            // El caso de uso trata la nota como mejor esfuerzo y no
                            // propaga este fallo al auditor: que quede en el log es
                            // la única forma de que alguien se entere de que faltó.
                            //
                            // ADVERTENCIA: /generic/claimnotes no existe en el contrato
                            // real de OHI (verificado: 404). El único recurso de notas
                            // publicado en el catálogo de metadata es /generic/notes/{subject},
                            // documentado con únicamente operaciones GET — no se encontró
                            // una vía de creación. Pendiente de confirmar con el equipo
                            // de integración de OHI cuál es la ruta correcta.
                            .doOnError(e -> log.warn(
                                    "No se pudo registrar la nota de auditoría en OHI para la "
                                  + "cuenta {} (el pendiente sí quedó resuelto): {}",
                                    codigo.valor(), e.getMessage()));
                });
    }
}
