package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Notas de la cuenta en el sistema de registro: hoy no tienen adónde ir (OPE-02).
 *
 * <h3>Por qué no sale ninguna llamada</h3>
 * Este adaptador hacía {@code POST /generic/claimnotes}, y ese recurso no existe en OHI
 * —verificado: 404—. El único de notas que publica su catálogo es
 * {@code /generic/notes/{subject}}, y solo con GET: no hay forma conocida de crear una nota
 * ligada a la cuenta. Lo tiene que abrir el equipo de integración de OHI (BTN-05).
 *
 * <p>Mientras tanto, llamar «a mejor esfuerzo» no era inocuo: la llamada iba por el circuito
 * de comandos y cada resolución de pendientes, individual o masiva, le sumaba un fallo seguro.
 * Bajo carga eso bastaba para abrir el circuito y cortar las escrituras de todos.
 *
 * <p><b>La justificación no se pierde</b>: viaja en el evento de auditoría de la resolución,
 * que es donde se consulta quién resolvió qué y por qué. Cuando OHI publique la ruta de alta,
 * este es el único sitio que cambia.
 */
@Component
public class AdaptadorNotasOhi implements PuertoNotas {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AdaptadorNotasOhi.class);

    @Override
    public Mono<Void> agregarNota(CodigoCuenta codigo, String autor, String texto) {
        log.debug("La nota de la cuenta {} no se envía al sistema de registro: no publica cómo "
                + "crearla. La justificación queda en el evento de auditoría.", codigo.valor());
        return Mono.empty();
    }
}
