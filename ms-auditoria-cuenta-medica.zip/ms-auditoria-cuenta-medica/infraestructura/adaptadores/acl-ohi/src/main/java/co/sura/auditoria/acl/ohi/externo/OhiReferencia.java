package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Referencia a otra entidad de OHI:
 * {@code {"id":..., "code":..., "descr":..., "flexCodeDefinitionCode":..., "value":...}}.
 *
 * <p>Aparece en los campos que apuntan a catálogos (procedimiento, prestador,
 * persona). OHI no expone el código plano en la entidad que lo referencia.
 *
 * <p>{@code descr} solo llega si se pide explícitamente en la proyección
 * ({@code procedure.descr}): pedir {@code procedure} a secas devuelve la
 * referencia sin descripción. {@code flexCodeDefinitionCode} dice de qué catálogo
 * sale el código (CUPS, CUM, SURACUPS o el propio de un prestador), que es lo que
 * permite leer un mismo código sin ambigüedad.
 */
public record OhiReferencia(String id, String code,
                            @JsonProperty("descr") String descripcion,
                            @JsonProperty("flexCodeDefinitionCode") String catalogo,
                            String value) {

    /** Código de negocio de la referencia, o {@code null} si no viene. */
    public static String codigoDe(OhiReferencia referencia) {
        if (referencia == null) return null;
        return referencia.code() != null ? referencia.code() : referencia.id();
    }

    /** Descripción de la referencia, o {@code null} si no viene. */
    public static String descripcionDe(OhiReferencia referencia) {
        return referencia == null ? null : referencia.descripcion();
    }

    /** Catálogo del que sale el código (CUPS, CUM…), o {@code null} si no viene. */
    public static String catalogoDe(OhiReferencia referencia) {
        return referencia == null ? null : referencia.catalogo();
    }

    /** Identificador interno de la referencia, o {@code null} si no viene. */
    public static String identificadorDe(OhiReferencia referencia) {
        return referencia == null ? null : referencia.id();
    }
}
