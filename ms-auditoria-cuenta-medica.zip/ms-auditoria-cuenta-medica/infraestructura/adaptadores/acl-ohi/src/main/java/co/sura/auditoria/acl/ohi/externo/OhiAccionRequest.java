package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * Cuerpos de las acciones que llevan algo.
 *
 * <p>Son tres formas, sacadas de los {@code /definition} que el propio sistema
 * de registro publica para cada operación. Las otras seis acciones no llevan
 * cuerpo ninguno.
 */
public final class OhiAccionRequest {

    private OhiAccionRequest() {}

    /**
     * Un motivo dentro de la lista.
     *
     * <p>El contrato exige {@code unfinalizeReason} con su {@code code}; la
     * referencia de origen es opcional salvo que el motivo la marque como
     * obligatoria en el catálogo.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Motivo(Referencia unfinalizeReason, String sourceReference) {

        @JsonInclude(JsonInclude.Include.NON_NULL)
        public record Referencia(String code) {}

        public static Motivo de(String codigo, String referencia) {
            return new Motivo(new Referencia(codigo),
                              referencia == null || referencia.isBlank() ? null : referencia);
        }
    }

    /**
     * Anulación.
     *
     * <p>Lleva motivos de <b>desfinalización</b>, no de anulación: es el mismo
     * catálogo. Su contrato documenta que sin ellos responde que no se
     * especificó ninguno.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Anular(String cancelReasonMessageCode,
                         List<Motivo> claimUnfinalizeReasonList,
                         String providerReference) {}

    /** Reversión de la finalización. */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Desfinalizar(List<Motivo> claimUnfinalizeReasonList) {}

    /**
     * Desbloqueo de líneas.
     *
     * <p>La lista es opcional: sin ella se desbloquean todas. Se manda solo
     * cuando el auditor eligió unas concretas.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record DesbloquearLineas(List<Long> claimLineIdList) {}
}
