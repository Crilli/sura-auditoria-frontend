package co.sura.auditoria.acl.ohi.externo;

/**
 * Clasificación del servicio ({@code claseServicio}) de OHI.
 *
 * <p>Es un flexfield más rico que los de {@link OhiFlexCode}: además del código
 * corto trae el subcampo {@code tipoServicio}, que es el que corresponde al
 * "Tipo de servicio" que necesita el dominio.
 */
public record OhiClaseServicio(String value, String descriptor, String tipoServicio) {

    /** Texto para mostrar: el tipo de servicio si viene, si no el descriptor general. */
    public static String textoDe(OhiClaseServicio clase) {
        if (clase == null) return null;
        if (clase.tipoServicio() != null) return clase.tipoServicio();
        return clase.descriptor() != null ? clase.descriptor() : clase.value();
    }
}
