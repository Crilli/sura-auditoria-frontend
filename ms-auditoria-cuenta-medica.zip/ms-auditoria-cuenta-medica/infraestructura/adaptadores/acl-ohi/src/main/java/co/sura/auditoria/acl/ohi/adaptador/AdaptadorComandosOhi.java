package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiClaimPatch;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import org.springframework.context.annotation.Profile;

@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorComandosOhi implements PuertoComandosCuenta {

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final TraductorLinea traductorLinea;
    private final ResolutorIdentidadOhi resolutor;
    private final PuertoConsultaCuentas consultas; // para devolver el estado resultante
    private final ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo;

    public AdaptadorComandosOhi(WebClient webClient,
                                ConfiguracionResiliencia resiliencia,
                                TraductorErrores traductorErrores,
                                TraductorLinea traductorLinea,
                                ResolutorIdentidadOhi resolutor,
                                PuertoConsultaCuentas consultas,
                                ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.traductorLinea = traductorLinea;
        this.resolutor = resolutor;
        this.consultas = consultas;
        this.buscadorPorCodigo = buscadorPorCodigo;
    }

    @Override
    public Mono<LineaCuenta> aplicarEdicionesDeLinea(CodigoCuenta codigo, Version versionCuenta,
                                                     List<EdicionLinea> ediciones) {
        var parches = ediciones.stream()
                .map(traductorLinea::desdeEdicion)
                .toList();

        var body = new OhiClaimPatch(versionCuenta.numero(), parches);   // -> claimLineList
        // Se asume el modo del primer elemento (en la API el modo aplica a todo el parche)
        var recalcular = DiccionarioOhi.desdeModoRecalculo(ediciones.get(0).modoRecalculo());

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> webClient.patch()
                        .uri(builder -> builder.path("/generic/claims/{id}")
                                .queryParam("reprocess", recalcular)
                                .build(idCuenta))
                        .bodyValue(body)
                        .retrieve()
                        .onStatus(s -> s.isError(), traductorErrores::traducir)
                        .bodyToMono(Void.class)
                        .transform(resiliencia.paraComandosMono()))
                // Al finalizar, se consulta de nuevo para retornar el estado final de la línea afectada
                // (Se asume una sola edición para devolver; si son varias, se retorna la primera)
                .then(Mono.defer(() -> consultas.buscarDetalleLinea(codigo, ediciones.get(0).referencia())));
    }

    @Override
    public Mono<TiqueteProceso> enviar(CodigoCuenta codigo, Version version, DecisionEnvio decision) {
        var action = DiccionarioOhi.desdeDecision(decision.decision());

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> {
                    var uri = webClient.post()
                            .uri(builder -> {
                                builder.path("/generic/claims/{id}/submit")
                                       .queryParam("action", action);
                                decision.codigoNovedad().ifPresent(n -> builder.queryParam("messageCode", n));
                                return builder.build(idCuenta);
                            });

                    return uri.retrieve()
                            .onStatus(s -> s.isError(), traductorErrores::traducir)
                            .bodyToMono(Void.class)
                            .transform(resiliencia.paraEnvioMono());
                })
                .map(v -> new TiqueteProceso(codigo, "process-url-from-headers-not-impl"));
    }

}
