package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiClaimPatch;
import co.sura.auditoria.acl.ohi.externo.OhiNovedadPatch;
import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorAcciones;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.acl.ohi.traductor.TraductorLinea;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public class AdaptadorComandosOhi implements PuertoComandosCuenta {

    private final WebClient webClient;
    /**
     * El de operaciones largas (25 s), para lo que obliga al motor a recalcular: el guardado en
     * cascada y las acciones. Con el de 5 s el cliente cortaba, salía un 503 y OHI terminaba
     * igual, así que el auditor veía «no se pudo» de algo que sí se había hecho (OPE-11).
     */
    private final WebClient clientePaciente;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final TraductorLinea traductorLinea;
    private final ResolutorIdentidadOhi resolutor;
    private final PuertoConsultaCuentas consultas; // para devolver el estado resultante
    private final ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo;
    /** Lo que se invalida tras cada comando: filtros, motivos y acciones de la cuenta (OPE-09). */
    private final co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi agregados;

    public AdaptadorComandosOhi(WebClient webClient,
                                @org.springframework.beans.factory.annotation.Qualifier(
                                        co.sura.auditoria.acl.ohi.cliente.ConfiguracionClienteOhi.CLIENTE_OPERACIONES_LARGAS)
                                WebClient clientePaciente,
                                ConfiguracionResiliencia resiliencia,
                                TraductorErrores traductorErrores,
                                TraductorLinea traductorLinea,
                                ResolutorIdentidadOhi resolutor,
                                PuertoConsultaCuentas consultas,
                                ResolutorIdentidadOhi.BuscadorPorCodigo buscadorPorCodigo,
                                co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi agregados) {
        this.webClient = webClient;
        this.clientePaciente = clientePaciente;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.traductorLinea = traductorLinea;
        this.resolutor = resolutor;
        this.consultas = consultas;
        this.buscadorPorCodigo = buscadorPorCodigo;
        this.agregados = agregados;
    }

    @Override
    public Mono<LineaCuenta> aplicarEdicionesDeLinea(CodigoCuenta codigo, Version versionCuenta,
                                                     List<EdicionLinea> ediciones) {
        var parches = ediciones.stream()
                .map(traductorLinea::desdeEdicion)
                .toList();

        var body = OhiClaimPatch.deLineas(versionCuenta.numero(), parches);   // -> claimLineList
        // Se asume el modo del primer elemento (en la API el modo aplica a todo el parche)
        var recalcular = DiccionarioOhi.desdeModoRecalculo(ediciones.get(0).modoRecalculo());

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> ("true".equals(recalcular) ? clientePaciente : webClient).patch()
                        // Con plantilla, para que las métricas no lo agrupen en uri="none" (OPE-05).
                        .uri("/generic/claims/{id}?reprocess={reprocess}", idCuenta, recalcular)
                        .bodyValue(body)
                        .retrieve()
                        .onStatus(s -> s.isError(), traductorErrores::traducir)
                        .bodyToMono(Void.class)
                        .transform(resiliencia.paraComandosMono()))
                // Al finalizar, se consulta de nuevo para retornar el estado final de la línea afectada
                // (Se asume una sola edición para devolver; si son varias, se retorna la primera)
                // Haya ido bien o mal —un corte no dice que OHI no lo aplicara—, lo guardado de la
                // cuenta ya no vale (OPE-09).
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal))
                .then(releer(() -> consultas.buscarDetalleLinea(codigo, ediciones.get(0).referencia()),
                             "linea:" + ediciones.get(0).referencia().valor()));
    }

    /**
     * Aplica altas y bajas de novedad sobre la cabecera de la cuenta.
     *
     * <p>Mismo endpoint que la edición de línea, otra colección: aquí viaja
     * {@code claimMessageList} al nivel de la cuenta.
     *
     * <p><b>Sin recálculo</b> ({@code reprocess=false}): una novedad de cabecera
     * no mueve importes, así que pedirlo solo costaría tiempo. En la línea el
     * modo lo elige el auditor porque allí sí se tocan valores.
     */
    @Override
    public Mono<CuentaMedica> aplicarCambiosDeNovedadDeCabecera(CodigoCuenta codigo, Version version,
                                                      List<CambioNovedad> cambios) {
        var parches = cambios.stream()
                .map(c -> c.esBaja()
                        ? OhiNovedadPatch.baja(c.identificador())
                        : OhiNovedadPatch.alta(c.codigoMensaje(), c.valores()))
                .toList();

        var body = OhiClaimPatch.deNovedades(version.numero(), parches);

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> webClient.patch()
                        // reprocess=false literal: así las novedades salen en su propia serie de
                        // métricas y no mezcladas con la edición de línea.
                        .uri("/generic/claims/{id}?reprocess=false", idCuenta)
                        .bodyValue(body)
                        .retrieve()
                        .onStatus(s -> s.isError(), traductorErrores::traducir)
                        .bodyToMono(Void.class)
                        .transform(resiliencia.paraComandosMono()))
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal))
                // Se relee para devolver el estado resultante, igual que en la
                // edición de línea: la respuesta del PATCH trae la cuenta pero
                // sin las novedades resueltas.
                .then(releer(() -> consultas.buscarPorCodigo(codigo), "cuenta:" + codigo.valor()));
    }

    /**
     * Envía la cuenta a proceso.
     *
     * <h3>Tres cosas que estaban mal y se arreglan juntas</h3>
     * <ol>
     *   <li><b>La ruta llevaba {@code /generic}</b> y no existe: comprobado
     *       contra el entorno de pruebas, {@code /generic/claims/{id}/submit}
     *       responde <b>404</b> y {@code /claims/{id}/submit} responde 200. Las
     *       acciones viven fuera de {@code /generic}, que es solo para las
     *       búsquedas y el parche —{@code AdaptadorPendientesOhi} ya lo hacía
     *       bien—. El 404 llegaba con cuerpo HTML, el traductor no lo reconocía
     *       y acababa convertido en «la decisión de envío no es válida», que no
     *       tiene nada que ver. <b>Esta operación no había funcionado nunca.</b></li>
     *   <li><b>Mandaba {@code action} y {@code messageCode}</b>, que el contrato
     *       no tiene: su única entrada es el identificador de la ruta. Aceptar o
     *       denegar no es cosa de esta operación; denegar se hace poniendo una
     *       novedad bloqueante y no enviando.</li>
     *   <li><b>El tiquete era inventado</b>: se devolvía la cadena
     *       {@code "process-url-from-headers-not-impl"} en vez de leer la
     *       cabecera {@code Location} del 201, que es donde el contrato dice que
     *       viaja el recurso de estado. Con eso, el seguimiento del proceso
     *       arrancaba con una referencia falsa.</li>
     * </ol>
     *
     * <p>Sigue aparte de {@link #ejecutarAccion} porque es la única que no es
     * síncrona: responde 201 y deja un proceso corriendo, mientras que las demás
     * responden 200 o 303 con la cuenta ya movida.
     */
    @Override
    public Mono<TiqueteProceso> enviar(CodigoCuenta codigo, Version version, DecisionEnvio decision) {
        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> webClient.post()
                        .uri("/claims/{id}/submit", idCuenta)
                        .retrieve()
                        .onStatus(s -> s.isError(), traductorErrores::traducir)
                        .toBodilessEntity()
                        .transform(resiliencia.paraEnvioMono()))
                .map(respuesta -> {
                    var location = respuesta.getHeaders().getFirst("Location");
                    return new TiqueteProceso(codigo,
                            location != null ? location : SIN_REFERENCIA_DE_PROCESO);
                })
                // El envío deja un proceso corriendo en OHI: se invalida ya y otra vez después,
                // además de cuando el seguimiento lo ve terminar (consultarEstadoProceso).
                .doFinally(senal -> {
                    agregados.invalidar(codigo);
                    agregados.invalidarMasTarde(codigo);
                });
    }

    /**
     * Lo que se pone como referencia cuando el sistema de registro no devuelve
     * {@code Location}. No debería pasar —su contrato lo documenta en el 201—
     * pero se dice en vez de inventar una referencia que parezca buena.
     */
    private static final String SIN_REFERENCIA_DE_PROCESO = "(sin referencia de proceso)";

    /**
     * Ejecuta una acción habilitada sobre la cuenta.
     *
     * <h3>Por qué la ruta se arma con el nombre de la operación</h3>
     * Las nueve comparten forma: {@code POST /claims/{id}/<operación>}, fuera de
     * {@code /generic}. Lo que cambia es el cuerpo, y eso lo resuelve
     * {@link TraductorAcciones#cuerpoDe}.
     *
     * <p><b>Los códigos de éxito no son uniformes</b> y hay que decirlo: siete
     * responden 303 redirigiendo a la cuenta, y <i>devolver a beneficios</i> y
     * <i>devolver a tarifación</i> responden 200. El predicado de error se
     * escribe en positivo —2xx y 303 son éxito— en vez de fiarse de que un 3xx
     * no cuente como error: el cliente no sigue redirecciones, y si alguien lo
     * activara cada transición se convertiría en una lectura completa de la
     * cuenta.
     */
    @Override
    public Mono<CuentaMedica> ejecutarAccion(CodigoCuenta codigo, EjecucionAccion ejecucion) {
        var operacion = DiccionarioOhi.operacionDe(ejecucion.accion());
        var cuerpo    = TraductorAcciones.cuerpoDe(ejecucion);

        return resolutor.resolverParaCuenta(codigo, buscadorPorCodigo)
                .flatMap(idCuenta -> {
                    // Las acciones mueven el estado y recalculan: van por el cliente de 25 s.
                    var peticion = clientePaciente.post()
                            // Una serie de métricas por acción: son siete, un Map.of cerrado.
                            .uri("/claims/{id}/" + operacion, idCuenta);
                    var conCuerpo = cuerpo == null
                            ? peticion.retrieve()
                            : peticion.bodyValue(cuerpo).retrieve();

                    return conCuerpo
                            .onStatus(s -> !(s.is2xxSuccessful() || s.value() == 303),
                                      traductorErrores::traducir)
                            .toBodilessEntity()
                            .transform(resiliencia.paraComandosMono());
                })
                .doFinally(senal -> agregados.invalidarTrasComando(codigo, senal))
                // Se relee: la acción mueve el estado, y con él las acciones que
                // quedan habilitadas. El 303 trae la cuenta, pero seguirlo
                // costaría la representación completa.
                .then(releer(() -> consultas.buscarPorCodigo(codigo), "cuenta:" + codigo.valor()));
    }


    /** Cuántas veces se reintenta la relectura, que es una lectura sin efectos. */
    private static final int REINTENTOS_DE_RELECTURA = 2;

    /**
     * La relectura que sigue a un comando ya aplicado (OPE-11).
     *
     * <p>Se reintenta ante una caída del sistema de registro —es una lectura: repetirla no
     * cambia nada—. Si aun así falla, lo que sale es {@link ErrorDeDominio.AplicadoSinRelectura}:
     * el comando se aplicó y decir otra cosa invitaría a repetirlo. Solo se envuelve lo que
     * falla aquí; un error del propio comando sale tal cual.
     */
    private <T> Mono<T> releer(java.util.function.Supplier<Mono<T>> lectura, String recurso) {
        return Mono.defer(lectura)
                .retryWhen(reactor.util.retry.Retry
                        .backoff(REINTENTOS_DE_RELECTURA, java.time.Duration.ofMillis(300))
                        .filter(AdaptadorComandosOhi::esCaidaReintentable)
                        .onRetryExhaustedThrow((especificacion, senal) -> senal.failure()))
                // Una relectura que no encuentra nada tampoco dice que el comando no se aplicara.
                .switchIfEmpty(Mono.error(RelecturaVacia::new))
                .onErrorMap(error -> ExcepcionDeDominio.de(new ErrorDeDominio.AplicadoSinRelectura(
                        recurso, error.getMessage() == null ? error.getClass().getSimpleName()
                                                            : error.getMessage())));
    }

    /** La relectura volvió vacía. Solo existe para llevar un mensaje claro al error de dominio. */
    private static final class RelecturaVacia extends RuntimeException {
        RelecturaVacia() { super("la relectura no devolvió nada", null, false, false); }
    }

    /**
     * Si merece la pena volver a leer: una caída del sistema de registro, pero no un 429 —pide
     * bajar el ritmo— ni un 4xx sin clasificar, que darían lo mismo al repetirse.
     */
    private static boolean esCaidaReintentable(Throwable error) {
        if (error instanceof co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi respuesta)
            return respuesta.estadoHttp() >= 500;
        return error instanceof ExcepcionDeDominio excepcion
            && excepcion.error() instanceof ErrorDeDominio.SistemaRegistroNoDisponible;
    }
}
