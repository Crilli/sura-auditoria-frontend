package co.sura.auditoria.acl.ohi.resiliencia;

import co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi;
import java.util.function.Predicate;
import org.springframework.web.reactive.function.client.WebClientResponseException;

/**
 * Qué se reintenta en una consulta: las caídas de {@link FalloDeDisponibilidadOhi}, menos el
 * 429 (OPE-01).
 *
 * <p>Un 429 es el sistema de registro pidiendo que se baje el ritmo: abrir el circuito es la
 * respuesta correcta, y reintentarlo a los 500 ms la contraria —triplica las peticiones justo
 * cuando sobran—. Encontrado en la revisión adversarial de la Fase 0.
 */
public class ReintentableOhi implements Predicate<Throwable> {

    private final FalloDeDisponibilidadOhi esCaida = new FalloDeDisponibilidadOhi();

    @Override
    public boolean test(Throwable error) {
        return esCaida.test(error) && !esFreno(error);
    }

    private static boolean esFreno(Throwable error) {
        return (error instanceof RespuestaDeErrorOhi r && r.estadoHttp() == 429)
            || (error instanceof WebClientResponseException w && w.getStatusCode().value() == 429);
    }
}
