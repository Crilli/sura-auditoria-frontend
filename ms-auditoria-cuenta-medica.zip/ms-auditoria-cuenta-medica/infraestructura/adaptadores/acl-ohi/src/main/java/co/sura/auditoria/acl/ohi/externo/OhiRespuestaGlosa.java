package co.sura.auditoria.acl.ohi.externo;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una respuesta a glosa tal como la publica {@code claims.respuestaGlosa}.
 *
 * <p>Los nombres están en español porque así los publica el sistema de registro: es una
 * extensión de SURA, no del producto. Medidos uno a uno el 2026-10-17 sobre CM-94421, que
 * tiene dos respuestas.
 *
 * <p>{@code numeroSecuencia} llega como <b>cadena</b> («1», «2») y no como número; se deja tal
 * cual para no inventar una conversión que el sistema de registro no hace.
 */
public record OhiRespuestaGlosa(String id,
                                LocalDate fechaLlegada,
                                String numeroSecuencia,
                                String versionamiento,
                                BigDecimal valor,
                                LocalDate fechaVencimiento) {}
