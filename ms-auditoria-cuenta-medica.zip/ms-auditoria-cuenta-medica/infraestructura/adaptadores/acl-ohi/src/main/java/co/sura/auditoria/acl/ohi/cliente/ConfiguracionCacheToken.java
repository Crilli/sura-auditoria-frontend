package co.sura.auditoria.acl.ohi.cliente;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * Caché del token OAuth2 de OHI.
 *
 * <p>{@code ProveedorTokenOhi.obtenerToken()} devuelve un {@code Mono}, y la
 * abstracción de caché de Spring solo sabe cachear tipos reactivos si el gestor
 * está en modo asíncrono. Sin esta configuración la llamada falla con
 * «No Caffeine AsyncCache available».
 *
 * <p>La expiración se fija por debajo del TTL real del token (IDCS entrega
 * {@code expires_in = 3600 s}) para no usar nunca uno a punto de vencer.
 */
@Configuration
public class ConfiguracionCacheToken {

    /** Nombre de la caché declarado en {@code @Cacheable} del proveedor de token. */
    public static final String CACHE_TOKEN = "tokenOhi";

    @Bean
    public CacheManager cacheManager(
            @Value("${integraciones.ohi.cache-token.expiracion:50m}") Duration expiracion) {

        var gestor = new CaffeineCacheManager(CACHE_TOKEN);
        gestor.setAsyncCacheMode(true);          // imprescindible para valores reactivos
        gestor.setCaffeine(Caffeine.newBuilder().expireAfterWrite(expiracion));
        return gestor;
    }
}
