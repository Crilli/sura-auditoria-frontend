package co.sura.auditoria.acl.ohi.consulta;

/**
 * Proyecciones de campos para las búsquedas en OHI.
 *
 * <p><b>Validación obligatoria antes de producción:</b> estos alias corresponden
 * a los <em>View Objects</em> de OHI, no a las columnas ni al JSON de salida.
 * Cada constante debe verificarse contra {@code /generic/{recurso}/metadata} del
 * ambiente de Sura, incluyendo los registros dinámicos configurados (riesgo #7).
 */
public final class CamposOhi {

    /**
     * Cabecera de la cuenta, para usar con {@code SolicitudBusqueda.cabecera(...)}
     * ({@code excludereferenceresources=true}, para no arrastrar {@code claimLineList}
     * en cuentas grandes).
     *
     * <p><b>{@code person}, {@code claimantProvider} y {@code paymentReceiverProvider}
     * NO van aquí</b>, aunque el dominio los necesite: se confirmó contra OHI que
     * {@code excludereferenceresources} descarta cualquier referencia a otra entidad,
     * sea lista o escalar, sin importar que esté en {@code fields}. Pedirlos en esta
     * proyección no tiene efecto — se resuelven en una segunda consulta sin esa
     * exclusión ({@code referenciasDeLaCabecera} en {@code AdaptadorConsultasOhi}).
     */
    public static final String CABECERA_CUENTA = String.join(",",
        "id", "code", "status", "startDate", "endDate",
        "totalAllowedAmount", "totalCoveredAmount", "totalClaimedAmount",
        // Facturación y radicación (extensión SURA) — confirmados contra
        // /generic/claims/metadata; ver InformacionFacturacion en el dominio.
        "numeroFactura", "receiptDate", "fechaEmisionFactura", "fechaVencimiento",
        "fechaIngresoAtencion", "fechaEgresoAtencion",
        "valorFactura", "valorTotalFactura", "totalValorGlosado", "valorNotaCredito",
        "claseServicio", "acuseRecibido", "radicadoATEP", "multicore", "pendienteManual",
        "internalRemarks", "externalRemarks",
        "objectVersionNumber");

    /**
     * {@code person.id} y no {@code person}: con la proyección activa
     * ({@code defaultoverride}) OHI solo devuelve los subcampos que se le pidan, y
     * el afiliado —a diferencia de {@code procedure} o {@code serviceProvider}, que
     * son flex codes con {@code code}— se identifica únicamente por {@code id}.
     * Pedir {@code person} a secas devuelve <code>{}</code> y
     * {@code OhiReferencia.codigoDe} se queda sin nada que leer.
     */
    /**
     * {@code procedure.descr} es la descripción de la prestación y hay que pedirla
     * explícitamente: {@code procedure} a secas devuelve solo
     * <code>{code, flexCodeDefinitionCode, value}</code>. Cobertura medida en
     * producción: 100% de las líneas.
     *
     * <p>{@code person.code} es el documento del afiliado ({@code CC30359313}) y
     * {@code person.id} su identificador interno. Se piden los dos: el nombre se
     * resuelve aparte contra {@code /generic/persons}, que es el único sitio donde
     * OHI lo publica —la línea no lo trae—.
     */
    public static final String RESUMEN_LINEA = String.join(",",
        "id", "sequence", "startDate", "endDate",
        "procedure.code", "procedure.descr", "procedure.flexCodeDefinitionCode",
        "serviceProvider.code", "person.id", "person.code",
        "allowedAmount", "coveredAmount",
        "keepBenefits", "keepPricing", "locked", "replaced", "objectVersionNumber");

    /**
     * Detalle de la línea: todo lo que el negocio exige ver sin salir de ella.
     *
     * <p>Es deliberadamente más ancha que {@link #RESUMEN_LINEA} —la grilla no
     * necesita convenio ni diagnósticos— y aun así cuesta una sola consulta:
     * todo viaja en la misma fila de {@code claimlines}.
     *
     * <p>Los campos de extensión de Sura solo llegan si se piden; no están en la
     * representación por omisión. Los flex code se piden por {@code .value} y
     * {@code .descriptor}: el descriptor es la etiqueta en castellano.
     */
    public static final String DETALLE_LINEA = String.join(",",
        "id", "sequence", "status", "startDate", "endDate",
        // prestación
        "procedure.code", "procedure.descr", "procedure.flexCodeDefinitionCode",
        "claseServicio.value", "claseServicio.descriptor",
        "prestacionCodigoNoDefinido", "prestacionCodigoNoDefinidoDef",
        "archivoRIPSDescrPrestacion",
        "serviceSpecialty.code", "serviceSpecialty.descr",
        // quién atiende y a quién
        "serviceProvider.code", "serviceProviderName", "person.id", "person.code",
        "authorizationCode",
        // importes y cantidades
        "claimedAmount", "claimedNumberOfUnits",
        "allowedAmount", "allowedNumberOfUnits",
        "coveredAmount", "coveredNumberOfUnits",
        "valorGlosado", "observacionesGlosa",
        // convenio
        "codeTariffISS2001.value", "codeTariffISS2001.descriptor",
        "codeTariffISS2000.value", "codeTariffISS2000.descriptor",
        "codeTariffSOAT.value", "codeTariffSOAT.descriptor",
        "numeroContrato", "homologoCups",
        "multiplesCupsHomologos.value", "multiplesCupsHomologos.descriptor",
        "codigoUnicoContratoSIIFA",
        // atención y siniestro
        "tipoSala.value", "tipoSala.descriptor",
        "viaDeAcceso.value", "viaDeAcceso.descriptor",
        "datosAdicionalesSiniestro.UEN",
        "codigoSiniestro",
        // diagnósticos de la línea
        "claimLineDiagnosisList.sequence",
        "claimLineDiagnosisList.diagnosis.code", "claimLineDiagnosisList.diagnosis.descr",
        "claimLineDiagnosisList.diagnosisType.code", "claimLineDiagnosisList.diagnosisType.descr",
        // desglose de la glosa
        "detallesGlosa.id", "detallesGlosa.valorGlosa", "detallesGlosa.codigoNotaCredito",
        "detallesGlosa.descripcionGenerico", "detallesGlosa.descripcionEspecifico",
        "detallesGlosa.texto",
        // control de edición
        "keepBenefits", "keepPricing", "manualBenefits", "manualPricing",
        "locked", "replaced", "objectVersionNumber");

    /**
     * Nombre del afiliado. OHI compone el nombre colombiano en cuatro campos:
     * {@code firstName} (primer nombre), {@code secondName} (segundo),
     * {@code name} (primer apellido) y {@code middleName} (segundo apellido).
     * {@code namePartner} e {@code initials} llegan siempre vacíos en esta
     * instalación y no se piden.
     *
     * <p>Se pide lo mínimo para identificar al afiliado en la grilla. El recurso
     * publica además fecha de nacimiento y género, que no hacen falta para auditar
     * una línea y por tanto <b>no</b> se traen.
     */
    public static final String AFILIADO = String.join(",",
        "id", "code", "firstName", "secondName", "name", "middleName");

    /**
     * Nombre del prestador. {@code serviceProviderName} de la línea llega
     * <b>siempre vacío</b> (0 de 200 medidas), así que el nombre hay que
     * resolverlo aquí por el código.
     */
    public static final String PRESTADOR = String.join(",", "id", "code", "name");

    /**
     * Cláusulas de tarifación de una línea. De aquí sale el «valor convenido»:
     * la tarifa pactada con el prestador, que no existe como campo de la línea.
     */
    public static final String CLAUSULA_TARIFA = String.join(",",
        "id", "sequence", "amount", "providerPricingClause.descr", "claimLine.id");

    /**
     * {@code pendReason.descr}, no {@code description}: ver la nota de
     * {@code OhiPendReasonItem.OhiPendReasonRef}. Con el nombre anterior la
     * descripción del motivo llegaba vacía y el auditor solo veía el código.
     */
    public static final String PENDIENTE_CABECERA = String.join(",",
        "id", "pendReason.code", "pendReason.descr", "resolved",
        "pendReason.adjudicationOnly", "objectVersionNumber");

    /**
     * Ver la nota de {@link #PENDIENTE_CABECERA} sobre {@code pendReason.descr}.
     *
     * <p>El número de línea es {@code claimLine.sequence}, no {@code lineNumber}:
     * es el mismo nombre que ya documenta {@code OhiClaimLineItem} para la línea
     * suelta. Con {@code lineNumber} llegaba vacío y el pendiente solo podía
     * citar la referencia interna de OHI en vez del número que ve el auditor.
     */
    public static final String PENDIENTE_LINEA = String.join(",",
        "id", "pendReason.code", "pendReason.descr", "resolved",
        "pendReason.adjudicationOnly",
        "claimLine.id", "claimLine.sequence", "objectVersionNumber");

    /**
     * El texto del mensaje viaja en {@code message.message}, no en
     * {@code message.description}: ver {@code OhiMessageItem.OhiMessageRef}.
     */
    public static final String NOVEDAD_LINEA = String.join(",",
        "id", "message.code", "message.severity", "message.message", "origin");

    /**
     * Mensajes de una operación de larga duración.
     *
     * <p>{@code message.severity} es lo que separa el fallo del ruido: toda
     * operación deja un informativo ({@code I}) diciendo que escribió su fichero
     * de respuesta, y los fallos de verdad llegan como fatales ({@code F}).
     * {@code value0} es el parámetro que rellena el {@code {0}} del texto del
     * catálogo, o sea el elemento al que se refiere el fallo.
     */
    public static final String MENSAJE_ACTIVIDAD = String.join(",",
        "id", "message.code", "message.severity", "message.message",
        "value0", "value1", "activity.id");

    public static final String SOLO_ID = "id";

    private CamposOhi() {}
}
