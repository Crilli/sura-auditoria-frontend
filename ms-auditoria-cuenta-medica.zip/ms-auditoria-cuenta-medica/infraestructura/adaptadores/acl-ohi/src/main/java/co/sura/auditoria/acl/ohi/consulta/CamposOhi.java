package co.sura.auditoria.acl.ohi.consulta;

/**
 * Proyecciones de campos para las búsquedas en OHI.
 *
 * <p><b>Validación obligatoria antes de producción:</b> estos alias corresponden
 * a los <em>View Objects</em> de OHI, no a las columnas ni al JSON de salida.
 * Cada constante debe verificarse contra {@code /generic/{recurso}/metadata} del
 * ambiente de Sura, incluyendo los registros dinámicos configurados (riesgo #7).
 */
public final class CamposOhi {

    /**
     * Cabecera de la cuenta, para usar con {@code SolicitudBusqueda.cabecera(...)}
     * ({@code excludereferenceresources=true}, para no arrastrar {@code claimLineList}
     * en cuentas grandes).
     *
     * <p><b>{@code person}, {@code claimantProvider} y {@code paymentReceiverProvider}
     * NO van aquí</b>, aunque el dominio los necesite: se confirmó contra OHI que
     * {@code excludereferenceresources} descarta cualquier referencia a otra entidad,
     * sea lista o escalar, sin importar que esté en {@code fields}. Pedirlos en esta
     * proyección no tiene efecto — se resuelven en una segunda consulta sin esa
     * exclusión ({@code referenciasDeLaCabecera} en {@code AdaptadorConsultasOhi}).
     */
    public static final String CABECERA_CUENTA = String.join(",",
        "id", "code", "status", "startDate", "endDate",
        "totalAllowedAmount", "totalCoveredAmount", "totalClaimedAmount",
        // Facturación y radicación (extensión SURA) — confirmados contra
        // /generic/claims/metadata; ver InformacionFacturacion en el dominio.
        "numeroFactura", "receiptDate", "fechaEmisionFactura", "fechaVencimiento",
        "fechaIngresoAtencion", "fechaEgresoAtencion",
        "valorFactura", "valorTotalFactura", "totalValorGlosado", "valorNotaCredito",
        "claseServicio", "acuseRecibido", "radicadoATEP", "multicore", "pendienteManual",
        "internalRemarks", "externalRemarks",
        // La respuesta del prestador a las glosas, con la versión que abrió cada una.
        // Medido el 2026-10-17: viene poblada y trae «versionamiento» con la forma
        // CM-94421-V4, así que VIS-11 no necesita consultar ctrclaims.
        "respuestaGlosa",
        "objectVersionNumber");

    /**
     * {@code person.id} y no {@code person}: con la proyección activa
     * ({@code defaultoverride}) OHI solo devuelve los subcampos que se le pidan, y
     * el afiliado —a diferencia de {@code procedure} o {@code serviceProvider}, que
     * son flex codes con {@code code}— se identifica únicamente por {@code id}.
     * Pedir {@code person} a secas devuelve <code>{}</code> y
     * {@code OhiReferencia.codigoDe} se queda sin nada que leer.
     */
    /**
     * {@code procedure.descr} es la descripción de la prestación y hay que pedirla
     * explícitamente: {@code procedure} a secas devuelve solo
     * <code>{code, flexCodeDefinitionCode, value}</code>. Cobertura medida en
     * producción: 100% de las líneas.
     *
     * <p>{@code person.code} es el documento del afiliado ({@code CC30359313}) y
     * {@code person.id} su identificador interno. Se piden los dos: el nombre se
     * resuelve aparte contra {@code /generic/persons}, que es el único sitio donde
     * OHI lo publica —la línea no lo trae—.
     */
    public static final String RESUMEN_LINEA = String.join(",",
        "id", "sequence", "startDate", "endDate",
        "procedure.code", "procedure.descr", "procedure.flexCodeDefinitionCode",
        "serviceProvider.code", "person.id", "person.code",
        // Los dos siguientes están aquí porque son criterios de búsqueda del
        // listado. `valorGlosado` además es imprescindible traerlo: el sistema
        // de registro no sabe filtrar por ningún importe de la línea, así que
        // solo se puede evaluar sobre la fila ya recibida.
        "authorizationCode", "valorGlosado",
        "allowedAmount", "coveredAmount",
        // La grilla del MVP pide cantidades e IVA además de importes. Los cinco viajan en
        // la misma fila de claimlines, así que no cuestan una consulta más — pero hay que
        // pedirlos: OHI no valida los nombres de `fields` y lo que no se pide llega ausente
        // con HTTP 200 y sin aviso.
        "claimedAmount", "claimedNumberOfUnits", "allowedNumberOfUnits",
        "montoIVACalculado", "porcentajeIVA",
        "keepBenefits", "keepPricing", "locked", "replaced", "objectVersionNumber");

    /**
     * Detalle de la línea: todo lo que el negocio exige ver sin salir de ella.
     *
     * <p>Es deliberadamente más ancha que {@link #RESUMEN_LINEA} —la grilla no
     * necesita convenio ni diagnósticos— y aun así cuesta una sola consulta:
     * todo viaja en la misma fila de {@code claimlines}.
     *
     * <p>Los campos de extensión de Sura solo llegan si se piden; no están en la
     * representación por omisión. Los flex code se piden por {@code .value} y
     * {@code .descriptor}: el descriptor es la etiqueta en castellano.
     */
    public static final String DETALLE_LINEA = String.join(",",
        "id", "sequence", "status", "startDate", "endDate",
        // prestación
        "procedure.code", "procedure.descr", "procedure.flexCodeDefinitionCode",
        "claseServicio.value", "claseServicio.descriptor",
        "prestacionCodigoNoDefinido", "prestacionCodigoNoDefinidoDef",
        "archivoRIPSDescrPrestacion",
        "serviceSpecialty.code", "serviceSpecialty.descr",
        // quién atiende y a quién
        "serviceProvider.code", "serviceProviderName", "person.id", "person.code",
        "authorizationCode",
        // importes y cantidades
        "claimedAmount", "claimedNumberOfUnits",
        "allowedAmount", "allowedNumberOfUnits",
        "coveredAmount", "coveredNumberOfUnits",
        "valorGlosado", "observacionesGlosa",
        // convenio
        "codeTariffISS2001.value", "codeTariffISS2001.descriptor",
        "codeTariffISS2000.value", "codeTariffISS2000.descriptor",
        "codeTariffSOAT.value", "codeTariffSOAT.descriptor",
        "numeroContrato", "homologoCups",
        "multiplesCupsHomologos.value", "multiplesCupsHomologos.descriptor",
        "codigoUnicoContratoSIIFA",
        // atención y siniestro
        "tipoSala.value", "tipoSala.descriptor",
        "viaDeAcceso.value", "viaDeAcceso.descriptor",
        "datosAdicionalesSiniestro.UEN",
        "codigoSiniestro",
        // diagnósticos de la línea
        "claimLineDiagnosisList.sequence",
        "claimLineDiagnosisList.diagnosis.code", "claimLineDiagnosisList.diagnosis.descr",
        "claimLineDiagnosisList.diagnosisType.code", "claimLineDiagnosisList.diagnosisType.descr",
        // desglose de la glosa
        "detallesGlosa.id", "detallesGlosa.valorGlosa", "detallesGlosa.codigoNotaCredito",
        "detallesGlosa.descripcionGenerico", "detallesGlosa.descripcionEspecifico",
        "detallesGlosa.texto",
        // El causal y el importe de la nota crédito. Existían en el contrato desde siempre
        // —leído de /generic/claimlines/definition el 2026-10-17— y esta proyección no los
        // pedía, así que el auditor escribía un causal al glosar y al guardar dejaba de
        // verlo. Medido en producción sobre la línea 169852132331 de CM-118210488404, cuyo
        // desglose trae codigoGlosa «AU0202».
        "detallesGlosa.codigoGlosa", "detallesGlosa.valorNotaCredito",
        // control de edición
        "keepBenefits", "keepPricing", "manualBenefits", "manualPricing",
        "locked", "replaced", "objectVersionNumber");

    /**
     * Nombre del afiliado. OHI compone el nombre colombiano en cuatro campos:
     * {@code firstName} (primer nombre), {@code secondName} (segundo),
     * {@code name} (primer apellido) y {@code middleName} (segundo apellido).
     * {@code namePartner} e {@code initials} llegan siempre vacíos en esta
     * instalación y no se piden.
     *
     * <p>Se pide lo mínimo para identificar al afiliado en la grilla. El recurso
     * publica además fecha de nacimiento y género, que no hacen falta para auditar
     * una línea y por tanto <b>no</b> se traen.
     */
    public static final String AFILIADO = String.join(",",
        "id", "code", "firstName", "secondName", "name", "middleName");

    /**
     * Nombre del prestador. {@code serviceProviderName} de la línea llega
     * <b>siempre vacío</b> (0 de 200 medidas), así que el nombre hay que
     * resolverlo aquí por el código.
     */
    public static final String PRESTADOR = String.join(",", "id", "code", "name");

    /**
     * Cláusulas de tarifación de una línea. De aquí sale el «valor convenido»:
     * la tarifa pactada con el prestador, que no existe como campo de la línea.
     */
    public static final String CLAUSULA_TARIFA = String.join(",",
        "id", "sequence", "amount", "providerPricingClause.descr", "claimLine.id");

    /**
     * {@code pendReason.descr}, no {@code description}: ver la nota de
     * {@code OhiPendReasonItem.OhiPendReasonRef}. Con el nombre anterior la
     * descripción del motivo llegaba vacía y el auditor solo veía el código.
     */
    public static final String PENDIENTE_CABECERA = String.join(",",
        "id", "pendReason.code", "pendReason.descr", "resolved",
        "pendReason.adjudicationOnly", "objectVersionNumber");

    /**
     * Ver la nota de {@link #PENDIENTE_CABECERA} sobre {@code pendReason.descr}.
     *
     * <p>El número de línea es {@code claimLine.sequence}, no {@code lineNumber}:
     * es el mismo nombre que ya documenta {@code OhiClaimLineItem} para la línea
     * suelta. Con {@code lineNumber} llegaba vacío y el pendiente solo podía
     * citar la referencia interna de OHI en vez del número que ve el auditor.
     */
    /**
     * El motivo tal como lo publica el catálogo {@code /generic/pendreasons}.
     *
     * <p>{@code descr} y {@code adjudicationOnly} con esos nombres exactos: los largos
     * —{@code description}, {@code adjudicationOnlyIndicator}— los descarta la proyección en
     * silencio, porque el sistema de registro no valida {@code fields}.
     */
    /**
     * Lo justo para reconocer una cuenta en una lista de resultados.
     *
     * <p>Seis columnas y no la cabecera entera: la lista puede traer cientos de filas, y cada
     * campo de más ensancha una consulta que ya recorre todo el sistema de registro.
     */
    public static final String RESUMEN_CUENTA = String.join(",",
        "id", "code", "status", "numeroFactura", "receiptDate", "valorFactura",
        "claimantProvider");

    /**
     * Una versión del histórico, con su estado.
     *
     * <p>{@code ctrStatusHistoryList} se proyecta con sus subcampos explícitos: pedido a secas
     * devuelve una lista de objetos vacíos —medido—, porque la proyección no desciende sola.
     */
    public static final String VERSION_CUENTA = String.join(",",
        "id", "code", "version", "reversal", "entryDate", "valorFactura",
        "ctrStatusHistoryList.status", "ctrStatusHistoryList.statusDateTime");

    /**
     * La foto de una versión: cabecera, importes y su historial de estados.
     *
     * <p>Los importes de {@code ctrclaims} son <b>números planos</b> con la moneda en un campo
     * aparte ({@code totalAllowedAmount} + {@code totalAllowedAmountCurrency}), no el objeto
     * {@code {currency, value}} de {@code claims}. Mismo nombre, otra forma: decodificarlos
     * con el tipo de {@code claims} los dejaría en nulo sin error.
     */
    public static final String FOTO_VERSION = String.join(",",
        "id", "code", "version", "entryDate", "numeroFactura", "claimantName",
        "valorFactura", "totalClaimedAmount", "totalAllowedAmount", "totalCoveredAmount",
        "totalValorGlosado", "totalValorNotasCredito",
        "ctrStatusHistoryList.status", "ctrStatusHistoryList.statusDateTime");

    public static final String MOTIVO_PENDIENTE_CATALOGO = String.join(",",
        "id", "code", "descr", "adjudicationOnly");

    public static final String PENDIENTE_LINEA = String.join(",",
        "id", "pendReason.code", "pendReason.descr", "resolved",
        "pendReason.adjudicationOnly",
        "claimLine.id", "claimLine.sequence", "objectVersionNumber");

    /**
     * El texto del mensaje viaja en {@code message.message}, no en
     * {@code message.description}: ver {@code OhiMessageItem.OhiMessageRef}.
     *
     * <p>Lleva también quién puso la novedad y cuándo. Eso no es un añadido
     * nuestro: es lo que la propia interfaz de OHI enseña en su tabla, y es lo
     * que hace falta para distinguir lo que puso un compañero de lo que levantó
     * el motor. Los dos campos llegan <b>incluso sin pedirlos</b>, pero se
     * nombran para que la proyección no los pierda el día que eso cambie.
     *
     * <p>Los dos conceptos solo llegan si se piden anidados, y hay mensajes que
     * los traen vacíos, así que la pantalla tiene que aguantar que falten.
     */
    public static final String NOVEDAD_LINEA = String.join(",",
        "id", "message.code", "message.severity", "message.message", "origin",
        "message.conceptoGenerico", "message.conceptoEspecifico", "message.system",
        "createdByUserName", "creationDate",
        // Los «Valor 0»…«Valor 9» completan los marcadores de la plantilla. Sin
        // ellos el texto se pinta con las llaves a la vista, porque OHI devuelve
        // la plantilla sin sustituir: ver TextoDeNovedad.
        "value0", "value1", "value2", "value3", "value4",
        "value5", "value6", "value7", "value8", "value9");

    /**
     * Novedades de la cabecera de la cuenta.
     *
     * <p>Los mismos campos que {@link #NOVEDAD_LINEA} menos {@code claimLine}:
     * la colección de la cabecera no lo tiene, y el recurso de OHI tampoco
     * publica {@code product}, que es la única diferencia entre los dos.
     */
    public static final String NOVEDAD_CUENTA = String.join(",",
        "id", "message.code", "message.severity", "message.message", "origin",
        "message.conceptoGenerico", "message.conceptoEspecifico", "message.system",
        "createdByUserName", "creationDate",
        "value0", "value1", "value2", "value3", "value4",
        "value5", "value6", "value7", "value8", "value9");

    /**
     * El catálogo de mensajes que un auditor puede poner como novedad.
     *
     * <p>{@code message} es el texto —la misma trampa de nombre que arriba— y
     * {@code system} es lo que OHI rotula «Específico de Sistema?»: con eso se
     * descartan los 1.325 que levanta su propio motor.
     */
    public static final String MENSAJE_CATALOGO = String.join(",",
        "id", "code", "message", "severity", "system", "active", "obsolete",
        "conceptoGenerico", "conceptoEspecifico");

    /**
     * Lo mínimo para calcular con qué se puede filtrar una cuenta.
     *
     * <p>Mucho más estrecha que {@link #RESUMEN_LINEA} a propósito: el agregado
     * recorre la cuenta entera —unas 21 consultas en la mayor medida— y no pinta
     * ninguna fila, solo cuenta. Traer la descripción de la prestación, los
     * importes y los indicadores de edición era pagar ancho de banda y tiempo de
     * materialización en OHI por campos que nadie mira.
     */
    public static final String RESUMEN_PARA_FILTROS = String.join(",",
        "id", "person.id", "person.code",
        "procedure.flexCodeDefinitionCode", "startDate", "valorGlosado");

    /**
     * Mensajes de una operación de larga duración.
     *
     * <p>{@code message.severity} es lo que separa el fallo del ruido: toda
     * operación deja un informativo ({@code I}) diciendo que escribió su fichero
     * de respuesta, y los fallos de verdad llegan como fatales ({@code F}).
     * {@code value0} es el parámetro que rellena el {@code {0}} del texto del
     * catálogo, o sea el elemento al que se refiere el fallo.
     */
    public static final String MENSAJE_ACTIVIDAD = String.join(",",
        "id", "message.code", "message.severity", "message.message",
        "value0", "value1", "activity.id");

    public static final String SOLO_ID = "id";

    private CamposOhi() {}
}
