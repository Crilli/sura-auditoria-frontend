package co.sura.auditoria.acl.ohi.externo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Representación de una línea (claimLine) en OHI.
 *
 * <p>Ajustado al contrato real de {@code POST /generic/claimlines/search}:
 * <ul>
 *   <li>el número de línea es {@code sequence}, no {@code lineNumber};</li>
 *   <li>el procedimiento es una referencia anidada, no un código plano;</li>
 *   <li>los importes son objetos con moneda;</li>
 *   <li>los indicadores son booleanos, no los caracteres "Y"/"N";</li>
 *   <li>el afiliado ({@code person}) es propio de la línea: una misma cuenta
 *       puede agrupar líneas de personas distintas.</li>
 * </ul>
 *
 * <p>Los campos de extensión de Sura (los de nombre en castellano y los
 * {@code codeTariff*}) <b>solo llegan si se piden en la proyección</b>: no están
 * en la representación por omisión de OHI. Y los que son flex code
 * ({@code claseServicio}, {@code tipoSala}, {@code viaDeAcceso}…) además
 * <b>no se pueden filtrar</b> en la {@code q} —responden HTTP 500—, cosa que no
 * estorba porque solo se pintan.
 */
public record OhiClaimLineItem(
        Long id,
        Integer sequence,
        String status,
        LocalDate startDate,
        LocalDate endDate,
        OhiReferencia procedure,
        OhiReferencia serviceProvider,
        String serviceProviderName,
        OhiReferencia serviceSpecialty,
        /** Afiliado. Es un atributo de la línea: la cabecera no lo tiene. */
        OhiReferencia person,
        /** Autorización con la que se prestó el servicio. */
        String authorizationCode,

        // ── importes y cantidades ──────────────────────────────────────────
        OhiMonto claimedAmount,
        BigDecimal claimedNumberOfUnits,
        OhiMonto allowedAmount,
        BigDecimal allowedNumberOfUnits,
        OhiMonto coveredAmount,
        BigDecimal coveredNumberOfUnits,
        BigDecimal valorGlosado,
        String observacionesGlosa,

        // ── prestación ─────────────────────────────────────────────────────
        OhiFlexCode claseServicio,
        String prestacionCodigoNoDefinido,
        String prestacionCodigoNoDefinidoDef,
        String archivoRIPSDescrPrestacion,

        // ── convenio ───────────────────────────────────────────────────────
        OhiFlexCode codeTariffISS2001,
        OhiFlexCode codeTariffISS2000,
        OhiFlexCode codeTariffSOAT,
        String numeroContrato,
        String homologoCups,
        OhiFlexCode multiplesCupsHomologos,
        String codigoUnicoContratoSIIFA,

        // ── atención y siniestro ───────────────────────────────────────────
        OhiFlexCode tipoSala,
        OhiFlexCode viaDeAcceso,
        OhiDatosSiniestro datosAdicionalesSiniestro,
        String codigoSiniestro,

        // ── listas ─────────────────────────────────────────────────────────
        List<OhiClaimLineDiagnosis> claimLineDiagnosisList,
        List<OhiDetalleGlosa> detallesGlosa,

        Boolean keepBenefits,
        Boolean keepPricing,
        Boolean manualBenefits,
        Boolean manualPricing,
        Boolean locked,
        Boolean replaced,
        Long objectVersionNumber) {

    /**
     * Datos adicionales del siniestro.
     *
     * <p><b>No es un flex code, es un registro dinámico (DYNR)</b> con subcampos
     * propios: pedirle {@code .value}/{@code .descriptor} devuelve ausente y sin
     * error, que es como se dio por vacío antes. La UEN va en mayúsculas.
     */
    public record OhiDatosSiniestro(@com.fasterxml.jackson.annotation.JsonProperty("UEN") String uen,
                                    OhiFlexCode tipoEventoSiniestro,
                                    OhiFlexCode finTratamiento) {}

    /** Diagnóstico de la línea: código CIE-10 y su tipo. */
    public record OhiClaimLineDiagnosis(Integer sequence,
                                        OhiReferencia diagnosis,
                                        OhiReferencia diagnosisType) {}

    /**
     * Una glosa concreta. {@code descripcionGenerico} y {@code descripcionEspecifico}
     * son la clasificación normativa y {@code texto} la redacción completa.
     */
    public record OhiDetalleGlosa(Long id,
                                  BigDecimal valorGlosa,
                                  String codigoNotaCredito,
                                  String descripcionGenerico,
                                  String descripcionEspecifico,
                                  String texto) {}
}
