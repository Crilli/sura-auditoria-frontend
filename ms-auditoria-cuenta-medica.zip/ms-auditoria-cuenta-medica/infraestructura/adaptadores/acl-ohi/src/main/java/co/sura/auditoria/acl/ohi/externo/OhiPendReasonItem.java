package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

/** Pendiente de cabecera (claimPendReason) en OHI. */
public record OhiPendReasonItem(
        Long id,
        OhiPendReasonRef pendReason,
        Boolean resolved,
        OhiClaimLineRef claimLine,
        Long objectVersionNumber) {

    /**
     * Referencia al motivo del catálogo.
     *
     * <p>El {@code id} es el que OHI espera en las rutas de resolución
     * ({@code /claims/{id}/resolvepend/{idMotivo}}), distinto del id de esta fila.
     *
     * <p><b>Los nombres de OHI son {@code descr} y {@code adjudicationOnly}</b>, no
     * {@code description} ni {@code adjudicationOnlyIndicator}. Se verificó contra
     * {@code /generic/pendreasons} en producción: con los nombres antiguos la
     * proyección los descartaba en silencio —OHI no valida {@code fields}— y el
     * auditor veía el código del motivo sin su texto.
     */
    public record OhiPendReasonRef(
            String id,
            String code,
            @JsonProperty("descr") String descripcion,
            @JsonProperty("adjudicationOnly") Boolean soloAdjudicacion) {}

    /** El número de línea es {@code sequence}, igual que en {@code claimlines}. */
    public record OhiClaimLineRef(Long id,
                                  @JsonProperty("sequence") Integer numeroLinea) {}
}
