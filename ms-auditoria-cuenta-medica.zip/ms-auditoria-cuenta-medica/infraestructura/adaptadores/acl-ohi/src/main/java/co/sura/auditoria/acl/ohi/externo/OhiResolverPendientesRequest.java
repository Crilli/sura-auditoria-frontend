package co.sura.auditoria.acl.ohi.externo;

import java.util.List;

/**
 * Cuerpo de {@code POST /claims/resolvependreasons}, el recurso de OHI que
 * resuelve varios motivos de golpe.
 *
 * <p>La forma está tomada de lo que publica el propio servicio
 * ({@code /claims/resolvependreasons/definition}, esquema
 * {@code resolvependreasonrequest}, y su {@code /create-form}) y contrastada con
 * la documentación de la versión instalada (4.25.1).
 *
 * <p>Tres cosas del contrato que no se adivinan:
 * <ul>
 *   <li>los motivos van por <b>código</b>, no por identificador;</li>
 *   <li>{@code level} solo admite dos valores —son niveles disjuntos, no uno
 *       contenido en el otro— y si se omite vale el de cuenta. Aquí se envía
 *       siempre explícito, y los literales los pone
 *       {@code DiccionarioOhi.desdeNivelPendiente}, que es el único sitio
 *       autorizado a contener vocabulario del sistema externo;</li>
 *   <li>una cuenta sin {@code claimLineList} y con {@code level="claim line"}
 *       resuelve el motivo en <b>todas</b> las líneas aplicables de la cuenta,
 *       que es justo lo que se quiere: el motivo entero.</li>
 * </ul>
 *
 * <p>El recurso acepta varias cuentas a la vez. Aquí se envía siempre una: la
 * pantalla trabaja sobre la cuenta abierta, y mezclar cuentas en una operación
 * haría que un fallo parcial fuera imposible de atribuir desde la interfaz.
 *
 * <p>Los nombres en inglés son correctos: este record vive en la ACL y copia el
 * vocabulario del sistema externo.
 */
public record OhiResolverPendientesRequest(List<CodigoMotivo> pendReasonCodeList,
                                           String level,
                                           List<CuentaConLineas> claimList) {

    public record CodigoMotivo(String code) {}

    /**
     * Una cuenta de la operación.
     *
     * @param claimLineList líneas concretas a las que limitar la resolución.
     *                      {@code null} —no lista vacía— para que alcance todas
     *                      las líneas aplicables.
     */
    public record CuentaConLineas(String id, List<ReferenciaLinea> claimLineList) {}

    public record ReferenciaLinea(String id) {}

    /** Resolución de varios motivos sobre una cuenta entera, sin acotar líneas. */
    public static OhiResolverPendientesRequest deCuentaCompleta(long idCuenta,
                                                                java.util.Collection<String> codigos,
                                                                String nivel) {
        return new OhiResolverPendientesRequest(
                codigos.stream().map(CodigoMotivo::new).toList(),
                nivel,
                List.of(new CuentaConLineas(String.valueOf(idCuenta), null)));
    }
}
