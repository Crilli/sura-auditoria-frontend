package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import co.sura.auditoria.modelo.cuenta.MotivoPendienteCatalogo;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * El catálogo de motivos de pendiente, desde {@code /generic/pendreasons}.
 *
 * <h3>Por qué se recorre y no se pide de un tirón</h3>
 * Porque son <b>237</b> —medido el 2026-10-17 en el entorno de pruebas— y el tope de página
 * del sistema de registro es 200, que no avisa de que hay más: una sola llamada devuelve 200
 * y el selector se quedaría sin 37 motivos sin que nada fallara. Es la misma trampa que ya
 * cortó el recorrido de pendientes de una cuenta.
 *
 * <p>Se recorre por clave ({@code id.gt} con {@code orderBy id asc}, que han de coincidir) y
 * se corta si el cursor no avanza, para que un catálogo raro no se convierta en un bucle.
 *
 * <p><b>Sin filtrar por «ofrecible»</b>, al contrario que el catálogo de mensajes. Allí hay
 * {@code active}, {@code obsolete} y {@code system} para separar lo que una persona puede
 * poner de lo que es del motor; aquí no se ha medido que existan equivalentes, y descartar
 * por un campo que no se ha comprobado escondería motivos legítimos. Si aparecen, este es el
 * sitio.
 */
@Component
public class AdaptadorCatalogoMotivosPendienteOhi implements PuertoCatalogoMotivosPendiente {

    private static final int LOTE = SolicitudBusqueda.LIMITE_MAXIMO;

    /** Con 237 motivos sobran dos lotes; la holgura es para que pueda crecer sin tocar esto. */
    private static final int MAXIMO_LOTES = 20;

    /** Media hora, igual que el catálogo de mensajes y por lo mismo. */
    private static final Duration VIGENCIA = Duration.ofMinutes(30);

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final Mono<List<MotivoPendienteCatalogo>> cache;

    public AdaptadorCatalogoMotivosPendienteOhi(WebClient webClient,
                                                ConfiguracionResiliencia resiliencia,
                                                TraductorErrores traductorErrores) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.cache = Mono.defer(this::recorrer)
                // Solo se guarda un catálogo con algo: un error o una lista vacía se olvidan al
                // momento y la siguiente petición vuelve a preguntar. Con cache(VIGENCIA) a
                // secas, Reactor guardaba también el error 30 minutos (OPE-04).
                .cache(lista -> lista.isEmpty() ? Duration.ZERO : VIGENCIA,
                       error -> Duration.ZERO,
                       () -> Duration.ZERO);
    }

    @Override
    public Mono<List<MotivoPendienteCatalogo>> listar() {
        return cache;
    }

    private Mono<List<MotivoPendienteCatalogo>> recorrer() {
        return siguienteLote(0L, new ArrayList<>(), 0);
    }

    private Mono<List<MotivoPendienteCatalogo>> siguienteLote(
            long cursor, List<MotivoPendienteCatalogo> acumulado, int lote) {

        if (lote >= MAXIMO_LOTES) return Mono.just(List.copyOf(acumulado));

        var consulta = ConstructorConsulta.mayorQue("id", cursor).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.MOTIVO_PENDIENTE_CATALOGO,
                                             "id asc", LOTE, false);

        return webClient.post()
                .uri("/generic/pendreasons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiMotivoPendiente>>() {})
                .transform(resiliencia.paraConsultasMono())
                .flatMap(respuesta -> {
                    if (respuesta.isEmpty()) return Mono.just(List.copyOf(acumulado));

                    var items = respuesta.items();
                    items.stream()
                            .filter(i -> i.code() != null && !i.code().isBlank())
                            .map(AdaptadorCatalogoMotivosPendienteOhi::aDominio)
                            .forEach(acumulado::add);

                    if (items.size() < LOTE) return Mono.just(List.copyOf(acumulado));

                    var ultimo = items.get(items.size() - 1).id();
                    if (ultimo == null || ultimo <= cursor) return Mono.just(List.copyOf(acumulado));
                    return siguienteLote(ultimo, acumulado, lote + 1);
                })
                .defaultIfEmpty(List.copyOf(acumulado));
    }

    private static MotivoPendienteCatalogo aDominio(OhiMotivoPendiente externo) {
        return new MotivoPendienteCatalogo(
                externo.code(), externo.descripcion(),
                Boolean.TRUE.equals(externo.soloAdjudicacion()));
    }

    /**
     * Un motivo tal como lo publica el sistema de registro.
     *
     * <p>{@code descr} y {@code adjudicationOnly}, <b>no</b> {@code description} ni
     * {@code adjudicationOnlyIndicator}: es la misma trampa que ya está documentada en
     * {@code OhiPendReasonItem}, y con los nombres largos la proyección los descarta en
     * silencio porque el sistema de registro no valida {@code fields}.
     */
    private record OhiMotivoPendiente(
            Long id,
            String code,
            @JsonProperty("descr") String descripcion,
            @JsonProperty("adjudicationOnly") Boolean soloAdjudicacion) {}
}
