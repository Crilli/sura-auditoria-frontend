package co.sura.auditoria.acl.ohi.traductor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.sura.auditoria.acl.ohi.externo.OhiErrorBody;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

/**
 * Traduce las respuestas de error de OHI a errores de dominio.
 *
 * <p>Los códigos {@code CLA-*} son más precisos que el estado HTTP:
 * tienen prioridad en la traducción.
 *
 * <p>Los literales en inglés dentro de este traductor son correctos:
 * viven en la ACL y reflejan el vocabulario del sistema externo.
 */
@Component
public class TraductorErrores {

    private static final Logger log = LoggerFactory.getLogger(TraductorErrores.class);

    private final ObjectMapper jackson;

    public TraductorErrores(ObjectMapper jackson) {
        this.jackson = jackson;
    }

    /**
     * Traduce la respuesta de error de OHI.
     *
     * <p>El cuerpo se lee <b>una sola vez</b> como texto y se interpreta después:
     * un {@code ClientResponse} no admite dos lecturas, y OHI no siempre responde
     * JSON —ante una ruta inexistente devuelve una página {@code text/html}—.
     * Interpretarlo directamente como {@link OhiErrorBody} hacía fallar la
     * traducción y el error real salía como un 500 del microservicio.
     */
    public Mono<Throwable> traducir(ClientResponse respuesta) {
        var estado = respuesta.statusCode();
        var tipo = respuesta.headers().contentType().map(Object::toString).orElse("sin tipo");

        return respuesta.bodyToMono(String.class)
                .defaultIfEmpty("")
                .map(texto -> mapear(estado, interpretar(texto, estado, tipo)));
    }

    /** Convierte el cuerpo en {@link OhiErrorBody}; si no es JSON, devuelve uno vacío. */
    private OhiErrorBody interpretar(String texto, HttpStatusCode estado, String tipo) {
        if (texto == null || texto.isBlank()) return OhiErrorBody.vacio();
        try {
            return jackson.readValue(texto, OhiErrorBody.class);
        } catch (Exception e) {
            log.warn("OHI respondió {} con un cuerpo que no es JSON ({}): {}",
                     estado, tipo, texto.length() > 200 ? texto.substring(0, 200) + "…" : texto);
            return OhiErrorBody.vacio();
        }
    }

    private Throwable mapear(HttpStatusCode estado, OhiErrorBody cuerpo) {
        var codigo = cuerpo.primerCodigo();

        return switch (codigo) {
            case "CLA-CLAI-035" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.PendientesBloqueanEnvio(cuerpo.sujeto(), -1));

            case "CLA-IP-CLAI-023" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.SinPermiso("resolver pendientes",
                    "No tiene privilegios para resolver estos pendientes. "
                  + "No se aplicó ningún cambio en la cuenta."));

            case "CLA-IP-CLAI-024" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.AccionNoDisponible(cuerpo.sujeto(), "ENVIAR"));

            case "CLA-IP-SUBC-001" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.AccionNoDisponible(cuerpo.sujeto(),
                    "ENVIAR (cuenta de gran cuantía no soportada)"));

            case "CLA-IP-SBMT-001", "CLA-IP-SBMT-002",
                 "CLA-IP-SBMT-003", "CLA-IP-SBMT-004" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.DecisionEnvioInvalida(traducirMensajeEnvio(codigo)));

            default -> mapearPorEstado(estado, cuerpo);
        };
    }

    private String traducirMensajeEnvio(String codigo) {
        return switch (codigo) {
            case "CLA-IP-SBMT-001" -> "Denegar exige el código de una novedad bloqueante";
            case "CLA-IP-SBMT-002" -> "El código de novedad bloqueante no existe";
            case "CLA-IP-SBMT-003" -> "Al aceptar solo se admiten novedades informativas";
            case "CLA-IP-SBMT-004" -> "El código de novedad es desconocido";
            default -> "La decisión de envío no es válida";
        };
    }

    private Throwable mapearPorEstado(HttpStatusCode estado, OhiErrorBody cuerpo) {
        if (estado.value() == 403 && cuerpo.mencionaLimiteAprobacion())
            return ExcepcionDeDominio.de(
                new ErrorDeDominio.LimiteAprobacionExcedido(cuerpo.sujeto()));

        if (estado.value() == 403)
            return ExcepcionDeDominio.de(
                new ErrorDeDominio.SinPermiso("operación en el sistema de registro",
                    "No tiene permisos para ejecutar esta operación"));

        if (estado.value() == 409)
            return ExcepcionDeDominio.de(
                new ErrorDeDominio.ModificacionConcurrente("cuenta", -1));

        // Sin variante propia para "recurso no encontrado en OHI" (distinta de
        // CuentaNoEncontrada/LineaNoEncontrada, que son del dominio, no del externo).
        // Se reporta como solicitud inválida (400): el mismo criterio que usa el
        // simulador local para "pendiente inexistente", así que el contrato de
        // error es igual sin importar el perfil.
        if (estado.value() == 404)
            return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "El sistema de registro no encontró el recurso solicitado"
              + (cuerpo.sujeto().isBlank() ? "" : ": " + cuerpo.sujeto())));

        return ExcepcionDeDominio.de(
            new ErrorDeDominio.SistemaRegistroNoDisponible(
                "Respuesta " + estado.value() + " del sistema de cuentas"));
    }
}
