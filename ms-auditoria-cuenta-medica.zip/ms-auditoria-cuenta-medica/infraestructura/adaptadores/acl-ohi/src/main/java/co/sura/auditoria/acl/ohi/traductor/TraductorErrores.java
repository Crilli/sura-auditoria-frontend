package co.sura.auditoria.acl.ohi.traductor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.sura.auditoria.acl.ohi.externo.OhiErrorBody;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

/**
 * Traduce las respuestas de error de OHI a errores de dominio.
 *
 * <p>Los códigos {@code CLA-*} son más precisos que el estado HTTP:
 * tienen prioridad en la traducción.
 *
 * <p>Los literales en inglés dentro de este traductor son correctos:
 * viven en la ACL y reflejan el vocabulario del sistema externo.
 */
@Component
public class TraductorErrores {

    private static final Logger log = LoggerFactory.getLogger(TraductorErrores.class);

    private final ObjectMapper jackson;

    public TraductorErrores(ObjectMapper jackson) {
        this.jackson = jackson;
    }

    /**
     * Traduce la respuesta de error de OHI.
     *
     * <p>El cuerpo se lee <b>una sola vez</b> como texto y se interpreta después:
     * un {@code ClientResponse} no admite dos lecturas, y OHI no siempre responde
     * JSON —ante una ruta inexistente devuelve una página {@code text/html}—.
     * Interpretarlo directamente como {@link OhiErrorBody} hacía fallar la
     * traducción y el error real salía como un 500 del microservicio.
     */
    public Mono<Throwable> traducir(ClientResponse respuesta) {
        var estado = respuesta.statusCode();
        var tipo = respuesta.headers().contentType().map(Object::toString).orElse("sin tipo");

        return respuesta.bodyToMono(String.class)
                .defaultIfEmpty("")
                .map(texto -> conEstado(mapear(estado, interpretar(texto, estado, tipo)),
                                        estado.value()));
    }

    /**
     * Le pone al error el código HTTP con el que respondió OHI.
     *
     * <p>El circuit breaker lo necesita para no contar como caída lo que fue una respuesta
     * de negocio (OPE-01). Ver {@link RespuestaDeErrorOhi}.
     */
    private static Throwable conEstado(Throwable error, int estado) {
        return error instanceof co.sura.auditoria.modelo.error.ExcepcionDeDominio dominio
                ? new RespuestaDeErrorOhi(dominio.error(), estado)
                : error;
    }

    /** Convierte el cuerpo en {@link OhiErrorBody}; si no es JSON, devuelve uno vacío. */
    private OhiErrorBody interpretar(String texto, HttpStatusCode estado, String tipo) {
        if (texto == null || texto.isBlank()) return OhiErrorBody.vacio();
        try {
            return jackson.readValue(texto, OhiErrorBody.class);
        } catch (Exception e) {
            log.warn("OHI respondió {} con un cuerpo que no es JSON ({}): {}",
                     estado, tipo, texto.length() > 200 ? texto.substring(0, 200) + "…" : texto);
            return OhiErrorBody.vacio();
        }
    }

    private Throwable mapear(HttpStatusCode estado, OhiErrorBody cuerpo) {
        var codigo = cuerpo.primerCodigo();

        return switch (codigo) {
            case "CLA-CLAI-035" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.PendientesBloqueanEnvio(cuerpo.sujeto(), -1));

            case "CLA-IP-CLAI-023" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.SinPermiso("resolver pendientes",
                    "No tiene privilegios para resolver estos pendientes. "
                  + "No se aplicó ningún cambio en la cuenta."));

            // Los fallos de validación de la resolución conjunta
            // (POST /claims/resolvependreasons). Llegan en la respuesta de la
            // propia petición, no en la operación de larga duración: cuando uno
            // de estos salta, la operación no se abre siquiera, así que no hay
            // nada aplicado que advertir.
            case "CLA-IP-RPND-006" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.SinPermiso("resolver pendientes",
                    "No tiene privilegios sobre alguno de los motivos seleccionados. "
                  + "No se aplicó ningún cambio en la cuenta."));

            // 002 es «la cuenta no existe», que el dominio ya sabe nombrar; sin
            // esta rama caía en mapearPorEstado y salía como un 503 de sistema.
            case "CLA-IP-RPND-002" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.CuentaNoEncontrada(cuerpo.sujeto()));

            case "CLA-IP-RPND-001", "CLA-IP-RPND-003", "CLA-IP-RPND-004",
                 "CLA-IP-RPND-005", "CLA-IP-RPND-007",
                 "CLA-IP-RPND-008", "CLA-IP-RPND-009" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.DecisionEnvioInvalida(
                    co.sura.auditoria.acl.ohi.DiccionarioOhi
                            .explicacionDeFalloDeResolucion(codigo)
                  + ". No se aplicó ningún cambio en la cuenta."));

            case "CLA-IP-CLAI-024" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.AccionNoDisponible(cuerpo.sujeto(), "ENVIAR"));

            // Medido el 2026-10-17: poner un motivo de pendiente que la línea YA TIENE
            // responde así, y da igual que el que tiene esté resuelto. No es un fallo del
            // sistema ni de permisos; es una regla suya, y el auditor necesita leerla como
            // tal en vez de como «el sistema no está disponible».
            case "GEN-ORA-00001" -> ExcepcionDeDominio.de(
                    new ErrorDeDominio.DecisionEnvioInvalida(
                            "Ese motivo de pendiente ya está puesto donde se intentó agregar. "
                          + "El sistema de registro no admite repetirlo, ni siquiera cuando el "
                          + "que hay ya está resuelto"));

            case "CLA-IP-SUBC-001" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.AccionNoDisponible(cuerpo.sujeto(),
                    "ENVIAR (cuenta de gran cuantía no soportada)"));

            case "CLA-IP-SBMT-001", "CLA-IP-SBMT-002",
                 "CLA-IP-SBMT-003", "CLA-IP-SBMT-004" -> ExcepcionDeDominio.de(
                new ErrorDeDominio.DecisionEnvioInvalida(traducirMensajeEnvio(codigo)));

            default -> mapearPorEstado(estado, cuerpo);
        };
    }

    private String traducirMensajeEnvio(String codigo) {
        return switch (codigo) {
            case "CLA-IP-SBMT-001" -> "Denegar exige el código de una novedad bloqueante";
            case "CLA-IP-SBMT-002" -> "El código de novedad bloqueante no existe";
            case "CLA-IP-SBMT-003" -> "Al aceptar solo se admiten novedades informativas";
            case "CLA-IP-SBMT-004" -> "El código de novedad es desconocido";
            default -> "La decisión de envío no es válida";
        };
    }

    private Throwable mapearPorEstado(HttpStatusCode estado, OhiErrorBody cuerpo) {
        if (estado.value() == 403 && cuerpo.mencionaLimiteAprobacion())
            return ExcepcionDeDominio.de(
                new ErrorDeDominio.LimiteAprobacionExcedido(cuerpo.sujeto()));

        if (estado.value() == 403)
            return ExcepcionDeDominio.de(
                new ErrorDeDominio.SinPermiso("operación en el sistema de registro",
                    "No tiene permisos para ejecutar esta operación"));

        if (estado.value() == 409)
            return ExcepcionDeDominio.de(
                new ErrorDeDominio.ModificacionConcurrente("cuenta", -1));

        // Una línea concreta del parche. Va antes del caso general porque el 422 que la
        // nombra y el 422 que no son cosas distintas: con la línea señalada se puede quitar
        // esa y reintentar el resto; sin ella, el problema es de la cuenta y reintentar es
        // gastar llamadas para obtener el mismo error. Ver OhiErrorBody.indiceDeLineaRechazada.
        var indiceRechazado = cuerpo.indiceDeLineaRechazada();
        if (indiceRechazado.isPresent())
            return ExcepcionDeDominio.de(new ErrorDeDominio.LineaDelLoteRechazada(
                    indiceRechazado.getAsInt(),
                    cuerpo.sujeto().isBlank() ? "El sistema de registro la rechazó"
                                              : cuerpo.sujeto()));

        // Sin variante propia para "recurso no encontrado en OHI" (distinta de
        // CuentaNoEncontrada/LineaNoEncontrada, que son del dominio, no del externo).
        // Se reporta como solicitud inválida (400): el mismo criterio que usa el
        // entorno de pruebas para "pendi inexistente", así que el contrato de
        // error es igual sin importar el perfil.
        if (estado.value() == 404)
            return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "El sistema de registro no encontró el recurso solicitado"
              + (cuerpo.sujeto().isBlank() ? "" : ": " + cuerpo.sujeto())));

        return ExcepcionDeDominio.de(
            new ErrorDeDominio.SistemaRegistroNoDisponible(
                "Respuesta " + estado.value() + " del sistema de cuentas"));
    }
}
