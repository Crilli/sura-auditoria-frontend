package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;

/**
 * Un error de dominio que nació de una respuesta HTTP de error del sistema de registro, y
 * que recuerda con qué código respondió.
 *
 * <h3>Por qué hace falta recordarlo</h3>
 * El dominio no distingue un 503 de OHI de un 400 que el traductor no sabía clasificar: los
 * dos acaban en {@link ErrorDeDominio.SistemaRegistroNoDisponible}, y para el auditor está
 * bien. Pero el circuit breaker sí tiene que distinguirlos: el primero es una caída y el
 * segundo una respuesta. Sin el código, la única opción era contar las dos —que es lo que
 * pasaba, y por eso un conflicto de un usuario podía cortar a los demás— o no contar
 * ninguna. Ver {@code FalloDeDisponibilidadOhi} (OPE-01).
 *
 * <p>Sigue siendo una {@link ExcepcionDeDominio}: el resto del servicio no nota la
 * diferencia.
 */
public final class RespuestaDeErrorOhi extends ExcepcionDeDominio {

    private final int estadoHttp;

    public RespuestaDeErrorOhi(ErrorDeDominio error, int estadoHttp) {
        super(error);
        this.estadoHttp = estadoHttp;
    }

    /** El código HTTP con el que respondió el sistema de registro. */
    public int estadoHttp() {
        return estadoHttp;
    }

    /** Lo que se lee en el log de un 5xx: de dónde vino el error. */
    @Override
    public String toString() {
        return "respuesta HTTP " + estadoHttp + " del sistema de registro";
    }
}
