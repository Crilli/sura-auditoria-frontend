package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Un mensaje de una operación de larga duración
 * ({@code POST /generic/activitymessages/search}).
 *
 * <p>Es donde está el detalle de los fallos parciales. OHI publica cómo
 * buscarlos en el propio enlace {@code rel: operator:messages} de la operación:
 * <pre>
 * q = activity.id.eq(N).or.(activity.rootActivityId.eq(N))
 * </pre>
 * El {@code rootActivityId} no es opcional: la operación padre reparte el
 * trabajo en actividades hijas ({@code RESOLVE_PEND_CHILD}) y los fallos los
 * reporta la hija, no el padre. Comprobado en producción: en una operación
 * {@code CB}, el mensaje del padre era solo el aviso de que se creó el fichero
 * de respuesta, y los dos {@code CLA-IP-RPND-003} colgaban de una hija.
 *
 * <p>La proyección tiene que pedir {@code message.code} explícitamente: con
 * {@code message} a secas llega el objeto vacío —el mismo defecto de siempre con
 * los campos anidados de OHI—. El elemento al que se refiere el fallo viene en
 * {@code value0}, que es el parámetro que rellena el {@code {0}} del texto del
 * catálogo.
 */
public record OhiMensajeActividad(String id,
                                  String severity,
                                  OhiMessageItem.OhiMessageRef message,
                                  String value0,
                                  String value1,
                                  @JsonProperty("activity") OhiReferencia actividad) {

    /** El código del catálogo de mensajes, o cadena vacía si no vino. */
    public String codigo() {
        return message == null || message.code() == null ? "" : message.code();
    }

    /** El elemento al que apunta el mensaje, o cadena vacía. */
    public String elemento() {
        return value0 == null ? "" : value0;
    }

    /**
     * Si es ruido de la mecánica de ficheros y no un fallo de la resolución.
     *
     * <p>Toda operación {@code RESOLVE_PEND} deja un {@code ACT-FL-DAFI-001}
     * —«se creó el conjunto de archivos de respuesta»—, también las que salen
     * limpias. Contarlo como fallo convertiría cualquier resolución en «parcial».
     */
    public boolean esRuido() {
        return codigo().startsWith("ACT-FL-") || codigo().startsWith("GEN-FILE-");
    }
}
