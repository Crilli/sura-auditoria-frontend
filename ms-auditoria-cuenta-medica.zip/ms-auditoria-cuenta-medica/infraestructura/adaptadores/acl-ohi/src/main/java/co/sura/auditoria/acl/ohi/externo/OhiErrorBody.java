package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Cuerpo de error de OHI.
 *
 * <p>Los nombres reales del contrato llevan dos puntos —{@code o:errorDetails},
 * {@code o:errorCode}—, que no son identificadores válidos en Java. Sin los
 * {@code @JsonProperty} el cuerpo se deserializa vacío y los códigos {@code CLA-*}
 * no se reconocen nunca.
 *
 * <p>Ejemplo real:
 * <pre>{"o:errorDetails":[{"o:errorCode":"GEN-HTTP-015","title":"…","o:errorPath":"$"}]}</pre>
 */
public record OhiErrorBody(
        String title,
        String detail,
        @JsonProperty("o:errorDetails") List<OhiErrorInstance> errorDetails) {

    public record OhiErrorInstance(
            @JsonProperty("o:errorCode") String errorCode,
            @JsonProperty("o:errorPath") String errorPath,
            String title,
            String detail) {}

    public static OhiErrorBody vacio() {
        return new OhiErrorBody(null, null, List.of());
    }

    /** Primer código de error informado, o cadena vacía si no hay ninguno. */
    public String primerCodigo() {
        if (errorDetails == null || errorDetails.isEmpty()) return "";
        var codigo = errorDetails.get(0).errorCode();
        return codigo != null ? codigo : "";
    }

    /**
     * Texto con el que OHI describe el error. Se usa para componer el mensaje que
     * ve el auditor, así que se toma el más específico disponible.
     */
    public String sujeto() {
        if (detail != null) return detail;
        if (title != null)  return title;
        if (errorDetails != null && !errorDetails.isEmpty()) {
            var primero = errorDetails.get(0);
            if (primero.title() != null)  return primero.title();
            if (primero.detail() != null) return primero.detail();
        }
        return "";
    }

    /** OHI menciona el límite de aprobación en el mensaje de error en inglés. */
    public boolean mencionaLimiteAprobacion() {
        return sujeto().toLowerCase().contains("authorized limit");
    }
}
