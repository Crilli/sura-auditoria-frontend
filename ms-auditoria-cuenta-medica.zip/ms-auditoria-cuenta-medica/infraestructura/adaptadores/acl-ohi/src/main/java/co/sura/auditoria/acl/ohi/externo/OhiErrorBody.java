package co.sura.auditoria.acl.ohi.externo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Cuerpo de error de OHI.
 *
 * <p>Los nombres reales del contrato llevan dos puntos —{@code o:errorDetails},
 * {@code o:errorCode}—, que no son identificadores válidos en Java. Sin los
 * {@code @JsonProperty} el cuerpo se deserializa vacío y los códigos {@code CLA-*}
 * no se reconocen nunca.
 *
 * <p>Ejemplo real:
 * <pre>{"o:errorDetails":[{"o:errorCode":"GEN-HTTP-015","title":"…","o:errorPath":"$"}]}</pre>
 */
public record OhiErrorBody(
        String title,
        String detail,
        @JsonProperty("o:errorDetails") List<OhiErrorInstance> errorDetails) {

    public record OhiErrorInstance(
            @JsonProperty("o:errorCode") String errorCode,
            @JsonProperty("o:errorPath") String errorPath,
            String title,
            String detail) {}

    public static OhiErrorBody vacio() {
        return new OhiErrorBody(null, null, List.of());
    }

    /** Primer código de error informado, o cadena vacía si no hay ninguno. */
    public String primerCodigo() {
        if (errorDetails == null || errorDetails.isEmpty()) return "";
        var codigo = errorDetails.get(0).errorCode();
        return codigo != null ? codigo : "";
    }

    /**
     * Texto con el que OHI describe el error. Se usa para componer el mensaje que
     * ve el auditor, así que se toma el más específico disponible.
     */
    public String sujeto() {
        if (detail != null) return detail;
        if (title != null)  return title;
        if (errorDetails != null && !errorDetails.isEmpty()) {
            var primero = errorDetails.get(0);
            if (primero.title() != null)  return primero.title();
            if (primero.detail() != null) return primero.detail();
        }
        return "";
    }

    /**
     * Qué línea del parche rechazó, si el error apunta a una.
     *
     * <p>Medido el 2026-10-17 contra el entorno de pruebas: un parche de varias líneas con
     * una inválida responde <b>422 y no aplica nada</b> —es atómico— y el error trae
     * {@code "o:errorPath": "$.claimLineList[1]"} o, si el problema está más adentro,
     * {@code "$.claimLineList[1].claimLineMessageList[0].message"}. En los dos casos el
     * primer índice es la posición de la línea dentro del parche enviado.
     *
     * <p>Cuando el problema es de la cuenta y no de una línea —el conflicto de versión, por
     * ejemplo— el camino es {@code "$"} y aquí no hay nada que devolver. La diferencia
     * importa: con índice se puede quitar esa línea y reintentar el resto; sin él,
     * reintentar es gastar llamadas para obtener el mismo error.
     *
     * @return la posición empezando en cero, o vacío si el error no es de una línea
     */
    public java.util.OptionalInt indiceDeLineaRechazada() {
        if (errorDetails == null) return java.util.OptionalInt.empty();
        for (var detalle : errorDetails) {
            var camino = detalle.errorPath();
            if (camino == null) continue;
            var m = CAMINO_DE_LINEA.matcher(camino);
            if (m.find()) return java.util.OptionalInt.of(Integer.parseInt(m.group(1)));
        }
        return java.util.OptionalInt.empty();
    }

    private static final java.util.regex.Pattern CAMINO_DE_LINEA =
            java.util.regex.Pattern.compile("^\\$\\.claimLineList\\[(\\d+)\\]");

    /** OHI menciona el límite de aprobación en el mensaje de error en inglés. */
    public boolean mencionaLimiteAprobacion() {
        return sujeto().toLowerCase().contains("authorized limit");
    }
}
