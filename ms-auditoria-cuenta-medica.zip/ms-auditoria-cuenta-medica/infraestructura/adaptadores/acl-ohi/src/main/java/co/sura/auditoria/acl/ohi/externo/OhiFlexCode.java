package co.sura.auditoria.acl.ohi.externo;

/**
 * Código dinámico ("flexfield") de OHI: {@code claseServicio}, {@code radicadoATEP},
 * {@code multicore}, {@code pendienteManual}.
 *
 * <p>OHI los publica como {@code {"flexCodeDefinitionCode":…, "value":"S", "descriptor":"Sí"}}.
 * {@code value} es el código corto (una letra, típicamente "S"/"N") y
 * {@code descriptor} es la etiqueta legible que ya trae el catálogo en español —
 * es la que se expone al dominio, para no tener que adivinar la codificación
 * exacta de {@code value} en cada instalación.
 */
public record OhiFlexCode(String value, String descriptor) {

    /** Texto para mostrar: el descriptor legible, o el código crudo si no hay descriptor. */
    public static String textoDe(OhiFlexCode flex) {
        if (flex == null) return null;
        return flex.descriptor() != null ? flex.descriptor() : flex.value();
    }
}
