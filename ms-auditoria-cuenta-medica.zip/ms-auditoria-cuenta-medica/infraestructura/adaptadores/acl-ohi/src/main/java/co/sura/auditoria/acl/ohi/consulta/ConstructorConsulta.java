package co.sura.auditoria.acl.ohi.consulta;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Constructor tipado del DSL de consulta de OHI.
 *
 * <p>Evita concatenación de cadenas ad hoc, cuyos errores de sintaxis solo se
 * manifiestan en ejecución con mensajes poco descriptivos del sistema externo.
 * Toda expresión construida aquí se valida implícitamente por el sistema de tipos.
 *
 * <p>Ejemplo de uso:
 * <pre>
 *   ConstructorConsulta.igual("code", "GT-106586883036")
 *       .yIgual("resolved", false)
 *       .construir();
 *   // → "code.eq('GT-106586883036').and.resolved.eq(false)"
 * </pre>
 */
public final class ConstructorConsulta {

    private final StringBuilder expresion = new StringBuilder();

    private ConstructorConsulta(String inicial) {
        expresion.append(inicial);
    }

    public static ConstructorConsulta igual(String campo, String valor) {
        return new ConstructorConsulta("%s.eq('%s')".formatted(campo, escapar(valor)));
    }

    public static ConstructorConsulta igual(String campo, long valor) {
        return new ConstructorConsulta("%s.eq(%d)".formatted(campo, valor));
    }

    public static ConstructorConsulta igual(String campo, boolean valor) {
        return new ConstructorConsulta("%s.eq(%b)".formatted(campo, valor));
    }

    public static ConstructorConsulta contenidoEn(String campo, List<String> valores) {
        var lista = valores.stream()
                .map(v -> "'" + escapar(v) + "'")
                .collect(Collectors.joining(","));
        return new ConstructorConsulta("%s.in(%s)".formatted(campo, lista));
    }

    /**
     * Pertenencia a un conjunto de identificadores.
     * Los ids de OHI son numéricos, así que van sin comillas.
     */
    public static ConstructorConsulta contenidoEnIds(String campo, List<Long> valores) {
        var lista = valores.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));
        return new ConstructorConsulta("%s.in(%s)".formatted(campo, lista));
    }

    public ConstructorConsulta y(ConstructorConsulta otra) {
        expresion.append(".and.").append(otra.expresion);
        return this;
    }

    /**
     * Alternativa: {@code a.eq(1).or.(b.eq(1))}.
     *
     * <p>El paréntesis del operando derecho no es cosmético: es la forma en que
     * OHI publica sus propias consultas alternativas —el enlace
     * {@code operator:messages} de una operación de larga duración trae
     * literalmente {@code activity.id.eq(N).or.(activity.rootActivityId.eq(N))}—
     * y sin él la precedencia frente a un {@code .and.} anterior queda al azar.
     */
    public ConstructorConsulta o(ConstructorConsulta otra) {
        expresion.append(".or.(").append(otra.expresion).append(')');
        return this;
    }

    public ConstructorConsulta yMayorQue(String campo, long valor) {
        expresion.append(".and.%s.gt(%d)".formatted(campo, valor));
        return this;
    }

    public ConstructorConsulta yMenorQue(String campo, long valor) {
        expresion.append(".and.%s.lt(%d)".formatted(campo, valor));
        return this;
    }

    public ConstructorConsulta yIgual(String campo, boolean valor) {
        expresion.append(".and.%s.eq(%b)".formatted(campo, valor));
        return this;
    }

    public ConstructorConsulta yIgual(String campo, String valor) {
        expresion.append(".and.%s.eq('%s')".formatted(campo, escapar(valor)));
        return this;
    }

    /** @return la expresión DSL lista para incluir en la solicitud de búsqueda. */
    public String construir() {
        return expresion.toString();
    }

    private static String escapar(String valor) {
        return valor.replace("'", "''");
    }
}
