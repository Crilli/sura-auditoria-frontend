package co.sura.auditoria.acl.ohi.consulta;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Constructor tipado del DSL de consulta de OHI.
 *
 * <p>Evita concatenación de cadenas ad hoc, cuyos errores de sintaxis solo se
 * manifiestan en ejecución con mensajes poco descriptivos del sistema externo.
 * Toda expresión construida aquí se valida implícitamente por el sistema de tipos.
 *
 * <p>Ejemplo de uso:
 * <pre>
 *   ConstructorConsulta.igual("code", "GT-106586883036")
 *       .yIgual("resolved", false)
 *       .construir();
 *   // → "code.eq('GT-106586883036').and.resolved.eq(false)"
 * </pre>
 */
public final class ConstructorConsulta {

    private final StringBuilder expresion = new StringBuilder();

    private ConstructorConsulta(String inicial) {
        expresion.append(inicial);
    }

    public static ConstructorConsulta igual(String campo, String valor) {
        return new ConstructorConsulta("%s.eq('%s')".formatted(campo, escapar(valor)));
    }

    public static ConstructorConsulta igual(String campo, long valor) {
        return new ConstructorConsulta("%s.eq(%d)".formatted(campo, valor));
    }

    public static ConstructorConsulta igual(String campo, boolean valor) {
        return new ConstructorConsulta("%s.eq(%b)".formatted(campo, valor));
    }

    public static ConstructorConsulta contenidoEn(String campo, List<String> valores) {
        var lista = valores.stream()
                .map(v -> "'" + escapar(v) + "'")
                .collect(Collectors.joining(","));
        return new ConstructorConsulta("%s.in(%s)".formatted(campo, lista));
    }

    /**
     * Pertenencia a un conjunto de identificadores.
     * Los ids de OHI son numéricos, así que van sin comillas.
     */
    public static ConstructorConsulta contenidoEnIds(String campo, List<Long> valores) {
        var lista = valores.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));
        return new ConstructorConsulta("%s.in(%s)".formatted(campo, lista));
    }

    public ConstructorConsulta y(ConstructorConsulta otra) {
        expresion.append(".and.").append(otra.expresion);
        return this;
    }

    /**
     * Alternativa: {@code a.eq(1).or.(b.eq(1))}.
     *
     * <p>El paréntesis del operando derecho no es cosmético: es la forma en que
     * OHI publica sus propias consultas alternativas —el enlace
     * {@code operator:messages} de una operación de larga duración trae
     * literalmente {@code activity.id.eq(N).or.(activity.rootActivityId.eq(N))}—
     * y sin él la precedencia frente a un {@code .and.} anterior queda al azar.
     */
    public ConstructorConsulta o(ConstructorConsulta otra) {
        expresion.append(".or.(").append(otra.expresion).append(')');
        return this;
    }

    /** Primer criterio «mayor que», para arrancar un recorrido por clave sin otro filtro. */
    public static ConstructorConsulta mayorQue(String campo, long valor) {
        return new ConstructorConsulta("%s.gt(%d)".formatted(campo, valor));
    }

    public ConstructorConsulta yMayorQue(String campo, long valor) {
        expresion.append(".and.%s.gt(%d)".formatted(campo, valor));
        return this;
    }

    public ConstructorConsulta yMenorQue(String campo, long valor) {
        expresion.append(".and.%s.lt(%d)".formatted(campo, valor));
        return this;
    }

    public ConstructorConsulta yIgual(String campo, boolean valor) {
        expresion.append(".and.%s.eq(%b)".formatted(campo, valor));
        return this;
    }

    public ConstructorConsulta yIgual(String campo, String valor) {
        expresion.append(".and.%s.eq('%s')".formatted(campo, escapar(valor)));
        return this;
    }

    // ── Operadores para los filtros del listado de líneas ────────────────────
    //
    // Todos verificados contra producción el 13-oct-2026 sobre una cuenta de
    // 4.063 líneas, y reconciliados: `startDate.gte('2025-10-03')` da 3.774 y
    // `lte` del mismo día 431; los 142 del día solapado se cuentan en los dos,
    // y 3.774 + 431 − 142 = 4.063. El catálogo de operadores de OHI está en
    // docs/ohi/02-api-y-lenguaje-de-consulta.md.

    /**
     * Comparación de texto <b>sin distinguir mayúsculas</b>.
     *
     * <p>Para lo que teclea el auditor —una cédula, un código— exigirle la caja
     * exacta es hacerle fallar la búsqueda por un detalle que no conoce: en el
     * sistema de registro las cédulas van como {@code CC43973184}. Medido:
     * {@code person.code.eqic('cc43973184')} devuelve las mismas 4.063 filas que
     * la forma en mayúsculas.
     */
    public ConstructorConsulta yIgualSinCaja(String campo, String valor) {
        expresion.append(".and.%s.eqic('%s')".formatted(campo, escapar(valor)));
        return this;
    }

    /**
     * Igualdad con un número, sin comillas.
     *
     * <p>Comprobado contra el sistema de registro que acepta las dos formas —{@code eq(101)}
     * y {@code eq('101')}— para un campo numérico, pero se manda sin comillas porque es lo
     * que el campo es.
     */
    public ConstructorConsulta yIgual(String campo, int valor) {
        expresion.append(".and.%s.eq(%d)".formatted(campo, valor));
        return this;
    }

    /** Desde, incluido, para un número. Ver {@link #yDesdeNumero} sobre por qué sin comillas. */
    public ConstructorConsulta yDesdeNumero(String campo, java.math.BigDecimal valor) {
        expresion.append(".and.%s.gte(%s)".formatted(campo, valor.toPlainString()));
        return this;
    }

    /** Hasta, incluido, para un número. */
    public ConstructorConsulta yHastaNumero(String campo, java.math.BigDecimal valor) {
        expresion.append(".and.%s.lte(%s)".formatted(campo, valor.toPlainString()));
        return this;
    }

    /** Desde, incluido. Vale para fechas ({@code 'yyyy-MM-dd'}) y para texto. */
    public ConstructorConsulta yDesde(String campo, String valor) {
        expresion.append(".and.%s.gte('%s')".formatted(campo, escapar(valor)));
        return this;
    }

    /** Hasta, incluido. */
    public ConstructorConsulta yHasta(String campo, String valor) {
        expresion.append(".and.%s.lte('%s')".formatted(campo, escapar(valor)));
        return this;
    }

    /**
     * Empieza por, sin distinguir mayúsculas.
     *
     * <p>El {@code %} lo pone este método: que lo escriba quien llama invita a
     * que un valor del usuario con un {@code %} dentro cambie la consulta. Lo que
     * llegue se escapa como literal.
     */
    public ConstructorConsulta yEmpiezaPor(String campo, String prefijo) {
        expresion.append(".and.%s.likeic('%s%%')".formatted(campo, escaparComodines(prefijo)));
        return this;
    }

    /** Pertenencia a un conjunto de textos, encadenable con {@code .and.}. */
    public ConstructorConsulta yContenidoEn(String campo, List<String> valores) {
        var lista = valores.stream().map(v -> "'" + escapar(v) + "'").collect(Collectors.joining(","));
        expresion.append(".and.%s.in(%s)".formatted(campo, lista));
        return this;
    }

    /** @return la expresión DSL lista para incluir en la solicitud de búsqueda. */
    public String construir() {
        return expresion.toString();
    }

    private static String escapar(String valor) {
        return valor.replace("'", "''");
    }

    /**
     * Además de la comilla, neutraliza los comodines de {@code like}.
     *
     * <p>Sin esto, un valor del usuario con {@code %} o {@code _} dentro deja de
     * ser un prefijo y pasa a ser un patrón: buscar «100%» traería cualquier cosa
     * que empiece por 100.
     */
    private static String escaparComodines(String valor) {
        return escapar(valor).replace("%", "\\%").replace("_", "\\_");
    }
}
