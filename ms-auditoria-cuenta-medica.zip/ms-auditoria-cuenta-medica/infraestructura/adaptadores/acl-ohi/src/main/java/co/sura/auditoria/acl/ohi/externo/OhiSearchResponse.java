package co.sura.auditoria.acl.ohi.externo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

// ─── DTOs EXTERNOS — EN INGLÉS DELIBERADAMENTE ──────────────────────────────
// Estos records reflejan el contrato de la API de OHI Claims sin interpretarlo.
// El vocabulario en inglés es correcto y esperado aquí.

/** Respuesta genérica de POST /generic/{recurso}/search. */
public record OhiSearchResponse<T>(
        List<T> items,
        Long totalResults,
        /**
         * Si queda algo después de esta página.
         *
         * <p>Lo dice el propio sistema de registro cuando se pagina por
         * desplazamiento, y es más de fiar que deducirlo del total: con un
         * filtro que él no sabe aplicar, el total cuenta de más y la resta
         * saldría mal.
         */
        Boolean hasMore,
        List<OhiLink> links) {



    public boolean isEmpty() { return items == null || items.isEmpty(); }
    public Optional<T> first() { return isEmpty() ? Optional.empty() : Optional.of(items.get(0)); }

    /**
     * Si queda algo después de esta página, con lo que haya para saberlo.
     *
     * <p>Primero {@code hasMore}, que el sistema de registro publica al paginar por
     * desplazamiento —comprobado: {@code true} hasta la última página y {@code false} en
     * ella—; si faltara, el total; y si tampoco, que la página venga llena, que es lo único que
     * queda. Estaba copiado tal cual en dos adaptadores antes de que lo necesitara un tercero.
     *
     * @param desde     el desplazamiento con que se pidió la página
     * @param devueltas cuántas filas trajo
     * @param tamano    cuántas se pidieron
     */
    public boolean hayMas(int desde, int devueltas, int tamano) {
        if (hasMore != null) return hasMore;
        if (totalResults != null) return desde + devueltas < totalResults;
        return devueltas >= tamano;
    }

    /** Respuesta vacía: la forma que le da sentido a un {@code 204 No Content} de OHI. */
    public static <T> OhiSearchResponse<T> vacio() {
        return new OhiSearchResponse<>(List.of(), 0L, false, List.of());
    }
}
