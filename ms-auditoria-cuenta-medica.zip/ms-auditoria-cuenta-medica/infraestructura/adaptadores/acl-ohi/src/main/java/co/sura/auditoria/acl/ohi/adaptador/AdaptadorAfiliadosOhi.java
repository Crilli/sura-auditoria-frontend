package co.sura.auditoria.acl.ohi.adaptador;

import co.sura.auditoria.acl.ohi.consulta.CamposOhi;
import co.sura.auditoria.acl.ohi.consulta.ConstructorConsulta;
import co.sura.auditoria.acl.ohi.consulta.SolicitudBusqueda;
import co.sura.auditoria.acl.ohi.externo.OhiPersonItem;
import co.sura.auditoria.acl.ohi.externo.OhiSearchResponse;
import co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia;
import co.sura.auditoria.acl.ohi.traductor.TraductorErrores;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Nombres de los afiliados.
 *
 * <p>La línea solo trae la referencia al afiliado ({@code person.id} y
 * {@code person.code}, el documento); el nombre vive únicamente en
 * {@code /generic/persons}, así que hace falta una consulta aparte. Se resuelve
 * por lote —una sola llamada por página de la grilla, no una por línea— y se
 * cachea, porque una cuenta suele repetir el mismo afiliado en todas sus líneas
 * y el auditor pagina adelante y atrás sobre la misma cuenta.
 *
 * <p><b>El nombre es decorativo: si no se puede resolver, la pantalla se pinta
 * igual.</b> Cualquier fallo aquí devuelve un mapa vacío en vez de propagar el
 * error, para que un problema del padrón no deje al auditor sin su grilla de
 * líneas, que es lo que de verdad necesita para trabajar.
 *
 * <p>Medido en producción: un lote de 25 afiliados (una página de la grilla)
 * tarda ~0,45 s, y uno de 200 ~0,53 s.
 */
@Profile("!local")   // en perfil local lo sustituye el módulo simulador
@Component
public class AdaptadorAfiliadosOhi {

    private static final Logger log = LoggerFactory.getLogger(AdaptadorAfiliadosOhi.class);

    /** Tope de valores que admite un {@code in(...)} de OHI. */
    private static final int TAMANO_LOTE = 200;

    private final WebClient webClient;
    private final ConfiguracionResiliencia resiliencia;
    private final TraductorErrores traductorErrores;
    private final Cache<String, String> nombres;

    public AdaptadorAfiliadosOhi(WebClient webClient,
                                 ConfiguracionResiliencia resiliencia,
                                 TraductorErrores traductorErrores,
                                 @Value("${integraciones.ohi.cache-afiliados.expiracion:30m}")
                                 Duration expiracion,
                                 @Value("${integraciones.ohi.cache-afiliados.maximo:20000}")
                                 long maximo) {
        this.webClient = webClient;
        this.resiliencia = resiliencia;
        this.traductorErrores = traductorErrores;
        this.nombres = Caffeine.newBuilder()
                .expireAfterWrite(expiracion)
                .maximumSize(maximo)
                .build();
    }

    /**
     * Nombres de los afiliados indicados, por identificador interno de OHI.
     *
     * <p>Se resuelve por {@code person.id} y no por el documento: el id es el que
     * la línea trae siempre y es la clave natural del padrón. Los que ya están en
     * caché no se vuelven a pedir.
     *
     * @param idsAfiliado identificadores de {@code person.id}; admite nulos y repetidos
     * @return mapa id → nombre completo. Sin entrada para los que OHI no resuelva
     */
    public Mono<Map<String, String>> nombresPorId(Collection<String> idsAfiliado) {
        if (idsAfiliado == null || idsAfiliado.isEmpty()) return Mono.just(Map.of());

        var resueltos = new HashMap<String, String>();
        var pendientes = new ArrayList<String>();
        idsAfiliado.stream().filter(id -> id != null && !id.isBlank()).distinct().forEach(id -> {
            var enCache = nombres.getIfPresent(id);
            if (enCache != null) resueltos.put(id, enCache);
            else pendientes.add(id);
        });
        if (pendientes.isEmpty()) return Mono.just(Map.copyOf(resueltos));

        return Flux.fromIterable(enLotes(pendientes))
                .concatMap(this::buscarLote)
                .reduce(resueltos, (acumulado, lote) -> {
                    acumulado.putAll(lote);
                    return acumulado;
                })
                .map(Map::copyOf);
    }

    private Mono<HashMap<String, String>> buscarLote(List<String> ids) {
        var consulta = ConstructorConsulta.contenidoEn("id", ids).construir();
        var solicitud = SolicitudBusqueda.de(consulta, CamposOhi.AFILIADO, null,
                                             SolicitudBusqueda.limitarAlMaximo(ids.size()), false);

        return webClient.post()
                .uri("/generic/persons/search")
                .bodyValue(solicitud)
                .retrieve()
                .onStatus(s -> s.isError(), traductorErrores::traducir)
                .bodyToMono(new ParameterizedTypeReference<OhiSearchResponse<OhiPersonItem>>() {})
                // OHI responde 204 sin cuerpo cuando la búsqueda no tiene resultados.
                .defaultIfEmpty(OhiSearchResponse.vacio())
                .transform(resiliencia.paraConsultasMono())
                .map(respuesta -> {
                    var lote = new HashMap<String, String>();
                    if (respuesta.isEmpty()) return lote;
                    for (var persona : respuesta.items()) {
                        var nombre = persona.nombreCompleto();
                        if (persona.id() != null && nombre != null) {
                            lote.put(persona.id(), nombre);
                            nombres.put(persona.id(), nombre);
                        }
                    }
                    return lote;
                })
                // El nombre adorna; la grilla tiene que pintarse aunque el padrón falle.
                .onErrorResume(error -> {
                    log.warn("No se pudo resolver el nombre de {} afiliados: {}",
                             ids.size(), error.toString());
                    return Mono.just(new HashMap<String, String>());
                });
    }

    private static List<List<String>> enLotes(List<String> ids) {
        var lotes = new ArrayList<List<String>>();
        for (int i = 0; i < ids.size(); i += TAMANO_LOTE) {
            lotes.add(ids.subList(i, Math.min(i + TAMANO_LOTE, ids.size())));
        }
        return lotes;
    }
}
