package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiInstante;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.Severidad;
import org.springframework.stereotype.Component;

/** Traduce novedades OHI (claimLineMessage) al modelo de dominio. */
@Component
public class TraductorNovedad {

    /**
     * Texto con el que se pinta una novedad cuyo mensaje no se puede resolver.
     * Se dice en la pantalla en lugar de dejarla en blanco: una novedad sin
     * mensaje es un dato roto en el sistema de registro, y esconderla haría
     * creer que la línea tiene una novedad menos.
     */
    private static final String SIN_MENSAJE = "(novedad sin mensaje en el catálogo)";

    /**
     * <p><b>La referencia al mensaje puede venir nula.</b> No es una hipótesis:
     * en UAT hay novedades manuales —creadas en 2025 y todavía vivas— cuyo
     * {@code message} llega vacío, seguramente porque el mensaje del catálogo
     * desapareció después. Antes esto se leía sin comprobarlo y la consulta de
     * la línea entera se caía con un {@code NullPointerException} por una sola
     * novedad huérfana.
     */
    public Novedad aDominio(OhiMessageItem externo) {
        var autor = externo.createdByUserName();
        var fecha = OhiInstante.aInstante(externo.creationDate());
        var mensaje = externo.message();

        var valores = externo.valoresPorIndice();

        if (mensaje == null) {
            return new Novedad(externo.id(), null, SIN_MENSAJE, Severidad.DESCONOCIDA,
                               externo.origin(), null, null, autor, fecha, false, valores);
        }
        return new Novedad(
                externo.id(),
                mensaje.code(),
                mensaje.descripcion(),
                DiccionarioOhi.aSeveridad(mensaje.severity()),
                externo.origin(),
                aClasificacion(mensaje.conceptoGenerico()),
                aClasificacion(mensaje.conceptoEspecifico()),
                autor,
                fecha,
                Boolean.TRUE.equals(mensaje.system()),
                valores);
    }

    /**
     * Traduce un concepto normativo, que OHI publica como flex code.
     *
     * <p>Se conservan <b>los dos</b>, código y descripción, y no solo el texto
     * legible como hace {@link OhiFlexCode#textoDe}: en este catálogo conviven
     * dos sistemas de codificación —uno de letras ({@code TA · TARIFAS}) y uno
     * numérico ({@code 2 · Tarifas}, {@code 23 · Tarifas})— y hay descripciones
     * repetidas entre ellos. Quedarse solo con la descripción juntaría grupos
     * que no son el mismo.
     */
    private static Novedad.Clasificacion aClasificacion(OhiFlexCode flex) {
        if (flex == null) return null;
        return new Novedad.Clasificacion(flex.value(), flex.descriptor());
    }
}
