package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiMessageItem;
import co.sura.auditoria.modelo.cuenta.Novedad;
import org.springframework.stereotype.Component;

/** Traduce novedades OHI (claimLineMessage) al modelo de dominio. */
@Component
public class TraductorNovedad {

    public Novedad aDominio(OhiMessageItem externo) {
        return new Novedad(
                externo.id(),
                externo.message().code(),
                externo.message().descripcion(),
                DiccionarioOhi.aSeveridad(externo.message().severity()),
                externo.origin());
    }
}
