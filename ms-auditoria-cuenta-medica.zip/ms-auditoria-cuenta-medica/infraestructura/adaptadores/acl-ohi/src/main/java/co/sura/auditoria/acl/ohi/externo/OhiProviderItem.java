package co.sura.auditoria.acl.ohi.externo;

/**
 * Prestador (provider) en OHI.
 *
 * <p>Se trae solo el nombre: es lo único que falta en la línea, que ya publica
 * el código. El recurso expone bastante más (direcciones, contactos), que no
 * hace falta para auditar y por tanto no se pide.
 */
public record OhiProviderItem(String id, String code, String name) {}
