package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.externo.OhiClaseServicio;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiMonto;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiClaimItem;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.modelo.cuenta.*;
import org.springframework.stereotype.Component;

import java.util.List;

/** Traduce una cuenta OHI (claim) al modelo de dominio. */
@Component
public class TraductorCuenta {

    private final TraductorPendiente traductorPendiente;
    private final TraductorNovedad traductorNovedad;

    public TraductorCuenta(TraductorPendiente traductorPendiente,
                           TraductorNovedad traductorNovedad) {
        this.traductorPendiente = traductorPendiente;
        this.traductorNovedad = traductorNovedad;
    }

    /**
     * @param prestadorFacturacionNit NIT del prestador que radica la factura, ya
     *                               resuelto aparte (ver {@code referenciasDeLaCabecera}
     *                               en el adaptador: el propio {@code externo} nunca lo
     *                               trae, porque la consulta de cabecera excluye las
     *                               referencias para no arrastrar las líneas).
     * @param pagarAPrestadorNit    NIT del prestador de pago, misma razón que arriba.
     */
    public CuentaMedica aDominio(OhiClaimItem externo,
                                 List<OhiPendReasonItem> pendientesExternos,
                                 List<co.sura.auditoria.acl.ohi.externo.OhiMessageItem> novedadesExternas,
                                 String prestadorFacturacionNit,
                                 String prestadorFacturacionNombre,
                                 String pagarAPrestadorNit,
                                 String pagarAPrestadorNombre) {
        return new CuentaMedica(
                new CodigoCuenta(externo.code()),
                DiccionarioOhi.aEstado(externo.status()),
                externo.startDate(),
                externo.endDate(),
                OhiMonto.valorDe(externo.totalAllowedAmount()),
                OhiMonto.valorDe(externo.totalCoveredAmount()),
                new Version(externo.objectVersionNumber()),
                pendientesExternos.stream()
                        .map(traductorPendiente::aDominioCabecera)
                        .toList(),
                novedadesExternas.stream()
                        .map(traductorNovedad::aDominio)
                        .toList(),
                aInformacionFacturacion(externo, prestadorFacturacionNit,
                                        prestadorFacturacionNombre, pagarAPrestadorNit,
                                        pagarAPrestadorNombre),
                aRespuestasGlosa(externo));
    }

    /**
     * Las respuestas del prestador a las glosas, ordenadas por cuándo llegaron.
     *
     * <p>Se ordena aquí y no se confía en el orden del sistema de registro: lo que la pantalla
     * enseña es una secuencia temporal, y que venga ordenada es una casualidad medida, no un
     * contrato. Las que no traen fecha van al final, porque no se puede situarlas.
     */
    private static java.util.List<RespuestaGlosa> aRespuestasGlosa(OhiClaimItem externo) {
        if (externo.respuestaGlosa() == null) return java.util.List.of();
        return externo.respuestaGlosa().stream()
                .map(r -> new RespuestaGlosa(r.numeroSecuencia(), r.versionamiento(),
                                             r.valor(), r.fechaLlegada(), r.fechaVencimiento()))
                .sorted(java.util.Comparator.comparing(
                        RespuestaGlosa::fechaLlegada,
                        java.util.Comparator.nullsLast(java.util.Comparator.naturalOrder())))
                .toList();
    }

    private InformacionFacturacion aInformacionFacturacion(OhiClaimItem externo,
                                                           String prestadorFacturacionNit,
                                                           String prestadorFacturacionNombre,
                                                           String pagarAPrestadorNit,
                                                           String pagarAPrestadorNombre) {
        return new InformacionFacturacion(
                prestadorFacturacionNit,
                prestadorFacturacionNombre,
                externo.numeroFactura(),
                externo.code(),
                externo.receiptDate(),
                externo.fechaEmisionFactura(),
                externo.fechaVencimiento(),
                externo.fechaIngresoAtencion(),
                externo.fechaEgresoAtencion(),
                externo.valorFactura(),
                externo.valorTotalFactura(),
                OhiMonto.valorDe(externo.totalClaimedAmount()),
                null,   // totalConvenido: sin fuente en OHI, ver javadoc de InformacionFacturacion
                externo.totalValorGlosado(),
                externo.valorNotaCredito(),
                OhiClaseServicio.textoDe(externo.claseServicio()),
                externo.acuseRecibido(),
                OhiFlexCode.textoDe(externo.radicadoATEP()),
                OhiFlexCode.textoDe(externo.multicore()),
                OhiFlexCode.textoDe(externo.pendienteManual()),
                externo.internalRemarks(),
                externo.externalRemarks(),
                pagarAPrestadorNit,
                pagarAPrestadorNombre);
    }
}
