package co.sura.auditoria.acl.ohi.traductor;

import co.sura.auditoria.acl.ohi.externo.OhiClaseServicio;
import co.sura.auditoria.acl.ohi.externo.OhiFlexCode;
import co.sura.auditoria.acl.ohi.externo.OhiMonto;

import co.sura.auditoria.acl.ohi.DiccionarioOhi;
import co.sura.auditoria.acl.ohi.externo.OhiClaimItem;
import co.sura.auditoria.acl.ohi.externo.OhiPendReasonItem;
import co.sura.auditoria.modelo.cuenta.*;
import org.springframework.stereotype.Component;

import java.util.List;

/** Traduce una cuenta OHI (claim) al modelo de dominio. */
@Component
public class TraductorCuenta {

    private final TraductorPendiente traductorPendiente;

    public TraductorCuenta(TraductorPendiente traductorPendiente) {
        this.traductorPendiente = traductorPendiente;
    }

    /**
     * @param prestadorFacturacionNit NIT del prestador que radica la factura, ya
     *                               resuelto aparte (ver {@code referenciasDeLaCabecera}
     *                               en el adaptador: el propio {@code externo} nunca lo
     *                               trae, porque la consulta de cabecera excluye las
     *                               referencias para no arrastrar las líneas).
     * @param pagarAPrestadorNit    NIT del prestador de pago, misma razón que arriba.
     */
    public CuentaMedica aDominio(OhiClaimItem externo,
                                 List<OhiPendReasonItem> pendientesExternos,
                                 String prestadorFacturacionNit,
                                 String pagarAPrestadorNit) {
        return new CuentaMedica(
                new CodigoCuenta(externo.code()),
                DiccionarioOhi.aEstado(externo.status()),
                externo.startDate(),
                externo.endDate(),
                OhiMonto.valorDe(externo.totalAllowedAmount()),
                OhiMonto.valorDe(externo.totalCoveredAmount()),
                new Version(externo.objectVersionNumber()),
                pendientesExternos.stream()
                        .map(traductorPendiente::aDominioCabecera)
                        .toList(),
                aInformacionFacturacion(externo, prestadorFacturacionNit, pagarAPrestadorNit));
    }

    private InformacionFacturacion aInformacionFacturacion(OhiClaimItem externo,
                                                           String prestadorFacturacionNit,
                                                           String pagarAPrestadorNit) {
        return new InformacionFacturacion(
                prestadorFacturacionNit,
                externo.numeroFactura(),
                externo.code(),
                externo.receiptDate(),
                externo.fechaEmisionFactura(),
                externo.fechaVencimiento(),
                externo.fechaIngresoAtencion(),
                externo.fechaEgresoAtencion(),
                externo.valorFactura(),
                externo.valorTotalFactura(),
                OhiMonto.valorDe(externo.totalClaimedAmount()),
                null,   // totalConvenido: sin fuente en OHI, ver javadoc de InformacionFacturacion
                externo.totalValorGlosado(),
                externo.valorNotaCredito(),
                OhiClaseServicio.textoDe(externo.claseServicio()),
                externo.acuseRecibido(),
                OhiFlexCode.textoDe(externo.radicadoATEP()),
                OhiFlexCode.textoDe(externo.multicore()),
                OhiFlexCode.textoDe(externo.pendienteManual()),
                externo.internalRemarks(),
                externo.externalRemarks(),
                pagarAPrestadorNit);
    }
}
