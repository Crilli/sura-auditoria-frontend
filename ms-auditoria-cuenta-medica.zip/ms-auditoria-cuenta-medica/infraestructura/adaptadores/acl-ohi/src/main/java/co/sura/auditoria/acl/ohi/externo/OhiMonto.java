package co.sura.auditoria.acl.ohi.externo;

import java.math.BigDecimal;

/**
 * Importe monetario de OHI: {@code {"currency":"COP","value":29919}}.
 *
 * <p>OHI no devuelve escalares para los montos sino este objeto con su moneda.
 * El dominio solo maneja el valor —la moneda es única por instalación—, así que
 * la conversión se resuelve aquí y no se propaga hacia adentro.
 */
public record OhiMonto(String currency, BigDecimal value) {

    /**
     * Valor del importe, o {@code null} si OHI no lo informó.
     *
     * <p>Nulo y no cero, desde el 2026-10-21: un importe que falta no es un importe de cero.
     * Una línea negada no trae {@code allowedAmount} —medido: ninguna de las 60 de
     * CM-29939061906 V8— y leerlo como cero pintaba «convenido $0» donde lo correcto es una
     * raya. Además dejaba la cuenta viva en desacuerdo con la foto de versión, que lee números
     * planos y ya conservaba el nulo. Quien sume o reste estos importes tiene que tratar el
     * nulo; es el precio de no afirmar un cero que el sistema de registro no dijo.
     *
     * <p>Antes se llamaba {@code valorDe} y devolvía cero; se renombró para que ningún sitio
     * que contara con el cero siguiera compilando sin enterarse del cambio.
     */
    public static BigDecimal valorONulo(OhiMonto monto) {
        return monto == null ? null : monto.value();
    }
}
