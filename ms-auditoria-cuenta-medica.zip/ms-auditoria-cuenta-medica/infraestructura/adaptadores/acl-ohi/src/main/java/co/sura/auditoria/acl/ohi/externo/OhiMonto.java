package co.sura.auditoria.acl.ohi.externo;

import java.math.BigDecimal;

/**
 * Importe monetario de OHI: {@code {"currency":"COP","value":29919}}.
 *
 * <p>OHI no devuelve escalares para los montos sino este objeto con su moneda.
 * El dominio solo maneja el valor —la moneda es única por instalación—, así que
 * la conversión se resuelve aquí y no se propaga hacia adentro.
 */
public record OhiMonto(String currency, BigDecimal value) {

    /** Valor del importe, o cero si OHI no lo informó. */
    public static BigDecimal valorDe(OhiMonto monto) {
        return monto == null || monto.value() == null ? BigDecimal.ZERO : monto.value();
    }
}
