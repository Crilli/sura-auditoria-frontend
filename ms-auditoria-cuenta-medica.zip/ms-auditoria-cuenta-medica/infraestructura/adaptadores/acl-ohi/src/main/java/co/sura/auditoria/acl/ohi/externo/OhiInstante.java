package co.sura.auditoria.acl.ohi.externo;

import java.time.Instant;
import java.time.OffsetDateTime;

/**
 * Marca de tiempo de OHI.
 *
 * <p>No es un escalar: OHI la publica envuelta, como
 * {@code {"value": "2026-10-15T08:34:23.637-05:00"}}, y su propia definición la
 * declara como el tipo {@code TimestampObject}. Leerla como cadena suelta deja
 * el campo en nulo sin dar error.
 *
 * <p>El desplazamiento viene en el propio valor —Bogotá, {@code -05:00}— así que
 * se interpreta como {@link OffsetDateTime} y se normaliza a {@link Instant}: el
 * dominio no tiene por qué cargar con la zona del sistema de registro.
 */
public record OhiInstante(String value) {

    /** @return el instante, o {@code null} si no vino o no se puede interpretar. */
    public static Instant aInstante(OhiInstante envuelto) {
        if (envuelto == null || envuelto.value() == null || envuelto.value().isBlank()) {
            return null;
        }
        try {
            return OffsetDateTime.parse(envuelto.value()).toInstant();
        } catch (java.time.format.DateTimeParseException e) {
            // Una fecha que no se entiende no debe tumbar la consulta de la
            // línea entera: se pierde el «cuándo» y se pinta el resto.
            return null;
        }
    }
}
