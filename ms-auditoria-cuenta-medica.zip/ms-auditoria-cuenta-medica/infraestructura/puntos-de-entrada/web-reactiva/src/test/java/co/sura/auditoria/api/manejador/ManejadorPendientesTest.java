package co.sura.auditoria.api.manejador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.api.dto.SolicitudAgregarPendiente;
import co.sura.auditoria.api.dto.SolicitudResolverEnMasa;
import co.sura.auditoria.api.dto.SolicitudResolverPendiente;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ListarPendientesCasoDeUso;
import co.sura.auditoria.casodeuso.ResolverPendientesCasoDeUso;
import co.sura.auditoria.casodeuso.ResolverPendientesCasoDeUso.Alcance;
import co.sura.auditoria.casodeuso.ResolverPendientesEnMasaCasoDeUso;
import co.sura.auditoria.casodeuso.ResumirMotivosPendientesCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.NivelResolucion;
import co.sura.auditoria.modelo.cuenta.Pagina;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import co.sura.auditoria.modelo.cuenta.Version;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ManejadorPendientes")
class ManejadorPendientesTest {

    private static final String CODIGO = "CM-108800618430";
    private static final String AUTOR = "auditor@sura.com.co";

    @Mock ListarPendientesCasoDeUso listar;
    @Mock ResumirMotivosPendientesCasoDeUso resumirMotivos;
    @Mock ResolverPendientesCasoDeUso resolver;
    @Mock ResolverPendientesEnMasaCasoDeUso resolverEnMasa;
    @Mock ValidadorSolicitudes validador;
    @Mock co.sura.auditoria.casodeuso.AgregarMotivoPendienteCasoDeUso agregar;
    @Mock ServerRequest solicitud;
    @Mock ServerRequest.Headers cabeceras;

    @InjectMocks ManejadorPendientes manejador;

    @Captor ArgumentCaptor<FiltroBloqueo> bloqueoCaptor;
    @Captor ArgumentCaptor<Cursor> cursorCaptor;
    @Captor ArgumentCaptor<NivelResolucion> nivelCaptor;
    @SuppressWarnings("rawtypes")
    @Captor ArgumentCaptor<Set> motivosCaptor;
    @Captor ArgumentCaptor<Boolean> resueltosCaptor;
    @Captor ArgumentCaptor<co.sura.auditoria.modelo.cuenta.SeleccionLineas> seleccionCaptor;

    private static MotivoPendiente pendiente(NivelPendiente nivel, boolean soloAdjudicacion) {
        return new MotivoPendiente(42L, "AUD01", "Auditoría médica", false, soloAdjudicacion,
                nivel, nivel == NivelPendiente.LINEA ? new ReferenciaLinea(99L) : null,
                nivel == NivelPendiente.LINEA ? 3 : null, new Version(2L));
    }

    private void rutaYParametros() {
        when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
        for (var p : List.of("cursor", "tamano", "motivo", "bloqueo")) {
            lenient().when(solicitud.queryParam(p)).thenReturn(Optional.empty());
        }
    }

    private void parametro(String nombre, String valor) {
        lenient().when(solicitud.queryParam(nombre)).thenReturn(Optional.of(valor));
    }

    private void conAuditor() {
        when(solicitud.headers()).thenReturn(cabeceras);
        when(cabeceras.firstHeader("X-Auditor")).thenReturn(AUTOR);
    }

    private static void esperarEstado(Mono<ServerResponse> resultado, HttpStatus estado) {
        StepVerifier.create(resultado)
                .assertNext(r -> assertThat(r.statusCode()).isEqualTo(estado))
                .verifyComplete();
    }

    @Nested
    @DisplayName("listarSinResolver")
    class Listar {

        private void devuelvePagina(EstadoCuenta estado, MotivoPendiente... pendientes) {
            var pagina = Pagina.construir(List.of(pendientes), 25, 1L,
                    p -> p.identificador());
            when(listar.ejecutar(any(), any(), anyInt(), any(), any(), anyBoolean()))
                    .thenReturn(Mono.just(new PaginaPendientes(pagina, estado)));
        }

        @Test
        @DisplayName("sin parámetros arranca en la primera página, tamaño 25 y sin filtrar bloqueo")
        void sinParametrosUsaLosPredeterminados() {
            rutaYParametros();
            devuelvePagina(EstadoCuenta.MODIFICACION);

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), cursorCaptor.capture(), eq(25), eq(null),
                    bloqueoCaptor.capture(), anyBoolean());
            assertThat(cursorCaptor.getValue()).isEqualTo(Cursor.PRIMERA_PAGINA);
            assertThat(bloqueoCaptor.getValue()).isEqualTo(FiltroBloqueo.TODOS);
        }

        @Test
        @DisplayName("recoge cursor, tamaño y motivo de la consulta")
        void recogeLosParametros() {
            rutaYParametros();
            parametro("cursor", "77");
            parametro("tamano", "10");
            parametro("motivo", "AUD01");
            devuelvePagina(EstadoCuenta.MODIFICACION);

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), cursorCaptor.capture(), eq(10), eq("AUD01"), any(), anyBoolean());
            assertThat(cursorCaptor.getValue().ultimaReferencia()).isEqualTo(77L);
        }

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({"TODOS, TODOS", "bloqueantes, BLOQUEANTES",
                    "  NO_BLOQUEANTES  , NO_BLOQUEANTES"})
        @DisplayName("el filtro de bloqueo se reconoce sin distinguir mayúsculas ni espacios")
        void elFiltroDeBloqueoSeReconoceFlexible(String entrada, FiltroBloqueo esperado) {
            rutaYParametros();
            parametro("bloqueo", entrada);
            devuelvePagina(EstadoCuenta.MODIFICACION);

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), any(), anyInt(), any(), bloqueoCaptor.capture(), anyBoolean());
            assertThat(bloqueoCaptor.getValue()).isEqualTo(esperado);
        }

        @Test
        @DisplayName("un bloqueo en blanco cae al predeterminado en vez de explotar")
        void unBloqueoEnBlancoCaeAlPredeterminado() {
            rutaYParametros();
            parametro("bloqueo", "   ");
            devuelvePagina(EstadoCuenta.MODIFICACION);

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), any(), anyInt(), any(), bloqueoCaptor.capture(), anyBoolean());
            assertThat(bloqueoCaptor.getValue()).isEqualTo(FiltroBloqueo.TODOS);
        }

        @Test
        @DisplayName("un bloqueo inventado enumera los admitidos")
        void unBloqueoInventadoEnumeraLosAdmitidos() {
            rutaYParametros();
            parametro("bloqueo", "CASI");

            assertThatThrownBy(() -> manejador.listarSinResolver(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("TODOS, BLOQUEANTES o NO_BLOQUEANTES")
                    .hasMessageContaining("CASI");
        }

        @Test
        @DisplayName("la marca de bloqueante se calcula CON el estado de la cuenta, no se inventa")
        void laMarcaDeBloqueanteSeCalculaConElEstado() {
            // El mismo pendiente —solo de adjudicación— bloquea en ADJUDICACION_MANUAL
            // y no bloquea en MODIFICACION. Es lo que la pantalla pinta en rojo.
            rutaYParametros();
            devuelvePagina(EstadoCuenta.ADJUDICACION_MANUAL,
                    pendiente(NivelPendiente.CABECERA, true));

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);
        }

        @Test
        @DisplayName("un pendiente de línea viaja con su referencia y su número")
        void unPendienteDeLineaViajaConSuReferencia() {
            rutaYParametros();
            devuelvePagina(EstadoCuenta.MODIFICACION, pendiente(NivelPendiente.LINEA, false));

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);
        }
    }

    @Nested
    @DisplayName("resumirMotivos")
    class ResumirMotivos {

        @Test
        @DisplayName("devuelve la lista de motivos con sus conteos")
        void devuelveLaListaDeMotivos() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(resumirMotivos.ejecutar(any())).thenReturn(Flux.just(
                    new ResumenMotivoPendiente("AUD01", "Auditoría", 3, 7, true, false, true)));

            esperarEstado(manejador.resumirMotivos(solicitud), HttpStatus.OK);
        }

        @Test
        @DisplayName("sin motivos responde 200 con lista vacía, no 404")
        void sinMotivosRespondeListaVacia() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(resumirMotivos.ejecutar(any())).thenReturn(Flux.empty());

            esperarEstado(manejador.resumirMotivos(solicitud), HttpStatus.OK);
        }
    }

    @Nested
    @DisplayName("resolver uno")
    class ResolverUno {

        @Test
        @DisplayName("responde 204: resolver no devuelve cuerpo")
        void respondeSinContenido() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("motivo")).thenReturn("4242");
            conAuditor();
            var dto = new SolicitudResolverPendiente("Soportes completos", "CUENTA_Y_LINEAS");
            when(solicitud.bodyToMono(SolicitudResolverPendiente.class))
                    .thenReturn(Mono.just(dto));
            when(resolver.ejecutar(any(), anyLong(), any(), any(), any()))
                    .thenReturn(Mono.empty());

            esperarEstado(manejador.resolver(solicitud), HttpStatus.NO_CONTENT);

            verify(validador).validar(dto);
            verify(resolver).ejecutar(eq(new CodigoCuenta(CODIGO)), eq(4242L),
                    eq(Alcance.CUENTA_Y_LINEAS), eq("Soportes completos"), eq(AUTOR));
        }

        @Test
        @DisplayName("el alcance SOLO_LINEAS llega como tal")
        void elAlcanceSoloLineasLlegaComoTal() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("motivo")).thenReturn("1");
            conAuditor();
            when(solicitud.bodyToMono(SolicitudResolverPendiente.class))
                    .thenReturn(Mono.just(new SolicitudResolverPendiente("j", "SOLO_LINEAS")));
            when(resolver.ejecutar(any(), anyLong(), any(), any(), any()))
                    .thenReturn(Mono.empty());

            esperarEstado(manejador.resolver(solicitud), HttpStatus.NO_CONTENT);

            verify(resolver).ejecutar(any(), anyLong(), eq(Alcance.SOLO_LINEAS), any(), any());
        }

        @Test
        @DisplayName("sin cuerpo lo dice explícitamente")
        void sinCuerpoLoDice() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("motivo")).thenReturn("1");
            when(solicitud.headers()).thenReturn(cabeceras);
            when(solicitud.bodyToMono(SolicitudResolverPendiente.class)).thenReturn(Mono.empty());

            StepVerifier.create(manejador.resolver(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }

        @Test
        @DisplayName("un motivo que no es número explota antes de resolver nada")
        void unMotivoNoNumericoExplota() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("motivo")).thenReturn("abc");

            assertThatThrownBy(() -> manejador.resolver(solicitud))
                    .isInstanceOf(NumberFormatException.class);
            verify(resolver, never()).ejecutar(any(), anyLong(), any(), any(), any());
        }
    }

    @Nested
    @DisplayName("resolver en masa")
    class ResolverEnMasa {

        private void cuerpo(List<String> motivos, String nivel) {
            cuerpo(motivos, nivel, null);
        }

        private void cuerpo(List<String> motivos, String nivel, List<Long> lineas) {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            conAuditor();
            when(solicitud.bodyToMono(SolicitudResolverEnMasa.class))
                    .thenReturn(Mono.just(new SolicitudResolverEnMasa(motivos, "j", nivel, lineas)));
        }

        private void resultado(Desenlace desenlace,
                               List<ResultadoResolucionMasiva.Fallo> fallos) {
            when(resolverEnMasa.ejecutar(any(), any(), any(), any(), any(), any()))
                    .thenReturn(Mono.just(new ResultadoResolucionMasiva(
                            List.of("op-1"), desenlace, fallos)));
        }

        @Test
        @DisplayName("un desenlace completo responde 200")
        void unDesenlaceCompletoResponde200() {
            cuerpo(List.of("AUD01"), "CUENTA");
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);
        }

        @Test
        @DisplayName("un desenlace EN_CURSO responde 202: todavía no se puede concluir")
        void unDesenlaceEnCursoResponde202() {
            cuerpo(List.of("AUD01"), "CUENTA");
            resultado(Desenlace.EN_CURSO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.ACCEPTED);
        }

        @Test
        @DisplayName("un parcial responde 200 y los fallos viajan en el cuerpo")
        void unParcialResponde200ConSusFallos() {
            cuerpo(List.of("AUD01"), "DONDE_APLIQUE");
            resultado(Desenlace.PARCIAL, List.of(new ResultadoResolucionMasiva.Fallo(
                    "NIVEL_LINEA", "AUD01", "las líneas no se resolvieron")));

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);
        }

        @Test
        @DisplayName("sin nivel se usa DONDE_APLIQUE")
        void sinNivelSeUsaDondeAplique() {
            cuerpo(List.of("AUD01"), null);
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).ejecutar(any(), any(), nivelCaptor.capture(), any(), any(), any());
            assertThat(nivelCaptor.getValue()).isEqualTo(NivelResolucion.DONDE_APLIQUE);
        }

        @Test
        @DisplayName("un nivel en blanco también cae en DONDE_APLIQUE")
        void unNivelEnBlancoTambienCaeEnDondeAplique() {
            cuerpo(List.of("AUD01"), "   ");
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).ejecutar(any(), any(), nivelCaptor.capture(), any(), any(), any());
            assertThat(nivelCaptor.getValue()).isEqualTo(NivelResolucion.DONDE_APLIQUE);
        }

        @Test
        @DisplayName("los motivos conservan el orden en que llegaron")
        void losMotivosConservanElOrden() {
            cuerpo(List.of("Z9", "A1", "M5"), "CUENTA");
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).ejecutar(any(), motivosCaptor.capture(), any(), any(), any(), any());
            assertThat(motivosCaptor.getValue()).containsExactly("Z9", "A1", "M5");
        }

        @Test
        @Tag("F2-12")
        @Tag("DBG-04")
        @DisplayName("las líneas del cuerpo llegan al caso de uso como selección acotada")
        void lasLineasLleganComoSeleccionAcotada() {
            cuerpo(List.of("AUD01"), "LINEAS", List.of(46_000_000_001L, 46_000_000_002L));
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).ejecutar(any(), any(), any(), any(), any(),
                                            seleccionCaptor.capture());
            var seleccion = seleccionCaptor.getValue();
            assertThat(seleccion.esTodaLaCuenta()).isFalse();
            assertThat(seleccion.identificadores()).containsExactly(46_000_000_001L, 46_000_000_002L);
        }

        @ParameterizedTest(name = "lineas = {0}")
        @NullSource
        @Tag("F2-12")
        @DisplayName("sin líneas en el cuerpo se resuelve en toda la cuenta, como siempre")
        void sinLineasSeResuelveEnTodaLaCuenta(List<Long> lineas) {
            // Importa que el camino de siempre no cambie: esta ruta existía antes del alcance
            // y la mayoría de las resoluciones siguen siendo de cuenta entera.
            cuerpo(List.of("AUD01"), "LINEAS", lineas);
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).ejecutar(any(), any(), any(), any(), any(),
                                            seleccionCaptor.capture());
            assertThat(seleccionCaptor.getValue().esTodaLaCuenta()).isTrue();
        }

        @Test
        @Tag("F2-12")
        @DisplayName("una lista vacía también es toda la cuenta: es el contrato de OHI")
        void unaListaVaciaTambienEsTodaLaCuenta() {
            cuerpo(List.of("AUD01"), "LINEAS", List.of());
            resultado(Desenlace.COMPLETO, List.of());

            esperarEstado(manejador.resolverEnMasa(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).ejecutar(any(), any(), any(), any(), any(),
                                            seleccionCaptor.capture());
            assertThat(seleccionCaptor.getValue().esTodaLaCuenta()).isTrue();
        }

        @Test
        @DisplayName("sin cuerpo lo dice explícitamente")
        void sinCuerpoLoDice() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(solicitud.bodyToMono(SolicitudResolverEnMasa.class)).thenReturn(Mono.empty());

            StepVerifier.create(manejador.resolverEnMasa(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }
    }
    /**
     * El alta de un motivo de pendiente.
     *
     * <p>Responde 204 porque el sistema de registro la aplica de forma síncrona —medido el
     * 17-oct-2026: 204 sin cabecera de seguimiento— así que no hay desenlace que devolver ni
     * actividad que sondear, al contrario que la resolución.
     */
    @Nested
    @DisplayName("agregar pendiente")
    class AgregarPendiente {

        private void peticion(String motivo, List<Long> lineas) {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            conAuditor();
            when(solicitud.bodyToMono(SolicitudAgregarPendiente.class))
                    .thenReturn(Mono.just(new SolicitudAgregarPendiente(motivo, lineas)));
        }

        @Test
        @Tag("DBG-05")
        @DisplayName("responde 204 y acota a las líneas del cuerpo")
        void responde204YAcota() {
            peticion("MP_FATAL_SIN_GLOSA", List.of(135277L, 135280L));
            when(agregar.ejecutar(any(), any(), any(), any())).thenReturn(Mono.empty());

            esperarEstado(manejador.agregarPendiente(solicitud), HttpStatus.NO_CONTENT);

            verify(validador).validar(any(SolicitudAgregarPendiente.class));
            verify(agregar).ejecutar(any(), eq("MP_FATAL_SIN_GLOSA"),
                                     seleccionCaptor.capture(), eq("auditor@sura.com.co"));
            assertThat(seleccionCaptor.getValue().identificadores())
                    .containsExactly(135277L, 135280L);
        }

        @Test
        @Tag("DBG-05")
        @DisplayName("sin líneas se pone en la cabecera, no en todas")
        void sinLineasVaALaCabecera() {
            peticion("MP_FATAL_SIN_GLOSA", null);
            when(agregar.ejecutar(any(), any(), any(), any())).thenReturn(Mono.empty());

            esperarEstado(manejador.agregarPendiente(solicitud), HttpStatus.NO_CONTENT);

            verify(agregar).ejecutar(any(), any(), seleccionCaptor.capture(), any());
            assertThat(seleccionCaptor.getValue().esTodaLaCuenta()).isTrue();
        }

        @Test
        @Tag("DBG-05")
        @DisplayName("sin cuerpo lo dice explícitamente")
        void sinCuerpoLoDice() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            conAuditor();
            when(solicitud.bodyToMono(SolicitudAgregarPendiente.class)).thenReturn(Mono.empty());

            StepVerifier.create(manejador.agregarPendiente(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }
    }
    @Nested
    @DisplayName("ver los ya resueltos")
    class Resueltos {

        private void paginaVacia() {
            var pagina = Pagina.construir(java.util.List.<MotivoPendiente>of(), 25, 0L,
                    MotivoPendiente::identificador);
            when(listar.ejecutar(any(), any(), anyInt(), any(), any(), anyBoolean()))
                    .thenReturn(Mono.just(new PaginaPendientes(pagina, EstadoCuenta.MODIFICACION)));
        }

        private void peticion(String incluir) {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            for (var p : java.util.List.of("cursor", "tamano", "motivo", "bloqueo")) {
                lenient().when(solicitud.queryParam(p)).thenReturn(java.util.Optional.empty());
            }
            when(solicitud.queryParam("incluirResueltos"))
                    .thenReturn(java.util.Optional.ofNullable(incluir));
        }

        @Test
        @Tag("VIS-05")
        @DisplayName("sin el parámetro no se piden: el cambio no altera lo que ya veía el auditor")
        void sinElParametroNoSePiden() {
            peticion(null);
            paginaVacia();

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), any(), anyInt(), any(), any(),
                                    resueltosCaptor.capture());
            assertThat(resueltosCaptor.getValue()).isFalse();
        }

        @Test
        @Tag("VIS-05")
        @DisplayName("con incluirResueltos=true se piden")
        void conElParametroSePiden() {
            peticion("true");
            paginaVacia();

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), any(), anyInt(), any(), any(),
                                    resueltosCaptor.capture());
            assertThat(resueltosCaptor.getValue()).isTrue();
        }

        @org.junit.jupiter.params.ParameterizedTest(name = "incluirResueltos=[{0}]")
        @org.junit.jupiter.params.provider.ValueSource(strings = {"false", "1", "si", "  "})
        @Tag("VIS-05")
        @DisplayName("cualquier otro valor se trata como «no»: mirar atrás es explícito")
        void cualquierOtroValorEsNo(String valor) {
            // Al revés que en los filtros de la grilla, aquí interpretar mal el parámetro no
            // esconde nada: devuelve menos, no más. Por eso aquí sí vale el valor por omisión.
            peticion(valor);
            paginaVacia();

            esperarEstado(manejador.listarSinResolver(solicitud), HttpStatus.OK);

            verify(listar).ejecutar(any(), any(), anyInt(), any(), any(),
                                    resueltosCaptor.capture());
            assertThat(resueltosCaptor.getValue()).isFalse();
        }
    }

    /** OPE-06: el seguimiento de una resolución ya lanzada. */
    @Nested
    @DisplayName("seguirResolucion")
    class SeguirResolucion {

        private void conReferencias(String... valores) {
            var parametros = new org.springframework.util.LinkedMultiValueMap<String, String>();
            for (var v : valores) parametros.add("referencias", v);
            when(solicitud.queryParams()).thenReturn(parametros);
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
        }

        private static co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva con(
                co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace desenlace) {
            return new co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva(
                    java.util.List.of("11", "22"), desenlace, java.util.List.of());
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("acepta las referencias separadas por comas o repitiendo el parámetro")
        void separaLasReferencias() {
            conReferencias("11,22", "33");
            when(resolverEnMasa.seguir(any(), any())).thenReturn(Mono.just(
                    con(co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace.COMPLETO)));

            esperarEstado(manejador.seguirResolucion(solicitud), HttpStatus.OK);

            verify(resolverEnMasa).seguir(new CodigoCuenta(CODIGO), java.util.List.of("11", "22", "33"));
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("mientras alguna siga en curso responde 202, igual que al lanzarla")
        void enCursoResponde202() {
            conReferencias("11");
            when(resolverEnMasa.seguir(any(), any())).thenReturn(Mono.just(
                    con(co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace.EN_CURSO)));

            esperarEstado(manejador.seguirResolucion(solicitud), HttpStatus.ACCEPTED);
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("sin parámetro llega una lista vacía, y es el caso de uso quien lo rechaza")
        void sinParametro() {
            when(solicitud.queryParams()).thenReturn(new org.springframework.util.LinkedMultiValueMap<>());
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(resolverEnMasa.seguir(any(), any())).thenReturn(Mono.error(new IllegalArgumentException("vacía")));

            StepVerifier.create(manejador.seguirResolucion(solicitud)).expectError().verify();
            verify(resolverEnMasa).seguir(new CodigoCuenta(CODIGO), java.util.List.of());
        }
    }
}
