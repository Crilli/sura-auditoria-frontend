package co.sura.auditoria.api.mapeo;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.DatosConvenio;
import co.sura.auditoria.modelo.cuenta.DetalleGlosa;
import co.sura.auditoria.modelo.cuenta.DiagnosticoLinea;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.OtrosDatosLinea;
import co.sura.auditoria.modelo.cuenta.Prestacion;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.Severidad;
import co.sura.auditoria.modelo.cuenta.Version;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("MapeadorLinea — detalle de la línea")
class MapeadorLineaDetalleTest {

    private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(148111592284L);
    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    private static LineaCuenta completa() {
        return new LineaCuenta(
                REFERENCIA, CODIGO, 3,
                LocalDate.of(2026, 8, 11), LocalDate.of(2026, 8, 11),
                "CC1", "Afiliado de prueba", "873206",
                "RADIOGRAFÍA DE PUÑO O MUÑECA", "CUPS",
                new BigDecimal("38222"), BigDecimal.ONE,
                new BigDecimal("38222"), BigDecimal.ONE,
                new BigDecimal("38222"), BigDecimal.ONE,
                BigDecimal.ZERO, "sin observaciones", "104409176961",
                "9000114361-001", "PALERMO IMAGEN LTDA",
                true, false, true, false, false, false,
                new Prestacion("873206", "Radiografía", "CUPS", "ND", "NDD",
                        "rips", "clase", "especialidad"),
                new DatosConvenio("iss2001", "iss2000", "soat", "contrato", "cups",
                        "multiples", "siifa", new BigDecimal("38222"), "tarifa"),
                new OtrosDatosLinea("sala", "via", "uen", "siniestro"),
                List.of(new DiagnosticoLinea(1, "PRINCIPAL", "Principal", "S61", "Herida")),
                List.of(new DetalleGlosa(7L, "AU0202", new BigDecimal("1500"), "NC1",
                        new BigDecimal("1200"), "Tarifas", "Ayudas", "tarifa superior")),
                List.of(new Novedad(9L, "SURA-AUT-002", "Autorización {2} consumida",
                        Severidad.INFORMATIVA, "MANUAL",
                        new Novedad.Clasificacion("G", "Tarifas"),
                        new Novedad.Clasificacion("E", "Ayudas"),
                        "auditor", Instant.parse("2026-08-21T11:04:05Z"), false,
                        Map.of(2, "104409176961"))),
                List.of(new MotivoPendiente(42L, "AUD01", "Auditoría médica", false, true,
                        NivelPendiente.LINEA, REFERENCIA, 3, new Version(2L))),
                null, new Version(5L));
    }

    @Nested
    @DisplayName("identidad e importes")
    class IdentidadEImportes {

        @Test
        @DisplayName("traslada la referencia, la cuenta y el número de línea")
        void trasladaLaIdentidad() {
            var r = MapeadorLinea.aRespuestaDetalle(completa());

            assertThat(r.referencia()).isEqualTo(148111592284L);
            assertThat(r.codigoCuenta()).isEqualTo("CM-108800618430");
            assertThat(r.numeroLinea()).isEqualTo(3);
            assertThat(r.version()).isEqualTo(5L);
        }

        @Test
        @DisplayName("traslada al afiliado y la prestación")
        void trasladaAfiliadoYPrestacion() {
            var r = MapeadorLinea.aRespuestaDetalle(completa());

            // Datos inventados a propósito: en los fixtures no van cédulas ni nombres reales.
            assertThat(r.codigoAfiliado()).isEqualTo("CC1");
            assertThat(r.nombreAfiliado()).isEqualTo("Afiliado de prueba");
            assertThat(r.codigoProcedimiento()).isEqualTo("873206");
            assertThat(r.catalogoProcedimiento()).isEqualTo("CUPS");
        }

        @Test
        @DisplayName("traslada los cuatro pares de importe y unidades")
        void trasladaLosImportes() {
            var r = MapeadorLinea.aRespuestaDetalle(completa());

            assertThat(r.valorCargado()).isEqualByComparingTo("38222");
            assertThat(r.valorAutorizado()).isEqualByComparingTo("38222");
            assertThat(r.valorCubierto()).isEqualByComparingTo("38222");
            assertThat(r.valorGlosado()).isEqualByComparingTo("0");
            assertThat(r.unidadesCubiertas()).isEqualByComparingTo("1");
        }

        @Test
        @DisplayName("traslada al prestador de atención, que puede diferir del de cabecera")
        void trasladaElPrestadorDeAtencion() {
            var r = MapeadorLinea.aRespuestaDetalle(completa());

            assertThat(r.prestadorAtencionCodigo()).isEqualTo("9000114361-001");
            assertThat(r.prestadorAtencionNombre()).isEqualTo("PALERMO IMAGEN LTDA");
        }
    }

    @Nested
    @DisplayName("bloques anidados")
    class BloquesAnidados {

        @Test
        @DisplayName("la prestación lleva sus ocho datos")
        void laPrestacionLlevaSusDatos() {
            var p = MapeadorLinea.aRespuestaDetalle(completa()).prestacion();

            assertThat(p.codigo()).isEqualTo("873206");
            assertThat(p.descripcion()).isEqualTo("Radiografía");
            assertThat(p.codigoNoDefinido()).isEqualTo("ND");
            assertThat(p.descripcionRips()).isEqualTo("rips");
            assertThat(p.especialidad()).isEqualTo("especialidad");
        }

        @Test
        @DisplayName("el convenio lleva tarifas, contrato e importe convenido")
        void elConvenioLlevaSusDatos() {
            var c = MapeadorLinea.aRespuestaDetalle(completa()).convenio();

            assertThat(c.codigoTarifarioIss2001()).isEqualTo("iss2001");
            assertThat(c.numeroContrato()).isEqualTo("contrato");
            assertThat(c.codigoUnicoContratoSiifa()).isEqualTo("siifa");
            assertThat(c.valorConvenido()).isEqualByComparingTo("38222");
        }

        @Test
        @DisplayName("los otros datos llevan sala, vía, UEN y siniestro")
        void losOtrosDatos() {
            var o = MapeadorLinea.aRespuestaDetalle(completa()).otrosDatos();

            assertThat(o.tipoSala()).isEqualTo("sala");
            assertThat(o.unidadEstrategicaNegocio()).isEqualTo("uen");
            assertThat(o.codigoSiniestro()).isEqualTo("siniestro");
        }

        @Test
        @DisplayName("los diagnósticos llevan secuencia, tipo y código")
        void losDiagnosticos() {
            var d = MapeadorLinea.aRespuestaDetalle(completa()).diagnosticos();

            assertThat(d).singleElement().satisfies(x -> {
                assertThat(x.secuencia()).isEqualTo(1);
                assertThat(x.tipo()).isEqualTo("PRINCIPAL");
                assertThat(x.codigo()).isEqualTo("S61");
            });
        }

        @Test
        @DisplayName("las glosas llevan su identificador, importe y clasificación")
        void lasGlosas() {
            var g = MapeadorLinea.aRespuestaDetalle(completa()).glosas();

            assertThat(g).singleElement().satisfies(x -> {
                assertThat(x.identificador()).isEqualTo(7L);
                assertThat(x.valor()).isEqualByComparingTo("1500");
                assertThat(x.codigoNotaCredito()).isEqualTo("NC1");
                assertThat(x.generico()).isEqualTo("Tarifas");
            });
        }
    }

    @Nested
    @DisplayName("novedades")
    class Novedades {

        @Test
        @DisplayName("el texto llega ya resuelto, además de la plantilla cruda y sus valores")
        void elTextoLlegaResueltoYTambienLaPlantilla() {
            // La interfaz necesita las dos cosas: el texto para leer y la plantilla
            // con sus valores para poder editarlos.
            var n = MapeadorLinea.aRespuestaDetalle(completa()).novedades().get(0);

            assertThat(n.descripcion()).isEqualTo("Autorización 104409176961 consumida");
            assertThat(n.plantilla()).isEqualTo("Autorización {2} consumida");
            assertThat(n.valores()).containsEntry(2, "104409176961");
        }

        @Test
        @DisplayName("marca si la puso una persona, que es lo que decide si se puede borrar")
        void marcaSiLaPusoUnaPersona() {
            var n = MapeadorLinea.aRespuestaDetalle(completa()).novedades().get(0);

            assertThat(n.laPusoUnaPersona()).isTrue();
            assertThat(n.origen()).isEqualTo("MANUAL");
            assertThat(n.severidad()).isEqualTo("INFORMATIVA");
        }

        @Test
        @DisplayName("la clasificación viaja con código y descripción")
        void laClasificacionViaja() {
            var n = MapeadorLinea.aRespuestaDetalle(completa()).novedades().get(0);

            assertThat(n.generico().codigo()).isEqualTo("G");
            assertThat(n.generico().descripcion()).isEqualTo("Tarifas");
            assertThat(n.especifico().descripcion()).isEqualTo("Ayudas");
        }

        @Test
        @DisplayName("una clasificación nula viaja como null, no como un objeto vacío")
        void unaClasificacionNulaViajaComoNull() {
            var sinClasificar = new Novedad(1L, "332-1", "t", Severidad.INFORMATIVA, "MANUAL");
            var linea = new LineaCuenta(REFERENCIA, CODIGO, 1, null, null, null, null, null,
                    null, null, null, null, null, null, null, null, null, null, null,
                    null, null, false, false, false, false, false, false,
                    null, null, null, List.of(), List.of(), List.of(sinClasificar),
                    List.of(), null, new Version(1L));

            var n = MapeadorLinea.aRespuestaDetalle(linea).novedades().get(0);

            assertThat(n.generico()).isNull();
            assertThat(n.especifico()).isNull();
        }
    }

    @Nested
    @DisplayName("pendientes de la línea")
    class Pendientes {

        @Test
        @DisplayName("llevan nivel, referencia y número de línea")
        void llevanNivelReferenciaYNumero() {
            var p = MapeadorLinea.aRespuestaDetalle(completa()).pendientes().get(0);

            assertThat(p.identificador()).isEqualTo(42L);
            assertThat(p.codigo()).isEqualTo("AUD01");
            assertThat(p.nivel()).isEqualTo("LINEA");
            assertThat(p.referenciaLinea()).isEqualTo(148111592284L);
            assertThat(p.numeroLinea()).isEqualTo(3);
            assertThat(p.soloAdjudicacion()).isTrue();
        }

        @Test
        @DisplayName("un pendiente de cabecera viaja sin referencia de línea")
        void unPendienteDeCabeceraViajaSinReferencia() {
            var deCabecera = new MotivoPendiente(1L, "AUD01", "d", false, false,
                    NivelPendiente.CABECERA, null, null, new Version(1L));
            var linea = new LineaCuenta(REFERENCIA, CODIGO, 1, null, null, null, null, null,
                    null, null, null, null, null, null, null, null, null, null, null,
                    null, null, false, false, false, false, false, false,
                    null, null, null, List.of(), List.of(), List.of(),
                    List.of(deCabecera), null, new Version(1L));

            var p = MapeadorLinea.aRespuestaDetalle(linea).pendientes().get(0);

            assertThat(p.nivel()).isEqualTo("CABECERA");
            assertThat(p.referenciaLinea()).isNull();
        }
    }

    @Nested
    @DisplayName("marcas de edición")
    class MarcasDeEdicion {

        @Test
        @DisplayName("una línea libre es editable y lo dice")
        void unaLineaLibreEsEditable() {
            var r = MapeadorLinea.aRespuestaDetalle(completa());

            assertThat(r.editable()).isTrue();
            assertThat(r.bloqueada()).isFalse();
            assertThat(r.reemplazada()).isFalse();
        }

        @Test
        @DisplayName("traslada las cuatro marcas de conservar y manual")
        void trasladaLasCuatroMarcas() {
            var r = MapeadorLinea.aRespuestaDetalle(completa());

            assertThat(r.conservarBeneficios()).isTrue();
            assertThat(r.conservarTarifacion()).isFalse();
            assertThat(r.beneficiosManuales()).isTrue();
            assertThat(r.tarifacionManual()).isFalse();
        }

        @Test
        @DisplayName("una línea bloqueada no es editable")
        void unaLineaBloqueadaNoEsEditable() {
            var bloqueada = new LineaCuenta(REFERENCIA, CODIGO, 1, null, null, null, null,
                    null, null, null, null, null, null, null, null, null, null, null, null,
                    null, null, false, false, false, false, true, false,
                    null, null, null, List.of(), List.of(), List.of(), List.of(),
                    null, new Version(1L));

            assertThat(MapeadorLinea.aRespuestaDetalle(bloqueada).editable()).isFalse();
        }
    }

    @Test
    @DisplayName("una línea sin colecciones mapea a listas vacías, nunca a null")
    void unaLineaSinColeccionesMapeaAListasVacias() {
        var pelada = new LineaCuenta(REFERENCIA, CODIGO, 1, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null,
                null, null, false, false, false, false, false, false,
                null, null, null, null, null, null, null, null, new Version(1L));

        var r = MapeadorLinea.aRespuestaDetalle(pelada);

        assertThat(r.diagnosticos()).isEmpty();
        assertThat(r.glosas()).isEmpty();
        assertThat(r.novedades()).isEmpty();
        assertThat(r.pendientes()).isEmpty();
        assertThat(r.prestacion()).isNotNull();
        assertThat(r.convenio()).isNotNull();
        assertThat(r.otrosDatos()).isNotNull();
    }
    /**
     * La marca de bloqueante en los pendientes <b>de la línea</b>.
     *
     * <p>Antes llegaba siempre en nulo —«no evaluado aquí»— porque quien armaba esta respuesta
     * no conocía el estado de la cuenta, y el auditor que entraba por la línea no veía cuál de
     * sus pendientes la frena. Ahora el estado viaja dentro de {@code LineaCuenta}.
     *
     * <p>El veredicto es del <b>par</b> motivo-estado: el mismo motivo bloquea o no según el
     * estado, y por eso las dos pruebas de abajo usan el mismo motivo.
     */
    @Nested
    @DisplayName("la marca de bloqueante")
    class MarcaDeBloqueante {

        /** Solo de adjudicación: el caso donde el estado cambia el veredicto. */
        private static LineaCuenta conPendienteDeSolaAdjudicacion(EstadoCuenta estado) {
            var base = completa();
            return new LineaCuenta(
                    base.referencia(), base.codigoCuenta(), base.numeroLinea(),
                    base.fechaInicio(), base.fechaFin(), base.codigoAfiliado(),
                    base.nombreAfiliado(), base.codigoProcedimiento(),
                    base.descripcionProcedimiento(), base.catalogoProcedimiento(),
                    base.valorAutorizado(), base.unidadesAutorizadas(),
                    base.valorCubierto(), base.unidadesCubiertas(),
                    base.valorCargado(), base.unidadesCargadas(),
                    base.valorGlosado(), base.observacionesGlosa(), base.codigoAutorizacion(),
                    base.prestadorAtencionCodigo(), base.prestadorAtencionNombre(),
                    base.conservarBeneficios(), base.conservarTarifacion(),
                    base.beneficiosManuales(), base.tarifacionManual(),
                    base.bloqueada(), base.reemplazada(),
                    base.prestacion(), base.convenio(), base.otrosDatos(),
                    base.diagnosticos(), base.glosas(), base.novedades(),
                    List.of(new MotivoPendiente(42L, "AUD01", "Auditoría médica", false, true,
                            NivelPendiente.LINEA, REFERENCIA, 3, new Version(2L))),
                    estado,
                    base.version());
        }

        @Test
        @Tag("F2-11")
        @DisplayName("en ADJUDICACION_MANUAL se marca: allí bloquea hasta el de sola adjudicación")
        void enAdjudicacionManualSeMarca() {
            var respuesta = MapeadorLinea.aRespuestaDetalle(
                    conPendienteDeSolaAdjudicacion(EstadoCuenta.ADJUDICACION_MANUAL));

            assertThat(respuesta.pendientes()).singleElement()
                    .satisfies(p -> {
                        assertThat(p.bloqueante()).isTrue();
                        assertThat(p.soloAdjudicacion()).isTrue();
                    });
        }

        @Test
        @Tag("F2-11")
        @DisplayName("en otro estado el mismo motivo no se marca: el veredicto es del par")
        void enOtroEstadoElMismoMotivoNoSeMarca() {
            var respuesta = MapeadorLinea.aRespuestaDetalle(
                    conPendienteDeSolaAdjudicacion(EstadoCuenta.MODIFICACION));

            assertThat(respuesta.pendientes()).singleElement()
                    .satisfies(p -> assertThat(p.bloqueante()).isFalse());
        }

        @Test
        @Tag("F2-11")
        @DisplayName("sin estado conocido no se afirma nada: el nulo es «no se sabe»")
        void sinEstadoConocidoNoSeAfirmaNada() {
            // Rellenarlo con false sería decir que no bloquea sin haberlo comprobado.
            var respuesta = MapeadorLinea.aRespuestaDetalle(
                    conPendienteDeSolaAdjudicacion(null));

            assertThat(respuesta.pendientes()).singleElement()
                    .satisfies(p -> assertThat(p.bloqueante()).isNull());
        }
    }
}
