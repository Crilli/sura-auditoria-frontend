package co.sura.auditoria.api.manejador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.api.dto.RespuestaCuenta;
import co.sura.auditoria.api.dto.SolicitudAccion;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarAccionesCasoDeUso;
import co.sura.auditoria.casodeuso.ConsultarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso;
import co.sura.auditoria.casodeuso.EnviarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarNovedadesDeCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.SeguirProcesoCasoDeUso;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.Version;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.EntityResponse;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ManejadorCuentas")
class ManejadorCuentasTest {

    private static final String CODIGO = "CM-108800618430";
    private static final String AUTOR = "auditor@sura.com.co";

    @Mock ConsultarCuentaCasoDeUso consultar;
    @Mock ConsultarAccionesCasoDeUso consultarAcciones;
    @Mock EnviarCuentaCasoDeUso enviar;
    @Mock SeguirProcesoCasoDeUso seguir;
    @Mock GuardarNovedadesDeCuentaCasoDeUso guardarNovedades;
    @Mock EjecutarAccionCasoDeUso ejecutarAccion;
    @Mock ValidadorSolicitudes validador;
    @Mock ServerRequest solicitud;
    @Mock ServerRequest.Headers cabeceras;

    @InjectMocks ManejadorCuentas manejador;

    @Captor ArgumentCaptor<CodigoCuenta> codigoCaptor;
    @Captor ArgumentCaptor<EjecucionAccion> ejecucionCaptor;

    private static CuentaMedica cuenta() {
        return cuenta(EstadoCuenta.MODIFICACION);
    }

    private static CuentaMedica cuenta(EstadoCuenta estado) {
        return new CuentaMedica(new CodigoCuenta(CODIGO), estado,
                LocalDate.now(), LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN,
                new Version(26L), List.of(), List.of(), null, List.of());
    }

    /** La cuenta que el manejador puso en el cuerpo de la respuesta. */
    private static RespuestaCuenta cuentaDe(ServerResponse respuesta) {
        return (RespuestaCuenta) ((EntityResponse<?>) respuesta).entity();
    }

    private void rutaCon(String codigo) {
        when(solicitud.pathVariable("codigo")).thenReturn(codigo);
    }

    private void conAuditor(String autor) {
        when(solicitud.headers()).thenReturn(cabeceras);
        when(cabeceras.firstHeader("X-Auditor")).thenReturn(autor);
    }

    private static void respuestaOk(Mono<ServerResponse> resultado) {
        StepVerifier.create(resultado)
                .assertNext(r -> {
                    assertThat(r.statusCode()).isEqualTo(HttpStatus.OK);
                    assertThat(r.headers().getContentType())
                            .isEqualTo(MediaType.APPLICATION_JSON);
                })
                .verifyComplete();
    }

    @Nested
    @DisplayName("consultarCuenta")
    class ConsultarCuenta {

        @Test
        @DisplayName("toma el código de la ruta y responde 200 con JSON")
        void tomaElCodigoDeLaRuta() {
            rutaCon(CODIGO);
            when(consultar.ejecutar(any())).thenReturn(Mono.just(cuenta()));

            respuestaOk(manejador.consultarCuenta(solicitud));

            verify(consultar).ejecutar(codigoCaptor.capture());
            assertThat(codigoCaptor.getValue().valor()).isEqualTo(CODIGO);
        }

        @Test
        @DisplayName("un código en blanco explota en el propio value object, antes del caso de uso")
        void unCodigoEnBlancoExplotaAntes() {
            rutaCon("   ");

            org.assertj.core.api.Assertions
                    .assertThatThrownBy(() -> manejador.consultarCuenta(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("obligatorio");

            verify(consultar, never()).ejecutar(any());
        }

        @Test
        @DisplayName("un error del caso de uso se propaga al manejador global de errores")
        void unErrorSePropaga() {
            var caida = new IllegalStateException("OHI no responde");
            rutaCon(CODIGO);
            when(consultar.ejecutar(any())).thenReturn(Mono.error(caida));

            StepVerifier.create(manejador.consultarCuenta(solicitud))
                    .expectErrorMatches(e -> e == caida)
                    .verify();
        }
    }

    @Nested
    @DisplayName("consultarAccionesDisponibles")
    class ConsultarAcciones {

        @Test
        @DisplayName("devuelve las acciones del código pedido")
        void devuelveLasAccionesDelCodigo() {
            rutaCon(CODIGO);
            when(consultarAcciones.ejecutar(any()))
                    .thenReturn(Mono.just(new AccionesDisponibles(Set.of(AccionCuenta.ENVIAR))));

            respuestaOk(manejador.consultarAccionesDisponibles(solicitud));

            verify(consultarAcciones).ejecutar(codigoCaptor.capture());
            assertThat(codigoCaptor.getValue().valor()).isEqualTo(CODIGO);
        }
    }

    @Nested
    @DisplayName("ejecutarAccion")
    class EjecutarAccion {

        @ParameterizedTest(name = "accion=[{0}]")
        @ValueSource(strings = {"ANULAR", "anular", "Anular"})
        @DisplayName("la acción de la ruta se reconoce sin distinguir mayúsculas")
        void laAccionSeReconoceSinDistinguirMayusculas(String enLaRuta) {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn(enLaRuta);
            conAuditor(AUTOR);
            when(solicitud.bodyToMono(SolicitudAccion.class))
                    .thenReturn(Mono.just(new SolicitudAccion(List.of("M1"), "REF", null, "MSG")));
            when(ejecutarAccion.ejecutar(any(), any(), any())).thenReturn(Mono.just(cuenta()));

            respuestaOk(manejador.ejecutarAccion(solicitud));

            verify(ejecutarAccion).ejecutar(any(), ejecucionCaptor.capture(), eq(AUTOR));
            assertThat(ejecucionCaptor.getValue().accion()).isEqualTo(AccionCuenta.ANULAR);
        }

        @Test
        @DisplayName("una acción inventada da un error que la nombra, no un 500 opaco")
        void unaAccionInventadaDaUnErrorQueLaNombra() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("VOLATILIZAR");
            lenient().when(solicitud.headers()).thenReturn(cabeceras);

            StepVerifier.create(manejador.ejecutarAccion(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("VOLATILIZAR"))
                    .verify();

            verify(ejecutarAccion, never()).ejecutar(any(), any(), any());
        }

        @Test
        @DisplayName("sin cuerpo se usa una solicitud vacía: las acciones simples no lo necesitan")
        void sinCuerpoSeUsaUnaSolicitudVacia() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("DEVOLVER_A_MODIFICACION");
            conAuditor(AUTOR);
            when(solicitud.bodyToMono(SolicitudAccion.class)).thenReturn(Mono.empty());
            when(ejecutarAccion.ejecutar(any(), any(), any())).thenReturn(Mono.just(cuenta()));

            respuestaOk(manejador.ejecutarAccion(solicitud));

            verify(ejecutarAccion).ejecutar(any(), ejecucionCaptor.capture(), any());
            assertThat(ejecucionCaptor.getValue().motivos()).isEmpty();
            assertThat(ejecucionCaptor.getValue().lineas()).isEmpty();
        }

        @Test
        @DisplayName("el cuerpo pasa por el validador antes de convertirse en comando")
        void elCuerpoPasaPorElValidador() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("DEVOLVER_A_MODIFICACION");
            conAuditor(AUTOR);
            var dto = new SolicitudAccion(null, null, null, null);
            when(solicitud.bodyToMono(SolicitudAccion.class)).thenReturn(Mono.just(dto));
            when(ejecutarAccion.ejecutar(any(), any(), any())).thenReturn(Mono.just(cuenta()));

            respuestaOk(manejador.ejecutarAccion(solicitud));

            verify(validador).validar(dto);
        }

        @Test
        @DisplayName("el auditor sale de la cabecera X-Auditor, no del cuerpo")
        void elAuditorSaleDeLaCabecera() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("DEVOLVER_A_MODIFICACION");
            conAuditor(AUTOR);
            when(solicitud.bodyToMono(SolicitudAccion.class)).thenReturn(Mono.empty());
            when(ejecutarAccion.ejecutar(any(), any(), any())).thenReturn(Mono.just(cuenta()));

            respuestaOk(manejador.ejecutarAccion(solicitud));

            verify(ejecutarAccion).ejecutar(any(), any(), eq(AUTOR));
        }

        @Test
        @DisplayName("sin cabecera X-Auditor viaja null, y el caso de uso lo rechazará")
        void sinCabeceraViajaNull() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("DEVOLVER_A_MODIFICACION");
            conAuditor(null);
            when(solicitud.bodyToMono(SolicitudAccion.class)).thenReturn(Mono.empty());
            when(ejecutarAccion.ejecutar(any(), any(), any())).thenReturn(Mono.just(cuenta()));

            respuestaOk(manejador.ejecutarAccion(solicitud));

            verify(ejecutarAccion).ejecutar(any(), any(), eq((String) null));
        }
    }

    /**
     * La regla de cambios viaja con la cuenta (EST-01): la pantalla abre o cierra la edición con
     * este booleano y no repite la regla. Va en cada respuesta que devuelve la cuenta.
     */
    @Nested
    @DisplayName("admiteCambios en las respuestas de la cuenta")
    class AdmiteCambios {

        @Test
        @Tag("EST-01.3")
        @DisplayName("[EST-01.3] GET /{codigo} lo publica: en ADJUDICACION_MANUAL, que no")
        void laConsultaLoPublica() {
            rutaCon(CODIGO);
            when(consultar.ejecutar(any()))
                    .thenReturn(Mono.just(cuenta(EstadoCuenta.ADJUDICACION_MANUAL)));

            StepVerifier.create(manejador.consultarCuenta(solicitud))
                    .assertNext(r -> {
                        assertThat(cuentaDe(r).estado()).isEqualTo("ADJUDICACION_MANUAL");
                        assertThat(cuentaDe(r).admiteCambios()).isFalse();
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("EST-01.1")
        @DisplayName("[EST-01.1] GET /{codigo} en MODIFICACION publica que sí")
        void laConsultaEnModificacion() {
            rutaCon(CODIGO);
            when(consultar.ejecutar(any())).thenReturn(Mono.just(cuenta()));

            StepVerifier.create(manejador.consultarCuenta(solicitud))
                    .assertNext(r -> assertThat(cuentaDe(r).admiteCambios()).isTrue())
                    .verifyComplete();
        }

        @Test
        @Tag("EST-02.2")
        @DisplayName("[EST-02.2] POST /{codigo}/acciones/{accion} lo publica con el estado nuevo: pasar a Modificación abre la edición sin otra consulta")
        void laAccionLoPublicaConElEstadoNuevo() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("DEVOLVER_A_MODIFICACION");
            conAuditor(AUTOR);
            when(solicitud.bodyToMono(SolicitudAccion.class)).thenReturn(Mono.empty());
            // La acción devuelve la cuenta releída, ya en MODIFICACION.
            when(ejecutarAccion.ejecutar(any(), any(), any())).thenReturn(Mono.just(cuenta()));

            StepVerifier.create(manejador.ejecutarAccion(solicitud))
                    .assertNext(r -> assertThat(cuentaDe(r).admiteCambios()).isTrue())
                    .verifyComplete();
        }

        @Test
        @Tag("EST-01.3")
        @DisplayName("[EST-01.3] y una acción que la saca de MODIFICACION la cierra")
        void laAccionQueLaSacaLaCierra() {
            rutaCon(CODIGO);
            when(solicitud.pathVariable("accion")).thenReturn("ANULAR");
            conAuditor(AUTOR);
            when(solicitud.bodyToMono(SolicitudAccion.class))
                    .thenReturn(Mono.just(new SolicitudAccion(List.of("M1"), "REF", null, "MSG")));
            // Una anulada es FINALIZED en OHI (medido el 2026-10-21).
            when(ejecutarAccion.ejecutar(any(), any(), any()))
                    .thenReturn(Mono.just(cuenta(EstadoCuenta.FINALIZADA)));

            StepVerifier.create(manejador.ejecutarAccion(solicitud))
                    .assertNext(r -> assertThat(cuentaDe(r).admiteCambios()).isFalse())
                    .verifyComplete();
        }
    }
}
