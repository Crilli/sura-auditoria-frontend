package co.sura.auditoria.api.manejador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.api.dto.SolicitudCambioNovedad;
import co.sura.auditoria.api.dto.SolicitudEnviarCuenta;
import co.sura.auditoria.api.dto.SolicitudNovedadesCuenta;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarAccionesCasoDeUso;
import co.sura.auditoria.casodeuso.ConsultarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso;
import co.sura.auditoria.casodeuso.EnviarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarNovedadesDeCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.SeguirProcesoCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.DecisionEnvio;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import co.sura.auditoria.modelo.cuenta.EstadoProceso.Avance;
import co.sura.auditoria.modelo.cuenta.TiqueteProceso;
import co.sura.auditoria.modelo.cuenta.Version;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ManejadorCuentas — envío, novedades y proceso")
class ManejadorCuentasRestoTest {

    private static final String CODIGO = "CM-108800618430";
    private static final String AUTOR = "auditor@sura.com.co";

    @Mock ConsultarCuentaCasoDeUso consultar;
    @Mock ConsultarAccionesCasoDeUso consultarAcciones;
    @Mock EnviarCuentaCasoDeUso enviar;
    @Mock SeguirProcesoCasoDeUso seguir;
    @Mock GuardarNovedadesDeCuentaCasoDeUso guardarNovedades;
    @Mock EjecutarAccionCasoDeUso ejecutarAccion;
    @Mock co.sura.auditoria.casodeuso.ConsultarHistoriaCasoDeUso historia;
    @Mock co.sura.auditoria.casodeuso.BuscarCuentasCasoDeUso buscar;
    @Mock ValidadorSolicitudes validador;
    @Mock ServerRequest solicitud;
    @Mock ServerRequest.Headers cabeceras;

    @InjectMocks ManejadorCuentas manejador;

    @Captor ArgumentCaptor<DecisionEnvio> decisionCaptor;
    @Captor ArgumentCaptor<Version> versionCaptor;

    private static CuentaMedica cuenta() {
        return new CuentaMedica(new CodigoCuenta(CODIGO), EstadoCuenta.MODIFICACION,
                LocalDate.now(), LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN,
                new Version(26L), List.of(), List.of(), null, List.of());
    }

    private void rutaYAuditor() {
        when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
        when(solicitud.headers()).thenReturn(cabeceras);
        when(cabeceras.firstHeader("X-Auditor")).thenReturn(AUTOR);
    }

    private static void esperarEstado(Mono<ServerResponse> resultado, HttpStatus estado) {
        StepVerifier.create(resultado)
                .assertNext(r -> assertThat(r.statusCode()).isEqualTo(estado))
                .verifyComplete();
    }

    @Nested
    @DisplayName("guardarNovedades")
    class GuardarNovedades {

        @Test
        @DisplayName("valida el cuerpo, traduce los cambios y usa la versión esperada del cliente")
        void validaTraduceYUsaLaVersion() {
            rutaYAuditor();
            var dto = new SolicitudNovedadesCuenta(26L, List.of(
                    new SolicitudCambioNovedad("AGREGAR", null, "332-1", null)));
            when(solicitud.bodyToMono(SolicitudNovedadesCuenta.class)).thenReturn(Mono.just(dto));
            when(guardarNovedades.ejecutar(any(), any(), any(), any()))
                    .thenReturn(Mono.just(cuenta()));

            esperarEstado(manejador.guardarNovedades(solicitud), HttpStatus.OK);

            verify(validador).validar(dto);
            verify(guardarNovedades).ejecutar(eq(new CodigoCuenta(CODIGO)),
                    versionCaptor.capture(), any(), eq(AUTOR));
            assertThat(versionCaptor.getValue()).isEqualTo(new Version(26L));
        }

        @Test
        @DisplayName("sin cuerpo lo dice explícitamente")
        void sinCuerpoLoDice() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(solicitud.bodyToMono(SolicitudNovedadesCuenta.class)).thenReturn(Mono.empty());

            StepVerifier.create(manejador.guardarNovedades(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }
    }

    @Nested
    @DisplayName("enviarCuenta")
    class EnviarCuenta {

        private void cuerpo(String decision, String codigoNovedad) {
            rutaYAuditor();
            when(solicitud.bodyToMono(SolicitudEnviarCuenta.class))
                    .thenReturn(Mono.just(new SolicitudEnviarCuenta(decision, codigoNovedad)));
        }

        @Test
        @DisplayName("responde 202: el envío es asíncrono y devuelve un tiquete de seguimiento")
        void respondeAceptadoConTiquete() {
            cuerpo("ACEPTAR", null);
            when(enviar.ejecutar(any(), any(), any())).thenReturn(Mono.just(
                    new TiqueteProceso(new CodigoCuenta(CODIGO), "PROC-2026-1016-000178")));

            StepVerifier.create(manejador.enviarCuenta(solicitud))
                    .assertNext(r -> {
                        assertThat(r.statusCode()).isEqualTo(HttpStatus.ACCEPTED);
                        assertThat(r.headers().getContentType())
                                .isEqualTo(MediaType.APPLICATION_JSON);
                    })
                    .verifyComplete();
        }

        @Test
        @DisplayName("traduce la decisión del cliente antes de ejecutarla")
        void traduceLaDecision() {
            cuerpo("DENEGAR", "SURA-CHK-063");
            when(enviar.ejecutar(any(), any(), any())).thenReturn(Mono.just(
                    new TiqueteProceso(new CodigoCuenta(CODIGO), "PROC-1")));

            esperarEstado(manejador.enviarCuenta(solicitud), HttpStatus.ACCEPTED);

            verify(enviar).ejecutar(any(), decisionCaptor.capture(), eq(AUTOR));
            assertThat(decisionCaptor.getValue().decision())
                    .isEqualTo(DecisionEnvio.Decision.DENEGAR);
            assertThat(decisionCaptor.getValue().codigoNovedad()).contains("SURA-CHK-063");
        }

        @Test
        @DisplayName("denegar sin código llega como decisión inválida, no revienta el mapeo")
        void denegarSinCodigoLlegaComoInvalida() {
            // Antes lanzaba NullPointerException aquí y el cliente veía un 500; ahora
            // la decisión llega inválida y el caso de uso la rechaza con su 400.
            cuerpo("DENEGAR", null);
            when(enviar.ejecutar(any(), any(), any())).thenReturn(Mono.just(
                    new TiqueteProceso(new CodigoCuenta(CODIGO), "PROC-1")));

            esperarEstado(manejador.enviarCuenta(solicitud), HttpStatus.ACCEPTED);

            verify(enviar).ejecutar(any(), decisionCaptor.capture(), any());
            assertThat(decisionCaptor.getValue().esValida()).isFalse();
        }

        @Test
        @DisplayName("sin cuerpo lo dice explícitamente")
        void sinCuerpoLoDice() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(solicitud.bodyToMono(SolicitudEnviarCuenta.class)).thenReturn(Mono.empty());

            StepVerifier.create(manejador.enviarCuenta(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }
    }

    @Nested
    @DisplayName("seguimiento del proceso")
    class Proceso {

        @Test
        @DisplayName("el sondeo puntual responde 200 con JSON")
        void elSondeoPuntualRespondeJson() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(seguir.consultarUnaVez(any())).thenReturn(Mono.just(
                    new EstadoProceso(Avance.EN_PROCESO, false, List.of())));

            StepVerifier.create(manejador.consultarProceso(solicitud))
                    .assertNext(r -> {
                        assertThat(r.statusCode()).isEqualTo(HttpStatus.OK);
                        assertThat(r.headers().getContentType())
                                .isEqualTo(MediaType.APPLICATION_JSON);
                    })
                    .verifyComplete();
        }

        @Test
        @DisplayName("el sondeo traslada los errores que reporta el proceso")
        void elSondeoTrasladaLosErrores() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(seguir.consultarUnaVez(any())).thenReturn(Mono.just(
                    new EstadoProceso(Avance.FALLIDO, true, List.of("falta prestador"))));

            esperarEstado(manejador.consultarProceso(solicitud), HttpStatus.OK);

            verify(seguir).consultarUnaVez(eq(new CodigoCuenta(CODIGO)));
        }

        @Test
        @DisplayName("la transmisión se sirve como text/event-stream, no como JSON")
        void laTransmisionSeSirveComoEventStream() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(seguir.transmitir(any())).thenReturn(Flux.just(
                    new EstadoProceso(Avance.EN_PROCESO, false, List.of()),
                    new EstadoProceso(Avance.EXITOSO, true, List.of())));

            StepVerifier.create(manejador.transmitirProceso(solicitud))
                    .assertNext(r -> {
                        assertThat(r.statusCode()).isEqualTo(HttpStatus.OK);
                        assertThat(r.headers().getContentType())
                                .isEqualTo(MediaType.TEXT_EVENT_STREAM);
                    })
                    .verifyComplete();

            verify(seguir).transmitir(eq(new CodigoCuenta(CODIGO)));
        }

        @Test
        @DisplayName("la transmisión se arma aunque el flujo venga vacío")
        void laTransmisionSeArmaConFlujoVacio() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(seguir.transmitir(any())).thenReturn(Flux.empty());

            esperarEstado(manejador.transmitirProceso(solicitud), HttpStatus.OK);
        }
    }
    /**
     * La historia de la cuenta.
     *
     * <p>No confundir con «Seguimiento», que está en este mismo manejador y es otra cosa:
     * aquél dice si el envío asíncrono terminó, ésta por dónde ha pasado la cuenta.
     */
    @Nested
    @DisplayName("consultarHistoria")
    class Historia {

        @Test
        @Tag("BTN-06")
        @DisplayName("publica los hitos con el tipo, el autor y quién lo hizo")
        void publicaLosHitos() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(historia.ejecutar(any())).thenReturn(reactor.core.publisher.Flux.just(
                    new co.sura.auditoria.modelo.cuenta.HitoCuenta(
                            co.sura.auditoria.modelo.cuenta.HitoCuenta.Tipo.CAMBIO_DE_ESTADO,
                            "FINALIZADA", null, "Internal System User",
                            java.time.Instant.parse("2026-10-15T11:43:29Z")),
                    new co.sura.auditoria.modelo.cuenta.HitoCuenta(
                            co.sura.auditoria.modelo.cuenta.HitoCuenta.Tipo.DESFINALIZACION,
                            "PRORROGA", "Prorroga", "auditor",
                            java.time.Instant.parse("2026-10-17T16:28:34Z"))));

            esperarEstado(manejador.consultarHistoria(solicitud), HttpStatus.OK);

            verify(historia).ejecutar(new CodigoCuenta(CODIGO));
        }

        @Test
        @Tag("BTN-06")
        @DisplayName("una cuenta sin historia responde 200 con lista vacía, no un error")
        void sinHistoriaResponde200() {
            // Que una cuenta no se haya movido es una respuesta, no un fallo.
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(historia.ejecutar(any())).thenReturn(reactor.core.publisher.Flux.empty());

            esperarEstado(manejador.consultarHistoria(solicitud), HttpStatus.OK);
        }
    }

    /** Lo que el manejador puso en el cuerpo de la respuesta. */
    private static Object cuerpoDe(ServerResponse respuesta) {
        return ((org.springframework.web.reactive.function.server.EntityResponse<?>) respuesta).entity();
    }

    private static co.sura.auditoria.modelo.cuenta.VersionCuenta version(String codigo, int numero) {
        return new co.sura.auditoria.modelo.cuenta.VersionCuenta(
                new CodigoCuenta(codigo), numero, LocalDate.of(2026, 9, numero),
                new BigDecimal(numero * 1000), "Finalizado",
                java.time.Instant.parse("2026-09-0" + numero + "T10:00:00Z"));
    }

    /**
     * El buscador y las versiones de negocio.
     *
     * <p>Los códigos y facturas son de prueba; ninguno identifica a una persona.
     */
    @Nested
    @DisplayName("buscarCuentas, consultarVersiones y consultarVersion")
    class Busqueda {

        private co.sura.auditoria.modelo.cuenta.ResumenCuenta resumen(String codigo,
                                                                      EstadoCuenta estado,
                                                                      String literal) {
            return new co.sura.auditoria.modelo.cuenta.ResumenCuenta(
                    new CodigoCuenta(codigo), "JONATHAN201", LocalDate.of(2026, 10, 1),
                    "800000000", "Prestador de prueba", new BigDecimal("8800000"), estado, literal);
        }

        @Test
        @Tag("BUS-13")
        @DisplayName("devuelve la página con las versiones de cada cuenta, la vigente arriba")
        void paginaConVersiones() {
            when(solicitud.queryParam("factura")).thenReturn(java.util.Optional.of("JONATHAN201"));
            when(solicitud.queryParam("radicado")).thenReturn(java.util.Optional.empty());
            when(solicitud.queryParam("pagina")).thenReturn(java.util.Optional.of("1"));
            when(solicitud.queryParam("tamano")).thenReturn(java.util.Optional.of("10"));
            var pagina = co.sura.auditoria.modelo.cuenta.PaginaDesplazada.deOhi(List.of(
                    resumen("CM-1", EstadoCuenta.ADJUDICACION_MANUAL, "MANUAL ADJUDICATION"),
                    resumen("CM-2", EstadoCuenta.DESCONOCIDO, "ESTADO NUEVO")), 10, 10, 12L, false);
            when(buscar.ejecutar(any(), eq(10), eq(10))).thenReturn(Mono.just(pagina));
            when(buscar.versionesDe(any())).thenReturn(Mono.just(java.util.Map.of(
                    "CM-1", List.of(version("CM-1", 1), version("CM-1", 3), version("CM-1", 2)))));

            StepVerifier.create(manejador.buscarCuentas(solicitud))
                    .assertNext(r -> {
                        assertThat(r.statusCode()).isEqualTo(HttpStatus.OK);
                        var cuerpo = (co.sura.auditoria.api.dto.RespuestaPaginaDesplazada<?>) cuerpoDe(r);
                        assertThat(cuerpo.totalRegistros()).isEqualTo(12L);
                        assertThat(cuerpo.totalPaginas()).isEqualTo(2L);
                        var filas = cuerpo.elementos().stream()
                                .map(co.sura.auditoria.api.dto.RespuestaResumenCuenta.class::cast)
                                .toList();
                        // BUS-19: el estado conocido en vocabulario del auditor, el otro tal cual.
                        assertThat(filas.get(0).estado()).isEqualTo("ADJUDICACION_MANUAL");
                        assertThat(filas.get(1).estado()).isEqualTo("ESTADO NUEVO");
                        assertThat(filas.get(0).versiones())
                                .extracting(co.sura.auditoria.api.dto.RespuestaResumenCuenta
                                                    .RespuestaVersionCuenta::numero)
                                .containsExactly(3, 2, 1);
                        // BUS-13.3: sin transmitir, lista vacía; el campo no se omite.
                        assertThat(filas.get(1).versiones()).isEmpty();
                    })
                    .verifyComplete();

            verify(buscar).ejecutar(new co.sura.auditoria.modelo.cuenta.FiltroCuentas("JONATHAN201", null),
                                    10, 10);
            verify(buscar).versionesDe(List.of(new CodigoCuenta("CM-1"), new CodigoCuenta("CM-2")));
        }

        @Test
        @Tag("BUS-01")
        @DisplayName("sin página ni tamaño, primera página con el tamaño predeterminado")
        void sinPaginacion() {
            when(solicitud.queryParam(any())).thenReturn(java.util.Optional.empty());
            when(solicitud.queryParam("radicado")).thenReturn(java.util.Optional.of("CM-9442"));
            when(buscar.ejecutar(any(), eq(0), eq(null))).thenReturn(Mono.just(
                    co.sura.auditoria.modelo.cuenta.PaginaDesplazada.vacia(25)));
            when(buscar.versionesDe(any())).thenReturn(Mono.just(java.util.Map.of()));

            esperarEstado(manejador.buscarCuentas(solicitud), HttpStatus.OK);
        }

        @Test
        @Tag("BTN-04")
        @DisplayName("las versiones de una cuenta, de la más reciente a la más antigua")
        void versionesDeUnaCuenta() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(buscar.versionesDe(List.of(new CodigoCuenta(CODIGO)))).thenReturn(Mono.just(
                    java.util.Map.of(CODIGO, List.of(version(CODIGO, 1), version(CODIGO, 2)))));

            StepVerifier.create(manejador.consultarVersiones(solicitud))
                    .assertNext(r -> assertThat((List<?>) cuerpoDe(r))
                            .extracting(v -> ((co.sura.auditoria.api.dto.RespuestaResumenCuenta
                                    .RespuestaVersionCuenta) v).numero())
                            .containsExactly(2, 1))
                    .verifyComplete();
        }

        @Test
        @Tag("BTN-04")
        @DisplayName("una cuenta sin transmitir responde 200 con lista vacía")
        void sinVersiones() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(buscar.versionesDe(any())).thenReturn(Mono.just(java.util.Map.of()));

            StepVerifier.create(manejador.consultarVersiones(solicitud))
                    .assertNext(r -> assertThat((List<?>) cuerpoDe(r)).isEmpty())
                    .verifyComplete();
        }

        @Test
        @Tag("BUS-20")
        @DisplayName("la foto de una versión con sus importes y su estado actual")
        void fotoDeUnaVersion() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("numero")).thenReturn("2");
            var foto = new co.sura.auditoria.modelo.cuenta.FotoVersion(
                    new CodigoCuenta(CODIGO), 2, LocalDate.of(2026, 9, 2), "JONATHAN201",
                    "Prestador de prueba", new BigDecimal("6000000"), new BigDecimal("6000000"),
                    new BigDecimal("5000000"), new BigDecimal("5000000"), new BigDecimal("1000000"),
                    BigDecimal.ZERO, List.of(
                            new co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion(
                                    "Pendiente", java.time.Instant.parse("2026-09-02T10:00:00Z")),
                            new co.sura.auditoria.modelo.cuenta.FotoVersion.EstadoDeVersion(
                                    "Finalizado", java.time.Instant.parse("2026-09-05T10:00:00Z"))));
            when(buscar.fotoDeVersion(new CodigoCuenta(CODIGO), 2)).thenReturn(Mono.just(foto));

            StepVerifier.create(manejador.consultarVersion(solicitud))
                    .assertNext(r -> {
                        var cuerpo = (co.sura.auditoria.api.dto.RespuestaFotoVersion) cuerpoDe(r);
                        assertThat(cuerpo.numero()).isEqualTo(2);
                        assertThat(cuerpo.valorFactura()).isEqualByComparingTo("6000000");
                        assertThat(cuerpo.totalGlosado()).isEqualByComparingTo("1000000");
                        assertThat(cuerpo.estadoActual()).isEqualTo("Finalizado");
                        assertThat(cuerpo.historial()).extracting(
                                co.sura.auditoria.api.dto.RespuestaFotoVersion.Estado::estado)
                                .containsExactly("Pendiente", "Finalizado");
                    })
                    .verifyComplete();
        }
    }
}
