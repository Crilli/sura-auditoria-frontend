package co.sura.auditoria.api.manejador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.lenient;

import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.server.ServerRequest;

/**
 * La traducción de página a posición que comparten la grilla viva y la de una versión (BUS-21).
 *
 * <p>Lo que se fija aquí es el desbordamiento: {@code pagina × tamano} se calculaba en
 * {@code int}, y una página muy alta daba la vuelta a un negativo que el caso de uso convertía en
 * 0. El auditor que pegaba {@code ?pagina=90000001} veía las primeras líneas bajo el número de una
 * página que no existe.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ParametrosDePagina")
class ParametrosDePaginaTest {

    @Mock ServerRequest solicitud;

    private void pide(String desplazamiento, String pagina) {
        lenient().when(solicitud.queryParam("desplazamiento")).thenReturn(Optional.ofNullable(desplazamiento));
        lenient().when(solicitud.queryParam("pagina")).thenReturn(Optional.ofNullable(pagina));
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("una página cuyo producto no cabe en un int se queda en el máximo, no en el principio")
    void unaPaginaQueDesbordariaSeSatura() {
        // 90.000.000 × 25 = 2.250.000.000: en int, −2.044.967.296.
        pide(null, "90000000");

        assertThat(ParametrosDePagina.desplazamiento(solicitud, 25)).isEqualTo(Integer.MAX_VALUE);
    }

    @ParameterizedTest(name = "pagina={0}, tamano={1} → {2}")
    @Tag("BUS-21")
    @CsvSource({
        // El último que cabe y el primero que no.
        "85899345, 25, 2147483625",
        "85899346, 25, 2147483647",
        "2147483647, 25, 2147483647",
        // Lo normal no cambia.
        "2, 25, 50",
        "0, 25, 0",
        "-3, 25, 0"
    })
    @DisplayName("la página se traduce multiplicando, sin dar la vuelta en los bordes")
    void bordesDeLaMultiplicacion(String pagina, int tamano, int esperado) {
        pide(null, pagina);

        assertThat(ParametrosDePagina.desplazamiento(solicitud, tamano)).isEqualTo(esperado);
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("un tamaño negativo no produce una posición negativa")
    void unTamanoNegativoNoDaPosicionNegativa() {
        // La grilla viva pasa el tamaño tal como llegó: el recorte lo hace su caso de uso.
        pide(null, "3");

        assertThat(ParametrosDePagina.desplazamiento(solicitud, -10)).isZero();
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("un desplazamiento explícito manda y no se multiplica")
    void elDesplazamientoExplicitoManda() {
        pide("2147483647", "90000000");

        assertThat(ParametrosDePagina.desplazamiento(solicitud, 25)).isEqualTo(Integer.MAX_VALUE);
    }
}
