package co.sura.auditoria.api.mapeo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import co.sura.auditoria.api.dto.SolicitudCambioGlosa;
import co.sura.auditoria.api.dto.SolicitudCambioNovedad;
import co.sura.auditoria.api.dto.SolicitudEnviarCuenta;
import co.sura.auditoria.api.dto.SolicitudGuardarLinea;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CambioGlosa;
import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.DecisionEnvio;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("Mapeadores del API")
class MapeadoresTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(148111592284L);

    @Nested
    @DisplayName("MapeadorCuenta")
    class DeCuenta {

        private static MotivoPendiente pendiente(boolean resuelto) {
            return new MotivoPendiente(1L, "AUD01", "d", resuelto, false,
                    NivelPendiente.CABECERA, null, null, new Version(1L));
        }

        private static CuentaMedica cuenta(List<MotivoPendiente> pendientes) {
            return cuenta(pendientes, List.of());
        }

        private static CuentaMedica cuenta(List<MotivoPendiente> pendientes,
                                           List<co.sura.auditoria.modelo.cuenta.RespuestaGlosa> glosas) {
            return cuenta(pendientes, glosas, new BigDecimal("900"), new BigDecimal("800"));
        }

        /**
         * Convenido y autorizado con cifras distintas (900 y 800): con la misma cifra en los dos,
         * como estaba antes, un cruce entre ellos pasaba en verde.
         */
        private static CuentaMedica cuenta(List<MotivoPendiente> pendientes,
                                           List<co.sura.auditoria.modelo.cuenta.RespuestaGlosa> glosas,
                                           BigDecimal totalConvenido, BigDecimal totalAutorizado) {
            return new CuentaMedica(CODIGO, EstadoCuenta.MODIFICACION,
                    LocalDate.of(2026, 8, 11), LocalDate.of(2026, 8, 11),
                    totalConvenido, totalAutorizado, new Version(26L),
                    pendientes, List.of(), null, glosas);
        }

        @Test
        @Tag("VIS-08")
        @Tag("VIS-11")
        @DisplayName("las respuestas a glosa viajan con su versión y su vencimiento resuelto")
        void lasRespuestasAGlosaViajan() {
            // El «vencida» se calcula en el servidor y no en la pantalla para que no haya dos
            // relojes: el del servidor y el del navegador pueden no coincidir, y de ahí salen
            // avisos que aparecen y desaparecen sin que nada haya cambiado.
            var respuesta = MapeadorCuenta.aRespuesta(cuenta(List.of(), List.of(
                    new co.sura.auditoria.modelo.cuenta.RespuestaGlosa(
                            "1", "CM-94421-V4", new BigDecimal("3534729"),
                            LocalDate.of(2023, 6, 30), LocalDate.of(2023, 7, 12)))));

            assertThat(respuesta.respuestasGlosa()).singleElement().satisfies(r -> {
                assertThat(r.secuencia()).isEqualTo("1");
                assertThat(r.versionAbierta()).isEqualTo("CM-94421-V4");
                assertThat(r.valor()).isEqualByComparingTo("3534729");
                assertThat(r.vencida()).isTrue();
            });
        }

        @Test
        @Tag("VIS-08")
        @DisplayName("una cuenta sin respuestas llega con la lista vacía, no en nulo")
        void sinRespuestasLlegaListaVacia() {
            assertThat(MapeadorCuenta.aRespuesta(cuenta(List.of())).respuestasGlosa()).isEmpty();
        }

        @Test
        @DisplayName("las acciones salen ordenadas, para que la UI no baile entre peticiones")
        void lasAccionesSalenOrdenadas() {
            var acciones = new AccionesDisponibles(Set.of(
                    AccionCuenta.ENVIAR, AccionCuenta.ANULAR, AccionCuenta.SEGUIR_PROCESO));

            assertThat(MapeadorCuenta.aRespuesta(CODIGO, acciones).accionesDisponibles())
                    .containsExactly("ANULAR", "ENVIAR", "SEGUIR_PROCESO");
        }

        @Test
        @DisplayName("sin acciones, la lista va vacía y no nula")
        void sinAccionesLaListaVaVacia() {
            assertThat(MapeadorCuenta.aRespuesta(CODIGO, AccionesDisponibles.ninguna()).accionesDisponibles())
                    .isEmpty();
        }

        @Test
        @DisplayName("el contador de pendientes cuenta solo los SIN resolver")
        void elContadorCuentaSoloLosSinResolver() {
            var respuesta = MapeadorCuenta.aRespuesta(cuenta(List.of(
                    pendiente(false), pendiente(true), pendiente(false))));

            assertThat(respuesta.pendientesSinResolver()).isEqualTo(2);
        }

        @Test
        @Tag("ENC-12")
        @Tag("ENC-13")
        @DisplayName("[ENC-12][ENC-13] traslada identidad, estado, versión y cada total a su nombre")
        void trasladaLoEsencial() {
            var respuesta = MapeadorCuenta.aRespuesta(cuenta(List.of()));

            assertThat(respuesta.codigo()).isEqualTo("CM-108800618430");
            assertThat(respuesta.estado()).isEqualTo("MODIFICACION");
            assertThat(respuesta.totalConvenido()).isEqualByComparingTo("900");
            assertThat(respuesta.totalAutorizado()).isEqualByComparingTo("800");
            assertThat(respuesta.version()).isEqualTo(26L);
        }

        @Test
        @Tag("ENC-12")
        @Tag("ENC-13")
        @DisplayName("[ENC-12][ENC-13] un total que no vino sale nulo, no cero")
        void unTotalQueNoVinoSaleNulo() {
            var respuesta = MapeadorCuenta.aRespuesta(cuenta(List.of(), List.of(), null, null));

            assertThat(respuesta.totalConvenido()).isNull();
            assertThat(respuesta.totalAutorizado()).isNull();
        }

        @Test
        @Tag("ENC-12")
        @DisplayName("[ENC-12] el total convenido tiene una sola fuente: la ficha de facturación no lo repite")
        void elTotalConvenidoNoSeRepiteEnLaFicha() {
            // Hasta el 2026-10-21 la ficha llevaba su propio totalConvenido, siempre en null: la
            // pantalla pintaba «—» aunque la raíz ya tuviera la cifra.
            var nombres = java.util.Arrays.stream(
                            co.sura.auditoria.api.dto.RespuestaInformacionFacturacion.class
                                    .getRecordComponents())
                    .map(java.lang.reflect.RecordComponent::getName).toList();

            assertThat(nombres).contains("totalCargado", "totalValorGlosado")
                    .doesNotContain("totalConvenido", "totalAutorizado", "totalCubierto");
        }

        @Test
        @DisplayName("una cuenta sin información de facturación no revienta: el dominio da una vacía")
        void sinInformacionDeFacturacionNoRevienta() {
            assertThat(MapeadorCuenta.aRespuesta(cuenta(List.of())).informacionFacturacion()).isNotNull();
        }

        private static CuentaMedica cuentaEn(EstadoCuenta estado) {
            return new CuentaMedica(CODIGO, estado,
                    LocalDate.of(2026, 8, 11), LocalDate.of(2026, 8, 11),
                    new BigDecimal("900"), new BigDecimal("800"), new Version(26L),
                    List.of(), List.of(), null, List.of());
        }

        @Test
        @Tag("EST-01.1")
        @Tag("EST-01.3")
        @DisplayName("[EST-01.1] en MODIFICACION la cuenta publica que admite cambios")
        void enModificacionAdmiteCambios() {
            assertThat(MapeadorCuenta.aRespuesta(cuentaEn(EstadoCuenta.MODIFICACION)).admiteCambios())
                    .isTrue();
        }

        @ParameterizedTest(name = "{0}")
        @Tag("EST-01.3")
        @EnumSource(value = EstadoCuenta.class, names = "MODIFICACION",
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("[EST-01.3] en cualquier otro estado publica que no: la pantalla no repite la regla")
        void enCualquierOtroNoAdmiteCambios(EstadoCuenta estado) {
            var respuesta = MapeadorCuenta.aRespuesta(cuentaEn(estado));

            assertThat(respuesta.admiteCambios()).isFalse();
            assertThat(respuesta.estado()).isEqualTo(estado.name());
        }
    }

    @Nested
    @DisplayName("MapeadorCuenta.aDecisionEnvio")
    class DecisionDeEnvio {

        @Test
        @DisplayName("ACEPTAR sin código es una aceptación simple")
        void aceptarSinCodigo() {
            var decision = MapeadorCuenta.aDecisionEnvio(
                    new SolicitudEnviarCuenta("ACEPTAR", null));

            assertThat(decision.decision()).isEqualTo(DecisionEnvio.Decision.ACEPTAR);
            assertThat(decision.codigoNovedad()).isEmpty();
        }

        @Test
        @DisplayName("ACEPTAR con código lo conserva")
        void aceptarConCodigo() {
            assertThat(MapeadorCuenta.aDecisionEnvio(
                    new SolicitudEnviarCuenta("ACEPTAR", "SURA-INF-001")).codigoNovedad())
                    .contains("SURA-INF-001");
        }

        @Test
        @DisplayName("DENEGAR conserva el código bloqueante")
        void denegarConservaElCodigo() {
            var decision = MapeadorCuenta.aDecisionEnvio(
                    new SolicitudEnviarCuenta("DENEGAR", "SURA-CHK-063"));

            assertThat(decision.decision()).isEqualTo(DecisionEnvio.Decision.DENEGAR);
            assertThat(decision.codigoNovedad()).contains("SURA-CHK-063");
        }

        @Test
        @DisplayName("DENEGAR sin código produce una decisión que el dominio marcará inválida")
        void denegarSinCodigoProduceDecisionInvalida() {
            assertThat(MapeadorCuenta.aDecisionEnvio(new SolicitudEnviarCuenta("DENEGAR", null))
                    .esValida()).isFalse();
        }

        @Test
        @DisplayName("una decisión desconocida explota como 400, no se traga")
        void unaDecisionDesconocidaExplota() {
            assertThatThrownBy(() -> MapeadorCuenta.aDecisionEnvio(
                    new SolicitudEnviarCuenta("QUIZAS", null)))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("Decisión inválida");
        }
    }

    @Nested
    @DisplayName("MapeadorLinea.aRespuestaDesplazada")
    class Paginacion {

        private static ResumenLinea resumen(long referencia) {
            return resumen(referencia, List.of(), List.of());
        }

        private static ResumenLinea resumen(long referencia,
                                            List<co.sura.auditoria.modelo.cuenta.MotivoPendiente> pendientes,
                                            List<co.sura.auditoria.modelo.cuenta.Novedad> novedades) {
            return new ResumenLinea(new ReferenciaLinea(referencia), 1,
                    LocalDate.now(), LocalDate.now(), "CC1", "Afiliado", "873206", "desc",
                    "CUPS", "AUT1", BigDecimal.TEN, BigDecimal.TEN, BigDecimal.ZERO,
                    false, false, false, false, pendientes.size(), pendientes,
                    novedades.stream().anyMatch(n -> n.severidad().frenaLaCuenta()),
                    novedades, new Version(1L), null, null, null, null, null, null);
        }

        private static co.sura.auditoria.modelo.cuenta.Novedad novedad(
                co.sura.auditoria.modelo.cuenta.Severidad severidad) {
            return new co.sura.auditoria.modelo.cuenta.Novedad(
                    9L, "SURA-CHK-065", "Falta el motivo de la glosa", severidad, "SYSTEM",
                    null, null, "Internal System User",
                    java.time.Instant.parse("2026-08-21T11:04:05Z"), false, java.util.Map.of());
        }

        @Test
        @Tag("F3-NOV-02")
        @DisplayName("la fila lleva el texto de la novedad, no solo el booleano")
        void laFilaLlevaElTextoDeLaNovedad() {
            // El dato ya viajaba en la misma petición y se descartaba: la grilla solo
            // recibía tieneNovedadBloqueante y pintaba un chip con un tooltip fijo que
            // no decía ni qué campo ni por qué.
            var pagina = PaginaDesplazada.deOhi(
                    List.of(resumen(10L, List.of(),
                            List.of(novedad(co.sura.auditoria.modelo.cuenta.Severidad.BLOQUEANTE)))),
                    0, 25, 1L, false);

            var fila = MapeadorLinea.aRespuestaDesplazada(pagina).elementos().get(0);

            assertThat(fila.tieneNovedadBloqueante()).isTrue();
            assertThat(fila.novedades()).singleElement().satisfies(n -> {
                assertThat(n.codigo()).isEqualTo("SURA-CHK-065");
                // `descripcion` es el texto ya resuelto que se lee; la plantilla va aparte.
                assertThat(n.descripcion()).isEqualTo("Falta el motivo de la glosa");
                assertThat(n.severidad()).isEqualTo("BLOQUEANTE");
            });
        }

        @Test
        @Tag("GRID-10")
        @Tag("GRID-11")
        @Tag("GRID-12")
        @Tag("GRID-13")
        @DisplayName("[GRID-10][GRID-11][GRID-12][GRID-13] la fila lleva cada importe y cada cantidad con su nombre")
        void laFilaLlevaCadaImporteConSuNombre() {
            // Cifras distintas por importe (cargado 1000, convenido 900, autorizado 800, glosado
            // 100) y por cantidad (4, 3, 2): un cruce entre dos de ellos rompe una aserción.
            var linea = new ResumenLinea(new ReferenciaLinea(10L), 1,
                    LocalDate.now(), LocalDate.now(), "CC1", "Afiliado", "873206", "desc",
                    "CUPS", "AUT1",
                    new BigDecimal("900"), new BigDecimal("800"), new BigDecimal("100"),
                    false, false, false, false, 0, List.of(), false, List.of(), new Version(1L),
                    new BigDecimal("1000"), new BigDecimal("4"), new BigDecimal("3"),
                    null, null, new BigDecimal("2"));

            var fila = MapeadorLinea.aRespuestaDesplazada(
                    PaginaDesplazada.deOhi(List.of(linea), 0, 25, 1L, false)).elementos().get(0);

            assertThat(fila.valorCargado()).isEqualByComparingTo("1000");
            assertThat(fila.unidadesCargadas()).isEqualByComparingTo("4");
            assertThat(fila.valorConvenido()).isEqualByComparingTo("900");
            assertThat(fila.unidadesConvenidas()).isEqualByComparingTo("3");
            assertThat(fila.valorAutorizado()).isEqualByComparingTo("800");
            assertThat(fila.unidadesAutorizadas()).isEqualByComparingTo("2");
            assertThat(fila.valorGlosado()).isEqualByComparingTo("100");
        }

        @Test
        @Tag("F3-NOV-02")
        @DisplayName("una línea sin novedades llega con la lista vacía, no en nulo")
        void sinNovedadesLlegaListaVacia() {
            var pagina = PaginaDesplazada.deOhi(List.of(resumen(10L)), 0, 25, 1L, false);

            var fila = MapeadorLinea.aRespuestaDesplazada(pagina).elementos().get(0);

            assertThat(fila.novedades()).isEmpty();
            assertThat(fila.tieneNovedadBloqueante()).isFalse();
        }

        @Test
        @Tag("F2-11")
        @DisplayName("en la grilla el pendiente llega sin marca de bloqueante: aquí no se sabe")
        void enLaGrillaElPendienteLlegaSinMarca() {
            // La diferencia con el detalle de la línea es deliberada: la grilla no trae el
            // estado de la cuenta, y afirmar «no bloquea» sin comprobarlo sería peor que
            // decir «no se sabe». El nulo es esa tercera respuesta.
            var pendiente = new co.sura.auditoria.modelo.cuenta.MotivoPendiente(
                    42L, "AUD01", "Auditoría médica", false, true,
                    co.sura.auditoria.modelo.cuenta.NivelPendiente.LINEA,
                    new ReferenciaLinea(10L), 1, new Version(2L));
            var pagina = PaginaDesplazada.deOhi(
                    List.of(resumen(10L, List.of(pendiente), List.of())), 0, 25, 1L, false);

            var fila = MapeadorLinea.aRespuestaDesplazada(pagina).elementos().get(0);

            assertThat(fila.cantidadPendientes()).isEqualTo(1);
            assertThat(fila.pendientes()).singleElement()
                    .satisfies(p -> assertThat(p.bloqueante()).isNull());
        }

        @Test
        @DisplayName("la posición y el número de página viajan juntos")
        void laPosicionYElNumeroDePaginaViajanJuntos() {
            var pagina = PaginaDesplazada.deOhi(List.of(resumen(10L)), 4025, 25, 4063L, true);
            var respuesta = MapeadorLinea.aRespuestaDesplazada(pagina);

            assertThat(respuesta.desplazamiento()).isEqualTo(4025);
            assertThat(respuesta.pagina()).isEqualTo(161);
            assertThat(respuesta.tamanoPagina()).isEqualTo(25);
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("con total se publica además cuántas páginas hay")
        void conTotalSePublicaCuantasPaginasHay() {
            var pagina = PaginaDesplazada.deOhi(List.of(resumen(1L)), 0, 25, 4063L, true);
            var respuesta = MapeadorLinea.aRespuestaDesplazada(pagina);

            assertThat(respuesta.totalRegistros()).isEqualTo(4063L);
            // 4.063 entre 25 son 162,52: la última página existe aunque esté a medias.
            assertThat(respuesta.totalPaginas()).isEqualTo(163L);
        }

        @Test
        @Tag("F3-CNT-03")
        @DisplayName("sin total de fiar, total y páginas viajan en null; hayMas sigue siendo la señal")
        void sinTotalDeFiarViajanEnNull() {
            // Es el caso del filtro que el sistema de registro no sabe aplicar:
            // publicar su cuenta prometería páginas que no existen.
            var pagina = PaginaDesplazada.filtradaAqui(List.of(resumen(1L)), 50, 25, true);
            var respuesta = MapeadorLinea.aRespuestaDesplazada(pagina);

            assertThat(respuesta.totalRegistros()).isNull();
            assertThat(respuesta.totalPaginas()).isNull();
            assertThat(respuesta.hayMas()).isTrue();
        }

        @Test
        @DisplayName("hayMas en false es lo que corta el avance en la última página")
        void hayMasEnFalseCortaElAvance() {
            var pagina = PaginaDesplazada.deOhi(List.of(resumen(1L)), 4050, 25, 4063L, false);

            assertThat(MapeadorLinea.aRespuestaDesplazada(pagina).hayMas()).isFalse();
        }

        @Test
        @DisplayName("una página vacía mapea a elementos vacíos, en la posición cero y sin más")
        void unaPaginaVaciaMapeaAVacio() {
            var respuesta = MapeadorLinea.aRespuestaDesplazada(
                    PaginaDesplazada.<ResumenLinea>vacia(25));

            assertThat(respuesta.elementos()).isEmpty();
            assertThat(respuesta.desplazamiento()).isZero();
            assertThat(respuesta.hayMas()).isFalse();
            assertThat(respuesta.totalRegistros()).isZero();
        }
    }

    @Nested
    @DisplayName("MapeadorLinea: cambios de novedad")
    class CambiosDeNovedad {

        @Test
        @DisplayName("AGREGAR conserva código y valores")
        void agregarConservaCodigoYValores() {
            var cambios = MapeadorLinea.aCambiosDeNovedadPublico(List.of(
                    new SolicitudCambioNovedad("AGREGAR", null, "332-1", Map.of(0, "dato"))));

            assertThat(cambios).singleElement().satisfies(c -> {
                assertThat(c.esAlta()).isTrue();
                assertThat(c.codigoMensaje()).isEqualTo("332-1");
                assertThat(c.valores()).containsEntry(0, "dato");
            });
        }

        @Test
        @DisplayName("ELIMINAR con identificador produce una baja limpia")
        void eliminarConIdentificador() {
            var cambios = MapeadorLinea.aCambiosDeNovedadPublico(List.of(
                    new SolicitudCambioNovedad("ELIMINAR", 7L, null, null)));

            assertThat(cambios).singleElement().satisfies(c -> {
                assertThat(c.esBaja()).isTrue();
                assertThat(c.identificador()).isEqualTo(7L);
            });
        }

        @Test
        @DisplayName("ELIMINAR sin identificador explota como 400 con un mensaje que lo explica")
        void eliminarSinIdentificadorExplota() {
            assertThatThrownBy(() -> MapeadorLinea.aCambiosDeNovedadPublico(List.of(
                    new SolicitudCambioNovedad("ELIMINAR", null, null, null))))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("identificador");
        }

        @Test
        @DisplayName("ELIMINAR con código además del identificador se rechaza en el dominio")
        void eliminarConCodigoSeRechaza() {
            // La baja solo admite el identificador; mandar también el código sería
            // una solicitud ambigua, y sale como 400 en vez de aplicarse a medias.
            assertThatThrownBy(() -> MapeadorLinea.aCambiosDeNovedadPublico(List.of(
                    new SolicitudCambioNovedad("ELIMINAR", 7L, "332-1", null))))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("solo admite su identificador");
        }

        @Test
        @DisplayName("una lista nula o vacía da una lista vacía, no nula")
        void unaListaNulaDaVacia() {
            assertThat(MapeadorLinea.aCambiosDeNovedadPublico(null)).isEmpty();
            assertThat(MapeadorLinea.aCambiosDeNovedadPublico(List.of())).isEmpty();
        }
    }

    @Nested
    @DisplayName("MapeadorLinea.aEdicionLinea")
    class AEdicionLinea {

        private static SolicitudGuardarLinea solicitud(BigDecimal valorConvenido,
                                                       String observaciones,
                                                       String modoRecalculo,
                                                       List<SolicitudCambioGlosa> glosas,
                                                       List<SolicitudCambioNovedad> novedades) {
            return new SolicitudGuardarLinea(5L, valorConvenido, null, null, null, null,
                    observaciones, null, null, null, null, null, null, null, null, null, null,
                    null, null, modoRecalculo, glosas, novedades, null, null, null, null);
        }

        @Test
        @Tag("GRID-18")
        @Tag("LIN-07")
        @Tag("LIN-08")
        @DisplayName("[GRID-18][LIN-07] el valor y las unidades convenidas llegan al comando con su nombre")
        void elConvenidoLlegaAlComando() {
            var edicion = MapeadorLinea.aEdicionLinea(REFERENCIA, new SolicitudGuardarLinea(5L,
                    new BigDecimal("900"), new BigDecimal("3"),     // convenido
                    new BigDecimal("1000"), new BigDecimal("4"),    // cargado
                    null, null, null, null, null, null, null, null, null, null, null, null,
                    null, null, "AISLADO", null, null, null, null, null, null));

            assertThat(edicion.valorConvenido()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("900"));
            assertThat(edicion.unidadesConvenidas()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("3"));
            assertThat(edicion.valorCargado()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("1000"));
            assertThat(edicion.unidadesCargadas()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("4"));
        }

        @Test
        @DisplayName("los campos ausentes viajan como Optional vacío, no como null")
        void losCamposAusentesViajanComoOptionalVacio() {
            var edicion = MapeadorLinea.aEdicionLinea(REFERENCIA,
                    solicitud(null, "obs", "EN_CASCADA", null, null));

            assertThat(edicion.valorConvenido()).isEmpty();
            assertThat(edicion.observacionesGlosa()).contains("obs");
            assertThat(edicion.glosas()).isEmpty();
            assertThat(edicion.novedades()).isEmpty();
        }

        @Test
        @DisplayName("conserva referencia, versión esperada y modo de recálculo")
        void conservaReferenciaVersionYModo() {
            var edicion = MapeadorLinea.aEdicionLinea(REFERENCIA,
                    solicitud(null, "obs", "AISLADO", null, null));

            assertThat(edicion.referencia()).isEqualTo(REFERENCIA);
            assertThat(edicion.versionEsperada()).isEqualTo(new Version(5L));
            assertThat(edicion.modoRecalculo()).isEqualTo(ModoRecalculo.AISLADO);
        }

        @Test
        @DisplayName("un modo de recálculo inventado explota como 400")
        void unModoInventadoExplota() {
            assertThatThrownBy(() -> MapeadorLinea.aEdicionLinea(REFERENCIA,
                    solicitud(null, "obs", "A_LA_BRAVA", null, null)))
                    .isInstanceOf(IllegalArgumentException.class);
        }

        @Test
        @DisplayName("una glosa AGREGAR se traduce a alta con su valor")
        void unaGlosaAgregarSeTraduceAAlta() {
            var edicion = MapeadorLinea.aEdicionLinea(REFERENCIA, solicitud(null, null,
                    "EN_CASCADA",
                    List.of(new SolicitudCambioGlosa("AGREGAR", null, "208-1", "Tarifas",
                            "Ayudas", new BigDecimal("1500"), "texto")),
                    null));

            assertThat(edicion.glosas()).singleElement().satisfies(g -> {
                assertThat(g.esAlta()).isTrue();
                assertThat(g.codigoGlosa()).isEqualTo("208-1");
                assertThat(g.valor()).isEqualByComparingTo("1500");
            });
        }

        @Test
        @DisplayName("una glosa ELIMINAR sin identificador explota con el mensaje que lo pide")
        void unaGlosaEliminarSinIdentificadorExplota() {
            assertThatThrownBy(() -> MapeadorLinea.aEdicionLinea(REFERENCIA,
                    solicitud(null, null, "EN_CASCADA",
                            List.of(new SolicitudCambioGlosa("ELIMINAR", null, null, null,
                                    null, null, null)),
                            null)))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("«identificador»");
        }

        @Test
        @DisplayName("una glosa ELIMINAR con identificador se traduce a baja")
        void unaGlosaEliminarConIdentificadorSeTraduceABaja() {
            var edicion = MapeadorLinea.aEdicionLinea(REFERENCIA, solicitud(null, null,
                    "EN_CASCADA",
                    List.of(new SolicitudCambioGlosa("ELIMINAR", 42L, null, null, null,
                            null, null)),
                    null));

            assertThat(edicion.glosas()).singleElement()
                    .extracting(CambioGlosa::identificador).isEqualTo(42L);
        }

        @Test
        @DisplayName("las novedades también se traducen dentro de la edición")
        void lasNovedadesTambienSeTraducen() {
            var edicion = MapeadorLinea.aEdicionLinea(REFERENCIA, solicitud(null, null,
                    "EN_CASCADA", null,
                    List.of(new SolicitudCambioNovedad("AGREGAR", null, "332-1", Map.of()))));

            assertThat(edicion.novedades()).singleElement()
                    .extracting(CambioNovedad::codigoMensaje).isEqualTo("332-1");
            assertThat(edicion.tocaNovedades()).isTrue();
        }
    }

    @org.junit.jupiter.api.Test
    @org.junit.jupiter.api.Tag("OPE-12")
    @org.junit.jupiter.api.DisplayName("la respuesta del lote dice cuántas y cuáles ya estaban, aparte de aplicadas y fallidas")
    void loteConLasQueYaEstaban() {
        var r1 = new co.sura.auditoria.modelo.cuenta.ReferenciaLinea(1L);
        var r2 = new co.sura.auditoria.modelo.cuenta.ReferenciaLinea(2L);
        var resultado = co.sura.auditoria.modelo.cuenta.ResultadoPorLinea.de(
                java.util.List.of(r1), java.util.List.of(), java.util.List.of(r2));

        var respuesta = MapeadorLinea.aRespuestaDeLote(resultado);

        org.assertj.core.api.Assertions.assertThat(respuesta.desenlace()).isEqualTo("COMPLETO");
        org.assertj.core.api.Assertions.assertThat(respuesta.aplicadas()).isEqualTo(1);
        org.assertj.core.api.Assertions.assertThat(respuesta.yaEstaban()).isEqualTo(1);
        org.assertj.core.api.Assertions.assertThat(respuesta.referenciasYaEstaban()).containsExactly(2L);
    }
}
