package co.sura.auditoria.api;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;

import co.sura.auditoria.api.dto.SolicitudEnviarCuenta;
import co.sura.auditoria.api.dto.SolicitudResolverEnMasa;
import co.sura.auditoria.api.error.AtributosErrorGlobal;
import co.sura.auditoria.api.error.ManejadorErroresJson;
import co.sura.auditoria.api.manejador.ManejadorCatalogos;
import co.sura.auditoria.api.manejador.ManejadorCuentas;
import co.sura.auditoria.api.manejador.ManejadorLineas;
import co.sura.auditoria.api.manejador.ManejadorPendientes;
import co.sura.auditoria.api.mapeo.MapeadorCuenta;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.Severidad;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerRequest;
import reactor.test.StepVerifier;

@DisplayName("Enrutador, manejo de errores y validación")
class EnrutadorYValidacionTest {

    @Nested
    @DisplayName("EnrutadorRest")
    class Enrutador {

        private final EnrutadorRest enrutador = new EnrutadorRest();

        @Test
        @DisplayName("las rutas de cuentas se montan en un manejador HTTP válido")
        void lasRutasDeCuentasSeMontan() {
            var rutas = enrutador.rutasCuentas(mock(ManejadorCuentas.class));

            assertThat(RouterFunctions.toHttpHandler(rutas)).isNotNull();
        }

        @Test
        @DisplayName("las rutas de líneas se montan")
        void lasRutasDeLineasSeMontan() {
            var rutas = enrutador.rutasLineas(mock(ManejadorLineas.class));

            assertThat(RouterFunctions.toHttpHandler(rutas)).isNotNull();
        }

        @Test
        @DisplayName("las rutas de catálogos se montan")
        void lasRutasDeCatalogosSeMontan() {
            var rutas = enrutador.rutasCatalogos(mock(ManejadorCatalogos.class));

            assertThat(RouterFunctions.toHttpHandler(rutas)).isNotNull();
        }

        @Test
        @DisplayName("las rutas de pendientes se montan")
        void lasRutasDePendientesSeMontan() {
            var rutas = enrutador.rutasPendientes(mock(ManejadorPendientes.class));

            assertThat(RouterFunctions.toHttpHandler(rutas)).isNotNull();
        }

        /**
         * Las rutas que declara un grupo, tal como las describe el propio enrutador: el prefijo
         * del grupo más el predicado de cada una, y su manejador.
         */
        private java.util.Map<String, org.springframework.web.reactive.function.server.HandlerFunction<?>>
                rutasDe(org.springframework.web.reactive.function.server.RouterFunction<?> grupo) {
            var rutas = new java.util.LinkedHashMap<String,
                    org.springframework.web.reactive.function.server.HandlerFunction<?>>();
            var prefijos = new java.util.ArrayDeque<String>();
            grupo.accept(new RouterFunctions.Visitor() {
                @Override public void startNested(
                        org.springframework.web.reactive.function.server.RequestPredicate p) {
                    prefijos.push(p.toString());
                }
                @Override public void endNested(
                        org.springframework.web.reactive.function.server.RequestPredicate p) {
                    prefijos.pop();
                }
                @Override public void route(
                        org.springframework.web.reactive.function.server.RequestPredicate p,
                        org.springframework.web.reactive.function.server.HandlerFunction<?> h) {
                    var ruta = String.join("", prefijos.reversed()) + " " + p;
                    assertThat(rutas.put(ruta, h)).as("ruta repetida: %s", ruta).isNull();
                }
                @Override public void resources(java.util.function.Function<ServerRequest,
                        reactor.core.publisher.Mono<org.springframework.core.io.Resource>> f) { }
                @Override public void attributes(Map<String, Object> atributos) { }
                @Override public void unknown(
                        org.springframework.web.reactive.function.server.RouterFunction<?> r) { }
            });
            return rutas;
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("las líneas de una versión tienen sus dos rutas GET, cada una con su manejador")
        void lasLineasDeUnaVersionTienenSusRutas() throws Exception {
            var manejador = mock(ManejadorCuentas.class);
            var rutas = rutasDe(enrutador.rutasCuentas(manejador));

            var lista = rutas.keySet().stream()
                    .filter(r -> r.contains("/{codigo}/versiones/{numero}/lineas)")).toList();
            var detalle = rutas.keySet().stream()
                    .filter(r -> r.contains("/{codigo}/versiones/{numero}/lineas/{numeroLinea})"))
                    .toList();
            assertThat(lista).singleElement().satisfies(r -> assertThat(r)
                    .startsWith("/api/v1/cuentas").contains("GET").contains("application/json"));
            assertThat(detalle).singleElement().satisfies(r -> assertThat(r).contains("GET"));

            // Cada una llama a su método del manejador, no a la foto ni a la otra.
            var solicitud = mock(ServerRequest.class);
            ((org.springframework.web.reactive.function.server.HandlerFunction<?>)
                    rutas.get(lista.get(0))).handle(solicitud);
            ((org.springframework.web.reactive.function.server.HandlerFunction<?>)
                    rutas.get(detalle.get(0))).handle(solicitud);
            org.mockito.Mockito.verify(manejador).consultarLineasDeVersion(solicitud);
            org.mockito.Mockito.verify(manejador).consultarLineaDeVersion(solicitud);
            org.mockito.Mockito.verify(manejador, org.mockito.Mockito.never()).consultarVersion(any());
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("las rutas de la versión no se mezclan con las de las líneas de la cuenta viva")
        void lasDeLaVersionNoSonLasDeLaCuentaViva() {
            var vivas = rutasDe(enrutador.rutasLineas(mock(ManejadorLineas.class))).keySet();

            // Las vivas cuelgan de /{codigo}/lineas; ninguna lleva versión. Y la foto no tiene
            // ninguna ruta que escriba: solo GET.
            assertThat(vivas).noneMatch(r -> r.contains("versiones"));
            assertThat(rutasDe(enrutador.rutasCuentas(mock(ManejadorCuentas.class))).keySet())
                    .filteredOn(r -> r.contains("/versiones"))
                    .hasSize(4)
                    .allMatch(r -> r.contains("GET"));
        }

        @Test
        @DisplayName("los cuatro grupos componen entre sí sin colisionar")
        void losCuatroGruposComponen() {
            // Si dos grupos declararan la misma ruta y verbo, componerlos seguiría
            // compilando pero el segundo quedaría muerto. Esto al menos prueba que
            // el conjunto se arma y se puede servir.
            var todo = enrutador.rutasCuentas(mock(ManejadorCuentas.class))
                    .and(enrutador.rutasLineas(mock(ManejadorLineas.class)))
                    .and(enrutador.rutasPendientes(mock(ManejadorPendientes.class)))
                    .and(enrutador.rutasCatalogos(mock(ManejadorCatalogos.class)));

            assertThat(RouterFunctions.toHttpHandler(todo)).isNotNull();
        }
    }

    @Nested
    @DisplayName("ManejadorErroresJson")
    class ManejoDeErrores {

        /** Atributos que devuelven siempre el mismo error, sin depender del exchange. */
        private AtributosErrorGlobal atributosQueDevuelven(Throwable causa) {
            return new AtributosErrorGlobal() {
                @Override
                public Throwable getError(ServerRequest peticion) {
                    return causa;
                }
            };
        }

        /** Expone la función de rutas, que en la clase real es protegida. */
        private static final class Accesible extends ManejadorErroresJson {
            private final AtributosErrorGlobal atributos;

            Accesible(AtributosErrorGlobal atributos) {
                super(atributos, new org.springframework.context.support.StaticApplicationContext(),
                      ServerCodecConfigurer.create());
                this.atributos = atributos;
            }

            org.springframework.web.reactive.function.server.RouterFunction<
                    org.springframework.web.reactive.function.server.ServerResponse> rutas() {
                return getRoutingFunction(atributos);
            }
        }

        private Accesible manejadorPara(Throwable causa) {
            return new Accesible(atributosQueDevuelven(causa));
        }

        /** Atiende la petición con la ruta del manejador y devuelve la respuesta. */
        private org.springframework.web.reactive.function.server.ServerResponse atender(
                Throwable causa) {
            var manejador = manejadorPara(causa);
            var solicitud = mock(ServerRequest.class);
            return manejador.rutas().route(solicitud)
                    .flatMap(handler -> handler.handle(solicitud))
                    .block();
        }

        @Test
        @DisplayName("atiende cualquier petición: la ruta no filtra por verbo ni por camino")
        void atiendeCualquierPeticion() {
            assertThat(manejadorPara(new IllegalStateException("x")).rutas()).isNotNull();
        }

        @Test
        @DisplayName("responde con el estado del problema, no con un 500 fijo")
        void respondeConElEstadoDelProblema() {
            var respuesta = atender(ExcepcionDeDominio.de(
                    new ErrorDeDominio.CuentaNoEncontrada("CM-108800618430")));

            assertThat(respuesta.statusCode()).isEqualTo(HttpStatus.NOT_FOUND);
            assertThat(respuesta.headers().getContentType())
                    .isEqualTo(org.springframework.http.MediaType.APPLICATION_JSON);
        }

        @Test
        @DisplayName("un error inesperado sí sale como 500")
        void unErrorInesperadoSaleComo500() {
            assertThat(atender(new NullPointerException("fallo interno")).statusCode())
                    .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        @Test
        @DisplayName("un conflicto de versión sale como 412, igual que por el camino normal")
        void unConflictoDeVersionSaleComo412() {
            assertThat(atender(ExcepcionDeDominio.de(
                    new ErrorDeDominio.ModificacionConcurrente("cuenta", 26L))).statusCode())
                    .isEqualTo(HttpStatus.PRECONDITION_FAILED);
        }
    }

    @Nested
    @DisplayName("ValidadorSolicitudes")
    class Validador {

        private final ValidadorSolicitudes validador = new ValidadorSolicitudes(
                Validation.buildDefaultValidatorFactory().getValidator());

        @Test
        @DisplayName("una solicitud correcta pasa sin decir nada")
        void unaSolicitudCorrectaPasa() {
            assertThatCode(() -> validador.validar(
                    new SolicitudEnviarCuenta("ACEPTAR", null)))
                    .doesNotThrowAnyException();
        }

        @Test
        @DisplayName("una solicitud inválida lanza ConstraintViolationException con sus violaciones")
        void unaSolicitudInvalidaLanza() {
            assertThatThrownBy(() -> validador.validar(
                    new SolicitudEnviarCuenta("QUIZAS", null)))
                    .isInstanceOf(ConstraintViolationException.class)
                    .satisfies(e -> assertThat(
                            ((ConstraintViolationException) e).getConstraintViolations())
                            .isNotEmpty());
        }

        @Test
        @DisplayName("acumula todas las violaciones, no se detiene en la primera")
        void acumulaTodasLasViolaciones() {
            // Motivos vacíos y justificación en blanco: dos problemas en una solicitud.
            assertThatThrownBy(() -> validador.validar(
                    new SolicitudResolverEnMasa(List.of(), "   ", "CUENTA", null)))
                    .isInstanceOf(ConstraintViolationException.class)
                    .satisfies(e -> assertThat(
                            ((ConstraintViolationException) e).getConstraintViolations())
                            .hasSizeGreaterThanOrEqualTo(2));
        }
    }

    @Nested
    @DisplayName("MapeadorCuenta con novedades de cabecera")
    class NovedadesDeCabecera {

        @Test
        @DisplayName("las novedades de la cuenta se mapean igual que las de línea")
        void lasNovedadesDeLaCuentaSeMapean() {
            var cuenta = new CuentaMedica(new CodigoCuenta("CM-108800618430"),
                    EstadoCuenta.MODIFICACION, LocalDate.now(), LocalDate.now(),
                    BigDecimal.TEN, BigDecimal.TEN, new Version(26L), List.of(),
                    List.of(new Novedad(5L, "ANULACION_010", "Anulada por {0}",
                            Severidad.BLOQUEANTE, "MANUAL",
                            new Novedad.Clasificacion("G", "Anulación"), null,
                            "auditor", Instant.now(), false, Map.of(0, "duplicidad"))),
                    null, List.of());

            var novedades = MapeadorCuenta.aRespuesta(cuenta).novedades();

            assertThat(novedades).singleElement().satisfies(n -> {
                assertThat(n.codigo()).isEqualTo("ANULACION_010");
                assertThat(n.descripcion()).isEqualTo("Anulada por duplicidad");
                assertThat(n.plantilla()).isEqualTo("Anulada por {0}");
                assertThat(n.severidad()).isEqualTo("BLOQUEANTE");
                assertThat(n.laPusoUnaPersona()).isTrue();
                assertThat(n.generico().descripcion()).isEqualTo("Anulación");
                assertThat(n.especifico()).isNull();
            });
        }
    }
}
