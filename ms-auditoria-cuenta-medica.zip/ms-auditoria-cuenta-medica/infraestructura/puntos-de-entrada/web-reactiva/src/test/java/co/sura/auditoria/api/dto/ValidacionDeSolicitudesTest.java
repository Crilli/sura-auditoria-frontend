package co.sura.auditoria.api.dto;

import static org.assertj.core.api.Assertions.assertThat;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * El contrato de entrada del API. Lo que estas anotaciones dejan pasar es lo que
 * llega al dominio, así que vale la pena fijarlo.
 */
@DisplayName("Validación de las solicitudes del API")
class ValidacionDeSolicitudesTest {

    private static ValidatorFactory fabrica;
    private static Validator validador;

    @BeforeAll
    static void abrirValidador() {
        fabrica = Validation.buildDefaultValidatorFactory();
        validador = fabrica.getValidator();
    }

    @AfterAll
    static void cerrarValidador() {
        if (fabrica != null) fabrica.close();
    }

    private static List<String> mensajes(Object solicitud) {
        return validador.validate(solicitud).stream()
                .map(v -> v.getMessage())
                .sorted()
                .toList();
    }

    @Nested
    @DisplayName("SolicitudCambioGlosa")
    class CambioGlosa {

        private static SolicitudCambioGlosa con(String operacion, BigDecimal valor,
                                                String codigo, String texto) {
            return new SolicitudCambioGlosa(operacion, null, codigo, null, null, valor, texto);
        }

        @Test
        @DisplayName("una glosa bien formada no produce ninguna queja")
        void unaGlosaBienFormadaPasa() {
            assertThat(mensajes(con("AGREGAR", new BigDecimal("1500"), "208-1", "texto")))
                    .isEmpty();
        }

        @Test
        @DisplayName("la operación es obligatoria")
        void laOperacionEsObligatoria() {
            assertThat(mensajes(con(null, BigDecimal.TEN, "208-1", null)))
                    .contains("Hay que decir si la glosa se agrega o se elimina");
        }

        @ParameterizedTest(name = "[{0}] no es una operación válida")
        @ValueSource(strings = {"BORRAR", "agregar", "ADD", ""})
        @DisplayName("solo se admiten AGREGAR y ELIMINAR, en mayúsculas")
        void soloSeAdmitenLasDosOperaciones(String operacion) {
            assertThat(mensajes(con(operacion, BigDecimal.TEN, "208-1", null)))
                    .contains("La operación sobre la glosa debe ser AGREGAR o ELIMINAR");
        }

        @Test
        @DisplayName("un valor negativo se rechaza aquí, antes de llegar al dominio")
        void unValorNegativoSeRechaza() {
            assertThat(mensajes(con("AGREGAR", new BigDecimal("-1"), "208-1", null)))
                    .contains("El valor de la glosa no puede ser negativo");
        }

        @Test
        @DisplayName("el cero sí se admite: glosar por cero es objetar sin descontar")
        void elCeroSeAdmite() {
            assertThat(mensajes(con("AGREGAR", BigDecimal.ZERO, "208-1", null))).isEmpty();
        }

        @Test
        @DisplayName("el código de glosa admite 30 caracteres y no 31")
        void elCodigoAdmite30() {
            assertThat(mensajes(con("AGREGAR", BigDecimal.TEN, "x".repeat(30), null))).isEmpty();
            assertThat(mensajes(con("AGREGAR", BigDecimal.TEN, "x".repeat(31), null)))
                    .contains("El código de glosa no puede superar los 30 caracteres");
        }

        @Test
        @DisplayName("el texto admite 1000 caracteres y no 1001")
        void elTextoAdmite1000() {
            assertThat(mensajes(con("AGREGAR", BigDecimal.TEN, "208-1", "x".repeat(1000))))
                    .isEmpty();
            assertThat(mensajes(con("AGREGAR", BigDecimal.TEN, "208-1", "x".repeat(1001))))
                    .contains("El texto de la glosa no puede superar los 1000 caracteres");
        }
    }

    @Nested
    @DisplayName("SolicitudCambioNovedad")
    class CambioNovedad {

        private static SolicitudCambioNovedad con(String operacion, String codigo,
                                                  Map<Integer, String> valores) {
            return new SolicitudCambioNovedad(operacion, null, codigo, valores);
        }

        @Test
        @DisplayName("una novedad bien formada no produce quejas")
        void unaNovedadBienFormadaPasa() {
            assertThat(mensajes(con("AGREGAR", "332-1", Map.of(0, "dato")))).isEmpty();
        }

        @Test
        @DisplayName("los índices de los valores van del 0 al 9")
        void losIndicesVanDelCeroAlNueve() {
            assertThat(mensajes(con("AGREGAR", "332-1", Map.of(0, "a", 9, "b")))).isEmpty();
            assertThat(mensajes(con("AGREGAR", "332-1", Map.of(10, "a"))))
                    .contains("El dato de la novedad va numerado del 0 al 9");
            assertThat(mensajes(con("AGREGAR", "332-1", Map.of(-1, "a"))))
                    .contains("El dato de la novedad va numerado del 0 al 9");
        }

        @Test
        @DisplayName("cada valor admite 300 caracteres, que es lo que soporta el sistema de registro")
        void cadaValorAdmite300() {
            assertThat(mensajes(con("AGREGAR", "332-1", Map.of(0, "x".repeat(300))))).isEmpty();
            assertThat(mensajes(con("AGREGAR", "332-1", Map.of(0, "x".repeat(301)))))
                    .contains("Cada dato de la novedad admite 300 caracteres");
        }

        @Test
        @DisplayName("el código de novedad admite 40 caracteres")
        void elCodigoAdmite40() {
            assertThat(mensajes(con("AGREGAR", "x".repeat(41), Map.of())))
                    .contains("El código de la novedad no puede superar los 40 caracteres");
        }

        @Test
        @DisplayName("la operación es obligatoria y solo admite los dos valores")
        void laOperacionEsObligatoriaYAcotada() {
            assertThat(mensajes(con(null, "332-1", Map.of())))
                    .contains("Hay que decir si la novedad se agrega o se elimina");
            assertThat(mensajes(con("QUITAR", "332-1", Map.of())))
                    .contains("La operación sobre la novedad debe ser AGREGAR o ELIMINAR");
        }
    }

    @Nested
    @DisplayName("SolicitudResolverEnMasa")
    class ResolverEnMasa {

        private static SolicitudResolverEnMasa con(List<String> motivos, String justificacion,
                                                   String nivel) {
            return new SolicitudResolverEnMasa(motivos, justificacion, nivel, null);
        }

        @Test
        @DisplayName("una solicitud bien formada no produce quejas")
        void unaSolicitudBienFormadaPasa() {
            assertThat(mensajes(con(List.of("AUD01"), "Soportes completos", "CUENTA")))
                    .isEmpty();
        }

        @Test
        @DisplayName("hace falta al menos un motivo")
        void haceFaltaAlMenosUnMotivo() {
            assertThat(mensajes(con(List.of(), "justificación", "CUENTA")))
                    .contains("Hay que indicar al menos un motivo");
            assertThat(mensajes(con(null, "justificación", "CUENTA")))
                    .contains("Hay que indicar al menos un motivo");
        }

        @Test
        @DisplayName("el tope de 50 motivos se fija aquí, igual que en el caso de uso")
        void elTopeDe50SeFijaAqui() {
            var cincuenta = java.util.stream.IntStream.rangeClosed(1, 50)
                    .mapToObj(i -> "M" + i).toList();
            var cincuentaYUno = java.util.stream.IntStream.rangeClosed(1, 51)
                    .mapToObj(i -> "M" + i).toList();

            assertThat(mensajes(con(cincuenta, "j", "CUENTA"))).isEmpty();
            assertThat(mensajes(con(cincuentaYUno, "j", "CUENTA")))
                    .contains("No se pueden resolver más de 50 motivos en una sola operación");
        }

        @Test
        @DisplayName("un código de motivo en blanco se rechaza")
        void unCodigoEnBlancoSeRechaza() {
            assertThat(mensajes(con(List.of("   "), "j", "CUENTA")))
                    .contains("Hay códigos de motivo vacíos");
        }

        @Test
        @DisplayName("la justificación es obligatoria y no puede ir en blanco")
        void laJustificacionEsObligatoria() {
            assertThat(mensajes(con(List.of("A"), null, "CUENTA")))
                    .contains("La justificación es obligatoria");
            assertThat(mensajes(con(List.of("A"), "   ", "CUENTA")))
                    .contains("La justificación es obligatoria");
        }

        @Test
        @DisplayName("la justificación admite 2000 caracteres")
        void laJustificacionAdmite2000() {
            assertThat(mensajes(con(List.of("A"), "x".repeat(2000), "CUENTA"))).isEmpty();
            assertThat(mensajes(con(List.of("A"), "x".repeat(2001), "CUENTA")))
                    .contains("La justificación no puede superar los 2000 caracteres");
        }

        @ParameterizedTest(name = "nivel [{0}]")
        @ValueSource(strings = {"CUENTA", "LINEAS", "DONDE_APLIQUE"})
        @DisplayName("los tres niveles válidos pasan")
        void losTresNivelesPasan(String nivel) {
            assertThat(mensajes(con(List.of("A"), "j", nivel))).isEmpty();
        }

        @Test
        @DisplayName("un nivel inventado se rechaza, pero el nulo se admite y lo resuelve el caso de uso")
        void unNivelInventadoSeRechazaYElNuloSeAdmite() {
            assertThat(mensajes(con(List.of("A"), "j", "TODO")))
                    .contains("El nivel debe ser CUENTA, LINEAS o DONDE_APLIQUE");
            assertThat(mensajes(con(List.of("A"), "j", null))).isEmpty();
        }
    }
}
