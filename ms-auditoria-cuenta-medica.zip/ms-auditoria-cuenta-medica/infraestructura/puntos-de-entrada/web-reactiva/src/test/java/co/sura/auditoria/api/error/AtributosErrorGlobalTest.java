package co.sura.auditoria.api.error;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;

import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.server.ResponseStatusException;

/**
 * Se sustituye {@code getError} en una subclase en vez de montar el atributo interno
 * de Spring: así la prueba no depende de una clave privada del framework.
 */
@DisplayName("AtributosErrorGlobal")
class AtributosErrorGlobalTest {

    private final ServerRequest solicitud = mock(ServerRequest.class);

    private Map<String, Object> atributosDe(Throwable causa) {
        var atributos = new AtributosErrorGlobal() {
            @Override
            public Throwable getError(ServerRequest peticion) {
                return causa;
            }
        };
        return atributos.getErrorAttributes(solicitud, ErrorAttributeOptions.defaults());
    }

    private Map<String, Object> deDominio(ErrorDeDominio error) {
        return atributosDe(ExcepcionDeDominio.de(error));
    }

    @Nested
    @DisplayName("errores de dominio")
    class ErroresDeDominio {

        @Test
        @DisplayName("cuenta no encontrada es 404 y nombra la cuenta")
        void cuentaNoEncontrada() {
            var r = deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-108800618430"));

            assertThat(r).containsEntry("estado", 404)
                         .containsEntry("codigo", "CUENTA_NO_ENCONTRADA");
            assertThat(r.get("mensaje").toString()).contains("CM-108800618430");
        }

        @Test
        @DisplayName("línea no encontrada es 404")
        void lineaNoEncontrada() {
            assertThat(deDominio(new ErrorDeDominio.LineaNoEncontrada(1L)))
                    .containsEntry("estado", 404)
                    .containsEntry("codigo", "LINEA_NO_ENCONTRADA");
        }

        @Test
        @DisplayName("acción no disponible es 409 y dice cuál")
        void accionNoDisponible() {
            var r = deDominio(new ErrorDeDominio.AccionNoDisponible("CM-1", "ENVIAR"));

            assertThat(r).containsEntry("estado", 409)
                         .containsEntry("codigo", "ACCION_NO_DISPONIBLE");
            assertThat(r.get("mensaje").toString()).contains("ENVIAR");
        }

        @Test
        @DisplayName("pendientes que bloquean es 409 y dice cuántos")
        void pendientesBloquean() {
            var r = deDominio(new ErrorDeDominio.PendientesBloqueanEnvio("CM-1", 3));

            assertThat(r).containsEntry("estado", 409)
                         .containsEntry("codigo", "PENDIENTES_SIN_RESOLVER");
            assertThat(r.get("mensaje").toString()).contains("3 pendiente(s)");
        }

        @Test
        @DisplayName("modificación concurrente es 412, no 409: es un cerrojo de precondición")
        void modificacionConcurrente() {
            assertThat(deDominio(new ErrorDeDominio.ModificacionConcurrente("cuenta", 26L)))
                    .containsEntry("estado", 412)
                    .containsEntry("codigo", "MODIFICACION_CONCURRENTE");
        }

        @Test
        @DisplayName("sin permiso es 403 y deja pasar el detalle que explica qué se rechazó")
        void sinPermiso() {
            var r = deDominio(new ErrorDeDominio.SinPermiso("resolver", "No tiene privilegios"));

            assertThat(r).containsEntry("estado", 403)
                         .containsEntry("codigo", "SIN_PERMISO")
                         .containsEntry("mensaje", "No tiene privilegios");
        }

        @Test
        @DisplayName("límite de aprobación excedido es 403 con su propio código")
        void limiteDeAprobacion() {
            assertThat(deDominio(new ErrorDeDominio.LimiteAprobacionExcedido("CM-1")))
                    .containsEntry("estado", 403)
                    .containsEntry("codigo", "LIMITE_APROBACION_EXCEDIDO");
        }

        @Test
        @DisplayName("línea no editable es 422 y la razón llega al cliente")
        void lineaNoEditable() {
            // El rechazo de una línea dentro de un lote normalmente lo captura el caso de uso
            // para quitarla y reintentar el resto; si llega aquí, el rechazo fue fuera de un
            // lote y lo que importa es el porqué, no la posición dentro del parche.
            assertThat(deDominio(new ErrorDeDominio.LineaDelLoteRechazada(1, "La glosa está duplicada")))
                    .containsEntry("status", 422)
                    .containsEntry("codigo", "LINEA_RECHAZADA")
                    .containsEntry("mensaje", "La glosa está duplicada");

            // OPE-11: el cambio se aplicó; el mensaje lo dice y pide recargar, no repetir.
            assertThat(deDominio(new ErrorDeDominio.AplicadoSinRelectura("linea:1", "timeout")))
                    .containsEntry("status", 503)
                    .containsEntry("codigo", "APLICADO_SIN_RELEER")
                    .hasEntrySatisfying("mensaje", m -> assertThat((String) m)
                            .contains("se aplicó").contains("no lo repita"));

            assertThat(deDominio(new ErrorDeDominio.LineaNoEditable(1L, "La línea está bloqueada")))
                    .containsEntry("estado", 422)
                    .containsEntry("codigo", "LINEA_NO_EDITABLE")
                    .containsEntry("mensaje", "La línea está bloqueada");
        }

        @Test
        @DisplayName("edición sin cambios es 422")
        void edicionSinCambios() {
            assertThat(deDominio(new ErrorDeDominio.EdicionSinCambios(1L)))
                    .containsEntry("estado", 422)
                    .containsEntry("codigo", "SIN_CAMBIOS");
        }

        @Test
        @DisplayName("decisión inválida es 400 y deja pasar el detalle")
        void decisionInvalida() {
            assertThat(deDominio(new ErrorDeDominio.DecisionEnvioInvalida("falta el código")))
                    .containsEntry("estado", 400)
                    .containsEntry("codigo", "DECISION_INVALIDA")
                    .containsEntry("mensaje", "falta el código");
        }

        @Test
        @DisplayName("sistema de registro caído es 503, no 500: es indisponibilidad de un tercero")
        void sistemaDeRegistroCaido() {
            var r = deDominio(new ErrorDeDominio.SistemaRegistroNoDisponible("timeout"));

            assertThat(r).containsEntry("estado", 503)
                         .containsEntry("codigo", "SISTEMA_REGISTRO_NO_DISPONIBLE");
            // El detalle técnico NO se filtra al cliente.
            assertThat(r.get("mensaje").toString()).doesNotContain("timeout");
        }
    }

    @Nested
    @DisplayName("errores de validación y de forma")
    class ValidacionYForma {

        @Test
        @DisplayName("una violación de restricción es 400 y lista campo y motivo")
        void unaViolacionDeRestriccion() {
            var ruta = mock(Path.class);
            lenient().when(ruta.toString()).thenReturn("tamano");
            @SuppressWarnings("unchecked")
            ConstraintViolation<Object> violacion = mock(ConstraintViolation.class);
            lenient().when(violacion.getPropertyPath()).thenReturn(ruta);
            lenient().when(violacion.getMessage()).thenReturn("debe ser mayor que 0");

            var r = atributosDe(new ConstraintViolationException(Set.of(violacion)));

            assertThat(r).containsEntry("estado", 400)
                         .containsEntry("codigo", "SOLICITUD_INVALIDA");
            assertThat(r.get("mensaje").toString())
                    .contains("tamano").contains("debe ser mayor que 0");
        }

        @Test
        @DisplayName("un IllegalArgumentException del dominio sale como 400, no como 500")
        void unIllegalArgumentSaleComo400() {
            // Las validaciones de los records del dominio lanzan IllegalArgumentException:
            // si cayeran en el default, el cliente vería un 500 por un dato suyo mal puesto.
            var r = atributosDe(new IllegalArgumentException("El código de cuenta es obligatorio"));

            assertThat(r).containsEntry("estado", 400)
                         .containsEntry("codigo", "SOLICITUD_INVALIDA")
                         .containsEntry("mensaje", "El código de cuenta es obligatorio");
        }
    }

    @Nested
    @DisplayName("errores HTTP de Spring")
    class ErroresHttp {

        @ParameterizedTest(name = "{0} -> {1}")
        @CsvSource({
                "404, RUTA_NO_ENCONTRADA",
                "405, METODO_NO_PERMITIDO",
                "406, FORMATO_NO_ACEPTABLE",
                "415, MEDIO_NO_SOPORTADO"
        })
        @DisplayName("cada estado tiene su código propio")
        void cadaEstadoTieneSuCodigo(int estado, String codigo) {
            lenient().when(solicitud.path()).thenReturn("/api/v1/inventada");

            assertThat(atributosDe(new ResponseStatusException(HttpStatus.valueOf(estado))))
                    .containsEntry("estado", estado)
                    .containsEntry("codigo", codigo);
        }

        @Test
        @DisplayName("el 404 de ruta orienta hacia la forma correcta del recurso")
        void el404OrientaHaciaLaRutaCorrecta() {
            lenient().when(solicitud.path()).thenReturn("/api/v1/inventada");

            var mensaje = atributosDe(new ResponseStatusException(HttpStatus.NOT_FOUND))
                    .get("mensaje").toString();

            assertThat(mensaje)
                    .contains("/api/v1/inventada")
                    .contains("/api/v1/cuentas/{codigo}");
        }

        @Test
        @DisplayName("un estado HTTP sin caso propio usa la razón de la excepción")
        void unEstadoSinCasoPropioUsaLaRazon() {
            var r = atributosDe(new ResponseStatusException(HttpStatus.BAD_GATEWAY, "upstream mal"));

            assertThat(r).containsEntry("estado", 502)
                         .containsEntry("codigo", "ERROR_HTTP")
                         .containsEntry("mensaje", "upstream mal");
        }

        @Test
        @DisplayName("si no hay razón, se da un mensaje genérico en vez de null")
        void siNoHayRazonSeDaUnoGenerico() {
            assertThat(atributosDe(new ResponseStatusException(HttpStatus.BAD_GATEWAY))
                    .get("mensaje")).isNotNull();
        }
    }

    @Nested
    @DisplayName("cualquier otra cosa")
    class CualquierOtraCosa {

        @Test
        @DisplayName("una excepción inesperada es 500 y NO filtra el detalle interno")
        void unaExcepcionInesperadaNoFiltraDetalle() {
            var r = atributosDe(new NullPointerException("fallo en la línea 42 de FooBar"));

            assertThat(r).containsEntry("estado", 500)
                         .containsEntry("codigo", "ERROR_INTERNO")
                         .containsEntry("mensaje", "Ocurrió un error inesperado");
            assertThat(r.get("mensaje").toString()).doesNotContain("FooBar");
        }
    }

    @Nested
    @DisplayName("forma de la respuesta")
    class FormaDeLaRespuesta {

        @Test
        @DisplayName("siempre lleva las seis claves del contrato")
        void siempreLlevaLasSeisClaves() {
            assertThat(deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-1")))
                    .containsOnlyKeys("status", "estado", "codigo", "mensaje",
                                      "idTraza", "instante");
        }

        @Test
        @DisplayName("status y estado llevan el mismo valor: uno es para Spring y otro para el front")
        void statusYEstadoCoinciden() {
            var r = deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-1"));

            assertThat(r.get("status")).isEqualTo(r.get("estado"));
        }

        @Test
        @DisplayName("sin MDC el id de traza es un guion, nunca nulo")
        void sinMdcElIdDeTrazaEsUnGuion() {
            org.slf4j.MDC.clear();

            assertThat(deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-1")))
                    .containsEntry("idTraza", "-");
        }

        @Test
        @DisplayName("el idTraza propio gana al del trazado distribuido")
        void elIdTrazaPropioGana() {
            org.slf4j.MDC.put("idTraza", "propio-123");
            org.slf4j.MDC.put("traceId", "otel-456");
            try {
                assertThat(deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-1")))
                        .containsEntry("idTraza", "propio-123");
            } finally {
                org.slf4j.MDC.clear();
            }
        }

        @Test
        @DisplayName("si no hay propio, se usa el traceId del trazado distribuido")
        void siNoHayPropioSeUsaElTraceId() {
            org.slf4j.MDC.put("traceId", "otel-456");
            try {
                assertThat(deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-1")))
                        .containsEntry("idTraza", "otel-456");
            } finally {
                org.slf4j.MDC.clear();
            }
        }

        @Test
        @DisplayName("el instante es una marca ISO-8601 parseable")
        void elInstanteEsParseable() {
            var instante = deDominio(new ErrorDeDominio.CuentaNoEncontrada("CM-1"))
                    .get("instante").toString();

            assertThat(java.time.Instant.parse(instante)).isNotNull();
        }
    }
}
