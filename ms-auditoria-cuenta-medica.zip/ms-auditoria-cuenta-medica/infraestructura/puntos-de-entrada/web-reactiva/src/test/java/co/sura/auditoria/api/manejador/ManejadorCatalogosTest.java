package co.sura.auditoria.api.manejador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.api.dto.RespuestaMensajeCatalogo;
import co.sura.auditoria.casodeuso.ConsultarCatalogoNovedadesCasoDeUso;
import co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso;
import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion.Ambito;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.Severidad;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ManejadorCatalogos")
class ManejadorCatalogosTest {

    @Mock ConsultarCatalogoNovedadesCasoDeUso novedades;
    @Mock EjecutarAccionCasoDeUso acciones;
    @Mock co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente catalogoMotivosPendiente;
    @Mock ServerRequest peticion;
    @InjectMocks ManejadorCatalogos manejador;

    @Captor ArgumentCaptor<String> busquedaCaptor;
    @Captor ArgumentCaptor<Ambito> ambitoCaptor;

    private static MensajeCatalogo mensaje(String codigo, Severidad severidad) {
        return new MensajeCatalogo(codigo, "Autorización {2} consumida", severidad,
                new Novedad.Clasificacion("G", "Tarifas"), null, false);
    }

    private static MotivoDesfinalizacion motivo(String codigo) {
        return new MotivoDesfinalizacion(codigo, "desc", true, false, Ambito.AMBAS, "PERM");
    }

    private static void respuestaOk(Mono<ServerResponse> resultado) {
        StepVerifier.create(resultado)
                .assertNext(respuesta -> {
                    assertThat(respuesta.statusCode()).isEqualTo(HttpStatus.OK);
                    assertThat(respuesta.headers().getContentType())
                            .isEqualTo(MediaType.APPLICATION_JSON);
                })
                .verifyComplete();
    }

    @Nested
    @DisplayName("consultarNovedades")
    class ConsultarNovedades {

        @Test
        @DisplayName("sin parámetro de búsqueda pasa null, que el caso de uso lee como «todo»")
        void sinBusquedaPasaNull() {
            when(peticion.queryParam("busqueda")).thenReturn(Optional.empty());
            when(novedades.ejecutar(any())).thenReturn(Mono.just(List.of()));

            respuestaOk(manejador.consultarNovedades(peticion));

            verify(novedades).ejecutar(busquedaCaptor.capture());
            assertThat(busquedaCaptor.getValue()).isNull();
        }

        @Test
        @DisplayName("con parámetro lo pasa tal cual, sin recortarlo ni normalizarlo aquí")
        void conBusquedaLaPasaTalCual() {
            when(peticion.queryParam("busqueda")).thenReturn(Optional.of("  glosa "));
            when(novedades.ejecutar(any())).thenReturn(Mono.just(List.of()));

            respuestaOk(manejador.consultarNovedades(peticion));

            verify(novedades).ejecutar(busquedaCaptor.capture());
            assertThat(busquedaCaptor.getValue()).isEqualTo("  glosa ");
        }

        @Test
        @DisplayName("responde 200 con JSON")
        void respondeOkConJson() {
            when(peticion.queryParam("busqueda")).thenReturn(Optional.empty());
            when(novedades.ejecutar(any()))
                    .thenReturn(Mono.just(List.of(mensaje("332-1", Severidad.BLOQUEANTE))));

            respuestaOk(manejador.consultarNovedades(peticion));
        }

        @Test
        @DisplayName("un error del caso de uso se propaga para que lo traduzca el manejador global")
        void unErrorSePropaga() {
            var caida = new IllegalStateException("OHI no responde");
            when(peticion.queryParam("busqueda")).thenReturn(Optional.empty());
            when(novedades.ejecutar(any())).thenReturn(Mono.error(caida));

            StepVerifier.create(manejador.consultarNovedades(peticion))
                    .expectErrorMatches(e -> e == caida)
                    .verify();
        }
    }

    @Nested
    @DisplayName("consultarMotivos")
    class ConsultarMotivos {

        @Test
        @DisplayName("sin ámbito pide todos")
        void sinAmbitoPideTodos() {
            when(peticion.queryParam("ambito")).thenReturn(Optional.empty());
            when(acciones.motivosPara(any())).thenReturn(Mono.just(List.of()));

            respuestaOk(manejador.consultarMotivos(peticion));

            verify(acciones).motivosPara(ambitoCaptor.capture());
            assertThat(ambitoCaptor.getValue()).isNull();
        }

        @ParameterizedTest(name = "ambito=[{0}]")
        @ValueSource(strings = {"CUENTA_MEDICA", "cuenta_medica", "Cuenta_Medica"})
        @DisplayName("el ámbito se reconoce sin distinguir mayúsculas")
        void elAmbitoSeReconoceSinDistinguirMayusculas(String valor) {
            when(peticion.queryParam("ambito")).thenReturn(Optional.of(valor));
            when(acciones.motivosPara(any())).thenReturn(Mono.just(List.of()));

            respuestaOk(manejador.consultarMotivos(peticion));

            verify(acciones).motivosPara(ambitoCaptor.capture());
            assertThat(ambitoCaptor.getValue()).isEqualTo(Ambito.CUENTA_MEDICA);
        }

        @Test
        @DisplayName("un ámbito inventado NO falla: se ignora y se devuelven todos los motivos")
        void unAmbitoInventadoSeIgnora() {
            // Es deliberado —un filtro mal escrito no debería tumbar la consulta de un
            // catálogo— pero conviene tenerlo fijado: el cliente recibe 200 con la lista
            // completa, no un 400. Si algún día se quiere que avise, esta prueba lo dirá.
            when(peticion.queryParam("ambito")).thenReturn(Optional.of("LO_QUE_SEA"));
            when(acciones.motivosPara(any())).thenReturn(Mono.just(List.of(motivo("M1"))));

            respuestaOk(manejador.consultarMotivos(peticion));

            verify(acciones).motivosPara(ambitoCaptor.capture());
            assertThat(ambitoCaptor.getValue()).isNull();
        }

        @Test
        @DisplayName("un error del caso de uso se propaga")
        void unErrorSePropaga() {
            var caida = new IllegalStateException("catálogo caído");
            when(peticion.queryParam("ambito")).thenReturn(Optional.empty());
            when(acciones.motivosPara(any())).thenReturn(Mono.error(caida));

            StepVerifier.create(manejador.consultarMotivos(peticion))
                    .expectErrorMatches(e -> e == caida)
                    .verify();
        }
    }
    /**
     * El catálogo de motivos <b>de pendiente</b>.
     *
     * <p>Es el tercero, y el que más fácil se confunde: el documento del MVP llama «motivos»
     * a este y al de desfinalización, que se publica en la ruta de al lado. Ofrecer el que no
     * es daría una lista que el sistema de registro rechazaría entera.
     */
    @org.junit.jupiter.api.Nested
    @DisplayName("catálogo de motivos de pendiente")
    class MotivosDePendiente {

        @Test
        @Tag("DBG-05")
        @DisplayName("publica código, texto e indicador de sola adjudicación")
        void publicaCodigoTextoEIndicador() {
            when(catalogoMotivosPendiente.listar()).thenReturn(reactor.core.publisher.Mono.just(
                    java.util.List.of(
                            new co.sura.auditoria.modelo.cuenta.MotivoPendienteCatalogo(
                                    "MP_VALIDAR_INFORMACION", "Validar información", true),
                            new co.sura.auditoria.modelo.cuenta.MotivoPendienteCatalogo(
                                    "MP_FATAL_SIN_GLOSA", "Fatal sin glosa", false))));

            StepVerifier.create(manejador.consultarMotivosDePendiente(peticion))
                    .assertNext(r -> assertThat(r.statusCode())
                            .isEqualTo(org.springframework.http.HttpStatus.OK))
                    .verifyComplete();

            verify(catalogoMotivosPendiente).listar();
        }

        @Test
        @Tag("DBG-05")
        @DisplayName("un catálogo vacío responde 200 con lista vacía, no un error")
        void unCatalogoVacioResponde200() {
            // Si el recorrido falla, el selector se queda sin opciones y se dice así; un
            // error haría que la pantalla de la grilla no cargara por un catálogo auxiliar.
            when(catalogoMotivosPendiente.listar())
                    .thenReturn(reactor.core.publisher.Mono.just(java.util.List.of()));

            StepVerifier.create(manejador.consultarMotivosDePendiente(peticion))
                    .assertNext(r -> assertThat(r.statusCode())
                            .isEqualTo(org.springframework.http.HttpStatus.OK))
                    .verifyComplete();
        }
    }
}