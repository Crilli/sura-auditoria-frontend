package co.sura.auditoria.api.error;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import java.net.URI;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.server.ServerWebExchange;

/**
 * Qué deja en el log cada respuesta de error (OPE-05).
 *
 * <p>El manejador que trae Spring Boot solo escribía los 500, así que los 503 —circuito
 * abierto, pool lleno, timeout— salían sin rastro. Aquí se fija que cada 5xx deje una línea
 * con lo necesario para atribuirlo, y que los 4xx, que son respuestas de negocio y pueden ser
 * miles en una prueba de carga, no inunden el log.
 */
@DisplayName("ManejadorErroresJson — registro de errores")
class RegistroDeErroresTest {

    private final ListAppender<ILoggingEvent> eventos = new ListAppender<>();
    private final Logger logger = (Logger) LoggerFactory.getLogger(ManejadorErroresJson.class);
    private Level nivelPrevio;
    private ManejadorErroresJson manejador;

    @BeforeEach
    void preparar() {
        nivelPrevio = logger.getLevel();
        eventos.start();
        logger.addAppender(eventos);
        manejador = new ManejadorErroresJson(new AtributosErrorGlobal(),
                new StaticApplicationContext(), ServerCodecConfigurer.create());
    }

    @AfterEach
    void limpiar() {
        logger.detachAppender(eventos);
        logger.setLevel(nivelPrevio);
    }

    private static ServerRequest solicitud(Map<String, Object> cuerpo) {
        var solicitud = mock(ServerRequest.class);
        var intercambio = mock(ServerWebExchange.class);
        when(solicitud.method()).thenReturn(HttpMethod.POST);
        when(solicitud.path()).thenReturn("/api/v1/cuentas/CM-94421/pendientes/resolver");
        when(solicitud.uri()).thenReturn(URI.create("http://localhost/api/v1/cuentas/CM-94421/pendientes/resolver"));
        when(solicitud.exchange()).thenReturn(intercambio);
        when(intercambio.getLogPrefix()).thenReturn("[abc] ");
        when(solicitud.attribute(anyString())).thenReturn(Optional.ofNullable(cuerpo));
        return solicitud;
    }

    private static ServerResponse respuesta(HttpStatus estado) {
        var respuesta = mock(ServerResponse.class);
        when(respuesta.statusCode()).thenReturn(estado);
        return respuesta;
    }

    private static ExcepcionDeDominio circuitoAbierto() {
        return ExcepcionDeDominio.de(new ErrorDeDominio.SistemaRegistroNoDisponible(
                "El circuito hacia el sistema de registro está abierto por fallos previos"));
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("un 503 deja una línea WARN con código, ruta, idTraza y la causa")
    void un503DejaRastro() {
        var cuerpo = Map.<String, Object>of("codigo", "SISTEMA_REGISTRO_NO_DISPONIBLE", "idTraza", "t-123");

        manejador.logError(solicitud(cuerpo), respuesta(HttpStatus.SERVICE_UNAVAILABLE), circuitoAbierto());

        assertThat(eventos.list).singleElement().satisfies(e -> {
            assertThat(e.getLevel()).isEqualTo(Level.WARN);
            assertThat(e.getFormattedMessage())
                    .contains("HTTP 503 SISTEMA_REGISTRO_NO_DISPONIBLE POST")
                    .contains("/pendientes/resolver")
                    .contains("idTraza=t-123")
                    .contains("circuito hacia el sistema de registro está abierto");
        });
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("sin cuerpo guardado, la línea sale igual con guiones")
    void sinCuerpo() {
        manejador.logError(solicitud(null), respuesta(HttpStatus.GATEWAY_TIMEOUT),
                           new IllegalStateException("se agotó la espera"));

        assertThat(eventos.list).singleElement().satisfies(e -> assertThat(e.getFormattedMessage())
                .contains("HTTP 504 - POST").contains("idTraza=-")
                .contains("IllegalStateException: se agotó la espera"));
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("los 4xx no se escriben salvo en DEBUG")
    void los4xxSoloEnDebug() {
        var conflicto = ExcepcionDeDominio.de(new ErrorDeDominio.ModificacionConcurrente("linea:1", 3));

        logger.setLevel(Level.INFO);
        manejador.logError(solicitud(Map.of()), respuesta(HttpStatus.PRECONDITION_FAILED), conflicto);
        assertThat(eventos.list).isEmpty();

        logger.setLevel(Level.DEBUG);
        manejador.logError(solicitud(Map.of()), respuesta(HttpStatus.PRECONDITION_FAILED), conflicto);
        assertThat(eventos.list).singleElement()
                .satisfies(e -> assertThat(e.getLevel()).isEqualTo(Level.DEBUG));
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("un 500 sigue por el registro de Spring Boot, con su traza")
    void un500SigueComoAntes() {
        manejador.logError(solicitud(Map.of()), respuesta(HttpStatus.INTERNAL_SERVER_ERROR),
                           new NullPointerException("fallo"));

        // El nuestro no escribe nada: lo hace el registro de la clase madre, con su propio logger.
        assertThat(eventos.list).isEmpty();
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("la causa dice si el error vino de una respuesta HTTP del sistema de registro")
    void laCausaDistingueElOrigen() {
        var deOhi = new ExcepcionDeDominio(new ErrorDeDominio.SistemaRegistroNoDisponible("Respuesta 502")) {
            @Override public String toString() { return "respuesta HTTP 502 del sistema de registro"; }
        };

        assertThat(ManejadorErroresJson.causa(circuitoAbierto()))
                .startsWith("SistemaRegistroNoDisponible[").doesNotContain("respuesta HTTP");
        assertThat(ManejadorErroresJson.causa(deOhi))
                .contains("Respuesta 502").endsWith("; respuesta HTTP 502 del sistema de registro");
    }
}
