package co.sura.auditoria.api.manejador;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.api.dto.SolicitudCambiosEnLote;
import co.sura.auditoria.modelo.cuenta.CambiosEnLote;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.ResultadoPorLinea;
import co.sura.auditoria.api.dto.SolicitudGuardarLinea;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarDetalleLineaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarLineaCasoDeUso;
import co.sura.auditoria.casodeuso.ListarLineasCasoDeUso;
import co.sura.auditoria.casodeuso.ObtenerLineaSiguienteCasoDeUso;
import co.sura.auditoria.casodeuso.ResumirFiltrosLineasCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CatalogoPrestacion;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.OrdenLineas;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ManejadorLineas")
class ManejadorLineasTest {

    private static final String CODIGO = "CM-108800618430";
    private static final String REFERENCIA = "148111592284";

    @Mock ListarLineasCasoDeUso listar;
    @Mock ObtenerLineaSiguienteCasoDeUso siguiente;
    @Mock ResumirFiltrosLineasCasoDeUso resumirFiltros;
    @Mock ConsultarDetalleLineaCasoDeUso detalle;
    @Mock GuardarLineaCasoDeUso guardar;
    @Mock co.sura.auditoria.casodeuso.AplicarCambiosEnLoteCasoDeUso aplicarEnLote;
    @Mock ValidadorSolicitudes validador;
    @Mock ServerRequest solicitud;
    @Mock ServerRequest.Headers cabeceras;

    @InjectMocks ManejadorLineas manejador;

    @Captor ArgumentCaptor<FiltroLineas> filtroCaptor;
    @Captor ArgumentCaptor<Integer> desplazamientoCaptor;
    @Captor ArgumentCaptor<OrdenLineas> ordenCaptor;
    @Captor ArgumentCaptor<Integer> tamanoCaptor;

    private static LineaCuenta linea() {
        return new LineaCuenta(new ReferenciaLinea(148111592284L), new CodigoCuenta(CODIGO), 1,
                null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, false, false, false, false, false,
                false, null, null, null, List.of(), List.of(), List.of(), List.of(),
                null, new Version(1L));
    }

    private static void respuestaOk(Mono<ServerResponse> resultado) {
        StepVerifier.create(resultado)
                .assertNext(r -> {
                    assertThat(r.statusCode()).isEqualTo(HttpStatus.OK);
                    assertThat(r.headers().getContentType())
                            .isEqualTo(MediaType.APPLICATION_JSON);
                })
                .verifyComplete();
    }

    /** Todos los parámetros ausentes salvo los que la prueba indique. */
    private void sinParametros(String... presentes) {
        when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
        for (var p : List.of("pagina", "desplazamiento", "tamano", "orden", "sentido",
                             "cedula", "desde", "hasta",
                             "autorizacion", "prestacion", "catalogo",
                             "glosaDesde", "glosaHasta",
                             "conNovedad", "motivoPendiente", "bloqueo")) {
            lenient().when(solicitud.queryParam(p)).thenReturn(Optional.empty());
        }
    }

    private void parametro(String nombre, String valor) {
        lenient().when(solicitud.queryParam(nombre)).thenReturn(Optional.of(valor));
    }

    private void listadoDevuelvePagina() {
        when(listar.ejecutar(any(), anyInt(), anyInt(), any(), any()))
                .thenReturn(Mono.just(PaginaDesplazada.<ResumenLinea>vacia(25)));
    }

    @Nested
    @DisplayName("consultarSiguiente")
    class ConsultarSiguiente {

        private static ResumenLinea resumen(int numeroLinea) {
            return new ResumenLinea(new ReferenciaLinea(99L), numeroLinea,
                    LocalDate.now(), LocalDate.now(), "CC1", "Afiliado", "873206", "desc",
                    "CUPS", "AUT1", BigDecimal.TEN, BigDecimal.TEN, BigDecimal.ZERO,
                    false, false, false, false, 0, List.of(), false, List.of(), new Version(1L), null, null, null, null, null, null);
        }

        @Test
        @DisplayName("devuelve la línea siguiente con 200")
        void devuelveLaSiguienteCon200() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn(REFERENCIA);
            when(siguiente.ejecutar(any(), any())).thenReturn(Mono.just(resumen(102)));

            respuestaOk(manejador.consultarSiguiente(solicitud));
        }

        @Test
        @DisplayName("la última línea de la cuenta responde 204, no un error ni un cuerpo vacío")
        void laUltimaResponde204() {
            // El cliente distingue «no hay siguiente» de «falló la consulta» por
            // esto: con un 200 y cuerpo nulo tendría que adivinar.
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn(REFERENCIA);
            when(siguiente.ejecutar(any(), any())).thenReturn(Mono.empty());

            StepVerifier.create(manejador.consultarSiguiente(solicitud))
                    .assertNext(r -> assertThat(r.statusCode())
                            .isEqualTo(HttpStatus.NO_CONTENT))
                    .verifyComplete();
        }

        @Test
        @DisplayName("una referencia que no es número se rechaza antes de consultar")
        void unaReferenciaNoNumericaSeRechaza() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn("abc");

            assertThatThrownBy(() -> manejador.consultarSiguiente(solicitud))
                    .isInstanceOf(NumberFormatException.class);
            verify(siguiente, never()).ejecutar(any(), any());
        }
    }

    @Nested
    @DisplayName("listarResumen — paginación por desplazamiento")
    class Paginacion {

        @Test
        @DisplayName("sin parámetros arranca en el principio y con tamaño 25")
        void sinParametrosArrancaEnElPrincipio() {
            sinParametros();
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), desplazamientoCaptor.capture(),
                    tamanoCaptor.capture(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isZero();
            assertThat(tamanoCaptor.getValue()).isEqualTo(25);
        }

        @Test
        @DisplayName("un número de página se traduce multiplicando por el tamaño")
        void unNumeroDePaginaSeTraduceMultiplicando() {
            sinParametros();
            parametro("pagina", "161");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isEqualTo(161 * 25);
        }

        @Test
        @DisplayName("la traducción usa el tamaño pedido, no el de por omisión")
        void laTraduccionUsaElTamanoPedido() {
            sinParametros();
            parametro("pagina", "3");
            parametro("tamano", "10");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isEqualTo(30);
        }

        @Test
        @DisplayName("un desplazamiento explícito manda sobre el número de página")
        void unDesplazamientoExplicitoMandaSobreLaPagina() {
            sinParametros();
            parametro("desplazamiento", "4025");
            parametro("pagina", "7");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isEqualTo(4025);
        }

        @ParameterizedTest(name = "pagina={0}")
        @ValueSource(strings = {"-1", "-161"})
        @DisplayName("una página negativa cae en el principio, no en un desplazamiento negativo")
        void unaPaginaNegativaCaeEnElPrincipio(String pagina) {
            sinParametros();
            parametro("pagina", pagina);
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isZero();
        }

        @Test
        @DisplayName("una página tan alta que desbordaría cae más allá del final, no en el principio")
        void unaPaginaQueDesbordariaNoVuelveAlPrincipio() {
            sinParametros();
            parametro("pagina", "90000000");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isEqualTo(Integer.MAX_VALUE);
        }

        @Test
        @DisplayName("un tamaño explícito se respeta; el recorte al máximo lo hace el caso de uso")
        void unTamanoExplicitoSeRespeta() {
            sinParametros();
            parametro("tamano", "10");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), tamanoCaptor.capture(), any(), any());
            assertThat(tamanoCaptor.getValue()).isEqualTo(10);
        }

        @ParameterizedTest(name = "{0}=abc")
        @ValueSource(strings = {"pagina", "desplazamiento", "tamano"})
        @DisplayName("un parámetro de paginación que no es número se rechaza, en vez de caer "
                   + "en la primera página en silencio")
        void unParametroNoNumericoSeRechaza(String nombre) {
            sinParametros();
            parametro(nombre, "abc");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("abc");
            verify(listar, never()).ejecutar(any(), anyInt(), anyInt(), any(), any());
        }
    }

    @Nested
    @DisplayName("listarResumen — ordenamiento")
    class Ordenamiento {

        @Test
        @Tag("F3-ORD-00")
        @DisplayName("sin parámetro ordena por número de línea, que es como se lee una cuenta")
        void sinParametroOrdenaPorNumeroDeLinea() {
            sinParametros();
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), any(), ordenCaptor.capture());
            assertThat(ordenCaptor.getValue()).isEqualTo(OrdenLineas.PREDETERMINADO);
        }

        @ParameterizedTest(name = "orden={0} → {1}")
        @CsvSource({
                "numero_linea,        NUMERO_LINEA",
                "cedula_afiliado,     CEDULA_AFILIADO",
                "fecha_atencion,      FECHA_ATENCION",
                "codigo_autorizacion, CODIGO_AUTORIZACION",
                "codigo_prestacion,   CODIGO_PRESTACION",
                "valor_glosado,       VALOR_GLOSADO",
                "valor_cargado,       VALOR_CARGADO",
        })
        @Tag("F3-ORD-00")
        @DisplayName("los siete campos que pide el documento se aceptan")
        void losSieteCamposSeAceptan(String pedido, String esperado) {
            sinParametros();
            parametro("orden", pedido);
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), any(), ordenCaptor.capture());
            assertThat(ordenCaptor.getValue().campo().name()).isEqualTo(esperado);
        }

        @Test
        @Tag("F3-ORD-00")
        @DisplayName("el sentido descendente se entiende, en largo y en corto")
        void elSentidoDescendenteSeEntiende() {
            sinParametros();
            parametro("orden", "valor_glosado");
            parametro("sentido", "desc");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), any(), ordenCaptor.capture());
            assertThat(ordenCaptor.getValue().sentido())
                    .isEqualTo(OrdenLineas.Sentido.DESCENDENTE);
        }

        @Test
        @Tag("F3-ORD-00")
        @DisplayName("un campo desconocido se rechaza, en vez de devolver otro orden en silencio")
        void unCampoDesconocidoSeRechaza() {
            sinParametros();
            parametro("orden", "loQueSea");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("loQueSea")
                    .hasMessageContaining("valor_glosado");
            verify(listar, never()).ejecutar(any(), anyInt(), anyInt(), any(), any());
        }

        @Test
        @Tag("F3-ORD-00")
        @DisplayName("un sentido que no es asc ni desc se rechaza")
        void unSentidoDesconocidoSeRechaza() {
            sinParametros();
            parametro("orden", "secuencia");
            parametro("sentido", "arriba");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class);
        }
    }

    @Nested
    @DisplayName("listarResumen — filtros")
    class Filtros {

        @Test
        @DisplayName("sin parámetros el filtro va vacío")
        void sinParametrosElFiltroVaVacio() {
            sinParametros();
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue().vacio()).isTrue();
        }

        @Test
        @DisplayName("recoge los criterios que se empujan a OHI")
        void recogeLosCriteriosEmpujables() {
            sinParametros();
            parametro("cedula", "CC1000000001");
            parametro("autorizacion", "104409176961");
            parametro("prestacion", "873206");
            parametro("desde", "2026-08-01");
            parametro("hasta", "2026-08-31");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            var f = filtroCaptor.getValue();
            assertThat(f.cedulaAfiliado()).isEqualTo("CC1000000001");
            assertThat(f.codigoAutorizacion()).isEqualTo("104409176961");
            assertThat(f.codigoPrestacion()).isEqualTo("873206");
            assertThat(f.desde()).isEqualTo(LocalDate.of(2026, 8, 1));
            assertThat(f.hasta()).isEqualTo(LocalDate.of(2026, 8, 31));
        }

        @Test
        @DisplayName("recoge los que exigen recorte en cliente")
        void recogeLosDeRecorteLocal() {
            sinParametros();
            parametro("catalogo", "cups");
            parametro("glosaDesde", "100.50");
            parametro("glosaHasta", "2000");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            var f = filtroCaptor.getValue();
            assertThat(f.catalogo()).isEqualTo(CatalogoPrestacion.CUPS);
            assertThat(f.glosaDesde()).isEqualByComparingTo("100.50");
            assertThat(f.glosaHasta()).isEqualByComparingTo("2000");
            assertThat(f.exigeFiltradoLocal()).isTrue();
        }

        @ParameterizedTest(name = "parámetro [{0}] en blanco se ignora")
        @ValueSource(strings = {"desde", "hasta", "catalogo", "glosaDesde", "glosaHasta"})
        @DisplayName("un parámetro en blanco se ignora en vez de explotar al parsearlo")
        void unParametroEnBlancoSeIgnora(String nombre) {
            sinParametros();
            parametro(nombre, "   ");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue().vacio()).isTrue();
        }
    }

    @Nested
    @DisplayName("errores de forma en los filtros")
    class ErroresDeForma {

        @Test
        @DisplayName("una fecha mal escrita dice el formato esperado y repite lo recibido")
        void unaFechaMalEscritaDiceElFormato() {
            sinParametros();
            parametro("desde", "01/08/2026");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("aaaa-mm-dd")
                    .hasMessageContaining("01/08/2026");
        }

        @Test
        @DisplayName("un importe que no es número lo dice")
        void unImporteNoNumericoLoDice() {
            sinParametros();
            parametro("glosaDesde", "mucho");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("tiene que ser un número")
                    .hasMessageContaining("mucho");
        }

        @Test
        @DisplayName("un catálogo inventado enumera los admitidos")
        void unCatalogoInventadoEnumeraLosAdmitidos() {
            sinParametros();
            parametro("catalogo", "IUM");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("CUPS, CUM, SURACUPS, PROPIO u OTRO")
                    .hasMessageContaining("IUM");
        }

        @ParameterizedTest(name = "[{0}] -> {1}")
        @CsvSource({"cups, CUPS", "  CUM  , CUM", "SuraCups, SURACUPS", "propio, PROPIO"})
        @DisplayName("el catálogo se reconoce sin distinguir mayúsculas ni espacios")
        void elCatalogoSeReconoceFlexible(String entrada, CatalogoPrestacion esperado) {
            sinParametros();
            parametro("catalogo", entrada);
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue().catalogo()).isEqualTo(esperado);
        }
    }

    @Nested
    @DisplayName("resumirFiltros")
    class ResumirFiltros {

        @Test
        @DisplayName("un resumen vacío responde 200 con listas vacías")
        void unResumenVacio() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(resumirFiltros.ejecutar(any()))
                    .thenReturn(Mono.just(ResumenFiltrosLineas.vacio()));

            respuestaOk(manejador.resumirFiltros(solicitud));
        }

        @Test
        @DisplayName("el catálogo viaja con su nombre y su etiqueta legible")
        void elCatalogoViajaConNombreYEtiqueta() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(resumirFiltros.ejecutar(any())).thenReturn(Mono.just(
                    new ResumenFiltrosLineas(
                            List.of(new ResumenFiltrosLineas.AfiliadoConLineas(
                                    "CC1", "Afiliado Uno", 4)),
                            List.of(new ResumenFiltrosLineas.CatalogoConLineas(
                                    CatalogoPrestacion.PROPIO, 2)),
                            LocalDate.of(2026, 8, 1), LocalDate.of(2026, 8, 31),
                            new BigDecimal("1500"), 1, 6)));

            respuestaOk(manejador.resumirFiltros(solicitud));

            verify(resumirFiltros).ejecutar(any());
        }
    }

    @Nested
    @DisplayName("consultarDetalle y guardarLinea")
    class DetalleYGuardado {

        @Test
        @DisplayName("el detalle toma la referencia de la ruta")
        void elDetalleTomaLaReferenciaDeLaRuta() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn(REFERENCIA);
            when(detalle.ejecutar(any(), any())).thenReturn(Mono.just(linea()));

            respuestaOk(manejador.consultarDetalle(solicitud));

            verify(detalle).ejecutar(eq(new CodigoCuenta(CODIGO)),
                                     eq(new ReferenciaLinea(148111592284L)));
        }

        @Test
        @DisplayName("una referencia que no es número explota antes de consultar")
        void unaReferenciaNoNumericaExplota() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn("abc");

            assertThatThrownBy(() -> manejador.consultarDetalle(solicitud))
                    .isInstanceOf(NumberFormatException.class);
            verify(detalle, never()).ejecutar(any(), any());
        }

        @Test
        @DisplayName("guardar valida el cuerpo y usa el auditor de la cabecera")
        void guardarValidaYUsaElAuditor() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn(REFERENCIA);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(cabeceras.firstHeader("X-Auditor")).thenReturn("auditor@sura.com.co");
            var dto = new SolicitudGuardarLinea(5L, null, null, null, null, null,
                    "observación", null, null, null, null, null, null, null, null, null,
                    null, null, null, "EN_CASCADA", null, null, null, null, null, null);
            when(solicitud.bodyToMono(SolicitudGuardarLinea.class)).thenReturn(Mono.just(dto));
            when(guardar.ejecutar(any(), any(), any())).thenReturn(Mono.just(linea()));

            respuestaOk(manejador.guardarLinea(solicitud));

            verify(validador).validar(dto);
            verify(guardar).ejecutar(any(), any(), eq("auditor@sura.com.co"));
        }

        /**
         * El PATCH con los nombres retirados se rechaza con 400, y no en silencio.
         *
         * <p>El 2026-10-21 «valorAutorizado» dejó de ser el campo con el que se escribía el
         * convenido (allowedAmount) y pasó a nombrar el coveredAmount, que no se escribe. Spring
         * ignora las propiedades que no conoce: sin el rechazo explícito, un cliente que no se
         * hubiera actualizado vería su cambio descartado sin aviso. Aquí se recorre el camino de
         * verdad —JSON leído como lo lee Spring, validador real y traducción del error a HTTP—
         * porque es la combinación la que da el 400, no una pieza sola.
         */
        @ParameterizedTest(name = "[GRID-18] «{0}» responde 400")
        @ValueSource(strings = {"valorAutorizado", "unidadesAutorizadas",
                                "valorCubierto", "unidadesCubiertas"})
        @Tag("GRID-18")
        @Tag("LIN-09")
        @DisplayName("[GRID-18][LIN-09] un PATCH con un nombre retirado responde 400 y no guarda")
        void unNombreRetiradoResponde400(String campo) throws Exception {
            var error = errorAlGuardar("""
                    {"versionEsperada": 5, "modoRecalculo": "AISLADO", "%s": 800}
                    """.formatted(campo));

            assertThat(error).isInstanceOf(jakarta.validation.ConstraintViolationException.class);
            var http = comoRespuestaHttp(error);
            assertThat(http).containsEntry("estado", 400)
                            .containsEntry("codigo", "SOLICITUD_INVALIDA");
            // El mensaje nombra el campo y dice cuál es el que sí se puede escribir.
            assertThat(http.get("mensaje").toString()).startsWith(campo + ": ")
                    .contains("unidadesAutorizadas".equals(campo) || "unidadesCubiertas".equals(campo)
                              ? "unidadesConvenidas" : "valorConvenido");
            verify(guardar, never()).ejecutar(any(), any(), any());
        }

        @Test
        @Tag("GRID-18")
        @DisplayName("[GRID-18] el nombre retirado se rechaza aunque venga en null: lo que cuenta es que venga")
        void unNombreRetiradoEnNullTambienSeRechaza() throws Exception {
            // Un formulario viejo manda todos sus campos, también los vacíos: «valorAutorizado:
            // null» es la huella de un cliente que no se ha actualizado, y merece el mismo aviso.
            var error = errorAlGuardar("""
                    {"versionEsperada": 5, "modoRecalculo": "AISLADO", "valorConvenido": 900,
                     "valorAutorizado": null}
                    """);

            assertThat(comoRespuestaHttp(error)).containsEntry("estado", 400);
            verify(guardar, never()).ejecutar(any(), any(), any());
        }

        @Test
        @Tag("GRID-18")
        @Tag("LIN-07")
        @DisplayName("[GRID-18][LIN-07] con los nombres nuevos el convenido llega al caso de uso")
        void conLosNombresNuevosGuarda() throws Exception {
            var capturada = ArgumentCaptor.forClass(co.sura.auditoria.modelo.cuenta.EdicionLinea.class);
            when(guardar.ejecutar(any(), capturada.capture(), any())).thenReturn(Mono.just(linea()));

            respuestaOk(manejadorConValidadorReal().guardarLinea(peticionConCuerpo("""
                    {"versionEsperada": 5, "modoRecalculo": "AISLADO",
                     "valorConvenido": 900, "unidadesConvenidas": 3, "valorCargado": 1000}
                    """)));

            var edicion = capturada.getValue();
            assertThat(edicion.valorConvenido()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("900"));
            assertThat(edicion.unidadesConvenidas()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("3"));
            assertThat(edicion.valorCargado()).hasValueSatisfying(
                    v -> assertThat(v).isEqualByComparingTo("1000"));
        }

        /** El mismo manejador, pero con el validador de verdad y no con el doble. */
        private ManejadorLineas manejadorConValidadorReal() {
            return new ManejadorLineas(listar, siguiente, resumirFiltros, detalle, guardar,
                    aplicarEnLote, new ValidadorSolicitudes(
                            jakarta.validation.Validation.buildDefaultValidatorFactory().getValidator()));
        }

        /**
         * La petición con el cuerpo leído como lo lee Spring: su constructor de ObjectMapper deja
         * pasar las propiedades desconocidas, que es justo lo que hace falta reproducir.
         */
        private ServerRequest peticionConCuerpo(String json) throws Exception {
            var lector = org.springframework.http.converter.json.Jackson2ObjectMapperBuilder.json().build();
            var dto = lector.readValue(json, SolicitudGuardarLinea.class);
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn(REFERENCIA);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(solicitud.bodyToMono(SolicitudGuardarLinea.class)).thenReturn(Mono.just(dto));
            return solicitud;
        }

        private Throwable errorAlGuardar(String json) throws Exception {
            var error = new java.util.concurrent.atomic.AtomicReference<Throwable>();
            StepVerifier.create(manejadorConValidadorReal().guardarLinea(peticionConCuerpo(json)))
                    .expectErrorSatisfies(error::set)
                    .verify();
            return error.get();
        }

        /** Lo que saldría por HTTP: el mismo traductor de errores que usa la aplicación. */
        private static java.util.Map<String, Object> comoRespuestaHttp(Throwable error) {
            var atributos = new co.sura.auditoria.api.error.AtributosErrorGlobal() {
                @Override
                public Throwable getError(ServerRequest peticion) {
                    return error;
                }
            };
            return atributos.getErrorAttributes(org.mockito.Mockito.mock(ServerRequest.class),
                    org.springframework.boot.web.error.ErrorAttributeOptions.defaults());
        }

        @Test
        @DisplayName("guardar sin cuerpo lo dice explícitamente")
        void guardarSinCuerpoLoDice() {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.pathVariable("referencia")).thenReturn(REFERENCIA);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(solicitud.bodyToMono(SolicitudGuardarLinea.class)).thenReturn(Mono.empty());

            StepVerifier.create(manejador.guardarLinea(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }
    }
    /**
     * Los tres criterios que viven en una colección hija de la línea.
     *
     * <p>Se comprueban aquí, y no solo en el dominio, porque lo que puede salir mal es la
     * lectura del parámetro: un {@code conNovedad} que se interprete «todo lo que no sea
     * true es false» convierte un valor mal escrito en «sin filtro», y el auditor ve la
     * cuenta entera creyendo que filtró. Es un 200 con el dato equivocado.
     */
    @Nested
    @DisplayName("filtros de novedad y de pendiente")
    class FiltrosDeColeccionesHijas {

        @Test
        @Tag("F3-NOV-01")
        @DisplayName("conNovedad=true llega al caso de uso como criterio")
        void conNovedadLlegaComoCriterio() {
            sinParametros();
            parametro("conNovedad", "true");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            var f = filtroCaptor.getValue();
            assertThat(f.conNovedad()).isTrue();
            assertThat(f.vacio()).isFalse();
            // Se empuja: la página no pierde el total por filtrar por novedad.
            assertThat(f.exigeFiltradoLocal()).isFalse();
        }

        @Test
        @Tag("F3-NOV-01")
        @DisplayName("sin el parámetro no se filtra por novedad")
        void sinElParametroNoSeFiltra() {
            sinParametros();
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue().conNovedad()).isFalse();
        }

        @ParameterizedTest(name = "conNovedad={0}")
        @ValueSource(strings = {"1", "si", "TRUE ", "False"})
        @Tag("F3-NOV-01")
        @DisplayName("un valor que no es true ni false se rechaza, no se da por false")
        void unValorQueNoEsBooleanoSeRechaza(String valor) {
            sinParametros();
            parametro("conNovedad", valor);

            // «TRUE » y «False» con otra caja sí se admiten: se recorta y se baja la caja.
            if (valor.trim().equalsIgnoreCase("true") || valor.trim().equalsIgnoreCase("false")) {
                listadoDevuelvePagina();
                respuestaOk(manejador.listarResumen(solicitud));
                return;
            }
            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("admite true o false")
                    .hasMessageContaining(valor);
        }

        @Test
        @Tag("F2-06")
        @DisplayName("el motivo de pendiente llega tal cual")
        void elMotivoLlegaTalCual() {
            sinParametros();
            parametro("motivoPendiente", "MP_EVALUAR_UEN");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue().motivoPendiente()).isEqualTo("MP_EVALUAR_UEN");
        }

        @Test
        @Tag("F2-06")
        @DisplayName("bloqueo usa el mismo vocabulario que la pantalla de pendientes")
        void bloqueoUsaElMismoVocabulario() {
            sinParametros();
            parametro("bloqueo", "bloqueantes");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            var f = filtroCaptor.getValue();
            assertThat(f.bloqueo()).isEqualTo(FiltroBloqueo.BLOQUEANTES);
            // El estado no llega de fuera: lo resuelve la capa de integración.
            assertThat(f.exigeEstadoDeLaCuenta()).isTrue();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("sin el parámetro, bloqueo es TODOS y no cuesta la consulta del estado")
        void sinElParametroBloqueoEsTodos() {
            sinParametros();
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            var f = filtroCaptor.getValue();
            assertThat(f.bloqueo()).isEqualTo(FiltroBloqueo.TODOS);
            assertThat(f.exigeEstadoDeLaCuenta()).isFalse();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("un bloqueo inventado enumera los admitidos")
        void unBloqueoInventadoEnumeraLosAdmitidos() {
            sinParametros();
            parametro("bloqueo", "los-feos");

            assertThatThrownBy(() -> manejador.listarResumen(solicitud))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("TODOS, BLOQUEANTES o NO_BLOQUEANTES")
                    .hasMessageContaining("los-feos");
        }

        @ParameterizedTest(name = "parámetro [{0}] en blanco se ignora")
        @ValueSource(strings = {"conNovedad", "bloqueo", "motivoPendiente"})
        @Tag("F2-06")
        @DisplayName("un criterio nuevo en blanco se ignora en vez de explotar")
        void unCriterioNuevoEnBlancoSeIgnora(String nombre) {
            sinParametros();
            parametro(nombre, "   ");
            listadoDevuelvePagina();

            respuestaOk(manejador.listarResumen(solicitud));

            verify(listar).ejecutar(any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue().vacio()).isTrue();
        }
    }
    /**
     * El cambio en lote.
     *
     * <p>Dos cosas que se fijan aquí y no en el dominio: que un parcial responda <b>200</b>
     * —la petición fue correcta y algo se aplicó, y es irreversible: un error haría que el
     * cliente lo diera por no hecho— y que el número de línea llegue al cuerpo junto a la
     * referencia, porque la referencia es el identificador interno de OHI y no le dice nada
     * a quien lee el informe.
     */
    @Nested
    @DisplayName("aplicar en lote")
    class AplicarEnLote {

        private SolicitudCambiosEnLote cuerpo() {
            return new SolicitudCambiosEnLote(
                    List.of(10L, 20L), "AISLADO",
                    List.of(new co.sura.auditoria.api.dto.SolicitudCambioGlosa(
                            "AGREGAR", null, "TAR01", "G", "E",
                            new java.math.BigDecimal("1500"), "texto")),
                    null);
        }

        private void peticion(SolicitudCambiosEnLote dto) {
            when(solicitud.pathVariable("codigo")).thenReturn(CODIGO);
            when(solicitud.headers()).thenReturn(cabeceras);
            when(cabeceras.firstHeader("X-Auditor")).thenReturn("auditor@sura.com.co");
            when(solicitud.bodyToMono(SolicitudCambiosEnLote.class))
                    .thenReturn(dto == null ? Mono.empty() : Mono.just(dto));
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("valida el cuerpo, usa el auditor de la cabecera y traduce la selección")
        void validaTraduceYUsaElAuditor() {
            var dto = cuerpo();
            peticion(dto);
            when(aplicarEnLote.ejecutar(any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoPorLinea.de(
                            List.of(new ReferenciaLinea(10L), new ReferenciaLinea(20L)), List.of())));

            respuestaOk(manejador.aplicarEnLote(solicitud));

            verify(validador).validar(dto);
            var loteCaptor = ArgumentCaptor.forClass(CambiosEnLote.class);
            verify(aplicarEnLote).ejecutar(any(), loteCaptor.capture(), eq("auditor@sura.com.co"));
            var lote = loteCaptor.getValue();
            assertThat(lote.seleccion().identificadores()).containsExactly(10L, 20L);
            assertThat(lote.tocaGlosas()).isTrue();
            assertThat(lote.modoRecalculo()).isEqualTo(ModoRecalculo.AISLADO);
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("un parcial responde 200 y los fallos viajan en el cuerpo, con su número")
        void unParcialResponde200() {
            peticion(cuerpo());
            when(aplicarEnLote.ejecutar(any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoPorLinea.de(
                            List.of(new ReferenciaLinea(10L)),
                            List.of(new ResultadoPorLinea.Fallo(
                                    new ReferenciaLinea(20L), 37, "La línea está bloqueada")))));

            StepVerifier.create(manejador.aplicarEnLote(solicitud))
                    .assertNext(r -> assertThat(r.statusCode()).isEqualTo(HttpStatus.OK))
                    .verifyComplete();
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("sin cuerpo lo dice explícitamente")
        void sinCuerpoLoDice() {
            peticion(null);

            StepVerifier.create(manejador.aplicarEnLote(solicitud))
                    .expectErrorSatisfies(e -> assertThat(e)
                            .isInstanceOf(IllegalArgumentException.class)
                            .hasMessageContaining("El cuerpo es obligatorio"))
                    .verify();
        }
    }
}
