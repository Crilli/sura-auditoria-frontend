package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

/**
 * Una versión de la cuenta tal como quedó al transmitirse. Es una <b>foto</b>: sus importes
 * son los de esa versión, no los de la cuenta viva, y la pantalla tiene que decirlo.
 *
 * @param historial los estados por los que pasó esta versión, ya ordenados
 */
public record RespuestaFotoVersion(String codigo, int numero, LocalDate fechaEntrada,
                                   String numeroFactura, String prestador,
                                   BigDecimal valorFactura, BigDecimal totalCargado,
                                   BigDecimal totalAutorizado, BigDecimal totalCubierto,
                                   BigDecimal totalGlosado, BigDecimal totalNotasCredito,
                                   String estadoActual,
                                   List<Estado> historial) {

    public record Estado(String estado, Instant desde) {}
}
