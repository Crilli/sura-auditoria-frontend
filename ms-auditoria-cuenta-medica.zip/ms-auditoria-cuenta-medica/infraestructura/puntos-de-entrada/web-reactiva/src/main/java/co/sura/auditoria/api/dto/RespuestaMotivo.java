package co.sura.auditoria.api.dto;

/**
 * Un motivo del catálogo de desfinalización y anulación.
 *
 * <p>Publica las tres banderas porque las tres cambian lo que la pantalla tiene
 * que hacer, y ninguna se adivina del código.
 *
 * @param bloqueaLineas si al usarlo las líneas quedan bloqueadas y habrá que
 *        desbloquearlas después. Son 5 de los 16; avisarlo <b>antes</b> de
 *        elegir evita que el auditor lo descubra con la cuenta ya desfinalizada
 * @param exigeReferencia si sin referencia de origen el sistema de registro lo
 *        rechaza con un error que no nombra el campo
 * @param permiso el permiso propio del motivo, cuando lo tiene. Seis lo tienen,
 *        y de ahí que el rechazo hable de «todos los motivos especificados»: se
 *        comprueba motivo a motivo
 */
public record RespuestaMotivo(String codigo,
                              String descripcion,
                              boolean bloqueaLineas,
                              boolean exigeReferencia,
                              String ambito,
                              String permiso) {}
