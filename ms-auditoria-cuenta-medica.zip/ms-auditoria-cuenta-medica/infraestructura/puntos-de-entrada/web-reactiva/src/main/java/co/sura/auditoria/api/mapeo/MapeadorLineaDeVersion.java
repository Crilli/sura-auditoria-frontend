package co.sura.auditoria.api.mapeo;

import co.sura.auditoria.api.dto.RespuestaDetalleLineaDeVersion;
import co.sura.auditoria.api.dto.RespuestaLineaDeVersion;
import co.sura.auditoria.api.dto.RespuestaPaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;

/** Las líneas de una versión, del dominio a la respuesta del API (BUS-21). */
public final class MapeadorLineaDeVersion {

    private MapeadorLineaDeVersion() {}

    /** El mismo sobre que la página de líneas de la cuenta viva. */
    public static RespuestaPaginaDesplazada<RespuestaLineaDeVersion> aRespuestaDesplazada(
            PaginaDesplazada<LineaDeVersion> pagina) {
        return new RespuestaPaginaDesplazada<>(
                pagina.elementos().stream().map(MapeadorLineaDeVersion::aRespuesta).toList(),
                pagina.desplazamiento(),
                pagina.tamanoPagina(),
                pagina.numeroDePagina(),
                pagina.total().orElse(null),
                pagina.totalPaginas().orElse(null),
                pagina.hayMas());
    }

    public static RespuestaLineaDeVersion aRespuesta(LineaDeVersion l) {
        return new RespuestaLineaDeVersion(
                l.numeroLinea(), l.estado(), l.fechaInicio(), l.fechaFin(),
                l.codigoProcedimiento(), l.descripcionProcedimiento(), l.catalogoProcedimiento(),
                l.codigoAfiliado(), l.nombreAfiliado(), l.codigoAutorizacion(),
                l.prestadorCodigo(), l.prestadorNombre(),
                l.valorCargado(), l.unidadesCargadas(),
                l.valorConvenido(), l.unidadesConvenidas(),
                l.valorAutorizado(), l.unidadesAutorizadas(),
                l.valorGlosado(), l.valorIva(), l.porcentajeIva(),
                glosas(l));
    }

    public static RespuestaDetalleLineaDeVersion aRespuestaDetalle(DetalleLineaDeVersion d) {
        var l = d.linea();
        var c = d.convenio();
        var a = d.atencion();
        return new RespuestaDetalleLineaDeVersion(
                l.numeroLinea(), l.estado(), l.fechaInicio(), l.fechaFin(),
                l.codigoProcedimiento(), l.descripcionProcedimiento(), l.catalogoProcedimiento(),
                l.codigoAfiliado(), l.nombreAfiliado(), l.codigoAutorizacion(),
                l.prestadorCodigo(), l.prestadorNombre(),
                l.valorCargado(), l.unidadesCargadas(),
                l.valorConvenido(), l.unidadesConvenidas(),
                l.valorAutorizado(), l.unidadesAutorizadas(),
                l.valorGlosado(), l.valorIva(), l.porcentajeIva(),
                glosas(l),
                d.novedades().stream()
                        .map(n -> new RespuestaDetalleLineaDeVersion.NovedadDeVersion(
                                n.codigo(), n.severidad() == null ? null : n.severidad().name(),
                                n.texto(), n.origen(), n.anulada(), n.repeticiones()))
                        .toList(),
                d.diagnosticos().stream()
                        .map(x -> new RespuestaDetalleLineaDeVersion.DiagnosticoDeVersion(
                                x.secuencia(), x.codigo(), x.descripcion(), x.tipo()))
                        .toList(),
                new RespuestaDetalleLineaDeVersion.ConvenioDeVersion(
                        c.tarifaIss2000(), c.tarifaIss2001(), c.tarifaSoat(),
                        c.homologoCups(),
                        c.clausulas().stream()
                                .map(k -> new RespuestaDetalleLineaDeVersion.ClausulaDeVersion(
                                        k.monto(), k.descripcion(), k.regla()))
                                .toList()),
                new RespuestaDetalleLineaDeVersion.AtencionDeVersion(
                        a.tipoSala(), a.viaAcceso(), a.uen()));
    }

    private static java.util.List<RespuestaLineaDeVersion.GlosaDeVersion> glosas(LineaDeVersion l) {
        return l.glosas().stream()
                .map(g -> new RespuestaLineaDeVersion.GlosaDeVersion(
                        g.secuencia(), g.codigo(), g.valor(),
                        g.codigoNotaCredito(), g.valorNotaCredito(),
                        g.concepto(), g.conceptoEspecifico(), g.texto(), g.tipo()))
                .toList();
    }
}
