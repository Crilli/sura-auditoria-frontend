package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Un alta o una baja de novedad en la línea.
 *
 * <p>Viaja dentro del cuerpo del PATCH de la línea, por lo mismo que
 * {@link SolicitudCambioGlosa}: una novedad no existe fuera de su línea, y
 * mandarlas juntas permite que poner una novedad y corregir el valor autorizado
 * sean una sola operación, con una sola versión y un solo recálculo.
 *
 * <p><b>Tres campos, no siete</b>, al contrario que la glosa. Aquí sí hay
 * catálogo: el texto, la severidad y la clasificación normativa son del mensaje
 * que se elige, y aceptarlos aquí permitiría guardar una novedad cuyo texto no
 * es el de su código.
 *
 * <p><b>El origen no se recibe.</b> Lo pone la capa de integración como
 * {@code MANUAL}. Si llegara de fuera, un cliente podría grabar una novedad que
 * aparenta haberla levantado el motor de reglas, y el origen es justo el dato
 * con el que se distingue lo que decidió una persona.
 *
 * @param operacion      {@code AGREGAR} o {@code ELIMINAR}
 * @param identificador  el de la novedad a eliminar; no se envía al agregar,
 *                       porque lo asigna el sistema de registro
 * @param codigoNovedad  el código del mensaje del catálogo, p. ej. {@code TA0401}
 */
public record SolicitudCambioNovedad(

        @NotNull(message = "Hay que decir si la novedad se agrega o se elimina")
        @Pattern(regexp = "AGREGAR|ELIMINAR",
                 message = "La operación sobre la novedad debe ser AGREGAR o ELIMINAR")
        String operacion,

        Long identificador,

        /**
         * Cuarenta y no treinta: es el {@code code} del catálogo de mensajes, que
         * el contrato declara de 40. El {@code code} propio de la novedad —que sí
         * es de 30— no se usa.
         */
        @Size(max = 40, message = "El código de la novedad no puede superar los 40 caracteres")
        String codigoNovedad,

        /**
         * Los datos que completan el texto del mensaje, por índice de marcador.
         *
         * <p>El texto del catálogo puede llevar huecos —{@code {0}}…{@code {9}}—
         * que alguien tiene que rellenar; son los que el sistema de registro
         * guarda como «Valor 0»…«Valor 9». Qué índices pide cada mensaje sale de
         * su propio texto y <b>no son correlativos</b>: hay plantillas que usan
         * el 1 y el 2 sin usar el 0.
         *
         * <p>Se envían solo los que el mensaje pide: mandar uno de más se
         * rechaza, porque el sistema de registro lo guardaría sin que se vea en
         * ninguna parte.
         */
        java.util.Map<
                @jakarta.validation.constraints.Min(value = 0, message = "El dato de la novedad va numerado del 0 al 9")
                @jakarta.validation.constraints.Max(value = 9, message = "El dato de la novedad va numerado del 0 al 9")
                Integer,
                @Size(max = 300, message = "Cada dato de la novedad admite 300 caracteres")
                String> valores
) {}
