package co.sura.auditoria.api.dto;

/** Tiquete devuelto al enviar la cuenta. */
public record RespuestaTiquete(String codigoCuenta, String referenciaSeguimiento) {}
