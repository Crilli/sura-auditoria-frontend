package co.sura.auditoria.api.validacion;

import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validator;
import org.springframework.stereotype.Component;

/**
 * Validador de solicitudes que dispara las restricciones Jakarta Validation
 * de los DTOs antes de procesarlos en el caso de uso.
 */
@Component
public class ValidadorSolicitudes {

    private final Validator validador;

    public ValidadorSolicitudes(Validator validador) {
        this.validador = validador;
    }

    /**
     * Valida el objeto y lanza {@link ConstraintViolationException} si hay errores.
     *
     * @param objeto objeto a validar (debe tener anotaciones Jakarta Validation)
     */
    public void validar(Object objeto) {
        var violaciones = validador.validate(objeto);
        if (!violaciones.isEmpty())
            throw new ConstraintViolationException(violaciones);
    }
}
