package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Ficha de radicación y facturación, dentro de la respuesta de GET /api/v1/cuentas/{codigo}. */
public record RespuestaInformacionFacturacion(
        String prestadorFacturacionNit,
        String prestadorFacturacionNombre,
        String numeroFactura,
        String numeroRadicado,
        LocalDate fechaRadicacion,
        LocalDate fechaEmision,
        LocalDate fechaVencimiento,
        LocalDate fechaIngreso,
        LocalDate fechaEgreso,
        BigDecimal valorFactura,
        BigDecimal valorTotalFactura,
        BigDecimal totalCargado,
        // Sin totalConvenido desde el 2026-10-21: va en la raíz de RespuestaCuenta, que es su
        // única fuente. Aquí iba siempre en null y la pantalla pintaba «—» en todas las cuentas.
        BigDecimal totalValorGlosado,
        BigDecimal valorNotaCredito,
        String tipoServicio,
        String acuseRecibido,
        String marcaRadicadoAtep,
        String marcaMulticore,
        String marcaPendienteManual,
        String observacionesInternas,
        String observacionesExternas,
        String pagarAPrestadorNit,
        String pagarAPrestadorNombre
) {}
