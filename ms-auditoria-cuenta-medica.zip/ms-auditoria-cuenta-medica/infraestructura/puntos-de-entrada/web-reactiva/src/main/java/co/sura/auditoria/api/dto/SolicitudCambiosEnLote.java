package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

/**
 * Cuerpo de {@code POST /api/v1/cuentas/{codigo}/lineas/lote}.
 *
 * <p>El mismo cambio sobre varias líneas. <b>Solo lo que tiene sentido idéntico en todas</b>: el
 * desglose de glosa y las novedades. Los importes propios de cada línea no viajan aquí a
 * propósito —aplicar el mismo valor convenido a veinte líneas distintas no es una operación
 * masiva sino veinte errores— y el valor glosado tampoco, porque es la suma del desglose de cada
 * una y lo calcula el servicio.
 *
 * @param lineas        referencias de las líneas marcadas. <b>Obligatoria y no vacía</b>: aquí
 *                      una lista vacía no significa «todas», significa que falta el alcance
 * @param modoRecalculo sin valor por omisión, igual que al guardar una sola línea: la decisión
 *                      tiene impacto financiero y en un lote se multiplica
 */
public record SolicitudCambiosEnLote(

        @NotEmpty(message = "Hay que indicar las líneas sobre las que aplicar el cambio")
        @Size(max = 500, message = "No se pueden cambiar más de 500 líneas en una operación")
        List<@NotNull(message = "Hay referencias de línea vacías") Long> lineas,

        @NotNull(message = "Debe declarar el modo de recálculo")
        @Pattern(regexp = "EN_CASCADA|AISLADO",
                 message = "El modo de recálculo debe ser EN_CASCADA o AISLADO")
        String modoRecalculo,

        /** Altas y bajas del desglose de glosa, iguales para todas las líneas. */
        @jakarta.validation.Valid
        List<SolicitudCambioGlosa> glosas,

        /** Altas y bajas de novedad, iguales para todas las líneas. */
        @jakarta.validation.Valid
        List<SolicitudCambioNovedad> novedades) {}
