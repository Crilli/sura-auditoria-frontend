package co.sura.auditoria.api.dto;

import java.util.List;

/** Estado puntual del proceso. */
public record RespuestaEstadoProceso(String avance, boolean finalizado, List<String> errores) {}
