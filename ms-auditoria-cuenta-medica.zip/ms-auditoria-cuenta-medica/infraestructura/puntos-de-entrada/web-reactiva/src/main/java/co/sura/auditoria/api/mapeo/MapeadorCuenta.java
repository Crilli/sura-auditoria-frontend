package co.sura.auditoria.api.mapeo;

import co.sura.auditoria.api.dto.*;
import co.sura.auditoria.modelo.cuenta.*;

import java.util.Optional;

/** Mapea entre el modelo de dominio y los DTOs de respuesta de la API. */
public final class MapeadorCuenta {

    private MapeadorCuenta() {}

    public static RespuestaAcciones aRespuesta(CodigoCuenta codigo, AccionesDisponibles acciones) {
        return new RespuestaAcciones(
                codigo.valor(),
                acciones.acciones().stream().map(AccionCuenta::name).sorted().toList());
    }

    public static RespuestaCuenta aRespuesta(CuentaMedica cuenta) {
        return new RespuestaCuenta(
                cuenta.codigo().valor(),
                cuenta.estado().name(),
                cuenta.fechaInicio(),
                cuenta.fechaFin(),
                cuenta.totalAutorizado(),
                cuenta.totalCubierto(),
                cuenta.version().numero(),
                (int) cuenta.pendientesCabecera().stream().filter(p -> !p.resuelto()).count(),
                // El mismo mapeo que usa el detalle de línea: una novedad es lo
                // mismo en los dos sitios, así que se traduce igual.
                cuenta.novedades().stream().map(MapeadorLinea::aNovedadPublica).toList(),
                aRespuestaFacturacion(cuenta.informacionFacturacion()));
    }

    private static RespuestaInformacionFacturacion aRespuestaFacturacion(InformacionFacturacion f) {
        return new RespuestaInformacionFacturacion(
                f.prestadorFacturacionNit(),
                f.numeroFactura(),
                f.numeroRadicado(),
                f.fechaRadicacion(),
                f.fechaEmision(),
                f.fechaVencimiento(),
                f.fechaIngreso(),
                f.fechaEgreso(),
                f.valorFactura(),
                f.valorTotalFactura(),
                f.totalCargado(),
                f.totalConvenido(),
                f.totalValorGlosado(),
                f.valorNotaCredito(),
                f.tipoServicio(),
                f.acuseRecibido(),
                f.marcaRadicadoAtep(),
                f.marcaMulticore(),
                f.marcaPendienteManual(),
                f.observacionesInternas(),
                f.observacionesExternas(),
                f.pagarAPrestadorNit());
    }

    public static DecisionEnvio aDecisionEnvio(SolicitudEnviarCuenta solicitud) {
        return switch (solicitud.decision()) {
            case "ACEPTAR" -> solicitud.codigoNovedad() != null
                    ? DecisionEnvio.aceptarConNovedad(solicitud.codigoNovedad())
                    : DecisionEnvio.aceptar();
            case "DENEGAR" -> DecisionEnvio.denegar(solicitud.codigoNovedad());
            default -> throw new IllegalArgumentException("Decisión inválida: " + solicitud.decision());
        };
    }
}
