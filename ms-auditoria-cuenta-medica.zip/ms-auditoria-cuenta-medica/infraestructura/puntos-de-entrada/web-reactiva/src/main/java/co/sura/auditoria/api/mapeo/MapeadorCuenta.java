package co.sura.auditoria.api.mapeo;

import co.sura.auditoria.api.dto.*;
import co.sura.auditoria.modelo.cuenta.*;

import java.util.Optional;

/** Mapea entre el modelo de dominio y los DTOs de respuesta de la API. */
public final class MapeadorCuenta {

    private MapeadorCuenta() {}

    public static RespuestaAcciones aRespuesta(CodigoCuenta codigo, AccionesDisponibles acciones) {
        return new RespuestaAcciones(
                codigo.valor(),
                acciones.acciones().stream().map(AccionCuenta::name).sorted().toList());
    }

    public static RespuestaCuenta aRespuesta(CuentaMedica cuenta) {
        return new RespuestaCuenta(
                cuenta.codigo().valor(),
                cuenta.estado().name(),
                cuenta.estado().admiteCambiosDeDatos(),
                cuenta.fechaInicio(),
                cuenta.fechaFin(),
                cuenta.totalConvenido(),
                cuenta.totalAutorizado(),
                cuenta.version().numero(),
                (int) cuenta.pendientesCabecera().stream().filter(p -> !p.resuelto()).count(),
                // El mismo mapeo que usa el detalle de línea: una novedad es lo
                // mismo en los dos sitios, así que se traduce igual.
                cuenta.novedades().stream().map(MapeadorLinea::aNovedadPublica).toList(),
                aRespuestaFacturacion(cuenta.informacionFacturacion()),
                aRespuestasGlosa(cuenta));
    }

    private static RespuestaInformacionFacturacion aRespuestaFacturacion(InformacionFacturacion f) {
        return new RespuestaInformacionFacturacion(
                f.prestadorFacturacionNit(),
                f.prestadorFacturacionNombre(),
                f.numeroFactura(),
                f.numeroRadicado(),
                f.fechaRadicacion(),
                f.fechaEmision(),
                f.fechaVencimiento(),
                f.fechaIngreso(),
                f.fechaEgreso(),
                f.valorFactura(),
                f.valorTotalFactura(),
                f.totalCargado(),
                f.totalValorGlosado(),
                f.valorNotaCredito(),
                f.tipoServicio(),
                f.acuseRecibido(),
                f.marcaRadicadoAtep(),
                f.marcaMulticore(),
                f.marcaPendienteManual(),
                f.observacionesInternas(),
                f.observacionesExternas(),
                f.pagarAPrestadorNit(),
                f.pagarAPrestadorNombre());
    }

    public static DecisionEnvio aDecisionEnvio(SolicitudEnviarCuenta solicitud) {
        return switch (solicitud.decision()) {
            case "ACEPTAR" -> solicitud.codigoNovedad() != null
                    ? DecisionEnvio.aceptarConNovedad(solicitud.codigoNovedad())
                    : DecisionEnvio.aceptar();
            case "DENEGAR" -> DecisionEnvio.denegar(solicitud.codigoNovedad());
            default -> throw new IllegalArgumentException("Decisión inválida: " + solicitud.decision());
        };
    }

    /**
     * Las respuestas a glosa, con el vencimiento ya resuelto.
     *
     * <p>El «vencida» se calcula aquí y no en la pantalla para que no haya dos relojes: el
     * del servidor y el del navegador del auditor pueden no coincidir, y de esa diferencia
     * salen avisos que aparecen y desaparecen sin que nada haya cambiado.
     */
    private static java.util.List<RespuestaCuenta.RespuestaAGlosa> aRespuestasGlosa(
            CuentaMedica cuenta) {
        var hoy = java.time.LocalDate.now();
        return cuenta.respuestasGlosa().stream()
                .map(r -> new RespuestaCuenta.RespuestaAGlosa(
                        r.secuencia(), r.versionAbierta(), r.valor(),
                        r.fechaLlegada(), r.fechaVencimiento(), r.vencida(hoy)))
                .toList();
    }

    /**
     * La página del buscador, con las versiones ya repartidas bajo su cuenta.
     *
     * <p>Una cuenta sin versiones sale con la lista vacía: todavía no se ha transmitido. Es
     * distinto de «no se pudieron consultar», y por eso no se omite el campo.
     */
    public static RespuestaPaginaDesplazada<RespuestaResumenCuenta> aRespuestaBusqueda(
            PaginaDesplazada<ResumenCuenta> pagina,
            java.util.Map<String, java.util.List<VersionCuenta>> versiones) {

        return new RespuestaPaginaDesplazada<>(
                pagina.elementos().stream()
                        .map(c -> aResumenDeBusqueda(c, versiones.getOrDefault(
                                c.codigo().valor(), java.util.List.of())))
                        .toList(),
                pagina.desplazamiento(),
                pagina.tamanoPagina(),
                pagina.numeroDePagina(),
                pagina.total().orElse(null),
                pagina.totalPaginas().orElse(null),
                pagina.hayMas());
    }

    private static RespuestaResumenCuenta aResumenDeBusqueda(
            ResumenCuenta cuenta, java.util.List<VersionCuenta> versiones) {
        return new RespuestaResumenCuenta(
                cuenta.codigo().valor(),
                cuenta.numeroFactura(),
                cuenta.fechaRadicacion(),
                cuenta.prestadorNit(),
                cuenta.prestadorNombre(),
                cuenta.valorFactura(),
                // El estado legible decide solo si el diccionario conoce el literal.
                cuenta.estadoLegible(),
                versiones.stream()
                        // De la más reciente a la más antigua: la vigente va arriba, que es
                        // la que el auditor mira primero.
                        .sorted(java.util.Comparator.comparingInt(VersionCuenta::numero).reversed())
                        .map(v -> new RespuestaResumenCuenta.RespuestaVersionCuenta(
                                v.numero(), v.fechaEntrada(), v.valor(),
                                v.estado(), v.estadoDesde()))
                        .toList());
    }
}
