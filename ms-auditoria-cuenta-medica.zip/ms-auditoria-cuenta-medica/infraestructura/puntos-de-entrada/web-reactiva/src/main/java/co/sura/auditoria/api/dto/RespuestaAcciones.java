package co.sura.auditoria.api.dto;

import java.util.List;

/**
 * Respuesta del GET /api/v1/cuentas/{codigo}/acciones.
 *
 * <p>Va separada de {@link RespuestaCuenta} porque el sistema de registro solo publica
 * las capacidades en su representación completa del claim, mucho más lenta que la
 * cabecera. La interfaz pinta la cabecera de inmediato y habilita los botones cuando
 * llega esta respuesta.
 */
public record RespuestaAcciones(
        String codigo,
        /** Qué puede hacer el auditor ahora. Vacío si la cuenta no admite ninguna. */
        List<String> accionesDisponibles
) {}
