package co.sura.auditoria.api.manejador;

import org.springframework.web.reactive.function.server.ServerRequest;

/**
 * Cómo se leen la página y los números de la ruta, igual en todas las listas paginadas.
 *
 * <p>Vivía como métodos privados de {@link ManejadorLineas}; sale aquí cuando las líneas de una
 * versión (BUS-21) necesitan la misma regla, para que «página 2» signifique lo mismo en la grilla
 * viva y en la de la foto.
 */
final class ParametrosDePagina {

    private ParametrosDePagina() {}

    /**
     * Qué página se pide, admitiendo las dos formas de decirlo.
     *
     * <p>{@code desplazamiento} es la posición exacta y manda si viene; {@code pagina} es el
     * número de página contando desde cero, que es lo que tiene a mano una tabla, y se traduce
     * multiplicando por el tamaño. Si no viene ninguno, el principio.
     *
     * <p>El tamaño que se usa para traducir debería ser el ya resuelto, no el que llegó: así una
     * página 5 con un tamaño fuera de rango cae donde el listado la va a situar de verdad, y no
     * en una posición que el caso de uso luego no respetaría.
     *
     * <p>La multiplicación se hace en {@code long} y se satura al máximo de un {@code int}. En
     * {@code int} desbordaba sin aviso: {@code pagina=90000000} con tamaño 25 daba
     * −2.044.967.296, el caso de uso lo recortaba a 0 y el servicio respondía la <b>primera</b>
     * página con filas bajo el número de una que no existe. Saturada, la posición queda más allá
     * del final, el sistema de registro no devuelve filas y la respuesta es una página vacía con
     * su total, que es lo que de verdad hay en esa página.
     *
     * @param tamano el tamaño por el que multiplicar la página
     */
    static int desplazamiento(ServerRequest solicitud, int tamano) {
        var explicito = solicitud.queryParam("desplazamiento").map(ParametrosDePagina::entero);
        if (explicito.isPresent()) {
            return Math.max(0, explicito.get());
        }
        return solicitud.queryParam("pagina").map(ParametrosDePagina::entero)
                        .map(p -> sinDesbordar((long) Math.max(0, p) * tamano))
                        .orElse(0);
    }

    /** Una posición calculada en {@code long}, llevada al rango de un {@code int} sin darle la vuelta. */
    private static int sinDesbordar(long posicion) {
        return (int) Math.max(0, Math.min(posicion, Integer.MAX_VALUE));
    }

    /**
     * Un entero de la ruta o de la consulta.
     *
     * <p>Lo que no es número se rechaza con un mensaje que lo nombra —400 por
     * {@code IllegalArgumentException}— en vez del «For input string» de Java.
     */
    static int entero(String valor) {
        try {
            return Integer.parseInt(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "Se esperaba un número entero, no '" + valor + "'");
        }
    }
}
