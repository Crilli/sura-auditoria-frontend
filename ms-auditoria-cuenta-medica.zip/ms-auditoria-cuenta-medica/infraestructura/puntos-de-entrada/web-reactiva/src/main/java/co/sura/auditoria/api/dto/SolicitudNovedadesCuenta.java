package co.sura.auditoria.api.dto;

/**
 * Cuerpo del PATCH de novedades de la cabecera de la cuenta.
 *
 * <p>Mucho más corto que {@link SolicitudGuardarLinea} y no por casualidad: en
 * la cabecera <b>la novedad es lo único que se edita</b>. No hay importes, así
 * que tampoco hay modo de recálculo —la novedad no mueve nada que recalcular— ni
 * ningún otro campo con el que pudiera contradecirse.
 *
 * @param versionEsperada la de la <b>cuenta</b>, para el bloqueo optimista.
 *        Conviene saber que es la misma versión que mueve una edición de línea:
 *        se midió que agregar una novedad a una línea sube la versión de la
 *        cuenta. Dos auditores, uno en una línea y otro en la cabecera, chocan
 *        aquí
 * @param novedades las altas y bajas a aplicar
 */
public record SolicitudNovedadesCuenta(

        @jakarta.validation.constraints.NotNull(
                message = "Hay que decir sobre qué versión de la cuenta se está trabajando")
        Long versionEsperada,

        @jakarta.validation.constraints.NotEmpty(
                message = "No se envió ninguna novedad que agregar o quitar")
        @jakarta.validation.Valid
        java.util.List<SolicitudCambioNovedad> novedades
) {}
