package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.List;

/**
 * Cuerpo de {@code POST /api/v1/cuentas/{codigo}/pendientes/agregar}.
 *
 * @param motivo código del catálogo de pendientes. <b>No</b> el de desfinalización, que se
 *               publica en {@code /catalogos/motivos} y es otro catálogo
 * @param lineas a qué líneas ponerlo. Ausente o vacía = la cabecera de la cuenta, no «todas
 *               las líneas»: son los dos niveles disjuntos del sistema de registro
 */
public record SolicitudAgregarPendiente(

        @NotBlank(message = "Hay que indicar el motivo de pendiente")
        String motivo,

        @Size(max = 2000, message = "No se pueden acotar más de 2000 líneas en una operación")
        List<Long> lineas) {}
