package co.sura.auditoria.api.dto;

import java.util.List;

/** Respuesta del GET /api/v1/cuentas/{codigo}/lineas (una página). */
public record RespuestaPaginada<T>(
        List<T> elementos,
        String cursorSiguiente,
        Long totalRegistros,
        int tamanoPagina
) {}
