package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Detalle completo de línea: todo lo que el auditor debe ver sin salir de ella. */
public record RespuestaDetalleLinea(
        long referencia,
        String codigoCuenta,
        int numeroLinea,
        LocalDate fechaInicio,
        LocalDate fechaFin,

        /** Documento del afiliado, p. ej. {@code CC30359313}. */
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si no se pudo resolver contra el padrón. */
        String nombreAfiliado,

        String codigoProcedimiento,
        /** Texto de la prestación; {@code null} si el código no está en el catálogo. */
        String descripcionProcedimiento,
        /** Catálogo del código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        RespuestaPrestacion prestacion,

        /** Autorización con la que se prestó el servicio. */
        String codigoAutorizacion,
        String prestadorAtencionCodigo,
        String prestadorAtencionNombre,

        BigDecimal valorCargado,
        BigDecimal unidadesCargadas,
        BigDecimal valorAutorizado,
        BigDecimal unidadesAutorizadas,
        BigDecimal valorCubierto,
        BigDecimal unidadesCubiertas,
        BigDecimal valorGlosado,
        String observacionesGlosa,

        RespuestaDatosConvenio convenio,
        RespuestaOtrosDatosLinea otrosDatos,
        List<RespuestaDiagnosticoLinea> diagnosticos,
        List<RespuestaDetalleGlosa> glosas,

        boolean conservarBeneficios,
        boolean conservarTarifacion,
        boolean beneficiosManuales,
        boolean tarifacionManual,
        boolean bloqueada,
        boolean reemplazada,
        boolean editable,
        List<RespuestaNovedades> novedades,
        List<RespuestaMotivoPendiente> pendientes,
        long version
) {
    /** Qué se prestó. */
    public record RespuestaPrestacion(
            String codigo,
            String descripcion,
            String catalogo,
            String codigoNoDefinido,
            String codigoNoDefinidoDef,
            /** Texto literal del archivo RIPS; la única descripción si el código no está en catálogo. */
            String descripcionRips,
            String claseServicio,
            String especialidad) {}

    /** Tarifas y contrato que aplican a la línea. */
    public record RespuestaDatosConvenio(
            String codigoTarifarioIss2001,
            String codigoTarifarioIss2000,
            String codigoTarifarioSoat,
            String numeroContrato,
            String homologoCups,
            String multiplesCupsHomologos,
            String codigoUnicoContratoSiifa,
            /** Tarifa pactada con el prestador, antes de los ajustes de regla. */
            BigDecimal valorConvenido,
            /** Cláusula aplicada: prestador, propuesta y manual tarifario. */
            String tarifaAplicada) {}

    /** Datos de la atención y del siniestro. */
    public record RespuestaOtrosDatosLinea(
            String tipoSala,
            String viaDeAcceso,
            String unidadEstrategicaNegocio,
            String codigoSiniestro) {}

    /** Diagnóstico CIE-10 de la línea. */
    public record RespuestaDiagnosticoLinea(
            int secuencia,
            String tipo,
            String descripcionTipo,
            String codigo,
            String descripcion) {}

    /** Una glosa concreta de la línea. */
    public record RespuestaDetalleGlosa(
            long identificador,
            BigDecimal valor,
            String codigoNotaCredito,
            String generico,
            String especifico,
            String texto) {}
}
