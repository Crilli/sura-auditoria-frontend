package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/**
 * Un alta o una baja en el desglose de glosa de la línea.
 *
 * <p>Viaja dentro del cuerpo del PATCH de la línea y no en una ruta propia: una
 * glosa no existe fuera de su línea, y mandarlas juntas permite que agregar una
 * glosa y corregir el valor convenido sean una sola operación con una sola
 * versión y un solo recálculo.
 *
 * @param operacion     {@code AGREGAR} o {@code ELIMINAR}
 * @param identificador el de la glosa a eliminar; no se envía al agregar, porque
 *                      lo asigna el sistema de registro
 * @param codigoGlosa   el causal, p. ej. {@code 208-1}. No se valida contra un
 *                      catálogo: el sistema de registro no publica ninguno y en
 *                      los datos conviven dos convenciones distintas
 */
public record SolicitudCambioGlosa(

        @NotNull(message = "Hay que decir si la glosa se agrega o se elimina")
        @Pattern(regexp = "AGREGAR|ELIMINAR",
                 message = "La operación sobre la glosa debe ser AGREGAR o ELIMINAR")
        String operacion,

        Long identificador,

        @Size(max = 30, message = "El código de glosa no puede superar los 30 caracteres")
        String codigoGlosa,

        @Size(max = 100, message = "La clasificación genérica no puede superar los 100 caracteres")
        String generico,

        @Size(max = 1000, message = "La clasificación específica no puede superar los 1000 caracteres")
        String especifico,

        @PositiveOrZero(message = "El valor de la glosa no puede ser negativo")
        BigDecimal valor,

        @Size(max = 1000, message = "El texto de la glosa no puede superar los 1000 caracteres")
        String texto
) {}
