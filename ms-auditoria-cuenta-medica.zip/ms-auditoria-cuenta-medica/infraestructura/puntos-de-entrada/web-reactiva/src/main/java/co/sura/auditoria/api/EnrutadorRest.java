package co.sura.auditoria.api;

import co.sura.auditoria.api.manejador.ManejadorCatalogos;
import co.sura.auditoria.api.manejador.ManejadorCuentas;
import co.sura.auditoria.api.manejador.ManejadorLineas;
import co.sura.auditoria.api.manejador.ManejadorPendientes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.TEXT_EVENT_STREAM;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RouterFunctions.nest;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.RequestPredicates.*;

/**
 * Enrutador funcional REST.
 * Define las rutas del API sin usar anotaciones de Spring MVC.
 *
 * <p>Cumple el Manifiesto Reactivo: RouterFunction + ServerRequest/ServerResponse,
 * sin bloqueos en ningún punto de la cadena.
 */
@Configuration
public class EnrutadorRest {

    private static final String BASE = "/api/v1/cuentas";

    /**
     * Los catálogos no cuelgan de la cuenta: no pertenecen a ninguna.
     *
     * <p>Este prefijo tiene que estar permitido en {@code ConfiguracionSeguridad},
     * que enumera los que deja pasar y cierra con
     * {@code anyExchange().authenticated()}.
     */
    private static final String BASE_CATALOGOS = "/api/v1/catalogos";

    @Bean
    public RouterFunction<ServerResponse> rutasCuentas(ManejadorCuentas manejador) {
        return nest(path(BASE),
            route()
                // La colección. Va PRIMERO: "" no compite con "/{codigo}", pero leerlo aquí
                // recuerda que esta es la única ruta de cuentas que no trabaja sobre una.
                .GET("", accept(APPLICATION_JSON), manejador::buscarCuentas)
                .GET("/{codigo}", accept(APPLICATION_JSON), manejador::consultarCuenta)
                .GET("/{codigo}/acciones", accept(APPLICATION_JSON), manejador::consultarAccionesDisponibles)
                .PATCH("/{codigo}/novedades", accept(APPLICATION_JSON), manejador::guardarNovedades)
                .POST("/{codigo}/enviar", accept(APPLICATION_JSON), manejador::enviarCuenta)
                // Después de "/{codigo}/enviar" y "/{codigo}/novedades": ninguna
                // ambigüedad, porque "acciones" es literal y lleva un segmento más.
                .POST("/{codigo}/acciones/{accion}", accept(APPLICATION_JSON),
                      manejador::ejecutarAccion)
                // La historia de la cuenta. Va junto a «proceso» para que se lean seguidos:
                // son dos preguntas parecidas y distintas, y tenerlas pegadas lo recuerda.
                .GET("/{codigo}/historia", accept(APPLICATION_JSON), manejador::consultarHistoria)
                // La foto de una versión transmitida. Dos segmentos tras el código: no compite
                // con "/{codigo}/acciones/{accion}" porque aquél es POST.
                .GET("/{codigo}/versiones", accept(APPLICATION_JSON), manejador::consultarVersiones)
                .GET("/{codigo}/versiones/{numero}", accept(APPLICATION_JSON),
                     manejador::consultarVersion)
                // Las líneas de esa versión (BUS-21). Van aquí y no en rutasLineas: aquéllas
                // cuelgan de "/{codigo}/lineas" y son de la cuenta viva; éstas son de la foto y
                // no tienen nada que editar. Tres y cuatro segmentos tras el código: no compiten
                // con ninguna otra ruta GET.
                .GET("/{codigo}/versiones/{numero}/lineas", accept(APPLICATION_JSON),
                     manejador::consultarLineasDeVersion)
                .GET("/{codigo}/versiones/{numero}/lineas/{numeroLinea}", accept(APPLICATION_JSON),
                     manejador::consultarLineaDeVersion)
                .GET("/{codigo}/proceso", accept(APPLICATION_JSON), manejador::consultarProceso)
                .GET("/{codigo}/proceso/flujo", accept(TEXT_EVENT_STREAM), manejador::transmitirProceso)
                .build());
    }

    @Bean
    public RouterFunction<ServerResponse> rutasLineas(ManejadorLineas manejador) {
        return nest(path(BASE + "/{codigo}/lineas"),
            route()
                .GET("", accept(APPLICATION_JSON), manejador::listarResumen)
                // Antes que "/{referencia}": si no, "filtros" se tomaría por una
                // referencia de línea y fallaría al convertirla a número.
                .GET("/filtros", accept(APPLICATION_JSON), manejador::resumirFiltros)
                // Dos segmentos, así que no compite con "/{referencia}"; se declara
                // junto a él para que se lean seguidos.
                .GET("/{referencia}/siguiente", accept(APPLICATION_JSON),
                     manejador::consultarSiguiente)
                .GET("/{referencia}", accept(APPLICATION_JSON), manejador::consultarDetalle)
                .PATCH("/{referencia}", accept(APPLICATION_JSON), manejador::guardarLinea)
                // Antes que "/{referencia}" no hace falta: es POST y aquél es PATCH, así que
                // no compiten. Se declara al final porque es la única que no es de una línea.
                .POST("/lote", accept(APPLICATION_JSON), manejador::aplicarEnLote)
                .build());
    }

    @Bean
    public RouterFunction<ServerResponse> rutasCatalogos(ManejadorCatalogos manejador) {
        return nest(path(BASE_CATALOGOS),
            route()
                .GET("/novedades", accept(APPLICATION_JSON), manejador::consultarNovedades)
                .GET("/motivos", accept(APPLICATION_JSON), manejador::consultarMotivos)
                // Tercer catálogo, y el nombre lo dice para que no se confunda con el de
                // arriba: "/motivos" es el de DESFINALIZACIÓN y este el de PENDIENTES.
                .GET("/motivos-pendiente", accept(APPLICATION_JSON),
                     manejador::consultarMotivosDePendiente)
                .build());
    }

    @Bean
    public RouterFunction<ServerResponse> rutasPendientes(ManejadorPendientes manejador) {
        return nest(path(BASE + "/{codigo}/pendientes"),
            route()
                .GET("", accept(APPLICATION_JSON), manejador::listarSinResolver)
                // Antes que "/{motivo}/resolver" no haría falta —son métodos
                // distintos— pero se deja junto al listado porque es su agregado.
                .GET("/motivos", accept(APPLICATION_JSON), manejador::resumirMotivos)
                // Un segmento frente a los dos de "/{motivo}/resolver": no hay
                // ambigüedad posible entre las dos rutas.
                .POST("/resolver", accept(APPLICATION_JSON), manejador::resolverEnMasa)
                // El seguimiento de una resolución ya lanzada: sin estado, por sus referencias.
                .GET("/resoluciones", accept(APPLICATION_JSON), manejador::seguirResolucion)
                // Un segmento, como "/resolver": tampoco compite con "/{motivo}/resolver".
                .POST("/agregar", accept(APPLICATION_JSON), manejador::agregarPendiente)
                .POST("/{motivo}/resolver", accept(APPLICATION_JSON), manejador::resolver)
                .build());
    }
}
