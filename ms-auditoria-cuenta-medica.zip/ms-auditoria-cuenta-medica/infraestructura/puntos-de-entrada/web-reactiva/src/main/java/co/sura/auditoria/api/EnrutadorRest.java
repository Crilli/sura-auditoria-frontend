package co.sura.auditoria.api;

import co.sura.auditoria.api.manejador.ManejadorCuentas;
import co.sura.auditoria.api.manejador.ManejadorLineas;
import co.sura.auditoria.api.manejador.ManejadorPendientes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.TEXT_EVENT_STREAM;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RouterFunctions.nest;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.RequestPredicates.*;

/**
 * Enrutador funcional REST.
 * Define las rutas del API sin usar anotaciones de Spring MVC.
 *
 * <p>Cumple el Manifiesto Reactivo: RouterFunction + ServerRequest/ServerResponse,
 * sin bloqueos en ningún punto de la cadena.
 */
@Configuration
public class EnrutadorRest {

    private static final String BASE = "/api/v1/cuentas";

    @Bean
    public RouterFunction<ServerResponse> rutasCuentas(ManejadorCuentas manejador) {
        return nest(path(BASE),
            route()
                .GET("/{codigo}", accept(APPLICATION_JSON), manejador::consultarCuenta)
                .GET("/{codigo}/acciones", accept(APPLICATION_JSON), manejador::consultarAccionesDisponibles)
                .POST("/{codigo}/enviar", accept(APPLICATION_JSON), manejador::enviarCuenta)
                .GET("/{codigo}/proceso", accept(APPLICATION_JSON), manejador::consultarProceso)
                .GET("/{codigo}/proceso/flujo", accept(TEXT_EVENT_STREAM), manejador::transmitirProceso)
                .build());
    }

    @Bean
    public RouterFunction<ServerResponse> rutasLineas(ManejadorLineas manejador) {
        return nest(path(BASE + "/{codigo}/lineas"),
            route()
                .GET("", accept(APPLICATION_JSON), manejador::listarResumen)
                .GET("/{referencia}", accept(APPLICATION_JSON), manejador::consultarDetalle)
                .PATCH("/{referencia}", accept(APPLICATION_JSON), manejador::guardarLinea)
                .build());
    }

    @Bean
    public RouterFunction<ServerResponse> rutasPendientes(ManejadorPendientes manejador) {
        return nest(path(BASE + "/{codigo}/pendientes"),
            route()
                .GET("", accept(APPLICATION_JSON), manejador::listarSinResolver)
                // Antes que "/{motivo}/resolver" no haría falta —son métodos
                // distintos— pero se deja junto al listado porque es su agregado.
                .GET("/motivos", accept(APPLICATION_JSON), manejador::resumirMotivos)
                // Un segmento frente a los dos de "/{motivo}/resolver": no hay
                // ambigüedad posible entre las dos rutas.
                .POST("/resolver", accept(APPLICATION_JSON), manejador::resolverEnMasa)
                .POST("/{motivo}/resolver", accept(APPLICATION_JSON), manejador::resolver)
                .build());
    }
}
