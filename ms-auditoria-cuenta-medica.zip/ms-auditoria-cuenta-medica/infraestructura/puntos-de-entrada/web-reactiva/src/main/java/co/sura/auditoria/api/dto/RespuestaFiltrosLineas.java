package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Con qué se puede acotar el listado de líneas de <b>esta</b> cuenta.
 *
 * <p>Va en su propia llamada, igual que el agregado de motivos pendientes, por
 * la misma razón: el listado se pagina, así que las opciones no se pueden sacar
 * de la página a la vista sin ofrecer un afiliado y esconder los demás.
 *
 * @param afiliados       los de la cuenta, con cuántas líneas tiene cada uno, de
 *                        mayor a menor
 * @param catalogos       los catálogos de prestación presentes, con los propios
 *                        de prestador ya agrupados bajo {@code PROPIO}
 * @param primeraAtencion extremos de la fecha de atención, para acotar el
 *                        calendario a lo que la cuenta tiene
 * @param glosaMaxima     mayor valor glosado; {@code null} si no hay glosas
 * @param lineasConGlosa  cuántas líneas tienen glosa. Permite ofrecer «solo
 *                        glosadas» sin que el auditor invente un rango, y
 *                        desactivar el filtro cuando no hay ninguna
 * @param totalLineas     sobre cuántas líneas se calculó todo esto
 */
public record RespuestaFiltrosLineas(List<Afiliado> afiliados,
                                     List<Catalogo> catalogos,
                                     LocalDate primeraAtencion,
                                     LocalDate ultimaAtencion,
                                     BigDecimal glosaMaxima,
                                     int lineasConGlosa,
                                     int totalLineas) {

    public record Afiliado(String cedula, String nombre, int lineas) {}

    /**
     * @param codigo   el valor del dominio ({@code CUPS}, {@code PROPIO}…), que es
     *                 el que se manda de vuelta al filtrar
     * @param etiqueta cómo se le enseña al auditor
     */
    public record Catalogo(String codigo, String etiqueta, int lineas) {}
}
