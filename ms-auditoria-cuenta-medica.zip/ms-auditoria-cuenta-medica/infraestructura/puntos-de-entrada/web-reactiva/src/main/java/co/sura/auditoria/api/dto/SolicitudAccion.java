package co.sura.auditoria.api.dto;

/**
 * Cuerpo para ejecutar una acción sobre la cuenta.
 *
 * <p>Todo opcional porque seis de las nueve acciones no llevan nada: son
 * transiciones de estado a secas. Lo que cada una admite lo comprueba el
 * dominio, que es quien sabe que anular exige motivos y que solo el desbloqueo
 * admite una lista de líneas.
 *
 * @param motivos    códigos del catálogo de desfinalización. Obligatorios para
 *                   anular y para revertir la finalización
 * @param referencia referencia de origen, si alguno de los motivos la exige
 * @param lineas     qué líneas desbloquear; vacío o ausente = todas
 * @param codigoMensajeAnulacion mensaje con el que marcar la anulación
 */
public record SolicitudAccion(
        java.util.List<@jakarta.validation.constraints.Size(
                max = 30, message = "Un código de motivo no pasa de 30 caracteres") String> motivos,

        @jakarta.validation.constraints.Size(
                max = 30, message = "La referencia de origen no pasa de 30 caracteres")
        String referencia,

        java.util.List<Long> lineas,

        @jakarta.validation.constraints.Size(
                max = 40, message = "El código de mensaje no pasa de 40 caracteres")
        String codigoMensajeAnulacion
) {}
