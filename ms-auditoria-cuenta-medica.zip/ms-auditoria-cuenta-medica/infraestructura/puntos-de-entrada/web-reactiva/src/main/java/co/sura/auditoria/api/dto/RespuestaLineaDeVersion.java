package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Una fila de la grilla de una versión: la línea tal como quedó en ella (BUS-21).
 *
 * <p><b>No es {@link RespuestaResumenLinea}</b>, y no por descuido: no lleva {@code referencia},
 * ni {@code version}, ni {@code editable}, ni pendientes. El identificador de la línea de versión
 * no es el de la línea viva, y si viajara aquí una grilla reutilizada podría mandarlo a guardar
 * contra la cuenta actual. Con esta forma, la foto no tiene nada con qué editarse.
 *
 * <p>Los importes que el sistema de registro no publica llegan en {@code null}, no en cero: la
 * pantalla pinta una raya (BUS-21.3).
 *
 * @param numeroLinea el número que ve el auditor; no es correlativo
 * @param estado      {@code APROBADA} o {@code NEGADA}; otra palabra si el histórico trae una
 *                    que no se conoce; {@code null} si no trae ninguna
 * @param nombreAfiliado solo el primer apellido: es lo único que guarda el histórico
 * @param glosas      el desglose de lo glosado; lista vacía si no hay
 */
public record RespuestaLineaDeVersion(
        int numeroLinea,
        String estado,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        String codigoProcedimiento,
        String descripcionProcedimiento,
        String catalogoProcedimiento,
        String codigoAfiliado,
        String nombreAfiliado,
        String codigoAutorizacion,
        String prestadorCodigo,
        String prestadorNombre,
        BigDecimal valorCargado,
        BigDecimal unidadesCargadas,
        // Los mismos nombres que la línea viva (BUS-21): convenido = allowed*, autorizado =
        // covered*. Hasta el 2026-10-21 eran «autorizado» y «cubierto»; ver RespuestaDetalleLinea.
        BigDecimal valorConvenido,
        BigDecimal unidadesConvenidas,
        BigDecimal valorAutorizado,
        BigDecimal unidadesAutorizadas,
        BigDecimal valorGlosado,
        BigDecimal valorIva,
        BigDecimal porcentajeIva,
        List<GlosaDeVersion> glosas
) {

    /**
     * Una glosa del desglose.
     *
     * @param concepto           la clasificación de primer nivel («Tarifas»)
     * @param conceptoEspecifico la de segundo nivel («Procedimiento o actividad»)
     * @param tipo               cómo se puso, en palabras del sistema de registro
     */
    public record GlosaDeVersion(
            Integer secuencia,
            String codigo,
            BigDecimal valor,
            String codigoNotaCredito,
            BigDecimal valorNotaCredito,
            String concepto,
            String conceptoEspecifico,
            String texto,
            String tipo
    ) {}
}
