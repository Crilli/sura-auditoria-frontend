package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

/** Cuerpo del POST /api/v1/cuentas/{codigo}/enviar. */
public record SolicitudEnviarCuenta(
        @NotNull
        @Pattern(regexp = "ACEPTAR|DENEGAR", message = "La decisión debe ser ACEPTAR o DENEGAR")
        String decision,
        String codigoNovedad
) {}
