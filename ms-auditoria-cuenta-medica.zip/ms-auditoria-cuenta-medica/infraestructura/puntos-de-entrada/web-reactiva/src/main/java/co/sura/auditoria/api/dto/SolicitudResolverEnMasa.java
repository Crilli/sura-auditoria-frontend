package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * Cuerpo del {@code POST /api/v1/cuentas/{codigo}/pendientes/resolver}.
 *
 * <p>Los motivos van por <b>código</b> y no por identificador de fila porque es
 * el motivo lo que se resuelve: el sistema de registro no sabe resolver una fila
 * suelta, y una lista de identificadores daría a entender que sí.
 *
 * @param motivos       códigos de motivo a resolver. El tope es el mismo que
 *                      aplica el dominio; aquí se acota también para que una
 *                      lista desbocada se rechace antes de llegar al caso de uso.
 * @param nivel         {@code CUENTA}, {@code LINEAS} o {@code DONDE_APLIQUE}.
 *                      Omitirlo vale {@code DONDE_APLIQUE}, que es lo que se
 *                      quiere casi siempre: que el motivo deje de estar puesto,
 *                      esté donde esté.
 * @param justificacion obligatoria, igual que en la resolución individual: queda
 *                      como nota en la cuenta y en la traza de auditoría.
 */
public record SolicitudResolverEnMasa(

        @NotEmpty(message = "Hay que indicar al menos un motivo")
        @Size(max = 50, message = "No se pueden resolver más de 50 motivos en una sola operación")
        List<@NotBlank(message = "Hay códigos de motivo vacíos") String> motivos,

        @NotBlank(message = "La justificación es obligatoria")
        @Size(max = 2000, message = "La justificación no puede superar los 2000 caracteres")
        String justificacion,

        @Pattern(regexp = "CUENTA|LINEAS|DONDE_APLIQUE",
                 message = "El nivel debe ser CUENTA, LINEAS o DONDE_APLIQUE")
        String nivel
) {}
