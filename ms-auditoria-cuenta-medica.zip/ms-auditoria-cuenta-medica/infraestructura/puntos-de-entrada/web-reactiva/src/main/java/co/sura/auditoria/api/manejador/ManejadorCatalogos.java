package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.RespuestaMensajeCatalogo;
import co.sura.auditoria.api.dto.RespuestaNovedad;
import co.sura.auditoria.api.dto.RespuestaMotivo;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.casodeuso.ConsultarCatalogoNovedadesCasoDeUso;
import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.cuenta.Novedad;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Manejador de los catálogos.
 *
 * <p>Va aparte de {@link ManejadorLineas} porque lo que sirve <b>no pertenece a
 * ninguna cuenta</b>: es global y lo comparten todas.
 *
 * <p><b>Ojo si se añaden rutas aquí:</b> {@code ConfiguracionSeguridad} enumera
 * los prefijos permitidos y cierra con {@code anyExchange().authenticated()}.
 * Una ruta nueva fuera de {@code /api/v1/catalogos/**} responde 401, y en el
 * navegador eso no se distingue de «el catálogo está vacío».
 */
@Component
public class ManejadorCatalogos {

    private final ConsultarCatalogoNovedadesCasoDeUso novedades;

    private final co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente catalogoMotivosPendiente;
    private final co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso acciones;

    public ManejadorCatalogos(ConsultarCatalogoNovedadesCasoDeUso novedades,
                              co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso acciones,
                              co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente
                                      catalogoMotivosPendiente) {
        this.novedades = novedades;
        this.acciones = acciones;
        this.catalogoMotivosPendiente = catalogoMotivosPendiente;
    }

    /**
     * GET /api/v1/catalogos/novedades?busqueda=
     *
     * <p>Devuelve el catálogo completo de lo que un auditor puede poner como
     * novedad. {@code busqueda} es opcional y acota por código, texto o
     * clasificación, sin distinguir tildes ni mayúsculas.
     *
     * <p>Sin paginar a propósito: son 631 mensajes y la interfaz los quiere de
     * una vez para poder buscar sin ir y volver por cada tecla. Ver
     * {@link ConsultarCatalogoNovedadesCasoDeUso}.
     */
    public Mono<ServerResponse> consultarNovedades(ServerRequest peticion) {
        var busqueda = peticion.queryParam("busqueda").orElse(null);

        return novedades.ejecutar(busqueda)
                .map(ManejadorCatalogos::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/catalogos/motivos[?ambito=CUENTA_MEDICA|AUTORIZACION]
     *
     * <p>Los motivos de desfinalización y anulación. {@code ambito} acota a los
     * que aplican a ese tipo de proceso —hay seis solo de cuenta médica y cuatro
     * solo de autorización— y se filtra aquí porque el sistema de registro
     * publica ese campo como código dinámico y no deja filtrarlo en la consulta.
     */
    /**
     * GET /api/v1/catalogos/motivos-pendiente
     *
     * <p>El catálogo de motivos <b>de pendiente</b>, para el selector de la grilla. Va aparte
     * de {@code /motivos}, que es el de desfinalización: el documento del MVP llama «motivos»
     * a los dos y confundirlos ofrecería al auditor una lista que el sistema de registro
     * rechazaría entera.
     *
     * <p>Son 237 y el adaptador los recorre por clave: el tope de página de 200 no avisa de
     * que hay más.
     */
    public Mono<ServerResponse> consultarMotivosDePendiente(ServerRequest peticion) {
        return catalogoMotivosPendiente.listar()
                .map(motivos -> motivos.stream()
                        .map(m -> new RespuestaMotivoDePendiente(
                                m.codigo(), m.descripcion(), m.soloAdjudicacion()))
                        .toList())
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * Un motivo del catálogo de pendientes.
     *
     * <p>{@code soloAdjudicacion} y no «bloqueante»: bloquear depende del par motivo-estado y
     * el catálogo no conoce ninguna cuenta. La pantalla que quiera avisar tiene el estado.
     */
    public record RespuestaMotivoDePendiente(String codigo, String descripcion,
                                             boolean soloAdjudicacion) {}

    public Mono<ServerResponse> consultarMotivos(ServerRequest peticion) {
        // Sin el parámetro no se filtra. `AMBAS` no sirve de valor por omisión:
        // es un ámbito más —el de los motivos que valen para cuenta y para
        // autorización— y usarlo aquí escondería los diez que son específicos.
        var ambito = peticion.queryParam("ambito")
                .map(a -> {
                    try {
                        return MotivoDesfinalizacion.Ambito.valueOf(a.toUpperCase());
                    } catch (IllegalArgumentException e) {
                        return null;
                    }
                })
                .orElse(null);

        return acciones.motivosPara(ambito)
                .map(ms -> ms.stream().map(m -> new RespuestaMotivo(
                        m.codigo(), m.descripcion(), m.bloqueaLineas(),
                        m.exigeReferencia(), m.aplicaA().name(), m.permiso())).toList())
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    private static List<RespuestaMensajeCatalogo> aRespuesta(List<MensajeCatalogo> mensajes) {
        return mensajes.stream().map(m -> new RespuestaMensajeCatalogo(
                        m.codigo(),
                        m.texto(),
                        m.severidad() == null ? null : m.severidad().name(),
                        m.frenaLaCuenta(),
                        m.esDelSistema(),
                        m.datosQuePide(),
                        aClasificacion(m.generico()),
                        aClasificacion(m.especifico())))
                .toList();
    }

    private static RespuestaNovedad.Clasificacion aClasificacion(Novedad.Clasificacion c) {
        return c == null ? null
                : new RespuestaNovedad.Clasificacion(c.codigo(), c.descripcion());
    }
}
