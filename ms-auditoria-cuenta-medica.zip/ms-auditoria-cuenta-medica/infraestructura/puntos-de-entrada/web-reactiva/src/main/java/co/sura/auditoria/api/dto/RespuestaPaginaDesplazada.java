package co.sura.auditoria.api.dto;

import java.util.List;

/**
 * Respuesta del GET /api/v1/cuentas/{codigo}/lineas: una página localizada por
 * desplazamiento.
 *
 * <p>Va aparte de {@link RespuestaPaginada} —la de los pendientes, que pagina
 * por cursor— porque lo que el cliente necesita saber es distinto: no hay
 * cursor que devolver, y sí hay una posición y, cuando se puede, un número de
 * páginas.
 *
 * @param elementos       los de esta página
 * @param desplazamiento  cuántos elementos se saltaron para llegar aquí
 * @param tamanoPagina    cuántos se pidieron
 * @param pagina          en qué página estamos, contando desde cero
 * @param totalRegistros  cuántos hay en total, o {@code null} cuando no es de
 *                        fiar. Es {@code null} —a propósito— si el filtro
 *                        incluye algo que el sistema de registro no sabe
 *                        aplicar: su cuenta sería de las filas de antes de
 *                        descartar, y el paginador prometería páginas vacías
 * @param totalPaginas    cuántas páginas hay, o {@code null} si no hay total
 * @param hayMas          si queda algo después de esta página. Siempre fiable,
 *                        también cuando el total no lo es: es con esto con lo
 *                        que se habilita «siguiente»
 */
public record RespuestaPaginaDesplazada<T>(
        List<T> elementos,
        int desplazamiento,
        int tamanoPagina,
        int pagina,
        Long totalRegistros,
        Long totalPaginas,
        boolean hayMas
) {}
