package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.RespuestaMotivoPendiente;
import co.sura.auditoria.api.dto.RespuestaPaginada;
import co.sura.auditoria.api.dto.RespuestaResolucionMasiva;
import co.sura.auditoria.api.dto.RespuestaResumenMotivo;
import co.sura.auditoria.api.dto.SolicitudAgregarPendiente;
import co.sura.auditoria.api.dto.SolicitudResolverEnMasa;
import co.sura.auditoria.api.dto.SolicitudResolverPendiente;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.AgregarMotivoPendienteCasoDeUso;
import co.sura.auditoria.casodeuso.ListarPendientesCasoDeUso;
import co.sura.auditoria.casodeuso.ResolverPendientesCasoDeUso;
import co.sura.auditoria.casodeuso.ResolverPendientesEnMasaCasoDeUso;
import co.sura.auditoria.casodeuso.ResumirMotivosPendientesCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelResolucion;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.SeleccionLineas;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones sobre pendientes de la cuenta médica.
 */
@Component
public class ManejadorPendientes {

    private final ListarPendientesCasoDeUso          listar;
    private final ResumirMotivosPendientesCasoDeUso  resumirMotivos;
    private final ResolverPendientesCasoDeUso        resolver;
    private final ResolverPendientesEnMasaCasoDeUso  resolverEnMasa;
    private final AgregarMotivoPendienteCasoDeUso    agregar;
    private final ValidadorSolicitudes               validador;

    public ManejadorPendientes(ListarPendientesCasoDeUso listar,
                               ResumirMotivosPendientesCasoDeUso resumirMotivos,
                               ResolverPendientesCasoDeUso resolver,
                               ResolverPendientesEnMasaCasoDeUso resolverEnMasa,
                               AgregarMotivoPendienteCasoDeUso agregar,
                               ValidadorSolicitudes validador) {
        this.listar         = listar;
        this.resumirMotivos = resumirMotivos;
        this.resolver       = resolver;
        this.resolverEnMasa = resolverEnMasa;
        this.agregar        = agregar;
        this.validador      = validador;
    }

    /**
     * GET /api/v1/cuentas/{codigo}/pendientes?cursor=&amp;tamano=25&amp;motivo=
     *
     * <p>Mismos parámetros y misma forma de respuesta que el listado de líneas:
     * {@code cursor} ausente es la primera página y {@code totalRegistros} solo
     * viaja en ella. {@code motivo} es el código del pendiente por el que filtrar
     * y {@code bloqueo} vale {@code TODOS}, {@code BLOQUEANTES} o
     * {@code NO_BLOQUEANTES}; un valor que no sea ninguno de esos se rechaza con
     * 400 en vez de interpretarse como «todos», que escondería un error del
     * cliente detrás de una lista plausible.
     */
    public Mono<ServerResponse> listarSinResolver(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var cursor = solicitud.queryParam("cursor")
                              .map(Long::parseLong).map(Cursor::new)
                              .orElse(Cursor.PRIMERA_PAGINA);
        var tamano = solicitud.queryParam("tamano").map(Integer::parseInt).orElse(25);
        var motivo = solicitud.queryParam("motivo").orElse(null);
        var bloqueo = solicitud.queryParam("bloqueo")
                               .filter(v -> !v.isBlank())
                               .map(ManejadorPendientes::aFiltroBloqueo)
                               .orElse(FiltroBloqueo.TODOS);

        // Mirar atrás es explícito: sin el parámetro se ve lo de siempre, los sin resolver.
        var incluirResueltos = solicitud.queryParam("incluirResueltos")
                                        .map("true"::equalsIgnoreCase).orElse(false);

        return listar.ejecutar(codigo, cursor, tamano, motivo, bloqueo, incluirResueltos)
                .map(ManejadorPendientes::aRespuestaPaginada)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/cuentas/{codigo}/pendientes/motivos
     *
     * <p>Los motivos distintos de la cuenta, para el filtro. Va aparte del listado
     * porque tiene otro ciclo de vida: se calcula recorriendo la cuenta entera y no
     * cambia al pasar de página, así que el cliente lo pide una vez en paralelo con
     * la primera página en lugar de arrastrarlo en cada salto.
     */
    public Mono<ServerResponse> resumirMotivos(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));

        return resumirMotivos.ejecutar(codigo)
                .map(m -> new RespuestaResumenMotivo(m.codigo(), m.descripcion(),
                                                     m.sinResolver(), m.lineasAfectadas(),
                                                     m.enCabecera(), m.soloAdjudicacion(),
                                                     m.bloqueante()))
                .collectList()
                .flatMap(lista -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(lista));
    }

    private static FiltroBloqueo aFiltroBloqueo(String valor) {
        try {
            return FiltroBloqueo.valueOf(valor.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "El parámetro 'bloqueo' admite TODOS, BLOQUEANTES o NO_BLOQUEANTES, no '"
                    + valor + "'");
        }
    }

    private static RespuestaPaginada<RespuestaMotivoPendiente> aRespuestaPaginada(
            PaginaPendientes resultado) {
        var pagina = resultado.pagina();
        return new RespuestaPaginada<>(
                pagina.elementos().stream()
                        .map(p -> aRespuesta(p, resultado.bloquea(p)))
                        .toList(),
                pagina.cursorSiguiente().map(c -> String.valueOf(c.ultimaReferencia())).orElse(null),
                pagina.totalRegistros().orElse(null),
                pagina.tamanoPagina());
    }

    private static RespuestaMotivoPendiente aRespuesta(MotivoPendiente p, boolean bloqueante) {
        return new RespuestaMotivoPendiente(
                p.identificador(), p.codigo(), p.descripcion(),
                p.resuelto(), p.soloAdjudicacion(), p.nivel().name(),
                p.referenciaLinea() != null ? p.referenciaLinea().valor() : null,
                p.numeroLinea(),
                bloqueante,
                p.version().numero());
    }

    /**
     * POST /api/v1/cuentas/{codigo}/pendientes/resolver
     *
     * <p>Resuelve varios motivos de una vez. Responde {@code 200} con el
     * desenlace, no {@code 204}: la operación puede salir a medias y hace falta
     * un cuerpo donde quepa decirlo. Ver {@link RespuestaResolucionMasiva}.
     *
     * <p>Un nivel ausente se interpreta como {@code DONDE_APLIQUE}; uno que no
     * sea de los tres válidos lo rechaza la validación del DTO con un 400, en vez
     * de caer al valor por omisión y resolver algo distinto de lo que se pidió.
     */
    public Mono<ServerResponse> resolverEnMasa(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudResolverEnMasa.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> resolverEnMasa.ejecutar(
                        codigo,
                        new java.util.LinkedHashSet<>(dto.motivos()),
                        dto.nivel() == null || dto.nivel().isBlank()
                                ? NivelResolucion.DONDE_APLIQUE
                                : NivelResolucion.valueOf(dto.nivel()),
                        dto.justificacion(), autor,
                        aSeleccion(dto.lineas())))
                .flatMap(ManejadorPendientes::aRespuestaHttp);
    }

    /**
     * GET /api/v1/cuentas/{codigo}/pendientes/resoluciones?referencias=1,2
     *
     * <p>Cómo van las resoluciones que devolvió {@code /resolver} con desenlace
     * {@code EN_CURSO} (OPE-06). Responde lo mismo que aquella: 202 mientras alguna siga en
     * curso y 200 cuando todas terminaron, con los fallos parciales dentro.
     *
     * <p>No guarda ni lee nada del servicio: pregunta al sistema de registro por cada
     * referencia, así que contesta igual cualquier réplica. Las referencias pueden venir en
     * un parámetro separado por comas o repitiendo el parámetro.
     */
    public Mono<ServerResponse> seguirResolucion(ServerRequest solicitud) {
        var referencias = solicitud.queryParams().getOrDefault("referencias", java.util.List.of())
                .stream()
                .flatMap(valor -> java.util.Arrays.stream(valor.split(",")))
                .toList();

        return resolverEnMasa.seguir(new CodigoCuenta(solicitud.pathVariable("codigo")), referencias)
                .flatMap(ManejadorPendientes::aRespuestaHttp);
    }

    /**
     * POST /api/v1/cuentas/{codigo}/pendientes/agregar
     *
     * <p>Pone un motivo de pendiente sobre las líneas marcadas, o sobre la cabecera si no se
     * indican. Responde <b>204</b> porque no hay nada que devolver: el sistema de registro lo
     * aplica de forma síncrona —medido: 204 sin cabecera de seguimiento— y el estado nuevo se
     * lee recargando la pestaña.
     */
    public Mono<ServerResponse> agregarPendiente(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudAgregarPendiente.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> agregar.ejecutar(codigo, dto.motivo(),
                                                 aSeleccion(dto.lineas()), autor))
                .then(ServerResponse.noContent().build());
    }

    /**
     * A qué líneas acotar, o todas.
     *
     * <p>Una lista ausente <b>o vacía</b> es «todas»: es el contrato del sistema de registro
     * y lo que hacía esta ruta antes de que existiera el alcance. Lo que no puede pasar es
     * que una selección vacía de la pantalla llegue aquí como lista vacía y se entienda como
     * «toda la cuenta»; por eso el tipo del dominio obliga a decirlo y la pantalla no ofrece
     * el botón sin selección.
     */
    private static SeleccionLineas aSeleccion(java.util.List<Long> lineas) {
        if (lineas == null || lineas.isEmpty()) return SeleccionLineas.TODAS;
        return SeleccionLineas.de(lineas.stream().map(ReferenciaLinea::new).toList());
    }

    /**
     * {@code 200} cuando ya se sabe en qué acabó; {@code 202} mientras el sistema
     * de registro siga trabajando.
     *
     * <p>La distinción es la que impide que el cliente rotule como hecho algo que
     * todavía no lo está: un {@code 200} dice «esto es el resultado», y un
     * {@code 202} dice «se aceptó y sigue en curso». El mismo criterio que usa el
     * envío de la cuenta.
     */
    private static Mono<ServerResponse> aRespuestaHttp(ResultadoResolucionMasiva resultado) {
        var enCurso = resultado.desenlace() == ResultadoResolucionMasiva.Desenlace.EN_CURSO;
        var constructor = enCurso ? ServerResponse.accepted() : ServerResponse.ok();
        return constructor.contentType(MediaType.APPLICATION_JSON)
                          .bodyValue(aRespuesta(resultado));
    }

    private static RespuestaResolucionMasiva aRespuesta(ResultadoResolucionMasiva resultado) {
        return new RespuestaResolucionMasiva(
                resultado.desenlace().name(),
                resultado.todoResuelto(),
                resultado.referencias(),
                resultado.fallos().stream()
                        .map(f -> new RespuestaResolucionMasiva.Fallo(
                                f.codigo(), f.elemento(), f.detalle()))
                        .toList());
    }

    /** POST /api/v1/cuentas/{codigo}/pendientes/{motivo}/resolver */
    public Mono<ServerResponse> resolver(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var motivo = Long.parseLong(solicitud.pathVariable("motivo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudResolverPendiente.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> resolver.ejecutar(
                        codigo, motivo,
                        ResolverPendientesCasoDeUso.Alcance.valueOf(dto.alcance()),
                        dto.justificacion(), autor))
                .then(ServerResponse.noContent().build());
    }
}
