package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.RespuestaMotivoPendiente;
import co.sura.auditoria.api.dto.SolicitudResolverPendiente;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ResolverPendientesCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones sobre pendientes de la cuenta médica.
 */
@Component
public class ManejadorPendientes {

    private final PuertoPendientes            pendientes;
    private final ResolverPendientesCasoDeUso resolver;
    private final ValidadorSolicitudes        validador;

    public ManejadorPendientes(PuertoPendientes pendientes,
                               ResolverPendientesCasoDeUso resolver,
                               ValidadorSolicitudes validador) {
        this.pendientes = pendientes;
        this.resolver   = resolver;
        this.validador  = validador;
    }

    /** GET /api/v1/cuentas/{codigo}/pendientes */
    public Mono<ServerResponse> listarSinResolver(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));

        return pendientes.listarSinResolver(codigo)
                .map(p -> new RespuestaMotivoPendiente(
                        p.identificador(), p.codigo(), p.descripcion(),
                        p.resuelto(), p.soloAdjudicacion(), p.nivel().name(),
                        p.referenciaLinea() != null ? p.referenciaLinea().valor() : null,
                        p.numeroLinea(),
                        p.version().numero()))
                .collectList()
                .flatMap(lista -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(lista));
    }

    /** POST /api/v1/cuentas/{codigo}/pendientes/{motivo}/resolver */
    public Mono<ServerResponse> resolver(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var motivo = Long.parseLong(solicitud.pathVariable("motivo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudResolverPendiente.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> resolver.ejecutar(
                        codigo, motivo,
                        ResolverPendientesCasoDeUso.Alcance.valueOf(dto.alcance()),
                        dto.justificacion(), autor))
                .then(ServerResponse.noContent().build());
    }
}
