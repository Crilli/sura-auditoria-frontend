package co.sura.auditoria.api.dto;

import java.util.List;

/**
 * Cómo acabó un cambio sobre varias líneas.
 *
 * <p>El desenlace viaja aparte del código HTTP a propósito: un parcial es {@code 200}, porque la
 * petición fue correcta y algo se aplicó. Devolver un error por las líneas que no se pudieron
 * tocar haría que el cliente diera por no hecho lo que sí ocurrió —y es irreversible—.
 *
 * @param desenlace COMPLETO, PARCIAL o FALLIDO
 * @param fallos    una entrada por línea que no se pudo cambiar, con el número que ve el auditor
 * @param yaEstaban las que ya tenían lo pedido y no se tocaron: repetir un lote no duplica nada
 *                  (OPE-12)
 */
public record RespuestaCambiosEnLote(String desenlace,
                                     int aplicadas,
                                     List<Long> referenciasAplicadas,
                                     List<Fallo> fallos,
                                     int yaEstaban,
                                     List<Long> referenciasYaEstaban) {

    /** @param numeroLinea el que ve el auditor; {@code null} si la línea ya no existe */
    public record Fallo(Long referencia, Integer numeroLinea, String motivo) {}
}
