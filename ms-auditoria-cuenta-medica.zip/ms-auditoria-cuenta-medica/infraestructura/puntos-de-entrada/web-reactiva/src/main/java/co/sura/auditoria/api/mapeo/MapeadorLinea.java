package co.sura.auditoria.api.mapeo;

import co.sura.auditoria.api.dto.*;
import co.sura.auditoria.modelo.cuenta.*;

import java.util.Optional;

/** Mapea entre el modelo de dominio de líneas y los DTOs de respuesta de la API. */
public final class MapeadorLinea {

    private MapeadorLinea() {}

    public static RespuestaPaginada<RespuestaResumenLinea> aRespuestaPaginada(Pagina<ResumenLinea> pagina) {
        return new RespuestaPaginada<>(
                pagina.elementos().stream().map(MapeadorLinea::aResumen).toList(),
                pagina.cursorSiguiente().map(c -> String.valueOf(c.ultimaReferencia())).orElse(null),
                pagina.totalRegistros().orElse(null),
                pagina.tamanoPagina());
    }

    public static RespuestaResumenLinea aResumen(ResumenLinea linea) {
        return new RespuestaResumenLinea(
                linea.referencia().valor(),
                linea.numeroLinea(),
                linea.codigoProcedimiento(),
                linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(),
                linea.codigoAfiliado(),
                linea.nombreAfiliado(),
                linea.valorAutorizado(),
                linea.valorCubierto(),
                linea.esEditable(),
                linea.cantidadPendientes(),
                linea.pendientes().stream().map(MapeadorLinea::aMotivoPendiente).toList(),
                linea.tieneNovedadBloqueante(),
                linea.version().numero());
    }

    public static RespuestaDetalleLinea aRespuestaDetalle(LineaCuenta linea) {
        var p = linea.prestacion();
        var c = linea.convenio();
        var o = linea.otrosDatos();
        return new RespuestaDetalleLinea(
                linea.referencia().valor(),
                linea.codigoCuenta().valor(),
                linea.numeroLinea(),
                linea.fechaInicio(),
                linea.fechaFin(),
                linea.codigoAfiliado(),
                linea.nombreAfiliado(),
                linea.codigoProcedimiento(),
                linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(),
                new RespuestaDetalleLinea.RespuestaPrestacion(
                        p.codigo(), p.descripcion(), p.catalogo(),
                        p.codigoNoDefinido(), p.codigoNoDefinidoDef(),
                        p.descripcionRips(), p.claseServicio(), p.especialidad()),
                linea.codigoAutorizacion(),
                linea.prestadorAtencionCodigo(),
                linea.prestadorAtencionNombre(),
                linea.valorCargado(),
                linea.unidadesCargadas(),
                linea.valorAutorizado(),
                linea.unidadesAutorizadas(),
                linea.valorCubierto(),
                linea.unidadesCubiertas(),
                linea.valorGlosado(),
                linea.observacionesGlosa(),
                new RespuestaDetalleLinea.RespuestaDatosConvenio(
                        c.codigoTarifarioIss2001(), c.codigoTarifarioIss2000(),
                        c.codigoTarifarioSoat(), c.numeroContrato(), c.homologoCups(),
                        c.multiplesCupsHomologos(), c.codigoUnicoContratoSiifa(),
                        c.valorConvenido(), c.tarifaAplicada()),
                new RespuestaDetalleLinea.RespuestaOtrosDatosLinea(
                        o.tipoSala(), o.viaDeAcceso(),
                        o.unidadEstrategicaNegocio(), o.codigoSiniestro()),
                linea.diagnosticos().stream()
                        .map(d -> new RespuestaDetalleLinea.RespuestaDiagnosticoLinea(
                                d.secuencia(), d.tipo(), d.descripcionTipo(),
                                d.codigo(), d.descripcion()))
                        .toList(),
                linea.glosas().stream()
                        .map(g -> new RespuestaDetalleLinea.RespuestaDetalleGlosa(
                                g.identificador(), g.valor(), g.codigoNotaCredito(),
                                g.generico(), g.especifico(), g.texto()))
                        .toList(),
                linea.conservarBeneficios(),
                linea.conservarTarifacion(),
                linea.beneficiosManuales(),
                linea.tarifacionManual(),
                linea.bloqueada(),
                linea.reemplazada(),
                linea.esEditable(),
                linea.novedades().stream()
                        .map(n -> new RespuestaNovedades(n.identificador(), n.codigo(),
                                n.descripcion(), n.severidad().name(), n.origen()))
                        .toList(),
                // Mismo DTO que el listado de pendientes de la cuenta: antes era un
                // HashMap anónimo que se dejaba fuera soloAdjudicacion y la versión,
                // así que la pantalla de la línea no podía saber si el pendiente
                // bloquea ni resolverlo.
                linea.pendientes().stream()
                        .map(MapeadorLinea::aMotivoPendiente)
                        .toList(),
                linea.version().numero());
    }

    private static RespuestaMotivoPendiente aMotivoPendiente(MotivoPendiente p) {
        return new RespuestaMotivoPendiente(
                p.identificador(),
                p.codigo(),
                p.descripcion(),
                p.resuelto(),
                p.soloAdjudicacion(),
                p.nivel().name(),
                p.referenciaLinea() == null ? null : p.referenciaLinea().valor(),
                p.numeroLinea(),
                // Si un pendiente bloquea depende del estado de la cuenta, y el
                // detalle de la línea no lo trae: null es «no evaluado aquí».
                null,
                p.version().numero());
    }

    /**
     * Arma el comando de edición. Cada campo nulo en el cuerpo se traduce a
     * {@link Optional#empty()}, que es cómo el dominio distingue «no me lo
     * mandaron» de «mándalo en nulo».
     */
    public static EdicionLinea aEdicionLinea(ReferenciaLinea referencia, SolicitudGuardarLinea dto) {
        return new EdicionLinea(
                referencia,
                new Version(dto.versionEsperada()),
                Optional.ofNullable(dto.valorAutorizado()),
                Optional.ofNullable(dto.unidadesAutorizadas()),
                Optional.ofNullable(dto.conservarBeneficios()),
                Optional.ofNullable(dto.conservarTarifacion()),
                Optional.ofNullable(dto.observacionesGlosa()),
                Optional.ofNullable(dto.valorCargado()),
                Optional.ofNullable(dto.unidadesCargadas()),
                Optional.ofNullable(dto.valorGlosado()),
                Optional.ofNullable(dto.codigoAutorizacion()),
                Optional.ofNullable(dto.fechaInicio()),
                Optional.ofNullable(dto.fechaFin()),
                Optional.ofNullable(dto.codigoNoDefinido()),
                Optional.ofNullable(dto.codigoNoDefinidoDef()),
                Optional.ofNullable(dto.descripcionRips()),
                Optional.ofNullable(dto.numeroContrato()),
                Optional.ofNullable(dto.homologoCups()),
                Optional.ofNullable(dto.codigoUnicoContratoSiifa()),
                Optional.ofNullable(dto.codigoSiniestro()),
                ModoRecalculo.valueOf(dto.modoRecalculo()));
    }
}
