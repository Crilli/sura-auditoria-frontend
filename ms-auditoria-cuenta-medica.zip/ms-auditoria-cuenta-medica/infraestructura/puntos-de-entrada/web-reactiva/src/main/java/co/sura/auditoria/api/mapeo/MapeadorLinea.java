package co.sura.auditoria.api.mapeo;

import co.sura.auditoria.api.dto.*;
import co.sura.auditoria.modelo.cuenta.*;

import java.util.Optional;

/** Mapea entre el modelo de dominio de líneas y los DTOs de respuesta de la API. */
public final class MapeadorLinea {

    private MapeadorLinea() {}

    public static RespuestaPaginada<RespuestaResumenLinea> aRespuestaPaginada(Pagina<ResumenLinea> pagina) {
        return new RespuestaPaginada<>(
                pagina.elementos().stream().map(MapeadorLinea::aResumen).toList(),
                pagina.cursorSiguiente().map(c -> String.valueOf(c.ultimaReferencia())).orElse(null),
                pagina.totalRegistros().orElse(null),
                pagina.tamanoPagina());
    }

    public static RespuestaResumenLinea aResumen(ResumenLinea linea) {
        return new RespuestaResumenLinea(
                linea.referencia().valor(),
                linea.numeroLinea(),
                linea.codigoProcedimiento(),
                linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(),
                linea.codigoAfiliado(),
                linea.nombreAfiliado(),
                linea.fechaInicio(),
                linea.fechaFin(),
                linea.codigoAutorizacion(),
                linea.valorAutorizado(),
                linea.valorCubierto(),
                linea.valorGlosado(),
                linea.esEditable(),
                linea.cantidadPendientes(),
                linea.pendientes().stream().map(MapeadorLinea::aMotivoPendiente).toList(),
                linea.tieneNovedadBloqueante(),
                linea.version().numero());
    }

    public static RespuestaDetalleLinea aRespuestaDetalle(LineaCuenta linea) {
        var p = linea.prestacion();
        var c = linea.convenio();
        var o = linea.otrosDatos();
        return new RespuestaDetalleLinea(
                linea.referencia().valor(),
                linea.codigoCuenta().valor(),
                linea.numeroLinea(),
                linea.fechaInicio(),
                linea.fechaFin(),
                linea.codigoAfiliado(),
                linea.nombreAfiliado(),
                linea.codigoProcedimiento(),
                linea.descripcionProcedimiento(),
                linea.catalogoProcedimiento(),
                new RespuestaDetalleLinea.RespuestaPrestacion(
                        p.codigo(), p.descripcion(), p.catalogo(),
                        p.codigoNoDefinido(), p.codigoNoDefinidoDef(),
                        p.descripcionRips(), p.claseServicio(), p.especialidad()),
                linea.codigoAutorizacion(),
                linea.prestadorAtencionCodigo(),
                linea.prestadorAtencionNombre(),
                linea.valorCargado(),
                linea.unidadesCargadas(),
                linea.valorAutorizado(),
                linea.unidadesAutorizadas(),
                linea.valorCubierto(),
                linea.unidadesCubiertas(),
                linea.valorGlosado(),
                linea.observacionesGlosa(),
                new RespuestaDetalleLinea.RespuestaDatosConvenio(
                        c.codigoTarifarioIss2001(), c.codigoTarifarioIss2000(),
                        c.codigoTarifarioSoat(), c.numeroContrato(), c.homologoCups(),
                        c.multiplesCupsHomologos(), c.codigoUnicoContratoSiifa(),
                        c.valorConvenido(), c.tarifaAplicada()),
                new RespuestaDetalleLinea.RespuestaOtrosDatosLinea(
                        o.tipoSala(), o.viaDeAcceso(),
                        o.unidadEstrategicaNegocio(), o.codigoSiniestro()),
                linea.diagnosticos().stream()
                        .map(d -> new RespuestaDetalleLinea.RespuestaDiagnosticoLinea(
                                d.secuencia(), d.tipo(), d.descripcionTipo(),
                                d.codigo(), d.descripcion()))
                        .toList(),
                linea.glosas().stream()
                        .map(g -> new RespuestaDetalleLinea.RespuestaDetalleGlosa(
                                g.identificador(), g.valor(), g.codigoNotaCredito(),
                                g.generico(), g.especifico(), g.texto()))
                        .toList(),
                linea.conservarBeneficios(),
                linea.conservarTarifacion(),
                linea.beneficiosManuales(),
                linea.tarifacionManual(),
                linea.bloqueada(),
                linea.reemplazada(),
                linea.esEditable(),
                linea.novedades().stream()
                        .map(MapeadorLinea::aNovedad)
                        .toList(),
                // Mismo DTO que el listado de pendientes de la cuenta: antes era un
                // HashMap anónimo que se dejaba fuera soloAdjudicacion y la versión,
                // así que la pantalla de la línea no podía saber si el pendiente
                // bloquea ni resolverlo.
                linea.pendientes().stream()
                        .map(MapeadorLinea::aMotivoPendiente)
                        .toList(),
                linea.version().numero());
    }

    /**
     * Una novedad para la pantalla.
     *
     * <p>Lleva el origen, quién la puso y cuándo, además de los dos conceptos
     * normativos. Es lo que hace falta para que el auditor distinga lo que puso
     * un compañero de lo que levantó el motor —que es, además, lo único que se
     * le permite quitar—, y es lo mismo que enseña la interfaz del sistema de
     * registro en su propia tabla.
     */
    /**
     * Visible fuera porque la cabecera de la cuenta publica las suyas con este
     * mismo DTO: una novedad es lo mismo colgando de una línea o de la cuenta.
     */
    static RespuestaNovedad aNovedadPublica(Novedad n) {
        return aNovedad(n);
    }

    private static RespuestaNovedad aNovedad(Novedad n) {
        return new RespuestaNovedad(
                n.identificador(), n.codigo(),
                // El texto ya resuelto es el que se lee; la plantilla va aparte
                // para que la pantalla pueda enseñar qué hueco rellena cada dato.
                n.textoResuelto(), n.descripcion(), n.valores(),
                n.severidad().name(), n.origen(), n.laPusoUnaPersona(), n.esDelSistema(),
                aClasificacion(n.generico()), aClasificacion(n.especifico()),
                n.autor(), n.fecha());
    }

    private static RespuestaNovedad.Clasificacion aClasificacion(Novedad.Clasificacion c) {
        return c == null ? null
                : new RespuestaNovedad.Clasificacion(c.codigo(), c.descripcion());
    }

    private static RespuestaMotivoPendiente aMotivoPendiente(MotivoPendiente p) {
        return new RespuestaMotivoPendiente(
                p.identificador(),
                p.codigo(),
                p.descripcion(),
                p.resuelto(),
                p.soloAdjudicacion(),
                p.nivel().name(),
                p.referenciaLinea() == null ? null : p.referenciaLinea().valor(),
                p.numeroLinea(),
                // Si un pendiente bloquea depende del estado de la cuenta, y el
                // detalle de la línea no lo trae: null es «no evaluado aquí».
                null,
                p.version().numero());
    }

    /**
     * Arma el comando de edición. Cada campo nulo en el cuerpo se traduce a
     * {@link Optional#empty()}, que es cómo el dominio distingue «no me lo
     * mandaron» de «mándalo en nulo».
     */
    public static EdicionLinea aEdicionLinea(ReferenciaLinea referencia, SolicitudGuardarLinea dto) {
        return new EdicionLinea(
                referencia,
                new Version(dto.versionEsperada()),
                Optional.ofNullable(dto.valorAutorizado()),
                Optional.ofNullable(dto.unidadesAutorizadas()),
                Optional.ofNullable(dto.conservarBeneficios()),
                Optional.ofNullable(dto.conservarTarifacion()),
                Optional.ofNullable(dto.observacionesGlosa()),
                Optional.ofNullable(dto.valorCargado()),
                Optional.ofNullable(dto.unidadesCargadas()),
                Optional.ofNullable(dto.valorGlosado()),
                Optional.ofNullable(dto.codigoAutorizacion()),
                Optional.ofNullable(dto.fechaInicio()),
                Optional.ofNullable(dto.fechaFin()),
                Optional.ofNullable(dto.codigoNoDefinido()),
                Optional.ofNullable(dto.codigoNoDefinidoDef()),
                Optional.ofNullable(dto.descripcionRips()),
                Optional.ofNullable(dto.numeroContrato()),
                Optional.ofNullable(dto.homologoCups()),
                Optional.ofNullable(dto.codigoUnicoContratoSiifa()),
                Optional.ofNullable(dto.codigoSiniestro()),
                aCambiosDeGlosa(dto.glosas()),
                aCambiosDeNovedad(dto.novedades()),
                ModoRecalculo.valueOf(dto.modoRecalculo()));
    }

    /**
     * Traduce las altas y bajas del desglose.
     *
     * <p>Las fábricas del dominio son las que comprueban que un alta no traiga
     * identificador y que una baja no traiga importe. Aquí solo se elige cuál
     * llamar: el error que salga de ellas es un {@code IllegalArgumentException}
     * que la capa web ya traduce a 400.
     */
    private static java.util.List<CambioGlosa> aCambiosDeGlosa(
            java.util.List<SolicitudCambioGlosa> glosas) {
        if (glosas == null || glosas.isEmpty()) return java.util.List.of();
        return glosas.stream()
                .map(g -> "ELIMINAR".equals(g.operacion())
                        ? CambioGlosa.eliminar(
                                g.identificador() == null
                                        ? exigirIdentificador()
                                        : g.identificador())
                        : CambioGlosa.agregar(g.codigoGlosa(), g.generico(), g.especifico(),
                                              g.valor(), g.texto()))
                .toList();
    }

    /**
     * Traduce las altas y bajas de novedad.
     *
     * <p>Igual que {@link #aCambiosDeGlosa}: las fábricas del dominio comprueban
     * la coherencia y aquí solo se elige cuál llamar.
     */
    /**
     * Visible fuera porque la cabecera de la cuenta manda los mismos cambios:
     * el DTO de entrada es el mismo y las comprobaciones del dominio también.
     */
    public static java.util.List<CambioNovedad> aCambiosDeNovedadPublico(
            java.util.List<SolicitudCambioNovedad> novedades) {
        return aCambiosDeNovedad(novedades);
    }

    private static java.util.List<CambioNovedad> aCambiosDeNovedad(
            java.util.List<SolicitudCambioNovedad> novedades) {
        if (novedades == null || novedades.isEmpty()) return java.util.List.of();
        return novedades.stream()
                .map(n -> "ELIMINAR".equals(n.operacion())
                        // Se construye el record en vez de llamar a la fábrica
                        // `eliminar`: la fábrica descarta el código y los datos,
                        // y con eso la comprobación del dominio —«eliminar una
                        // novedad solo admite su identificador»— nunca llegaba a
                        // dispararse desde el API. Un cuerpo incoherente recibía
                        // 200 y silencio en vez del 400 que el dominio promete.
                        ? new CambioNovedad(CambioNovedad.Operacion.ELIMINAR,
                                            n.identificador() == null
                                                    ? exigirIdentificador()
                                                    : n.identificador(),
                                            n.codigoNovedad(),
                                            n.valores())
                        : CambioNovedad.agregar(n.codigoNovedad(), n.valores()))
                .toList();
    }

    /** El dominio lo diría igual, pero aquí el mensaje nombra el campo del cuerpo. */
    private static long exigirIdentificador() {
        throw new IllegalArgumentException(
                "Para eliminar una glosa hay que enviar su «identificador»");
    }
}
