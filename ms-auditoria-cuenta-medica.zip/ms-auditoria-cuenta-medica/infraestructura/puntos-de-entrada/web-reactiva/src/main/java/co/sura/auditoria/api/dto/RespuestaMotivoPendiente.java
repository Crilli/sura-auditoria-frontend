package co.sura.auditoria.api.dto;

/** Motivo pendiente. */
public record RespuestaMotivoPendiente(
        long identificador,
        String codigo,
        String descripcion,
        boolean resuelto,
        boolean soloAdjudicacion,
        String nivel,
        /** Identificador interno de la línea en OHI; no significa nada para el auditor. */
        Long referenciaLinea,
        /** Número de línea tal como se ve en la grilla. {@code null} en los de cabecera. */
        Integer numeroLinea,
        long version
) {}
