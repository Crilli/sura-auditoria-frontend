package co.sura.auditoria.api.dto;

/**
 * Motivo pendiente.
 *
 * <p>{@code soloAdjudicacion} es el indicador del catálogo de OHI y
 * {@code bloqueante} la conclusión ya sacada contra el estado en que está la
 * cuenta: el mismo motivo bloquea o no según ese estado, así que el cliente no
 * puede deducirlo del primero por su cuenta sin repetir la regla.
 *
 * <p>Por eso {@code bloqueante} es {@code Boolean} y no {@code boolean}: el
 * detalle de una línea usa este mismo DTO y ahí no se conoce el estado de la
 * cuenta, así que llega {@code null} — «no evaluado aquí», que es distinto de
 * «no bloquea». Rellenarlo con {@code false} habría sido afirmar que no bloquea
 * sin haberlo comprobado; quien lo consuma debe tratar el nulo como «no se sabe».
 */
public record RespuestaMotivoPendiente(
        long identificador,
        String codigo,
        String descripcion,
        boolean resuelto,
        boolean soloAdjudicacion,
        String nivel,
        /** Identificador interno de la línea en OHI; no significa nada para el auditor. */
        Long referenciaLinea,
        /** Número de línea tal como se ve en la grilla. {@code null} en los de cabecera. */
        Integer numeroLinea,
        /**
         * Si impide enviar la cuenta en el estado en que está hoy.
         * {@code null} cuando quien construye la respuesta no conoce ese estado.
         */
        Boolean bloqueante,
        long version
) {}
