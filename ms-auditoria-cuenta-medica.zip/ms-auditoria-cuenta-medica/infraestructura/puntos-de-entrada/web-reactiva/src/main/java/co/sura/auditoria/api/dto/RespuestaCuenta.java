package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Respuesta del GET /api/v1/cuentas/{codigo}: solo lo que la interfaz pinta.
 *
 * <p>Las acciones disponibles ya no vienen aquí — se piden a
 * {@code GET /api/v1/cuentas/{codigo}/acciones}. Ver {@link RespuestaAcciones}.
 */
public record RespuestaCuenta(
        String codigo,
        String estado,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        BigDecimal totalAutorizado,
        BigDecimal totalCubierto,
        long version,
        int pendientesSinResolver,
        RespuestaInformacionFacturacion informacionFacturacion
) {}
