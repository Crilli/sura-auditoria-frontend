package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Respuesta del GET /api/v1/cuentas/{codigo}: solo lo que la interfaz pinta.
 *
 * <p>Las acciones disponibles ya no vienen aquí — se piden a
 * {@code GET /api/v1/cuentas/{codigo}/acciones}. Ver {@link RespuestaAcciones}.
 */
public record RespuestaCuenta(
        String codigo,
        String estado,
        /**
         * Si se pueden cambiar los datos de la cuenta: solo en {@code MODIFICACION} (EST-01).
         *
         * <p>Lo calcula el servicio con {@code EstadoCuenta.admiteCambiosDeDatos()} para que la
         * pantalla no repita la regla: le basta este booleano para abrir o cerrar la edición. El
         * servicio sigue siendo la autoridad: fuera de modificación, cualquier cambio de datos
         * responde {@code 409 CUENTA_NO_MODIFICABLE}. Viaja también en las respuestas que
         * devuelven la cuenta releída (novedades de cabecera y acciones), así que una acción que
         * la pasa a modificación abre la edición sin otra consulta.
         */
        boolean admiteCambios,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        /**
         * Total convenido: {@code totalAllowedAmount} (ENC-12). Es la única fuente del total
         * convenido: la ficha de facturación ya no lo repite. Hasta el 2026-10-21 este importe
         * viajaba con el nombre {@code totalAutorizado}. {@code null} si no viene, no cero.
         */
        BigDecimal totalConvenido,
        /**
         * Total autorizado: {@code totalCoveredAmount} (ENC-13). Hasta el 2026-10-21 viajaba como
         * {@code totalCubierto}.
         */
        BigDecimal totalAutorizado,
        long version,
        int pendientesSinResolver,
        /**
         * Novedades de la cabecera, las mismas que el sistema de registro
         * enseña en su tabla de la cuenta. Son de la misma forma que las de una
         * línea y por eso comparten DTO.
         */
        java.util.List<RespuestaNovedad> novedades,
        RespuestaInformacionFacturacion informacionFacturacion,
        /**
         * Lo que el prestador respondió a las glosas, en orden de llegada.
         *
         * <p>Viaja en la cabecera y no en una ruta aparte porque viene en la misma consulta
         * al sistema de registro: pedirla por separado sería una llamada de más para un dato
         * que ya está en la mano.
         */
        java.util.List<RespuestaAGlosa> respuestasGlosa
) {

    /**
     * Una respuesta a glosa.
     *
     * @param versionAbierta la versión de la cuenta que esta respuesta abrió, con la forma
     *                       {@code CM-94421-V4}. Es VIS-11, y sale de aquí: no hace falta
     *                       consultar el histórico de versiones para tenerla
     */
    public record RespuestaAGlosa(String secuencia,
                                  String versionAbierta,
                                  java.math.BigDecimal valor,
                                  java.time.LocalDate fechaLlegada,
                                  java.time.LocalDate fechaVencimiento,
                                  boolean vencida) {}
}
