package co.sura.auditoria.api.error;

import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.MDC;
import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Traductor de errores de dominio a atributos HTTP estructurados.
 *
 * <p>El {@code switch} sobre la interfaz sellada {@link ErrorDeDominio}
 * es exhaustivo: agregar una variante sin traducirla rompe la compilación.
 */
@Component
public class AtributosErrorGlobal extends DefaultErrorAttributes {

    @Override
    public Map<String, Object> getErrorAttributes(ServerRequest solicitud,
                                                  org.springframework.boot.web.error.ErrorAttributeOptions opciones) {
        var causa = getError(solicitud);

        var problema = switch (causa) {
            case ExcepcionDeDominio exc -> traducir(exc.error());
            case ConstraintViolationException cve -> new Problema(400, "SOLICITUD_INVALIDA",
                    cve.getConstraintViolations().stream()
                            .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                            .collect(Collectors.joining("; ")));
            case IllegalArgumentException iae -> new Problema(400, "SOLICITUD_INVALIDA", iae.getMessage());
            // Errores del propio WebFlux: ruta inexistente, método no permitido, medio no soportado.
            // Sin este caso caerían en el default y saldrían como 500.
            case ResponseStatusException rse -> traducirHttp(rse, solicitud);
            default -> new Problema(500, "ERROR_INTERNO", "Ocurrió un error inesperado");
        };

        return Map.of(
                // Spring lee "status" de este mapa para fijar el código HTTP de la respuesta
                // (DefaultErrorWebExceptionHandler#getHttpStatus). Sin esta clave todo saldría 500.
                "status",    problema.estado(),
                "estado",    problema.estado(),
                "codigo",    problema.codigo(),
                "mensaje",   problema.mensaje(),
                "idTraza",   idTraza(),
                "instante",  Instant.now().toString());
    }

    /** Identificador de traza para correlacionar con los logs; "-" si no hay traza activa. */
    private String idTraza() {
        var propio = MDC.get("idTraza");
        if (propio != null) return propio;
        var deTrazado = MDC.get("traceId");
        return deTrazado != null ? deTrazado : "-";
    }

    /**
     * Conserva el código HTTP que ya decidió WebFlux en vez de degradarlo a 500.
     * El mensaje se reescribe: el texto interno de Spring («No static resource …»)
     * delata el enrutamiento y no le dice nada útil a quien consume el API.
     */
    private Problema traducirHttp(ResponseStatusException excepcion, ServerRequest solicitud) {
        int estado = excepcion.getStatusCode().value();

        var codigo = switch (estado) {
            case 404 -> "RUTA_NO_ENCONTRADA";
            case 405 -> "METODO_NO_PERMITIDO";
            case 406 -> "FORMATO_NO_ACEPTABLE";
            case 415 -> "MEDIO_NO_SOPORTADO";
            default  -> "ERROR_HTTP";
        };

        var mensaje = switch (estado) {
            case 404 -> "La ruta %s no corresponde a ninguna operación del API. "
                            .formatted(solicitud.path())
                      + "Las cuentas médicas se consultan por su código: /api/v1/cuentas/{codigo}";
            case 405 -> "El método HTTP no está permitido para esta ruta";
            case 406 -> "Este API produce application/json; el seguimiento del proceso, text/event-stream";
            case 415 -> "El cuerpo de la solicitud debe enviarse como application/json";
            default  -> excepcion.getReason() != null
                            ? excepcion.getReason()
                            : "La solicitud no pudo ser atendida";
        };

        return new Problema(estado, codigo, mensaje);
    }

    private Problema traducir(ErrorDeDominio error) {
        return switch (error) {
            case ErrorDeDominio.CuentaNoEncontrada e ->
                new Problema(404, "CUENTA_NO_ENCONTRADA",
                        "No existe la cuenta médica " + e.codigoCuenta());

            case ErrorDeDominio.LineaNoEncontrada e ->
                new Problema(404, "LINEA_NO_ENCONTRADA",
                        "No existe la línea solicitada en la cuenta");

            case ErrorDeDominio.AccionNoDisponible e ->
                new Problema(409, "ACCION_NO_DISPONIBLE",
                        "La cuenta no permite la acción " + e.accion() + " en su estado actual");

            case ErrorDeDominio.PendientesBloqueanEnvio e ->
                new Problema(409, "PENDIENTES_SIN_RESOLVER",
                        e.cantidad() + " pendiente(s) impiden enviar la cuenta");

            // 409 como ACCION_NO_DISPONIBLE: choca con el estado actual y el auditor lo puede
            // remediar —pasar la cuenta a modificación— y reintentar. La pantalla enseña el
            // mensaje tal cual, así que tiene que bastarse solo y nombrar el estado con las
            // mismas palabras que ella (EstadoCuenta.enPalabras), no con el nombre del enum.
            case ErrorDeDominio.CuentaNoModificable e ->
                new Problema(409, "CUENTA_NO_MODIFICABLE",
                        ("La cuenta %1$s está en %2$s: sus datos solo se cambian en %3$s. "
                       + "Pásela a %3$s y vuelva a intentarlo.")
                                .formatted(e.codigoCuenta(), enPalabras(e.estado()),
                                           EstadoCuenta.MODIFICACION.enPalabras()));

            case ErrorDeDominio.ModificacionConcurrente e ->
                new Problema(412, "MODIFICACION_CONCURRENTE",
                        "Otro usuario modificó la información. Actualice y vuelva a intentar.");

            case ErrorDeDominio.SinPermiso e ->
                new Problema(403, "SIN_PERMISO", e.detalle());

            case ErrorDeDominio.LimiteAprobacionExcedido e ->
                new Problema(403, "LIMITE_APROBACION_EXCEDIDO",
                        // «Autorizado» y no «cubierto»: desde el 2026-10-21 el coveredAmount
                        // se llama valor autorizado en toda la aplicación.
                        "El valor autorizado supera su límite de aprobación");

            case ErrorDeDominio.LineaNoEditable e ->
                new Problema(422, "LINEA_NO_EDITABLE", e.razon());

            // Normalmente no llega hasta aquí: el caso de uso del lote lo captura para quitar
            // esa línea y reintentar el resto. Si sale por el canal web es que el rechazo
            // ocurrió fuera de un lote, y entonces lo que importa es el porqué, no el índice.
            case ErrorDeDominio.LineaDelLoteRechazada e ->
                new Problema(422, "LINEA_RECHAZADA", e.detalle());

            // 503 porque lo que falló fue el sistema de registro al releer, pero con un código
            // propio y un mensaje que dice que el cambio SÍ se aplicó: quien lo lea no debe
            // repetirlo, sino recargar (OPE-11).
            case ErrorDeDominio.AplicadoSinRelectura e ->
                new Problema(503, "APLICADO_SIN_RELEER",
                        "El cambio se aplicó en el sistema de registro, pero no se pudo releer el "
                      + "resultado. Recargue antes de volver a editar; no lo repita.");

            case ErrorDeDominio.EdicionSinCambios e ->
                new Problema(422, "SIN_CAMBIOS", "La edición no contiene modificaciones");

            case ErrorDeDominio.DecisionEnvioInvalida e ->
                new Problema(400, "DECISION_INVALIDA", e.detalle());

            case ErrorDeDominio.SistemaRegistroNoDisponible e ->
                new Problema(503, "SISTEMA_REGISTRO_NO_DISPONIBLE",
                        "El sistema de cuentas no está disponible en este momento");
        };
    }

    /**
     * El estado en las palabras de la aplicación. Un nombre que no es del enum —no debería
     * llegar ninguno— se enseña tal cual: informa más que un hueco y no tumba la respuesta.
     */
    private static String enPalabras(String estado) {
        return Arrays.stream(EstadoCuenta.values())
                .filter(valor -> valor.name().equals(estado))
                .findFirst()
                .map(EstadoCuenta::enPalabras)
                .orElse(estado);
    }

    private record Problema(int estado, String codigo, String mensaje) {}
}
