package co.sura.auditoria.api.dto;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cuerpo del PATCH /api/v1/cuentas/{codigo}/lineas/{referencia}.
 * {@code modoRecalculo} es obligatorio y sin valor por defecto.
 *
 * <p>Un campo ausente significa «no tocar». Por eso todos los campos editables
 * son opcionales y los límites de longitud son los que publica OHI en la
 * definición {@code claimline} de {@code GET /claimsupdate/definition}: se
 * validan aquí para fallar con un 400 explicativo en vez de con el error del
 * sistema de registro.
 *
 * <p><b>Los datos del afiliado no se aceptan a propósito.</b> OHI sí los deja
 * escribir —{@code person} está en el contrato de {@code /claimsupdate}—, así
 * que la restricción es de negocio y por eso se impone aquí y no solo no
 * pintando el campo: en una ARL la cuenta es de un lesionado y cambiar el
 * afiliado de una línea equivale a readjudicarla bajo otra póliza.
 *
 * <p><b>Convenido sí, autorizado no.</b> El valor y las unidades que se corrigen son los
 * <b>convenidos</b> ({@code valorConvenido} y {@code unidadesConvenidas}), que se escriben en
 * {@code allowedAmount} y {@code allowedNumberOfUnits}. El valor y las unidades
 * <b>autorizados</b> ({@code coveredAmount} y {@code coveredNumberOfUnits}) no se aceptan: no
 * están en el contrato de escritura porque son el resultado del motor de coberturas, y la forma
 * de moverlos es cambiar el convenido y recalcular. Ver más abajo por qué esos nombres no se
 * ignoran sino que se rechazan.
 *
 * <p>Los campos de
 * catálogo (clase de servicio, tipo de sala, vía de acceso, códigos tarifarios,
 * procedimiento, prestador, especialidad) y las listas (diagnósticos y detalles
 * de glosa) quedan fuera por ahora: OHI los acepta, pero exigen escoger de un
 * catálogo o editar filas, y un campo de texto libre dejaría guardar un código
 * inválido.
 */
public record SolicitudGuardarLinea(

        @NotNull(message = "La versión esperada es obligatoria")
        Long versionEsperada,

        // ── importes y cantidades ──────────────────────────────────────────

        // El convenido: se escribe en allowedAmount / allowedNumberOfUnits. Hasta el 2026-10-21
        // estos dos campos se llamaban valorAutorizado / unidadesAutorizadas.
        @PositiveOrZero(message = "El valor convenido no puede ser negativo")
        BigDecimal valorConvenido,

        @PositiveOrZero(message = "Las unidades convenidas no pueden ser negativas")
        BigDecimal unidadesConvenidas,

        @PositiveOrZero(message = "El valor cargado no puede ser negativo")
        BigDecimal valorCargado,

        @PositiveOrZero(message = "Las unidades cargadas no pueden ser negativas")
        BigDecimal unidadesCargadas,

        @PositiveOrZero(message = "El valor glosado no puede ser negativo")
        BigDecimal valorGlosado,

        @Size(max = 1000, message = "Las observaciones de glosa no pueden superar 1000 caracteres")
        String observacionesGlosa,

        // ── atención ───────────────────────────────────────────────────────

        @Size(max = 30, message = "El código de autorización no puede superar 30 caracteres")
        String codigoAutorizacion,

        LocalDate fechaInicio,
        LocalDate fechaFin,

        // ── prestación ─────────────────────────────────────────────────────

        @Size(max = 30, message = "El código no definido no puede superar 30 caracteres")
        String codigoNoDefinido,

        @Size(max = 30, message = "La definición del código no definido no puede superar 30 caracteres")
        String codigoNoDefinidoDef,

        @Size(max = 100, message = "La descripción RIPS no puede superar 100 caracteres")
        String descripcionRips,

        // ── convenio ───────────────────────────────────────────────────────

        @Size(max = 30, message = "El número de contrato no puede superar 30 caracteres")
        String numeroContrato,

        @Size(max = 30, message = "El homólogo CUPS no puede superar 30 caracteres")
        String homologoCups,

        @Size(max = 300, message = "El código único de contrato SIIFA no puede superar 300 caracteres")
        String codigoUnicoContratoSiifa,

        // ── siniestro ──────────────────────────────────────────────────────

        @Size(max = 20, message = "El código de siniestro no puede superar 20 caracteres")
        String codigoSiniestro,

        // ── indicadores ────────────────────────────────────────────────────

        Boolean conservarBeneficios,
        Boolean conservarTarifacion,

        @NotNull(message = "Debe declarar el modo de recálculo")
        @Pattern(regexp = "EN_CASCADA|AISLADO",
                 message = "El modo de recálculo debe ser EN_CASCADA o AISLADO")
        String modoRecalculo
,

        /**
         * Altas y bajas del desglose de glosa. Ausente o vacía = no tocarlo.
         *
         * <p>{@code @Valid} no es decorativo: sin él Jakarta no valida en
         * cascada y los límites de cada elemento no se comprobarían nunca.
         *
         * <p>Si se envían glosas <b>no se puede enviar además {@code valorGlosado}</b>:
         * el total de la línea es la suma de su desglose y lo calcula el servicio.
         */
        @jakarta.validation.Valid
        java.util.List<SolicitudCambioGlosa> glosas,

        /**
         * Altas y bajas de novedades de la línea.
         *
         * <p>{@code @Valid} tampoco es decorativo aquí, por lo mismo.
         *
         * <p>Al contrario que las glosas, <b>no hay ningún campo con el que se
         * pueda contradecir</b>: la novedad no tiene importe, así que no existe
         * un total que cuadrar ni una exclusión que respetar. Y el recálculo es
         * compatible: se comprobó que la novedad puesta a mano sobrevive a él.
         */
        @jakarta.validation.Valid
        java.util.List<SolicitudCambioNovedad> novedades,

        // ── nombres que se rechazan ────────────────────────────────────────
        //
        // Hasta el 2026-10-21 «valorAutorizado» era el nombre con el que se escribía el
        // convenido (allowedAmount); ese día negocio fijó que el autorizado es coveredAmount, y
        // el nombre pasó a significar lo que el motor calcula. Spring no rechaza las propiedades
        // que no conoce: sin estos cuatro campos, un cliente que aún mandara valorAutorizado vería
        // su cambio descartado en silencio, o, si su pantalla ya rotula como «autorizado» el
        // coveredAmount, nadie le avisaría de que el importe no se guarda. Por eso se declaran y
        // se exige que no vengan: la petición entera sale con 400 y un mensaje que lo explica.
        //
        // Son JsonNode y no BigDecimal para que el rechazo dependa de que el nombre venga, no de
        // su valor: con JsonNode un «null» explícito llega como NullNode —no nulo— y también se
        // rechaza, y un texto no se convierte en un error de formato que hable de otra cosa. Un
        // campo ausente sí llega como null, que es lo único que @Null deja pasar.

        @Null(message = "El valor autorizado (coveredAmount) no se puede escribir: lo calcula el "
                + "motor de coberturas. El importe editable es valorConvenido (allowedAmount), que "
                + "hasta el 2026-10-21 se enviaba con el nombre valorAutorizado")
        JsonNode valorAutorizado,

        @Null(message = "Las unidades autorizadas (coveredNumberOfUnits) no se pueden escribir: "
                + "las calcula el motor de coberturas. Las editables son unidadesConvenidas "
                + "(allowedNumberOfUnits), que hasta el 2026-10-21 se enviaban como "
                + "unidadesAutorizadas")
        JsonNode unidadesAutorizadas,

        @Null(message = "valorCubierto ya no existe: el autorizado (coveredAmount) se llama "
                + "valorAutorizado y no se puede escribir. El importe editable es valorConvenido")
        JsonNode valorCubierto,

        @Null(message = "unidadesCubiertas ya no existe: las unidades autorizadas "
                + "(coveredNumberOfUnits) no se pueden escribir. Las editables son "
                + "unidadesConvenidas")
        JsonNode unidadesCubiertas) {}
