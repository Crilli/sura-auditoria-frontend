package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cuerpo del PATCH /api/v1/cuentas/{codigo}/lineas/{referencia}.
 * {@code modoRecalculo} es obligatorio y sin valor por defecto.
 *
 * <p>Un campo ausente significa «no tocar». Por eso todos los campos editables
 * son opcionales y los límites de longitud son los que publica OHI en la
 * definición {@code claimline} de {@code GET /claimsupdate/definition}: se
 * validan aquí para fallar con un 400 explicativo en vez de con el error del
 * sistema de registro.
 *
 * <p><b>Los datos del afiliado no se aceptan a propósito.</b> OHI sí los deja
 * escribir —{@code person} está en el contrato de {@code /claimsupdate}—, así
 * que la restricción es de negocio y por eso se impone aquí y no solo no
 * pintando el campo: en una ARL la cuenta es de un lesionado y cambiar el
 * afiliado de una línea equivale a readjudicarla bajo otra póliza.
 *
 * <p>Tampoco se aceptan <b>el valor y las unidades cubiertas</b>: no están en el
 * contrato de escritura porque son el resultado del motor de coberturas, y la
 * forma de moverlos es cambiar lo autorizado y recalcular. Los campos de
 * catálogo (clase de servicio, tipo de sala, vía de acceso, códigos tarifarios,
 * procedimiento, prestador, especialidad) y las listas (diagnósticos y detalles
 * de glosa) quedan fuera por ahora: OHI los acepta, pero exigen escoger de un
 * catálogo o editar filas, y un campo de texto libre dejaría guardar un código
 * inválido.
 */
public record SolicitudGuardarLinea(

        @NotNull(message = "La versión esperada es obligatoria")
        Long versionEsperada,

        // ── importes y cantidades ──────────────────────────────────────────

        @PositiveOrZero(message = "El valor autorizado no puede ser negativo")
        BigDecimal valorAutorizado,

        @PositiveOrZero(message = "Las unidades autorizadas no pueden ser negativas")
        BigDecimal unidadesAutorizadas,

        @PositiveOrZero(message = "El valor cargado no puede ser negativo")
        BigDecimal valorCargado,

        @PositiveOrZero(message = "Las unidades cargadas no pueden ser negativas")
        BigDecimal unidadesCargadas,

        @PositiveOrZero(message = "El valor glosado no puede ser negativo")
        BigDecimal valorGlosado,

        @Size(max = 1000, message = "Las observaciones de glosa no pueden superar 1000 caracteres")
        String observacionesGlosa,

        // ── atención ───────────────────────────────────────────────────────

        @Size(max = 30, message = "El código de autorización no puede superar 30 caracteres")
        String codigoAutorizacion,

        LocalDate fechaInicio,
        LocalDate fechaFin,

        // ── prestación ─────────────────────────────────────────────────────

        @Size(max = 30, message = "El código no definido no puede superar 30 caracteres")
        String codigoNoDefinido,

        @Size(max = 30, message = "La definición del código no definido no puede superar 30 caracteres")
        String codigoNoDefinidoDef,

        @Size(max = 100, message = "La descripción RIPS no puede superar 100 caracteres")
        String descripcionRips,

        // ── convenio ───────────────────────────────────────────────────────

        @Size(max = 30, message = "El número de contrato no puede superar 30 caracteres")
        String numeroContrato,

        @Size(max = 30, message = "El homólogo CUPS no puede superar 30 caracteres")
        String homologoCups,

        @Size(max = 300, message = "El código único de contrato SIIFA no puede superar 300 caracteres")
        String codigoUnicoContratoSiifa,

        // ── siniestro ──────────────────────────────────────────────────────

        @Size(max = 20, message = "El código de siniestro no puede superar 20 caracteres")
        String codigoSiniestro,

        // ── indicadores ────────────────────────────────────────────────────

        Boolean conservarBeneficios,
        Boolean conservarTarifacion,

        @NotNull(message = "Debe declarar el modo de recálculo")
        @Pattern(regexp = "EN_CASCADA|AISLADO",
                 message = "El modo de recálculo debe ser EN_CASCADA o AISLADO")
        String modoRecalculo
,

        /**
         * Altas y bajas del desglose de glosa. Ausente o vacía = no tocarlo.
         *
         * <p>{@code @Valid} no es decorativo: sin él Jakarta no valida en
         * cascada y los límites de cada elemento no se comprobarían nunca.
         *
         * <p>Si se envían glosas <b>no se puede enviar además {@code valorGlosado}</b>:
         * el total de la línea es la suma de su desglose y lo calcula el servicio.
         */
        @jakarta.validation.Valid
        java.util.List<SolicitudCambioGlosa> glosas,

        /**
         * Altas y bajas de novedades de la línea.
         *
         * <p>{@code @Valid} tampoco es decorativo aquí, por lo mismo.
         *
         * <p>Al contrario que las glosas, <b>no hay ningún campo con el que se
         * pueda contradecir</b>: la novedad no tiene importe, así que no existe
         * un total que cuadrar ni una exclusión que respetar. Y el recálculo es
         * compatible: se comprobó que la novedad puesta a mano sobrevive a él.
         */
        @jakarta.validation.Valid
        java.util.List<SolicitudCambioNovedad> novedades) {}
