package co.sura.auditoria.api.dto;

/** Novedad adjunta a una línea. */
public record RespuestaNovedades(long id, String codigo, String descripcion,
                                 String severidad, String origen) {}
