package co.sura.auditoria.api.dto;

import java.time.Instant;

/**
 * Un hito de la historia de la cuenta.
 *
 * @param tipo           CAMBIO_DE_ESTADO o DESFINALIZACION
 * @param etiqueta       el estado, o el código del motivo de la desfinalización
 * @param detalle        el texto del motivo; {@code null} en un cambio de estado
 * @param loHizoElSistema para que la pantalla pueda separar lo que movió el motor de lo que
 *                        movió una persona sin tener que conocer el literal del sistema de
 *                        registro («Internal System User»)
 */
public record RespuestaHito(String tipo, String etiqueta, String detalle,
                            String autor, boolean loHizoElSistema, Instant ocurridoEn) {}
