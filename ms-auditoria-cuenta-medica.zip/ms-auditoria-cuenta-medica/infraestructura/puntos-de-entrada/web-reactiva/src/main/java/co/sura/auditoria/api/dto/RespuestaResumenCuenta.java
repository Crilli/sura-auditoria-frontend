package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Una cuenta médica en la lista de resultados del buscador.
 *
 * @param estado          ya traducido al vocabulario del auditor, o el literal del sistema de
 *                        registro si el diccionario no lo conoce: en una lista, un nombre feo
 *                        informa y «DESCONOCIDO» no
 * @param prestadorNombre razón social; va junto al NIT y no en su lugar
 * @param versiones       las versiones de negocio de esta cuenta. Vacío cuando todavía no se
 *                        ha transmitido, que no es lo mismo que no haberse podido consultar
 */
public record RespuestaResumenCuenta(String codigo,
                                     String numeroFactura,
                                     LocalDate fechaRadicacion,
                                     String prestadorNit,
                                     String prestadorNombre,
                                     BigDecimal valorFactura,
                                     String estado,
                                     List<RespuestaVersionCuenta> versiones) {

    /**
     * Una versión de negocio.
     *
     * <p><b>No</b> es el contador de bloqueo optimista que la cabecera llama «Versión»: esta
     * es la versión del documento transmitido, la que nace cada vez que la cuenta se
     * desfinaliza y vuelve a cerrarse.
     *
     * @param estado el de la versión, con el mismo nombre del dominio que el de la cuenta viva
     *               (FINALIZADA, ADJUDICACION_MANUAL…) o la palabra del histórico tal cual si no
     *               se conoce. El histórico solo guarda versiones finalizadas: la que una cuenta
     *               reabierta está trabajando no viene aquí
     */
    public record RespuestaVersionCuenta(int numero, LocalDate fechaEntrada,
                                         BigDecimal valor, String estado,
                                         java.time.Instant estadoDesde) {}
}
