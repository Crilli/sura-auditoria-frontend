package co.sura.auditoria.api.dto;

/**
 * Un mensaje del catálogo, de los que el auditor puede poner como novedad.
 *
 * <p><b>No lleva el identificador interno del sistema de registro</b>, a
 * propósito: es distinto en cada entorno —el mismo código {@code TA0401} es un
 * número en pruebas y otro en producción— así que publicarlo invitaría a
 * guardarlo en el navegador y a que un alta dejara de funcionar al cambiar de
 * entorno. El código basta, y se comprobó que el sistema de registro resuelve la
 * referencia por código igual que por identificador.
 *
 * @param codigo     el que el auditor reconoce y cita la normativa
 * @param texto      la redacción que acabará leyendo el prestador
 * @param severidad  la que el catálogo asigna al código; no se elige
 * @param frenaLaCuenta si al ponerla la cuenta deja de poder avanzar. Derivado de
 *                      la severidad y publicado aparte para que la interfaz no
 *                      tenga que saberse el vocabulario
 * @param esDelSistema lo que el sistema de registro rotula «Específico de
 *                     Sistema?». Siempre falso en lo que se ofrece —ese es el
 *                     filtro— pero se publica porque es una de las columnas que
 *                     el auditor reconoce de la pantalla del sistema de registro
 * @param datosQuePide los huecos del texto que hay que rellenar para poder usar
 *                     este mensaje, por índice y en el orden en que aparecen.
 *                     <b>No son correlativos</b>: hay plantillas que usan el 1 y
 *                     el 2 sin usar el 0. Vacío en 631 de los 696
 * @param generico   clasificación normativa de primer nivel; puede faltar
 * @param especifico de segundo nivel; puede faltar
 */
public record RespuestaMensajeCatalogo(String codigo,
                                       String texto,
                                       String severidad,
                                       boolean frenaLaCuenta,
                                       boolean esDelSistema,
                                       java.util.List<Integer> datosQuePide,
                                       RespuestaNovedad.Clasificacion generico,
                                       RespuestaNovedad.Clasificacion especifico) {}
