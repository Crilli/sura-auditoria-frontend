package co.sura.auditoria.api.dto;

/**
 * Un motivo distinto de los pendientes de la cuenta, para poblar el filtro.
 *
 * <p>No lleva «total» además de {@code sinResolver} porque el listado ya solo
 * trata con pendientes sin resolver: los resueltos no se pintan ni se cuentan,
 * y publicar un segundo número que siempre coincide invita a leerlo mal.
 */
public record RespuestaResumenMotivo(
        String codigo,
        String descripcion,
        int sinResolver,
        /** Líneas distintas afectadas. {@code 0} si el motivo es solo de cabecera. */
        int lineasAfectadas,
        boolean enCabecera,
        /** El {@code adjudicationOnly} del catálogo de OHI: el porqué del siguiente. */
        boolean soloAdjudicacion,
        /** Si los pendientes de este motivo impiden enviar la cuenta hoy. */
        boolean bloqueante
) {}
