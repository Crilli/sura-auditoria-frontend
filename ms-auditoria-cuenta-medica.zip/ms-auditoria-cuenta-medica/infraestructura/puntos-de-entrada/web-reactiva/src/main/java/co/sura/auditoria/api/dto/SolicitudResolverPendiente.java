package co.sura.auditoria.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Cuerpo del POST /api/v1/cuentas/{codigo}/pendientes/{motivo}/resolver. */
public record SolicitudResolverPendiente(
        @NotBlank(message = "La justificación es obligatoria")
        @Size(max = 2000, message = "La justificación no puede superar los 2000 caracteres")
        String justificacion,

        @NotNull
        @Pattern(regexp = "CUENTA_Y_LINEAS|SOLO_LINEAS",
                 message = "El alcance debe ser CUENTA_Y_LINEAS o SOLO_LINEAS")
        String alcance
) {}
