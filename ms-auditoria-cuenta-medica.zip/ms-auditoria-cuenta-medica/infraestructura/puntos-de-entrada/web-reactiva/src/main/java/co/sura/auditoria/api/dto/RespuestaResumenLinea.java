package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.util.List;

/** Resumen de línea en la grilla. */
public record RespuestaResumenLinea(
        long referencia,
        int numeroLinea,
        String codigoProcedimiento,
        /** Texto de la prestación; {@code null} si el código no está en el catálogo de OHI. */
        String descripcionProcedimiento,
        /** Catálogo del código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si no se pudo resolver contra el padrón. */
        String nombreAfiliado,
        BigDecimal valorAutorizado,
        BigDecimal valorCubierto,
        boolean editable,
        int cantidadPendientes,
        /** Motivos pendientes sin resolver, con su texto, para explicar el contador. */
        List<RespuestaMotivoPendiente> pendientes,
        boolean tieneNovedadBloqueante,
        long version
) {}
