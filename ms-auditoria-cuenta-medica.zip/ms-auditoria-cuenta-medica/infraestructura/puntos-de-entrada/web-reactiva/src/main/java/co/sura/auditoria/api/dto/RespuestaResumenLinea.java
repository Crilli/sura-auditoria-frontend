package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Resumen de línea en la grilla. */
public record RespuestaResumenLinea(
        long referencia,
        int numeroLinea,
        String codigoProcedimiento,
        /** Texto de la prestación; {@code null} si el código no está en el catálogo de OHI. */
        String descripcionProcedimiento,
        /** Catálogo del código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si no se pudo resolver contra el padrón. */
        String nombreAfiliado,
        /**
         * Fechas de atención de la línea.
         *
         * <p>Ya venían del sistema de registro y las tenía el dominio, pero este
         * DTO no las publicaba: se perdían en la frontera. Suben ahora porque son
         * criterio de búsqueda, y filtrar por una fecha que no se puede ver deja
         * al auditor sin saber por qué una fila salió.
         */
        LocalDate fechaInicio,
        LocalDate fechaFin,
        /** Código de autorización; {@code null} si la línea no lo trae. */
        String codigoAutorizacion,
        BigDecimal valorAutorizado,
        BigDecimal valorCubierto,
        /** Valor glosado; {@code null} si la línea no tiene glosa. */
        BigDecimal valorGlosado,
        boolean editable,
        int cantidadPendientes,
        /** Motivos pendientes sin resolver, con su texto, para explicar el contador. */
        List<RespuestaMotivoPendiente> pendientes,
        boolean tieneNovedadBloqueante,
        long version
) {}
