package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Resumen de línea en la grilla. */
public record RespuestaResumenLinea(
        long referencia,
        int numeroLinea,
        String codigoProcedimiento,
        /** Texto de la prestación; {@code null} si el código no está en el catálogo de OHI. */
        String descripcionProcedimiento,
        /** Catálogo del código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si no se pudo resolver contra el padrón. */
        String nombreAfiliado,
        /**
         * Fechas de atención de la línea.
         *
         * <p>Ya venían del sistema de registro y las tenía el dominio, pero este
         * DTO no las publicaba: se perdían en la frontera. Suben ahora porque son
         * criterio de búsqueda, y filtrar por una fecha que no se puede ver deja
         * al auditor sin saber por qué una fila salió.
         */
        LocalDate fechaInicio,
        LocalDate fechaFin,
        /** Código de autorización; {@code null} si la línea no lo trae. */
        String codigoAutorizacion,
        /**
         * Valor convenido ({@code allowedAmount}, GRID-10); el que se edita en la fila. Hasta el
         * 2026-10-21 viajaba con el nombre {@code valorAutorizado}. {@code null} si no viene.
         */
        BigDecimal valorConvenido,
        /**
         * Valor autorizado ({@code coveredAmount}, GRID-12); solo lectura. Hasta el 2026-10-21
         * viajaba como {@code valorCubierto}: el mismo nombre que hoy lleva otro importe, por eso
         * un cliente que no se haya actualizado pinta cifras cruzadas y no un error.
         */
        BigDecimal valorAutorizado,
        /** Valor glosado; {@code null} si la línea no tiene glosa. */
        BigDecimal valorGlosado,
        boolean editable,
        int cantidadPendientes,
        /** Motivos pendientes sin resolver, con su texto, para explicar el contador. */
        List<RespuestaMotivoPendiente> pendientes,
        boolean tieneNovedadBloqueante,
        /**
         * Las novedades de la línea, con su texto, para explicar el chip.
         *
         * <p>Antes la grilla solo recibía {@code tieneNovedadBloqueante} y pintaba «⚠ Bloqueada»
         * con un tooltip fijo que no decía ni qué campo ni por qué; el detalle solo se veía
         * abriendo la línea. El dato ya viajaba en la misma petición y se descartaba.
         */
        List<RespuestaNovedad> novedades,
        long version,

        // Lo que la grilla del MVP pide ver sin abrir la línea.
        BigDecimal valorCargado,
        BigDecimal unidadesCargadas,
        /** Cantidad convenida ({@code allowedNumberOfUnits}, GRID-11). */
        BigDecimal unidadesConvenidas,
        BigDecimal valorIva,
        BigDecimal porcentajeIva,
        /**
         * Cantidad autorizada ({@code coveredNumberOfUnits}, GRID-13). Nueva el 2026-10-21: antes
         * la grilla no la traía. Al final, como en {@code ResumenLinea}, para no correr posiciones.
         */
        BigDecimal unidadesAutorizadas
) {}
