package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.RespuestaCuenta;
import co.sura.auditoria.api.dto.RespuestaEstadoProceso;
import co.sura.auditoria.api.dto.RespuestaTiquete;
import co.sura.auditoria.api.dto.SolicitudEnviarCuenta;
import co.sura.auditoria.api.dto.SolicitudNovedadesCuenta;
import co.sura.auditoria.api.dto.SolicitudAccion;
import co.sura.auditoria.api.mapeo.MapeadorCuenta;
import co.sura.auditoria.api.mapeo.MapeadorLinea;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarAccionesCasoDeUso;
import co.sura.auditoria.casodeuso.ConsultarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EnviarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarNovedadesDeCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso;
import co.sura.auditoria.casodeuso.SeguirProcesoCasoDeUso;
import co.sura.auditoria.api.dto.RespuestaFotoVersion;
import co.sura.auditoria.api.dto.RespuestaHito;
import co.sura.auditoria.api.dto.RespuestaResumenCuenta;
import co.sura.auditoria.casodeuso.ConsultarHistoriaCasoDeUso;
import co.sura.auditoria.casodeuso.BuscarCuentasCasoDeUso;
import co.sura.auditoria.modelo.cuenta.FiltroCuentas;
import co.sura.auditoria.modelo.cuenta.ResumenCuenta;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones de cabecera de la cuenta médica.
 */
@Component
public class ManejadorCuentas {

    private final ConsultarCuentaCasoDeUso   consultar;
    private final ConsultarAccionesCasoDeUso consultarAcciones;
    private final EnviarCuentaCasoDeUso    enviar;
    private final SeguirProcesoCasoDeUso   seguir;
    private final GuardarNovedadesDeCuentaCasoDeUso guardarNovedades;
    private final EjecutarAccionCasoDeUso  ejecutarAccion;
    private final ConsultarHistoriaCasoDeUso historia;
    private final BuscarCuentasCasoDeUso     buscar;
    private final ValidadorSolicitudes     validador;

    public ManejadorCuentas(ConsultarCuentaCasoDeUso consultar,
                            ConsultarAccionesCasoDeUso consultarAcciones,
                            EnviarCuentaCasoDeUso enviar,
                            SeguirProcesoCasoDeUso seguir,
                            GuardarNovedadesDeCuentaCasoDeUso guardarNovedades,
                            EjecutarAccionCasoDeUso ejecutarAccion,
                            ConsultarHistoriaCasoDeUso historia,
                            BuscarCuentasCasoDeUso buscar,
                            ValidadorSolicitudes validador) {
        this.consultar = consultar;
        this.consultarAcciones = consultarAcciones;
        this.enviar    = enviar;
        this.seguir    = seguir;
        this.guardarNovedades = guardarNovedades;
        this.ejecutarAccion = ejecutarAccion;
        this.historia  = historia;
        this.buscar    = buscar;
        this.validador = validador;
    }

    public Mono<ServerResponse> consultarCuenta(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return consultar.ejecutar(codigo)
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * Acciones disponibles, en su propia petición.
     *
     * <p>La interfaz la lanza en paralelo con la de cabecera: esta tarda un orden de
     * magnitud más porque el sistema de registro solo publica las capacidades en la
     * representación completa de la cuenta.
     */
    public Mono<ServerResponse> consultarAccionesDisponibles(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return consultarAcciones.ejecutar(codigo)
                .map(acciones -> MapeadorCuenta.aRespuesta(codigo, acciones))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * PATCH /api/v1/cuentas/{codigo}/novedades
     *
     * <p>Agrega y quita novedades de la <b>cabecera</b>. Ruta propia y no un
     * «guardar cuenta»: en la cabecera la novedad es lo único editable, y un
     * guardado genérico prometería una edición que no existe.
     *
     * <p>Devuelve la cuenta releída, con sus novedades ya actualizadas, para que
     * la pantalla no tenga que volver a pedirla.
     */
    public Mono<ServerResponse> guardarNovedades(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudNovedadesCuenta.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> guardarNovedades.ejecutar(
                        codigo,
                        new Version(dto.versionEsperada()),
                        MapeadorLinea.aCambiosDeNovedadPublico(dto.novedades()),
                        autor))
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * POST /api/v1/cuentas/{codigo}/acciones/{accion}
     *
     * <p>Ejecuta una de las acciones que el sistema de registro habilita.
     * {@code accion} es el nombre del dominio —{@code ANULAR},
     * {@code DEVOLVER_A_MODIFICACION}…— y no el de OHI: la traducción vive en
     * la capa de integración, como el resto del vocabulario.
     *
     * <p>El cuerpo es opcional: seis de las nueve no llevan nada.
     */
    public Mono<ServerResponse> ejecutarAccion(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        final AccionCuenta accion;
        try {
            accion = AccionCuenta.valueOf(solicitud.pathVariable("accion").toUpperCase());
        } catch (IllegalArgumentException e) {
            return Mono.error(new IllegalArgumentException(
                    "No existe la acción '" + solicitud.pathVariable("accion") + "'"));
        }

        return solicitud.bodyToMono(SolicitudAccion.class)
                .defaultIfEmpty(new SolicitudAccion(null, null, null, null))
                .doOnNext(validador::validar)
                .map(dto -> new EjecucionAccion(accion, dto.motivos(), dto.referencia(),
                                                dto.lineas(), dto.codigoMensajeAnulacion()))
                .flatMap(ejecucion -> ejecutarAccion.ejecutar(codigo, ejecucion, autor))
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> enviarCuenta(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudEnviarCuenta.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .map(MapeadorCuenta::aDecisionEnvio)
                .flatMap(decision -> enviar.ejecutar(codigo, decision, autor))
                .map(t -> new RespuestaTiquete(t.codigoCuenta().valor(), t.referenciaSeguimiento()))
                .flatMap(cuerpo -> ServerResponse.accepted()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/cuentas?factura=&amp;radicado=&amp;pagina=0&amp;tamano=25
     *
     * <p>El buscador. Devuelve la página con su total y, debajo de cada cuenta, sus versiones
     * de negocio: la pantalla las despliega sin pedir nada más.
     *
     * <p>Las versiones se piden <b>en una sola consulta para toda la página</b>, no una por
     * fila. Y van en la misma respuesta porque es el caso normal —el auditor busca una factura
     * precisamente para ver cuántas veces se radicó y en qué versión va cada una—.
     *
     * <p>Sin criterio responde <b>400</b>: una búsqueda vacía devolvería el sistema entero
     * paginado, que cuesta lo mismo que una útil y no es lo que nadie pidió.
     */
    public Mono<ServerResponse> buscarCuentas(ServerRequest solicitud) {
        var filtro = new FiltroCuentas(
                solicitud.queryParam("factura").orElse(null),
                solicitud.queryParam("radicado").orElse(null));
        var pagina = solicitud.queryParam("pagina").map(Integer::parseInt).orElse(0);
        var tamano = solicitud.queryParam("tamano").map(Integer::parseInt).orElse(null);
        var porPagina = tamano == null ? BuscarCuentasCasoDeUso.TAMANO_PAGINA_PREDETERMINADO : tamano;

        return buscar.ejecutar(filtro, Math.max(0, pagina) * porPagina, tamano)
                .flatMap(p -> buscar.versionesDe(
                                p.elementos().stream().map(ResumenCuenta::codigo).toList())
                        .map(versiones -> MapeadorCuenta.aRespuestaBusqueda(p, versiones)))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/cuentas/{codigo}/versiones
     *
     * <p>Las versiones de negocio de la cuenta, de la más reciente a la más antigua: la primera
     * es la vigente. Va en su propia petición, igual que las acciones, para que la cabecera no
     * espere al histórico —la pantalla la lanza en paralelo—.
     *
     * <p>Lista vacía si la cuenta todavía no se ha transmitido: eso es una respuesta, no un
     * error.
     */
    public Mono<ServerResponse> consultarVersiones(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));

        return buscar.versionesDe(java.util.List.of(codigo))
                .map(porCodigo -> porCodigo.getOrDefault(codigo.valor(), java.util.List.of())
                        .stream()
                        .sorted(java.util.Comparator.comparingInt(
                                co.sura.auditoria.modelo.cuenta.VersionCuenta::numero).reversed())
                        .map(v -> new RespuestaResumenCuenta.RespuestaVersionCuenta(
                                v.numero(), v.fechaEntrada(), v.valor(), v.estado(), v.estadoDesde()))
                        .toList())
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/cuentas/{codigo}/versiones/{numero}
     *
     * <p>La foto de una versión. No es la cuenta viva: sus importes son los de cuando se
     * transmitió esa versión.
     */
    public Mono<ServerResponse> consultarVersion(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var numero = Integer.parseInt(solicitud.pathVariable("numero"));

        return buscar.fotoDeVersion(codigo, numero)
                .map(f -> new RespuestaFotoVersion(
                        f.codigo().valor(), f.numero(), f.fechaEntrada(), f.numeroFactura(),
                        f.prestador(), f.valorFactura(), f.totalCargado(), f.totalAutorizado(),
                        f.totalCubierto(), f.totalGlosado(), f.totalNotasCredito(),
                        f.estadoActual(),
                        f.historial().stream()
                                .map(e -> new RespuestaFotoVersion.Estado(e.estado(), e.desde()))
                                .toList()))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/cuentas/{codigo}/historia
     *
     * <p>Por dónde ha pasado la cuenta: sus cambios de estado y sus desfinalizaciones con el
     * motivo. <b>No es la pestaña de seguimiento</b>, que está justo debajo y es otra cosa:
     * aquélla dice si el envío asíncrono terminó, ésta por dónde ha pasado la cuenta.
     *
     * <p>Responde 200 con lista vacía si no hay historia: que una cuenta no se haya movido es
     * una respuesta, no un error.
     */
    public Mono<ServerResponse> consultarHistoria(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));

        return historia.ejecutar(codigo)
                .map(h -> new RespuestaHito(
                        h.tipo().name(), h.etiqueta(), h.detalle(),
                        h.autor(), h.loHizoElSistema(), h.ocurridoEn()))
                .collectList()
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> consultarProceso(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return seguir.consultarUnaVez(codigo)
                .map(ep -> new RespuestaEstadoProceso(ep.avance().name(), ep.finalizado(), ep.errores()))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> transmitirProceso(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var flujo  = seguir.transmitir(codigo)
                .map(ep -> new RespuestaEstadoProceso(ep.avance().name(), ep.finalizado(), ep.errores()));

        return ServerResponse.ok()
                .contentType(MediaType.TEXT_EVENT_STREAM)
                .body(flujo, RespuestaEstadoProceso.class);
    }
}
