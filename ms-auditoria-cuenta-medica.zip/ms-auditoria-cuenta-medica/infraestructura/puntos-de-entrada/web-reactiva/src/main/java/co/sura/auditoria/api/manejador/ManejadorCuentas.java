package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.RespuestaCuenta;
import co.sura.auditoria.api.dto.RespuestaEstadoProceso;
import co.sura.auditoria.api.dto.RespuestaTiquete;
import co.sura.auditoria.api.dto.SolicitudEnviarCuenta;
import co.sura.auditoria.api.dto.SolicitudNovedadesCuenta;
import co.sura.auditoria.api.dto.SolicitudAccion;
import co.sura.auditoria.api.mapeo.MapeadorCuenta;
import co.sura.auditoria.api.mapeo.MapeadorLinea;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarAccionesCasoDeUso;
import co.sura.auditoria.casodeuso.ConsultarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EnviarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarNovedadesDeCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EjecutarAccionCasoDeUso;
import co.sura.auditoria.casodeuso.SeguirProcesoCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones de cabecera de la cuenta médica.
 */
@Component
public class ManejadorCuentas {

    private final ConsultarCuentaCasoDeUso   consultar;
    private final ConsultarAccionesCasoDeUso consultarAcciones;
    private final EnviarCuentaCasoDeUso    enviar;
    private final SeguirProcesoCasoDeUso   seguir;
    private final GuardarNovedadesDeCuentaCasoDeUso guardarNovedades;
    private final EjecutarAccionCasoDeUso  ejecutarAccion;
    private final ValidadorSolicitudes     validador;

    public ManejadorCuentas(ConsultarCuentaCasoDeUso consultar,
                            ConsultarAccionesCasoDeUso consultarAcciones,
                            EnviarCuentaCasoDeUso enviar,
                            SeguirProcesoCasoDeUso seguir,
                            GuardarNovedadesDeCuentaCasoDeUso guardarNovedades,
                            EjecutarAccionCasoDeUso ejecutarAccion,
                            ValidadorSolicitudes validador) {
        this.consultar = consultar;
        this.consultarAcciones = consultarAcciones;
        this.enviar    = enviar;
        this.seguir    = seguir;
        this.guardarNovedades = guardarNovedades;
        this.ejecutarAccion = ejecutarAccion;
        this.validador = validador;
    }

    public Mono<ServerResponse> consultarCuenta(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return consultar.ejecutar(codigo)
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * Acciones disponibles, en su propia petición.
     *
     * <p>La interfaz la lanza en paralelo con la de cabecera: esta tarda un orden de
     * magnitud más porque el sistema de registro solo publica las capacidades en la
     * representación completa de la cuenta.
     */
    public Mono<ServerResponse> consultarAccionesDisponibles(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return consultarAcciones.ejecutar(codigo)
                .map(acciones -> MapeadorCuenta.aRespuesta(codigo, acciones))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * PATCH /api/v1/cuentas/{codigo}/novedades
     *
     * <p>Agrega y quita novedades de la <b>cabecera</b>. Ruta propia y no un
     * «guardar cuenta»: en la cabecera la novedad es lo único editable, y un
     * guardado genérico prometería una edición que no existe.
     *
     * <p>Devuelve la cuenta releída, con sus novedades ya actualizadas, para que
     * la pantalla no tenga que volver a pedirla.
     */
    public Mono<ServerResponse> guardarNovedades(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudNovedadesCuenta.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> guardarNovedades.ejecutar(
                        codigo,
                        new Version(dto.versionEsperada()),
                        MapeadorLinea.aCambiosDeNovedadPublico(dto.novedades()),
                        autor))
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * POST /api/v1/cuentas/{codigo}/acciones/{accion}
     *
     * <p>Ejecuta una de las acciones que el sistema de registro habilita.
     * {@code accion} es el nombre del dominio —{@code ANULAR},
     * {@code DEVOLVER_A_MODIFICACION}…— y no el de OHI: la traducción vive en
     * la capa de integración, como el resto del vocabulario.
     *
     * <p>El cuerpo es opcional: seis de las nueve no llevan nada.
     */
    public Mono<ServerResponse> ejecutarAccion(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        final AccionCuenta accion;
        try {
            accion = AccionCuenta.valueOf(solicitud.pathVariable("accion").toUpperCase());
        } catch (IllegalArgumentException e) {
            return Mono.error(new IllegalArgumentException(
                    "No existe la acción '" + solicitud.pathVariable("accion") + "'"));
        }

        return solicitud.bodyToMono(SolicitudAccion.class)
                .defaultIfEmpty(new SolicitudAccion(null, null, null, null))
                .doOnNext(validador::validar)
                .map(dto -> new EjecucionAccion(accion, dto.motivos(), dto.referencia(),
                                                dto.lineas(), dto.codigoMensajeAnulacion()))
                .flatMap(ejecucion -> ejecutarAccion.ejecutar(codigo, ejecucion, autor))
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> enviarCuenta(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudEnviarCuenta.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .map(MapeadorCuenta::aDecisionEnvio)
                .flatMap(decision -> enviar.ejecutar(codigo, decision, autor))
                .map(t -> new RespuestaTiquete(t.codigoCuenta().valor(), t.referenciaSeguimiento()))
                .flatMap(cuerpo -> ServerResponse.accepted()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> consultarProceso(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return seguir.consultarUnaVez(codigo)
                .map(ep -> new RespuestaEstadoProceso(ep.avance().name(), ep.finalizado(), ep.errores()))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> transmitirProceso(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var flujo  = seguir.transmitir(codigo)
                .map(ep -> new RespuestaEstadoProceso(ep.avance().name(), ep.finalizado(), ep.errores()));

        return ServerResponse.ok()
                .contentType(MediaType.TEXT_EVENT_STREAM)
                .body(flujo, RespuestaEstadoProceso.class);
    }
}
