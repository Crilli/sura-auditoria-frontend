package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.RespuestaCuenta;
import co.sura.auditoria.api.dto.RespuestaEstadoProceso;
import co.sura.auditoria.api.dto.RespuestaTiquete;
import co.sura.auditoria.api.dto.SolicitudEnviarCuenta;
import co.sura.auditoria.api.mapeo.MapeadorCuenta;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarAccionesCasoDeUso;
import co.sura.auditoria.casodeuso.ConsultarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.EnviarCuentaCasoDeUso;
import co.sura.auditoria.casodeuso.SeguirProcesoCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones de cabecera de la cuenta médica.
 */
@Component
public class ManejadorCuentas {

    private final ConsultarCuentaCasoDeUso   consultar;
    private final ConsultarAccionesCasoDeUso consultarAcciones;
    private final EnviarCuentaCasoDeUso    enviar;
    private final SeguirProcesoCasoDeUso   seguir;
    private final ValidadorSolicitudes     validador;

    public ManejadorCuentas(ConsultarCuentaCasoDeUso consultar,
                            ConsultarAccionesCasoDeUso consultarAcciones,
                            EnviarCuentaCasoDeUso enviar,
                            SeguirProcesoCasoDeUso seguir,
                            ValidadorSolicitudes validador) {
        this.consultar = consultar;
        this.consultarAcciones = consultarAcciones;
        this.enviar    = enviar;
        this.seguir    = seguir;
        this.validador = validador;
    }

    public Mono<ServerResponse> consultarCuenta(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return consultar.ejecutar(codigo)
                .map(MapeadorCuenta::aRespuesta)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * Acciones disponibles, en su propia petición.
     *
     * <p>La interfaz la lanza en paralelo con la de cabecera: esta tarda un orden de
     * magnitud más porque el sistema de registro solo publica las capacidades en la
     * representación completa de la cuenta.
     */
    public Mono<ServerResponse> consultarAccionesDisponibles(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return consultarAcciones.ejecutar(codigo)
                .map(acciones -> MapeadorCuenta.aRespuesta(codigo, acciones))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> enviarCuenta(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudEnviarCuenta.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .map(MapeadorCuenta::aDecisionEnvio)
                .flatMap(decision -> enviar.ejecutar(codigo, decision, autor))
                .map(t -> new RespuestaTiquete(t.codigoCuenta().valor(), t.referenciaSeguimiento()))
                .flatMap(cuerpo -> ServerResponse.accepted()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> consultarProceso(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        return seguir.consultarUnaVez(codigo)
                .map(ep -> new RespuestaEstadoProceso(ep.avance().name(), ep.finalizado(), ep.errores()))
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    public Mono<ServerResponse> transmitirProceso(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var flujo  = seguir.transmitir(codigo)
                .map(ep -> new RespuestaEstadoProceso(ep.avance().name(), ep.finalizado(), ep.errores()));

        return ServerResponse.ok()
                .contentType(MediaType.TEXT_EVENT_STREAM)
                .body(flujo, RespuestaEstadoProceso.class);
    }
}
