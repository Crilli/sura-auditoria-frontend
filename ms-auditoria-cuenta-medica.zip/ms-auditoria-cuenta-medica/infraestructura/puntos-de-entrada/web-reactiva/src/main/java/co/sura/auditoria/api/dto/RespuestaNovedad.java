package co.sura.auditoria.api.dto;

import java.time.Instant;

/**
 * Una novedad adjunta a una línea.
 *
 * <p>Se llamaba {@code RespuestaNovedades}, en plural, representando una sola.
 * Al ampliarlo se renombró en singular, como el resto de los DTO de respuesta.
 *
 * @param descripcion el texto <b>ya resuelto</b>: la plantilla con sus huecos
 *        rellenos. Es lo que se lee y lo que lee el prestador
 * @param plantilla el texto del catálogo tal cual, con los huecos sin rellenar.
 *        Va aparte del resuelto porque es lo que permite a la pantalla enseñar
 *        qué hueco completa cada dato. El sistema de registro <b>solo</b> da
 *        esto: no resuelve nada, devuelve la plantilla y los valores por
 *        separado
 * @param valores los datos que rellenan los huecos, por índice. Vacío en la
 *        mayoría: solo 65 de los 696 mensajes piden alguno
 * @param esDelSistema lo que el sistema de registro rotula «Específico de
 *        Sistema?»: si el mensaje es de los que levanta su motor por cuestiones
 *        técnicas. Es del catálogo, no de esta novedad
 * @param laPusoUnaPersona si la puso un auditor y no el motor de reglas. Se
 *        publica <b>derivado y no se deja deducir del origen en el navegador</b>:
 *        de esto depende que la interfaz ofrezca quitarla, y el criterio tiene
 *        que ser el mismo que aplica el servicio al rechazar la baja
 * @param generico   clasificación normativa de primer nivel; {@code null} si el
 *                   mensaje no la trae, que pasa a menudo
 * @param especifico de segundo nivel, igual de opcional
 * @param autor      quién la puso. {@code null} en las que no lo publican
 * @param fecha      cuándo se puso
 */
public record RespuestaNovedad(long id,
                               String codigo,
                               String descripcion,
                               String plantilla,
                               java.util.Map<Integer, String> valores,
                               String severidad,
                               String origen,
                               boolean laPusoUnaPersona,
                               boolean esDelSistema,
                               Clasificacion generico,
                               Clasificacion especifico,
                               String autor,
                               Instant fecha) {

    /**
     * Una clasificación normativa: el código y cómo se lee.
     *
     * <p>Van los dos y no solo el texto porque en el catálogo conviven dos
     * sistemas de codificación con descripciones repetidas entre ellos
     * —{@code TA · TARIFAS} junto a {@code 2 · Tarifas} y {@code 23 · Tarifas}—,
     * así que agrupar por descripción juntaría lo que no es lo mismo.
     */
    public record Clasificacion(String codigo, String descripcion) {}
}
