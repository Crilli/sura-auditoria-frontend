package co.sura.auditoria.api.error;

import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import java.util.Map;
import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.*;
import reactor.core.publisher.Mono;

/**
 * Responde los errores siempre en JSON.
 *
 * <p>El manejador que trae Spring Boot decide el formato según el {@code Accept} de la
 * solicitud: si el cliente acepta {@code text/html} —un navegador, por ejemplo— intenta
 * pintar una vista de error y termina mostrando la página de respaldo
 * («This application has no configured error view»). Este servicio es un API: el
 * contrato de error es el mismo para todos los clientes.
 *
 * <p>Se registra con orden {@code -2} para anteponerse al
 * {@code DefaultErrorWebExceptionHandler}, que usa {@code -1}.
 */
@Component
@Order(-2)
public class ManejadorErroresJson extends AbstractErrorWebExceptionHandler {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ManejadorErroresJson.class);

    /** Dónde queda el cuerpo del error para que el log use el mismo código e idTraza. */
    private static final String CUERPO = ManejadorErroresJson.class.getName() + ".cuerpo";

    public ManejadorErroresJson(AtributosErrorGlobal atributos,
                                ApplicationContext contexto,
                                ServerCodecConfigurer codecs) {
        // No servimos páginas de error estáticas: basta con los valores por omisión.
        super(atributos, new WebProperties.Resources(), contexto);
        setMessageWriters(codecs.getWriters());
        setMessageReaders(codecs.getReaders());
    }

    @Override
    protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes atributos) {
        return RouterFunctions.route(RequestPredicates.all(), this::responder);
    }

    private Mono<ServerResponse> responder(ServerRequest solicitud) {
        var cuerpo = getErrorAttributes(solicitud, ErrorAttributeOptions.defaults());
        int estado = cuerpo.get("status") instanceof Integer valor ? valor : 500;
        solicitud.attributes().put(CUERPO, cuerpo);

        return ServerResponse.status(estado)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(cuerpo);
    }

    /**
     * Deja rastro de los 5xx (OPE-05).
     *
     * <p>El de Spring Boot solo escribe los 500. Los 503 —circuito abierto, pool lleno,
     * timeout, OHI caído— salían sin una sola línea, y una tormenta de ellos durante una prueba
     * de carga dejaba el log en blanco. Ahora cada 5xx deja una línea con el código, la ruta, el
     * idTraza que vio el cliente y la causa, que es lo que permite separar «OHI no responde» de
     * «este servicio está saturado». Los 500 siguen con su traza completa; los 4xx, que son
     * respuestas de negocio y pueden ser miles, solo en DEBUG.
     */
    @Override
    protected void logError(ServerRequest solicitud, ServerResponse respuesta, Throwable error) {
        int estado = respuesta.statusCode().value();
        if (estado == 500) {
            super.logError(solicitud, respuesta, error);
        } else if (estado > 500) {
            log.warn(lineaDeLog(solicitud, estado, error));
        } else if (log.isDebugEnabled()) {
            log.debug(lineaDeLog(solicitud, estado, error));
        }
    }

    static String lineaDeLog(ServerRequest solicitud, int estado, Throwable error) {
        var cuerpo = solicitud.attribute(CUERPO)
                .filter(Map.class::isInstance).map(Map.class::cast).orElse(Map.of());
        return "HTTP %d %s %s %s idTraza=%s causa=%s".formatted(
                estado, cuerpo.getOrDefault("codigo", "-"), solicitud.method(), solicitud.path(),
                cuerpo.getOrDefault("idTraza", "-"), causa(error));
    }

    /**
     * La causa, con lo que la distingue: el error de dominio trae su detalle —«circuito
     * abierto», «Pending acquire queue has reached its maximum size», el código con el que
     * respondió OHI—, y la excepción que lo envuelve dice si vino de una respuesta HTTP.
     */
    static String causa(Throwable error) {
        if (error instanceof ExcepcionDeDominio dominio) {
            return dominio.getClass() == ExcepcionDeDominio.class
                    ? String.valueOf(dominio.error())
                    : dominio.error() + "; " + dominio;
        }
        return String.valueOf(error);
    }
}
