package co.sura.auditoria.api.error;

import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.*;
import reactor.core.publisher.Mono;

/**
 * Responde los errores siempre en JSON.
 *
 * <p>El manejador que trae Spring Boot decide el formato según el {@code Accept} de la
 * solicitud: si el cliente acepta {@code text/html} —un navegador, por ejemplo— intenta
 * pintar una vista de error y termina mostrando la página de respaldo
 * («This application has no configured error view»). Este servicio es un API: el
 * contrato de error es el mismo para todos los clientes.
 *
 * <p>Se registra con orden {@code -2} para anteponerse al
 * {@code DefaultErrorWebExceptionHandler}, que usa {@code -1}.
 */
@Component
@Order(-2)
public class ManejadorErroresJson extends AbstractErrorWebExceptionHandler {

    public ManejadorErroresJson(AtributosErrorGlobal atributos,
                                ApplicationContext contexto,
                                ServerCodecConfigurer codecs) {
        // No servimos páginas de error estáticas: basta con los valores por omisión.
        super(atributos, new WebProperties.Resources(), contexto);
        setMessageWriters(codecs.getWriters());
        setMessageReaders(codecs.getReaders());
    }

    @Override
    protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes atributos) {
        return RouterFunctions.route(RequestPredicates.all(), this::responder);
    }

    private Mono<ServerResponse> responder(ServerRequest solicitud) {
        var cuerpo = getErrorAttributes(solicitud, ErrorAttributeOptions.defaults());
        int estado = cuerpo.get("status") instanceof Integer valor ? valor : 500;

        return ServerResponse.status(estado)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(cuerpo);
    }
}
