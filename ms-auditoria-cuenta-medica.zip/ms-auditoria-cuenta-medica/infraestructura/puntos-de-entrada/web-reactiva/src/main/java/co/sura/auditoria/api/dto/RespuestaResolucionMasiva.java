package co.sura.auditoria.api.dto;

import java.util.List;

/**
 * Cómo acabó una resolución de varios motivos.
 *
 * <p>No es un {@code 204 No Content} como la resolución individual, y la
 * diferencia es deliberada: la operación conjunta puede salir a medias, y un
 * cuerpo vacío con un código de éxito solo sabe decir «se aceptó». El cliente
 * necesita poder distinguir «todo resuelto» de «parte sí, parte no» para no
 * rotular como hecho lo que no lo está.
 *
 * @param desenlace    {@code COMPLETO}, {@code PARCIAL}, {@code FALLIDO} o
 *                     {@code EN_CURSO}.
 * @param todoResuelto atajo de {@code desenlace == COMPLETO}. Va explícito para
 *                     que el cliente no tenga que conocer el conjunto de valores
 *                     para hacer la única pregunta que casi siempre importa.
 * @param referencias  identificadores de las operaciones en el sistema de
 *                     registro. Son dos cuando el nivel obliga a resolver en la
 *                     cabecera y en las líneas. Sirven para rastrear la
 *                     operación desde fuera de la aplicación.
 * @param fallos       lo que no se pudo resolver. Vacío si {@code todoResuelto}.
 */
public record RespuestaResolucionMasiva(String desenlace,
                                        boolean todoResuelto,
                                        List<String> referencias,
                                        List<Fallo> fallos) {

    /**
     * @param codigo   código de mensaje del sistema de registro, estable, para
     *                 distinguir causas sin leer el texto
     * @param elemento el elemento al que se refiere, si el mensaje lo trae
     * @param detalle  la explicación para el auditor
     */
    public record Fallo(String codigo, String elemento, String detalle) {}
}
