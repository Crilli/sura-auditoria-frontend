package co.sura.auditoria.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Una línea de una versión abierta (BUS-21.5): todos los campos de
 * {@link RespuestaLineaDeVersion}, al mismo nivel, y además sus novedades, diagnósticos, convenio
 * y datos de la atención de entonces. Nada de aquí es editable.
 *
 * <p>Los campos de la fila se repiten en vez de anidarse para que la pantalla lea la fila y el
 * detalle con los mismos nombres: el detalle es la fila con más cosas, no otra cosa.
 *
 * @param novedades agrupadas: {@code repeticiones} dice cuántas veces la repetía el sistema de
 *                  registro
 */
public record RespuestaDetalleLineaDeVersion(
        int numeroLinea,
        String estado,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        String codigoProcedimiento,
        String descripcionProcedimiento,
        String catalogoProcedimiento,
        String codigoAfiliado,
        String nombreAfiliado,
        String codigoAutorizacion,
        String prestadorCodigo,
        String prestadorNombre,
        BigDecimal valorCargado,
        BigDecimal unidadesCargadas,
        // Los mismos nombres que la línea viva (BUS-21): convenido = allowed*, autorizado =
        // covered*. Hasta el 2026-10-21 eran «autorizado» y «cubierto»; ver RespuestaDetalleLinea.
        BigDecimal valorConvenido,
        BigDecimal unidadesConvenidas,
        BigDecimal valorAutorizado,
        BigDecimal unidadesAutorizadas,
        BigDecimal valorGlosado,
        BigDecimal valorIva,
        BigDecimal porcentajeIva,
        List<RespuestaLineaDeVersion.GlosaDeVersion> glosas,
        List<NovedadDeVersion> novedades,
        List<DiagnosticoDeVersion> diagnosticos,
        ConvenioDeVersion convenio,
        AtencionDeVersion atencion
) {

    /**
     * @param severidad {@code INFORMATIVA}, {@code BLOQUEANTE}, {@code NEGACION} o
     *                  {@code DESCONOCIDA}, como en la línea viva
     * @param texto     el de la fecha de la foto, ya resuelto; puede no coincidir con el catálogo
     *                  de hoy
     * @param origen    la etapa que la levantó, tal cual ({@code MANUAL} si la puso una persona)
     * @param anulada   si se anuló; sigue en la foto
     */
    public record NovedadDeVersion(String codigo, String severidad, String texto, String origen,
                                   boolean anulada, int repeticiones) {}

    public record DiagnosticoDeVersion(Integer secuencia, String codigo, String descripcion,
                                       String tipo) {}

    /**
     * Sin número de contrato: la foto de producción no lo guarda (solo la de UAT), y un campo
     * siempre vacío se leería como «sin contrato».
     */
    public record ConvenioDeVersion(String tarifaIss2000, String tarifaIss2001, String tarifaSoat,
                                    String homologoCups, List<ClausulaDeVersion> clausulas) {}

    /** @param regla el método o regla que la produjo; un monto negativo es un descuento */
    public record ClausulaDeVersion(BigDecimal monto, String descripcion, String regla) {}

    public record AtencionDeVersion(String tipoSala, String viaAcceso, String uen) {}
}
