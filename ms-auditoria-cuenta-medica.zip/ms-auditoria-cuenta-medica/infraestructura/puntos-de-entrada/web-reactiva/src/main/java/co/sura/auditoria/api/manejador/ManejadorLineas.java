package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.SolicitudGuardarLinea;
import co.sura.auditoria.api.mapeo.MapeadorLinea;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarDetalleLineaCasoDeUso;
import co.sura.auditoria.casodeuso.AplicarCambiosEnLoteCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarLineaCasoDeUso;
import co.sura.auditoria.api.dto.RespuestaFiltrosLineas;
import co.sura.auditoria.casodeuso.ListarLineasCasoDeUso;
import co.sura.auditoria.casodeuso.ObtenerLineaSiguienteCasoDeUso;
import co.sura.auditoria.casodeuso.ResumirFiltrosLineasCasoDeUso;
import co.sura.auditoria.api.dto.SolicitudCambiosEnLote;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CatalogoPrestacion;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.cuenta.OrdenLineas;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones sobre líneas de la cuenta médica.
 */
@Component
public class ManejadorLineas {

    private final ListarLineasCasoDeUso           listar;
    private final ObtenerLineaSiguienteCasoDeUso siguiente;
    private final ResumirFiltrosLineasCasoDeUso   resumirFiltros;
    private final ConsultarDetalleLineaCasoDeUso  detalle;
    private final GuardarLineaCasoDeUso           guardar;
    private final AplicarCambiosEnLoteCasoDeUso   aplicarEnLote;
    private final ValidadorSolicitudes            validador;

    public ManejadorLineas(ListarLineasCasoDeUso listar,
                           ObtenerLineaSiguienteCasoDeUso siguiente,
                           ResumirFiltrosLineasCasoDeUso resumirFiltros,
                           ConsultarDetalleLineaCasoDeUso detalle,
                           GuardarLineaCasoDeUso guardar,
                           AplicarCambiosEnLoteCasoDeUso aplicarEnLote,
                           ValidadorSolicitudes validador) {
        this.listar         = listar;
        this.siguiente      = siguiente;
        this.resumirFiltros = resumirFiltros;
        this.detalle        = detalle;
        this.guardar        = guardar;
        this.aplicarEnLote  = aplicarEnLote;
        this.validador      = validador;
    }

    /**
     * GET /api/v1/cuentas/{codigo}/lineas?pagina=0&amp;tamano=25
     * &amp;cedula=&amp;desde=&amp;hasta=&amp;autorizacion=&amp;prestacion=&amp;catalogo=&amp;glosaDesde=&amp;glosaHasta=
     *
     * <p>Los criterios son acumulativos y todos opcionales. Dos avisos sobre lo
     * que el cliente puede esperar:
     * <ul>
     *   <li>{@code autorizacion} y {@code prestacion} buscan <b>por prefijo</b> y
     *       sin distinguir mayúsculas, que es como se teclea un código a medias;</li>
     *   <li>con {@code catalogo} la respuesta <b>no trae total</b>: es el único
     *       criterio que el sistema de registro no sabe aplicar, así que esas
     *       líneas se descartan aquí y su número no cuenta lo que se enseña.
     *       Ver {@link FiltroLineas}.</li>
     * </ul>
     *
     * <p>Un {@code catalogo} que no sea uno de los valores conocidos se rechaza
     * con 400 en vez de interpretarse como «todos», que escondería un error del
     * cliente detrás de una lista plausible.
     */
    public Mono<ServerResponse> listarResumen(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var tamano = solicitud.queryParam("tamano").map(ManejadorLineas::aEntero)
                             .orElse(ListarLineasCasoDeUso.TAMANO_PAGINA_PREDETERMINADO);
        var desplazamiento = aDesplazamiento(solicitud, tamano);
        var filtro = aFiltro(solicitud);
        var orden = aOrden(solicitud);

        return listar.ejecutar(codigo, desplazamiento, tamano, filtro, orden)
                .map(MapeadorLinea::aRespuestaDesplazada)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * Qué página se pide, admitiendo las dos formas de decirlo.
     *
     * <p>{@code desplazamiento} es la posición exacta y manda si viene;
     * {@code pagina} es el número de página contando desde cero, que es lo que
     * tiene a mano una tabla, y se traduce multiplicando por el tamaño. Si no
     * viene ninguno, el principio.
     *
     * <p>El tamaño que se usa para traducir es el ya resuelto, no el que llegó:
     * así una página 5 con un tamaño fuera de rango cae donde el listado la va a
     * situar de verdad, y no en una posición que el caso de uso luego no
     * respetaría.
     */
    private static int aDesplazamiento(ServerRequest solicitud, int tamano) {
        var explicito = solicitud.queryParam("desplazamiento").map(ManejadorLineas::aEntero);
        if (explicito.isPresent()) {
            return Math.max(0, explicito.get());
        }
        return solicitud.queryParam("pagina").map(ManejadorLineas::aEntero)
                        .map(p -> Math.max(0, p) * tamano)
                        .orElse(0);
    }

    /**
     * Por qué columna ordenar, de una lista cerrada.
     *
     * <p>Un campo desconocido se rechaza con 400 en vez de ignorarse. Ignorarlo devolvería
     * un listado ordenado de otra manera sin decirlo, y el auditor leería como ordenado por
     * valor glosado algo que viene por número de línea.
     */
    private static OrdenLineas aOrden(ServerRequest solicitud) {
        var campo = solicitud.queryParam("orden").filter(v -> !v.isBlank());
        if (campo.isEmpty()) return OrdenLineas.PREDETERMINADO;

        var sentido = solicitud.queryParam("sentido").filter(v -> !v.isBlank())
                .map(ManejadorLineas::aSentido)
                .orElse(OrdenLineas.Sentido.ASCENDENTE);
        return new OrdenLineas(aCampoDeOrden(campo.get()), sentido);
    }

    private static OrdenLineas.Campo aCampoDeOrden(String valor) {
        try {
            return OrdenLineas.Campo.valueOf(valor.trim().toUpperCase().replace('-', '_'));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "No se puede ordenar por '" + valor + "'. Los campos admitidos son: "
                    + java.util.Arrays.stream(OrdenLineas.Campo.values())
                            .map(c -> c.name().toLowerCase())
                            .collect(java.util.stream.Collectors.joining(", ")));
        }
    }

    private static OrdenLineas.Sentido aSentido(String valor) {
        var v = valor.trim().toLowerCase();
        if (v.equals("asc") || v.equals("ascendente")) return OrdenLineas.Sentido.ASCENDENTE;
        if (v.equals("desc") || v.equals("descendente")) return OrdenLineas.Sentido.DESCENDENTE;
        throw new IllegalArgumentException(
                "El sentido del orden es 'asc' o 'desc', no '" + valor + "'");
    }

    private static int aEntero(String valor) {
        try {
            return Integer.parseInt(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "Se esperaba un número entero, no '" + valor + "'");
        }
    }

    /**
     * GET /api/v1/cuentas/{codigo}/lineas/{referencia}/siguiente
     *
     * <p>Cuál es la línea que sigue a esta, para «guardar y pasar a la
     * siguiente». Responde <b>204</b> cuando no hay siguiente: es la última de
     * la cuenta, y eso es una respuesta, no un error.
     *
     * <p>Lo resolvía el cliente pidiendo una página de una fila con la
     * referencia actual como cursor, lo que daba la siguiente por identificador
     * y no por número de línea. Está aquí porque el orden en que se revisan las
     * líneas es del negocio, no de cómo esté paginado el listado.
     */
    public Mono<ServerResponse> consultarSiguiente(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));

        return siguiente.ejecutar(codigo, referencia)
                .map(MapeadorLinea::aResumen)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo))
                .switchIfEmpty(ServerResponse.noContent().build());
    }

    /**
     * GET /api/v1/cuentas/{codigo}/lineas/filtros
     *
     * <p>Con qué se puede acotar esta cuenta. Va aparte del listado porque
     * recorre la cuenta entera y no cambia al pasar de página: el cliente lo pide
     * una vez, en paralelo con la primera página, y la tabla pinta sin esperarlo.
     */
    public Mono<ServerResponse> resumirFiltros(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));

        return resumirFiltros.ejecutar(codigo)
                .map(ManejadorLineas::aRespuestaFiltros)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * POST /api/v1/cuentas/{codigo}/lineas/lote
     *
     * <p>El mismo cambio sobre las líneas marcadas en la grilla. Responde <b>200 también cuando
     * es parcial</b>: la petición fue correcta y algo se aplicó —y es irreversible—, así que
     * devolver un error haría que el cliente diera por no hecho lo que sí ocurrió. El desenlace
     * y los fallos por línea viajan en el cuerpo, que es donde se pueden leer uno a uno.
     */
    public Mono<ServerResponse> aplicarEnLote(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var autor  = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudCambiosEnLote.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .flatMap(dto -> aplicarEnLote.ejecutar(codigo, MapeadorLinea.aCambiosEnLote(dto), autor))
                .map(MapeadorLinea::aRespuestaDeLote)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    private static FiltroLineas aFiltro(ServerRequest solicitud) {
        return new FiltroLineas(
                solicitud.queryParam("secuencia").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aEntero).orElse(null),
                solicitud.queryParam("cedula").orElse(null),
                solicitud.queryParam("desde").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aFecha).orElse(null),
                solicitud.queryParam("hasta").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aFecha).orElse(null),
                solicitud.queryParam("autorizacion").orElse(null),
                solicitud.queryParam("prestacion").orElse(null),
                solicitud.queryParam("catalogo").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aCatalogo).orElse(null),
                solicitud.queryParam("glosaDesde").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aMonto).orElse(null),
                solicitud.queryParam("glosaHasta").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aMonto).orElse(null),
                solicitud.queryParam("conNovedad").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aBooleano).orElse(false),
                solicitud.queryParam("motivoPendiente").orElse(null),
                solicitud.queryParam("bloqueo").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aFiltroBloqueo).orElse(FiltroBloqueo.TODOS),
                // El estado de la cuenta no llega de fuera: lo resuelve la capa de integración,
                // que es la única que lo puede leer.
                null);
    }

    /**
     * Un criterio de sí o no.
     *
     * <p>Solo {@code true} y {@code false}, y no «todo lo que no sea true es false»: un
     * {@code conNovedad=1} o un {@code conNovedad=si} se leerían como «sin filtro» y el auditor
     * vería la cuenta entera creyendo que filtró. Eso es un 200 con el dato equivocado.
     */
    private static boolean aBooleano(String valor) {
        var limpio = valor.trim().toLowerCase();
        if (limpio.equals("true"))  return true;
        if (limpio.equals("false")) return false;
        throw new IllegalArgumentException(
                "El parámetro 'conNovedad' admite true o false, no '" + valor + "'");
    }

    /** Mismo vocabulario que el listado de pendientes: la regla de bloqueo es una sola. */
    private static FiltroBloqueo aFiltroBloqueo(String valor) {
        try {
            return FiltroBloqueo.valueOf(valor.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "El parámetro 'bloqueo' admite TODOS, BLOQUEANTES o NO_BLOQUEANTES, no '"
                    + valor + "'");
        }
    }

    private static java.time.LocalDate aFecha(String valor) {
        try {
            return java.time.LocalDate.parse(valor.trim());
        } catch (java.time.format.DateTimeParseException e) {
            throw new IllegalArgumentException(
                    "Las fechas se escriben como aaaa-mm-dd, no '" + valor + "'");
        }
    }

    private static java.math.BigDecimal aMonto(String valor) {
        try {
            return new java.math.BigDecimal(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "El valor glosado tiene que ser un número, no '" + valor + "'");
        }
    }

    private static CatalogoPrestacion aCatalogo(String valor) {
        try {
            return CatalogoPrestacion.valueOf(valor.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "El catálogo admite CUPS, CUM, SURACUPS, PROPIO u OTRO, no '" + valor + "'");
        }
    }

    private static RespuestaFiltrosLineas aRespuestaFiltros(ResumenFiltrosLineas resumen) {
        return new RespuestaFiltrosLineas(
                resumen.afiliados().stream()
                        .map(a -> new RespuestaFiltrosLineas.Afiliado(a.cedula(), a.nombre(), a.lineas()))
                        .toList(),
                resumen.catalogos().stream()
                        .map(c -> new RespuestaFiltrosLineas.Catalogo(
                                c.catalogo().name(), c.catalogo().etiqueta(), c.lineas()))
                        .toList(),
                resumen.primeraAtencion(), resumen.ultimaAtencion(),
                resumen.glosaMaxima(), resumen.lineasConGlosa(), resumen.totalLineas());
    }

    /** GET /api/v1/cuentas/{codigo}/lineas/{referencia} */
    public Mono<ServerResponse> consultarDetalle(ServerRequest solicitud) {
        var codigo     = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));

        return detalle.ejecutar(codigo, referencia)
                .map(MapeadorLinea::aRespuestaDetalle)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /** PATCH /api/v1/cuentas/{codigo}/lineas/{referencia} */
    public Mono<ServerResponse> guardarLinea(ServerRequest solicitud) {
        var codigo     = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));
        var autor      = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudGuardarLinea.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .map(dto -> MapeadorLinea.aEdicionLinea(referencia, dto))
                .flatMap(edicion -> guardar.ejecutar(codigo, edicion, autor))
                .map(MapeadorLinea::aRespuestaDetalle)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }
}
