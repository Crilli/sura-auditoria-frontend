package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.SolicitudGuardarLinea;
import co.sura.auditoria.api.mapeo.MapeadorLinea;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarDetalleLineaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarLineaCasoDeUso;
import co.sura.auditoria.api.dto.RespuestaFiltrosLineas;
import co.sura.auditoria.casodeuso.ListarLineasCasoDeUso;
import co.sura.auditoria.casodeuso.ResumirFiltrosLineasCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CatalogoPrestacion;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones sobre líneas de la cuenta médica.
 */
@Component
public class ManejadorLineas {

    private final ListarLineasCasoDeUso           listar;
    private final ResumirFiltrosLineasCasoDeUso   resumirFiltros;
    private final ConsultarDetalleLineaCasoDeUso  detalle;
    private final GuardarLineaCasoDeUso           guardar;
    private final ValidadorSolicitudes            validador;

    public ManejadorLineas(ListarLineasCasoDeUso listar,
                           ResumirFiltrosLineasCasoDeUso resumirFiltros,
                           ConsultarDetalleLineaCasoDeUso detalle,
                           GuardarLineaCasoDeUso guardar,
                           ValidadorSolicitudes validador) {
        this.listar         = listar;
        this.resumirFiltros = resumirFiltros;
        this.detalle        = detalle;
        this.guardar        = guardar;
        this.validador      = validador;
    }

    /**
     * GET /api/v1/cuentas/{codigo}/lineas?cursor=&amp;tamano=25
     * &amp;cedula=&amp;desde=&amp;hasta=&amp;autorizacion=&amp;prestacion=&amp;catalogo=&amp;glosaDesde=&amp;glosaHasta=
     *
     * <p>Los criterios son acumulativos y todos opcionales. Dos avisos sobre lo
     * que el cliente puede esperar:
     * <ul>
     *   <li>{@code autorizacion} y {@code prestacion} buscan <b>por prefijo</b> y
     *       sin distinguir mayúsculas, que es como se teclea un código a medias;</li>
     *   <li>con {@code catalogo} o con cualquiera de los dos de glosa, la
     *       respuesta <b>no trae total</b>: el sistema de registro no sabe
     *       filtrar por esos campos, así que el número que publica cuenta filas
     *       que después se descartan. Ver {@link FiltroLineas}.</li>
     * </ul>
     *
     * <p>Un {@code catalogo} que no sea uno de los valores conocidos se rechaza
     * con 400 en vez de interpretarse como «todos», que escondería un error del
     * cliente detrás de una lista plausible.
     */
    public Mono<ServerResponse> listarResumen(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var cursor = solicitud.queryParam("cursor")
                              .map(Long::parseLong).map(Cursor::new)
                              .orElse(Cursor.PRIMERA_PAGINA);
        var tamano = solicitud.queryParam("tamano").map(Integer::parseInt).orElse(25);
        var filtro = aFiltro(solicitud);

        return listar.ejecutar(codigo, cursor, tamano, filtro)
                .map(MapeadorLinea::aRespuestaPaginada)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /**
     * GET /api/v1/cuentas/{codigo}/lineas/filtros
     *
     * <p>Con qué se puede acotar esta cuenta. Va aparte del listado porque
     * recorre la cuenta entera y no cambia al pasar de página: el cliente lo pide
     * una vez, en paralelo con la primera página, y la tabla pinta sin esperarlo.
     */
    public Mono<ServerResponse> resumirFiltros(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));

        return resumirFiltros.ejecutar(codigo)
                .map(ManejadorLineas::aRespuestaFiltros)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    private static FiltroLineas aFiltro(ServerRequest solicitud) {
        return new FiltroLineas(
                solicitud.queryParam("cedula").orElse(null),
                solicitud.queryParam("desde").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aFecha).orElse(null),
                solicitud.queryParam("hasta").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aFecha).orElse(null),
                solicitud.queryParam("autorizacion").orElse(null),
                solicitud.queryParam("prestacion").orElse(null),
                solicitud.queryParam("catalogo").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aCatalogo).orElse(null),
                solicitud.queryParam("glosaDesde").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aMonto).orElse(null),
                solicitud.queryParam("glosaHasta").filter(v -> !v.isBlank())
                         .map(ManejadorLineas::aMonto).orElse(null));
    }

    private static java.time.LocalDate aFecha(String valor) {
        try {
            return java.time.LocalDate.parse(valor.trim());
        } catch (java.time.format.DateTimeParseException e) {
            throw new IllegalArgumentException(
                    "Las fechas se escriben como aaaa-mm-dd, no '" + valor + "'");
        }
    }

    private static java.math.BigDecimal aMonto(String valor) {
        try {
            return new java.math.BigDecimal(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "El valor glosado tiene que ser un número, no '" + valor + "'");
        }
    }

    private static CatalogoPrestacion aCatalogo(String valor) {
        try {
            return CatalogoPrestacion.valueOf(valor.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "El catálogo admite CUPS, CUM, SURACUPS, PROPIO u OTRO, no '" + valor + "'");
        }
    }

    private static RespuestaFiltrosLineas aRespuestaFiltros(ResumenFiltrosLineas resumen) {
        return new RespuestaFiltrosLineas(
                resumen.afiliados().stream()
                        .map(a -> new RespuestaFiltrosLineas.Afiliado(a.cedula(), a.nombre(), a.lineas()))
                        .toList(),
                resumen.catalogos().stream()
                        .map(c -> new RespuestaFiltrosLineas.Catalogo(
                                c.catalogo().name(), c.catalogo().etiqueta(), c.lineas()))
                        .toList(),
                resumen.primeraAtencion(), resumen.ultimaAtencion(),
                resumen.glosaMaxima(), resumen.lineasConGlosa(), resumen.totalLineas());
    }

    /** GET /api/v1/cuentas/{codigo}/lineas/{referencia} */
    public Mono<ServerResponse> consultarDetalle(ServerRequest solicitud) {
        var codigo     = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));

        return detalle.ejecutar(codigo, referencia)
                .map(MapeadorLinea::aRespuestaDetalle)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /** PATCH /api/v1/cuentas/{codigo}/lineas/{referencia} */
    public Mono<ServerResponse> guardarLinea(ServerRequest solicitud) {
        var codigo     = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));
        var autor      = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudGuardarLinea.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .map(dto -> MapeadorLinea.aEdicionLinea(referencia, dto))
                .flatMap(edicion -> guardar.ejecutar(codigo, edicion, autor))
                .map(MapeadorLinea::aRespuestaDetalle)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }
}
