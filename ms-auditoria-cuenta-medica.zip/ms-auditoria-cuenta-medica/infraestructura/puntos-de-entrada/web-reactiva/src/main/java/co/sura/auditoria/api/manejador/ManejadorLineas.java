package co.sura.auditoria.api.manejador;

import co.sura.auditoria.api.dto.SolicitudGuardarLinea;
import co.sura.auditoria.api.mapeo.MapeadorLinea;
import co.sura.auditoria.api.validacion.ValidadorSolicitudes;
import co.sura.auditoria.casodeuso.ConsultarDetalleLineaCasoDeUso;
import co.sura.auditoria.casodeuso.GuardarLineaCasoDeUso;
import co.sura.auditoria.casodeuso.ListarLineasCasoDeUso;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * Manejador de operaciones sobre líneas de la cuenta médica.
 */
@Component
public class ManejadorLineas {

    private final ListarLineasCasoDeUso           listar;
    private final ConsultarDetalleLineaCasoDeUso  detalle;
    private final GuardarLineaCasoDeUso           guardar;
    private final ValidadorSolicitudes            validador;

    public ManejadorLineas(ListarLineasCasoDeUso listar,
                           ConsultarDetalleLineaCasoDeUso detalle,
                           GuardarLineaCasoDeUso guardar,
                           ValidadorSolicitudes validador) {
        this.listar    = listar;
        this.detalle   = detalle;
        this.guardar   = guardar;
        this.validador = validador;
    }

    /** GET /api/v1/cuentas/{codigo}/lineas?cursor=&tamano=25 */
    public Mono<ServerResponse> listarResumen(ServerRequest solicitud) {
        var codigo = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var cursor = solicitud.queryParam("cursor")
                              .map(Long::parseLong).map(Cursor::new)
                              .orElse(Cursor.PRIMERA_PAGINA);
        var tamano = solicitud.queryParam("tamano").map(Integer::parseInt).orElse(25);

        return listar.ejecutar(codigo, cursor, tamano)
                .map(MapeadorLinea::aRespuestaPaginada)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /** GET /api/v1/cuentas/{codigo}/lineas/{referencia} */
    public Mono<ServerResponse> consultarDetalle(ServerRequest solicitud) {
        var codigo     = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));

        return detalle.ejecutar(codigo, referencia)
                .map(MapeadorLinea::aRespuestaDetalle)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }

    /** PATCH /api/v1/cuentas/{codigo}/lineas/{referencia} */
    public Mono<ServerResponse> guardarLinea(ServerRequest solicitud) {
        var codigo     = new CodigoCuenta(solicitud.pathVariable("codigo"));
        var referencia = new ReferenciaLinea(Long.parseLong(solicitud.pathVariable("referencia")));
        var autor      = solicitud.headers().firstHeader("X-Auditor");

        return solicitud.bodyToMono(SolicitudGuardarLinea.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo es obligatorio")))
                .doOnNext(validador::validar)
                .map(dto -> MapeadorLinea.aEdicionLinea(referencia, dto))
                .flatMap(edicion -> guardar.ejecutar(codigo, edicion, autor))
                .map(MapeadorLinea::aRespuestaDetalle)
                .flatMap(cuerpo -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(cuerpo));
    }
}
