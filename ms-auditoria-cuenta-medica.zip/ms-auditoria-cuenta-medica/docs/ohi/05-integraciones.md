# 05 — Integraciones

OHI prod no es un sistema aislado: es el motor de adjudicación en el centro de
una docena de servicios de Sura. Este documento dice exactamente qué sale, qué
entra y por dónde.

```mermaid
flowchart TB
    subgraph OCI["Oracle Cloud — us-ashburn-1"]
        OHI["OHI Claims 4.25.1.0.23<br/>prod-Claims"]
        OIG["OIG<br/>/prod/oig/api/notifications"]
    end

    IDCS["IDCS<br/>OAuth2 client_credentials"]
    GW{{"apivida.suramericana.com.co<br/>gateway"}}

    subgraph SURA["Microservicios de Sura"]
        MS937["937-ohi_arl_cuentasmedicas-ms<br/>radica, escala y borra"]
        MS1015["1015-contabilizador<br/>procesos contables"]
        AUD["ms-auditoria-cuenta-medica<br/>este repositorio"]
        BAND["bandejas / notificaciones"]
        RECL["reclamaciones"]
        AFIL["afiliaciones"]
        RESERVA["reserva"]
    end

    SAP[("SAP")]
    P8[("P8<br/>gestor documental")]

    IDCS -. "token 3600 s" .-> MS937
    IDCS -. token .-> AUD
    IDCS -. token .-> MS1015

    MS937 -- "escribe: radicacion RIPS, submit, resolvepend, DELETE" --> OHI
    AUD -- "lee y opera cuentas" --> OHI
    MS1015 -- "/claims/search" --> OHI

    OHI == "18 eventos de cuenta<br/>BasicAuth" ==> GW
    GW --> MS937
    GW --> BAND
    GW --> RECL
    GW --> RESERVA
    GW --> AFIL

    OHI == "mensaje financiero<br/>BasicAuth" ==> MS1015
    MS1015 --> SAP
    OHI -- "consulta afiliacion<br/>auth None" --> AFIL
    OHI -- "extractos, OAuth" --> OIG
    OHI -. "enlaces de la UI" .-> P8

    classDef ohi fill:#fff3e0,stroke:#e65100,stroke-width:2px
    classDef ext fill:#eceff1,stroke:#546e7a
    class OHI ohi
    class SAP,P8,IDCS ext
```

## Lo que sale de OHI

OHI empuja. No hay nadie sondeándolo: cuando una cuenta cambia de estado, OHI
llama por HTTP a quien corresponda. La configuración está en
`GET /outboundintegrationpoints` y hay **21 puntos de integración definidos**,
de los que **4 tienen endpoints configurados**:

| Punto de integración | Endpoints | Destino |
|---|---:|---|
| **Claims Event IP** | 18 | los eventos de cuenta médica |
| **Financial Message Claims IP** | 1 | el contabilizador |
| **Enrollment Integration Point** | 1 | afiliaciones |
| **Extract IP** | 1 | OIG |

Los 17 restantes están definidos y vacíos: `Claim Callout IP`,
`Claim Transaction Event IP`, `Free Format Claim Transaction Event IP`,
`Activity Integration Point`, `Financial Message IP`,
`Resend Financial Message IP`, `Workflow IP`, `Workflow IP (Configurable)`,
`Claims Technical Error IP`, `Claims Out IP`, `Claims Reprocess IP`,
`Data Set Operations Integration Point`, `Macros IP`. Que estén vacíos importa:
**no hay punto de integración para los errores técnicos** (`Claims Technical
Error IP`), así que un fallo del motor no se notifica a nadie por esa vía — se
descubre mirando las tareas ([06](06-operacion.md)).

### Los 18 eventos de cuenta médica

Cada evento es una **regla de evento** (`claimeventrules`) que se dispara cuando
una cuenta entra a un estado. Las 18 están **activas**. La tabla completa, leída
de la configuración de prod:

| Regla (`useCase`) | Se dispara en | Nivel | Sub­cuentas | Destino |
|---|---|---|---|---|
| `RE_NOTIFICA_BANDEJA_CM_ENTRADA` | `ENTRY` | cuenta | sí | `…/ohi/ms/cuentasmedicas/v1/eventosohi/cm/envio-factura-bandeja` |
| `RE_HOMOL_ESTADO_CM_ENTRADA` | `ENTRY` | cuenta | sí | `…/mi/cuentasmedicas/v1/eventosohi/cm/homologar-estado-cuenta-medica` |
| `RE_ESCALAR_CM_CAMBIAR` | `CHANGE` | cuenta | sí | `…/ohi/ms/cuentasmedicas/v1/eventosohi/cm/envio-factura-bandeja` |
| `RE_HOMOL_ESTADO_CM_CAMBIAR` | `CHANGE` | cuenta | sí | `…/mi/cuentasmedicas/v1/eventosohi/cm/homologar-estado-cuenta-medica` |
| `RE_CM_NOTIFICAR_RESERVA_CAMBIO` | `CHANGE` | cuenta | no | `…/mi/reserva/v1/eventosohi/ohi/pago-asistencial` |
| `RE_ESCALAR_CM_PENDIENTE` | `MANUAL ADJUDICATION` | cuenta | sí | `…/ohi/ms/cuentasmedicas/v1/eventosohi/cm/envio-factura-bandeja` |
| `RE_HOMOL_ESTADO_CM_PENDIENTE` | `MANUAL ADJUDICATION` | cuenta | no | `…/mi/cuentasmedicas/v1/eventosohi/cm/homologar-estado-cuenta-medica` |
| `RE_ENVIAR_AUT_PENDIENTE` | `MANUAL ADJUDICATION` | cuenta | no | `…/mi/reclamaciones/v1/eventosohi/respuesta-autorizaciones` |
| `RE_ESCALAR_AUT_PENDIENTE` | `MANUAL ADJUDICATION` | cuenta | no | `…/mi/reclamaciones/v1/eventosohi/bandeja-autorizaciones` |
| `RE_NOTIFICAR_CM_BANDEJAS` | `FINALIZED` | cuenta | sí | `…/ohi/ms/cuentasmedicas/v1/eventosohi/cm/envio-factura-bandeja` |
| `RE_CM_NOTIFICAR_RESERVA` | `FINALIZED` | cuenta | sí | `…/mi/reserva/v1/eventosohi/ohi/pago-asistencial` |
| `RE_CCM_CM_GLOSADA` | `FINALIZED` | cuenta | sí | `…/mi/notificaciones/v1/eventosohi/carta-prestador` |
| `RE_CCM_AUT_FINALIZADA` | `FINALIZED` | cuenta | no | `…/mi/bandejas/v1/eventosohi/homologar-estado-cuenta-medica` |
| `RE_ENVIAR_AUT_FINALIZADA` | `FINALIZED` | cuenta | no | `…/mi/reclamaciones/v1/eventosohi/respuesta-autorizaciones` |
| `RE_AUT_ACTUALIZA_SINIESTRO` | `FINALIZED` | cuenta | no | `…/mi/afiliaciones/v1/eventosohi/actualizarSiniestro` |
| `RE_CREACION_FACTURA_GT` | `FINALIZED` | cuenta | no | `…/mi/cuentasmedicas/v1/eventosohi/cm/crear-anticipo` |
| `RE_NOTIFICACION_GASTO_TRASLADO` | `FINALIZED` | cuenta | no | `…/mi/reclamaciones/v1/eventosohi/bandeja-autorizaciones` |
| `RE_VALIDA_DATOS_SINIESTRO` | `INITIAL` | **línea** | no | `…/mi/afiliaciones/v1/eventosohi/derivacion-siniestro` |

Todas sobre `https://apivida.suramericana.com.co/secure/` salvo
`RE_VALIDA_DATOS_SINIESTRO`, que apunta a `https://apivida.sura.com/secure/`
(otro dominio del gateway). Todas por `POST`, `application/json`,
`BasicAuthentication`.

```mermaid
flowchart LR
    subgraph E["estado que dispara"]
        direction TB
        INI["INITIAL"]
        ENT["ENTRY"]
        CHA["CHANGE"]
        MAD["MANUAL ADJUDICATION"]
        FIN["FINALIZED"]
    end

    INI --> V1["RE_VALIDA_DATOS_SINIESTRO<br/><i>nivel LINEA</i>"]
    V1 --> D1["afiliaciones<br/>derivacion-siniestro"]

    ENT --> E1["RE_NOTIFICA_BANDEJA_CM_ENTRADA"]
    ENT --> E2["RE_HOMOL_ESTADO_CM_ENTRADA"]

    CHA --> C1["RE_ESCALAR_CM_CAMBIAR"]
    CHA --> C2["RE_HOMOL_ESTADO_CM_CAMBIAR"]
    CHA --> C3["RE_CM_NOTIFICAR_RESERVA_CAMBIO"]

    MAD --> M1["RE_ESCALAR_CM_PENDIENTE"]
    MAD --> M2["RE_HOMOL_ESTADO_CM_PENDIENTE"]
    MAD --> M3["RE_ENVIAR_AUT_PENDIENTE"]
    MAD --> M4["RE_ESCALAR_AUT_PENDIENTE"]

    FIN --> F1["RE_NOTIFICAR_CM_BANDEJAS"]
    FIN --> F2["RE_CM_NOTIFICAR_RESERVA"]
    FIN --> F3["RE_CCM_CM_GLOSADA"]
    FIN --> F4["RE_CCM_AUT_FINALIZADA"]
    FIN --> F5["RE_ENVIAR_AUT_FINALIZADA"]
    FIN --> F6["RE_AUT_ACTUALIZA_SINIESTRO"]
    FIN --> F7["RE_CREACION_FACTURA_GT"]
    FIN --> F8["RE_NOTIFICACION_GASTO_TRASLADO"]

    E1 --> B["cuentasmedicas ms<br/>envio-factura-bandeja"]
    C1 --> B
    M1 --> B
    F1 --> B
    E2 --> H["cuentasmedicas mi<br/>homologar-estado"]
    C2 --> H
    M2 --> H
    C3 --> R["reserva<br/>pago-asistencial"]
    F2 --> R
    M3 --> A["reclamaciones<br/>respuesta-autorizaciones"]
    F5 --> A
    M4 --> BA["reclamaciones<br/>bandeja-autorizaciones"]
    F8 --> BA
    F3 --> N["notificaciones<br/>carta-prestador"]
    F4 --> BJ["bandejas<br/>homologar-estado"]
    F6 --> AF["afiliaciones<br/>actualizarSiniestro"]
    F7 --> AN["cuentasmedicas mi<br/>crear-anticipo"]

    classDef fin fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    class FIN fin
```

Cosas que se leen de esa tabla y del diagrama, y conviene tener presentes:

- **`FINALIZED` dispara ocho eventos distintos.** Finalizar una cuenta es la
  operación más cara del sistema en términos de integración.
- **Dos rutas de gateway distintas para cuentas médicas**:
  `/secure/ohi/ms/cuentasmedicas/...` y `/secure/aseguramiento/mi/cuentasmedicas/...`.
  La primera (`ms`) va al microservicio nuevo; la segunda (`mi`) al camino
  anterior. Conviven, y el escalamiento a bandeja usa la primera mientras la
  homologación de estado usa la segunda.
- **`applicableToSubClaim`** decide si el evento se emite también por cada
  subcuenta de un *large claim*. Está en `true` en las de bandeja y
  homologación, y en `false` en las de autorizaciones. Es lo que evita que una
  cuenta troceada en 12 subcuentas genere 12 notificaciones a reclamaciones.
- **`RE_VALIDA_DATOS_SINIESTRO` es la única a nivel de línea** (`claimLevel = L`)
  y la única que se dispara en `INITIAL`: valida los datos del siniestro antes de
  que la cuenta avance.

#### Cómo se arma el cuerpo de cada evento

Cada regla engancha dos piezas de lógica dinámica
([04](04-extensiones-sura.md#lógica-dinámica)):

- **`dynamicLogicCondition`** — una `COND` que decide si el evento aplica de
  verdad. Por ejemplo `RE_CCM_ES_CM_GLOSADA` («es una cuenta médica finalizada y
  contiene glosa»), `RECM_SOLO_AUTORIZACIONES`, `RE_ES_CUENTA_MEDICA`.
- **`functionDynamicLogicClaim`** — una `FUNC` que añade campos al mensaje. Por
  ejemplo `RE_CCM_CM_GLOSADA` («envía el código de cuenta médica y el estado»),
  `RE_CM_CAMPOS_RESERVA_CAMBIO`, `RE_HOMOL_ESTADO_CM_ENTRADA` («envía
  `externalClaimDataID` y …»).

```mermaid
flowchart TB
    TRIG["la cuenta entra al estado"] --> CER["claimeventrules<br/>codigo = useCase"]
    CER --> F1{"enabled?"}
    F1 -- no --> STOP["no se emite"]
    F1 -- si --> F2{"claimStatus coincide?"}
    F2 -- no --> STOP
    F2 -- si --> F3{"applicableToSubClaim<br/>y es subcuenta?"}
    F3 -- "no aplica" --> STOP
    F3 -- si --> COND["dynamicLogicCondition<br/><i>COND</i>"]
    COND --> F4{"devuelve true?"}
    F4 -- no --> STOP
    F4 -- si --> PAY["functionDynamicLogicClaim<br/>functionDynamicLogicClaimPayload<br/><i>FUNC: anade campos</i>"]
    PAY --> MSG["mensaje JSON"]
    MSG --> OIP["outboundintegrationpoint<br/>destinationURL + auth"]
    OIP --> T["tarea ClaimsEvent"]
    T --> OK["COMPLETE"]
    T --> ERR["ERRORED<br/>238.075 acumuladas"]
    T --> HIST["claimeventhistory<br/>el rastro de lo emitido"]

    classDef mal fill:#ffebee,stroke:#c62828
    class ERR mal
```

Siete reglas no definen función de carga y mandan el mensaje estándar; las
demás lo enriquecen. Si hace falta cambiar qué campos viajan en un evento, **no
se toca código: se edita la lógica dinámica.** Y eso significa que un cambio en
la integración puede entrar en producción sin despliegue, lo cual es cómodo y
peligroso a partes iguales.

Las reglas también pueden restringirse por formulario
(`claimEventRuleClaimFormList`), por grupo de prestaciones
(`procedureGroup`, `procedureGroup2`, `procedureGroup3`) y por grupo de
mensajes (`messageGroup`).

#### El rastro de lo emitido

Lo que se emitió queda en `claimeventhistory` (con `claimLineEventHistoryList`
para el nivel de línea) ligado a la entrada de `claimstatushistory` que lo
provocó. Es el sitio donde comprobar «¿se notificó esta cuenta?», y es mejor que
preguntarle al receptor.

### El mensaje financiero

El único endpoint del **Financial Message Claims IP**:

```
POST https://apivida.suramericana.com.co/secure/aseguramiento/ms/accountingprocess/v1/procesos-contables-arl/ohi/healthcarepayments
useCase: SendFinancialMessageClient      auth: BasicAuthentication
```

Lo recibe **`1015-contabilizador_arl-procesos-contables-ohi-arl-ms`**, que lo
transforma y lo lleva a SAP. El ciclo completo —OHI, contabilizador, SAP y la
legalización— está diseñado en `PLAN_ARQUITECTURA_CICLO_CM.md` de ese
repositorio; aquí solo queda el lado de OHI.

```mermaid
sequenceDiagram
    autonumber
    participant M as Motor OHI
    participant BFO as basefinancialobjects
    participant FT as financialtransactions
    participant IP as Financial Message Claims IP
    participant CO as contabilizador 1015
    participant SAP as SAP

    M->>BFO: cuenta FINALIZED, crea objeto financiero
    Note over BFO: si es reserva, no se crea<br/>(reservation.financial = false)
    BFO->>FT: transaccion con totalAmount y version
    FT->>FT: actividad GENERATE_FIN_MESSAGES_*
    FT->>IP: finMessageId, finMessageResult = MessageCreated
    IP->>CO: POST /procesos-contables-arl/ohi/healthcarepayments
    CO->>SAP: asiento (sociedad, tipoProcesoSAP, fechaContable...)
    SAP-->>CO: resultado
    CO-->>IP: 200

    alt la cuenta se desfinaliza
        M->>FT: actividad SUPERSEDE
        FT->>FT: finMessageResult = Superseded
    end
```

Del lado de OHI lo que hay que saber es la cadena de cuatro saltos
(`claims` → `basefinancialobjects` → `financialtransactions` →
`financialtransactionprocessdata`) y el contrato de resultado
(`finMessageResult`: `MessageCreated` / `NotRequired` / `Superseded`), que está
en [03 — La cadena financiera](03-modelo-de-datos.md#la-cadena-financiera).

Dos propiedades gobiernan este camino:

- `ohi.claims.reservation.financial = false` — **las reservas no generan mensaje
  financiero**. Es la explicación de por qué hay 276.098 cuentas y 65.283
  objetos financieros.
- `ohi.service.financialmessage.client.authentication = BasicAuthentication`.

Las actividades que lo producen son `GENERATE_FIN_MESSAGES_EMBEDDED`,
`GENERATE_FIN_MSG_XML`, `GENERATE_FIN_MSG_FLAT_FILE`, y para reenviar o anular,
`RESEND_FIN_MSG_*` y `UNSEND_FIN_MSG_*`. También existe
`POST /financialtransactionsets/{id}/close` para cerrar un conjunto.

### La consulta de afiliación

```
POST https://apivida.suramericana.com.co/secure/aseguramiento/mi/afiliaciones/v1/eventosohi
useCase: PolicyEnrollmentClient      auth: None
```

`ohi.ws.enrollmentresponse.request.enabled = true`,
`ohi.enrollment.server.read.timeout = 30000`,
`ohi.enrollment.server.status.operation = api/enrollments`.

**La autenticación de este endpoint es `None`.** Es el único de los 21 sin
autenticación configurada, y vale la pena saberlo: la protección depende
enteramente del gateway y de la red.

Esta es la pieza que suple la ausencia de OHI *Policies*/*Enrollment*: la
afiliación se consulta hacia afuera en el momento de adjudicar. Un timeout de 30
s en afiliaciones se traduce en cuentas que no avanzan.

### Los extractos

```
POST https://prod.sura.ohi.ocs.oraclecloud.com/prod/oig/api/notifications
useCase: gateway      auth: OAuth
```

Único endpoint con **OAuth** (`ohi.service.gateway.client.authentication = OAuth`)
y el único cuyo destino es interno a la nube de Oracle: es **OIG**, el Oracle
Insurance Gateway, desplegado en el mismo tenant (`/prod/oig/`). Los extractos
(`extracts`, `SELECT_EXTRACT_ITEMS`, `PROCESS_EXTRACT_ITEMS`) notifican ahí su
finalización y OIG se encarga de la entrega.

## Lo que entra a OHI

Dos caminos, y son muy distintos en garantías.

### El API, con los clientes OAuth

Todo lo demás entra por el API REST con un token de IDCS
([01 — Autenticación](01-plataforma-y-entorno.md#autenticación)). El dato clave
para auditar: **cada `client_id` es un usuario de OHI**, y `createdBy` /
`lastUpdatedBy` dicen qué integración escribió cada registro.

| Usuario | `loginName` (= `client_id`) | Cuentas creadas |
|---|---|---:|
| `431` | `d29d344485ea49f9b50b0c42cb4cd708` | 233.934 |
| `35861` | `523c1af79ec04fb4a3ac6d8dd7e76672` | 36.679 |
| `10` | Internal System User | 305 |
| otros 31 | usuarios humanos | el resto |

El `431` es el `client-id` que usa **este** microservicio y el que aparece en
`application.yml` del perfil `prod`. Como varios servicios comparten la
credencial, OHI no los distingue entre sí: si hace falta trazabilidad por
servicio, hay que pedir clientes OAuth separados.

#### Quién consume qué

**`937-ohi_arl_cuentasmedicas-ms`** es el consumidor principal. Usa 25 rutas
genéricas y 2 específicas:

```
/generic/claims                          /generic/claims/search       /generic/claims/{id}
/generic/ctrclaims/search                /generic/externalclaimsdata
/generic/persons/search                  /generic/persons/{personId}
/generic/providers/search                /generic/organizationproviders/search
/generic/providergroupaffiliations/search
/generic/procedures/search               /generic/proceduregroups     /generic/proceduregroupdetails
/generic/specialties/{id}                /generic/relations/search
/generic/feeschedules                    /generic/feeschedulelines
/generic/providerpricingclauses/search   /generic/draftproviderpricingclauses
/generic/pricingworksheets
/claims/{id}/submit                      /claims/{claimId}/resolvepend/{motivoId}
```

Y expone, bajo `apivida.suramericana.com.co`:

| Contexto | Controlador | Qué recibe |
|---|---|---|
| `/v1/cm` + `/envio-factura-bandeja` | `NotificacionBandejaController` | el evento de escalamiento a bandeja de OHI |
| `/v1/cm` + `/homologar-estado-cuenta-medica` | `HomologarEstadoCuentaMedicaController` | el evento de homologación de estado |
| `/v1/cm` + `/crear-anticipo` | `GastosTrasladoController` | el evento de creación de factura GT |
| `/v1/rips` + `/radicacion-cabeceras`, `/radicacion-carga-masiva`, `/validar_ingreso_rips`, `/validar-radicado` | los de radicación | la radicación de RIPS y la carga masiva |
| `/v1/fe` + `/factura`, `/carta` | factura electrónica y carta | |

Es decir: **937 está a los dos lados.** Recibe eventos de OHI y también escribe
en OHI. Es el servicio que radica las cuentas, el que las escala y el que las
borra cuando ATEP las rechaza.

Además consume RabbitMQ para la carga masiva (topología replicada del MI) y
tiene su propio umbral de cuenta grande (`OHI_LIMITE_LINEAS_CUENTA_GRANDE = 250`),
que **no es el de OHI** (25.000). Son dos cosas distintas: el de 937 decide cómo
trocea la radicación, el de OHI cuándo crea subcuentas.

**`1015-contabilizador...`** solo usa `/claims/search`: recibe el mensaje
financiero por push y consulta OHI para completar datos.

**`ms-auditoria-cuenta-medica`** (este repositorio) consume el núcleo de
consulta y las operaciones de cuenta a través de la ACL en
`infraestructura/adaptadores/acl-ohi`. El detalle de su API está en el
[README](../../README.md).

### Las importaciones por lote

El otro camino de entrada son los ficheros. `POST /datafilesets` sube el
conjunto, y una actividad lo procesa. Las importaciones configuradas en prod:

| Actividad | Qué importa |
|---|---|
| `LARGE_CLAIM_IMPORT` + `LARGE_CLAIM_LINE_IMPORT` | cuentas grandes y sus líneas |
| `PROVIDER_IMPORT` | prestadores |
| `PROCEDURE_IMPORT` | prestaciones |
| `DIAGNOSIS_IMPORT` | diagnósticos |
| `RELATION_IMPORT` | relaciones |
| `REGISTRATION_IMPORT` | registros |
| `FEE_SCH_LINE_IMPORT` | líneas de tarifario |
| `DRAFT_PROVIDER_PRC_IMPORT` | cláusulas de tarifación en borrador |
| `PROD_BEN_SPEC_IMPORT` | especificaciones de beneficio de producto |
| `CONSUMPTION_IMPORT` | consumos |
| `REFSHEETLINE_IMPORT` | hojas de referencia |
| `PEND_RESO_BATCH_IMPORT` | resolución masiva de pendientes |
| `REPROCESSCLAIMS_IMPORT` | reproceso masivo de cuentas |
| `INSURABLEOBJECT_IMPORT` | objetos asegurables |

**Todo fichero pasa por el antivirus ICAP antes de procesarse**
(`ohi.antivirus.scan.enabled = true`). Si el escaneo falla, la carga no avanza y
el síntoma es «no hizo nada». Es lo primero que mirar.

## Los puntos de salida que existen pero no se usan

Vale la pena conocerlos porque son capacidad disponible sin desarrollo:

| Punto | Qué permitiría |
|---|---|
| `Claims Technical Error IP` | **notificar los errores técnicos del motor**. Hoy no hay nadie escuchando; los 238.169 errores de tarea se descubren sondeando |
| `Claim Callout IP` | consultar un sistema externo **en medio** de la adjudicación y usar la respuesta (`claimscalloutresponse`, `CalloutRule*`) |
| `Claim Transaction Event IP` | emitir eventos sobre `ctrclaims`, no sobre `claims` |
| `Activity Integration Point` | notificar fin de actividad de lote |
| `Claims Out IP` | entregar transacciones de cuenta por fichero (`claimstransactionout`) |
| `Workflow IP` | flujo configurable (apagado: `ohi.workflowtaskdone.enabled = false`) |

El primero es el que más se echa de menos. Está en
[06 — Operación](06-operacion.md).

## Resumen de autenticación saliente

| Destino | Autenticación |
|---|---|
| los 18 eventos de cuenta (`ClaimsEventClient`) | `BasicAuthentication` |
| el mensaje financiero | `BasicAuthentication` |
| la carta al prestador (`RE_CCM_CM_GLOSADA`) | `BasicAuthentication` |
| afiliaciones (`PolicyEnrollmentClient`) | **`None`** |
| OIG (`gateway`) | `OAuth` |

Las credenciales de los clientes salientes se administran por
`GET/PUT/DELETE /credentials/{code}` y los almacenes de claves por
`/keystores`. El almacén de secretos es `ohistore`
(`ohi.secure.secrets.store`). Nada de eso está en el repositorio ni debe estarlo.

OHI espera hasta **10 minutos** la respuesta de cualquiera de estos destinos
(`ohi.ws.client.readtimeout = 600000`). Un receptor lento no le da error: le
bloquea un hilo de proceso.
