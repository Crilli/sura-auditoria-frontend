# 06 — Operación

Cómo trabaja OHI por dentro, qué se rompe y dónde se ve.

## El motor son dos colas

OHI no procesa nada de forma sincrónica. Todo pasa por dos mecanismos distintos
que es importante no confundir:

| | **Tareas** (`tasks`) | **Actividades** (`activities`) |
|---|---|---|
| Qué son | los pasos del ciclo de una cuenta | los trabajos de lote |
| Granularidad | una por cuenta y paso | una por ejecución, con hijas |
| Volumen en prod | **5.750.245** | **2.506.660** |
| Tipos configurados | 74 | 89 |
| Se reintentan con | `POST /taskprocessing/{id}/restart` | `POST /activities/{activityId}/recover` |
| Catálogo | `tasktypes` | `activitytypes` |

```mermaid
flowchart TB
    subgraph T["Tareas — 5.750.245 — una por cuenta y paso"]
        direction LR
        T1["Initialize<br/>prio 8"] --> T2["SanityChecks<br/>prio 7"] --> T3["PrePricing / Pricing<br/>prio 5"] --> T4["PreBenefits / Benefits<br/>prio 3"] --> T5["Adjudicate<br/>prio 2"] --> T6["Finalize<br/>prio 1"]
        T6 --> T7["ClaimsEvent<br/>prio 9"]
        T6 --> T8["FinancialMessage<br/>prio 8"]
    end

    subgraph A["Actividades — 2.506.660 — trabajos de lote, max 15 padres en paralelo"]
        direction LR
        A1["*_IMPORT<br/>padre"] --> A2["*_IMPORT_READER<br/>un fichero"] --> A3["*_CHUNK_PRC<br/>un trozo"]
        A4["FINPROC"] --> A5["GENERATE_FIN_MSG_*"]
        A6["SELECT_REPROCESSCLAIMS"] --> A7["SUBMIT_REPROCESSCLAIM_REQ"]
    end

    T -.->|"restart: POST /taskprocessing/{id}/restart"| T
    A -.->|"recover: POST /activities/{id}/recover"| A

    EST{{"estado de la tarea"}}
    EST --> S1["COMPLETE 4.204.848"]
    EST --> S2["SHADOWED 1.306.381<br/><i>no es error: la dejo sin efecto<br/>un reenvio posterior</i>"]
    EST --> S3["ERRORED 238.194"]
    EST --> S4["DISMISSED 2.294"]

    S3 --> CE["ClaimsEvent 238.075<br/><b>99,95%</b>"]
    S3 --> PR["proceso real 106<br/>Adjudicate 98, Benefits 5,<br/>Initialize 2, Finalize 1"]

    classDef mal fill:#ffebee,stroke:#c62828
    classDef ok fill:#e8f5e9,stroke:#2e7d32
    classDef neutro fill:#f5f5f5,stroke:#9e9e9e
    class S3,CE mal
    class S1 ok
    class S2,S4 neutro
```

Una cuenta que se envía genera una cadena de tareas (`Initialize` →
`SanityChecks` → `PrePricing` → `Pricing` → `PreBenefits` → `Benefits` →
`Adjudicate` → `Finalize`), cada una con su prioridad. La lista completa con
prioridades está en
[03 — El ciclo de vida](03-modelo-de-datos.md#el-ciclo-de-vida-de-una-cuenta).

Las actividades son otra cosa: importaciones, generación de mensajes
financieros, reproceso masivo, resolución masiva de pendientes, troceo de
*large claims*. Corren como máximo **15 actividades padre en paralelo**
(`ohi.processing.max.concurrentparentactivities.size`).

## Estado de las tareas

| Estado (código en `q`) | Filas | Qué significa |
|---|---:|---|
| `COMPLETE` | 4.204.848 | terminó bien |
| `SHADOWED` | 1.306.381 | una tarea posterior la dejó sin efecto |
| **`ERRORED`** | **238.194** | falló |
| `DISMISSED` | 2.294 | descartada a mano |
| `PROCESSING` | 0 | en curso ahora mismo |

Los códigos van en **mayúsculas** en `q`: `status.eq("ERRORED")`. Con `groupBy`
salen las etiquetas (`Errored`, `Complete`, `Shadowed`), que **no sirven para
filtrar** — es la trampa de
[02 § 2](02-api-y-lenguaje-de-consulta.md#2-groupby-devuelve-etiquetas-q-filtra-por-códigos).

`SHADOWED` es el estado que más confunde: no es un error. Cuando una cuenta se
reenvía, las tareas pendientes de la pasada anterior quedan sin efecto y OHI las
marca así. Que haya 1,3 millones es normal en un sistema donde se reenvía y se
desfinaliza mucho.

### Casi todos los errores son de notificación, no de proceso

Este es el dato que cambia la lectura del `238.194`. Desglosado por tipo:

| Tipo de tarea | `ERRORED` |
|---|---:|
| **`ClaimsEvent`** | **238.075** |
| `Adjudicate` | 98 |
| `Benefits` | 5 |
| `Initialize` | 2 |
| `Finalize` | 1 |
| `CtrClaimEvent`, `FinancialMessage`, `Pricing`, `ClaimImport`, `Enrollment`, `TaskDoneEvent`, `UnifiedEvent`, `NotificationEvent`, `ActivitySubmission`, `SynchronousTask` | 0 |

**El 99,95% de los errores de OHI son entregas de eventos salientes que
fallaron.** La adjudicación en sí casi no falla: 106 tareas de proceso en error
sobre 276.098 cuentas.

Eso reencuadra el problema. La bolsa de errores no dice «OHI está roto»; dice
**«hay notificaciones que no llegaron a sus destinatarios»**, y cada una es una
cuenta que no apareció en una bandeja, una carta que no se envió o un siniestro
que no se actualizó. El síntoma en negocio no es un error: es una ausencia.

Y encaja con lo que falta del lado de la integración: **no hay
`Claims Technical Error IP` configurado**
([05](05-integraciones.md#los-puntos-de-salida-que-existen-pero-no-se-usan)), así
que nadie se entera salvo que alguien pregunte.

### Cómo buscar y reiniciar

```mermaid
flowchart TB
    START["tareas ERRORED en la ventana"] --> Q1{"taskType = ClaimsEvent?"}
    Q1 -- no --> PROC["fallo de proceso real<br/>mirar el mensaje de la tarea<br/>y la cuenta"]
    Q1 -- si --> URI["buscar el destino:<br/>taskattributes name=uri<br/>valueChar like '%/ruta'"]
    URI --> Q2{"el destino esta sano<br/>ahora mismo?"}
    Q2 -- no --> ESPERA["no reintentar todavia:<br/>arreglar el receptor primero"]
    Q2 -- si --> TANDA["tanda de 40<br/>2 s entre reinicios"]
    TANDA --> VER["antes de cada tanda<br/>comprobar que sigan ERRORED"]
    VER --> Q3{"de las resueltas,<br/>recae 30% o mas?"}
    Q3 -- si --> FRENO["frenar: no es transitorio.<br/>NO usar dismiss: la cuenta<br/>sigue sin su evento y<br/>desaparece de la cola"]
    Q3 -- no --> SIGUE{"quedan tareas?"}
    SIGUE -- si --> TANDA
    SIGUE -- no --> FIN["listo"]

    classDef mal fill:#ffebee,stroke:#c62828
    classDef ok fill:#e8f5e9,stroke:#2e7d32
    class FRENO,ESPERA mal
    class FIN ok
```

La consulta base, con la ventana de tiempo y el tipo:

```json
{
  "resource": {
    "q": "status.eq(\"ERRORED\").and.taskType.name.eq(\"ClaimsEvent\").and.creationDate.bet(\"2026-10-01T00:00:00.000Z\",\"2026-10-07T12:00:00.000Z\").and.(subjectCode.like(\"%CM%\").or.subjectCode.like(\"%RE%\").or.subjectCode.like(\"%GT%\").or.subjectCode.like(\"%RC%\"))",
    "limit": 200, "orderBy": "id:asc", "totalResults": true
  }
}
```

Nótese que **el join sí funciona en `q`** (`taskType.name.eq(...)`) aunque no
funcione en `groupBy`. `subjectCode` trae el código de la cuenta afectada, que es
lo que permite cruzar con negocio.

Para saber **a qué endpoint iba** el evento que falló hay que mirar los atributos
de la tarea, no la tarea: el atributo `uri` está en `taskattributes` y se
consulta al revés —desde el atributo hacia la tarea—:

```json
{ "resource": { "q": "name.eq('uri').and.valueChar.like('%/envio-factura-bandeja').and.task.status.eq('ERRORED')" } }
```

El reintento es `POST /taskprocessing/{id}/restart`, de una en una, o
`POST /taskprocessing/tasks/restart` para un lote (con
`GET /taskprocessing/taskrestartbatches/{id}/status` para seguirlo). También
existe `POST /tasks/{id}/process` y, para rendirse con una tarea,
`POST /tasks/{id}/dismiss`.

> **Dos cuidados al reiniciar en masa**, aprendidos en producción:
>
> 1. **Comprobar antes de cada tanda que las tareas sigan en `ERRORED`.** Otras
>    personas y procesos trabajan sobre la misma cola; reiniciar una que ya se
>    resolvió desplaza las páginas siguientes y se pierden filas.
> 2. **Frenar si vuelven a fallar.** Si de las tandas resueltas un 30% o más
>    recae en `ERRORED` con el mismo error, el problema no es transitorio y
>    reintentar solo gasta. Y `dismiss` es peor que dejarla: la cuenta sigue sin
>    su evento y además desaparece de la cola, donde al menos era visible.
>
> El procedimiento completo, con ritmo, tandas y criterios de parada, está en la
> *skill* `ohi-reiniciar-tareas` de `.claude/skills/`.

## Estado de las actividades

| Estado | Filas |
|---|---:|
| `Completed` | 2.506.208 |
| `TechnicalError` | 210 |
| `BusinessError` | 134 |
| `CompletedWithTechErrors` | 96 |
| `CompletedWithBussErrors` | 16 |

Los lotes están sanos. Los dos estados «Completed­With…» son los peligrosos:
**la actividad terminó, pero algunas de sus filas fallaron.** Un lote que acaba
en `CompletedWithBussErrors` se ve verde en un panel y dejó registros sin
procesar; hay que mirar `activitymessages` para saber cuáles.

Los mensajes de una actividad: `GET /activities/{activityId}/messages`.
Recuperarla: `POST /activities/{activityId}/recover`. Lanzarla:
`POST /activities/start` o `POST /activities/{activityId}/start`.

### Las actividades que importan

Agrupadas por lo que hacen (las 89 están en `activitytypes`):

**Importación** — `*_IMPORT`, con su `*_IMPORT_READER` y su
`*_IMPORT_CHUNK_PRC`. El patrón es siempre el mismo: una actividad padre lee el
conjunto de ficheros, una hija lee cada fichero y una nieta procesa cada trozo.
Cuando una importación «no hizo nada», el error casi siempre está en la nieta.

**Financieras** — `FINPROC` (el proceso financiero general),
`GENERATE_FIN_MESSAGES_EMBEDDED`, `GENERATE_FIN_MSG_XML`,
`GENERATE_FIN_MSG_FLAT_FILE`, `SEND_FIN_MESSAGE`, `SUPERSEDE`,
`SELECT_TRANSACTIONS_IN_SET`, y para corregir, `RESEND_FIN_MSG_*` y
`UNSEND_FIN_MSG_*`.

**Large claims** — `LARGE_CLAIMS_SUBMIT`, `LARGE_CLAIM_IMPORT`,
`LARGE_CLAIM_LINES_SPLIT`, `LARGE_CLAIM_LINES_ON_MBR_GC`,
`LARGE_CLAIM_LINES_ON_SEQ`, `LC_SC_REPLACEMENT`, `LARGE_CLAIM_REPLACEMENT`,
`UNFINALIZE_LARGE_CLAIM` (+ `_CHILD`), `SUB_CLAIMS_PROCESS_CHD`.

**Masivas sobre cuentas** — `PEND_RESOLUTION_CRITERIA` +
`SUBMIT_PEND_RESO_CRITERIA_REQ` (resolver pendientes por criterio),
`SELECT_REPROCESSCLAIMS` + `SUBMIT_REPROCESSCLAIM_REQ` (reprocesar),
`ADD_MESSAGE` + `ADD_MESSAGE_CHILD` (añadir mensajes), `RESOLVE_PEND` +
`RESOLVE_PEND_CHILD`.

**Salida** — `CLAIMS_OUT`, `CREATE_CLAIMS_OUT_RESPONSE`,
`SELECT_EXTRACT_ITEMS`, `PROCESS_EXTRACT_ITEMS`.

Las de reproceso y resolución masiva tienen su API en `specific`:
`POST /claimsreprocess`, `POST /claimsreprocesscriteria`,
`POST /claimsreprocesscount` (para saber cuántas tocaría **antes** de lanzarlo),
`POST /pendresolutionbatch`, `POST /pendresolutioncriteria`.

> `claimsreprocesscount` antes de `claimsreprocess`. Un reproceso mal acotado
> vuelve a pasar por adjudicación miles de cuentas finalizadas, y cada una
> dispara sus ocho eventos salientes.

## Qué vigilar

Por orden de utilidad:

| Señal | Cómo se mide | Por qué |
|---|---|---|
| Tareas `ERRORED` de `ClaimsEvent` creadas hoy | `tasks` con `status.eq("ERRORED")` + `creationDate` | cada una es una notificación que no llegó |
| Cuentas atascadas en `MANUAL ADJUDICATION` | `claims` con `status.eq("MANUAL ADJUDICATION")` | hoy 7.154; el crecimiento es lo que importa |
| Pendientes de línea sin resolver | `claimlinependreasons` con `resolved.eq(false)` | hoy 200.657 |
| Actividades `CompletedWith*Errors` | `activities` | lotes verdes con filas perdidas |
| `finMessageResult` nulo | `financialtransactionprocessdata` | hoy 262 transacciones sin procesar |
| Líneas sin prestador derivado | ver la *skill* `ohi-lineas-sin-prestador` | el incidente recurrente de `serviceProviderCodeDef` |
| Cargas que no avanzan | `datafilesets` y el escaneo ICAP | el antivirus corta en silencio |

Hay además métricas Prometheus expuestas, con percentiles configurados en 0,5 /
0,75 / 0,95 para los temporizadores de lógica dinámica, recursos, cliente de
recursos y encolado/desencolado de tareas
(`ohi.instrumentation.*`). Y `ohi.instrumentation.gather.*` recoge JVM, GC,
sistema y métricas de aplicación.

## Los registros

`ohi.logging.target = database`: los registros de OHI **no son ficheros**, son
tablas, y se consultan por el API:

| Recurso | Qué guarda |
|---|---|
| `logapplicationevents` | el registro de aplicación (nivel, logger, hilo, host, instancia, mensaje) |
| `logdynamiclogicevents` | lo que emite la lógica dinámica, con `scriptExecutionId` |
| `logphievents` | los accesos a datos personales: usuario, recurso, método, token, sesión |
| `logsecurityevents` | eventos de seguridad — **sin autorización para el cliente OAuth de prod** |
| `systemeventlogs` | eventos de sistema con `resolved`, `module`, `workID` |
| `logeventretentionperiods` | cuánto se guarda cada clase de registro |

`logphievents` es la pista de auditoría de datos sensibles y merece respeto: deja
constancia de cada lectura. `logsecurityevents` es el único recurso de los 453 al
que este cliente no tiene acceso ([01](01-plataforma-y-entorno.md#lo-que-este-cliente-no-puede)).

Para diagnosticar lógica dinámica lenta: `/dynamiclogicstatistics` da
ejecuciones, tiempo transcurrido, memoria asignada y filas leídas, por código de
lógica, y `POST /dynamiclogicstatistics/reset` reinicia el contador.
`POST /dynamiclogic/invalidateall` y `POST /nonentitycache/invalidateall`
invalidan cachés — con cuidado en producción, porque el siguiente proceso
recompila todo.

## Purga

`POST /purge/claims` y `POST /purge/authorizations`, con `GET /purge/claims/{id}`
para seguir el progreso. La configuración está en `autopurgemetadata` y hay un
`exemptFromPurging` en `externalclaimsdata` para marcar cuentas que no se deben
purgar. `ohi.incident.target = datafileset`: los resultados de incidentes salen
como conjuntos de ficheros.

## Transferencia de datos entre entornos

Para mover configuración entre entornos (no datos de negocio):
`POST /datatransfer`, `/import/datasetdefinition/{code}`,
`/export/datasetdefinition/{code}/dataset/{dataSetCode}`,
`/createandexport/datasetdefinition/{code}/dataset`.

Los campos `createdByDataSet`, `createdByEnvironment`, `lastUpdatedByDataSet` y
`lastUpdatedByEnvironment` que llevan casi todas las entidades de configuración
dicen **de qué entorno vino cada pieza**. Es la forma de saber si una regla se
configuró en prod o se importó de un entorno anterior, y el `uuid` la identifica
a través de los entornos.
