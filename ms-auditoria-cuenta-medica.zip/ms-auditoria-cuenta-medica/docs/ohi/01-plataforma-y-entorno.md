# 01 — Plataforma y entorno

## Qué corre en prod

| | |
|---|---|
| Producto | Oracle Health Insurance **Claims Adjudication and Pricing** |
| Versión | **4.25.1.0.23** |
| Identificador de aplicación | `CLA` |
| Identificador de entorno | `prod-Claims` |
| Despliegue | `cloud` — Oracle Cloud Infrastructure, región `us-ashburn-1` |
| Idioma | español (`Content-Language: es`; los mensajes de error vienen traducidos) |

La versión y el identificador no están en ningún endpoint de versión: OHI los
manda en **las cabeceras de toda respuesta**.

```
X-Ohi-App-Id: CLA
X-Ohi-App-Version: 4.25.1.0.23
```

Eso importa más de lo que parece. La documentación de Oracle está versionada y
la de una rama distinta miente en los detalles: hay recursos y operaciones que
cambiaron entre 3.x y 4.x. Antes de creerle a una página de `docs.oracle.com`,
comprueba que la URL diga `claims-4.25.1`.

Las mismas respuestas traen cabeceras de traza útiles para pedirle a Oracle que
busque un incidente: `X-Oracle-Dms-Ecid`, `X-B3-Traceid`, `X-B3-Spanid`.

## Direcciones

| Qué | Dónde |
|---|---|
| Raíz del API | `https://prod.sura.ohi.ocs.oraclecloud.com/prod/claims/api` |
| Interfaz de usuario | `https://prod.sura.ohi.ocs.oraclecloud.com/prod/claims/ui` |
| Salud | `GET /health` → `{"status": "UP"}` |
| Catálogo | `GET /` → dos colecciones: `generic` y `specific` |
| Métricas | Prometheus habilitado (`ohi.prometheusservlet.url.mapping`) |

`GET /` es el punto de entrada del descubrimiento y conviene conocerlo: desde
ahí se llega a todo sin tener ninguna ruta escrita a mano.

```
GET /                       → { generic, specific }
GET /generic                → 453 recursos, cada uno con sus enlaces
GET /specific               → 70 endpoints de operación
```

Cada recurso de `/generic` publica cinco enlaces, y dos de ellos son los que
convierten a OHI en autodescriptivo:

| Enlace | Para qué |
|---|---|
| `canonical` | la colección |
| `create-form`, `edit-form` | existen **solo si** el recurso admite alta o modificación |
| `describedBy` → `/metadata` | el OpenAPI 3.0.1 del recurso |
| `oi:definition` → `/definition` | el esquema de la entidad con los atributos propios de OHI |

La presencia o ausencia de `create-form` / `edit-form` es la respuesta
autorizada a «¿puedo escribir esto por API?». De los 453 recursos: **223**
admiten crear y editar, **8** solo editar, **2** solo crear y **220** son de
solo lectura. El detalle está en el [Anexo A](anexo-a-recursos.md).

## Autenticación

Dos mundos distintos, y conviene no confundirlos.

**El API** usa OAuth2 *client credentials* contra Oracle Identity Cloud
Service (IDCS). El `client_id` y el secreto van como `Basic` en el encabezado y
el `scope` en el cuerpo:

```
POST https://idcs-fc4a28e7a1fe4ad8954b17c5362764ae.identity.oraclecloud.com/oauth2/v1/token/
Authorization: Basic base64(client_id:client_secret)
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&scope=https://prod.sura.ohi.ocs.oraclecloud.com/prod/urn::ohi-components-apis
```

El token vive **3.600 segundos**. Este microservicio lo cachea 50 minutos
(`integraciones.ohi.cache-token.expiracion`) para no usar uno vencido; el
mecanismo está en
[`ProveedorTokenOhi`](../../infraestructura/adaptadores/acl-ohi/src/main/java/co/sura/auditoria/acl/ohi/cliente/ProveedorTokenOhi.java).

**La interfaz de usuario** usa SSO por WebGate, y es obligatorio:
`ohi.security.sso.enabled = true`, `ohi.security.sso.required = true`, con la
identidad en el encabezado `remote_user`. La sesión dura una hora
(`ohi.ui.session.timeout = 3600000`). No hay forma de entrar a la UI con el
cliente OAuth ni al API con la sesión de la UI.

### Cada cliente OAuth es un usuario de OHI

Esto no es obvio y explica muchas cosas. Cuando un cliente OAuth escribe en
OHI, OHI le crea (o le reusa) un **usuario propio cuyo `loginName` es el
`client_id`**. Los dos que mueven el volumen en prod:

| `id` de usuario | `loginName` | Creado | Cuentas creadas |
|---|---|---|---|
| `431` | `d29d344485ea49f9b50b0c42cb4cd708` | 2023-01-27 | 233.934 |
| `35861` | `523c1af79ec04fb4a3ac6d8dd7e76672` | 2023-11-23 | 36.679 |

El primero es el `client-id` que usa este microservicio (y los demás que
comparten la credencial). Hay **34 creadores distintos** en total: los dos
clientes de integración, el usuario interno `10` («Internal System User», el que
usa OHI para sus propios procesos) y una treintena de usuarios humanos.

La consecuencia práctica: `createdBy` y `lastUpdatedBy` de cualquier registro
dicen **qué integración lo escribió**, y `createdByUserName` lo resuelve a texto
sin necesidad de un join. Es la mejor herramienta que hay para auditar quién
tocó una cuenta. Y también el límite: si dos microservicios comparten el mismo
`client_id`, OHI no los distingue.

### Credenciales

El secreto vive en `.env` en la raíz de este repositorio, excluido por
`.gitignore`, y se inyecta por variable de entorno:

```
OHI_CLIENT_SECRET_PROD     # el único obligatorio; el resto tiene valor por omisión
```

Los demás valores (`OHI_URL_BASE_PROD`, `OHI_TOKEN_URL_PROD`,
`OHI_CLIENT_ID_PROD`, `OHI_SCOPE_PROD`) están como predeterminados en
`application.yml`, así que el perfil `prod` arranca exportando solo el secreto.
La plantilla completa está en `.env.ejemplo`.

Si vas a consultar OHI desde la línea de comandos, **pasa el secreto a `curl`
por stdin** con un fichero de configuración (`curl -K -`), nunca como argumento:
los argumentos quedan en la tabla de procesos y en el historial del shell.

```bash
printf 'url = "%s"\nuser = "%s:%s"\ndata = "grant_type=client_credentials"\ndata = "scope=%s"\nsilent\n' \
  "$OHI_TOKEN_URL_PROD" "$OHI_CLIENT_ID_PROD" "$OHI_CLIENT_SECRET_PROD" "$OHI_SCOPE_PROD" \
  | curl -K - | python3 -c 'import sys,json; print(json.load(sys.stdin)["access_token"])'
```

### Lo que este cliente no puede

El cliente OAuth de producción no tiene permiso sobre todo. De los 453 recursos,
exactamente uno responde `403 GEN-HTTP-004` («No autorizado para esta operación
en este recurso»):

- `logsecurityevents` — el registro de eventos de seguridad.

Que los otros 452 contesten no significa que se pueda escribir en ellos: la
autorización de escritura se comprueba al escribir, y las restricciones de
acceso a datos (`accessrestrictions`, `dataaccessgroups`) filtran **filas**, no
recursos. En prod hay cuatro grupos de acceso a datos:
`GA_CM_MONOUSUARIO_SURA`, `GA_AUTORIZACIONES`, `GA_OTRAS_CUENTAS_MEDICAS` y
`GA_CM_ANTICIPOS`.

## La configuración de prod que cambia el comportamiento

`GET /currentproperties` devuelve las **101 propiedades vigentes**. Las que
alteran lo que uno observa en los datos:

| Propiedad | Valor | Por qué importa |
|---|---|---|
| `ohi.claim.split` | `true` | El troceo de *large claims* está activo |
| `ohi.subclaim.claimline.threshold` | `25000` | Una cuenta se parte en subcuentas al pasar de **25.000 líneas** |
| `ohi.claims.reservation.financial` | `false` | **Las reservas no generan mensaje financiero.** Explica por qué hay 202.854 reservas y solo 65.283 objetos financieros |
| `ohi.processing.max.concurrentparentactivities.size` | `15` | Tope de actividades padre en paralelo: el techo del rendimiento de los lotes |
| `ohi.ws.client.readtimeout` | `600000` | OHI espera hasta **10 minutos** la respuesta de un servicio externo |
| `ohi.enrollment.server.read.timeout` | `30000` | 30 s para la consulta de afiliación |
| `ohi.logging.target` | `database` | Los registros de OHI van a la base, no a ficheros |
| `ohi.query.api.enable.sqlmonitorreport` | `false` | El encabezado `enablesqlmonitorreport` **no funciona en prod** |
| `ohi.antivirus.scan.enabled` | `true` | Todo fichero cargado pasa por ICAP antes de procesarse |
| `ohi.baseview.exclude.pii` | `true` | Las vistas base excluyen datos personales |
| `ohi.httpapi.cache.control.enable` | `true` | Los `/metadata` se sirven cacheados |
| `ohi.workflowtaskdone.enabled` | `false` | El punto de integración de fin de flujo está apagado |
| `ohi.ws.paymentstatusresponse.request.enabled` | `false` | No se consulta estado de pago hacia afuera |
| `ohi.ws.enrollmentresponse.request.enabled` | `true` | Sí se consulta afiliación hacia afuera |

Las propiedades marcadas de solo lectura no se cambian por API: hay que pedirlo
a Oracle. Las demás son editables y conviene no tocarlas sin entender el
alcance: `ohi.subclaim.claimline.threshold`, por ejemplo, cambia la forma de las
cuentas futuras pero no reparte las existentes.

### Dos enlaces a documentos externos

La UI de OHI enlaza al gestor documental de Sura para ver los soportes:

```
ohi.ui.httplink.p8          → https://p8app.suranet.com/ServiciosRest/web/ConsultasP8MainAutonoma?...NMNroFactura={{param0}}
ohi.ui.httplink.p8.reembolso → ...NMNroRadicado={{param0}}
```

Es decir, la factura se busca en P8 por **número de factura**, y el reembolso
por **número de radicado**. Está en la configuración, no en el código.

## Antivirus de ficheros

Todo fichero que entra por `datafilesets` se escanea por ICAP contra
`icap-gbu.p.c.scs.us-ashburn-1.ocs.oracleiaas.com:1344` (servidor `AVSCAN`), con
1 s de conexión y 5 s de lectura. Si el escaneo falla, el fichero no se procesa.
Es la primera cosa que mirar cuando una carga masiva «no hizo nada».

`ohi.datafile.object.storage.enabled` está en `false`: los ficheros no van a
Object Storage, se quedan en la base.
