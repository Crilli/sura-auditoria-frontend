# 03 — Modelo de datos

El modelo de OHI prod son **453 entidades** y **11.389 campos**. Este documento
cubre el núcleo —lo que de verdad se toca— y deja el inventario completo en los
anexos [A](anexo-a-recursos.md), [B](anexo-b-campos-nucleo.md) y
[D](anexo-d-relaciones.md).

## Los volúmenes, para calibrar

Medido el 7 de octubre de 2026. Son una foto: entran unas mil cuentas al día.

| Entidad | Filas | |
|---|---:|---|
| `claims` | 276.098 | la cuenta viva |
| `claimlines` | 852.561 | ~3,1 líneas por cuenta |
| `ctrclaims` | 395.485 | las fotos al finalizar |
| `ctrclaimlines` | 1.437.181 | |
| `claimstatushistory` | 2.641.583 | ~9,6 cambios de estado por cuenta |
| `claimmessages` | 154.660 | |
| `claimlinemessages` | **1.679.613** | ~2 mensajes por línea |
| `claimsubmithistory` | 166.243 | |
| `claimunfinalizereasons` | 42.978 | se desfinaliza mucho |
| `claimpendreasons` | 16.246 | |
| `claimlinependreasons` | 212.108 | |
| `basefinancialobjects` | 65.283 | |
| `financialtransactions` | 89.728 | |
| `financialtransactionprocessdata` | 89.728 | uno por transacción, exacto |
| `persons` | 102.483 | |
| `providers` | 6.923 | 2.491 personas + 4.432 organizaciones |
| `procedures` | **970.780** | el catálogo de prestaciones |
| `diagnoses` | 12.436 | |
| `flexcodesystems` | 4.937 | ver [04](04-extensiones-sura.md) |
| `flexcodes` | 91.091 | |
| `messages` | 1.992 | |
| `dynamiclogic` | 612 | |
| `pendreasons` | 233 | |
| `tasks` | 5.750.245 | ver [06](06-operacion.md) |
| `activities` | 2.506.660 | |
| `products` | 3 | ARL, EPS, SEGUROS SALUD |

Rango de `entryDate`: **2023-02-11** (la primera) hasta hoy.

### Lo que esta instalación no usa

Cuatro recursos del núcleo de OHI están en **cero**, y eso dice tanto del
diseño como lo que sí está lleno:

| Recurso | Filas | Qué significa |
|---|---:|---|
| `authorizations` | 0 | **Las autorizaciones no viven en OHI.** Están en ATEP y en los sistemas de reclamaciones; entran por integración |
| `authorizationlines` | 0 | lo mismo |
| `bills` | 0 | no se usa el agrupador de facturas de OHI |
| `accountingdetails` | 0 | la contabilidad se hace fuera (SAP), ver [05](05-integraciones.md) |

Y `policies` no existe como recurso: *Policies* y *Enrollment* son otras
aplicaciones de OHI que aquí no están desplegadas. La afiliación se consulta
hacia afuera (`ohi.ws.enrollmentresponse.request.enabled = true`).

Conclusión práctica: **esta es una instalación de adjudicación y tarifación, no
un núcleo de aseguramiento.** Quien busque la autorización que respalda una
línea no la va a encontrar en OHI; encontrará el código de autorización como
texto y los mensajes que resultaron de validarlo.

## Las cuatro entidades del núcleo

```mermaid
erDiagram
    claims ||--o{ claimlines : "claimLineList"
    claims ||--o{ claimmessages : "claimMessageList"
    claims ||--o{ claimpendreasons : "claimPendReasonList"
    claims ||--o{ claimstatushistory : "claimStatusHistoryList"
    claims ||--o{ claimsubmithistory : "claimSubmitHistoryList"
    claims ||--o{ claimunfinalizereasons : "claimUnfinalizeReasonList"
    claims ||--o{ claimdiagnoses : "claimDiagnosisList"
    claims ||--o{ policyproducts : "policyProductList"
    claims ||--o| externalclaimsdata : "externalClaimsData"
    claims }o--|| claims : "largeClaim (madre)"
    claims }o--|| persons : "person"
    claims }o--|| providers : "serviceProvider"
    claims }o--|| claimforms : "claimForm"
    claims }o--|| brands : "brand"
    claims }o--|| dataaccessgroups : "dataAccessGroup"

    claimlines ||--o{ claimlinemessages : "mensajes"
    claimlines ||--o{ claimlinependreasons : "pendientes"
    claimlines }o--|| procedures : "procedure"
    claimlines }o--|| providers : "serviceProvider"

    claimmessages }o--|| messages : "message"
    claimlinemessages }o--|| messages : "message"
    claimpendreasons }o--|| pendreasons : "pendReason"
    claimlinependreasons }o--|| pendreasons : "pendReason"

    externalclaimsdata }o--|| ctrclaims : "ctrClaim"
    ctrclaims ||--o{ ctrclaimlines : "ctrClaimLineList"
    ctrclaims ||--o{ ctrstatushistory : "ctrStatusHistoryList"
    ctrclaims ||--o{ ctrclaimmessages : "ctrClaimMessageList"

    claims {
        string code PK "CM- GT- RE- RC- o numerico"
        string status "FINALIZED, MANUAL ADJUDICATION..."
        string processType "C cuenta, R reserva"
        string type "P prestador, R restitucion"
        string processCategory "L madre, S subcuenta, null"
        date entryDate
        monto totalClaimedAmount
        monto totalAllowedAmount
        monto totalCoveredAmount
        number valorFactura "extension Sura"
        string numeroFactura "extension Sura"
    }
    ctrclaims {
        string code "cruza con claims.code, NO por referencia"
        int version
        boolean reversal "true = reverso de esa version"
        date transactionDateTime
        string serviceProvCode "aplanado, sin referencia"
        string formCode "aplanado"
        lista estadoCuentaMedica "DYNR, no filtrable"
    }
```

Los nombres de las cajas son los recursos tal como se llaman en `/generic`, así
que el diagrama se lee igual que la URL. Las dos cosas que conviene mirar dos
veces: `claims` se **autorreferencia** por `largeClaim` (la subcuenta apunta a
su madre), y `ctrclaims` cuelga de `externalclaimsdata`, **no** de `claims`
directamente.

`claims` tiene 186 campos, `claimlines` 195. De esos, 43 y 45 son extensiones
de Sura ([04](04-extensiones-sura.md)).

### `claims` — la cuenta viva

Los campos que clasifican una cuenta, con los **códigos almacenados** (los que
sirven en `q`) y las etiquetas que devuelve `groupBy`:

**`status`** — 11 valores en uso:

| Código almacenado | Etiqueta | Filas | Dominio |
|---|---|---:|---|
| `INITIAL` | Initial | 6 | INICIAL |
| `ENTRY` | Entry | 976 | DIGITACION |
| `CHANGE` | Change | 1.087 | MODIFICACION |
| `IN PROCESS` | InProcess | 39 | — |
| `MANUAL PRICING` | ManualPricing | 4 | TARIFACION_MANUAL |
| `MANUAL ADJUDICATION` | ManualAdjudication | **7.154** | ADJUDICACION_MANUAL |
| `PRICING DONE` | PricingDone | 2 | TARIFACION_COMPLETA |
| `BENEFITS DONE` | BenefitsDone | 98 | BENEFICIOS_COMPLETOS |
| `ADJUDICATION DONE` | AdjudicationDone | 1 | ADJUDICACION_COMPLETA |
| `SENT OUT FOR PREPROCESSING` | SentOutForPreProcessing | 3 | ENVIADA_A_PREPROCESO |
| `FINALIZED` | Finalized | **266.731** | FINALIZADA |

La columna «Dominio» es la traducción de
[`DiccionarioOhi`](../../infraestructura/adaptadores/acl-ohi/src/main/java/co/sura/auditoria/acl/ohi/DiccionarioOhi.java),
que es la única clase autorizada a conocer el vocabulario de OHI en este
repositorio. El diccionario cubre además `MANUAL BENEFITS`,
`MANUAL PRICING ADJUDICATION`, `PRICING ADJUDICATION DONE`,
`PRICING FINALIZED` y `SENT OUT FOR PRICING`, que no tienen filas hoy pero son
estados válidos del producto.

**`processType`** — qué clase de proceso es:

| Código | Etiqueta | Filas |
|---|---|---:|
| `C` | Claim | 73.247 |
| `R` | Reservation | 202.854 |

**El 73% de las filas de `claims` son reservas, no cuentas.** Es el dato que más
descoloca al principio: cualquier reporte sobre cuentas médicas tiene que filtrar
`processType.eq("C")` o se lleva tres veces más filas de las que debe.

**`type`**:

| Código | Etiqueta | Filas |
|---|---|---:|
| `P` | ProviderClaim | 266.756 |
| `R` | RestitutionClaim | 9.370 |

Todas las cuentas con código `RE-` (reembolso) son `type = R`.

**`processCategory`** — el troceo de *large claims*:

| Código | Etiqueta | Filas |
|---|---|---:|
| `L` | LargeClaimSystem | 94 |
| `S` | SubClaim | 305 |
| `null` | — | 275.730 |

Ese `null` es la causa de la trampa documentada en
[02 § 1](02-api-y-lenguaje-de-consulta.md#1-neq-descarta-los-nulos). Lee eso
antes de escribir cualquier filtro sobre este campo.

### El prefijo del código dice el tipo de cuenta

| Prefijo | Filas | Qué es |
|---|---:|---|
| `CM-` | 63.785 | cuenta médica |
| `GT-` | 7.132 | gasto de traslado |
| `RE-` | 2.235 | reembolso |
| `RC-` | 94 | recobro |
| numérico, sin prefijo | 51.519 | **reserva** |

Los prefijados suman 73.246, que es exactamente el `processType = C`. Las
reservas no llevan prefijo. Así que **el prefijo del código y el `processType`
son la misma información**, y el prefijo es más cómodo de leer en un reporte.

### Los formularios, marcas y grupos de acceso

| Catálogo | Valores en prod |
|---|---|
| `claimforms` (6) | `GENERICA`, `ANTICIPO`, `REEMBOLSO`, `RECOBRO`, `RESPUESTA_GLOSA`, `UVR_CON_ADICIONAL` |
| `brands` (4) | `ARL`, `EPS`, `SAL_COLECTIVO`, `SAL_FAMILIAR` |
| `dataaccessgroups` (4) | `GA_CM_MONOUSUARIO_SURA`, `GA_AUTORIZACIONES`, `GA_OTRAS_CUENTAS_MEDICAS`, `GA_CM_ANTICIPOS` |
| `products` (3) | `ARL`, `EPS`, `SEGUROS SALUD` |

El reparto real por formulario (medido en `ctrclaims`, que sí permite agrupar
por `formCode`): `GENERICA` 386.441, `ANTICIPO` 7.159, `REEMBOLSO` 1.846,
`RECOBRO` 67. `RESPUESTA_GLOSA` y `UVR_CON_ADICIONAL` existen en el catálogo
pero no aparecen en las transacciones.

### Los montos

`claims` lleva cuatro montos, todos como objeto `{currency, value}`:

| Campo | Qué es |
|---|---|
| `totalClaimedAmount` | lo facturado por el prestador |
| `totalAllowedAmount` | lo que la tarifación admite |
| `totalCoveredAmount` | lo que la cobertura paga |
| `totalRetentionAmount` | retenciones |

En `claimlines` los equivalentes por línea son `claimedAmount`, `allowedAmount`,
`coveredAmount`, `retentionAmount`, más `benefitsInputAmount` y
`precedingPayerPaidAmount`.

Cuatro cosas que hay que saber antes de sumar:

1. **Los montos son objetos, no números.** `float(valor)` falla. Hay que leer
   `valor["value"]`. Y en `ctrclaims` el mismo dato viene **plano** como número
   (`totalClaimedAmount`) con la moneda en un campo aparte
   (`totalClaimedAmountCurrency`). Las dos formas conviven.
2. **`paidDate` está vacío.** En las cuentas finalizadas lo pagado es
   `totalCoveredAmount`; no hay una fecha de pago poblada en OHI.
3. **En *large claims*, nunca se suman la madre y las subcuentas juntas.** Se
   cuenta por madre, el `valorFactura` se toma de la madre, y lo autorizado y lo
   cubierto de las subcuentas. Sumar ambas duplica.
4. **`valorFactura` es un campo de Sura**, no el `totalClaimedAmount` de OHI.
   Son dos cosas distintas y no siempre coinciden.

## El ciclo de vida de una cuenta

```mermaid
stateDiagram-v2
    direction LR
    [*] --> INITIAL

    INITIAL --> ENTRY : radicacion
    ENTRY --> IN_PROCESS : submit
    CHANGE --> IN_PROCESS : submit

    state IN_PROCESS {
        direction LR
        [*] --> SanityChecks
        SanityChecks --> PrePricing
        PrePricing --> Pricing
        Pricing --> PreBenefits
        PreBenefits --> Benefits
        Benefits --> Adjudicate
        Adjudicate --> [*]
    }

    IN_PROCESS --> MANUAL_PRICING : tarifa sin resolver
    IN_PROCESS --> MANUAL_ADJUDICATION : pendiente abierto
    IN_PROCESS --> FINALIZED : sin pendientes

    MANUAL_ADJUDICATION --> IN_PROCESS : resolvepend
    MANUAL_PRICING --> IN_PROCESS : tomanualpricing resuelto

    MANUAL_ADJUDICATION --> CHANGE : tochange
    FINALIZED --> CHANGE : unfinalize + tochange
    FINALIZED --> [*] : purga

    MANUAL_ADJUDICATION --> CANCELADA : cancel
    CANCELADA --> [*]

    note right of FINALIZED
        266.731 cuentas.
        Dispara 8 eventos salientes
        y escribe la foto en ctrclaims.
    end note
    note right of MANUAL_ADJUDICATION
        7.154 cuentas esperando
        decision humana.
    end note
```

En el diagrama los estados van con guion bajo porque Mermaid no admite espacios
en un identificador; **los códigos reales llevan espacio** (`MANUAL
ADJUDICATION`, `IN PROCESS`) y así hay que escribirlos en `q`.

El motor de OHI es una cola de tareas: cada fase del proceso es un tipo de tarea
con una prioridad. Los **74 tipos** están en prod y las prioridades (1 = más
urgente) dicen el orden del encadenamiento:

| Prioridad | Tipos de tarea | Fase |
|---|---|---|
| 1 | `Finalize`, `PricingFinalize` | cerrar |
| 2 | `Adjudicate` | adjudicar |
| 3 | `Benefits`, `PreBenefits` | coberturas |
| 4 | `PricingAdjudicate`, `PaymentStatus*` | |
| 5 | `Pricing`, `PrePricing`, `EndPricing`, `CalloutRule*`, `ClaimClassification`, `EpisodeDetection` | tarifar |
| 6 | `Enrollment*`, `NotificationEvent`, `UnifiedEvent` | afiliación y avisos |
| 7 | `SanityChecks`, `DraftProviderPricingClause*` | |
| 8 | `Initialize`, `FileImport`, `FinancialMessage*` | entrada y salida |
| 9 | el resto (eventos, importaciones, respuestas) | |

Y los de numeración antigua (`01` `ClaimStatusChange`, `11` `CompletenessCheck`,
`12` `ClaimLineCompletenessCheck`, `20` `ComplementClaim`,
`30` `PostComplementCheck`, `71` `CombinationRules`, `120` `RemoveInternalMessage`,
`121` `GeneralChecks`, `122` `DerivationRules`, `123` `DynamicChecks`,
`160` `BatchJob`) son los pasos internos de la cadena de validación. El
`122 DerivationRules` es el que deriva el prestador de atención: es el que estuvo
detrás del incidente de `serviceProviderCodeDef`.

### Las acciones que mueven la cuenta

No se cambia el estado escribiendo en `generic`. Se invocan operaciones del API
`specific`, y **OHI dice en cada respuesta qué acciones están disponibles** como
enlaces `rel` del recurso. Eso es lo que lee
[`TraductorAcciones`](../../infraestructura/adaptadores/acl-ohi/src/main/java/co/sura/auditoria/acl/ohi/traductor/TraductorAcciones.java):

| Enlace `rel` | Ruta | Dominio |
|---|---|---|
| `claim:submit` | `POST /claims/{id}/submit` | ENVIAR |
| `claim:status` | `GET /claims/{id}/status` | SEGUIR_PROCESO |
| `claim:resolvepend` | `POST /claims/{id}/resolvepend/{pendReasonId}` | RESOLVER_PENDIENTE |
| `claim:resolveclaimlinepend` | `POST /claims/{id}/resolveclaimlinepend/{pendReasonId}` | RESOLVER_PENDIENTE_LINEA |
| `claim:tochange` | `POST /claims/{id}/tochange` | DEVOLVER_A_MODIFICACION |
| `claim:tomanualbenefits` | `POST /claims/{id}/tomanualbenefits` | DEVOLVER_A_BENEFICIOS_MANUALES |
| `claim:tomanualpricing` | `POST /claims/{id}/tomanualpricing` | DEVOLVER_A_TARIFACION_MANUAL |
| `claim:unfinalize` | `POST /claims/{id}/unfinalize` | REVERTIR_FINALIZACION |
| `claim:unlocklines` | `POST /claims/{id}/unlocklines` | DESBLOQUEAR_LINEAS |
| `claim:undolinereplacements` | `POST /claims/{id}/undolinereplacements` | DESHACER_REEMPLAZOS |
| `claim:cancel` | `POST /claims/{id}/cancel` | ANULAR |

Y hay más que el diccionario de este repositorio no mapea porque no se usan
desde aquí: `claim:removefromset`, `claim:generateclaimevent`,
`claim:toinprocess`, `claim:largeclaimsubmit`, `claim:unfinalizelargeclaim`,
`claim:updateskiptags`. Las 171 rutas están en el
[Anexo C](anexo-c-api-specific.md).

**Preferir los enlaces a construir la URL.** Si OHI no publicó
`claim:unfinalize` en una cuenta, es porque en ese estado no se puede
desfinalizar; invocar la ruta a mano devuelve un error de negocio. La lista de
enlaces es la autorización, y se pierde si se usa proyección
([02](02-api-y-lenguaje-de-consulta.md#la-proyección-va-en-un-elemento-hermano)).

### El proceso es asíncrono

```mermaid
sequenceDiagram
    autonumber
    participant C as Cliente
    participant API as OHI /specific
    participant Q as Cola de tareas
    participant M as Motor de adjudicacion
    participant IP as Puntos salientes

    C->>API: POST /claims/{id}/submit
    API->>Q: encola Initialize
    API-->>C: 202 tiquete (NO terminado)

    loop cadena de tareas por prioridad
        Q->>M: SanityChecks, PrePricing, Pricing...
        M->>M: levanta mensajes y pendientes
    end

    alt queda algun pendiente
        M->>Q: estado MANUAL ADJUDICATION
    else sin pendientes
        M->>Q: Finalize
        M->>IP: 8 eventos de FINALIZED
    end

    C->>API: GET /claims/{id}/status
    API-->>C: notStarted | processing | succeeded | failed

    Note over C,API: resolvepend tarda mas que el timeout del cliente.<br/>La operacion SI termina en OHI. Reintentar readjudica dos veces.
```

`POST /claims/{id}/submit` **no termina el trabajo**: encola. Se sigue con
`GET /claims/{id}/status`, que devuelve un avance:

| Valor de OHI | Dominio |
|---|---|
| `notStarted` | NO_INICIADO |
| `processing` | EN_PROCESO |
| `succeeded` | EXITOSO |
| `failed` | FALLIDO |

Hay una excepción que vale la pena conocer porque parece un fallo y no lo es:
**resolver un pendiente dispara la readjudicación, y la operación se completa en
OHI aunque el cliente ya haya cortado por tiempo de espera.** Está verificado en
producción y por eso este microservicio le da 25 s a esa llamada y 5 s a las
demás (`integraciones.ohi.timeouts.resolucion-pendiente`). Si el cliente
reintenta al ver el timeout, readjudica dos veces.

### Los pendientes

Un pendiente (`pendReason`) es lo que detiene una cuenta y obliga a una decisión
humana. El catálogo tiene **233 motivos**, de los cuales **230 llevan el prefijo
`MP_`**: son todos configuración de Sura, no del producto. Ejemplos:
`MP_CM_GLOSADA`, `MP_AUT_SINIESTRO_CERRADO`, `MP_APOYO_ANALISTA_MOS`,
`MP_CAMPOS_VACIOS_SINIESTRO`, `MP_CONSULTA_SIN_AGENDAR`.

Cada motivo trae su comportamiento configurado:

| Atributo | Qué hace | En prod |
|---|---|---|
| `autoResolve` | se resuelve solo cuando desaparece la causa | 23 de 233 |
| `nonClean` | marca la cuenta como «no limpia» | 3 de 233 |
| `reprocess` | al resolverse, reprocesa | — |
| `adjudicationOnly` | solo aplica en adjudicación | — |
| `priority` | orden de atención | casi todos 1 |
| `functionDynamicLogicClaim` / `...ClaimLine` / `...Bill` | la lógica dinámica que lo levanta | |

Estado actual de los pendientes puestos:

| | Sin resolver | Resueltos |
|---|---:|---:|
| de cuenta | 13.684 | 2.571 |
| de línea | 200.657 | 11.505 |

Se resuelven de dos maneras, y conviene no confundirlas.

**Uno a uno**, con `POST /claims/{id}/resolvepend/{pendReasonId}` o
`POST /claims/{id}/resolveclaimlinepend/{pendReasonId}`. Dos avisos:

- **los dos niveles son disjuntos.** El spec que publica la propia instancia
  describe el primero como «Resolves a pend reason *at claim level*» y el segundo
  «*at claim line* level»: `resolvepend` **no toca las líneas**. Para que un
  motivo desaparezca de una cuenta donde está en los dos sitios hacen falta las
  dos llamadas;
- **no existe `action=accept|deny`.** No está en el spec de la versión instalada
  (4.25.1.0.23) ni en los enlaces HATEOAS que publica la cuenta. Este documento
  lo afirmaba y era falso (corregido el 12-oct-2026). El `{pendReasonId}` de la
  ruta es el id del **catálogo** (`pendreasons.id`, del orden de 2011 u 8003), no
  el de la fila (`claimpendreasons.id`, de miles de millones).

**Varios de golpe**, con `POST /claims/resolvependreasons`, que es lo que usa el
propio sistema de registro: 32.661 operaciones de este tipo en producción el
12-oct-2026, con duraciones del orden de 5 s. Cuerpo:

```json
{ "pendReasonCodeList": [ { "code": "MP_X" } ],
  "level": "claim" | "claim line",
  "claimList": [ { "id": 123, "claimLineList": [ { "id": 456 } ] } ] }
```

Resuelve por **código** de motivo, no por id, y responde `201` con la cabecera
`Location`: es una operación de larga duración que se sigue con
`GET /activities/{id}`. Los fallos **parciales** —un motivo que otro ya resolvió,
una línea que no existe— no viajan en el código HTTP: solo en
`POST /generic/activitymessages/search` filtrando
`activity.id.eq(N).or.(activity.rootActivityId.eq(N))` (la hija reporta el fallo,
el padre solo informativos) y quedándose con los de severidad `F`. El catálogo de
fallos es `CLA-IP-RPND-001..009`.

### Las novedades (mensajes)

Un mensaje es el resultado de una validación. Se guardan en `claimmessages` y
`claimlinemessages` y son, de lejos, la tabla más grande del núcleo: **1,68
millones de mensajes de línea.**

Cada mensaje trae:

- `message` → el catálogo (`messages.code`, `messages.severity`)
- `origin` → **en qué fase se levantó**
- `value0` … `value9` → los parámetros que rellenan los `{0}`, `{1}` del texto
- `overturned`, `overturnedBy` → si un usuario lo anuló, y quién
- `referenceCode`, `skipTag`, `transactionSource`

La severidad llega como **un solo carácter**: `I` → INFORMATIVA, `F` →
BLOQUEANTE, `D` → NEGACIÓN («Negar», más grave que la fatal). No hay cuarto
valor: **`WARNING` no existe en OHI**, y por eso `Severidad.ADVERTENCIA` solo la
producía el simulador local, ya retirado.

> Esto estuvo mal escrito aquí y mal implementado hasta el 15-oct-2026: el
> diccionario mapeaba las palabras `INFO`/`WARNING`/`FATAL`, que OHI no envía
> nunca, así que **toda novedad llegaba como DESCONOCIDA** y el indicador de
> línea bloqueada no se encendía jamás. De los 631 mensajes que un auditor puede
> elegir, 201 son fatales y 2 de negación.

El `origin` es el campo más útil para diagnosticar, porque dice qué parte del
motor se quejó:

| `origin` | Mensajes de línea | Mensajes de cuenta |
|---|---:|---:|
| `PrePricing` | 711.238 | 3.741 |
| `Pricing` | 570.690 | 2.215 |
| `Coverage` | 161.479 | — |
| `SanityChecks` | 79.270 | 1.678 |
| `PreBenefits` | 47.414 | — |
| `Manual` | 47.101 | 13.401 |
| `Benefits` | 43.004 | 133.624 |
| `Reservation` | 14.168 | — |
| `PricingNoRecalculation` | 4.947 | — |
| `Enrollment` | 309 | — |
| `Cancel` | — | 5 |

Dos lecturas: el 76% de los mensajes de línea nacen en tarifación
(`PrePricing` + `Pricing`), y el 86% de los mensajes de cuenta nacen en
coberturas (`Benefits`). Son dos problemas distintos y se atacan en sitios
distintos.

**Los `value0..value9` importan.** Un mismo código de mensaje significa cosas
distintas según sus parámetros: `CLA-FL-PPRI-006` («*serviceProvider not null*»)
solo indica que falta el prestador derivado cuando
`value0 == CLA_CLAIMLINE_FIELD_SERVICEPROVIDER_DEFAULT`. Con otro `value0` habla
de otro campo. Contarlo sin mirar el parámetro infla el resultado.

## `ctrclaims` — la foto al finalizar

Esta es la parte del modelo que más confunde, y conviene entenderla porque es
donde están los reportes.

`ctrclaims` **no es una vista de `claims`**: es la tabla de transacciones. Cada
vez que una cuenta se finaliza, OHI escribe una fila nueva con el estado
completo de la cuenta en ese instante. Cada vez que se desfinaliza, escribe otra
fila que **reversa** la anterior.

### Está desnormalizada a propósito

`claims` tiene 27 referencias a otras entidades. `ctrclaims` tiene **una sola**
(`externalClaimsData`): todo lo demás está aplanado a cadenas con sufijo `Code`.

```
claims.serviceProvider  → referencia a providers
ctrclaims.serviceProvCode + serviceProvCodeDef  → cadenas planas
```

Lo mismo con `servicedEntityCode`, `payerCode`, `formCode`, `brandCode`,
`dataAccessGroupCode`, `classificationCode`, `transactionSourceCode`… La foto se
guarda autocontenida para que siga siendo legible aunque el catálogo cambie
después.

**La consecuencia operativa: no se puede unir `ctrclaims` con `claims` por
referencia.** Hay que cruzar por `code`. Y `claim.in(...)` no existe en
`ctrclaims`; lo que funciona es `code.in(...)`.

### `ctrclaims` no tiene `status`

No hay campo de estado. El estado de la versión está en `ctrStatusHistoryList`,
y el estado de negocio de la cuenta médica está en `estadoCuentaMedica`, que es
un registro dinámico de Sura y se explica en [04](04-extensiones-sura.md).

### `processType` usa otras letras que en `claims`

| | `claims` | `ctrclaims` |
|---|---|---|
| cuenta | `C` | `C` |
| reserva | `R` | **`A`** |

En `ctrclaims`: `A` → 305.601 filas, `C` → 89.912. Comprobado cruzando con el
prefijo del código: `processType = C` son exactamente las `CM-`/`RC-`/`RE-`/`GT-`
y `processType = A` son exactamente las numéricas.

**`ctrclaims` con `processType.eq("R")` devuelve 204.** Es la clase de error que
no avisa.

### Las versiones y los reversos

Por cada `code` hay varias filas, y la pareja que las identifica es
**(`version`, `reversal`)**. Ejemplo real, `CM-84968614782`, 7 filas y 4
versiones:

| `version` | `reversal` | `transactionDateTime` | `totalClaimedAmount` |
|---:|---|---|---:|
| 1 | `false` | 2026-05-16 11:22 | 115.040 |
| 1 | `true` | 2026-05-22 10:37 | **−115.040** |
| 2 | `false` | 2026-05-27 11:15 | 115.040 |
| 2 | `true` | 2026-06-19 16:08 | **−115.040** |
| 3 | `false` | 2026-06-20 08:55 | 115.040 |
| 3 | `true` | 2026-10-06 15:37 | **−115.040** |
| 4 | `false` | 2026-10-07 11:47 | 115.040 |

```mermaid
flowchart TB
    subgraph CM["CM-84968614782 — 7 filas en ctrclaims, 4 versiones"]
        direction TB
        V1["v1 reversal=false<br/>16-may 11:22<br/>+115.040"]
        R1["v1 reversal=true<br/>22-may 10:37<br/>−115.040"]
        V2["v2 reversal=false<br/>27-may 11:15<br/>+115.040"]
        R2["v2 reversal=true<br/>19-jun 16:08<br/>−115.040"]
        V3["v3 reversal=false<br/>20-jun 08:55<br/>+115.040"]
        R3["v3 reversal=true<br/>06-oct 15:37<br/>−115.040"]
        V4["v4 reversal=false<br/>07-oct 11:47<br/>+115.040"]
    end

    V1 -- unfinalize --> R1 -- finalize --> V2
    V2 -- unfinalize --> R2 -- finalize --> V3
    V3 -- unfinalize --> R3 -- finalize --> V4
    V4 --> VIG["version vigente:<br/>mayor version, reversal=false,<br/>sin su reverso"]

    classDef pos fill:#e8f5e9,stroke:#2e7d32
    classDef neg fill:#ffebee,stroke:#c62828
    classDef viv fill:#e3f2fd,stroke:#1565c0,stroke-width:2px
    class V1,V2,V3 pos
    class R1,R2,R3 neg
    class V4,VIG viv
```

Se lee así: la cuenta se finalizó y se desfinalizó tres veces, y la versión
vigente es la 4. **La fila de reverso lleva los montos negados.** En todo el
entorno: 331.134 filas con `reversal = false` y 64.379 con `reversal = true`.

Tres reglas que salen de ahí:

1. **La versión vigente** es la de mayor `version` con `reversal = false` y sin
   su reverso correspondiente.
2. **Sumar montos sin filtrar por `reversal` no «da mal»: da el neto.** Para la
   cuenta del ejemplo, sumar las 7 filas da 115.040, que es correcto. Pero
   *contar filas* da 7 donde hay 1 cuenta, y filtrar por un rango de fechas
   parte las parejas y entonces sí sale cualquier cosa.
3. **Un reporte por mes tiene que decidir qué fecha usa.** `transactionDateTime`
   es cuándo se escribió la foto; `entryDate` es cuándo entró la cuenta. Son
   meses distintos: en el ejemplo, `entryDate` es de mayo y hay una transacción
   de octubre.

### Las versiones y los sellos

Relacionado, y distinto. Para los estados de negocio (el `estadoCuentaMedica`),
**el proceso de transmisión vuelve a sellar la misma transmisión durante días.**
Los sellos repetidos se reconocen porque comparten `codigoReferencia`.

Caso concreto, `CM-105774286544`: sello `T` el 31-ago 15:25, otro el 31-ago
16:25 y otro el 1-sep 08:05, los tres con referencia `230433`. Es **una**
transmisión, no tres, y la que cuenta para ubicarla en un mes es la primera: la
**fecha de entrada al estado**, no la última marca. En agosto de 2026 esto
afectaba a 62 cuentas; si se toma la última marca, 62 cuentas cambian de mes.

### Una cuenta sin finalizar no está en `ctrclaims`

La foto se escribe al finalizar. Una cuenta recién radicada, o en
`MANUAL ADJUDICATION`, **no tiene ninguna fila en `ctrclaims`** y por tanto no
tiene `estadoCuentaMedica`. No es un dato que falte: es que todavía no existe.

## Large claims

El troceo está activo (`ohi.claim.split = true`) y el umbral es de **25.000
líneas** (`ohi.subclaim.claimline.threshold`). Cuando una cuenta lo pasa, OHI
crea una **madre** (`processCategory = L`) y varias **subcuentas**
(`processCategory = S`) que apuntan a la madre por el campo `largeClaim`.

En prod: 94 madres y 305 subcuentas. Poco volumen, pero distorsiona cualquier
total si no se trata:

- **Contar** por madre.
- **`valorFactura`** de la madre.
- **Autorizado y cubierto** de las subcuentas.
- Nunca ambas cosas a la vez.

Las operaciones específicas son `POST /claims/{id}/largeclaimsubmit` y
`POST /claims/{id}/unfinalizelargeclaim`, y por debajo corren actividades
dedicadas (`LARGE_CLAIMS_SUBMIT`, `UNFINALIZE_LARGE_CLAIM`,
`LARGE_CLAIM_LINES_SPLIT`, `LC_SC_REPLACEMENT`).

## La cadena financiera

De una cuenta finalizada a un mensaje contable hay cuatro saltos, y cada uno es
una entidad:

```mermaid
flowchart LR
    CL["claims<br/>276.098"] -->|claimCode| BFO["basefinancialobjects<br/>65.283"]
    BFO -->|baseFinancialObject| FT["financialtransactions<br/>89.728"]
    FT -->|financialTransactionProcessData| FTPD["financialtransactionprocessdata<br/>89.728"]
    FTPD -->|POST BasicAuth| CONT["contabilizador<br/>1015-...-ohi-arl-ms"]
    CONT --> SAP[("SAP")]

    RES["reservas<br/>202.854"] -.->|"ohi.claims.reservation.financial = false"| NADA["no entran<br/>a la cadena"]

    FTPD --- RES2{{"finMessageResult"}}
    RES2 --> MC["MessageCreated<br/>73.921"]
    RES2 --> NR["NotRequired<br/>15.093"]
    RES2 --> SU["Superseded<br/>454"]
    RES2 --> NU["null — sin procesar<br/>262"]

    classDef gris fill:#f5f5f5,stroke:#9e9e9e,stroke-dasharray:4
    class RES,NADA gris
```

**`basefinancialobjects.status`:**

| Estado | Filas |
|---|---:|
| `FinancialMessageHandled` | 58.050 |
| `SupersedeAndReverseDone` | 7.211 |
| `Initial` | 15 |
| `Changed` | 9 |

`type` es `Claim` en las 65.283: no hay objetos financieros de otro origen.

**`financialtransactionprocessdata.finMessageResult`** — si se generó mensaje:

| Resultado | Filas | Significado |
|---|---:|---|
| `MessageCreated` | 73.921 | se generó el mensaje financiero |
| `NotRequired` | 15.093 | no hacía falta (monto 0, o reserva) |
| `Superseded` | 454 | reemplazado por una versión posterior |
| `null` | 262 | sin procesar aún |

Ese es el contrato para responder «¿esta cuenta generó evento financiero?»:
hay que llegar hasta `financialtransactionprocessdata` y mirar
`finMessageResult`, y `finMessageId` da el identificador del mensaje.

**Las reservas no entran en esta cadena**:
`ohi.claims.reservation.financial = false`. Por eso hay 276.098 cuentas y solo
65.283 objetos financieros.

`financialtransactionprocessdata` es además donde viven los campos de SAP
—`sociedad`, `tipoProcesoSAP`, `fechaContable`, `referencia`, `numeroFactura`,
`claseCuenta`, `baseDescuento`, `parametro01..04`, y los datos del beneficiario
(`primerNombre`, `primerApellido`, `numeroId`, `typeIdLegal`, `direccion`,
`correoElectronico`, `celular`, `pais`, `regiones`)—. Son 17 campos dinámicos
puestos ahí para armar el asiento contable. **Ninguno es filtrable**, así que
hay que proyectarlos y filtrar en el cliente.

## El rastro de la desfinalización

Si hay que explicar por qué una cuenta volvió atrás, el rastro está en
`claimunfinalizereasons` (42.978 filas): motivo, fecha y usuario. El catálogo de
motivos está en `unfinalizereasons`. `claimstatushistory` **no** guarda el
motivo, solo el estado y el instante.

## Prestadores, personas y prestaciones

| Entidad | Filas | Nota |
|---|---:|---|
| `providers` | 6.923 | la vista unificada |
| `individualproviders` | 2.491 | profesionales |
| `organizationproviders` | 4.432 | IPS y empresas |
| `persons` | 102.483 | los afiliados atendidos |
| `procedures` | 970.780 | CUPS, CUMS y los homólogos |
| `diagnoses` | 12.436 | CIE-10 |

`providers` es la entidad más rica en extensiones: **53 campos dinámicos**, de
los cuales 15 son registros derivados (`DYNR`). Los mismos 53 aparecen en
`individualproviders` y en `organizationproviders`, que son sus dos
especializaciones.

El detalle de los códigos propios de cada prestador —y por qué hay 4.937
sistemas de códigos flexibles— está en
[04 — Extensiones de Sura](04-extensiones-sura.md#los-códigos-propios-del-prestador).
