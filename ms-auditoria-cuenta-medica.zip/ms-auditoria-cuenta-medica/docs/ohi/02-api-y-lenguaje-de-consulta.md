# 02 — API y lenguaje de consulta

Si vas a escribir código contra OHI, este es el documento que hay que leer
completo. Casi todo lo que sale mal con el API de OHI sale mal **en silencio**:
devuelve `200` o `204` y un resultado que parece correcto pero no lo es. Las
trampas están al final, y cada una costó un diagnóstico.

## Los dos API

| | `generic` | `specific` |
|---|---|---|
| Qué es | CRUD y consulta sobre las entidades | operaciones de negocio y administración |
| Tamaño | 453 recursos | 70 endpoints, 171 rutas |
| Ruta | `/generic/<recurso>` | `/<endpoint>` (sin `/generic`) |
| Catálogo | `GET /generic` | `GET /specific` |
| Inventario | [Anexo A](anexo-a-recursos.md) | [Anexo C](anexo-c-api-specific.md) |

Una cuenta médica se **lee** por `generic` y se **mueve** por `specific`:
`/generic/claims/search` para consultarla, `/claims/{id}/submit` para enviarla.
No hay forma de cambiar el estado de una cuenta escribiendo en `generic`.

### Las operaciones de `generic`

```
POST   /generic/<recurso>/search     consultar
GET    /generic/<recurso>/{id}       leer una
GET    /generic/<recurso>/key/{key}  leer por clave de negocio
POST   /generic/<recurso>            crear
PUT    /generic/<recurso>/{id}       reemplazar
PATCH  /generic/<recurso>/{id}       modificar
DELETE /generic/<recurso>/{id}       borrar
POST   /generic/<recurso>/download   descargar el resultado de una consulta
```

`GET /generic/<recurso>` sin `id` responde **405**: no hay listado sin consulta.
Un 405 ahí no significa que el recurso no exista.

## La consulta

### El sobre `resource` es obligatorio

El cuerpo de `/search` lleva la consulta dentro de un elemento `resource`:

```json
{
  "resource": {
    "q": "status.eq(\"FINALIZED\")",
    "limit": 200,
    "offset": 0,
    "orderBy": "id:asc",
    "totalResults": true
  }
}
```

**Si se manda el contenido sin el sobre, OHI responde `204 No Content`.** No da
error, no avisa: interpreta que no se pidió nada y devuelve nada. Es la primera
cosa que comprobar cuando una consulta que debería traer miles de filas vuelve
vacía.

| Parámetro | Por omisión | Tope |
|---|---|---|
| `q` | sin filtro | — |
| `limit` | 50 | **200** |
| `offset` | 0 | — |
| `orderBy` | sin orden | — |
| `totalResults` | `false` | — |
| `groupBy` / `aggregate` | — | — |

### La proyección va en un elemento hermano

Para que OHI devuelva solo unos campos, hay que añadir
`resourceRepresentation` **al lado** de `resource`, no dentro:

```json
{
  "resource": { "q": "code.like(\"CM-%\")", "limit": 200, "orderBy": "id:asc" },
  "resourceRepresentation": {
    "defaultoverride": "true",
    "fields": "id|code|status|numeroFactura|valorFactura"
  }
}
```

Tres detalles, y los tres muerden:

1. **El separador es `|`**, no la coma.
2. **Sin `defaultoverride: "true"` el campo `fields` se ignora** y OHI devuelve
   la representación completa. No avisa.
3. `defaultoverride` **no es un encabezado HTTP.** Mandarlo como cabecera no
   hace nada. (La respuesta lo devuelve escrito `defaultOverride`, con mayúscula;
   en la petición va en minúsculas.)

Vale la pena usarla siempre: la representación completa de una cuenta trae todas
sus listas de hijos y una cuenta de 1.500 líneas pesa unos 280 KB. Proyectar
acelera entre 10 y 20 veces. El precio es que **se pierden los enlaces de
acciones** (`claim:submit`, `claim:resolvepend`…), así que si lo que quieres es
saber qué se puede hacer con la cuenta, no proyectes.

### El lenguaje de `q`

```
q               := expresion
expresion       := campo.operador(valor, ...)  |  expresion.and|or.expresion
campo           := atributo[(+)]?[.campo]*
```

| Operador | Qué hace |
|---|---|
| `eq`, `neq` | igual, distinto |
| `eqic` | igual sin distinguir mayúsculas |
| `lt`, `lte`, `gt`, `gte` | comparaciones |
| `in`, `nin` | dentro / fuera de una lista |
| `bet` | entre dos valores, inclusive |
| `like`, `likeic` | patrón con `%` y `_` |

Se combinan con `.and.` y `.or.`, y se agrupan con paréntesis:

```
(endDate.eq(null).or.endDate.lt("2026-01-01")).and.code.like("CM-%")
```

Para navegar a otra entidad se pone la ruta con puntos — eso genera un **inner
join**, que descarta las filas sin relación:

```
claim.code.eq("CM-84968614782")      inner join: pierde las líneas sin cuenta
claim(+).code.eq("CM-84968614782")   outer join: las conserva
```

El `(+)` va en el atributo de la relación, no en el campo final.

### Agrupar y agregar

La sintaxis del `aggregate` es **`funcion(campo):alias`**, en ese orden. Al
revés (`alias:funcion(campo)`) da un `GEN-PROC-ERR` con un error del parser que
no dice cuál es el problema.

```json
{ "resource": { "groupBy": "status", "aggregate": "count(id):n", "limit": 200 } }
```

Funciones: `count`, `sum`, `avg`, `min`, `max`, `var`, `std`.

Es la forma barata de sacar distribuciones y totales sin paginar nada: casi
todos los números de esta documentación salieron así.

### Paginación

**No uses `offset` para recorrer un conjunto grande.** Oracle lo ofrece, pero
sobre una tabla que se mueve —y en prod entran unas mil cuentas al día— las
filas se desplazan entre páginas y se duplican o se pierden. Usa paginación por
cursor:

```json
{ "resource": { "q": "id.gt(\"<ultimo id visto>\")", "orderBy": "id:asc", "limit": 200 } }
```

Dos reglas que van juntas:

- **Siempre `orderBy`.** Sin orden explícito OHI no garantiza nada y la
  paginación repite filas.
- **Siempre `id` en la proyección.** Si proyectas y te olvidas de `id`, el
  cursor se queda sin valor para avanzar. Es un error fácil y el síntoma es un
  bucle infinito o un `KeyError` en el cliente.

## Las trampas

Ordenadas por cuánto daño hacen si no se conocen.

### 1. `neq` descarta los nulos

La documentación de Oracle llama a `eq` y `neq` «null-safe». Lo que eso
significa es que `eq(null)` funciona — **no** que `neq(x)` incluya los nulos.
Por debajo es una desigualdad SQL, y en Oracle una desigualdad nunca es
verdadera contra `NULL`.

Medido en prod sobre `claims.processCategory`, que es nulo en las cuentas
ordinarias:

| Consulta | Filas |
|---|---:|
| `processCategory.neq("L")` | **305** |
| `processCategory.eq(null)` | 275.730 |
| `processCategory.neq("L").or.processCategory.eq(null)` | 276.035 |

Sobre un total de ~276.100 cuentas. Es decir: **`neq("L")` devolvió el 0,1% de
lo que uno cree que pide.** Quien escriba «todas las que no son *large claim*»
como `processCategory.neq('L')` se lleva solo las subcuentas y pierde el 99,9%
del conjunto, sin ningún error.

La forma correcta es `.neq("L").or.<campo>.eq(null)`, o proyectar el campo y
filtrar en el cliente.

### 2. `groupBy` devuelve etiquetas; `q` filtra por códigos

El mismo campo se ve de tres maneras según cómo lo pidas:

| Campo | En `q` (código almacenado) | En la representación | En `groupBy` (etiqueta) |
|---|---|---|---|
| `claims.status` | `"FINALIZED"`, `"MANUAL ADJUDICATION"` | `"FINALIZED"` | `Finalized`, `ManualAdjudication` |
| `claims.processType` | `"C"`, `"R"` | `"R"` | `Claim`, `Reservation` |
| `claims.type` | `"P"`, `"R"` | `"P"` | `ProviderClaim`, `RestitutionClaim` |
| `claims.processCategory` | `"L"`, `"S"` | `"L"` | `LargeClaimSystem`, `SubClaim` |

`status.eq("Finalized")` devuelve **204**. `status.eq("FINALIZED")` devuelve
266.731. Y ojo con los espacios: el código almacenado es
`"MANUAL ADJUDICATION"`, con espacio, aunque la etiqueta sea
`ManualAdjudication` sin él.

La trampa es que uno saca la lista de valores con un `groupBy` —que es lo
natural— y después los pega en un `q`, donde no sirven.

### 3. Un campo dinámico no filtrable rompe la consulta

Cada campo del esquema declara `x-oi-searchable`. Si dice `false`, usarlo en `q`
o en `groupBy` da `GEN-PROC-ERR`, no un resultado vacío. Es frecuente en los
campos propios de Sura: en `claims` muchos son filtrables, pero **en `ctrclaims`
casi ninguno lo es**. El [Anexo B](anexo-b-campos-nucleo.md) lo trae campo por
campo.

Los registros dinámicos (`DYNR`, como `estadoCuentaMedica`) **nunca** se
filtran: solo se proyectan y se filtra en el cliente.

### 4. `fields` no se valida

Un nombre de campo mal escrito en `fields` no da error: la respuesta llega con
`200` y el campo simplemente no aparece. Y como OHI **omite los campos nulos**
de la representación, un campo ausente es indistinguible de un campo nulo y de
un campo inexistente.

Si una columna te sale vacía para todas las filas, antes de concluir que el dato
no existe, comprueba el nombre contra el `/definition`.

### 5. Sin resultados es `204`, con cuerpo vacío

No es un `200` con `items: []`. Es un `204 No Content` y el cuerpo es la cadena
vacía, así que `json.loads()` revienta. Todo cliente tiene que normalizarlo:

```python
if codigo == 204:
    datos = {"totalResults": 0, "hasMore": False, "items": []}
```

### 6. `isnotnull()` no existe

Da `GEN-PROC-ERR`. Lo que se usa es `campo.neq(null)` — y esa sí incluye todas
las filas con valor (comprobado: `serviceProvider.neq(null)` = 808.519 y
`serviceProvider.eq(null)` = 44.093, que suman el total de líneas).

### 7. `in` sobre una referencia no funciona

| Consulta | Resultado |
|---|---|
| `code.in("CM-116278280952","CM-84968614782")` | 2 ✔ |
| `claim.in("CM-116278280952")` | `GEN-PROC-ERR` ✘ |
| `claim.code.in("CM-84968614782")` | 4 ✔ |

`in` quiere un escalar. Sobre una relación hay que bajar al subcampo.

Lo mismo aplica a cualquier referencia: `claim.code`, `message.code`,
`taskType.name`. Pedir la referencia sola devuelve el objeto con su `id` y sus
enlaces, nunca el código.

### 8. Las listas de `in` se parten en 1.000

Oracle corta en `ORA-01795`: una lista literal no admite más de **1.000**
elementos. Cuando hay que consultar por muchas claves, el patrón es trocear
—en la práctica se usan trozos de 40 a 200, que además mantienen la URL y el
cuerpo en tamaños razonables— y unir los resultados en el cliente.

### 9. `groupBy` solo sobre campos escalares de la raíz

| Consulta | Resultado |
|---|---|
| `groupBy: "status"` | ✔ |
| `groupBy: "taskType"` (una referencia) | `ORA-00979` ✘ |
| `groupBy: "taskType.code"` (subcampo) | «*is not a (dynamic) field for class…*» ✘ |

Para agrupar por el código de una entidad relacionada hay que traer el catálogo
aparte y cruzarlo en el cliente.

### 10. `bet()` ignora la zona horaria del literal

En un rango de fechas con hora, OHI lee el literal como hora **del servidor**
(`-05:00`), aunque el literal traiga su propio desplazamiento. Si importa la
frontera exacta del día, conviene comprobar el borde con una consulta de
control.

### 11. La fecha que cuenta no es siempre la última marca

Para ubicar una cuenta en un mes, la fecha de **entrada al estado** y la fecha
de la última marca son distintas: el proceso de transmisión re-sella la misma
transmisión durante días, y los sellos repetidos comparten `codigoReferencia`.
Está explicado con el caso concreto en
[03 — Modelo de datos](03-modelo-de-datos.md#las-versiones-y-los-sellos).

### 12. Un booleano filtrado con `"Y"` da el resultado contrario

Los booleanos se filtran con `true` y `false` sin comillas. Si se les pasa una
cadena, OHI **no da error**: la convierte a `false` y devuelve las filas
equivocadas.

Medido sobre `pendreasons.autoResolve`, que es `true` en 23 de los 233 motivos:

| Consulta | Filas | |
|---|---:|---|
| `autoResolve.eq(true)` | 23 | correcto |
| `autoResolve.eq(false)` | 210 | correcto |
| `autoResolve.eq("Y")` | **210** | silenciosamente el conjunto contrario |
| `autoResolve.eq("N")` | **210** | lo mismo, por la misma razón |

El `"Y"` y el `"N"` dan **la misma respuesta** porque ninguno es un booleano
válido y los dos terminan valiendo `false`.

Y hay que tener cuidado porque en OHI conviven las dos convenciones según la
entidad:

- Las entidades vivas (`claims`, `claimlines`, `pendreasons`…) usan **booleanos
  JSON**: `"manual": false`.
- Las entidades de transacción (`ctrclaims`, `ctrclaimlines`) los traen como
  **cadenas `"Y"`/`"N"`**: `"manualIndicator": "N"`, `"emergencyIndicator": "N"`.

Por eso [`DiccionarioOhi`](../../infraestructura/adaptadores/acl-ohi/src/main/java/co/sura/auditoria/acl/ohi/DiccionarioOhi.java)
tiene dos `aIndicador` sobrecargados, uno para `String` y otro para `Boolean`.
No es redundancia: son dos convenciones distintas del mismo sistema.

## Formato de error

```json
{
  "xsi:type": "exceptionDetail",
  "o:errorDetails": [
    { "o:errorCode": "GEN-PROC-ERR", "title": "GEN-PROC-ERR: …", "o:errorPath": "$" }
  ]
}
```

| Código | Qué suele ser |
|---|---|
| `GEN-PROC-ERR` | sintaxis del DSL, campo no filtrable, agregado mal escrito |
| `GEN-ORA-ERR` | error de base de datos; el `ORA-xxxxx` va en el texto |
| `GEN-HTTP-004` | el cliente no está autorizado en ese recurso |

El `title` viene en español y a veces trae el error del parser de Java escapado
en HTML. Es feo pero es informativo: dice en qué columna se atascó.

## Rendimiento

- Proyecta siempre que puedas: 10-20× más rápido.
- `totalResults: true` cuesta un conteo adicional. Pídelo en la primera página y
  no en las siguientes.
- `limit: 200` es el tope; una consulta de 200 en 200 con cursor es el camino
  más rápido para recorrer un conjunto grande.
- Los `/metadata` se sirven cacheados (`ohi.httpapi.cache.control.enable`), así
  que descubrir el modelo es barato.
- El encabezado `enablesqlmonitorreport` **no sirve en prod**: está deshabilitado
  por propiedad.

## Referencia oficial

Query API de Claims 4.25.1:
<https://docs.oracle.com/en/industries/insurance/health-insurance-components/claims-4.25.1/development/integration-points/http-api/query-api.html>

Ten presente que la trampa 1 (`neq` y los nulos) y la 2 (etiquetas contra
códigos) **no están documentadas ahí**, y la 1 contradice lo que dice esa
página.
