# Anexo D — Relaciones de las entidades del núcleo

Qué apunta a qué, leído de los `$ref` de cada `/definition`. `timestampobject`
se omite: lo usan 1.421 campos de fecha y no aporta nada al grafo.

## `claims`

**Referencia a** (una entidad):

- `brand` → `brands`
- `claimForm` → `claimforms`
- `claimSet` → `claimsets`
- `claimantProvider` → `providers`
- `claimantRelation` → `relations`
- `classification` → `classifications`
- `classificationScheme` → `classificationschemes`
- `dataAccessGroup` → `dataaccessgroups`
- `externalClaimsData` → `externalclaimsdata`
- `largeClaim` → `claims`
- `locationProvider` → `providers`
- `locationType` → `locationtypes`
- `payerCode` → `payercodes`
- `paymentBeneficiaryProvider` → `providers`
- `paymentBeneficiaryRelation` → `relations`
- `paymentReceiverProvider` → `providers`
- `paymentReceiverRelation` → `relations`
- `paymentSpecificationReceiverProvider` → `providers`
- `paymentSpecificationReceiverRelation` → `relations`
- `person` → `persons`
- `referralProvider` → `providers`
- `serviceProvider` → `providers`
- `serviceSpecialty` → `specialties`
- `transactionSource` → `transactionsources`

**Contiene** (listas):

- `billList` → `bills`
- `claimDiagnosisList` → `claimdiagnoses`
- `claimLineList` → `claimlines`
- `claimMessageList` → `claimmessages`
- `claimPendReasonList` → `claimpendreasons`
- `claimStatusHistoryList` → `claimstatushistory`
- `claimSubmitHistoryList` → `claimsubmithistory`
- `claimTagActionList` → `claimtagactions`
- `claimUnfinalizeReasonList` → `claimunfinalizereasons`
- `policyProductList` → `policyproducts`

**Referido por**: `adjudicationcasedetails.claim`, `authorizationconsumptions.claim`, `bills.claim`, `claimactivities.claim`, `claimdiagnoses.claim`, `claimlines.claim`, `claimmessages.claim`, `claimpendreasons.claim`, `claims.largeClaim`, `claimsimportprocess.largeClaim`, `claimstatushistory.claim`, `claimsubmithistory.claim`, `claimtagactions.claim`, `claimunfinalizereasons.claim`, `externalclaimsdata.claim`, `limitconsumptions.claim`, `limitcounters.claim`, `policyfamilies.claim`, `policyproducts.claim`, `providerlimitconsumptions.claim`, `providerlimitcounters.claim`, `providerlimitruleconsumptions.claim`, `regimeconsumptions.claim`

## `claimlines`

**Referencia a** (una entidad):

- `authorization` → `authorizations`
- `benefitsProvider` → `providers`
- `bill` → `bills`
- `claim` → `claims`
- `claimLineOverride` → `claimlineoverrides`
- `classification` → `classifications`
- `episodeDetail` → `episodedetails`
- `locationProvider` → `providers`
- `locationType` → `locationtypes`
- `originalClaimLine` → `claimlines`
- `paymentReceiverProvider` → `providers`
- `paymentReceiverRelation` → `relations`
- `person` → `persons`
- `priceIndividualProvider` → `individualproviders`
- `priceOrganizationProvider` → `organizationproviders`
- `procedure` → `procedures`
- `procedure2` → `procedures`
- `procedure3` → `procedures`
- `referralProvider` → `providers`
- `replacementClaimLine` → `claimlines`
- `reservationLine` → `claimlines`
- `serviceProvider` → `providers`
- `serviceSpecialty` → `specialties`
- `skipTag` → `skiptags`
- `skipTagAllowed` → `skiptags`
- `transactionSource` → `transactionsources`

**Contiene** (listas):

- `adjudicationCaseDetailList` → `adjudicationcasedetails`
- `claimLineAppliedParameterList` → `claimlineappliedparameters`
- `claimLineBenefitSpecificationList` → `claimlinebenefitspecifications`
- `claimLineContractReferenceList` → `claimlinecontractreferences`
- `claimLineCoverageList` → `claimlinecoverages`
- `claimLineDiagnosisList` → `claimlinediagnoses`
- `claimLineLimitList` → `claimlinelimits`
- `claimLineMessageList` → `claimlinemessages`
- `claimLineModifierList` → `claimlinemodifiers`
- `claimLineParameterList` → `claimlineparameters`
- `claimLinePendReasonList` → `claimlinependreasons`
- `claimLineProviderPricingClauseList` → `claimlineproviderpricingclauses`
- `claimLineRuleCoverageList` → `claimlinerulecoverages`
- `claimSubLineList` → `claimsublines`

**Referido por**: `adjudicationcasedetails.claimLine`, `authorizationconsumptions.claimLine`, `bills.claimLineList`, `claimlineappliedparameters.claimLine`, `claimlinebenefitspecifications.claimLine`, `claimlinecontractreferences.claimLine`, `claimlinecoverages.claimLine`, `claimlinediagnoses.claimLine`, `claimlinelimits.claimLine`, `claimlinemessages.claimLine`, `claimlinemodifiers.claimLine`, `claimlineoverrides.claimLine`, `claimlineparameters.claimLine`, `claimlinependreasons.claimLine`, `claimlineproviderpricingclauses.claimLine`, `claimlinereinsurancecoverages.claimLine`, `claimlinereinsurancerulecoverages.claimLine`, `claimlinerulecoverages.claimLine`, `claimlines.originalClaimLine`, `claimlines.replacementClaimLine`, `claimlines.reservationLine`, `claims.claimLineList`, `claimsublines.claimLine`, `episodedetails.claimLine`, `limitconsumptions.claimLine`, `providerlimitconsumptions.claimLine`, `providerlimitconsumptions.reservationLine`, `providerlimitruleconsumptions.claimLine`, `providerlimitruleconsumptions.reservationLine`, `regimeconsumptions.claimLine`, `regimeconsumptions.reservationLine`

## `ctrclaims`

**Referencia a** (una entidad):

- `externalClaimsData` → `externalclaimsdata`

**Contiene** (listas):

- `ctrBillList` → `ctrbills`
- `ctrClaimDiagnosisList` → `ctrclaimdiagnoses`
- `ctrClaimLineList` → `ctrclaimlines`
- `ctrClaimMessageList` → `ctrclaimmessages`
- `ctrClaimPolicyProductList` → `ctrclaimpolicyproducts`
- `ctrClaimUnfinalizeReasonList` → `ctrclaimunfinalizereasons`
- `ctrStatusHistoryList` → `ctrstatushistory`
- `ctrTransactionLabelList` → `ctrtransactionlabels`

**Referido por**: `ctrbills.ctrClaim`, `ctrclaimdiagnoses.ctrClaim`, `ctrclaimlines.ctrClaim`, `ctrclaimmessages.ctrClaim`, `ctrclaimpolicyproducts.ctrClaim`, `ctrclaimunfinalizereasons.ctrClaim`, `ctrstatushistory.ctrClaim`, `ctrtransactionlabels.ctrClaim`, `externalclaimsdata.ctrClaim`

## `ctrclaimlines`

**Referencia a** (una entidad):

- `ctrBill` → `ctrbills`
- `ctrClaim` → `ctrclaims`

**Contiene** (listas):

- `ctrClaimLineAppliedParameterList` → `ctrclaimlineappliedparameters`
- `ctrClaimLineBenefitSpecificationList` → `ctrclaimlinebenefitspecifications`
- `ctrClaimLineContractReferenceList` → `ctrclaimlinecontractreferences`
- `ctrClaimLineCoverageList` → `ctrclaimlinecoverages`
- `ctrClaimLineDiagnosisList` → `ctrclaimlinediagnoses`
- `ctrClaimLineMessageList` → `ctrclaimlinemessages`
- `ctrClaimLineModifierList` → `ctrclaimlinemodifiers`
- `ctrClaimLineProviderPricingClauseList` → `ctrclaimlineproviderpricingclauses`
- `ctrClaimSubLineList` → `ctrclaimsublines`

**Referido por**: `ctrbills.ctrClaimLineList`, `ctrclaimlineappliedparameters.ctrClaimLine`, `ctrclaimlinebenefitspecifications.ctrClaimLine`, `ctrclaimlinecontractreferences.ctrClaimLine`, `ctrclaimlinecoverages.ctrClaimLine`, `ctrclaimlinediagnoses.ctrClaimLine`, `ctrclaimlinemessages.ctrClaimLine`, `ctrclaimlinemodifiers.ctrClaimLine`, `ctrclaimlineproviderpricingclauses.ctrClaimLine`, `ctrclaimlinereinsurancecoverages.ctrClaimLine`, `ctrclaims.ctrClaimLineList`, `ctrclaimsublines.ctrClaimLine`, `financialsubjectregistrations.ctrClaimLines`

## `externalclaimsdata`

**Referencia a** (una entidad):

- `claim` → `claims`
- `ctrClaim` → `ctrclaims`
- `settlementReason` → `settlementreasons`

**Referido por**: `claims.externalClaimsData`, `ctrclaims.externalClaimsData`

## `basefinancialobjects`

**Referido por**: `basefinancialobjectactivities.baseFinancialObject`, `financialtransactions.baseFinancialObject`

## `financialtransactions`

**Referencia a** (una entidad):

- `baseFinancialObject` → `basefinancialobjects`
- `financialTransactionProcessData` → `financialtransactionprocessdata`

**Contiene** (listas):

- `financialTransactionDetailList` → `financialtransactiondetails`

**Referido por**: `financialtransactiondetails.financialTransaction`, `financialtransactionprocessdata.financialTransaction`, `financialtransactionprocessdata.financialTransactionOriginsFrom`

## `financialtransactionprocessdata`

**Referencia a** (una entidad):

- `financialTransaction` → `financialtransactions`
- `financialTransactionOriginsFrom` → `financialtransactions`
- `financialTransactionSet` → `financialtransactionsets`

**Referido por**: `financialtransactions.financialTransactionProcessData`

## Las 30 entidades más referenciadas de todo el modelo

Cuántos recursos distintos apuntan a cada una. Son los catálogos que
sostienen la configuración.

| Entidad | Recursos que la referencian |
|---|---:|
| `dynamiclogic` | 187 |
| `proceduregroups` | 98 |
| `messages` | 69 |
| `accessrestrictions` | 51 |
| `claimlines` | 29 |
| `providers` | 27 |
| `claims` | 23 |
| `flexcodesystems` | 20 |
| `persons` | 20 |
| `tables` | 19 |
| `diagnosisgroups` | 19 |
| `products` | 18 |
| `procedures` | 16 |
| `coveragelabels` | 16 |
| `languages` | 16 |
| `relations` | 13 |
| `transactionsources` | 11 |
| `claimforms` | 11 |
| `ctrclaimlines` | 11 |
| `users` | 10 |
| `providergroups` | 10 |
| `limits` | 10 |
| `currencies` | 9 |
| `benefitspecifications` | 9 |
| `ctrclaims` | 9 |
| `classifications` | 8 |
| `skiptags` | 8 |
| `coverwithholdcategories` | 8 |
| `providerpricingclauses` | 8 |
| `activitytypes` | 7 |
