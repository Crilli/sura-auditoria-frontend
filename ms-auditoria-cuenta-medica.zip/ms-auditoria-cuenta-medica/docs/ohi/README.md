# OHI producción — modelo, integraciones y operación

Documentación de **Oracle Health Insurance Claims Adjudication and Pricing**
tal como está configurado en el entorno de producción de Sura, el que consume
este microservicio.

No es la documentación del producto: es la de **esta instalación**. Oracle
documenta lo que OHI puede hacer; aquí está lo que OHI hace en `prod`, con los
números, los códigos y los extremos reales, y con las trampas que solo aparecen
cuando uno consulta el API de verdad.

## Los documentos

| Documento | Qué resuelve |
|---|---|
| [01 — Plataforma y entorno](01-plataforma-y-entorno.md) | Qué versión corre, dónde, cómo se autentica, qué dice la configuración de prod |
| [02 — API y lenguaje de consulta](02-api-y-lenguaje-de-consulta.md) | Cómo se consulta OHI sin equivocarse. **Empieza por aquí si vas a escribir código** |
| [03 — Modelo de datos](03-modelo-de-datos.md) | Las entidades del núcleo, el ciclo de vida de una cuenta, los montos, la cadena financiera |
| [04 — Extensiones de Sura](04-extensiones-sura.md) | Los 663 campos dinámicos, los 668 mensajes propios, la lógica dinámica, los códigos del prestador |
| [05 — Integraciones](05-integraciones.md) | Los 21 puntos salientes, los 18 eventos, quién recibe cada uno, quién escribe en OHI |
| [06 — Operación](06-operacion.md) | Tareas, actividades, errores, el proceso financiero, qué vigilar |
| [07 — El diseño de la ACL](07-diseno-de-la-acl.md) | Cómo se defiende este microservicio de OHI: clases, puertos, traducción, y los dos huecos del diseño |

Y los anexos, generados leyendo los metadatos del API y no escritos a mano:

| Anexo | Contenido |
|---|---|
| [A — Recursos](anexo-a-recursos.md) | Los 453 recursos genéricos, con forma y permisos de escritura |
| [B — Campos del núcleo](anexo-b-campos-nucleo.md) | Campo por campo de `claims`, `claimlines`, `ctrclaims`, `ctrclaimlines` |
| [C — API specific](anexo-c-api-specific.md) | Las 171 rutas de operaciones de negocio |
| [D — Relaciones](anexo-d-relaciones.md) | Qué apunta a qué en el núcleo, y los catálogos más referenciados |

## Los diagramas

Están junto al texto que explican, no en un apéndice aparte. Dónde está cada uno:

| Diagrama | Tipo | Dónde |
|---|---|---|
| Entidades del núcleo | entidad-relación | [03 § Las cuatro entidades](03-modelo-de-datos.md#las-cuatro-entidades-del-núcleo) |
| Ciclo de vida de una cuenta | estados | [03 § El ciclo de vida](03-modelo-de-datos.md#el-ciclo-de-vida-de-una-cuenta) |
| El envío asíncrono | secuencia | [03 § El proceso es asíncrono](03-modelo-de-datos.md#el-proceso-es-asíncrono) |
| Versiones y reversos de `ctrclaims` | proceso | [03 § Las versiones y los reversos](03-modelo-de-datos.md#las-versiones-y-los-reversos) |
| La cadena financiera | proceso | [03 § La cadena financiera](03-modelo-de-datos.md#la-cadena-financiera) |
| El panorama de integración | contexto | [05 § Lo que sale de OHI](05-integraciones.md#lo-que-sale-de-ohi) |
| Los 18 eventos por estado disparador | proceso | [05 § Los 18 eventos](05-integraciones.md#los-18-eventos-de-cuenta-médica) |
| Cómo se decide y se arma un evento | decisión | [05 § Cómo se arma el cuerpo](05-integraciones.md#cómo-se-arma-el-cuerpo-de-cada-evento) |
| El mensaje financiero hasta SAP | secuencia | [05 § El mensaje financiero](05-integraciones.md#el-mensaje-financiero) |
| Las dos colas y la cadena de tareas | proceso | [06 § El motor son dos colas](06-operacion.md#el-motor-son-dos-colas) |
| Triaje de tareas en error | decisión | [06 § Cómo buscar y reiniciar](06-operacion.md#cómo-buscar-y-reiniciar) |
| La forma del proyecto | componentes | [07 § La forma del proyecto](07-diseno-de-la-acl.md#la-forma-del-proyecto) |
| El modelo de dominio | clases | [07 § El modelo de dominio](07-diseno-de-la-acl.md#el-modelo-de-dominio) |
| Puertos y adaptadores | clases | [07 § Los puertos](07-diseno-de-la-acl.md#los-puertos-y-sus-dos-implementaciones) |
| La traducción OHI ↔ dominio | proceso | [07 § La traducción](07-diseno-de-la-acl.md#la-traducción-concepto-por-concepto) |
| Una petición de punta a punta | secuencia | [07 § Una petición](07-diseno-de-la-acl.md#una-petición-de-punta-a-punta) |

Son Mermaid, así que GitHub, GitLab y los IDE los renderizan sin plugin. **Los
16 se validaron con el parser de Mermaid**, no a ojo; el guion de validación
extrae cada bloque de los `.md` y lo pasa por `mermaid.parse()`.

## Cómo se construyó, y cómo volver a construirlo

Todo lo que dice esta documentación salió de dos fuentes, y cada afirmación es
de una de las dos:

**El propio OHI prod.** OHI publica su modelo. Tres endpoints lo describen
completo y no hay que adivinar nada:

```
GET  /generic                          → el catálogo de los 453 recursos
GET  /generic/<recurso>/definition     → el esquema de la entidad, con los atributos x-oi-*
GET  /generic/<recurso>/metadata       → el OpenAPI 3.0.1 del recurso
GET  /specific                         → el catálogo de los 70 endpoints de operación
GET  /currentproperties                → las 101 propiedades vigentes del entorno
GET  /outboundintegrationpoints        → los puntos de integración salientes y sus URLs
```

Las credenciales son las de este repositorio (`.env`, ver
[01](01-plataforma-y-entorno.md#credenciales)). Las distribuciones y los
conteos se midieron con `groupBy`/`aggregate` contra los datos reales el
**7 de octubre de 2026**; son una foto y se mueven, pero los órdenes de
magnitud y las proporciones aguantan.

**La documentación oficial de Oracle**, para el significado de los conceptos
del producto:
<https://docs.oracle.com/en/industries/insurance/health-insurance-components/claims-4.25.1/>
— la rama **4.25.1**, que es la versión que corre en prod.

> **Sobre el enlace de documentación que se pasó para este trabajo.** El que se
> entregó (`teams.public.onecdn.static.microsoft/.../atp-safelinks.html`) no es
> documentación de OHI: es la página de error del validador de enlaces seguros
> de Microsoft Teams, la que sale cuando Safe Links no puede comprobar un
> destino. Se perdió la URL real al copiarla desde Teams. Se usó en su lugar la
> documentación oficial de Oracle para la versión 4.25.1, que es la que
> corresponde. Si el enlace original apuntaba a un documento interno de Sura,
> vale la pena volver a pasarlo: lo que esté ahí y no aquí es justo lo que esta
> documentación no puede saber.

Los guiones de extracción quedaron fuera del repositorio porque son de un solo
uso; lo reproducible son los seis endpoints de arriba. Para las consultas que
sí se repiten hay dos *skills* en `.claude/skills/`:
`ohi-lineas-sin-prestador` y `ohi-reiniciar-tareas`.

## Advertencia sobre el alcance

Esta instalación es **OHI Claims**, un componente. No hay aquí
*Policies*, ni *Enrollment*, ni *Authorizations* como aplicaciones: la
afiliación y las autorizaciones viven fuera y entran por integración. Eso se
nota en los datos y está explicado en
[03 — Modelo de datos](03-modelo-de-datos.md#lo-que-esta-instalación-no-usa).
