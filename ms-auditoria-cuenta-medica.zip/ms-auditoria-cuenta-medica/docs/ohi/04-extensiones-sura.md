# 04 — Las extensiones de Sura

OHI se extiende sin tocar el producto. Casi todo lo que hace que este sea «el
OHI de Sura» y no «OHI» está en cuatro mecanismos de configuración:

| Mecanismo | En prod |
|---|---:|
| Campos dinámicos | **663** campos en 46 recursos |
| Lógica dinámica | **612** scripts |
| Mensajes propios | **668** de 1.992 |
| Motivos de pendiente | **230** de 233 |

Nada de esto está en la documentación de Oracle: es configuración de Sura, y la
única fuente de verdad es el propio entorno.

## Campos dinámicos

Un campo dinámico es una columna añadida a una entidad del producto. En el
esquema se reconocen por el atributo `x-oi-dynamic`, cuyo valor dice de qué
clase es:

| Valor | Qué es | En prod |
|---|---|---:|
| `SVNTV` | valor único sin vigencia — un dato que se sobrescribe | **504** |
| `MVNTV` | multivalor sin vigencia — una lista | 6 |
| `SVTV` | valor único con vigencia — guarda historia por fechas | 3 |
| `DYNR` | registro dinámico — un grupo de campos, o una lista de grupos | **150** |

La diferencia que importa en la práctica:

- **`SVNTV` puede ser filtrable o no**, según cómo se configuró (`x-oi-searchable`).
- **`DYNR` nunca es filtrable.** Un registro dinámico se proyecta y se filtra en
  el cliente. Usarlo en `q` o en `groupBy` da `GEN-PROC-ERR`. Y no viene en la
  representación por omisión: hay que pedirlo explícitamente en `fields`.

Referencia de Oracle sobre el mecanismo (no sobre esta configuración):
[Extending Tables](https://docs.oracle.com/en/industries/insurance/health-insurance-components/claims-4.23.2/configuration/extensibility/transactions-extensibility/trans-extending-tables.html).

### Dónde están

| Recurso | Campos dinámicos | |
|---|---:|---|
| `ctrclaims` | 55 | 52 `SVNTV` + 3 `DYNR` |
| `providers` / `individualproviders` / `organizationproviders` | 53 cada uno | 38 `SVNTV` + 15 `DYNR` |
| `procedures` | 52 | 40 `SVNTV` + 9 `DYNR` + 3 `MVNTV` |
| `ctrclaimlines` | 46 | 44 `SVNTV` + 2 `DYNR` |
| `claimlines` | 45 | 43 `SVNTV` + 2 `DYNR` |
| `claims` | 43 | 41 `SVNTV` + 2 `DYNR` |
| `financialtransactionprocessdata` | 34 | 32 `SVNTV` + 2 `DYNR` |
| `activities` / `globalactivities` | 31 cada uno | todos `DYNR` |
| `financialtransactiondetailprocessdata` | 17 | |
| otros 35 recursos | 1 a 9 cada uno | |

El campo a campo está en el [Anexo B](anexo-b-campos-nucleo.md). Aquí va lo que
hay que saber para usarlos.

### Los de `claims` — la cuenta médica colombiana

Son los que convierten una *claim* de OHI en una cuenta médica de la ARL.
Agrupados por para qué sirven:

**Identificación de la factura y del siniestro**

| Campo | Filtrable | Qué es |
|---|---|---|
| `numeroFactura` | sí | el número de factura del prestador |
| `valorFactura` | sí | el valor facturado **según Sura** (no es `totalClaimedAmount`) |
| `valorTotalFactura`, `valorIva` | no | |
| `codigoSiniestro` | sí | el siniestro al que se imputa |
| `estadoSiniestro` | sí | *flexcode* |
| `codigoPoliza` | sí | máx. 14 |
| `fechaEmisionFactura`, `fechaVencimiento` | sí / no | |
| `cufe` | no | el CUFE de la factura electrónica (máx. 140) |
| `codigoFacturaElectronica` | no | |

**El ciclo de la cuenta**

| Campo | Filtrable | Qué es |
|---|---|---|
| `radicadoATEP` | **sí** | el estado de radicación en ATEP. Es el campo que gobierna el borrado de la cuenta en OHI |
| `pendienteManual` | sí | |
| `acuseRecibido` | sí | |
| `esInconsistencia` | **no** | |
| `documentoOriginal`, `fuenteTransaccion`, `multicore`, `ocp` | sí | *flexcodes* |
| `esAtencionInicial` | sí | |
| `requiereGastoTraslado` | sí | dispara el evento de gasto de traslado |
| `claseServicio` | sí | *flexcode* |
| `fechaIngresoAtencion`, `fechaEgresoAtencion` | sí | |
| `codigoAutContingencia` | sí | |
| `notificacionSiifa`, `fechaNotificacionSiifa` | no | |

**Glosa y notas crédito**

| Campo | Filtrable |
|---|---|
| `totalValorGlosado` | **sí** |
| `totalValorNotasCredito`, `numeroNotaCredito`, `valorNotaCredito` | no |

**Impuestos y retenciones**

`comision`, `ivaComision`, `descuento`, `reteFuente`, `reteICA`,
`valorTotalAnticipo` — **ninguno filtrable**.

**Auditoría de usuario**

`usuarioCreacion`, `usuarioModificacion`, `usuarioDesfinaliza` (máx. 10, no
filtrables). Ojo: no son los `createdBy`/`lastUpdatedBy` de OHI, que sí son
fiables y sí se filtran. Estos tres los escribe la integración.

**Registros dinámicos (`DYNR`, no filtrables)**

- `datosAdicionalesSiniestro` — un grupo con `UEN`, `fechaMuerte`, `horaMuerte`,
  `finTratamiento`, `soat`, `tipoEventoSin`.
- `respuestaGlosa` — una **lista** de respuestas a glosa, con `fechaLlegada` y
  los campos de cada respuesta.

### Los de `claimlines` — la línea

Los que más se usan en los reportes y en el diagnóstico:

| Campo | Filtrable | Para qué |
|---|---|---|
| `homologoCups` | sí | el CUPS homólogo con el que se valoriza |
| `multiplesCupsHomologos` | sí | marca de ambigüedad en la homologación |
| `prestacionCodigoNoDefinido` / `...Def` | sí | la prestación que no se pudo resolver |
| `numeroContrato`, `codigoUnicoContratoSIIFA` | sí / no | el contrato con el que se tarifa |
| `archivoRIPS`, `archivoRIPSDescrPrestacion` | sí | la trazabilidad al RIPS |
| `negarPagoSinAutorizacion` | sí | |
| `motivoPagoSinAutorizacion` | no | |
| `prestacionPrioritaria`, `prestadorZonaEspecial` | sí | |
| `tipoSala`, `lateralidad`, `viaDeAcceso`, `contraste`, `fraq`, `partesCuerpo` | mixto | la caracterización clínica del acto |
| `fechaIngreso`, `fechaEgreso`, `horaIngreso`, `horaEgreso`, `horaInicio`, `horaFin` | mixto | |
| `codeTariffISS2000`, `codeTariffISS2001`, `codeTariffSOAT` | no | los manuales tarifarios |
| `valorGlosado`, `observacionesGlosa` | no | |
| `porcentajeIVA`, `montoIVACalculado` | sí / no | |
| `observacionesReembolso` | no | máx. 1.000 |
| `apoyoAnalistaMos`, `sinAgendar`, `cantidadAcompanantes`, `diasDurante`, `trayectoTransporte` | no | |

Y dos `DYNR`: `datosAdicionalesSiniestro` y `detallesGlosa` (lista).

### `ctrclaims` y `ctrclaimlines`: los mismos datos, aplanados y **no filtrables**

Esto es lo más importante del documento. Los campos dinámicos de las entidades
de transacción están **aplanados** y **casi ninguno es filtrable**:

```
claims.claseServicio        flexcode, filtrable
ctrclaims.claseServicio     cadena (30), NO filtrable
ctrclaims.codigoClaseServicio  cadena (3), NO filtrable
```

De los 55 campos dinámicos de `ctrclaims`, **cero son filtrables**. Lo mismo en
`ctrclaimlines`. Un *flexcode* que en `claims` era un objeto con código y
descripción, en `ctrclaims` aparece partido en dos o tres cadenas planas
(`codigoX`, `X`, `descripcionX`).

La consecuencia es dura y hay que diseñar alrededor de ella:

> **Cualquier reporte sobre `ctrclaims` que filtre por un campo de negocio de
> Sura tiene que traerse las filas y filtrar en el cliente.** No hay forma de
> empujar el filtro a OHI.

En la práctica eso significa: filtrar en `q` por lo que sí es filtrable
(`code`, `version`, `reversal`, `entryDate`, `processType`, `formCode`),
proyectar los campos dinámicos que se necesiten, y hacer el resto en memoria.

También significa que **paginar bien no es opcional**: si el filtro de negocio
va en el cliente, hay que recorrer el conjunto completo, y eso son cientos de
miles de filas en páginas de 200.

### `estadoCuentaMedica` — el estado de negocio

Es el campo más consultado y el que tiene más trampas. Resumen:

- Es un **`DYNR`, una lista**: no es un valor, es una colección de sellos.
- **Vive en `ctrclaims` y en `externalclaimsdata`, nunca en `claims`.**
- **No es filtrable.** Se proyecta y se filtra en el cliente.
- **No viene en la representación por omisión**: hay que pedirlo en `fields`.
- **La colección llega sin orden.** Hay que ordenarla en el cliente.
- Una cuenta sin finalizar no tiene `ctrclaims`, así que **no tiene
  `estadoCuentaMedica`**. No falta el dato: no existe todavía.

Los pares código/estado vistos en producción:

| Código | Estado |
|---|---|
| `P` | Pendiente |
| `R` | Revisada |
| `A` | Autorizada |
| `T` | Transmitido |
| `AC` | Aceptación Total |
| `GT` | Glosa Total |
| `D` | Devuelta |
| `ND` | NDevuelta |

Y la trampa de las fechas: los sellos repetidos de una misma transmisión
comparten `codigoReferencia`, así que para ubicar una cuenta en un mes hay que
tomar la **fecha de entrada al estado**, no la última marca. Está con el caso
concreto en
[03 — Las versiones y los sellos](03-modelo-de-datos.md#las-versiones-y-los-sellos).

### Los de `financialtransactionprocessdata` — el asiento de SAP

Los 17 campos que arman el documento contable, todos **no filtrables**:

- Del asiento: `sociedad`, `tipoProcesoSAP`, `fechaContable`, `fechaInicio`,
  `referencia`, `claseCuenta`, `baseDescuento`, `dueDate`, `penaltyDate`.
- De la factura: `numeroFactura`, `fechaEmisionFactura`.
- Del beneficiario: `primerNombre`, `segundoNombre`, `primerApellido`,
  `segundoApellido`, `numeroId`, `typeIdLegal`, `direccion`, `pais`, `regiones`,
  `correoElectronico`, `celular`.
- Genéricos de extensión: `parametro01`..`parametro04`, `porcentaje01`,
  `porcentaje02`, `dia01`, `dia02`, `parametroAdicionalClave`,
  `parametroAdicionalValor`, `texto`.

## Lógica dinámica

**612 scripts**, de los cuales **609 están activos**. Son la implementación de
las reglas de negocio: OHI las invoca desde las reglas de pendiente, las de
derivación, las de tarifación y las de evento.

| Subtipo | Qué es | Cantidad |
|---|---|---:|
| `COND` | condición — devuelve verdadero o falso | 421 |
| `FUNC` | función — calcula o arma un valor | 159 |
| `VAL` | validación | 32 |

La nomenclatura es consistente y vale la pena conocerla, porque dice dónde
buscar:

| Prefijo | Cantidad | Qué agrupa |
|---|---:|---|
| `RP_` | 176 | **Regla de Pendiente** — una por cada motivo `MP_`. `RP_ACP_SUPERA_TOPE_AMBULATORIO`, … |
| `CHK_` | 74 | **Chequeos** de consistencia. `CHK_AUTORIZACION_OBLIGATORIA`, `CHK_AUT_DUPLICIDAD`, … |
| `RA_` | 71 | **Reglas de ajuste/tarifa** — fórmulas del valor permitido. `RA_AJUSTE_ESTANCIA`, `RA_AYUDANTE_CALCULA_UVR`, … |
| `C_` | 64 | **Condiciones** de régimen. `C_AUTORIZACION_DETALLADA`, … |
| `RD_` | 57 | **Reglas de derivación** — rellenan campos. `RD_AFILIADO_REEMBOLSO`, `RD_CODIGO_CONTRATO_SIIFA`, … |
| `RM_` | 31 | **Reglas de mensaje** — validan y levantan novedad |
| `IS_` | 23 | predicados sobre el tipo de dato o el convenio. `IS_CUPS`, `IS_CONVENIO_ISS`, … |
| `RE_` | 16 | **Reglas de evento** — alimentan las integraciones salientes, ver [05](05-integraciones.md) |
| `UTILIDAD_` | 13 | funciones compartidas |
| `ES_` | 10 | condiciones de obligatoriedad de campo |
| `EMPAREJAR_` | 7 | estrategias para emparejar la cuenta con su autorización |
| `ESCENARIO_` | 5 | escenarios de transacción financiera |
| `BENEFIC_`, `PRECIO_` | 4 cada uno | fechas y precios iniciales de beneficios |

Los prefijos de la lógica y los de los mensajes se corresponden: la lógica
`RA_*` levanta mensajes `SURA-RA-*`, la `RD_*` levanta `SURA-RD-*`, la `RM_*`
levanta `SURA-RM-*` y la `CHK_*` levanta `SURA-CHK-*`. Si tienes un código de
mensaje, ya sabes en qué familia de lógica está la causa.

Para ver el cuerpo de un script: `GET /generic/dynamiclogic/{id}`, campo `logic`.
Para probarlo sin tocar datos: `POST /testdynamiclogic/{dynamicLogicCode}`. Y
hay estadísticas de ejecución en `/dynamiclogicstatistics` (tiempo, memoria,
filas leídas, ejecuciones), útiles cuando el proceso se pone lento.

## Los mensajes propios

De los **1.992** mensajes del catálogo, **1.324 son del producto** (`system =
true`) y **668 los configuró Sura**. Las severidades: 1.440 `F` (Fatal /
bloqueante), 551 `I` (Informativa), 1 `D` (Deny).

Los propios son de dos familias muy distintas:

**Los códigos de glosa oficiales** — numéricos, los de la normativa colombiana:
`106-1`, `107-1B`, `108-2`, `111-1`, `123-1`, `127-1`, `330-3`, `355-3`,
`401-1B`, `502-2`, `508-1`, `527-1`, `545-1`, `602-1A`, `603-2B`, `605-1B`,
`821-2`, `834-2`, `834-3`, `834-8`, `848-1`, `849-3`, `849-5`, `849-6`, `849-7`,
`850-1`… Son los que viajan al prestador en la carta de glosa, así que el texto
es el que el prestador lee y no se cambia a la ligera.

**Las reglas internas** — con prefijo, las que se ven en el diagnóstico:

| Prefijo | Cantidad | Qué valida |
|---|---:|---|
| `SURA-CHK` | 63 | chequeos de consistencia clínica (concomitancia, FRAQ, lateralidad, vía de acceso) |
| `SURA-DYLO` | 42 | fallos de la lógica dinámica |
| `SURA-RA` | 29 | reglas de ajuste y tarifa |
| `SURA-RD` | 27 | derivación de campos |
| `SURA-AUT` | 26 | autorización |
| `SURA-RM` | 24 | reglas de mensaje |
| `SURA-INFO` | — | informativos de valorización |
| `ANULACION_001` | 1 | anulado por siniestro cerrado |

Y los del producto, por módulo: `CLA-IP` 290, `CLA-FL` 116 (validaciones a nivel
de campo — aquí está `CLA-FL-PPRI-006`, el del prestador derivado), `RCL-IP` 51,
`GEN-UINT` 35, `REL-IP` 35, `CLA-JSUI` 34, `GEN-RULE` 32, `PRI-IP` 32,
`OHI-IP` 31, `PRI-DPPC` 30, `GEN-HTTP` 28, `CLA-CLAI` 22, `COD-DFUS` 22,
`GEN-DYNA` 21, `CTR-IP` 19, `PRI-PPRC` 19, `FIN-VL` 17, `OHI-DYLO` 17,
`DAT-IP` 16, `FIN-IP` 16, y una cola larga.

Cada mensaje tiene además `externalCode`, `alternativeExternalText`,
`externalTextProvider` y `codigoExternoLeyNueva`: el texto que ve el prestador
puede ser distinto del interno, y hay una variante para la ley nueva. Si el
reporte es para afuera, el campo correcto es el externo.

## Los motivos de pendiente

**233**, de los cuales **230 con prefijo `MP_`**. Están descritos en
[03 — Los pendientes](03-modelo-de-datos.md#los-pendientes). La relación con la
lógica es uno a uno por nombre: `MP_ACP_SUPERA_TOPE_AMBULATORIO` ↔
`RP_ACP_SUPERA_TOPE_AMBULATORIO`.

## Los códigos propios del prestador

Esto explica un número que al principio no cuadra: **4.937 sistemas de códigos
flexibles** (`flexcodesystems`) para 91.091 códigos.

| Prefijo del sistema | Cantidad | Qué es |
|---|---:|---|
| `NI_<nit>_PROPIO` | 3.330 | «Códigos propios Prestador» — personas jurídicas, por NIT |
| `CC_<cedula>_PROPIO` | 1.405 | lo mismo para prestadores persona natural |
| el resto (~200) | | definiciones de registros dinámicos de actividades (`CLAIMS_OUT`, `RESOLVE_PEND`, `LARGE_CLAIMS_SUBMIT`, …) y catálogos del producto |

Es decir: **cada prestador tiene su propio sistema de códigos** en OHI, con los
códigos con los que ese prestador factura, y la homologación al CUPS pasa por
ahí. 4.735 de los 4.937 sistemas son uno por prestador.

Dos consecuencias:

1. El `homologoCups` de una línea es el resultado de resolver el código propio
   del prestador contra el catálogo. Cuando eso falla, aparece
   `prestacionCodigoNoDefinido` y la línea se queda sin valorizar.
2. Dar de alta un prestador nuevo implica darle de alta su sistema de códigos.
   Es configuración, no datos.

Los sistemas tienen `dynValidation` (lógica de validación) y `referenceSheet`
(hoja de referencia), así que la homologación puede llevar reglas propias por
prestador.
