# Anexo B — Campos de las cuatro entidades del núcleo

Volcado de `/generic/<recurso>/definition` para `claims`, `claimlines`,
`ctrclaims` y `ctrclaimlines`. Es la referencia de campo a campo; la lectura
en prosa está en [03-modelo-de-datos.md](03-modelo-de-datos.md).

La columna **Dinámico** trae el tipo de campo dinámico cuando el campo es una
extensión y no parte del producto: `SVNTV` valor único sin vigencia, `MVNTV`
multivalor sin vigencia, `SVTV` valor único con vigencia, `DYNR` registro
dinámico derivado.

**Filtrable** es el atributo `x-oi-searchable` que publica OHI. Un `no` ahí
significa que el campo **no** se puede usar en `q` ni en `groupBy`: la consulta
falla con `GEN-PROC-ERR`. Un `—` es que OHI no declara el atributo (los campos
propios del producto, que sí se filtran).

## `claims` — la cuenta médica viva

186 campos.

| Campo | Tipo | Dinámico | Filtrable | Notas |
|---|---|---|---|---|
| `acuseRecibido` | string | SVNTV | sí | máx 100 |
| `authorizationCode` | string |  | — | máx 30 |
| `billList` | lista de `bills` |  | — |  |
| `brand` | → `brands` |  | — |  |
| `changedInUI` | boolean |  | — |  |
| `claimDate` | string |  | — | date |
| `claimDiagnosisList` | lista de `claimdiagnoses` |  | — |  |
| `claimForm` | → `claimforms` |  | — | obligatorio |
| `claimLineList` | lista de `claimlines` |  | — |  |
| `claimMessageList` | lista de `claimmessages` |  | — |  |
| `claimPendReasonList` | lista de `claimpendreasons` |  | — |  |
| `claimSet` | → `claimsets` |  | — |  |
| `claimStatusHistoryList` | lista de `claimstatushistory` |  | — |  |
| `claimSubmitHistoryList` | lista de `claimsubmithistory` |  | — | no actualizable |
| `claimTagActionList` | lista de `claimtagactions` |  | — |  |
| `claimUnfinalizeReasonList` | lista de `claimunfinalizereasons` |  | — |  |
| `claimantAddress` | string |  | — | máx 100 |
| `claimantDob` | string |  | — | máx 10 |
| `claimantFieldName` | string |  | — | máx 30 |
| `claimantFieldValue` | string |  | — | máx 30 |
| `claimantName` | string |  | — | máx 200 |
| `claimantProvCode` | string |  | — | máx 30 |
| `claimantProvCodeDef` | string |  | — | máx 30 |
| `claimantProvider` | → `providers` |  | — |  |
| `claimantRelCode` | string |  | — | máx 30 |
| `claimantRelation` | → `relations` |  | — |  |
| `claseServicio` | flexcode | SVNTV | sí |  |
| `classification` | → `classifications` |  | — |  |
| `classificationScheme` | → `classificationschemes` |  | — |  |
| `code` | string |  | — | obligatorio, máx 30 |
| `codigoAutContingencia` | string | SVNTV | sí | máx 30 |
| `codigoFacturaElectronica` | number | SVNTV | **no** |  |
| `codigoPoliza` | string | SVNTV | sí | máx 14 |
| `codigoSiniestro` | string | SVNTV | sí | máx 20 |
| `comision` | number | SVNTV | **no** |  |
| `createdBy` | string |  | — | solo lectura |
| `createdByUserName` | string |  | **no** | solo lectura |
| `creationDate` | → `timestampobject` |  | — |  |
| `cufe` | string | SVNTV | **no** | máx 140 |
| `dataAccessGroup` | → `dataaccessgroups` |  | — |  |
| `datosAdicionalesSiniestro` | objeto | DYNR | — |  |
| `descuento` | number | SVNTV | **no** |  |
| `documentoOriginal` | flexcode | SVNTV | sí |  |
| `dueDate` | string |  | — | date |
| `emergency` | boolean |  | — | obligatorio |
| `endDate` | string |  | — | solo lectura, date |
| `entryDate` | string |  | — | obligatorio, date |
| `esAtencionInicial` | flexcode | SVNTV | sí |  |
| `esInconsistencia` | flexcode | SVNTV | **no** |  |
| `estadoSiniestro` | flexcode | SVNTV | sí |  |
| `expirationDate` | string |  | — | date |
| `externalBenefits` | boolean |  | — | obligatorio |
| `externalClaimsData` | → `externalclaimsdata` |  | — |  |
| `externalPricing` | boolean |  | — | obligatorio |
| `externalRemarks` | string |  | — | máx 2000 |
| `fechaEgresoAtencion` | string | SVNTV | sí | date |
| `fechaEmisionFactura` | string | SVNTV | sí | date |
| `fechaIngresoAtencion` | string | SVNTV | sí | date |
| `fechaNotificacionSiifa` | string | SVNTV | **no** | date |
| `fechaVencimiento` | string | SVNTV | **no** | date |
| `fuenteTransaccion` | flexcode | SVNTV | sí |  |
| `highPriority` | boolean |  | — |  |
| `horaCreacionAutorizacion` | string | SVNTV | **no** | máx 5 |
| `id` | string |  | — | solo lectura |
| `ignoreHistory` | boolean |  | — | obligatorio |
| `internalRemarks` | string |  | — | máx 2000 |
| `ivaComision` | number | SVNTV | **no** |  |
| `keepEnrollmentData` | boolean |  | — |  |
| `largeClaim` | → `claims` |  | — |  |
| `lastUpdatedBy` | string |  | — | solo lectura |
| `lastUpdatedByUserName` | string |  | **no** | solo lectura |
| `lastUpdatedDate` | → `timestampobject` |  | — |  |
| `locationAddress` | string |  | — | máx 100 |
| `locationFieldName` | string |  | — | máx 30 |
| `locationFieldValue` | string |  | — | máx 30 |
| `locationName` | string |  | — | máx 200 |
| `locationProvCode` | string |  | — | máx 30 |
| `locationProvCodeDef` | string |  | — | máx 30 |
| `locationProvider` | → `providers` |  | — |  |
| `locationType` | → `locationtypes` |  | — |  |
| `locationTypeCode` | string |  | — | máx 30 |
| `manual` | boolean |  | — | obligatorio |
| `multicore` | flexcode | SVNTV | sí |  |
| `nextPayerCode` | string |  | — | máx 30 |
| `notificacionSiifa` | flexcode | SVNTV | **no** |  |
| `numeroFactura` | string | SVNTV | sí | máx 40 |
| `numeroNotaCredito` | string | SVNTV | **no** | máx 40 |
| `objectLastUpdatedBy` | string |  | — |  |
| `objectLastUpdatedDate` | → `timestampobject` |  | — |  |
| `objectVersionNumber` | integer |  | — | no insertable, int64 |
| `ocp` | flexcode | SVNTV | **no** |  |
| `op` | string |  | — | no insertable |
| `paidDate` | string |  | — | date |
| `payBeneficiaryAddress` | string |  | — | máx 100 |
| `payBeneficiaryDob` | string |  | — | máx 10 |
| `payBeneficiaryFieldName` | string |  | — | máx 30 |
| `payBeneficiaryFieldValue` | string |  | — | máx 30 |
| `payBeneficiaryName` | string |  | — | máx 200 |
| `payBeneficiaryProvCode` | string |  | — | máx 30 |
| `payBeneficiaryProvCodeDef` | string |  | — | máx 30 |
| `payBeneficiaryRelCode` | string |  | — | máx 30 |
| `payReceiverAddress` | string |  | — | máx 100 |
| `payReceiverDob` | string |  | — | máx 10 |
| `payReceiverFieldName` | string |  | — | máx 30 |
| `payReceiverFieldValue` | string |  | — | máx 30 |
| `payReceiverName` | string |  | — | máx 200 |
| `payReceiverProvCode` | string |  | — | máx 30 |
| `payReceiverProvCodeDef` | string |  | — | máx 30 |
| `payReceiverRelCode` | string |  | — | máx 30 |
| `payerCode` | → `payercodes` |  | — |  |
| `paymentBeneficiaryProvider` | → `providers` |  | — |  |
| `paymentBeneficiaryRelation` | → `relations` |  | — |  |
| `paymentReceiverProvider` | → `providers` |  | — |  |
| `paymentReceiverRelation` | → `relations` |  | — |  |
| `paymentSpecificationReceiverProvider` | → `providers` |  | — |  |
| `paymentSpecificationReceiverRelation` | → `relations` |  | — |  |
| `pendienteManual` | flexcode | SVNTV | sí |  |
| `person` | → `persons` |  | — |  |
| `policyProductList` | lista de `policyproducts` |  | — |  |
| `precedingPayerCode` | string |  | — | máx 30 |
| `preprocessingDone` | boolean |  | — | obligatorio |
| `priceDate` | string |  | — | date |
| `pricingDone` | boolean |  | — | obligatorio |
| `processCategory` | string |  | — | no actualizable, máx 1 |
| `processType` | string |  | — | obligatorio, no actualizable, máx 1 |
| `providerEntityReference` | string |  | — | máx 60 |
| `providerReference` | string |  | — | máx 250 |
| `radicadoATEP` | flexcode | SVNTV | sí |  |
| `receiptDate` | string |  | — | date |
| `referenceCode` | string |  | — | máx 30 |
| `referralProvider` | → `providers` |  | — |  |
| `referralProviderAddress` | string |  | — | máx 100 |
| `referralProviderCode` | string |  | — | máx 30 |
| `referralProviderCodeDef` | string |  | — | máx 30 |
| `referralProviderFieldName` | string |  | — | máx 30 |
| `referralProviderFieldValue` | string |  | — | máx 30 |
| `referralProviderName` | string |  | — | máx 200 |
| `requiereGastoTraslado` | flexcode | SVNTV | sí |  |
| `respuestaGlosa` | lista embebida | DYNR | — |  |
| `reteFuente` | number | SVNTV | **no** |  |
| `reteICA` | number | SVNTV | **no** |  |
| `sendOutForPreprocessing` | boolean |  | — | obligatorio |
| `sendOutForPricing` | boolean |  | — | obligatorio |
| `serviceProvider` | → `providers` |  | — |  |
| `serviceProviderAddress` | string |  | — | máx 100 |
| `serviceProviderCode` | string |  | — | máx 30 |
| `serviceProviderCodeDef` | string |  | — | máx 30 |
| `serviceProviderFieldName` | string |  | — | máx 30 |
| `serviceProviderFieldValue` | string |  | — | máx 30 |
| `serviceProviderName` | string |  | — | máx 200 |
| `serviceSpecialty` | → `specialties` |  | — |  |
| `serviceSpecialtyCode` | string |  | — | máx 30 |
| `servicedEntityAddress` | string |  | — | máx 100 |
| `servicedEntityCode` | string |  | — | máx 30 |
| `servicedEntityDate` | string |  | — | máx 10 |
| `servicedEntityFieldName` | string |  | — | máx 30 |
| `servicedEntityFieldValue` | string |  | — | máx 30 |
| `servicedEntityName` | string |  | — | máx 200 |
| `servicedEntityType` | string |  | — | máx 30 |
| `specReceiverAddress` | string |  | — | máx 100 |
| `specReceiverDob` | string |  | — | máx 10 |
| `specReceiverFieldName` | string |  | — | máx 30 |
| `specReceiverFieldValue` | string |  | — | máx 30 |
| `specReceiverName` | string |  | — | máx 200 |
| `specReceiverProvCode` | string |  | — | máx 30 |
| `specReceiverProvCodeDef` | string |  | — | máx 30 |
| `specReceiverRelCode` | string |  | — | máx 30 |
| `startDate` | string |  | — | solo lectura, date |
| `status` | string |  | — | obligatorio, solo lectura, máx 30 |
| `taskEventId` | string |  | — | máx 200 |
| `totalAllowedAmount` | monto |  | — | solo lectura |
| `totalClaimedAmount` | monto |  | — | solo lectura |
| `totalCoveredAmount` | monto |  | — | solo lectura |
| `totalRetentionAmount` | monto |  | — |  |
| `totalValorGlosado` | number | SVNTV | sí |  |
| `totalValorNotasCredito` | number | SVNTV | **no** |  |
| `transactionSource` | → `transactionsources` |  | — |  |
| `type` | string |  | — | obligatorio, máx 1 |
| `usuarioCreacion` | string | SVNTV | **no** | máx 10 |
| `usuarioDesfinaliza` | string | SVNTV | **no** | máx 10 |
| `usuarioModificacion` | string | SVNTV | **no** | máx 10 |
| `valorFactura` | number | SVNTV | sí |  |
| `valorIva` | number | SVNTV | **no** |  |
| `valorNotaCredito` | number | SVNTV | **no** |  |
| `valorTotalAnticipo` | number | SVNTV | **no** |  |
| `valorTotalFactura` | number | SVNTV | **no** |  |

## `claimlines` — la línea viva

195 campos.

| Campo | Tipo | Dinámico | Filtrable | Notas |
|---|---|---|---|---|
| `adjudicationCaseDetailList` | lista de `adjudicationcasedetails` |  | — |  |
| `allowedAmount` | monto |  | — |  |
| `allowedNumberOfUnits` | number |  | — |  |
| `amount` | number | SVNTV | **no** |  |
| `apoyoAnalistaMos` | flexcode | SVNTV | **no** |  |
| `archivoRIPS` | flexcode | SVNTV | sí |  |
| `archivoRIPSDescrPrestacion` | string | SVNTV | sí | máx 100 |
| `authorization` | → `authorizations` |  | — |  |
| `authorizationCode` | string |  | — | máx 30 |
| `authorizationExceptionType` | string |  | — | máx 30 |
| `benefitsAgeInputDate` | string |  | — | date |
| `benefitsInputAmount` | monto |  | — |  |
| `benefitsInputDate` | string |  | — | date |
| `benefitsProvider` | → `providers` |  | — |  |
| `benefitsProviderAddress` | string |  | — | máx 100 |
| `benefitsProviderCode` | string |  | — | máx 30 |
| `benefitsProviderCodeDef` | string |  | — | máx 30 |
| `benefitsProviderFieldName` | string |  | — | máx 30 |
| `benefitsProviderFieldValue` | string |  | — | máx 30 |
| `benefitsProviderName` | string |  | — | máx 200 |
| `bill` | → `bills` |  | — |  |
| `cantidadAcompanantes` | flexcode | SVNTV | **no** |  |
| `claim` | → `claims` |  | — | obligatorio |
| `claimLineAppliedParameterList` | lista de `claimlineappliedparameters` |  | — |  |
| `claimLineBenefitSpecificationList` | lista de `claimlinebenefitspecifications` |  | — |  |
| `claimLineContractReferenceList` | lista de `claimlinecontractreferences` |  | — |  |
| `claimLineCoverageList` | lista de `claimlinecoverages` |  | — |  |
| `claimLineDiagnosisList` | lista de `claimlinediagnoses` |  | — |  |
| `claimLineLimitList` | lista de `claimlinelimits` |  | — |  |
| `claimLineMessageList` | lista de `claimlinemessages` |  | — |  |
| `claimLineModifierList` | lista de `claimlinemodifiers` |  | — |  |
| `claimLineOverride` | → `claimlineoverrides` |  | — |  |
| `claimLineParameterList` | lista de `claimlineparameters` |  | — |  |
| `claimLinePendReasonList` | lista de `claimlinependreasons` |  | — |  |
| `claimLineProviderPricingClauseList` | lista de `claimlineproviderpricingclauses` |  | — |  |
| `claimLineRuleCoverageList` | lista de `claimlinerulecoverages` |  | — |  |
| `claimSubLineList` | lista de `claimsublines` |  | — |  |
| `claimedAmount` | monto |  | — |  |
| `claimedNumberOfUnits` | number |  | — | obligatorio |
| `claseServicio` | flexcode | SVNTV | sí |  |
| `classification` | → `classifications` |  | — |  |
| `code` | string |  | — | obligatorio, máx 30 |
| `codeTariffISS2000` | flexcode | SVNTV | **no** |  |
| `codeTariffISS2001` | flexcode | SVNTV | **no** |  |
| `codeTariffSOAT` | flexcode | SVNTV | **no** |  |
| `codigoSiniestro` | string | SVNTV | sí | máx 20 |
| `codigoUnicoContratoSIIFA` | string | SVNTV | **no** | máx 300 |
| `consumptionDate` | string |  | — | date |
| `contraste` | flexcode | SVNTV | **no** |  |
| `coveredAmount` | monto |  | — |  |
| `coveredNumberOfUnits` | number |  | — |  |
| `createdBy` | string |  | — | solo lectura |
| `createdByUserName` | string |  | **no** | solo lectura |
| `creationDate` | → `timestampobject` |  | — |  |
| `datosAdicionalesSiniestro` | objeto | DYNR | — |  |
| `detallesGlosa` | lista embebida | DYNR | — |  |
| `diasDurante` | number | SVNTV | **no** |  |
| `emergency` | boolean |  | — | obligatorio |
| `encounter` | boolean |  | — | obligatorio |
| `endDate` | string |  | — | date |
| `episodeDetail` | → `episodedetails` |  | — |  |
| `episodeIdentifier` | string |  | — | máx 30 |
| `fechaEgreso` | string | SVNTV | sí | date |
| `fechaIngreso` | string | SVNTV | sí | date |
| `fechaOrdenMedica` | string | SVNTV | **no** | date |
| `fraq` | flexcode | SVNTV | **no** |  |
| `homologoCups` | string | SVNTV | sí | máx 30 |
| `horaEgreso` | string | SVNTV | **no** | máx 5 |
| `horaFin` | string | SVNTV | **no** | máx 5 |
| `horaIngreso` | string | SVNTV | **no** | máx 5 |
| `horaInicio` | string | SVNTV | **no** | máx 5 |
| `id` | string |  | — | solo lectura |
| `keepBenefits` | boolean |  | — | obligatorio |
| `keepPricePrincipalProcs` | boolean |  | — | obligatorio |
| `keepPricing` | boolean |  | — | obligatorio |
| `lastUpdatedBy` | string |  | — | solo lectura |
| `lastUpdatedByUserName` | string |  | **no** | solo lectura |
| `lastUpdatedDate` | → `timestampobject` |  | — |  |
| `lateralidad` | flexcode | SVNTV | **no** |  |
| `lineGroupingCriteria` | string |  | — | máx 200 |
| `locationAddress` | string |  | — | máx 100 |
| `locationFieldName` | string |  | — | máx 30 |
| `locationFieldValue` | string |  | — | máx 30 |
| `locationName` | string |  | — | máx 200 |
| `locationProvCode` | string |  | — | máx 30 |
| `locationProvCodeDef` | string |  | — | máx 30 |
| `locationProvider` | → `providers` |  | — |  |
| `locationType` | → `locationtypes` |  | — |  |
| `locationTypeCode` | string |  | — | máx 30 |
| `locked` | boolean |  | — | obligatorio |
| `manualBenefits` | boolean |  | — | obligatorio |
| `manualPricing` | boolean |  | — | obligatorio |
| `montoIVACalculado` | number | SVNTV | **no** |  |
| `motivoPagoSinAutorizacion` | flexcode | SVNTV | **no** |  |
| `multiplesCupsHomologos` | flexcode | SVNTV | sí |  |
| `negarPagoSinAutorizacion` | flexcode | SVNTV | sí |  |
| `numeroContrato` | string | SVNTV | sí | máx 30 |
| `objectVersionNumber` | integer |  | — | no insertable, int64 |
| `observacionesGlosa` | string | SVNTV | **no** | máx 1000 |
| `observacionesReembolso` | string | SVNTV | **no** | máx 1000 |
| `ocp` | flexcode | SVNTV | sí |  |
| `op` | string |  | — | no insertable |
| `originalClaimLine` | → `claimlines` |  | — |  |
| `partesCuerpo` | flexcode | SVNTV | **no** |  |
| `payReceiverAddress` | string |  | — | máx 100 |
| `payReceiverDob` | string |  | — | máx 10 |
| `payReceiverFieldName` | string |  | — | máx 60 |
| `payReceiverFieldValue` | string |  | — | máx 30 |
| `payReceiverName` | string |  | — | máx 200 |
| `payReceiverProvCode` | string |  | — | máx 30 |
| `payReceiverProvCodeDef` | string |  | — | máx 30 |
| `payReceiverRelCode` | string |  | — | máx 30 |
| `paymentReceiverProvider` | → `providers` |  | — |  |
| `paymentReceiverRelation` | → `relations` |  | — |  |
| `person` | → `persons` |  | — |  |
| `porcentajeIVA` | number | SVNTV | sí |  |
| `precedingPayerPaidAmount` | monto |  | — |  |
| `prestacionCodigoNoDefinido` | string | SVNTV | sí | máx 30 |
| `prestacionCodigoNoDefinidoDef` | string | SVNTV | sí | máx 30 |
| `prestacionPadre` | flexcode | SVNTV | **no** |  |
| `prestacionPrioritaria` | flexcode | SVNTV | sí |  |
| `prestadorZonaEspecial` | flexcode | SVNTV | sí |  |
| `priceIndProviderAddress` | string |  | — | máx 100 |
| `priceIndProviderCode` | string |  | — | máx 30 |
| `priceIndProviderCodeDef` | string |  | — | máx 30 |
| `priceIndProviderFieldName` | string |  | — | máx 30 |
| `priceIndProviderFieldValue` | string |  | — | máx 30 |
| `priceIndProviderName` | string |  | — | máx 200 |
| `priceIndividualProvider` | → `individualproviders` |  | — |  |
| `priceInputDate` | string |  | — | date |
| `priceInputNumberOfUnits` | number |  | — |  |
| `priceOrgProviderAddress` | string |  | — | máx 100 |
| `priceOrgProviderCode` | string |  | — | máx 30 |
| `priceOrgProviderCodeDef` | string |  | — | máx 30 |
| `priceOrgProviderFieldName` | string |  | — | máx 30 |
| `priceOrgProviderFieldValue` | string |  | — | máx 30 |
| `priceOrgProviderName` | string |  | — | máx 100 |
| `priceOrganizationProvider` | → `organizationproviders` |  | — |  |
| `pricePrincipalProcedure1` | boolean |  | — | obligatorio |
| `pricePrincipalProcedure2` | boolean |  | — | obligatorio |
| `pricePrincipalProcedure3` | boolean |  | — | obligatorio |
| `procedure` | → `procedures` |  | — |  |
| `procedure2` | → `procedures` |  | — |  |
| `procedure2Code` | string |  | — | máx 30 |
| `procedure2CodeDef` | string |  | — | máx 30 |
| `procedure3` | → `procedures` |  | — |  |
| `procedure3Code` | string |  | — | máx 30 |
| `procedure3CodeDef` | string |  | — | máx 30 |
| `procedureCode` | string |  | — | máx 30 |
| `procedureCodeDef` | string |  | — | máx 30 |
| `processAsIn` | boolean |  | — | obligatorio |
| `providerEntityReference` | string |  | — | máx 60 |
| `providerReference` | string |  | — | máx 250 |
| `referenceCode` | string |  | — | máx 30 |
| `referralProvider` | → `providers` |  | — |  |
| `referralProviderAddress` | string |  | — | máx 100 |
| `referralProviderCode` | string |  | — | máx 30 |
| `referralProviderCodeDef` | string |  | — | máx 30 |
| `referralProviderFieldName` | string |  | — | máx 30 |
| `referralProviderFieldValue` | string |  | — | máx 30 |
| `referralProviderName` | string |  | — | máx 200 |
| `replaced` | boolean |  | — | obligatorio |
| `replacementClaimLine` | → `claimlines` |  | — |  |
| `reservationCode` | string |  | — | máx 30 |
| `reservationLine` | → `claimlines` |  | — |  |
| `reservationLineCode` | string |  | — | máx 30 |
| `retentionAmount` | monto |  | — |  |
| `sequence` | integer |  | — | obligatorio, int64 |
| `serviceProvider` | → `providers` |  | — |  |
| `serviceProviderAddress` | string |  | — | máx 100 |
| `serviceProviderCode` | string |  | — | máx 30 |
| `serviceProviderCodeDef` | string |  | — | máx 30 |
| `serviceProviderFieldName` | string |  | — | máx 30 |
| `serviceProviderFieldValue` | string |  | — | máx 30 |
| `serviceProviderName` | string |  | — | máx 200 |
| `serviceSpecialty` | → `specialties` |  | — |  |
| `serviceSpecialtyCode` | string |  | — | máx 30 |
| `servicedEntityAddress` | string |  | — | máx 100 |
| `servicedEntityCode` | string |  | — | máx 30 |
| `servicedEntityDate` | string |  | — | máx 10 |
| `servicedEntityFieldName` | string |  | — | máx 30 |
| `servicedEntityFieldValue` | string |  | — | máx 30 |
| `servicedEntityName` | string |  | — | máx 200 |
| `servicedEntityType` | string |  | — | máx 30 |
| `sinAgendar` | flexcode | SVNTV | **no** |  |
| `skipTag` | → `skiptags` |  | — |  |
| `skipTagAllowed` | → `skiptags` |  | — |  |
| `startDate` | string |  | — | obligatorio, date |
| `status` | string |  | — | solo lectura, máx 30 |
| `tipoSala` | flexcode | SVNTV | sí |  |
| `transactionSource` | → `transactionsources` |  | — |  |
| `trayectoTransporte` | flexcode | SVNTV | **no** |  |
| `valorGlosado` | number | SVNTV | **no** |  |
| `viaDeAcceso` | flexcode | SVNTV | **no** |  |
| `waitingPeriodInputDate` | string |  | — | date |

## `ctrclaims` — la foto de la cuenta al finalizar

161 campos.

| Campo | Tipo | Dinámico | Filtrable | Notas |
|---|---|---|---|---|
| `acuseRecibido` | string | SVNTV | **no** | máx 100 |
| `authorizationCode` | string |  | — | máx 30 |
| `brandAccessCode` | string |  | — | máx 100 |
| `brandCode` | string |  | — | máx 30 |
| `brandDescription` | string |  | — | máx 200 |
| `brandPayerAccessCode` | string |  | — | máx 100 |
| `brandPayerName` | string |  | — | máx 100 |
| `claimDate` | string |  | — | date |
| `claimSetCode` | string |  | — | máx 30 |
| `claimantAccessCode` | string |  | — | máx 100 |
| `claimantContactAccessCode` | string |  | — | máx 100 |
| `claimantName` | string |  | — | máx 200 |
| `claimantProvCode` | string |  | — | máx 30 |
| `claimantProvCodeDef` | string |  | — | máx 30 |
| `claimantRelCode` | string |  | — | máx 30 |
| `claseServicio` | string | SVNTV | **no** | máx 30 |
| `classificationCode` | string |  | — | máx 30 |
| `classificationSchemeCode` | string |  | — | máx 30 |
| `code` | string |  | — | obligatorio, máx 30 |
| `codigoAtencionInicial` | string | SVNTV | **no** | máx 2 |
| `codigoAutContingencia` | string | SVNTV | **no** | máx 30 |
| `codigoClaseServicio` | string | SVNTV | **no** | máx 3 |
| `codigoDocumentoOriginal` | string | SVNTV | **no** | máx 2 |
| `codigoEstadoSiniestro` | string | SVNTV | **no** | máx 10 |
| `codigoFuenteTransaccion` | string | SVNTV | **no** | máx 30 |
| `codigoOCP` | string | SVNTV | **no** | máx 1 |
| `codigoPoliza` | string | SVNTV | **no** | máx 14 |
| `codigoSiniestro` | string | SVNTV | **no** | máx 20 |
| `codigoTipoAtencion` | string | SVNTV | **no** | máx 3 |
| `comision` | number | SVNTV | **no** |  |
| `createdBy` | string |  | — | solo lectura |
| `createdByUserName` | string |  | **no** | solo lectura |
| `creationDate` | → `timestampobject` |  | — |  |
| `ctrBillList` | lista de `ctrbills` |  | — |  |
| `ctrClaimDiagnosisList` | lista de `ctrclaimdiagnoses` |  | — |  |
| `ctrClaimLineList` | lista de `ctrclaimlines` |  | — |  |
| `ctrClaimMessageList` | lista de `ctrclaimmessages` |  | — |  |
| `ctrClaimPolicyProductList` | lista de `ctrclaimpolicyproducts` |  | — |  |
| `ctrClaimUnfinalizeReasonList` | lista de `ctrclaimunfinalizereasons` |  | — |  |
| `ctrStatusHistoryList` | lista de `ctrstatushistory` |  | — |  |
| `ctrTransactionLabelList` | lista de `ctrtransactionlabels` |  | — |  |
| `cufe` | string | SVNTV | **no** | máx 140 |
| `dataAccessGroupAccessCode` | string |  | — | máx 100 |
| `dataAccessGroupCode` | string |  | — | máx 30 |
| `datosAdicionalesSiniestro` | objeto | DYNR | — |  |
| `descripcionAtencionInicial` | string | SVNTV | **no** | máx 2 |
| `descripcionFuenteTransaccion` | string | SVNTV | **no** | máx 100 |
| `descripcionOCP` | string | SVNTV | **no** | máx 2 |
| `descrpcionDocumentoOriginal` | string | SVNTV | **no** | máx 2 |
| `descuento` | number | SVNTV | **no** |  |
| `dueDate` | string |  | — | date |
| `emergencyIndicator` | string |  | — | máx 1 |
| `endDate` | string |  | — | date |
| `entryDate` | string |  | — | date |
| `estadoCuentaMedica` | lista embebida | DYNR | — |  |
| `expirationDate` | string |  | — | date |
| `externalClaimsData` | → `externalclaimsdata` |  | — |  |
| `externalRemarks` | string |  | — | máx 2000 |
| `fechaEgresoAtencion` | string | SVNTV | **no** | date |
| `fechaEmisionFactura` | string | SVNTV | **no** | date |
| `fechaIngresoAtencion` | string | SVNTV | **no** | date |
| `fechaLlegada` | string | SVNTV | **no** | date |
| `fechaVencimiento` | string | SVNTV | **no** | date |
| `formCode` | string |  | — | máx 30 |
| `formDescription` | string |  | — | máx 60 |
| `horaCreacionAutorizacion` | string | SVNTV | **no** | máx 5 |
| `id` | string |  | — | solo lectura |
| `ignoreHistoryIndicator` | string |  | — | máx 1 |
| `incluyeTransfuciones` | string | SVNTV | **no** | máx 1 |
| `indicadorJuridicoRF` | string | SVNTV | **no** | máx 2 |
| `indicadorNaturalRF` | string | SVNTV | **no** | máx 2 |
| `internalRemarks` | string |  | — | máx 2000 |
| `ivaComision` | number | SVNTV | **no** |  |
| `largeClaimCode` | string |  | — | máx 30 |
| `lastUpdatedBy` | string |  | — | solo lectura |
| `lastUpdatedByUserName` | string |  | **no** | solo lectura |
| `lastUpdatedDate` | → `timestampobject` |  | — |  |
| `locationProvAddress` | string |  | — | máx 400 |
| `locationProvCode` | string |  | — | máx 30 |
| `locationProvCodeDef` | string |  | — | máx 30 |
| `locationProvName` | string |  | — | máx 200 |
| `locationTypeCode` | string |  | — | máx 30 |
| `locationTypeDescription` | string |  | — | máx 200 |
| `manualIndicator` | string |  | — | máx 1 |
| `multicore` | string | SVNTV | **no** | máx 2 |
| `nextPayerCode` | string |  | — | máx 30 |
| `nivelServicio` | string | SVNTV | **no** | máx 20 |
| `numeroFactura` | string | SVNTV | **no** | máx 40 |
| `numeroNotaCredito` | string | SVNTV | **no** | máx 40 |
| `objectVersionNumber` | integer |  | — | no insertable, int64 |
| `op` | string |  | — | no insertable |
| `paidDate` | string |  | — | date |
| `payBeneficiaryName` | string |  | — | máx 200 |
| `payBeneficiaryProvCode` | string |  | — | máx 30 |
| `payBeneficiaryProvCodeDef` | string |  | — | máx 30 |
| `payBeneficiaryRelCode` | string |  | — | máx 30 |
| `payReceiverName` | string |  | — | máx 200 |
| `payReceiverProvCode` | string |  | — | máx 30 |
| `payReceiverProvCodeDef` | string |  | — | máx 30 |
| `payReceiverRelCode` | string |  | — | máx 30 |
| `payerCode` | string |  | — | máx 30 |
| `pendienteManual` | string | SVNTV | **no** | máx 1 |
| `precedingPayerCode` | string |  | — | máx 30 |
| `priceDate` | string |  | — | date |
| `processCategory` | string |  | — | máx 1 |
| `processType` | string |  | — | máx 1 |
| `providerEntityReference` | string |  | — | máx 60 |
| `providerReference` | string |  | — | máx 250 |
| `radicadoATEP` | string | SVNTV | **no** | máx 2 |
| `receiptDate` | string |  | — | date |
| `referenceCode` | string |  | — | máx 30 |
| `referralProvCode` | string |  | — | máx 30 |
| `referralProvCodeDef` | string |  | — | máx 30 |
| `referralProvName` | string |  | — | máx 200 |
| `requiereGastoTraslado` | string | SVNTV | **no** | máx 2 |
| `respuestaGlosa` | lista embebida | DYNR | — |  |
| `reteFuente` | number | SVNTV | **no** |  |
| `reteICA` | number | SVNTV | **no** |  |
| `reversal` | boolean |  | — | obligatorio |
| `serviceProvCode` | string |  | — | máx 30 |
| `serviceProvCodeDef` | string |  | — | máx 30 |
| `serviceProvName` | string |  | — | máx 200 |
| `serviceSpecialtyCode` | string |  | — | máx 30 |
| `servicedEntityAccessCode` | string |  | — | máx 100 |
| `servicedEntityCode` | string |  | — | máx 30 |
| `servicedEntityContactAccessCode` | string |  | — | máx 100 |
| `servicedEntityDate` | string |  | — | máx 10 |
| `servicedEntityDateInterpretation` | string |  | — | máx 1 |
| `servicedEntityName` | string |  | — | máx 200 |
| `servicedEntityType` | string |  | — | máx 30 |
| `specReceiverName` | string |  | — | máx 200 |
| `specReceiverProvCode` | string |  | — | máx 30 |
| `specReceiverProvCodeDef` | string |  | — | máx 30 |
| `specReceiverRelCode` | string |  | — | máx 30 |
| `startDate` | string |  | — | date |
| `tiempoVigenciaDias` | number | SVNTV | **no** |  |
| `tipoAtencion` | string | SVNTV | **no** | máx 30 |
| `tipoAutorizacion` | string | SVNTV | **no** | máx 5 |
| `tipoIndicadorRF` | string | SVNTV | **no** | máx 2 |
| `tipoServicio` | string | SVNTV | **no** | máx 20 |
| `totalAllowedAmount` | number |  | — |  |
| `totalAllowedAmountCurrency` | string |  | — | máx 3 |
| `totalClaimedAmount` | number |  | — |  |
| `totalClaimedAmountCurrency` | string |  | — | máx 3 |
| `totalCoveredAmount` | number |  | — |  |
| `totalCoveredAmountCurrency` | string |  | — | máx 3 |
| `totalRetentionAmount` | number |  | — |  |
| `totalRetentionAmountCurrency` | string |  | — | máx 3 |
| `totalValorGlosado` | number | SVNTV | **no** |  |
| `totalValorNotasCredito` | number | SVNTV | **no** |  |
| `transactionDateTime` | → `timestampobject` |  | — |  |
| `transactionSourceCode` | string |  | — | máx 30 |
| `type` | string |  | — | máx 1 |
| `usuarioCreacion` | string | SVNTV | **no** | máx 10 |
| `usuarioDesfinaliza` | string | SVNTV | **no** | máx 10 |
| `usuarioModificacion` | string | SVNTV | **no** | máx 10 |
| `valorFactura` | number | SVNTV | **no** |  |
| `valorIva` | number | SVNTV | **no** |  |
| `valorNotaCredito` | number | SVNTV | **no** |  |
| `valorTotalFactura` | number | SVNTV | **no** |  |
| `version` | integer |  | — | obligatorio, int64 |

## `ctrclaimlines` — la foto de la línea al finalizar

170 campos.

| Campo | Tipo | Dinámico | Filtrable | Notas |
|---|---|---|---|---|
| `DescripcionLateralidad` | string | SVNTV | **no** | máx 10 |
| `allowedAmount` | number |  | — |  |
| `allowedAmountCurrency` | string |  | — | máx 3 |
| `allowedNumberOfUnits` | number |  | — |  |
| `amount` | number | SVNTV | **no** |  |
| `archivoRIPSDescrPrestacion` | string | SVNTV | **no** | máx 100 |
| `authorizationCode` | string |  | — | máx 30 |
| `authorizationExceptionType` | string |  | — | máx 30 |
| `authorizationRegimeCode` | string |  | — | máx 30 |
| `benefitsAgeInputDate` | string |  | — | date |
| `benefitsInputAmount` | number |  | — |  |
| `benefitsInputAmountCurrency` | string |  | — | máx 3 |
| `benefitsInputDate` | string |  | — | date |
| `benefitsProvCode` | string |  | — | máx 30 |
| `benefitsProvCodeDef` | string |  | — | máx 30 |
| `benefitsProvName` | string |  | — | máx 200 |
| `claimDate` | string |  | — | date |
| `claimedAmount` | number |  | — |  |
| `claimedAmountCurrency` | string |  | — | máx 3 |
| `claimedNumberOfUnits` | number |  | — |  |
| `classificationAuthorizationCode` | string |  | — | máx 30 |
| `classificationCode` | string |  | — | máx 30 |
| `code` | string |  | — | obligatorio, máx 30 |
| `codeTariffISS2000` | string | SVNTV | **no** | máx 30 |
| `codeTariffISS2001` | string | SVNTV | **no** | máx 30 |
| `codeTariffSOAT` | string | SVNTV | **no** | máx 30 |
| `codigoContraste` | string | SVNTV | **no** | máx 2 |
| `codigoFraq` | string | SVNTV | **no** | máx 2 |
| `codigoGlosa` | string | SVNTV | **no** | máx 30 |
| `codigoLateralidad` | string | SVNTV | **no** | máx 1 |
| `codigoNotaCredito` | string | SVNTV | **no** | máx 30 |
| `codigoOipa` | string | SVNTV | **no** | máx 10 |
| `codigoSalud` | string | SVNTV | **no** | máx 10 |
| `codigoSiniestro` | string | SVNTV | **no** | máx 20 |
| `codigoTipoSala` | string | SVNTV | **no** | máx 2 |
| `codigoUnicoContratoSIIFA` | string | SVNTV | **no** | máx 300 |
| `codigoViaAcceso` | string | SVNTV | **no** | máx 2 |
| `consumptionDate` | string |  | — | date |
| `coverageRegimeCode` | string |  | — | máx 30 |
| `coverageRegimeNoAuthCode` | string |  | — | máx 30 |
| `coverageSpecificationCode` | string |  | — | máx 30 |
| `coveredAmount` | number |  | — |  |
| `coveredAmountCurrency` | string |  | — | máx 3 |
| `coveredNumberOfUnits` | number |  | — |  |
| `createdBy` | string |  | — | solo lectura |
| `createdByUserName` | string |  | **no** | solo lectura |
| `creationDate` | → `timestampobject` |  | — |  |
| `ctrBill` | → `ctrbills` |  | — |  |
| `ctrClaim` | → `ctrclaims` |  | — | obligatorio |
| `ctrClaimLineAppliedParameterList` | lista de `ctrclaimlineappliedparameters` |  | — |  |
| `ctrClaimLineBenefitSpecificationList` | lista de `ctrclaimlinebenefitspecifications` |  | — |  |
| `ctrClaimLineContractReferenceList` | lista de `ctrclaimlinecontractreferences` |  | — |  |
| `ctrClaimLineCoverageList` | lista de `ctrclaimlinecoverages` |  | — |  |
| `ctrClaimLineDiagnosisList` | lista de `ctrclaimlinediagnoses` |  | — |  |
| `ctrClaimLineMessageList` | lista de `ctrclaimlinemessages` |  | — |  |
| `ctrClaimLineModifierList` | lista de `ctrclaimlinemodifiers` |  | — |  |
| `ctrClaimLineProviderPricingClauseList` | lista de `ctrclaimlineproviderpricingclauses` |  | — |  |
| `ctrClaimSubLineList` | lista de `ctrclaimsublines` |  | — |  |
| `datosAdicionalesSiniestro` | objeto | DYNR | — |  |
| `descripcion` | string | SVNTV | **no** | máx 100 |
| `descripcionContraste` | string | SVNTV | **no** | máx 30 |
| `descripcionFraq` | string | SVNTV | **no** | máx 100 |
| `descripcionTipoSala` | string | SVNTV | **no** | máx 100 |
| `descripcionViaAcceso` | string | SVNTV | **no** | máx 50 |
| `detallesGlosa` | lista embebida | DYNR | — |  |
| `diasDurante` | number | SVNTV | **no** |  |
| `emergencyIndicator` | string |  | — | máx 1 |
| `encounterIndicator` | string |  | — | máx 1 |
| `endDate` | string |  | — | date |
| `episodeIdentifier` | string |  | — | máx 30 |
| `especialidad` | string | SVNTV | **no** | máx 30 |
| `familyCode` | string |  | — | máx 30 |
| `fechaEgreso` | string | SVNTV | **no** | date |
| `fechaIngreso` | string | SVNTV | **no** | date |
| `fechaOrdenMedica` | string | SVNTV | **no** | date |
| `fundingArrangementCode` | string |  | — | máx 30 |
| `homologoCups` | string | SVNTV | **no** | máx 30 |
| `horaEgreso` | string | SVNTV | **no** | máx 5 |
| `horaFin` | string | SVNTV | **no** | máx 5 |
| `horaIngreso` | string | SVNTV | **no** | máx 5 |
| `horaInicio` | string | SVNTV | **no** | máx 5 |
| `id` | string |  | — | solo lectura |
| `lastUpdatedBy` | string |  | — | solo lectura |
| `lastUpdatedByUserName` | string |  | **no** | solo lectura |
| `lastUpdatedDate` | → `timestampobject` |  | — |  |
| `lineGroupingCriteria` | string |  | — | máx 200 |
| `locationProvCode` | string |  | — | máx 30 |
| `locationProvCodeDef` | string |  | — | máx 30 |
| `locationProvName` | string |  | — | máx 200 |
| `locationTypeCode` | string |  | — | máx 30 |
| `locationTypeDescription` | string |  | — | máx 200 |
| `montoIVACalculado` | number | SVNTV | **no** |  |
| `multiplesCupsHomologos` | string | SVNTV | **no** | máx 1 |
| `numeroSecuencia` | string | SVNTV | **no** | máx 2 |
| `objectVersionNumber` | integer |  | — | no insertable, int64 |
| `observacionesGlosa` | string | SVNTV | **no** | máx 1000 |
| `ocp` | string | SVNTV | **no** | máx 2 |
| `op` | string |  | — | no insertable |
| `payReceiverName` | string |  | — | máx 200 |
| `payReceiverProvCode` | string |  | — | máx 30 |
| `payReceiverProvCodeDef` | string |  | — | máx 30 |
| `payReceiverRelCode` | string |  | — | máx 30 |
| `porcentajeIVA` | number | SVNTV | **no** |  |
| `postBenefitsRegimeCode` | string |  | — | máx 30 |
| `precedingPayerPaidAmount` | number |  | — |  |
| `precedingPayerPaidAmountCurrency` | string |  | — | máx 3 |
| `prestacionCodigoNoDefinido` | string | SVNTV | **no** | máx 30 |
| `prestacionCodigoNoDefinidoDef` | string | SVNTV | **no** | máx 30 |
| `prestacionPadre` | string | SVNTV | **no** | máx 30 |
| `priceIndProvCode` | string |  | — | máx 30 |
| `priceIndProvCodeDef` | string |  | — | máx 30 |
| `priceIndProvName` | string |  | — | máx 200 |
| `priceInputDate` | string |  | — | date |
| `priceInputNumberOfUnits` | number |  | — |  |
| `priceOrgProvCode` | string |  | — | máx 30 |
| `priceOrgProvCodeDef` | string |  | — | máx 30 |
| `priceOrgProvName` | string |  | — | máx 100 |
| `pricePrincipalProc1Ind` | string |  | — | máx 1 |
| `pricePrincipalProc2Ind` | string |  | — | máx 1 |
| `pricePrincipalProc3Ind` | string |  | — | máx 1 |
| `procedure2AccessCode` | string |  | — | máx 100 |
| `procedure2Code` | string |  | — | máx 30 |
| `procedure2CodeDef` | string |  | — | máx 30 |
| `procedure2Description` | string |  | — | máx 99 |
| `procedure3AccessCode` | string |  | — | máx 100 |
| `procedure3Code` | string |  | — | máx 30 |
| `procedure3CodeDef` | string |  | — | máx 30 |
| `procedure3Description` | string |  | — | máx 99 |
| `procedureAccessCode` | string |  | — | máx 100 |
| `procedureCode` | string |  | — | máx 30 |
| `procedureCodeDef` | string |  | — | máx 30 |
| `procedureDescription` | string |  | — | máx 99 |
| `processAsIn` | string |  | — | máx 1 |
| `productCode` | string |  | — | máx 30 |
| `productFamilyCode` | string |  | — | máx 30 |
| `productLineCode` | string |  | — | máx 30 |
| `providerEntityReference` | string |  | — | máx 60 |
| `providerReference` | string |  | — | máx 250 |
| `referenceCode` | string |  | — | máx 30 |
| `referralProvCode` | string |  | — | máx 30 |
| `referralProvCodeDef` | string |  | — | máx 30 |
| `referralProvName` | string |  | — | máx 200 |
| `replacedByCode` | string |  | — | máx 30 |
| `replacedIndicator` | string |  | — | máx 1 |
| `replacesCode` | string |  | — | máx 30 |
| `reservationCode` | string |  | — | máx 30 |
| `reservationLineCode` | string |  | — | máx 30 |
| `retentionAmount` | number |  | — |  |
| `retentionAmountCurrency` | string |  | — | máx 3 |
| `sequence` | integer |  | — | int64 |
| `serviceProvCode` | string |  | — | máx 30 |
| `serviceProvCodeDef` | string |  | — | máx 30 |
| `serviceProvName` | string |  | — | máx 200 |
| `serviceSpecialtyCode` | string |  | — | máx 30 |
| `servicedEntityAccessCode` | string |  | — | máx 100 |
| `servicedEntityCode` | string |  | — | máx 30 |
| `servicedEntityContactAccessCode` | string |  | — | máx 100 |
| `servicedEntityDate` | string |  | — | máx 10 |
| `servicedEntityDateInterpretation` | string |  | — | máx 1 |
| `servicedEntityName` | string |  | — | máx 200 |
| `servicedEntityType` | string |  | — | máx 30 |
| `startDate` | string |  | — | date |
| `status` | string |  | — | máx 30 |
| `subscriptionDate` | string |  | — | date |
| `transactionSourceCode` | string |  | — | máx 30 |
| `valorGlosa` | number | SVNTV | **no** |  |
| `valorGlosado` | number | SVNTV | **no** |  |
| `valorNotaCredito` | number | SVNTV | **no** |  |
| `waitingPeriodInputDate` | string |  | — | date |
| `waitingPeriodRegimeCode` | string |  | — | máx 30 |
