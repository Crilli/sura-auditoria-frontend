# 07 — El diseño de la ACL contra OHI

Los seis documentos anteriores describen OHI. Este describe **cómo se defiende
este microservicio de OHI**: la frontera, las clases que la forman y por dónde
pasa una petición de punta a punta.

Importa porque el modelo de OHI no es el modelo del negocio. OHI habla de
*claims* con 186 campos, estados en inglés con espacios, montos como objetos,
indicadores que a veces son `"Y"` y a veces `true`, y 43 campos dinámicos
mezclados con los del producto. El dominio de la auditoría habla de cuentas
médicas con nueve atributos. La capa anticorrupción es lo que hay en medio.

## La forma del proyecto

```mermaid
flowchart TB
    subgraph PE["infraestructura-web-reactiva — puntos de entrada"]
        ENR["EnrutadorRest"] --> MAN["ManejadorCuentas<br/>ManejadorLineas<br/>ManejadorPendientes"]
        MAN --> MAP["MapeadorCuenta<br/>MapeadorLinea"]
    end

    subgraph CU["dominio-casos-de-uso"]
        direction LR
        U1["ConsultarCuentaCasoDeUso"]
        U2["ListarLineasCasoDeUso"]
        U3["GuardarLineaCasoDeUso"]
        U4["ResolverPendientesCasoDeUso"]
        U5["EnviarCuentaCasoDeUso"]
        U6["SeguirProcesoCasoDeUso"]
        U7["ConsultarAccionesCasoDeUso"]
        U8["ConsultarDetalleLineaCasoDeUso"]
    end

    subgraph MO["dominio-modelo — puertos e idioma del negocio"]
        direction LR
        P1(["PuertoConsultaCuentas"])
        P2(["PuertoComandosCuenta"])
        P3(["PuertoPendientes"])
        P4(["PuertoNotas"])
        P5(["PublicadorEventosAuditoria"])
        P6(["RepositorioTrazaAuditoria"])
    end

    subgraph AD["adaptadores — dos implementaciones de los mismos puertos"]
        direction LR
        subgraph OHIAD["acl-ohi — perfiles dev, lab, prod"]
            AO["AdaptadorConsultasOhi<br/>AdaptadorComandosOhi<br/>AdaptadorPendientesOhi<br/>AdaptadorNotasOhi"]
            DIC["DiccionarioOhi<br/><i>unico sitio con vocabulario de OHI</i>"]
            TR["Traductor*<br/>Cuenta, Linea, Acciones,<br/>Novedad, Pendiente, Errores"]
            AO --- TR --- DIC
        end
        subgraph SIM["simulador-local — perfil local"]
            AS["AdaptadorConsultasSimulado<br/>AdaptadorComandosSimulado<br/>AdaptadorPendientesSimulado<br/>AdaptadorNotasSimulado"]
        end
        OTR["AdaptadorTrazaAuditoria (r2dbc)<br/>AdaptadorPublicadorEventos (bus)"]
    end

    OHI[("OHI Claims")]

    PE --> CU
    CU --> MO
    AD -.->|implementan| MO
    AO --> OHI

    classDef puerto fill:#e3f2fd,stroke:#1565c0
    classDef ohi fill:#fff3e0,stroke:#e65100
    class P1,P2,P3,P4,P5,P6 puerto
    class OHI,DIC ohi
```

Cuatro cosas que se leen ahí y son el diseño entero:

1. **El dominio no conoce OHI.** `dominio-modelo` y `dominio-casos-de-uso` no
   tienen ni una dependencia hacia `acl-ohi`; la flecha va al revés. Los casos
   de uso hablan con interfaces que el propio dominio declara.
2. **Los puertos tienen dos implementaciones.** Los adaptadores de OHI están
   anotados `@Profile("!local")` y el módulo `simulador-local` ocupa su sitio en
   el perfil `local`. El perfil `local` arranca sin OHI, sin MySQL y sin
   RabbitMQ, y eso es lo que permite desarrollar y demostrar sin VPN.
3. **`DiccionarioOhi` es la única frontera del vocabulario.** Es la única clase
   autorizada a contener literales de OHI.
4. **Los traductores son clases aparte**, una por concepto
   (`TraductorCuenta`, `TraductorLinea`, `TraductorAcciones`, `TraductorNovedad`,
   `TraductorPendiente`, `TraductorEstadoProceso`, `TraductorErrores`). Traducir
   no está repartido por los adaptadores.

## El modelo de dominio

Lo que el negocio ve. Nueve atributos en la cuenta frente a los 186 de OHI; el
resto o no se usa, o se agrupa en `InformacionFacturacion`, o es ruido del
producto.

```mermaid
classDiagram
    direction LR

    class CuentaMedica {
        <<record>>
        CodigoCuenta codigo
        EstadoCuenta estado
        LocalDate fechaInicio
        LocalDate fechaFin
        BigDecimal totalAutorizado
        BigDecimal totalCubierto
        Version version
    }
    class LineaCuenta {
        <<record>>
        ReferenciaLinea referencia
        int numeroLinea
        String codigoAfiliado
        String codigoProcedimiento
        BigDecimal valorAutorizado
        BigDecimal valorCubierto
        boolean bloqueada
        boolean reemplazada
        Version version
    }
    class ResumenLinea {
        <<record>>
        int cantidadPendientes
        boolean tieneNovedadBloqueante
    }
    class Novedad {
        <<record>>
        long identificador
        String codigo
        String descripcion
        String origen
    }
    class MotivoPendiente {
        <<record>>
        long identificador
        String codigo
        boolean resuelto
        boolean soloAdjudicacion
    }
    class InformacionFacturacion {
        <<record>>
        String numeroFactura
        String numeroRadicado
        BigDecimal valorFactura
        BigDecimal totalValorGlosado
    }
    class AccionesDisponibles {
        <<record>>
        Set~AccionCuenta~ acciones
    }
    class EstadoProceso {
        <<record>>
        boolean finalizado
        List~String~ errores
    }
    class CodigoCuenta {
        <<value object>>
    }
    class Version {
        <<value object>>
    }
    class ReferenciaLinea {
        <<value object>>
    }
    class EstadoCuenta {
        <<enumeration>>
        INICIAL
        DIGITACION
        MODIFICACION
        ADJUDICACION_MANUAL
        FINALIZADA
        DESCONOCIDO
    }
    class Severidad {
        <<enumeration>>
        INFORMATIVA
        ADVERTENCIA
        BLOQUEANTE
        DESCONOCIDA
    }
    class AccionCuenta {
        <<enumeration>>
        ENVIAR
        RESOLVER_PENDIENTE
        DEVOLVER_A_MODIFICACION
        REVERTIR_FINALIZACION
        ANULAR
    }
    class NivelPendiente {
        <<enumeration>>
    }

    CuentaMedica "1" *-- "0..*" MotivoPendiente : pendientesCabecera
    CuentaMedica "1" *-- "0..1" InformacionFacturacion
    CuentaMedica --> CodigoCuenta
    CuentaMedica --> EstadoCuenta
    CuentaMedica --> Version
    LineaCuenta "1" *-- "0..*" Novedad
    LineaCuenta "1" *-- "0..*" MotivoPendiente
    LineaCuenta --> ReferenciaLinea
    LineaCuenta --> Version
    ResumenLinea --> ReferenciaLinea
    Novedad --> Severidad
    MotivoPendiente --> NivelPendiente
    AccionesDisponibles --> AccionCuenta
```

Todo son `record` de Java 21 e inmutables. `CodigoCuenta`, `Version` y
`ReferenciaLinea` son objetos de valor y no `String` ni `long` sueltos: es lo
que evita pasar un código donde iba una versión, que con dos `String` compila.

`ResumenLinea` existe aparte de `LineaCuenta` a propósito. El listado de líneas
—que puede traer miles— no necesita las novedades ni los pendientes de cada
una, solo `cantidadPendientes` y `tieneNovedadBloqueante`. Un `LineaCuenta`
completo se pide solo al abrir el detalle. Sin esa separación la paginación
traería la cuenta entera.

`EstadoCuenta` tiene un valor `DESCONOCIDO` y `Severidad` tiene `DESCONOCIDA`.
No son adorno: OHI puede devolver un estado que el diccionario no mapea —hay
estados válidos del producto que hoy no tienen filas en prod— y el dominio
prefiere un valor explícito a una excepción en tiempo de ejecución.

## Los puertos y sus dos implementaciones

```mermaid
classDiagram
    direction TB

    class PuertoConsultaCuentas {
        <<interface>>
        +buscarPorCodigo(CodigoCuenta) Mono~CuentaMedica~
        +consultarAccionesDisponibles(CodigoCuenta) Mono~AccionesDisponibles~
        +listarResumenLineas(CodigoCuenta, Cursor, ...) Mono~Pagina~
        +buscarDetalleLinea(CodigoCuenta, ReferenciaLinea) Mono~LineaCuenta~
        +recorrerTodasLasLineas(CodigoCuenta, int) Flux~ResumenLinea~
        +consultarEstadoProceso(CodigoCuenta) Mono~EstadoProceso~
    }
    class PuertoComandosCuenta {
        <<interface>>
        +aplicarEdicionesDeLinea(CodigoCuenta, Version, List) Mono~LineaCuenta~
        +enviar(CodigoCuenta, Version, DecisionEnvio) Mono~TiqueteProceso~
    }
    class PuertoPendientes {
        <<interface>>
        +listarSinResolver(CodigoCuenta) Flux~MotivoPendiente~
        +resolverEnCuentaYLineas(CodigoCuenta, long) Mono~Void~
        +resolverSoloEnLineas(CodigoCuenta, long) Mono~Void~
        +resolverPendienteCabecera(long) Mono~Void~
        +resolverPendienteLinea(long) Mono~Void~
    }
    class PuertoNotas {
        <<interface>>
        +agregarNota(CodigoCuenta, String, String) Mono~Void~
    }

    class AdaptadorConsultasOhi
    class AdaptadorComandosOhi
    class AdaptadorPendientesOhi
    class AdaptadorNotasOhi
    class AdaptadorConsultasSimulado
    class AdaptadorComandosSimulado
    class AdaptadorPendientesSimulado
    class AdaptadorNotasSimulado

    PuertoConsultaCuentas <|.. AdaptadorConsultasOhi : dev lab prod
    PuertoConsultaCuentas <|.. AdaptadorConsultasSimulado : local
    PuertoComandosCuenta <|.. AdaptadorComandosOhi
    PuertoComandosCuenta <|.. AdaptadorComandosSimulado
    PuertoPendientes <|.. AdaptadorPendientesOhi
    PuertoPendientes <|.. AdaptadorPendientesSimulado
    PuertoNotas <|.. AdaptadorNotasOhi
    PuertoNotas <|.. AdaptadorNotasSimulado

    note for AdaptadorConsultasOhi "implementa ademas\nResolutorIdentidadOhi.BuscadorPorCodigo"
```

El reparto de puertos por caso de uso dice quién necesita qué:

| Caso de uso | Puertos que recibe |
|---|---|
| `ConsultarCuentaCasoDeUso` | consulta |
| `ConsultarAccionesCasoDeUso` | consulta |
| `ConsultarDetalleLineaCasoDeUso` | consulta |
| `ListarLineasCasoDeUso` | consulta |
| `SeguirProcesoCasoDeUso` | consulta |
| `GuardarLineaCasoDeUso` | consulta + comandos + eventos |
| `EnviarCuentaCasoDeUso` | consulta + comandos + pendientes + eventos |
| `ResolverPendientesCasoDeUso` | consulta + pendientes + notas + eventos |

Los tres que escriben son también los tres que publican evento de auditoría.
Ninguno lo hace sin haber consultado antes: `EnviarCuentaCasoDeUso` y
`ResolverPendientesCasoDeUso` piden `consultarAccionesDisponibles` como **guarda
de autorización** —si OHI no publicó el enlace `claim:submit`, la operación no
se intenta— y lo piden con `Mono.zip` junto a la cabecera para no pagar dos
viajes.

## La traducción, concepto por concepto

```mermaid
flowchart LR
    subgraph OHIV["vocabulario de OHI (ingles)"]
        direction TB
        O1["status: FINALIZED<br/>MANUAL ADJUDICATION"]
        O2["rel: claim:submit<br/>claim:resolvepend"]
        O3["severity: FATAL<br/>WARNING / INFO"]
        O4["avance: notStarted<br/>processing / succeeded / failed"]
        O5["indicador: Y / N<br/>o booleano JSON"]
    end

    DIC{{"DiccionarioOhi<br/>la unica frontera"}}

    subgraph DOM["idioma del dominio (espanol)"]
        direction TB
        D1["EstadoCuenta.FINALIZADA<br/>ADJUDICACION_MANUAL"]
        D2["AccionCuenta.ENVIAR<br/>RESOLVER_PENDIENTE"]
        D3["Severidad.BLOQUEANTE<br/>ADVERTENCIA / INFORMATIVA"]
        D4["EstadoProceso.Avance.NO_INICIADO<br/>EN_PROCESO / EXITOSO / FALLIDO"]
        D5["boolean"]
    end

    O1 --> DIC --> D1
    O2 --> DIC --> D2
    O3 --> DIC --> D3
    O4 --> DIC --> D4
    O5 --> DIC --> D5

    DOM -.->|"desdeDecision, desdeIndicador,<br/>desdeModoRecalculo"| OHIV

    classDef ohi fill:#fff3e0,stroke:#e65100
    classDef dom fill:#e8f5e9,stroke:#2e7d32
    class O1,O2,O3,O4,O5 ohi
    class D1,D2,D3,D4,D5 dom
```

La traducción no es simétrica, y eso es deliberado: entran cinco vocabularios y
salen tres conversiones (`desdeDecision`, `desdeIndicador`,
`desdeModoRecalculo`). El dominio no necesita poder expresar todo lo que OHI
acepta.

Dos detalles del diccionario que vienen de cosas documentadas en [02](02-api-y-lenguaje-de-consulta.md):

- **`aIndicador` está sobrecargado** para `String` y para `Boolean`, porque OHI
  usa las dos convenciones según la entidad: `"Y"`/`"N"` en `ctrclaims` y
  booleanos JSON en `claims`. No es redundancia
  ([02 § 12](02-api-y-lenguaje-de-consulta.md#12-un-booleano-filtrado-con-y-da-el-resultado-contrario)).
- **`aEstado` normaliza con `trim().toUpperCase()`** antes de buscar en el mapa,
  y el mapa tiene las claves con espacio (`"MANUAL ADJUDICATION"`), que es la
  forma en que OHI devuelve el estado en la representación del recurso. Las
  etiquetas sin espacio que se ven en un `groupBy` **no** son lo que llega aquí
  ([02 § 2](02-api-y-lenguaje-de-consulta.md#2-groupby-devuelve-etiquetas-q-filtra-por-códigos)).

El diccionario cubre 15 estados, 11 acciones, 3 severidades y 4 avances de
proceso. Los estados del producto que hoy no tienen filas en prod
(`MANUAL BENEFITS`, `PRICING FINALIZED`, `SENT OUT FOR PRICING`,
`MANUAL PRICING ADJUDICATION`, `PRICING ADJUDICATION DONE`) **están mapeados**:
si mañana aparecen, no caen en `DESCONOCIDO`.

## Una petición de punta a punta

```mermaid
sequenceDiagram
    autonumber
    actor A as Auditor
    participant F as sura-auditoria-frontend
    participant E as EnrutadorRest
    participant U as ResolverPendientesCasoDeUso
    participant PC as PuertoConsultaCuentas
    participant PP as PuertoPendientes
    participant AD as AdaptadorPendientesOhi
    participant TK as ProveedorTokenOhi
    participant O as OHI
    participant EV as PublicadorEventosAuditoria

    A->>F: resuelve un pendiente
    F->>E: POST /cuentas/{codigo}/pendientes/{id}
    E->>U: ejecutar(codigo, id, decision)
    U->>PC: consultarAccionesDisponibles(codigo)
    PC-->>U: RESOLVER_PENDIENTE presente (guarda de autorizacion)
    U->>PP: resolverEnCuentaYLineas(codigo, id)
    PP->>AD: delega
    AD->>TK: obtenerToken() (cache 50 min)
    TK-->>AD: Bearer
    AD->>O: POST /claims/{id}/resolvepend/{pendId}?action=accept
    Note over AD,O: timeout 25 s, no 5 s.<br/>OHI readjudica y termina aunque<br/>el cliente ya haya cortado.
    O-->>AD: 200
    AD-->>U: Mono~Void~
    U->>EV: publicar(EventoAuditoria)
    U-->>E: ok
    E-->>F: 204
```

Los dos momentos que no son obvios:

- **El token se cachea 50 minutos** aunque viva 60
  (`integraciones.ohi.cache-token.expiracion`), para no usar uno a punto de
  vencer. Lo resuelve `ProveedorTokenOhi` con `@Cacheable`.
- **Resolver un pendiente tiene su propio tiempo de espera**, 25 s frente a los
  5 s del resto (`integraciones.ohi.timeouts.resolucion-pendiente`), porque
  dispara readjudicación. Está verificado en producción que **la operación
  termina en OHI aunque el cliente ya haya cortado**. Si el cliente reintenta al
  ver el timeout, readjudica dos veces.

## Resiliencia y límites

| Ajuste | Valor | Por qué |
|---|---|---|
| `maximo-respuesta` | **8 MB** | el tope de WebFlux (256 KB) se queda corto: OHI devuelve la cuenta con todas sus líneas y una de 1.500 líneas pesa ~280 KB. 8 MB cubre ~40.000 |
| timeouts | conexión 2 s, lectura 5 s, escritura 5 s | y 25 s para resolver pendiente |
| cortacircuitos `ohiConsultas` | ventana 10, 50% de fallo, 10 s abierto | |
| cortacircuitos `ohiComandos` | ventana 20 | más tolerante: escribir es menos frecuente |
| cortacircuitos `ohiEnvio` | ventana 5, 30 s abierto | el envío cuesta más, el backoff es más largo |
| reintento `ohiConsultas` | 3 intentos, 500 ms | solo en consultas; **nunca en comandos** |

No hay reintento configurado para comandos, y es correcto: reenviar un `submit`
o un `resolvepend` no es idempotente del lado de OHI.

## Lo que el diseño promete y no está garantizado

Dos huecos reales, por si alguien los da por hechos:

**No hay ninguna prueba en el proyecto.** `find . -path '*/src/test/*' -name
'*.java'` devuelve cero ficheros. El javadoc de `DiccionarioOhi` dice que la
invariante «cualquier término de OHI fuera de este paquete es un defecto de
arquitectura» queda *«detectado por la prueba `PruebaArquitecturaTest`»* — y esa
clase **no existe**. `build.gradle` ya declara `archunitVersion = '1.3.0'`, así
que la dependencia está prevista y la prueba no se escribió.

Comprobado a mano el 7 de octubre de 2026: **la invariante hoy se cumple.** No
hay literales de estado, de `rel` ni de severidad de OHI en `dominio/`,
`puntos-de-entrada/`, `aplicacion/` ni en el simulador. La frontera es real; lo
que falta es el guardia que impida que se rompa en el próximo cambio. Escribirla
es media hora y es la prueba de mayor valor por línea que admite este
repositorio.

**El simulador y la ACL pueden divergir sin que nada avise.** Son dos
implementaciones de los mismos puertos y nada comprueba que se comporten igual.
Una batería de pruebas de contrato sobre la interfaz, ejecutada contra las dos,
es lo que convertiría el perfil `local` en una garantía y no solo en una
comodidad.
