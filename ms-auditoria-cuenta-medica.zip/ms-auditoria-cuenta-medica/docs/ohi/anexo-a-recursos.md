# Anexo A — Inventario de recursos genéricos de OHI prod

Las 453 colecciones que publica `GET /generic` en
`https://prod.sura.ohi.ocs.oraclecloud.com/prod/claims/api`, con la forma de
cada entidad. Generado leyendo `/generic/<recurso>/definition` de cada una, no
escrito a mano.

- **Campos**: propiedades de la entidad raíz, incluidos los dinámicos.
- **Refs**: referencias a una sola entidad (claves foráneas).
- **Colecciones**: listas de entidades hijas.
- **Escritura**: qué formularios publica el catálogo (`create-form` / `edit-form`).
  «solo lectura» significa que OHI no ofrece alta ni modificación por el API genérico.
- **Dinámicos**: cuántos de esos campos son extensiones configuradas (ver
  [04-extensiones-sura.md](04-extensiones-sura.md)).
- **Referido por**: cuántos otros recursos apuntan a este. Es la medida de qué
  tan al centro del modelo está.

| Recurso | Campos | Refs | Colecciones | Escritura | Dinámicos | Referido por |
|---|---:|---:|---:|---|---:|---:|
| `accessrestrictiongrants` | 25 | 6 | 0 | solo lectura |  |  |
| `accessrestrictions` | 24 | 4 | 0 | crear + editar |  | 51 |
| `accessroles` | 26 | 4 | 2 | crear + editar |  | 2 |
| `accountingdetailgroupings` | 12 | 4 | 0 | solo lectura |  |  |
| `accountingdetails` | 92 | 4 | 0 | solo lectura |  |  |
| `activities` | 62 | 8 | 1 | solo lectura | 31 |  |
| `activitymessages` | 19 | 3 | 0 | solo lectura |  |  |
| `activitytypes` | 27 | 5 | 1 | solo lectura |  | 7 |
| `addresses` | 26 | 7 | 0 | crear + editar |  |  |
| `addresstypes` | 21 | 4 | 0 | crear + editar |  | 1 |
| `adjudicationcasedetails` | 21 | 6 | 0 | solo lectura |  |  |
| `adjudicationcases` | 17 | 4 | 2 | solo editar |  | 2 |
| `adjustmentexecutionphases` | 21 | 4 | 0 | crear + editar |  | 4 |
| `adjustmentrulepercentages` | 23 | 4 | 0 | crear + editar |  |  |
| `adjustmentrules` | 88 | 31 | 4 | crear + editar |  |  |
| `adviceresponsedefinitions` | 23 | 5 | 0 | crear + editar |  |  |
| `ancillaryinclusionrules` | 29 | 10 | 0 | solo lectura |  |  |
| `assignedproviders` | 14 | 5 | 0 | crear + editar |  |  |
| `asynchronousmessages` | 21 | 4 | 1 | solo lectura |  |  |
| `audittraildetails` | 9 | 3 | 0 | solo lectura |  |  |
| `audittrails` | 5 | 2 | 0 | solo lectura |  | 1 |
| `authorizationbaskets` | 13 | 4 | 0 | crear + editar |  | 1 |
| `authorizationconsumptions` | 29 | 7 | 0 | solo lectura |  |  |
| `authorizationcounterperiods` | 15 | 3 | 0 | solo lectura |  |  |
| `authorizationcounters` | 14 | 6 | 0 | solo lectura |  | 2 |
| `authorizationdiagnoses` | 11 | 4 | 0 | crear + editar |  |  |
| `authorizationforms` | 21 | 5 | 0 | crear + editar |  | 1 |
| `authorizationlines` | 21 | 5 | 0 | crear + editar |  | 1 |
| `authorizationmessages` | 22 | 4 | 0 | crear + editar |  |  |
| `authorizationregimeperiods` | 23 | 5 | 1 | solo lectura |  | 1 |
| `authorizationregimeperiodtranches` | 24 | 5 | 0 | solo lectura |  | 1 |
| `authorizationregimes` | 42 | 19 | 1 | crear + editar |  | 4 |
| `authorizations` | 47 | 13 | 5 | crear + editar |  | 7 |
| `authorizationservicetypes` | 12 | 4 | 0 | crear + editar |  |  |
| `autopurgemetadata` | 17 | 2 | 0 | solo editar |  |  |
| `bankaccountnumbers` | 18 | 5 | 0 | crear + editar |  | 3 |
| `bankaccountvalidations` | 29 | 6 | 0 | solo lectura |  | 1 |
| `banks` | 36 | 7 | 6 | crear + editar |  | 1 |
| `basefinancialobjectactivities` | 33 | 9 | 1 | solo lectura |  |  |
| `basefinancialobjects` | 9 | 1 | 0 | solo lectura |  | 2 |
| `baseviewcolumns` | 7 | 0 | 0 | solo lectura |  |  |
| `baseviewerrors` | 10 | 0 | 0 | solo lectura |  |  |
| `baseviewgenerations` | 12 | 2 | 0 | solo lectura |  |  |
| `baseviews` | 8 | 1 | 2 | solo lectura |  |  |
| `basketdetails` | 28 | 6 | 0 | solo lectura |  | 1 |
| `baskets` | 22 | 5 | 1 | crear + editar |  | 2 |
| `batchmessages` | 23 | 4 | 1 | solo lectura |  |  |
| `benefitpriorities` | 21 | 4 | 0 | crear + editar |  | 1 |
| `benefitspecificationdynamiclogic` | 21 | 6 | 0 | solo lectura |  |  |
| `benefitspecificationlocationtypes` | 20 | 6 | 0 | solo lectura |  |  |
| `benefitspecificationmodifiers` | 20 | 6 | 0 | solo lectura |  |  |
| `benefitspecificationprovidergroups` | 21 | 6 | 0 | solo lectura |  |  |
| `benefitspecifications` | 69 | 25 | 5 | crear + editar |  | 9 |
| `benefitspecificationspecialties` | 20 | 6 | 0 | solo lectura |  |  |
| `billdiagnoses` | 16 | 5 | 0 | solo lectura |  |  |
| `billmessages` | 23 | 4 | 0 | solo lectura |  |  |
| `billpendreasons` | 12 | 4 | 0 | solo lectura |  |  |
| `bills` | 62 | 11 | 4 | solo lectura |  | 4 |
| `boilerplatetexts` | 23 | 5 | 0 | crear + editar |  |  |
| `bookmarks` | 13 | 3 | 0 | crear + editar |  |  |
| `brands` | 24 | 6 | 0 | crear + editar | 1 | 6 |
| `bundledamountcategories` | 20 | 6 | 0 | crear + editar |  |  |
| `bundledamounts` | 30 | 11 | 1 | crear + editar |  | 1 |
| `bundledamounttypes` | 21 | 4 | 0 | crear + editar |  | 1 |
| `calloutdefinitions` | 27 | 7 | 0 | crear + editar |  | 1 |
| `casedefinitions` | 40 | 14 | 1 | crear + editar |  | 5 |
| `chargedamountclassifications` | 20 | 6 | 0 | crear + editar |  |  |
| `chargedamountmodifiers` | 20 | 6 | 0 | crear + editar |  |  |
| `chargedamounts` | 43 | 13 | 2 | crear + editar |  | 2 |
| `chargedamounttypes` | 21 | 4 | 0 | crear + editar |  | 2 |
| `claimaccessrestrictionclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `claimaccessrestrictions` | 21 | 5 | 1 | crear + editar |  | 1 |
| `claimactivities` | 33 | 9 | 1 | solo lectura | 1 |  |
| `claimcallouthistory` | 15 | 5 | 0 | solo lectura |  |  |
| `claimcalloutrules` | 28 | 8 | 0 | crear + editar |  | 1 |
| `claimdiagnoses` | 16 | 5 | 0 | crear + editar |  |  |
| `claimeventhistory` | 15 | 3 | 1 | solo lectura |  | 1 |
| `claimeventruleclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `claimeventrules` | 42 | 12 | 1 | crear + editar |  | 1 |
| `claimforms` | 31 | 9 | 0 | crear + editar |  | 11 |
| `claimformtypes` | 20 | 4 | 0 | crear + editar |  | 3 |
| `claimlineappliedparameters` | 21 | 7 | 0 | solo lectura |  |  |
| `claimlinebenefitspecifications` | 29 | 13 | 0 | solo lectura |  |  |
| `claimlinecontractreferences` | 12 | 4 | 0 | crear + editar |  |  |
| `claimlinecoverages` | 16 | 5 | 0 | solo lectura |  |  |
| `claimlinediagnoses` | 16 | 5 | 0 | crear + editar |  |  |
| `claimlineeventhistory` | 11 | 3 | 0 | solo lectura |  |  |
| `claimlinelimits` | 18 | 6 | 0 | crear + editar |  |  |
| `claimlinemessages` | 29 | 8 | 0 | crear + editar |  |  |
| `claimlinemodifiers` | 12 | 4 | 0 | crear + editar |  |  |
| `claimlineoverrides` | 15 | 11 | 0 | solo lectura |  | 1 |
| `claimlineparameters` | 14 | 5 | 0 | crear + editar |  |  |
| `claimlinependreasons` | 12 | 4 | 0 | crear + editar |  |  |
| `claimlineproviderpricingclauses` | 15 | 5 | 0 | solo lectura |  |  |
| `claimlinereinsurancecoverages` | 16 | 5 | 0 | solo lectura |  |  |
| `claimlinereinsurancerulecoverages` | 17 | 6 | 0 | solo lectura |  |  |
| `claimlinerulecoverages` | 23 | 9 | 0 | solo editar |  |  |
| `claimlines` | 195 | 28 | 14 | crear + editar | 45 | 29 |
| `claimmessages` | 28 | 7 | 0 | crear + editar |  |  |
| `claimpendreasonhistory` | 15 | 6 | 0 | solo lectura |  |  |
| `claimpendreasons` | 12 | 4 | 0 | crear + editar |  |  |
| `claims` | 186 | 27 | 10 | crear + editar | 43 | 23 |
| `claimsets` | 16 | 3 | 0 | crear + editar |  | 1 |
| `claimsimportprocess` | 10 | 3 | 0 | solo lectura |  |  |
| `claimstatushistory` | 15 | 4 | 3 | solo lectura |  | 3 |
| `claimsublines` | 15 | 4 | 0 | crear + editar |  |  |
| `claimsubmithistory` | 12 | 5 | 0 | solo lectura |  |  |
| `claimtagactions` | 12 | 4 | 0 | crear + editar |  |  |
| `claimtransactioneventrules` | 34 | 10 | 0 | crear + editar |  |  |
| `claimunfinalizereasons` | 12 | 4 | 0 | solo lectura |  |  |
| `classificationpriorities` | 21 | 4 | 0 | crear + editar |  | 1 |
| `classifications` | 20 | 4 | 0 | crear + editar |  | 8 |
| `classificationschemeclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `classificationschemedetailmodifiers` | 20 | 6 | 0 | solo lectura |  |  |
| `classificationschemedetails` | 47 | 21 | 1 | solo lectura |  | 1 |
| `classificationschemes` | 29 | 7 | 2 | crear + editar |  | 5 |
| `combinationadjustmentrules` | 89 | 31 | 4 | crear + editar |  |  |
| `combinationcheckclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `combinationcheckprocedures` | 24 | 8 | 0 | solo lectura |  |  |
| `combinationchecks` | 40 | 10 | 2 | crear + editar | 2 | 2 |
| `configmigrationexcludeoptions` | 15 | 4 | 0 | solo lectura |  | 1 |
| `configmigrationitems` | 12 | 2 | 0 | crear + editar |  |  |
| `configmigrationsets` | 22 | 5 | 1 | crear + editar |  | 1 |
| `contractreferences` | 20 | 4 | 0 | crear + editar |  | 5 |
| `countries` | 39 | 5 | 2 | crear + editar | 4 | 5 |
| `countryregiongroupdetails` | 20 | 6 | 0 | solo lectura |  |  |
| `countryregiongroups` | 21 | 4 | 1 | crear + editar |  | 4 |
| `countryregions` | 27 | 5 | 0 | solo lectura | 5 | 6 |
| `counttowardslimits` | 24 | 6 | 0 | solo lectura |  |  |
| `coveragelabels` | 26 | 6 | 0 | crear + editar |  | 16 |
| `coverageregimeperiods` | 23 | 5 | 1 | solo lectura |  | 1 |
| `coverageregimeperiodtranches` | 27 | 5 | 1 | solo lectura |  | 2 |
| `coverageregimes` | 25 | 5 | 1 | crear + editar |  | 5 |
| `coveredservicetiers` | 21 | 4 | 0 | crear + editar |  | 1 |
| `coverwithholdcategories` | 21 | 6 | 0 | crear + editar |  | 8 |
| `coverwithholdrules` | 29 | 9 | 1 | solo lectura |  | 2 |
| `createaccountingdetailregistrations` | 26 | 3 | 0 | solo lectura |  |  |
| `ctrbilldiagnoses` | 17 | 3 | 0 | solo lectura |  |  |
| `ctrbillmessages` | 28 | 3 | 0 | solo lectura |  |  |
| `ctrbills` | 41 | 3 | 3 | solo lectura |  | 3 |
| `ctrcallouthistory` | 14 | 5 | 0 | solo lectura |  |  |
| `ctrclaimdiagnoses` | 17 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlineappliedparameters` | 23 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinebenefitspecifications` | 21 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinecontractreferences` | 12 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinecoverages` | 22 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinediagnoses` | 17 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinemessages` | 33 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinemodifiers` | 12 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlineproviderpricingclauses` | 18 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlinereinsurancecoverages` | 22 | 3 | 0 | solo lectura |  |  |
| `ctrclaimlines` | 170 | 4 | 9 | solo lectura | 46 | 11 |
| `ctrclaimlists` | 12 | 2 | 0 | solo lectura |  |  |
| `ctrclaimmessages` | 32 | 3 | 0 | solo lectura |  |  |
| `ctrclaimpolicyproducts` | 21 | 3 | 0 | solo lectura |  |  |
| `ctrclaims` | 161 | 4 | 8 | solo lectura | 55 | 9 |
| `ctrclaimsublines` | 15 | 3 | 0 | solo lectura |  |  |
| `ctrclaimunfinalizereasons` | 13 | 3 | 0 | solo lectura |  |  |
| `ctrpendreasonhistory` | 18 | 4 | 0 | solo lectura |  |  |
| `ctrstatushistory` | 14 | 4 | 2 | solo lectura |  | 2 |
| `ctrtransactionlabels` | 12 | 4 | 0 | solo lectura |  |  |
| `currencies` | 22 | 4 | 0 | crear + editar |  | 9 |
| `dataaccessgroups` | 21 | 5 | 0 | crear + editar |  | 2 |
| `datafiles` | 16 | 3 | 0 | crear + editar |  |  |
| `datafilesets` | 16 | 2 | 1 | crear + editar |  | 2 |
| `datamaskingdefinitions` | 13 | 2 | 0 | solo lectura |  |  |
| `datasetdefinitiondetailexcludeoptions` | 14 | 5 | 0 | solo lectura |  | 1 |
| `datasetdefinitiondetails` | 12 | 4 | 1 | solo lectura |  | 1 |
| `datasetdefinitions` | 18 | 2 | 1 | solo lectura |  | 4 |
| `datasetprocesses` | 20 | 6 | 0 | solo lectura |  | 2 |
| `datasets` | 17 | 5 | 0 | crear + editar |  | 1 |
| `datatransferlogs` | 14 | 2 | 0 | solo lectura |  |  |
| `deploymentmetadata` | 8 | 1 | 0 | solo lectura |  |  |
| `derivationruleclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `derivationrules` | 33 | 5 | 1 | crear + editar | 5 | 1 |
| `diagnoses` | 33 | 6 | 1 | crear + editar | 6 | 7 |
| `diagnosisgroupdetails` | 28 | 9 | 0 | crear + editar |  |  |
| `diagnosisgroups` | 22 | 5 | 0 | crear + editar |  | 19 |
| `diagnosissettings` | 24 | 5 | 0 | solo lectura | 3 |  |
| `diagnosistypes` | 20 | 4 | 0 | crear + editar |  | 4 |
| `diminishingrateblockamounts` | 23 | 6 | 0 | solo lectura |  |  |
| `diminishingrateblocks` | 22 | 5 | 2 | crear + editar |  | 2 |
| `diminishingrateblocksizes` | 23 | 6 | 0 | solo lectura |  |  |
| `diminishingrates` | 26 | 8 | 1 | crear + editar |  | 1 |
| `diminishingratetypes` | 22 | 4 | 0 | crear + editar |  | 1 |
| `draftproviderpricingclausebatches` | 15 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclauseclaimclassifications` | 11 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclauseclaimlineclassifications` | 11 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclauseclassificationschemes` | 11 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclausedimrates` | 13 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclausedynlogic` | 11 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclauserestrictreimbursementmethods` | 12 | 3 | 0 | solo lectura |  |  |
| `draftproviderpricingclauses` | 83 | 8 | 6 | crear + editar | 7 | 6 |
| `draftproviderpricingclauseselections` | 11 | 3 | 1 | solo lectura |  | 1 |
| `dynamiccheckclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `dynamicchecks` | 33 | 7 | 1 | crear + editar | 3 | 1 |
| `dynamicfieldrules` | 55 | 16 | 3 | crear + editar |  |  |
| `dynamicfieldusages` | 39 | 10 | 0 | crear + editar |  | 1 |
| `dynamiclogic` | 26 | 7 | 0 | crear + editar |  | 187 |
| `dynamiclogicreferencesheets` | 20 | 6 | 0 | crear + editar |  |  |
| `eligibilitycalloutrules` | 25 | 6 | 0 | crear + editar |  | 1 |
| `eligibilitycheckmessages` | 21 | 4 | 0 | solo lectura |  |  |
| `eligibilitychecks` | 20 | 5 | 1 | solo lectura |  | 1 |
| `eligibilityprocesssteps` | 22 | 5 | 1 | solo lectura |  | 1 |
| `eligibilityresponsedefinitions` | 24 | 5 | 1 | crear + editar |  | 2 |
| `eligibilityrulesteps` | 22 | 7 | 0 | solo lectura |  |  |
| `eligibilityvalidationrules` | 26 | 7 | 0 | crear + editar |  | 1 |
| `encounterrules` | 51 | 15 | 3 | crear + editar |  |  |
| `episodecategories` | 20 | 4 | 0 | crear + editar |  | 3 |
| `episodecriteria` | 34 | 12 | 0 | solo lectura |  |  |
| `episodedefinitions` | 38 | 13 | 1 | crear + editar |  | 3 |
| `episodedetails` | 14 | 5 | 0 | crear + editar |  | 1 |
| `episodes` | 19 | 4 | 1 | crear + editar |  | 1 |
| `exchangerates` | 24 | 6 | 0 | crear + editar |  |  |
| `externalclaimsdata` | 15 | 5 | 0 | crear + editar | 2 | 2 |
| `externalinterventionruleclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `externalinterventionrules` | 48 | 15 | 1 | crear + editar | 7 | 1 |
| `feeschedulelinebatches` | 13 | 3 | 0 | solo lectura |  |  |
| `feeschedulelineclassifications` | 20 | 6 | 0 | crear + editar |  |  |
| `feeschedulelinemodifiers` | 20 | 6 | 0 | crear + editar |  |  |
| `feeschedulelines` | 43 | 15 | 2 | crear + editar | 5 | 3 |
| `feeschedulemodifiers` | 20 | 6 | 0 | crear + editar |  |  |
| `feeschedules` | 30 | 10 | 1 | crear + editar |  | 3 |
| `feescheduletypes` | 22 | 4 | 0 | crear + editar |  | 1 |
| `fields` | 25 | 5 | 0 | crear + editar |  | 2 |
| `financialgroupingcombinations` | 7 | 0 | 0 | solo lectura |  | 1 |
| `financialholds` | 23 | 10 | 0 | crear + editar |  |  |
| `financialholdtypes` | 22 | 4 | 0 | crear + editar |  | 1 |
| `financialsubjectregistrations` | 5 | 3 | 0 | crear + editar |  |  |
| `financialtransactiondetailprocessdata` | 40 | 2 | 0 | solo editar | 17 | 2 |
| `financialtransactiondetails` | 15 | 2 | 0 | solo lectura |  | 1 |
| `financialtransactionprocessdata` | 52 | 5 | 0 | solo editar | 34 | 1 |
| `financialtransactions` | 13 | 3 | 1 | solo lectura |  | 3 |
| `financialtransactionsetactivities` | 39 | 9 | 1 | solo lectura | 7 |  |
| `financialtransactionsets` | 14 | 2 | 0 | solo editar |  | 2 |
| `flexcodefieldusages` | 32 | 10 | 0 | solo lectura |  | 1 |
| `flexcodegroupdetails` | 22 | 6 | 0 | crear + editar |  |  |
| `flexcodegroups` | 22 | 5 | 0 | crear + editar |  | 1 |
| `flexcodes` | 14 | 3 | 0 | crear + editar |  | 1 |
| `flexcodesetdetails` | 20 | 6 | 0 | crear + editar |  |  |
| `flexcodesystems` | 27 | 5 | 2 | crear + editar |  | 20 |
| `floorplans` | 32 | 5 | 1 | crear + editar |  | 3 |
| `floorplantagdetails` | 22 | 5 | 0 | solo lectura |  |  |
| `fundingarrangements` | 20 | 4 | 0 | crear + editar |  | 3 |
| `genderidentities` | 20 | 4 | 0 | crear + editar |  | 1 |
| `generateaccountingmessage` | 28 | 3 | 0 | solo lectura |  |  |
| `geographicconditions` | 23 | 6 | 0 | solo lectura |  |  |
| `geographicregions` | 21 | 4 | 1 | crear + editar |  | 1 |
| `globalactivities` | 62 | 8 | 1 | solo lectura | 31 |  |
| `identifiertypes` | 23 | 5 | 0 | crear + editar |  | 2 |
| `inclusionrules` | 67 | 21 | 3 | crear + editar |  |  |
| `individualproviders` | 103 | 11 | 5 | crear + editar | 53 | 7 |
| `insurableentities` | 16 | 5 | 0 | solo lectura |  |  |
| `insurableentitytypes` | 24 | 4 | 0 | crear + editar |  | 3 |
| `insurablepersons` | 16 | 5 | 0 | crear + editar |  |  |
| `insurancetypes` | 21 | 4 | 1 | crear + editar |  | 4 |
| `interfacedmessagedetails` | 17 | 3 | 0 | solo lectura | 1 |  |
| `interfacedmessages` | 23 | 4 | 1 | solo lectura |  | 1 |
| `keyboardshortcuts` | 25 | 4 | 0 | crear + editar |  |  |
| `languages` | 16 | 2 | 0 | crear + editar |  | 16 |
| `largeclaimchangelogs` | 6 | 1 | 0 | solo lectura |  |  |
| `limitconsumptions` | 39 | 10 | 0 | solo lectura |  |  |
| `limitcounterperiods` | 22 | 4 | 0 | solo lectura |  |  |
| `limitcounters` | 15 | 5 | 0 | solo lectura |  | 2 |
| `limits` | 45 | 11 | 0 | crear + editar |  | 10 |
| `locationtypegroupdetails` | 20 | 6 | 0 | solo lectura |  |  |
| `locationtypegroups` | 21 | 4 | 1 | crear + editar |  | 6 |
| `locationtypes` | 22 | 5 | 0 | crear + editar |  | 5 |
| `logapplicationevents` | 17 | 3 | 0 | solo lectura |  |  |
| `logdynamiclogicevents` | 18 | 3 | 0 | solo lectura |  |  |
| `logeventretentionperiods` | 12 | 2 | 1 | solo lectura |  | 1 |
| `logfilesetspecifications` | 17 | 5 | 0 | solo crear |  |  |
| `loggers` | 13 | 3 | 0 | crear + editar |  |  |
| `loglevelretentionperiods` | 12 | 3 | 0 | solo lectura |  |  |
| `logphievents` | 20 | 1 | 0 | solo lectura |  |  |
| `logsecurityevents` | — | — | — | solo lectura | — | sin definición legible |
| `lowerofrules` | 52 | 15 | 3 | crear + editar |  |  |
| `macrodefinitions` | 28 | 7 | 1 | crear + editar |  | 2 |
| `macrohistory` | 14 | 3 | 0 | solo editar |  |  |
| `macroparameters` | 27 | 6 | 0 | solo lectura |  |  |
| `maritalstatuses` | 13 | 4 | 0 | crear + editar |  |  |
| `maritalstatustypes` | 21 | 4 | 0 | crear + editar |  | 1 |
| `messagegroupdetails` | 20 | 6 | 0 | solo lectura |  |  |
| `messagegroups` | 22 | 5 | 1 | crear + editar |  | 5 |
| `messagerules` | 53 | 15 | 3 | crear + editar |  |  |
| `messages` | 35 | 4 | 0 | crear + editar | 3 | 69 |
| `modifiers` | 21 | 4 | 0 | crear + editar |  | 7 |
| `notes` | 9 | 2 | 0 | solo lectura |  |  |
| `oauthassertionjwtbearergrantconfigurations` | 23 | 2 | 1 | crear + editar |  |  |
| `oauthclientconfigurationparameters` | 11 | 3 | 0 | solo lectura |  |  |
| `oauthclientcredentialsgrantconfigurations` | 16 | 2 | 1 | crear + editar |  |  |
| `oauthparameters` | 12 | 2 | 0 | crear + editar |  | 1 |
| `objectstorageapikeyusecases` | 14 | 3 | 0 | crear + editar |  |  |
| `objectstorageconfigurationfileusecases` | 13 | 2 | 0 | crear + editar |  |  |
| `objectstoragecredentials` | 14 | 2 | 0 | crear + editar |  | 1 |
| `objectstorageresourceprincipalusecases` | 13 | 2 | 0 | crear + editar |  |  |
| `ohiresources` | 17 | 2 | 1 | solo lectura |  | 4 |
| `organizationproviders` | 95 | 10 | 4 | crear + editar | 53 | 7 |
| `organizations` | 39 | 7 | 6 | crear + editar | 7 | 2 |
| `parametersets` | 30 | 5 | 0 | solo lectura | 8 | 6 |
| `partialproviderpricingclauseclaimclassifications` | 11 | 3 | 0 | solo lectura |  |  |
| `partialproviderpricingclauseclaimlineclassifications` | 11 | 3 | 0 | solo lectura |  |  |
| `partialproviderpricingclauseclassificationschemes` | 11 | 3 | 0 | solo lectura |  |  |
| `partialproviderpricingclauserestrictreimbursementmethods` | 12 | 3 | 0 | solo lectura |  |  |
| `partialproviderpricingclauses` | 47 | 3 | 5 | solo lectura |  | 5 |
| `partialprovpricingclausedynlogic` | 11 | 3 | 0 | solo lectura |  |  |
| `payercodes` | 23 | 5 | 0 | solo lectura |  | 1 |
| `payers` | 29 | 5 | 1 | crear + editar | 6 | 6 |
| `paymentfunctions` | 26 | 8 | 0 | crear + editar |  |  |
| `paymentfunctiontypes` | 21 | 4 | 0 | crear + editar |  | 1 |
| `pendreasons` | 37 | 8 | 0 | crear + editar |  | 6 |
| `pendresolutionbatches` | 14 | 2 | 0 | solo lectura |  |  |
| `personcoveredservices` | 21 | 6 | 0 | crear + editar |  |  |
| `persons` | 56 | 11 | 10 | crear + editar | 7 | 20 |
| `persontitles` | 11 | 4 | 0 | crear + editar |  |  |
| `policyfamilies` | 14 | 4 | 0 | solo lectura |  |  |
| `policyproductparameters` | 15 | 3 | 0 | solo lectura |  |  |
| `policyproductprovidergroups` | 14 | 4 | 0 | solo lectura |  |  |
| `policyproducts` | 22 | 6 | 2 | solo lectura |  | 2 |
| `policyreinsuranceregimetreaties` | 14 | 3 | 1 | solo lectura |  | 1 |
| `policyreinsuranceregimetreatyparams` | 16 | 3 | 0 | solo lectura |  |  |
| `postbenefitsregimes` | 22 | 4 | 1 | crear + editar |  | 4 |
| `postcoverwithholdrules` | 27 | 9 | 0 | solo lectura |  | 1 |
| `prefixes` | 21 | 4 | 0 | crear + editar |  | 3 |
| `pricingexternalinterventionruleclaimforms` | 20 | 6 | 0 | crear + editar |  |  |
| `pricingexternalinterventionrules` | 59 | 20 | 4 | crear + editar |  | 1 |
| `pricingoptions` | 24 | 5 | 1 | crear + editar |  | 2 |
| `pricingpriorities` | 21 | 4 | 0 | crear + editar |  | 1 |
| `pricingruleclassifications` | 20 | 5 | 0 | crear + editar |  |  |
| `pricingrulemodifiers` | 20 | 5 | 0 | crear + editar |  |  |
| `pricingrulereimbursementmethodtypes` | 20 | 4 | 0 | crear + editar |  |  |
| `pricingrules` | 90 | 31 | 4 | solo lectura |  |  |
| `pricingsectionoptions` | 24 | 6 | 0 | solo lectura |  |  |
| `pricingsections` | 22 | 5 | 1 | solo lectura |  | 1 |
| `pricingtemplates` | 22 | 5 | 1 | crear + editar |  | 1 |
| `pricingworksheets` | 24 | 5 | 0 | crear + editar |  | 2 |
| `proceduregroupdetails` | 37 | 9 | 0 | crear + editar | 9 |  |
| `proceduregroups` | 23 | 5 | 0 | crear + editar | 1 | 98 |
| `procedures` | 79 | 6 | 1 | crear + editar | 52 | 16 |
| `proceduresettings` | 29 | 5 | 0 | solo lectura | 5 |  |
| `processfieldderivationpriorities` | 21 | 4 | 0 | crear + editar |  | 1 |
| `processfieldderivationruleclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `processfieldderivationrules` | 44 | 15 | 1 | crear + editar | 1 | 1 |
| `processfields` | 14 | 3 | 1 | solo lectura |  | 1 |
| `productbenefitspecificationbatches` | 15 | 4 | 0 | solo lectura |  |  |
| `productbenefitspecificationlimits` | 30 | 7 | 0 | crear + editar |  |  |
| `productbenefitspecificationreinsurances` | 23 | 5 | 0 | crear + editar |  |  |
| `productbenefitspecifications` | 28 | 6 | 3 | crear + editar |  | 5 |
| `productbenefitspecificationvalues` | 26 | 6 | 0 | crear + editar |  |  |
| `productcategories` | 22 | 4 | 2 | crear + editar |  | 4 |
| `productcategorydimensions` | 25 | 11 | 0 | solo lectura |  |  |
| `productcategorydynamiclogic` | 21 | 6 | 0 | solo lectura |  |  |
| `productfamilies` | 21 | 4 | 0 | crear + editar | 1 | 3 |
| `productlimits` | 32 | 6 | 0 | solo lectura |  |  |
| `productlines` | 20 | 4 | 0 | crear + editar |  | 3 |
| `productpriorities` | 21 | 4 | 0 | crear + editar |  | 1 |
| `productprovidergroups` | 23 | 6 | 0 | solo lectura |  |  |
| `products` | 32 | 10 | 2 | crear + editar |  | 18 |
| `properties` | 12 | 2 | 0 | crear + editar |  |  |
| `providerassignmenttypes` | 20 | 4 | 0 | crear + editar |  | 1 |
| `providercategories` | 23 | 4 | 2 | crear + editar |  | 4 |
| `providercategorydynamiclogic` | 21 | 6 | 0 | solo lectura |  |  |
| `providercategoryspecialties` | 20 | 6 | 0 | solo lectura |  |  |
| `providergroupaffiliations` | 26 | 6 | 0 | crear + editar | 4 |  |
| `providergroups` | 21 | 4 | 0 | crear + editar |  | 10 |
| `provideridentifiers` | 22 | 6 | 0 | crear + editar |  |  |
| `providerlimitcategories` | 36 | 9 | 1 | crear + editar |  | 1 |
| `providerlimitconsumptions` | 30 | 8 | 0 | solo lectura |  |  |
| `providerlimitcounterperiods` | 18 | 3 | 0 | solo lectura |  | 1 |
| `providerlimitcounters` | 17 | 9 | 0 | solo lectura |  | 3 |
| `providerlimitheights` | 24 | 5 | 0 | crear + editar |  |  |
| `providerlimitruleconsumptions` | 31 | 9 | 0 | solo lectura |  |  |
| `providerlimitrules` | 56 | 17 | 4 | solo lectura |  | 2 |
| `providerpricingclauseclaimclassifications` | 20 | 6 | 0 | solo lectura |  |  |
| `providerpricingclauseclaimlineclassifications` | 20 | 6 | 0 | solo lectura |  |  |
| `providerpricingclauseclassificationschemes` | 20 | 6 | 0 | solo lectura |  |  |
| `providerpricingclausedynamiclogic` | 21 | 6 | 0 | solo lectura |  |  |
| `providerpricingclauserestrictreimbursementmethods` | 20 | 5 | 0 | solo lectura |  |  |
| `providerpricingclauses` | 79 | 20 | 8 | crear + editar | 7 | 8 |
| `providers` | 93 | 9 | 3 | solo lectura | 53 | 27 |
| `providerspecialties` | 25 | 6 | 0 | crear + editar | 3 |  |
| `providertitles` | 20 | 6 | 0 | crear + editar |  |  |
| `purgeauthorizations` | 23 | 3 | 0 | solo lectura |  |  |
| `purgeclaims` | 29 | 3 | 0 | solo lectura |  |  |
| `readconsumptionbatches` | 14 | 5 | 0 | solo lectura |  |  |
| `referencesheetlines` | — | — | — | solo lectura | — | sin definición legible |
| `referencesheets` | 21 | 6 | 0 | crear + editar |  | 1 |
| `regimeconsumptions` | 26 | 9 | 0 | solo lectura |  |  |
| `regimecounters` | 20 | 6 | 0 | solo lectura |  | 1 |
| `registrationactivities` | 32 | 9 | 1 | solo lectura |  |  |
| `registrationinvoices` | 12 | 4 | 1 | crear + editar |  | 1 |
| `registrations` | 37 | 2 | 2 | crear + editar | 7 | 4 |
| `reimbursementmethods` | 44 | 13 | 2 | solo lectura |  |  |
| `reimbursementmethodtypes` | 22 | 4 | 0 | solo lectura |  |  |
| `reinsuranceregimes` | 24 | 5 | 1 | solo lectura |  | 1 |
| `reinsurancerules` | 27 | 9 | 0 | solo lectura |  | 1 |
| `relationidentifiers` | 13 | 4 | 0 | crear + editar |  |  |
| `relationlinks` | 14 | 5 | 0 | crear + editar |  |  |
| `relationlinktypes` | 25 | 4 | 0 | crear + editar |  | 1 |
| `relations` | 39 | 7 | 6 | solo lectura | 7 | 13 |
| `relationtags` | 13 | 4 | 0 | crear + editar |  |  |
| `renderingaddresses` | 22 | 6 | 0 | crear + editar |  |  |
| `replacementrules` | 56 | 17 | 3 | crear + editar |  |  |
| `reportingviews` | 11 | 3 | 0 | solo lectura |  | 1 |
| `reservationregimes` | 33 | 12 | 0 | crear + editar |  | 2 |
| `resourcecachesettings` | 12 | 2 | 0 | crear + editar |  | 2 |
| `resourceproperties` | 6 | 0 | 0 | solo lectura |  |  |
| `resourcesettingsoverride` | 11 | 4 | 0 | crear + editar |  |  |
| `serviceaddresses` | 37 | 7 | 1 | crear + editar | 5 | 1 |
| `servicetypes` | 20 | 4 | 0 | crear + editar |  | 1 |
| `settlementreasons` | 21 | 5 | 0 | crear + editar |  | 1 |
| `signatures` | 11 | 2 | 0 | solo lectura |  | 2 |
| `simpleadjustmentrules` | 55 | 17 | 4 | crear + editar | 1 |  |
| `skiptagclaimforms` | 20 | 6 | 0 | solo lectura |  |  |
| `skiptags` | 22 | 4 | 1 | crear + editar |  | 8 |
| `sourcereplicationeventlogconfigurations` | 13 | 2 | 0 | solo lectura |  | 1 |
| `sourcereplicationevents` | 9 | 1 | 0 | solo lectura |  |  |
| `specialties` | 29 | 4 | 0 | crear + editar | 8 | 7 |
| `sublimits` | 22 | 6 | 0 | crear + editar |  |  |
| `supportedinsurableentitytypes` | 20 | 6 | 0 | solo lectura |  |  |
| `synchronousmessages` | 21 | 4 | 1 | solo lectura |  |  |
| `systemeventlogs` | 15 | 2 | 0 | solo editar |  |  |
| `tablecolumns` | 14 | 3 | 0 | solo lectura |  |  |
| `tables` | 35 | 4 | 0 | solo lectura |  | 19 |
| `tagtypemessages` | 22 | 6 | 0 | solo lectura |  |  |
| `tagtypes` | 22 | 4 | 1 | crear + editar |  | 2 |
| `targetreplicationeventlogconfigurations` | 13 | 3 | 0 | solo lectura |  | 1 |
| `targetreplicationevents` | 14 | 4 | 0 | solo lectura |  |  |
| `taskattributes` | 17 | 4 | 0 | solo lectura |  |  |
| `tasks` | 25 | 7 | 1 | solo lectura |  | 2 |
| `tasktypeattributes` | 17 | 4 | 0 | solo lectura |  |  |
| `tasktypes` | 14 | 2 | 1 | solo lectura |  | 2 |
| `titles` | 23 | 4 | 0 | crear + editar |  | 2 |
| `transactionscenarios` | 35 | 11 | 0 | crear + editar |  |  |
| `transactionsources` | 22 | 4 | 1 | crear + editar |  | 11 |
| `transactionsourceusages` | 20 | 5 | 0 | solo lectura |  |  |
| `underwriters` | 14 | 3 | 0 | crear + editar |  |  |
| `unfinalizereasongroupdetails` | 20 | 6 | 0 | solo lectura |  |  |
| `unfinalizereasongroups` | 21 | 4 | 1 | crear + editar |  | 3 |
| `unfinalizereasons` | 25 | 5 | 0 | crear + editar | 1 | 2 |
| `userinterfaceprocessingmessages` | 21 | 4 | 1 | solo lectura |  |  |
| `userpreferences` | 19 | 4 | 2 | crear + editar |  | 3 |
| `userpreferencewidgets` | 15 | 4 | 0 | crear + editar |  |  |
| `userrolehistory` | 13 | 3 | 0 | solo lectura |  |  |
| `userroles` | 11 | 4 | 0 | solo lectura |  |  |
| `users` | 17 | 6 | 0 | solo lectura |  | 10 |
| `usersequences` | 15 | 2 | 0 | solo crear |  |  |
| `userviewpreferences` | 14 | 4 | 0 | crear + editar |  |  |
| `viewfloorplans` | 26 | 6 | 0 | crear + editar |  | 1 |
| `waitingperiodregimes` | 27 | 7 | 0 | crear + editar |  | 3 |
| `waiverreasons` | 22 | 5 | 0 | crear + editar |  | 1 |
| `widgets` | 28 | 6 | 0 | crear + editar |  | 1 |
| `writeconsumptionbatches` | 13 | 3 | 0 | solo lectura |  |  |
