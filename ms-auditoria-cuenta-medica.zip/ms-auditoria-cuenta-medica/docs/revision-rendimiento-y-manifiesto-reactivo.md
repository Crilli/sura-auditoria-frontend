# Revisión de arquitectura — rendimiento y manifiesto reactivo

`ms-auditoria-cuenta-medica` · revisión del 2026-10-16 · sobre el código, no sobre el diseño en papel.

Objetivo: anticipar **dónde falla el servicio en una prueba de rendimiento** y medir su cumplimiento
de los cuatro rasgos del Manifiesto Reactivo. Cada hallazgo cita el archivo y la línea.

---

## Resumen ejecutivo

Lo primero, porque condiciona el resto: **no hay una sola llamada bloqueante explícita**
(`.block()`, `Thread.sleep`, `toFuture().get()`) en el camino de petición. Eso es más de lo que
suele encontrarse y habla bien del equipo.

Dicho eso, **hay un bloqueo real que ningún `grep` encuentra**, y tres límites dimensionados por
debajo de lo que una prueba de carga va a exigir. Con la configuración actual mi pronóstico es que
el servicio **no supera una prueba sostenida de ~200 usuarios concurrentes**, y que fallará por
agotamiento de hilos de Netty antes que por CPU o por OHI.

| # | Hallazgo | Severidad | Falla por |
|---|---|---|---|
| 1 | `StreamBridge.send()` se ejecuta en el event loop | **Bloqueante** | hilos de Netty |
| 2 | Heap de 512 MB contra 100 respuestas de hasta 8 MB | **Bloqueante** | `OutOfMemoryError` |
| 3 | Caché de identidad de 500 entradas | **Bloqueante** | duplica el tráfico a OHI |
| 4 | Amplificación 1:20 (y 1:100) con reintento ×3 | Grave | presupuesto de latencia |
| 5 | `pendingAcquireTimeout` mayor que el timeout de lectura | Grave | latencia de cola invisible |
| 6 | SSE sin tope de conexiones concurrentes | Grave | saturación de OHI |
| 7 | La traza de auditoría se pierde en silencio | Grave | pérdida de datos sin señal |
| 8 | El módulo R2DBC no lo usa nadie | Media | peso muerto |
| 9 | Servidor Netty sin límites declarados | Media | sin contrapresión en la entrada |

---

## 1 · `StreamBridge.send()` bloquea el event loop · **bloqueante**

`infraestructura/adaptadores/bus-eventos/.../AdaptadorPublicadorEventos.java:26-34`

```java
return Mono.fromRunnable(() -> {
    ...
    boolean enviado = streamBridge.send(BINDING_NAME, mensaje);   // ← síncrono
});
```

`Mono.fromRunnable` ejecuta el bloque **en el hilo que se suscribe**, que en WebFlux es un hilo del
event loop de Netty. Y `StreamBridge.send(...)` es la API **síncrona** de Spring Cloud Stream:
contra RabbitMQ puede esperar al canal, a los *publisher confirms* o al reintento del binder.

No hay `subscribeOn(Schedulers.boundedElastic())` en ninguna parte del proyecto — lo comprobé:
`grep -r "subscribeOn\|boundedElastic"` no devuelve nada en `src/main`.

**Por qué es el hallazgo número uno.** Los event loops de Netty son tantos como núcleos: en un
contenedor con 2 o 4 vCPU hay 2 a 4 hilos para *todo* el servicio. Cada comando del auditor
—guardar línea, resolver pendiente, enviar cuenta, ejecutar acción— publica su evento por esta vía.
Basta con que RabbitMQ se ponga lento para que esos pocos hilos se queden esperando y el servicio
**deje de responder incluso a las consultas**, que no tienen nada que ver con el bus.

Es el caso de libro que el manifiesto reactivo llama *failure containment* y aquí no existe: un
fallo del bus se propaga a todo el servicio.

**Remedio:** `.subscribeOn(Schedulers.boundedElastic())` sobre el `Mono.fromRunnable`, o mejor,
pasar al `StreamOperations` reactivo. Un `BlockHound` en las pruebas lo habría detectado el primer
día; merece la pena añadirlo.

---

## 2 · Heap de 512 MB contra 100 respuestas de hasta 8 MB · **bloqueante**

`Dockerfile:12` → `-Xms256m -Xmx512m`
`ConfiguracionClienteOhi.java` → `maxConnections(50)` en **dos** pools
`application.yml` → `maximo-respuesta: 8MB`

El `maxInMemorySize` de 8 MB no es un límite agregado: es **por respuesta**, y el cuerpo se
materializa entero en heap antes de deserializarse. Con los dos pools saturados son 100 respuestas
en vuelo:

```
100 conexiones × 8 MB = 800 MB   contra un heap de 512 MB
```

No hace falta llegar al caso extremo. El detalle de línea proyecta ~60 campos y la paginación trae
lotes de 200; una respuesta real de `/lineas` ronda los cientos de KB, pero las de `resumirFiltros`
—que recorre hasta 10.000 líneas en lotes de 200— y las de `recorrerTodasLasLineas` son otra cosa.
Con ZGC el *allocation rate* además castiga: `-XX:+UseZGC` con 512 MB deja muy poco margen.

**Remedio:** subir `-Xmx` a 1-2 GB *o* bajar `maximo-respuesta` a 2 MB y `maxConnections` a lo que
OHI realmente tolere. Y medir con `jcmd GC.heap_info` durante la prueba, no después.

---

## 3 · La caché de identidad de 500 entradas se desfonda · **bloqueante**

`infraestructura/adaptadores/acl-ohi/.../identidad/ResolutorIdentidadOhi.java:28-29`

```java
.maximumSize(500)
.expireAfterWrite(Duration.ofMinutes(10))
```

**Toda** operación del API empieza resolviendo el código de negocio (`CM-108800618430`) al id técnico
de OHI, y eso es una consulta más contra OHI cuando falla la caché. Los adaptadores la invocan
4, 4, 5 y 1 veces respectivamente (`AdaptadorConsultasOhi`, `AdaptadorComandosOhi`,
`AdaptadorPendientesOhi`, `AdaptadorNotasOhi`).

Una prueba de rendimiento realista recorre **miles de cuentas distintas**, no diez. Con 500 entradas
la tasa de acierto se desploma y **cada petición pasa a costar dos llamadas a OHI en vez de una**.
Lo peor es cómo se manifiesta: la prueba corta con pocos usuarios parece bien (caché caliente, pocas
cuentas) y a partir de cierto volumen de datos la latencia se duplica de golpe, sin que nada en el
código haya cambiado.

La caché ya tiene `recordStats()`, así que la evidencia está a mano: **exponer el *hit rate* en
Micrometer antes de la prueba** y mirarlo durante.

**Remedio:** subir a 50.000 entradas (un `Long` por código: unos pocos MB) y alargar la expiración,
porque la relación código→id de OHI es inmutable.

---

## 4 · Amplificación de llamadas: 1 petición → hasta 60 llamadas a OHI · grave

`AdaptadorConsultasOhi.java:536` → `MAXIMO_LOTES_POR_PAGINA = 20`
`AdaptadorConsultasOhi.java:243` → `MAXIMO_LOTES_AL_DESCARTAR = 100`
`AdaptadorConsultasOhi.java:631` → `MAXIMO_LINEAS_RESUMIDAS = 10_000`
`application.yml` → `retry.ohiConsultas: maxAttempts 3, waitDuration 500ms`

Los topes existen y están bien pensados —no hay bucles infinitos—, pero el factor de amplificación
es alto y **se multiplica por el reintento**:

| Operación | Llamadas secuenciales a OHI | Con reintento ×3 |
|---|---|---|
| Listar líneas con filtro de catálogo o glosa | hasta **20** | hasta **60** |
| Listar descartando | hasta **100** | hasta **300** |
| Resumir filtros (10.000 líneas / lote de 200) | hasta **50** | hasta **150** |

El reintento se aplica **por llamada individual** (`resiliencia.paraConsultasMono()` envuelve cada
una), no a la operación completa. Son llamadas secuenciales con `expand`, así que a 5 s de timeout
cada una, **una sola petición del auditor puede ocupar una conexión durante minutos** mientras el
navegador hace rato que se rindió.

Esto es lo que convierte una prueba de 200 usuarios en una de 4.000 peticiones simultáneas contra
OHI. **Es el hallazgo que más probablemente haga caer a OHI antes que al servicio.**

**Remedio:** un presupuesto de tiempo por petición (`.timeout(...)` sobre la operación completa, no
solo por llamada), y desactivar el reintento cuando ya se van varios lotes.

---

## 5 · La cola de conexiones dura más que el timeout de lectura · grave

`ConfiguracionClienteOhi.java`

```java
.maxConnections(50)
.pendingAcquireTimeout(Duration.ofSeconds(10))   // ← mayor que lectura: 5s
.maxIdleTime(Duration.ofSeconds(20))
```

Dos problemas:

- **`pendingAcquireTimeout` (10 s) supera al timeout de lectura (5 s).** Una petición puede esperar
  10 s por una conexión y *después* consumir sus 5 s: 15 s totales para una operación que el
  presupuesto declara de 5. Esa espera **no aparece en las métricas del cliente HTTP**, porque
  sucede antes de que exista la petición.
- **`pendingAcquireMaxCount` no está definido**, así que toma el valor por omisión de Reactor Netty:
  `2 × maxConnections` = **100 en cola**. Con los dos pools, 300 peticiones pueden estar vivas antes
  de que algo se rechace. Rechazar rápido es mejor que encolar: encolar convierte una saturación en
  una cascada de timeouts.

**Remedio:** `pendingAcquireTimeout` por debajo del de lectura (2-3 s) y `pendingAcquireMaxCount`
explícito y pequeño. Y exponer `reactor.netty.connection.provider.pending.connections` en Micrometer.

---

## 6 · El SSE no tiene tope de conexiones · grave

`dominio/casos-de-uso/SeguirProcesoCasoDeUso.java:38` · `CasosDeUsoConfig.java:133-134`

```java
Flux.interval(Duration.ZERO, intervaloConsulta)      // 2 s por omisión
    .concatMap(tic -> consultas.consultarEstadoProceso(codigo))
    ...
    .take(esperaMaxima)                              // 30 s por omisión
```

Cada cliente conectado a `/proceso/flujo` monta **su propio temporizador** y genera **una llamada a
OHI cada 2 segundos durante 30**. Son 15 llamadas por auditor que mira. Con 100 auditores observando
—algo normal justo después de un envío masivo— son **750 llamadas a OHI en medio minuto**, solo para
sondear.

Además `GET /proceso/flujo` es un endpoint **con estado**: mantiene la conexión abierta y fija al
cliente a una instancia concreta. Eso limita el escalado horizontal (ver *Elastic*, más abajo).

**Remedio:** compartir un solo flujo por cuenta (`Flux.cache()` / `share()` sobre un `Map` por
código), de modo que N observadores de la misma cuenta cuesten un sondeo y no N. Y un tope de
conexiones SSE concurrentes.

---

## 7 · La traza de auditoría puede perderse entera, en silencio · grave

Hay **tres capas** que se tragan el error, una encima de otra:

1. `AdaptadorPublicadorEventos` captura `Exception` y solo registra (`log.error`).
2. Cuando el bus devuelve `false` (mensaje rechazado), solo registra (`log.warn`).
3. Cada caso de uso añade `.onErrorResume(e -> Mono.empty())`.

La intención es correcta y está bien razonada: **la traza no debe tumbar un comando que ya se
aplicó en OHI**. Pero el resultado es que, bajo carga, si el bus se satura **la auditoría desaparece
sin que ninguna métrica lo diga**. En un sistema de cuentas médicas eso es un riesgo de cumplimiento,
y en una prueba de rendimiento es la peor clase de hallazgo: la prueba **pasa** mientras se pierden
datos.

**Remedio:** un contador Micrometer de eventos descartados y una alerta sobre él. Si el dato importa
de verdad, un *outbox* en la base que ya está disponible.

---

## 8 · El módulo de trazabilidad R2DBC no lo usa nadie · media

`RepositorioTrazaAuditoria.guardar(...)` está declarado en el puerto, implementado en
`AdaptadorTrazaAuditoria` y **ningún caso de uso lo invoca**. Lo verifiqué con
`grep -rn "RepositorioTrazaAuditoria\|\.guardar("`: solo aparece en el puerto y en su propia
implementación.

Cuesta, sin dar nada a cambio: un pool de **20 conexiones** (`application.yml:17-18`), migraciones
Flyway y una dependencia de MySQL en el arranque. En una prueba de rendimiento es ruido que compite
por memoria y descriptores.

Lo mismo ocurre con `recorrerTodasLasLineas`: declarado en el puerto, implementado, **sin llamadores**.
Dado que hace un recorrido completo de la cuenta, es mejor que no lo tenga.

**Remedio:** decidir — o se conecta la traza a la base, o se retiran el módulo y el puerto.

---

## 9 · El servidor no declara ningún límite · media

`application.yml:1-3` tiene solo `port` y `shutdown: graceful`. No hay
`server.netty.max-connections`, ni `max-initial-line-length`, ni límite de tamaño de petición, ni
número de hilos del event loop.

Sin un tope en la entrada, el servicio acepta todo lo que llegue y la contrapresión se resuelve
agotando memoria en lugar de rechazando. Para una prueba de carga conviene fijarlos explícitamente,
aunque sea en los valores por omisión, para que el resultado sea reproducible.

---

# Cumplimiento del Manifiesto Reactivo

Los cuatro rasgos, con evidencia y veredicto.

## Responsive (capacidad de respuesta) — **parcial**

**A favor.** Hay timeouts en las tres dimensiones (`conexion: 2s`, `lectura: 5s`, `escritura`), un
cliente aparte con presupuesto largo para la resolución de pendientes (`25s`), y el modelo de error
traduce los 11 errores de dominio a su HTTP correcto, incluido `503` cuando OHI no está — el cliente
siempre recibe una respuesta con significado, nunca un cuelgue.

**En contra.** El presupuesto de latencia **no se respeta de punta a punta**: la amplificación del
hallazgo 4 permite que una petición de 5 s declarados tarde minutos, y la cola del hallazgo 5 añade
10 s invisibles. Un timeout por llamada no es un presupuesto por petición.

→ **Falta:** `.timeout()` sobre la operación completa en el caso de uso, no solo en el adaptador.

## Resilient (resiliencia) — **parcial**

**A favor.** Circuit breakers **segmentados por tipo de operación** (`ohiConsultas`, `ohiComandos`,
`ohiEnvio`) con ventanas y backoff distintos — eso es *bulkheading* bien hecho, y es la decisión de
diseño más acertada del proyecto. Dos pools de conexiones separados refuerzan el aislamiento. El
cerrojo optimista por versión evita corrupción bajo concurrencia.

**En contra.** El hallazgo 1 **anula el aislamiento donde más importa**: un fallo del bus de eventos
no está contenido, se come los hilos del servidor y tumba también las consultas. Y los errores
tragados del hallazgo 7 son lo contrario de resiliencia: es ocultamiento.

→ **Falta:** sacar el bus del event loop, y que *degradar* sea visible en métricas.

## Elastic (elasticidad) — **el más flojo**

**En contra, casi todo.** Nada en el servicio permite escalar horizontalmente sin pensarlo:

- **Estado en memoria por instancia.** La caché de identidad (500 entradas) y la del token viven en
  el proceso. Con N instancias hay N cachés frías y N×(peticiones a IDCS).
- **SSE fija al cliente a una instancia.** `/proceso/flujo` mantiene la conexión; un reequilibrio o
  un despliegue la corta.
- **Pools de tamaño fijo** (50 y 50) sin relación con el número de instancias: 4 réplicas son 400
  conexiones contra OHI, que puede no tolerarlas. **El límite de concurrencia debe repartirse entre
  réplicas, y hoy no lo hace nadie.**
- **Sin señales de escalado.** El actuator expone salud y métricas, pero no hay un indicador de
  saturación (profundidad de cola, conexiones pendientes) sobre el que un HPA pueda decidir.

→ **Falta:** caché distribuida o aceptar el coste y medirlo; límite de concurrencia por réplica
calculado desde el presupuesto global de OHI; y exponer la saturación como métrica.

## Message Driven (orientado a mensajes) — **incumplido en el punto clave**

**A favor.** Todo el camino interno es `Mono`/`Flux` sin bloqueo, la contrapresión se propaga por la
cadena, y `expand` mantiene la paginación secuencial sin acumular. Existe una frontera asíncrona real
(el bus de eventos).

**En contra.** **La única frontera asíncrona del sistema se cruza de forma síncrona** (hallazgo 1).
Un sistema *message driven* desacopla al emisor del receptor; aquí el emisor paga la latencia del
receptor, y la paga con el hilo más caro que tiene. Además, la contrapresión **no llega al cliente**:
el SSE no la propaga y el endpoint de líneas tampoco — la defensa es un tope de lotes, no una
negociación de demanda.

→ **Falta:** publicar fuera del event loop y propagar la contrapresión al borde.

---

# Qué haría antes de ejecutar la prueba

En este orden, porque el primero invalida los resultados de los demás:

1. **Sacar `StreamBridge.send` del event loop** y añadir **BlockHound** a las pruebas. Sin esto, la
   prueba mide el bus de RabbitMQ, no el servicio.
2. **Subir el heap a 1 GB** o bajar `maximo-respuesta` a 2 MB. Una prueba que muere por OOM no dice
   nada útil.
3. **Subir la caché de identidad a 50.000** y exponer su *hit rate*. Sin esto el resultado depende
   de cuántas cuentas distintas use el guion de la prueba, que es el peor eje de variación posible.
4. **Instrumentar antes de medir:** `hit rate` de las dos cachés, conexiones pendientes por pool,
   estado de los tres circuit breakers, eventos de auditoría descartados, y un histograma de
   *llamadas a OHI por petición* — esta última es la métrica que delata la amplificación.

Y un apunte sobre el guion de la prueba: **debe recorrer miles de cuentas distintas y usar los
filtros de catálogo y glosa**. Un guion que golpea diez cuentas sin filtros ejercita el camino
rápido y no encontrará ninguno de los tres hallazgos bloqueantes.
