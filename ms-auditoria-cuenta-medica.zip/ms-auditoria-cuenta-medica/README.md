# ms-auditoria-cuenta-medica

Microservicio que implementa la Auditoría de Cuentas Médicas actuando como una Anti-Corruption Layer (ACL) frente a Oracle Health Insurance (OHI).

> **El sistema del otro lado de la ACL está documentado en
> [`docs/ohi/`](docs/ohi/README.md)**: el modelo de datos de OHI producción, sus
> integraciones, cómo se consulta sin equivocarse y cómo se opera. Si vas a
> tocar `infraestructura-acl-ohi`, empieza por
> [02 — API y lenguaje de consulta](docs/ohi/02-api-y-lenguaje-de-consulta.md).

## Arquitectura

El servicio sigue estrictamente los lineamientos de **DDD (Domain-Driven Design)** y **Arquitectura Hexagonal**.

### Módulos

*   **dominio-modelo:** Entidades puras, objetos de valor y puertos (sin dependencias de frameworks externos excepto Project Reactor para firmas reactivas).
*   **dominio-casos-de-uso:** Lógica orquestadora del dominio.
*   **infraestructura-web-reactiva:** Adaptadores de entrada REST (WebFlux, Router functions).
*   **infraestructura-acl-ohi:** Capa anticorrupción hacia OHI. Traduce de OHI a dominio. Activa en `dev`, `lab` y `prod`.
*   **infraestructura-simulador-local:** Implementación en memoria de los mismos puertos. Activa **solo** en el perfil `local`.
*   **infraestructura-r2dbc-trazabilidad:** Persistencia reactiva en base de datos.
*   **infraestructura-bus-eventos:** Publicador de eventos en cola (Spring Cloud Stream).
*   **aplicacion-servicio-app:** Bootstrap, dependencias, migración y configuración (Spring Boot 3).

## Prerrequisitos

*   Java 21
*   Docker y Docker Compose (solo para los perfiles que usan base de datos y bus de eventos)

---

# Ejecución por perfil

| Perfil | Origen de los datos | Infraestructura que necesita |
| --- | --- | --- |
| `local` | **Simulador en memoria** (10 cuentas médicas) | Ninguna |
| `dev` | OHI real de desarrollo | MySQL, RabbitMQ, credenciales OHI |
| `lab` | OHI real de laboratorio | MySQL, RabbitMQ, credenciales OHI |
| `prod` | OHI real de producción | MySQL, RabbitMQ, credenciales OHI |

## Perfil `local` — sin dependencias externas

```bash
./gradlew :aplicacion-servicio-app:bootRun --args='--spring.profiles.active=local'
```

> El repositorio no incluye el wrapper de Gradle. Genérelo una vez con `gradle wrapper`
> (Gradle 8.x) o invoque directamente un `gradle` instalado.

No requiere MySQL, ni RabbitMQ, ni acceso a OHI: el simulador reemplaza al sistema de registro,
la traza de auditoría queda en memoria y los eventos se escriben en el log.

## Perfiles `dev`, `lab` y `prod` — integración real con OHI

1.  Levantar infraestructura local (solo si se corre contra una base y un bus locales):
    ```bash
    docker-compose up -d db rabbitmq
    ```
2.  Exportar las credenciales del perfil (ver `application.yml`): `OHI_URL_BASE_*`, `OHI_TOKEN_URL_*`,
    `OHI_CLIENT_ID_*`, `OHI_CLIENT_SECRET_*` y las variables `DB_*`.
3.  Ejecutar el servicio:
    ```bash
    ./gradlew :aplicacion-servicio-app:bootRun --args='--spring.profiles.active=dev'
    ```

### Cómo se conmuta entre simulador y OHI

Los adaptadores de la ACL (`AdaptadorConsultasOhi`, `AdaptadorComandosOhi`, `AdaptadorPendientesOhi`,
`AdaptadorNotasOhi`, el `WebClient` y el proveedor de token) están anotados con `@Profile("!local")`.
Los del simulador, con `@Profile("local")`. Los casos de uso y el enrutador REST son idénticos en
ambos casos: **el contrato del API no cambia entre perfiles**, solo cambia quién responde detrás del puerto.

---

# Perfil local: catálogo simulado

El simulador expone **10 cuentas médicas, cada una con entre 400 y 500 líneas**.
La generación es **determinista por fórmula** (sin aleatoriedad): cada arranque produce
exactamente los mismos datos, así que se pueden escribir pruebas de cliente estables.

Reiniciar el servicio devuelve el catálogo a su estado inicial: esa es la forma de descartar
las ediciones y los envíos hechos durante una sesión de pruebas.

## Las 10 cuentas

| Código | Líneas | Estado inicial | Pendientes sin resolver | Escenario que cubre |
| --- | ---: | --- | ---: | --- |
| `GT-106586883036` | 400 | `ADJUDICACION_MANUAL` | 19 (2 cabecera + 17 línea) | Envío bloqueado: exige resolver pendientes primero |
| `GT-106586883037` | 410 | `MODIFICACION` | 0 | Camino feliz: se puede enviar de inmediato |
| `GT-106586883038` | 420 | `TARIFACION_MANUAL` | 1 (cabecera) | Resolver un único pendiente de cabecera |
| `GT-106586883039` | 430 | `BENEFICIOS_MANUALES` | 11 (línea) | Pendientes solo a nivel de línea |
| `GT-106586883040` | 440 | `TARIFACION_ADJUDICACION_MANUAL` | 10 (2 cabecera + 8 línea) | Mezcla de niveles |
| `GT-106586883041` | 450 | `ADJUDICACION_MANUAL` | 20 (1 cabecera + 19 línea) | Volumen de pendientes |
| `GT-106586883042` | 460 | `MODIFICACION` | 0 | Segundo camino feliz |
| `GT-106586883043` | 470 | `ADJUDICACION_MANUAL` | 0 | Envío aceptado cuyo proceso termina en `FALLIDO` |
| `GT-106586883044` | 480 | `TARIFACION_COMPLETA` | 0 | Sin `ENVIAR`: devuelve `409 ACCION_NO_DISPONIBLE` |
| `GT-106586883045` | 490 | `FINALIZADA` | 0 | Sin `ENVIAR`: devuelve `409 ACCION_NO_DISPONIBLE` |

## Cuentas de PDN
| `CM-56791606102`  | 1500  |
| `CM-89012701730`  | 309   |
| `CM-55181980659`  | 40000 |
| `CM-108487770975` | 432   |






En estado `ADJUDICACION_MANUAL` **todo** pendiente sin resolver bloquea el envío, incluidos los de
sola adjudicación. En los demás estados manuales solo bloquean los que tienen `soloAdjudicacion: false`.

## Reglas de generación de las líneas

Con `c` = índice de la cuenta (0 a 9) y `n` = número de línea (1 a N):

| Atributo | Regla |
| --- | --- |
| `referencia` | `90114522 + c × 1.000.000 + n` |
| `codigoProcedimiento` | Catálogo de 12 procedimientos, índice `(n − 1 + c) mod 12` |
| `unidadesAutorizadas` | `1 + ((n − 1) mod 3)` |
| `valorAutorizado` | Tarifa del procedimiento × unidades autorizadas |
| `valorCubierto` | `0` si la línea tiene novedad bloqueante, está bloqueada o reemplazada; si no, **90 %** del autorizado |
| Novedad **bloqueante** | `n` múltiplo de **7** |
| Novedad de advertencia | `n` múltiplo de **5** |
| Novedad informativa | `n` múltiplo de **17** |
| `tarifacionManual` | `n` múltiplo de **11** |
| `beneficiosManuales` | `n` múltiplo de **13** |
| `reemplazada` (no editable) | `n` múltiplo de **89** |
| `bloqueada` (no editable) | `n` múltiplo de **97** |
| Pendiente de línea | `n` múltiplo del periodo de la cuenta (23, 37, 53 o ninguno) |
| `version` | `1 + (n mod 5)` |
| `codigoAfiliado` | `AF-` + `483921 + c × 137 + ((n − 1) div 150)` — unos 3 afiliados por cuenta |
| Fecha de prestación | Fecha de inicio de la cuenta + `((n − 1) mod 6)` días |

### Líneas útiles de `GT-106586883036` para probar cada caso

| Referencia | Línea | Qué tiene |
| --- | ---: | --- |
| `90114523` | 1 | Editable, sin novedades ni pendientes (`version` 2) |
| `90114529` | 7 | Novedad **bloqueante** `COB-208`; `valorCubierto` en 0 |
| `90114533` | 11 | `tarifacionManual: true` |
| `90114545` | 23 | Un pendiente de línea (`780023`, `PEN-LIN-TAR`) |
| `90114683` | 161 | Novedad bloqueante `AUT-031` **y** pendiente `780161` |
| `90114611` | 89 | `reemplazada: true` → `422 LINEA_NO_EDITABLE` al editar |
| `90114619` | 97 | `bloqueada: true` → `422 LINEA_NO_EDITABLE` al editar |

## Envío y proceso simulados

*   `POST /enviar` deja la cuenta en `ENVIADA_A_PREPROCESO` con `SEGUIR_PROCESO` como única acción.
*   Durante `simulador.local.duracion-proceso` (6 s por omisión) el proceso reporta `EN_PROCESO`.
*   Al vencer ese plazo, la cuenta pasa a `FINALIZADA` y el proceso reporta `EXITOSO`;
    en `GT-106586883043` reporta `FALLIDO` con dos errores y **restaura el estado previo**,
    de modo que se puede corregir y reintentar el envío.

## Parámetros configurables

```yaml
simulador:
  local:
    cantidad-cuentas: 10               # cuántas cuentas expone el simulador
    minimo-lineas: 400                 # cota inferior de líneas por cuenta
    maximo-lineas: 500                 # cota superior de líneas por cuenta
    prefijo-cuenta: "GT-"
    primer-consecutivo: 106586883036   # GT-106586883036 .. GT-106586883045
    latencia: 0ms                      # latencia artificial por operación
    duracion-proceso: 6s               # cuánto tarda el envío simulado
```

Subir `latencia` (por ejemplo a `80ms`) sirve para ver cómo se comporta la interfaz con una
red realista. Cambiar `minimo-lineas` / `maximo-lineas` reparte las cuentas de forma pareja
dentro del nuevo rango.

## Lo que el simulador **no** reproduce

*   Circuit breaker ni reintentos de Resilience4J (no hay llamadas remotas que proteger),
    así que `503 SISTEMA_REGISTRO_NO_DISPONIBLE` no aparece en `local`.
*   Errores de permisos: `403 SIN_PERMISO` y `403 LIMITE_APROBACION_EXCEDIDO` los origina OHI.
*   Persistencia entre reinicios: la traza de auditoría vive en memoria, acotada a 200 eventos por cuenta.

---

# Consumo del API desde un cliente

> Los cuerpos de respuesta de esta sección son **datos simulados**: no corresponden a información
> real de cuentas médicas ni de afiliados. Son exactamente los que devuelve el **perfil local**,
> así que sirven como contrato verificable: se pueden reproducir levantando el servicio con
> `--spring.profiles.active=local`.

## Convenciones generales

| Aspecto | Valor |
| --- | --- |
| URL base local | `http://localhost:8080` |
| Prefijo del recurso | `/api/v1/cuentas` |
| Content-Type | `application/json` (excepto el flujo SSE: `text/event-stream`) |
| Header de autoría | `X-Auditor` — usuario que origina el cambio; se registra en la traza de auditoría |
| Identificador de negocio | `codigo` de cuenta, tal como lo ve el auditor (ej. `GT-106586883036`) |
| Concurrencia | Las escrituras sobre líneas exigen `versionEsperada`; si otro usuario modificó la línea el servicio responde `412` |

### Endpoints disponibles

| Método | Ruta | Descripción | Éxito |
| --- | --- | --- | --- |
| `GET` | `/api/v1/cuentas/{codigo}` | Cabecera de la cuenta y acciones disponibles | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/lineas` | Listado paginado (keyset) de líneas | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/lineas/{referencia}` | Detalle de una línea | `200` |
| `PATCH` | `/api/v1/cuentas/{codigo}/lineas/{referencia}` | Guardar edición de línea | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/pendientes` | Pendientes sin resolver | `200` |
| `POST` | `/api/v1/cuentas/{codigo}/pendientes/{motivo}/resolver` | Resolver un motivo pendiente | `204` |
| `POST` | `/api/v1/cuentas/{codigo}/enviar` | Enviar la cuenta (asíncrono) | `202` |
| `GET` | `/api/v1/cuentas/{codigo}/proceso` | Estado puntual del envío | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/proceso/flujo` | Estado del envío en streaming (SSE) | `200` |

> **No existe un listado de cuentas.** `/api/v1/cuentas` sin código devuelve `404 RUTA_NO_ENCONTRADA`:
> siempre se consulta una cuenta por su código de negocio. Los 10 códigos del perfil local están en
> la sección «Perfil local» y también se imprimen en el log al arrancar.

---

## 1. Consultar la cabecera de una cuenta

El consumidor **no debe deducir qué puede hacer el auditor a partir del estado**: debe habilitar
cada operación según lo que venga en `accionesDisponibles` (contrato HATEOAS traducido por la ACL).

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036 \
  -H "Accept: application/json"
```

**Respuesta `200 OK`:**

```json
{
  "codigo": "GT-106586883036",
  "estado": "ADJUDICACION_MANUAL",
  "fechaInicio": "2026-05-04",
  "fechaFin": "2026-05-09",
  "totalAutorizado": 328298700.00,
  "totalCubierto": 247907070.00,
  "version": 1,
  "accionesDisponibles": [
    "ENVIAR",
    "SEGUIR_PROCESO",
    "RESOLVER_PENDIENTE",
    "RESOLVER_PENDIENTE_LINEA",
    "DEVOLVER_A_MODIFICACION",
    "DESBLOQUEAR_LINEAS",
    "DESHACER_REEMPLAZOS"
  ],
  "pendientesSinResolver": 2
}
```

> `accionesDisponibles` es un **conjunto**: el orden de los elementos no es significativo y puede
> variar entre ejecuciones. Trátelo como conjunto (contiene / no contiene), nunca por posición.
> `pendientesSinResolver` cuenta solo los pendientes de **cabecera**; los de línea se consultan
> en `/pendientes` o en el detalle de cada línea.

Antes de ofrecer el envío, el consumidor comprueba que `ENVIAR` esté en `accionesDisponibles`:

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036 \
  | jq '.accionesDisponibles | index("ENVIAR") != null'
```


---

## 2. Listar las líneas de la cuenta (paginación keyset)

`cursor` es **opaco**: el cliente lo recibe y lo devuelve tal cual, sin interpretarlo.
Se omite en la primera página. `totalRegistros` solo viene en la primera página
(para no ejecutar un `COUNT` en cada salto) y `cursorSiguiente` en `null` significa última página.

El tamaño de página se normaliza al rango **[1, 25]**: pedir `tamano=200` devuelve 25.

```bash
# Primera página
curl -s "http://localhost:8080/api/v1/cuentas/GT-106586883036/lineas?tamano=2" \
  -H "Accept: application/json"
```

**Respuesta `200 OK`:**

```json
{
  "elementos": [
    {
      "referencia": 90114523,
      "numeroLinea": 1,
      "codigoProcedimiento": "890201",
      "codigoAfiliado": "AF-00483921",
      "valorAutorizado": 320000.00,
      "valorCubierto": 288000.00,
      "editable": true,
      "cantidadPendientes": 0,
      "tieneNovedadBloqueante": false,
      "version": 2
    },
    {
      "referencia": 90114524,
      "numeroLinea": 2,
      "codigoProcedimiento": "903841",
      "codigoAfiliado": "AF-00483921",
      "valorAutorizado": 2300000.00,
      "valorCubierto": 2070000.00,
      "editable": true,
      "cantidadPendientes": 0,
      "tieneNovedadBloqueante": false,
      "version": 3
    }
  ],
  "cursorSiguiente": "90114524",
  "totalRegistros": 400,
  "tamanoPagina": 2
}
```

```bash
# Página siguiente: se reenvía el cursor recibido
curl -s "http://localhost:8080/api/v1/cuentas/GT-106586883036/lineas?tamano=2&cursor=90114524" \
  -H "Accept: application/json"
```

**Respuesta `200 OK`** — ya sin `totalRegistros`:

```json
{
  "elementos": [
    {
      "referencia": 90114525,
      "numeroLinea": 3,
      "codigoProcedimiento": "871121",
      "codigoAfiliado": "AF-00483921",
      "valorAutorizado": 223500.00,
      "valorCubierto": 201150.00,
      "editable": true,
      "cantidadPendientes": 0,
      "tieneNovedadBloqueante": false,
      "version": 4
    },
    {
      "referencia": 90114526,
      "numeroLinea": 4,
      "codigoProcedimiento": "902210",
      "codigoAfiliado": "AF-00483921",
      "valorAutorizado": 38900.00,
      "valorCubierto": 35010.00,
      "editable": true,
      "cantidadPendientes": 0,
      "tieneNovedadBloqueante": false,
      "version": 5
    }
  ],
  "cursorSiguiente": "90114526",
  "totalRegistros": null,
  "tamanoPagina": 2
}
```

La última página llega con menos elementos que `tamanoPagina` y `cursorSiguiente` en `null`.

> **Cuidado con los múltiplos exactos.** `GT-106586883036` tiene 400 líneas: con `tamano=25` las
> 16 páginas vienen llenas, así que la decimosexta todavía trae `cursorSiguiente`. Hace falta una
> petición más, que devuelve `elementos: []` y `cursorSiguiente: null`, para saber que se acabó.
> El corte lo marca **siempre** `cursorSiguiente`, nunca el conteo de elementos.

Recorrido completo de una cuenta encadenando el cursor:

```bash
BASE="http://localhost:8080/api/v1/cuentas"
CUENTA="GT-106586883036"
CURSOR=""

while : ; do
  URL="$BASE/$CUENTA/lineas?tamano=25"
  [ -n "$CURSOR" ] && URL="$URL&cursor=$CURSOR"

  PAGINA=$(curl -s "$URL" -H "Accept: application/json")
  echo "$PAGINA" | jq -c '.elementos[] | {referencia, numeroLinea, valorCubierto}'

  CURSOR=$(echo "$PAGINA" | jq -r '.cursorSiguiente // empty')
  [ -z "$CURSOR" ] && break
done
```


---

## 3. Consultar el detalle de una línea

La línea `90114683` es la que combina novedad bloqueante y pendiente, útil para probar la vista de detalle.

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036/lineas/90114683 \
  -H "Accept: application/json"
```

**Respuesta `200 OK`:**

```json
{
  "referencia": 90114683,
  "codigoCuenta": "GT-106586883036",
  "numeroLinea": 161,
  "fechaInicio": "2026-05-08",
  "fechaFin": "2026-05-08",
  "codigoAfiliado": "AF-00483922",
  "codigoProcedimiento": "993501",
  "valorAutorizado": 124800.00,
  "unidadesAutorizadas": 2,
  "valorCubierto": 0.00,
  "unidadesCubiertas": 0.00,
  "conservarBeneficios": false,
  "conservarTarifacion": false,
  "beneficiosManuales": false,
  "tarifacionManual": false,
  "bloqueada": false,
  "reemplazada": false,
  "editable": true,
  "novedades": [
    {
      "id": 56611,
      "codigo": "AUT-031",
      "descripcion": "La prestación requiere autorización previa y no la tiene",
      "severidad": "BLOQUEANTE",
      "origen": "AUTORIZACION"
    }
  ],
  "pendientes": [
    {
      "identificador": 780161,
      "codigo": "PEN-LIN-TAR",
      "descripcion": "Tarifa de la línea pendiente de revisión",
      "resuelto": false,
      "nivel": "LINEA"
    }
  ],
  "version": 2
}
```

---

## 4. Guardar la edición de una línea

Dos campos son obligatorios y no tienen valor por defecto:

*   **`versionEsperada`** — control de concurrencia optimista. Se toma de la línea consultada.
*   **`modoRecalculo`** — decisión con impacto financiero, siempre explícita:
    *   `EN_CASCADA` propaga tarifación, coberturas y consumo de límites a toda la cuenta.
    *   `AISLADO` aplica solo los campos enviados, sin propagar.

```bash
curl -s -X PATCH http://localhost:8080/api/v1/cuentas/GT-106586883036/lineas/90114523 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{
        "versionEsperada": 2,
        "valorAutorizado": 980000.00,
        "unidadesAutorizadas": 1,
        "conservarBeneficios": true,
        "conservarTarifacion": false,
        "modoRecalculo": "EN_CASCADA"
      }'
```

**Respuesta `200 OK`** — devuelve el detalle recalculado y la **versión nueva**:

```json
{
  "referencia": 90114523,
  "codigoCuenta": "GT-106586883036",
  "numeroLinea": 1,
  "fechaInicio": "2026-05-04",
  "fechaFin": "2026-05-04",
  "codigoAfiliado": "AF-00483921",
  "codigoProcedimiento": "890201",
  "valorAutorizado": 980000.00,
  "unidadesAutorizadas": 1,
  "valorCubierto": 882000.00,
  "unidadesCubiertas": 1,
  "conservarBeneficios": true,
  "conservarTarifacion": false,
  "beneficiosManuales": false,
  "tarifacionManual": false,
  "bloqueada": false,
  "reemplazada": false,
  "editable": true,
  "novedades": [],
  "pendientes": [],
  "version": 3
}
```

En el simulador, `EN_CASCADA` recalcula el cubierto al 90 % del autorizado y retira las novedades
bloqueantes; `AISLADO` deja el cubierto intacto. Eso permite ver la diferencia entre ambos modos
sin depender de OHI.

**Respuesta `412 Precondition Failed`** cuando otro auditor guardó primero
(o cuando se reenvía la misma petición con la versión ya consumida):

```json
{
  "status": 412,
  "estado": 412,
  "codigo": "MODIFICACION_CONCURRENTE",
  "mensaje": "Otro usuario modificó la información. Actualice y vuelva a intentar.",
  "idTraza": "b7c1f0a24e9d4a18",
  "instante": "2026-08-19T14:22:31.884Z"
}
```

El manejo esperado ante un `412` es releer el recurso y reintentar **una** vez con la versión vigente:

```bash
BASE="http://localhost:8080/api/v1/cuentas"
CUENTA="GT-106586883036"

# 1) Releer la línea para conocer la versión actual
VERSION=$(curl -s "$BASE/$CUENTA/lineas/90114523" | jq '.version')

# 2) Reintentar el PATCH con esa versión
curl -s -X PATCH "$BASE/$CUENTA/lineas/90114523" \
  -H "Content-Type: application/json" \
  -H "X-Auditor: cmedina" \
  -d "{\"versionEsperada\":$VERSION,\"valorAutorizado\":980000.00,\"modoRecalculo\":\"EN_CASCADA\"}"
```

No conviene reintentar más de una vez de forma automática: si el `412` se repite, hay edición
concurrente real y el auditor debe ver los datos actualizados antes de decidir.


Editar `90114611` (reemplazada) o `90114619` (bloqueada) devuelve `422 LINEA_NO_EDITABLE`.

---

## 5. Listar los pendientes sin resolver

Devuelve primero los de cabecera y luego los de línea, en orden de referencia.

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036/pendientes \
  -H "Accept: application/json"
```

**Respuesta `200 OK`** (los primeros 3 de 19):

```json
[
  {
    "identificador": 77001,
    "codigo": "PEN-COB",
    "descripcion": "Requiere validación de cobertura por auditoría médica",
    "resuelto": false,
    "soloAdjudicacion": false,
    "nivel": "CABECERA",
    "referenciaLinea": null,
    "version": 1
  },
  {
    "identificador": 77002,
    "codigo": "PEN-DOC",
    "descripcion": "Soporte documental incompleto en la cuenta",
    "resuelto": false,
    "soloAdjudicacion": true,
    "nivel": "CABECERA",
    "referenciaLinea": null,
    "version": 1
  },
  {
    "identificador": 780023,
    "codigo": "PEN-LIN-TAR",
    "descripcion": "Tarifa de la línea pendiente de revisión",
    "resuelto": false,
    "soloAdjudicacion": false,
    "nivel": "LINEA",
    "referenciaLinea": 90114545,
    "version": 1
  }
]
```

`referenciaLinea` viene en `null` cuando `nivel` es `CABECERA`. Un pendiente con
`soloAdjudicacion: true` bloquea el envío **únicamente** si la cuenta está en `ADJUDICACION_MANUAL`.

---

## 6. Resolver un pendiente

La `justificacion` es obligatoria (máx. 2000 caracteres) y queda como nota de auditoría.
El `alcance` define el radio de la resolución:

*   `CUENTA_Y_LINEAS` — resuelve el motivo en la cabecera y en todas las líneas.
*   `SOLO_LINEAS` — resuelve el motivo solo en las líneas.

```bash
curl -s -i -X POST \
  http://localhost:8080/api/v1/cuentas/GT-106586883036/pendientes/77001/resolver \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{
        "justificacion": "Cobertura validada contra el plan vigente del afiliado. Soporte adjunto en el caso SD-48120.",
        "alcance": "CUENTA_Y_LINEAS"
      }'
```

**Respuesta `204 No Content`** — sin cuerpo:

```http
HTTP/1.1 204 No Content
```

La operación es **todo o nada**: si la resolución falla, la nota de justificación no se registra.
Reintentar el mismo identificador cuando ya está resuelto devuelve `400`, no `204`: el pendiente
ya no existe entre los no resueltos.

**Respuesta `409 Conflict`** si la acción no está habilitada para el estado actual
(por ejemplo sobre `GT-106586883044`, que está en `TARIFACION_COMPLETA`):

```json
{
  "status": 409,
  "estado": 409,
  "codigo": "ACCION_NO_DISPONIBLE",
  "mensaje": "La cuenta no permite la acción RESOLVER_PENDIENTE en su estado actual",
  "idTraza": "3f9ad2c58e0b47aa",
  "instante": "2026-08-19T14:30:02.117Z"
}
```

---

## 7. Enviar la cuenta

El envío en OHI es **asíncrono**: el servicio responde `202 Accepted` con un tiquete de seguimiento,
no con el resultado final.

*   `decision`: `ACEPTAR` o `DENEGAR`.
*   `codigoNovedad`: opcional al aceptar (deja la novedad asociada), obligatorio al denegar.

```bash
curl -s -X POST http://localhost:8080/api/v1/cuentas/GT-106586883037/enviar \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{ "decision": "ACEPTAR", "codigoNovedad": null }'
```

**Respuesta `202 Accepted`:**

```json
{
  "codigoCuenta": "GT-106586883037",
  "referenciaSeguimiento": "PROC-2026-0819-000178"
}
```

Denegar con novedad:

```bash
curl -s -X POST http://localhost:8080/api/v1/cuentas/GT-106586883037/enviar \
  -H "Content-Type: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{ "decision": "DENEGAR", "codigoNovedad": "COB-114" }'
```

**Respuesta `409 Conflict`** si aún hay pendientes que bloquean
(es lo que devuelve `GT-106586883036` mientras no se resuelvan sus 19 pendientes):

```json
{
  "status": 409,
  "estado": 409,
  "codigo": "PENDIENTES_SIN_RESOLVER",
  "mensaje": "19 pendiente(s) impiden enviar la cuenta",
  "idTraza": "a04e7d13bb2c4f60",
  "instante": "2026-08-19T14:31:44.502Z"
}
```

---

## 8. Consultar el estado del proceso (sondeo puntual)

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883037/proceso \
  -H "Accept: application/json"
```

**Respuesta `200 OK` — antes de enviar:**

```json
{
  "avance": "NO_INICIADO",
  "finalizado": false,
  "errores": []
}
```

**Respuesta `200 OK` — en curso:**

```json
{
  "avance": "EN_PROCESO",
  "finalizado": false,
  "errores": []
}
```

**Respuesta `200 OK` — terminado con error** (`GT-106586883043`):

```json
{
  "avance": "FALLIDO",
  "finalizado": true,
  "errores": [
    "La línea quedó bloqueada durante la adjudicación",
    "No fue posible recalcular el consumo de límites del afiliado"
  ]
}
```

Valores de `avance`: `NO_INICIADO`, `EN_PROCESO`, `EXITOSO`, `FALLIDO`.

---

## 9. Seguir el proceso en streaming (Server-Sent Events)

En vez de sondear, el cliente puede suscribirse al flujo. Requiere
`Accept: text/event-stream`. El flujo emite solo cuando el `avance` cambia y termina
cuando el proceso finaliza o vence la espera máxima.

```bash
curl -N -s http://localhost:8080/api/v1/cuentas/GT-106586883037/proceso/flujo \
  -H "Accept: text/event-stream"
```

**Respuesta `200 OK`** — eventos emitidos hasta finalizar:

```
data:{"avance":"EN_PROCESO","finalizado":false,"errores":[]}

data:{"avance":"EXITOSO","finalizado":true,"errores":[]}
```

El flujo se cierra solo: emite un evento por cada cambio de `avance` y termina cuando llega
`"finalizado": true` o cuando vence `auditoria.proceso.maxima-espera`. El cliente no necesita
sondear ni cerrar la conexión por su cuenta; basta con leer hasta el fin del flujo.

Cualquier cliente de SSE sirve. Para dejar el último estado en una variable:

```bash
curl -N -s http://localhost:8080/api/v1/cuentas/GT-106586883037/proceso/flujo \
  -H "Accept: text/event-stream" \
  | sed -u 's/^data://' \
  | jq -c 'select(.finalizado == true)' \
  | head -1
```


---

## 10. Formato de error

Todos los errores usan la misma estructura, traducida desde los errores de dominio. La respuesta
es **siempre `application/json`**, sin importar el `Accept` de la solicitud: abrir una ruta errada
en un navegador devuelve este mismo cuerpo, no una página HTML.

```json
{
  "status": 404,
  "estado": 404,
  "codigo": "CUENTA_NO_ENCONTRADA",
  "mensaje": "No existe la cuenta médica GT-000000000000",
  "idTraza": "9c2e51f7a0d84b33",
  "instante": "2026-08-19T14:18:07.301Z"
}
```

`status` y `estado` siempre llevan el mismo valor: `status` existe porque es la clave que lee
Spring para fijar el código HTTP de la respuesta, y `estado` mantiene el vocabulario en español.
`idTraza` es la clave para correlacionar el error con los logs del servicio — inclúyala siempre al
reportar incidentes; vale `-` cuando no hay traza activa.

| HTTP | `codigo` | Cuándo ocurre | ¿Reproducible en `local`? |
| --- | --- | --- | --- |
| `400` | `SOLICITUD_INVALIDA` | Cuerpo ausente o campos que no pasan validación | Sí |
| `400` | `DECISION_INVALIDA` | Decisión de envío incoherente, o pendiente inexistente | Sí |
| `403` | `SIN_PERMISO` | El auditor no tiene permiso sobre la operación | No |
| `403` | `LIMITE_APROBACION_EXCEDIDO` | El valor cubierto supera el límite de aprobación del auditor | No |
| `404` | `CUENTA_NO_ENCONTRADA` | El código de cuenta no existe | Sí |
| `404` | `LINEA_NO_ENCONTRADA` | La referencia de línea no existe en la cuenta | Sí |
| `409` | `ACCION_NO_DISPONIBLE` | La acción no está habilitada en el estado actual | Sí (cuentas `…044` y `…045`) |
| `409` | `PENDIENTES_SIN_RESOLVER` | Hay pendientes que bloquean el envío | Sí (cuenta `…036`) |
| `412` | `MODIFICACION_CONCURRENTE` | La `versionEsperada` quedó obsoleta | Sí |
| `422` | `LINEA_NO_EDITABLE` | La línea está bloqueada o reemplazada | Sí (líneas `90114611`, `90114619`) |
| `422` | `SIN_CAMBIOS` | La edición no contiene modificaciones | Sí |
| `404` | `RUTA_NO_ENCONTRADA` | La ruta no corresponde a ninguna operación del API | Sí |
| `405` | `METODO_NO_PERMITIDO` | Método HTTP no permitido para la ruta | Sí |
| `406` | `FORMATO_NO_ACEPTABLE` | El `Accept` no admite `application/json` | Sí |
| `415` | `MEDIO_NO_SOPORTADO` | El cuerpo no se envió como `application/json` | Sí |
| `503` | `SISTEMA_REGISTRO_NO_DISPONIBLE` | OHI no responde (circuit breaker abierto) | No |

Ejemplo de `400` por validación:

```json
{
  "status": 400,
  "estado": 400,
  "codigo": "SOLICITUD_INVALIDA",
  "mensaje": "modoRecalculo: El modo de recálculo debe ser EN_CASCADA o AISLADO; versionEsperada: La versión esperada es obligatoria",
  "idTraza": "1d7b60c9f2a34e85",
  "instante": "2026-08-19T14:25:53.009Z"
}
```

---

## 11. Flujo completo de auditoría (script de ejemplo)

Secuencia típica: consultar → revisar líneas → editar → resolver pendientes → enviar → seguir.
Este script corre tal cual contra el perfil `local`.

```bash
#!/usr/bin/env bash
set -euo pipefail

BASE="http://localhost:8080/api/v1/cuentas"
CUENTA="GT-106586883037"     # la cuenta sin pendientes: camino feliz
AUDITOR="cmedina"

# 1. Cabecera y acciones disponibles
curl -s "$BASE/$CUENTA" | jq '{estado, pendientesSinResolver, accionesDisponibles}'

# 2. Buscar líneas con novedad bloqueante en la primera página
curl -s "$BASE/$CUENTA/lineas?tamano=25" | jq '.elementos[] | select(.tieneNovedadBloqueante)'

# 3. Editar la primera línea (referencia 91114523, versión vigente 2)
curl -s -X PATCH "$BASE/$CUENTA/lineas/91114523" \
  -H "Content-Type: application/json" -H "X-Auditor: $AUDITOR" \
  -d '{"versionEsperada":2,"valorAutorizado":980000.00,"modoRecalculo":"EN_CASCADA"}' \
  | jq '{version, valorCubierto}'

# 4. Enviar
curl -s -X POST "$BASE/$CUENTA/enviar" \
  -H "Content-Type: application/json" -H "X-Auditor: $AUDITOR" \
  -d '{"decision":"ACEPTAR"}' | jq .

# 5. Seguir el proceso hasta que finalice (unos 6 segundos)
curl -N -s "$BASE/$CUENTA/proceso/flujo" -H "Accept: text/event-stream"
```

**Salida esperada:**

```text
{
  "estado": "MODIFICACION",
  "pendientesSinResolver": 0,
  "accionesDisponibles": ["ENVIAR","SEGUIR_PROCESO","RESOLVER_PENDIENTE","RESOLVER_PENDIENTE_LINEA","DEVOLVER_A_MODIFICACION","DESBLOQUEAR_LINEAS","DESHACER_REEMPLAZOS"]
}
{ "referencia": 91114529, "numeroLinea": 7, "tieneNovedadBloqueante": true, ... }
{ "version": 3, "valorCubierto": 882000.00 }
{ "codigoCuenta": "GT-106586883037", "referenciaSeguimiento": "PROC-2026-0819-000179" }
data:{"avance":"EN_PROCESO","finalizado":false,"errores":[]}
data:{"avance":"EXITOSO","finalizado":true,"errores":[]}
```

> Ojo con las referencias: son distintas por cuenta. Las de `GT-106586883037` (índice 1) empiezan
> en `91114523`, no en `90114523`. La fórmula está en la sección «Perfil local».

---

## 12. Cliente Java reactivo (WebClient)

Ejemplo de consumo desde otro microservicio Spring, sin bloqueos. Los DTO de respuesta del
enrutador son de alcance de paquete, así que un consumidor externo declara los suyos con la
misma forma:

```java
var cliente = WebClient.builder()
        .baseUrl("http://localhost:8080/api/v1/cuentas")
        .build();

// Consultar cabecera
Mono<RespuestaCuenta> cuenta = cliente.get()
        .uri("/{codigo}", "GT-106586883036")
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(RespuestaCuenta.class);

// Guardar línea con control de versión
Mono<RespuestaDetalleLinea> guardada = cliente.patch()
        .uri("/{codigo}/lineas/{referencia}", "GT-106586883036", 90114523L)
        .header("X-Auditor", "cmedina")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(new SolicitudGuardarLinea(
                2L,                            // versionEsperada
                new BigDecimal("980000.00"),   // valorAutorizado
                BigDecimal.ONE,                // unidadesAutorizadas
                true,                          // conservarBeneficios
                false,                         // conservarTarifacion
                "EN_CASCADA"))                 // modoRecalculo (obligatorio)
        .retrieve()
        .bodyToMono(RespuestaDetalleLinea.class);

// Seguir el proceso como flujo SSE
Flux<RespuestaEstadoProceso> proceso = cliente.get()
        .uri("/{codigo}/proceso/flujo", "GT-106586883037")
        .accept(MediaType.TEXT_EVENT_STREAM)
        .retrieve()
        .bodyToFlux(RespuestaEstadoProceso.class)
        .takeUntil(RespuestaEstadoProceso::finalizado);
```

---

## 13. Recomendaciones para el cliente

1.  **Habilitar las operaciones con `accionesDisponibles`**, nunca deduciendo permisos a partir de `estado`.
    El estado es informativo; las transiciones válidas las declara el sistema de registro.
    Trátelo como conjunto: el orden del arreglo no es estable.
2.  **Propagar siempre `X-Auditor`** en las escrituras: sin él la traza de auditoría queda incompleta.
3.  **Guardar la `version`** de cada línea que se muestre en pantalla y enviarla como `versionEsperada`.
4.  **Tratar el `cursor` como opaco**: no derivar de él el número de página ni el total.
5.  **No asumir resultado inmediato del envío**: tras el `202` hay que seguir el proceso por `/proceso` o `/proceso/flujo`.
6.  **Declarar siempre `modoRecalculo`**: no existe valor por defecto porque la decisión tiene impacto financiero.
7.  **Reintentar el `503`** con backoff — el circuit breaker hacia OHI se recupera solo; no reintentar `409`, `412` ni `422` sin releer el recurso.
8.  **Desarrollar contra el perfil `local`** y validar contra `dev` antes de integrar: el contrato es el mismo,
    pero `local` no reproduce errores de permisos ni de disponibilidad de OHI.

---

## Patrones y Prácticas Implementadas

*   **Arquitectura Hexagonal:** Clara separación por módulos de Gradle.
*   **Domain-Driven Design (DDD):** Vocabulario en español en todo el dominio (Lenguaje Ubicuo).
*   **Anti-Corruption Layer (ACL):** Traducción del inglés (OHI) al español (Dominio Sura) concentrado en un solo adaptador.
*   **Adaptadores intercambiables por perfil:** El simulador local y la ACL de OHI implementan los mismos puertos; se conmutan con `@Profile` sin tocar dominio ni API.
*   **CQRS:** Separación de comandos y consultas, puertos específicos.
*   **Trazabilidad asíncrona:** Eventos persistidos vía R2DBC y publicados por un Bus para auditar sin tumbar flujos.
*   **Resiliencia:** Uso de Resilience4J (Circuit Breaker y Retry) configurado para integraciones inestables.
*   **Enrutador Funcional:** Uso de Router Functions de Spring WebFlux en vez de @RestController para adherirse al manifiesto reactivo.
*   **Paginación Keyset:** Para alto rendimiento en listas de líneas de facturas de OHI.
