# ms-auditoria-cuenta-medica

Microservicio que implementa la Auditoría de Cuentas Médicas actuando como una Anti-Corruption Layer (ACL) frente a Oracle Health Insurance (OHI).

> **Lo que hay que construir está especificado, y se trabaja por requisito.** La especificación del
> MVP del módulo de cuentas médicas —196 requisitos con identificador, estado y criterios de
> aceptación— vive en
> [`agents/ecosistema-auditoria/especificacion/mvp-cuentas-medicas.yaml`](../agents/ecosistema-auditoria/especificacion/mvp-cuentas-medicas.yaml).
> El ciclo (cómo se cita un requisito desde una prueba, qué comprueba el gate) está en
> [`contexto/09-sdd.md`](../agents/ecosistema-auditoria/contexto/09-sdd.md).
>
> En corto: cada prueba cita el requisito que comprueba —`@Tag("F3-ORD-01")` en JUnit,
> `it('[F3-ORD-01] …')` en vitest— y antes de dar algo por terminado:
>
> ```bash
> python3 ../agents/ecosistema-auditoria/especificacion/trazabilidad.py
> ```

> **El sistema del otro lado de la ACL está documentado en
> [`docs/ohi/`](docs/ohi/README.md)**: el modelo de datos de OHI producción, sus
> integraciones, cómo se consulta sin equivocarse y cómo se opera. Si vas a
> tocar `infraestructura-acl-ohi`, empieza por
> [02 — API y lenguaje de consulta](docs/ohi/02-api-y-lenguaje-de-consulta.md).

## Arquitectura

El servicio sigue estrictamente los lineamientos de **DDD (Domain-Driven Design)** y **Arquitectura Hexagonal**.

### Módulos

*   **dominio-modelo:** Entidades puras, objetos de valor y puertos (sin dependencias de frameworks externos excepto Project Reactor para firmas reactivas).
*   **dominio-casos-de-uso:** Lógica orquestadora del dominio.
*   **infraestructura-web-reactiva:** Adaptadores de entrada REST (WebFlux, Router functions).
*   **infraestructura-acl-ohi:** Capa anticorrupción hacia OHI. Traduce de OHI a dominio. Activa en `dev`, `lab` y `prod`.
*   **infraestructura-r2dbc-trazabilidad:** Persistencia reactiva en base de datos.
*   **infraestructura-bus-eventos:** Publicador de eventos en cola (Spring Cloud Stream).
*   **aplicacion-servicio-app:** Bootstrap, dependencias, migración y configuración (Spring Boot 3).

## Prerrequisitos

*   Java 21
*   Docker y Docker Compose (solo para los perfiles que usan base de datos y bus de eventos)

---

# Ejecución por perfil

| Perfil | Origen de los datos | Infraestructura que necesita |
| --- | --- | --- |
| `dev` | OHI real de desarrollo | MySQL, RabbitMQ, credenciales OHI |
| `lab` | OHI real de laboratorio | MySQL, RabbitMQ, credenciales OHI |
| `prod` | OHI real de producción | MySQL, RabbitMQ, credenciales OHI |

## Perfiles `dev`, `lab` y `prod` — integración real con OHI

1.  Levantar infraestructura local (solo si se corre contra una base y un bus locales):
    ```bash
    docker-compose up -d db rabbitmq
    ```
2.  Exportar las credenciales del perfil (ver `application.yml`): `OHI_URL_BASE_*`, `OHI_TOKEN_URL_*`,
    `OHI_CLIENT_ID_*`, `OHI_CLIENT_SECRET_*` y las variables `DB_*`.
3.  Ejecutar el servicio:
    ```bash
    ./gradlew :aplicacion-servicio-app:bootRun --args='--spring.profiles.active=dev'
    ```

# Consumo del API desde un cliente

> Los cuerpos de respuesta de esta sección son **ilustrativos**: no corresponden a información real
> de cuentas médicas ni de afiliados. Describen la **forma** del contrato —nombres de campo, tipos y
> códigos de estado—, no datos que se puedan reproducir tal cual contra un entorno concreto.

## Convenciones generales

| Aspecto | Valor |
| --- | --- |
| URL base local | `http://localhost:8080` |
| Prefijo del recurso | `/api/v1/cuentas` |
| Content-Type | `application/json` (excepto el flujo SSE: `text/event-stream`) |
| Header de autoría | `X-Auditor` — usuario que origina el cambio; se registra en la traza de auditoría |
| Identificador de negocio | `codigo` de cuenta, tal como lo ve el auditor (ej. `GT-106586883036`) |
| Concurrencia | Las escrituras sobre líneas exigen `versionEsperada`; si otro usuario modificó la línea el servicio responde `412` |

### Endpoints disponibles

| Método | Ruta | Descripción | Éxito |
| --- | --- | --- | --- |
| `GET` | `/api/v1/cuentas/{codigo}` | Cabecera de la cuenta | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/acciones` | Acciones que OHI publica para la cuenta | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/lineas` | Listado paginado (keyset) de líneas | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/lineas/{referencia}` | Detalle de una línea | `200` |
| `PATCH` | `/api/v1/cuentas/{codigo}/lineas/{referencia}` | Guardar edición de línea | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/pendientes` | Pendientes sin resolver | `200` |
| `POST` | `/api/v1/cuentas/{codigo}/pendientes/{motivo}/resolver` | Resolver un motivo pendiente | `204` |
| `POST` | `/api/v1/cuentas/{codigo}/enviar` | Enviar la cuenta (asíncrono) | `202` |
| `GET` | `/api/v1/cuentas/{codigo}/proceso` | Estado puntual del envío | `200` |
| `GET` | `/api/v1/cuentas/{codigo}/proceso/flujo` | Estado del envío en streaming (SSE) | `200` |

> **No existe un listado de cuentas.** `/api/v1/cuentas` sin código devuelve `404 RUTA_NO_ENCONTRADA`:
> siempre se consulta una cuenta por su código de negocio. Los 10 códigos del perfil local están en
> la sección «Perfil local» y también se imprimen en el log al arrancar.

---

## 1. Consultar la cabecera de una cuenta

El consumidor **no debe deducir qué puede hacer el auditor a partir del estado**: debe habilitar
cada operación según lo que venga en `accionesDisponibles` (contrato HATEOAS traducido por la ACL),
que se pide aparte a `GET /{codigo}/acciones`. Hay dos salvedades, por regla de negocio del
2026-10-21: el **envío** y **«Pasar a Modificación»**, cuyo rótulo, visibilidad y acción salen del
estado (ver el final de esta sección).

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036 \
  -H "Accept: application/json"
```

**Respuesta `200 OK`:**

```json
{
  "codigo": "GT-106586883036",
  "estado": "ADJUDICACION_MANUAL",
  "admiteCambios": false,
  "fechaInicio": "2026-05-04",
  "fechaFin": "2026-05-09",
  "totalConvenido": 328298700.00,
  "totalAutorizado": 247907070.00,
  "version": 1,
  "pendientesSinResolver": 2
}
```

> **Qué es cada importe** (decisión de negocio del 2026-10-21; la misma tabla vale para la línea,
> la grilla, el detalle, la foto de versión y la línea de versión):
>
> | Importe | Cabecera (`claims`) | Línea (`claimlines` / `ctrclaimlines`) | JSON del API |
> | --- | --- | --- | --- |
> | Valor convenido | `totalAllowedAmount` | `allowedAmount`, `allowedNumberOfUnits` | `totalConvenido`; `valorConvenido`, `unidadesConvenidas` |
> | Valor cargado | `totalClaimedAmount` | `claimedAmount`, `claimedNumberOfUnits` | `informacionFacturacion.totalCargado`; `valorCargado`, `unidadesCargadas` |
> | Valor autorizado | `totalCoveredAmount` | `coveredAmount`, `coveredNumberOfUnits` | `totalAutorizado`; `valorAutorizado`, `unidadesAutorizadas` |
> | Valor glosado | `totalValorGlosado` | `valorGlosado` | `informacionFacturacion.totalValorGlosado`; `valorGlosado` |
>
> Hasta esa fecha el API tenía los nombres invertidos: llamaba `totalAutorizado`/`valorAutorizado`
> al convenido (`allowed*`) y `totalCubierto`/`valorCubierto` al autorizado (`covered*`).
> **`totalAutorizado`, `valorAutorizado` y `unidadesAutorizadas` cambiaron de significado**: un
> cliente anterior a ese día pinta cifras cruzadas, no un error. `informacionFacturacion.totalConvenido`
> (que iba siempre en `null`) se quitó: el total convenido vive solo en la raíz. El importe de la
> cláusula de contrato, que en el detalle se llamaba `convenio.valorConvenido`, es ahora
> `convenio.valorTarifaContrato`: es la tarifa antes de los ajustes de regla, no el convenido.
> Un importe o una cantidad que OHI no trae viaja como `null`, no como `0` (una línea negada no
> tiene convenido; su autorizado sí llega, en `0`).

Las acciones no vienen en la cabecera: OHI solo publica sus enlaces en la representación completa
de la cuenta, mucho más lenta, y se piden aparte para no retrasar la pantalla:

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036/acciones \
  -H "Accept: application/json"
```

**Respuesta `200 OK`** (lo que OHI publica para una cuenta en `ADJUDICACION_MANUAL` con pendientes
abiertos):

```json
{
  "codigo": "GT-106586883036",
  "accionesDisponibles": [
    "ANULAR",
    "DEVOLVER_A_BENEFICIOS_MANUALES",
    "DEVOLVER_A_MODIFICACION",
    "DEVOLVER_A_TARIFACION_MANUAL",
    "ENVIAR",
    "RESOLVER_PENDIENTE"
  ]
}
```

> `accionesDisponibles` es un **conjunto**: el orden de los elementos no es significativo y puede
> variar entre ejecuciones. Trátelo como conjunto (contiene / no contiene), nunca por posición.
> `pendientesSinResolver` cuenta solo los pendientes de **cabecera**; los de línea se consultan
> en `/pendientes` o en el detalle de cada línea.

> **`admiteCambios`** (regla de negocio del 2026-10-21): los datos de la cuenta —valores, glosas y
> novedades de las líneas, el lote, las novedades de cabecera y los motivos de pendiente que se
> añaden— **solo se cambian con la cuenta en `MODIFICACION`**. El servicio publica la regla ya
> calculada en `admiteCambios` (también en la respuesta de `PATCH /{codigo}/novedades` y de
> `POST /{codigo}/acciones/{accion}`) y la hace cumplir: fuera de ese estado esas escrituras
> responden `409 CUENTA_NO_MODIFICABLE` sin llegar a OHI, que no la impone. Para editar, primero
> se pasa la cuenta a Modificación (`DEVOLVER_A_MODIFICACION`, o `REVERTIR_FINALIZACION` si está
> finalizada). Resolver pendientes, enviar y las demás acciones de estado **no** dependen de
> `admiteCambios`: las acciones las siguen gobernando los enlaces de OHI, y el envío tiene su
> propia regla (abajo). `editable` de cada línea sigue siendo de la línea (bloqueada o
> reemplazada); la pantalla compone los dos.

> **El envío no se apaga** (regla de negocio del 2026-10-21, BTN-13): el consumidor lo ofrece y lo
> deja pulsar en todo estado salvo `FINALIZADA`, **sin mirar** si `ENVIAR` está en
> `accionesDisponibles` ni si quedan pendientes. Se rotula «Aceptar» en `ADJUDICACION_MANUAL` y
> «Enviar» en el resto; por debajo es el mismo `POST /{codigo}/enviar`. Si OHI no lo permite, el
> servicio responde `409 ACCION_NO_DISPONIBLE` (OHI no publica `claim:submit` en ese estado) o
> `409 PENDIENTES_SIN_RESOLVER` (aceptar con pendientes que frenan la cuenta), la cuenta no cambia
> y la pantalla muestra `mensaje` tal cual. Lo que antes apagaba el botón se dice, como aviso, en el
> diálogo de confirmación.
>
> **«Pasar a Modificación»** (EST-02) se ofrece cuando el estado no es `MODIFICACION`, y la acción
> que ejecuta también sale del estado: `REVERTIR_FINALIZACION` en `FINALIZADA` (pide el motivo de
> la desfinalización y deja la cuenta directamente en `MODIFICACION`) y `DEVOLVER_A_MODIFICACION`
> en el resto. Solo se habilita si esa acción está en `accionesDisponibles` (si la consulta de
> acciones falla, se deja pulsar y decide el servicio). OHI publica `claim:unfinalize` en
> `FINALIZADA` y `claim:tochange` únicamente en `ADJUDICACION_MANUAL`, `TARIFACION_MANUAL` y
> `BENEFICIOS_MANUALES`: en los demás estados el botón se muestra apagado con su motivo, y en
> `MODIFICACION` no se ofrece.


---

## 2. Listar las líneas de la cuenta (paginación por desplazamiento)

Las líneas se piden por **posición**, no por cursor: `pagina` cuenta desde cero y el servicio la
traduce a desplazamiento multiplicando por `tamano`. También se admite `desplazamiento`, que es la
posición exacta y manda sobre `pagina` si llegan los dos.

El tamaño de página se normaliza al rango **[1, 25]**: pedir `tamano=200` devuelve 25. El
desplazamiento **no** se recorta: el tope de 200 del sistema de registro es del tamaño de página,
no de la posición, y comprobado contra producción `offset=4025` sobre una cuenta de 4.063 líneas
devuelve sus filas sin problema.

El orden es el **número de línea**, que es el que lee el auditor. No es el identificador: en la
cuenta mayor de producción, las cinco primeras filas por identificador son las líneas 2106, 2477,
2805, 2143 y 2681.

Tres campos de la respuesta deciden cómo se pinta el paginador:

| Campo | Qué dice |
|---|---|
| `totalRegistros` | Cuántas líneas hay. **`null` cuando no es de fiar** (ver abajo) |
| `totalPaginas` | Cuántas páginas hay, o `null` si no hay total |
| `hayMas` | Si queda algo después de esta página. **Siempre fiable**, también sin total |

`totalRegistros` llega a `null` a propósito cuando el filtro incluye `catalogo`, `glosaDesde` o
`glosaHasta`: el sistema de registro no sabe filtrar por esos campos, así que su cuenta sería de
las filas de antes de descartar y el paginador ofrecería páginas que no existen. En ese régimen se
navega con `hayMas`.

```bash
# Primera página
curl -s "http://localhost:8080/api/v1/cuentas/CM-55181980659/lineas?pagina=0&tamano=25" \
  -H "Accept: application/json" | jq '{n: (.elementos|length), desplazamiento, pagina,
                                       totalRegistros, totalPaginas, hayMas}'
```

```json
{
  "n": 25,
  "desplazamiento": 0,
  "pagina": 0,
  "totalRegistros": 4063,
  "totalPaginas": 163,
  "hayMas": true
}
```

```bash
# La última página: una sola petición, no 162 encadenadas
curl -s "http://localhost:8080/api/v1/cuentas/CM-55181980659/lineas?pagina=162&tamano=25" \
  -H "Accept: application/json" | jq '{n: (.elementos|length), desplazamiento, hayMas}'
```

```json
{ "n": 13, "desplazamiento": 4050, "hayMas": false }
```

> **Una posición pasada del final no dice que la cuenta esté vacía.** El sistema de registro
> responde `204` sin cuerpo, así que no manda total ni `hasMore`. El servicio lo detecta y
> pregunta el total aparte: la respuesta llega con `elementos: []` **y** con `totalRegistros` y
> `totalPaginas` verdaderos, para que la pantalla pueda decir «estás más allá del final» en vez de
> «no hay líneas».

Recorrido completo de una cuenta por desplazamiento:

```bash
BASE="http://localhost:8080/api/v1/cuentas"
CUENTA="CM-55181980659"
PAGINA=0

while : ; do
  RESP=$(curl -s "$BASE/$CUENTA/lineas?pagina=$PAGINA&tamano=25" -H "Accept: application/json")
  echo "$RESP" | jq -c '.elementos[] | {referencia, numeroLinea, valorConvenido, valorAutorizado}'

  [ "$(echo "$RESP" | jq -r '.hayMas')" = "true" ] || break
  PAGINA=$((PAGINA + 1))
done
```

### La línea siguiente

`GET /api/v1/cuentas/{codigo}/lineas/{referencia}/siguiente` devuelve la línea de número
inmediatamente mayor, que es lo que sostiene «guardar y pasar a la siguiente». Responde **204**
cuando esa era la última: es una respuesta, no un error.

Existe porque antes lo resolvía el cliente aprovechando el recorrido por clave —pedía una página
de una fila usando la referencia actual como cursor— y eso daba la siguiente **por
identificador**, así que el avance saltaba a una línea cualquiera de la cuenta.

> Los **pendientes** siguen paginando por clave (`cursor` / `cursorSiguiente`). Su listado son dos
> recursos de OHI concatenados y un desplazamiento suyo es por recurso, así que no se puede
> trasladar sin más; ver `AdaptadorPendientesOhi`.

---

## 3. Consultar el detalle de una línea

La línea `90114683` es la que combina novedad bloqueante y pendiente, útil para probar la vista de detalle.

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036/lineas/90114683 \
  -H "Accept: application/json"
```

**Respuesta `200 OK`:**

```json
{
  "referencia": 90114683,
  "codigoCuenta": "GT-106586883036",
  "numeroLinea": 161,
  "fechaInicio": "2026-05-08",
  "fechaFin": "2026-05-08",
  "codigoAfiliado": "AF-00483922",
  "codigoProcedimiento": "993501",
  "valorConvenido": 124800.00,
  "unidadesConvenidas": 2,
  "valorAutorizado": 0.00,
  "unidadesAutorizadas": 0.00,
  "conservarBeneficios": false,
  "conservarTarifacion": false,
  "beneficiosManuales": false,
  "tarifacionManual": false,
  "bloqueada": false,
  "reemplazada": false,
  "editable": true,
  "novedades": [
    {
      "id": 56611,
      "codigo": "AUT-031",
      "descripcion": "La prestación requiere autorización previa y no la tiene",
      "severidad": "BLOQUEANTE",
      "origen": "AUTORIZACION"
    }
  ],
  "pendientes": [
    {
      "identificador": 780161,
      "codigo": "PEN-LIN-TAR",
      "descripcion": "Tarifa de la línea pendiente de revisión",
      "resuelto": false,
      "nivel": "LINEA"
    }
  ],
  "version": 2
}
```

---

## 4. Guardar la edición de una línea

La cuenta tiene que estar en `MODIFICACION` (`admiteCambios: true`, ver la sección 1). La del
ejemplo, `GT-106586883036`, está en `ADJUDICACION_MANUAL`: antes de editar hay que pasarla con
`POST /api/v1/cuentas/GT-106586883036/acciones/DEVOLVER_A_MODIFICACION`.

Dos campos son obligatorios y no tienen valor por defecto:

*   **`versionEsperada`** — control de concurrencia optimista. Se toma de la línea consultada.
*   **`modoRecalculo`** — decisión con impacto financiero, siempre explícita:
    *   `EN_CASCADA` propaga tarifación, coberturas y consumo de límites a toda la cuenta.
    *   `AISLADO` aplica solo los campos enviados, sin propagar.

```bash
curl -s -X PATCH http://localhost:8080/api/v1/cuentas/GT-106586883036/lineas/90114523 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{
        "versionEsperada": 2,
        "valorConvenido": 980000.00,
        "unidadesConvenidas": 1,
        "conservarBeneficios": true,
        "conservarTarifacion": false,
        "modoRecalculo": "EN_CASCADA"
      }'
```

**Respuesta `200 OK`** — devuelve el detalle recalculado y la **versión nueva**:

```json
{
  "referencia": 90114523,
  "codigoCuenta": "GT-106586883036",
  "numeroLinea": 1,
  "fechaInicio": "2026-05-04",
  "fechaFin": "2026-05-04",
  "codigoAfiliado": "AF-00483921",
  "codigoProcedimiento": "890201",
  "valorConvenido": 980000.00,
  "unidadesConvenidas": 1,
  "valorAutorizado": 882000.00,
  "unidadesAutorizadas": 1,
  "conservarBeneficios": true,
  "conservarTarifacion": false,
  "beneficiosManuales": false,
  "tarifacionManual": false,
  "bloqueada": false,
  "reemplazada": false,
  "editable": true,
  "novedades": [],
  "pendientes": [],
  "version": 3
}
```

Lo que se escribe es el **convenido**: `valorConvenido` y `unidadesConvenidas` van a `allowedAmount`
y `allowedNumberOfUnits` de OHI. El **autorizado** (`coveredAmount`) no se escribe: lo calcula el
motor de coberturas al recalcular, y el contrato de escritura de OHI no lo acepta.

**Respuesta `400 SOLICITUD_INVALIDA`** si el cuerpo trae `valorAutorizado`, `unidadesAutorizadas`,
`valorCubierto` o `unidadesCubiertas`, aunque sea en `null`. Hasta el 2026-10-21 el convenido se
enviaba como `valorAutorizado`; ese nombre pasó a significar el autorizado, y un PATCH que lo trae
se rechaza entero con un mensaje que dice cuál es el campo editable, en vez de ignorarlo en silencio:

```json
{
  "status": 400,
  "estado": 400,
  "codigo": "SOLICITUD_INVALIDA",
  "mensaje": "valorAutorizado: El valor autorizado (coveredAmount) no se puede escribir: lo calcula el motor de coberturas. El importe editable es valorConvenido (allowedAmount), que hasta el 2026-10-21 se enviaba con el nombre valorAutorizado",
  "idTraza": "-",
  "instante": "2026-10-21T15:00:00Z"
}
```

**Respuesta `412 Precondition Failed`** cuando otro auditor guardó primero
(o cuando se reenvía la misma petición con la versión ya consumida):

```json
{
  "status": 412,
  "estado": 412,
  "codigo": "MODIFICACION_CONCURRENTE",
  "mensaje": "Otro usuario modificó la información. Actualice y vuelva a intentar.",
  "idTraza": "b7c1f0a24e9d4a18",
  "instante": "2026-08-19T14:22:31.884Z"
}
```

El manejo esperado ante un `412` es releer el recurso y reintentar **una** vez con la versión vigente:

```bash
BASE="http://localhost:8080/api/v1/cuentas"
CUENTA="GT-106586883036"

# 1) Releer la línea para conocer la versión actual
VERSION=$(curl -s "$BASE/$CUENTA/lineas/90114523" | jq '.version')

# 2) Reintentar el PATCH con esa versión
curl -s -X PATCH "$BASE/$CUENTA/lineas/90114523" \
  -H "Content-Type: application/json" \
  -H "X-Auditor: cmedina" \
  -d "{\"versionEsperada\":$VERSION,\"valorConvenido\":980000.00,\"modoRecalculo\":\"EN_CASCADA\"}"
```

No conviene reintentar más de una vez de forma automática: si el `412` se repite, hay edición
concurrente real y el auditor debe ver los datos actualizados antes de decidir.


Editar `90114611` (reemplazada) o `90114619` (bloqueada) devuelve `422 LINEA_NO_EDITABLE`.

**Respuesta `409 Conflict`** si la cuenta no está en `MODIFICACION`. Se rechaza antes de leer la
línea y sin escribir nada en OHI; lo mismo responden el lote, las novedades de cabecera y añadir un
motivo de pendiente. El mensaje nombra el estado con las palabras de la aplicación y basta para
enseñarlo tal cual:

```json
{
  "status": 409,
  "estado": 409,
  "codigo": "CUENTA_NO_MODIFICABLE",
  "mensaje": "La cuenta GT-106586883036 está en Adjudicación manual: sus datos solo se cambian en Modificación. Pásela a Modificación y vuelva a intentarlo.",
  "idTraza": "5d0c8e7a19b34f26",
  "instante": "2026-10-21T16:05:12.440Z"
}
```

---

## 5. Listar los pendientes sin resolver

Devuelve primero los de cabecera y luego los de línea, en orden de referencia.

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883036/pendientes \
  -H "Accept: application/json"
```

**Respuesta `200 OK`** (los primeros 3 de 19):

```json
[
  {
    "identificador": 77001,
    "codigo": "PEN-COB",
    "descripcion": "Requiere validación de cobertura por auditoría médica",
    "resuelto": false,
    "soloAdjudicacion": false,
    "nivel": "CABECERA",
    "referenciaLinea": null,
    "version": 1
  },
  {
    "identificador": 77002,
    "codigo": "PEN-DOC",
    "descripcion": "Soporte documental incompleto en la cuenta",
    "resuelto": false,
    "soloAdjudicacion": true,
    "nivel": "CABECERA",
    "referenciaLinea": null,
    "version": 1
  },
  {
    "identificador": 780023,
    "codigo": "PEN-LIN-TAR",
    "descripcion": "Tarifa de la línea pendiente de revisión",
    "resuelto": false,
    "soloAdjudicacion": false,
    "nivel": "LINEA",
    "referenciaLinea": 90114545,
    "version": 1
  }
]
```

`referenciaLinea` viene en `null` cuando `nivel` es `CABECERA`. Un pendiente con
`soloAdjudicacion: true` bloquea el envío **únicamente** si la cuenta está en `ADJUDICACION_MANUAL`.

---

## 6. Resolver un pendiente

La `justificacion` es obligatoria (máx. 2000 caracteres) y queda como nota de auditoría.
El `alcance` define el radio de la resolución:

*   `CUENTA_Y_LINEAS` — resuelve el motivo en la cabecera y en todas las líneas.
*   `SOLO_LINEAS` — resuelve el motivo solo en las líneas.

```bash
curl -s -i -X POST \
  http://localhost:8080/api/v1/cuentas/GT-106586883036/pendientes/77001/resolver \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{
        "justificacion": "Cobertura validada contra el plan vigente del afiliado. Soporte adjunto en el caso SD-48120.",
        "alcance": "CUENTA_Y_LINEAS"
      }'
```

**Respuesta `204 No Content`** — sin cuerpo:

```http
HTTP/1.1 204 No Content
```

La operación es **todo o nada**: si la resolución falla, la nota de justificación no se registra.
Reintentar el mismo identificador cuando ya está resuelto devuelve `400`, no `204`: el pendiente
ya no existe entre los no resueltos.

**Respuesta `409 Conflict`** si la acción no está habilitada para el estado actual
(por ejemplo sobre `GT-106586883044`, que está en `TARIFACION_COMPLETA`):

```json
{
  "status": 409,
  "estado": 409,
  "codigo": "ACCION_NO_DISPONIBLE",
  "mensaje": "La cuenta no permite la acción RESOLVER_PENDIENTE en su estado actual",
  "idTraza": "3f9ad2c58e0b47aa",
  "instante": "2026-08-19T14:30:02.117Z"
}
```

---

## 7. Enviar la cuenta

El envío en OHI es **asíncrono**: el servicio responde `202 Accepted` con un tiquete de seguimiento,
no con el resultado final.

*   `decision`: `ACEPTAR` o `DENEGAR`.
*   `codigoNovedad`: opcional al aceptar (deja la novedad asociada), obligatorio al denegar.

```bash
curl -s -X POST http://localhost:8080/api/v1/cuentas/GT-106586883037/enviar \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{ "decision": "ACEPTAR", "codigoNovedad": null }'
```

**Respuesta `202 Accepted`:**

```json
{
  "codigoCuenta": "GT-106586883037",
  "referenciaSeguimiento": "PROC-2026-0819-000178"
}
```

Denegar con novedad:

```bash
curl -s -X POST http://localhost:8080/api/v1/cuentas/GT-106586883037/enviar \
  -H "Content-Type: application/json" \
  -H "X-Auditor: cmedina" \
  -d '{ "decision": "DENEGAR", "codigoNovedad": "COB-114" }'
```

**Respuesta `409 Conflict`** si aún hay pendientes que bloquean
(es lo que devuelve `GT-106586883036` mientras no se resuelvan sus 19 pendientes):

```json
{
  "status": 409,
  "estado": 409,
  "codigo": "PENDIENTES_SIN_RESOLVER",
  "mensaje": "19 pendiente(s) impiden enviar la cuenta",
  "idTraza": "a04e7d13bb2c4f60",
  "instante": "2026-08-19T14:31:44.502Z"
}
```

---

## 8. Consultar el estado del proceso (sondeo puntual)

```bash
curl -s http://localhost:8080/api/v1/cuentas/GT-106586883037/proceso \
  -H "Accept: application/json"
```

**Respuesta `200 OK` — antes de enviar:**

```json
{
  "avance": "NO_INICIADO",
  "finalizado": false,
  "errores": []
}
```

**Respuesta `200 OK` — en curso:**

```json
{
  "avance": "EN_PROCESO",
  "finalizado": false,
  "errores": []
}
```

**Respuesta `200 OK` — terminado con error** (`GT-106586883043`):

```json
{
  "avance": "FALLIDO",
  "finalizado": true,
  "errores": [
    "La línea quedó bloqueada durante la adjudicación",
    "No fue posible recalcular el consumo de límites del afiliado"
  ]
}
```

Valores de `avance`: `NO_INICIADO`, `EN_PROCESO`, `EXITOSO`, `FALLIDO`.

---

## 9. Seguir el proceso en streaming (Server-Sent Events)

En vez de sondear, el cliente puede suscribirse al flujo. Requiere
`Accept: text/event-stream`. El flujo emite solo cuando el `avance` cambia y termina
cuando el proceso finaliza o vence la espera máxima.

```bash
curl -N -s http://localhost:8080/api/v1/cuentas/GT-106586883037/proceso/flujo \
  -H "Accept: text/event-stream"
```

**Respuesta `200 OK`** — eventos emitidos hasta finalizar:

```
data:{"avance":"EN_PROCESO","finalizado":false,"errores":[]}

data:{"avance":"EXITOSO","finalizado":true,"errores":[]}
```

El flujo se cierra solo: emite un evento por cada cambio de `avance` y termina cuando llega
`"finalizado": true` o cuando vence `auditoria.proceso.maxima-espera`. El cliente no necesita
sondear ni cerrar la conexión por su cuenta; basta con leer hasta el fin del flujo.

Cualquier cliente de SSE sirve. Para dejar el último estado en una variable:

```bash
curl -N -s http://localhost:8080/api/v1/cuentas/GT-106586883037/proceso/flujo \
  -H "Accept: text/event-stream" \
  | sed -u 's/^data://' \
  | jq -c 'select(.finalizado == true)' \
  | head -1
```


---

## 10. Formato de error

Todos los errores usan la misma estructura, traducida desde los errores de dominio. La respuesta
es **siempre `application/json`**, sin importar el `Accept` de la solicitud: abrir una ruta errada
en un navegador devuelve este mismo cuerpo, no una página HTML.

```json
{
  "status": 404,
  "estado": 404,
  "codigo": "CUENTA_NO_ENCONTRADA",
  "mensaje": "No existe la cuenta médica GT-000000000000",
  "idTraza": "9c2e51f7a0d84b33",
  "instante": "2026-08-19T14:18:07.301Z"
}
```

`status` y `estado` siempre llevan el mismo valor: `status` existe porque es la clave que lee
Spring para fijar el código HTTP de la respuesta, y `estado` mantiene el vocabulario en español.
`idTraza` es la clave para correlacionar el error con los logs del servicio — inclúyala siempre al
reportar incidentes; vale `-` cuando no hay traza activa.

| HTTP | `codigo` | Cuándo ocurre | ¿Reproducible en `local`? |
| --- | --- | --- | --- |
| `400` | `SOLICITUD_INVALIDA` | Cuerpo ausente o campos que no pasan validación | Sí |
| `400` | `DECISION_INVALIDA` | Decisión de envío incoherente, o pendiente inexistente | Sí |
| `403` | `SIN_PERMISO` | El auditor no tiene permiso sobre la operación | No |
| `403` | `LIMITE_APROBACION_EXCEDIDO` | El valor autorizado supera el límite de aprobación del auditor | No |
| `404` | `CUENTA_NO_ENCONTRADA` | El código de cuenta no existe | Sí |
| `404` | `LINEA_NO_ENCONTRADA` | La referencia de línea no existe en la cuenta | Sí |
| `409` | `ACCION_NO_DISPONIBLE` | La acción no está habilitada en el estado actual | Sí (cuentas `…044` y `…045`) |
| `409` | `PENDIENTES_SIN_RESOLVER` | Hay pendientes que bloquean el envío | Sí (cuenta `…036`) |
| `409` | `CUENTA_NO_MODIFICABLE` | Cambio de datos (línea, lote, novedades de cabecera, añadir pendiente) con la cuenta fuera de `MODIFICACION` | Sí, con cualquier cuenta fuera de `MODIFICACION`: no llega a escribir en OHI |
| `412` | `MODIFICACION_CONCURRENTE` | La `versionEsperada` quedó obsoleta | Sí |
| `422` | `LINEA_NO_EDITABLE` | La línea está bloqueada o reemplazada | Sí (líneas `90114611`, `90114619`) |
| `422` | `SIN_CAMBIOS` | La edición no contiene modificaciones | Sí |
| `404` | `RUTA_NO_ENCONTRADA` | La ruta no corresponde a ninguna operación del API | Sí |
| `405` | `METODO_NO_PERMITIDO` | Método HTTP no permitido para la ruta | Sí |
| `406` | `FORMATO_NO_ACEPTABLE` | El `Accept` no admite `application/json` | Sí |
| `415` | `MEDIO_NO_SOPORTADO` | El cuerpo no se envió como `application/json` | Sí |
| `503` | `SISTEMA_REGISTRO_NO_DISPONIBLE` | OHI no responde (circuit breaker abierto) | No |

Ejemplo de `400` por validación:

```json
{
  "status": 400,
  "estado": 400,
  "codigo": "SOLICITUD_INVALIDA",
  "mensaje": "modoRecalculo: El modo de recálculo debe ser EN_CASCADA o AISLADO; versionEsperada: La versión esperada es obligatoria",
  "idTraza": "1d7b60c9f2a34e85",
  "instante": "2026-08-19T14:25:53.009Z"
}
```

---

## 11. Flujo completo de auditoría (script de ejemplo)

Secuencia típica: consultar → revisar líneas → editar → resolver pendientes → enviar → seguir.
Este script corre tal cual contra el perfil `local`.

```bash
#!/usr/bin/env bash
set -euo pipefail

BASE="http://localhost:8080/api/v1/cuentas"
CUENTA="GT-106586883037"     # la cuenta sin pendientes: camino feliz
AUDITOR="cmedina"

# 1. Cabecera y acciones disponibles (las acciones se piden aparte)
curl -s "$BASE/$CUENTA" | jq '{estado, admiteCambios, pendientesSinResolver}'
curl -s "$BASE/$CUENTA/acciones" | jq -c '.accionesDisponibles'

# 2. Buscar líneas con novedad bloqueante en la primera página
curl -s "$BASE/$CUENTA/lineas?tamano=25" | jq '.elementos[] | select(.tieneNovedadBloqueante)'

# 3. Editar la primera línea (referencia 91114523, versión vigente 2)
curl -s -X PATCH "$BASE/$CUENTA/lineas/91114523" \
  -H "Content-Type: application/json" -H "X-Auditor: $AUDITOR" \
  -d '{"versionEsperada":2,"valorConvenido":980000.00,"modoRecalculo":"EN_CASCADA"}' \
  | jq '{version, valorAutorizado}'

# 4. Enviar
curl -s -X POST "$BASE/$CUENTA/enviar" \
  -H "Content-Type: application/json" -H "X-Auditor: $AUDITOR" \
  -d '{"decision":"ACEPTAR"}' | jq .

# 5. Seguir el proceso hasta que finalice (unos 6 segundos)
curl -N -s "$BASE/$CUENTA/proceso/flujo" -H "Accept: text/event-stream"
```

**Salida esperada:**

```text
{
  "estado": "MODIFICACION",
  "admiteCambios": true,
  "pendientesSinResolver": 0
}
["ENVIAR","SEGUIR_PROCESO","RESOLVER_PENDIENTE","RESOLVER_PENDIENTE_LINEA","DESBLOQUEAR_LINEAS","DESHACER_REEMPLAZOS"]
{ "referencia": 91114529, "numeroLinea": 7, "tieneNovedadBloqueante": true, ... }
{ "version": 3, "valorAutorizado": 882000.00 }
{ "codigoCuenta": "GT-106586883037", "referenciaSeguimiento": "PROC-2026-0819-000179" }
data:{"avance":"EN_PROCESO","finalizado":false,"errores":[]}
data:{"avance":"EXITOSO","finalizado":true,"errores":[]}
```

> Ojo con las referencias: son distintas por cuenta. Las de `GT-106586883037` (índice 1) empiezan
> en `91114523`, no en `90114523`. La fórmula está en la sección «Perfil local».

---

## 12. Cliente Java reactivo (WebClient)

Ejemplo de consumo desde otro microservicio Spring, sin bloqueos. Los DTO de respuesta del
enrutador son de alcance de paquete, así que un consumidor externo declara los suyos con la
misma forma:

```java
var cliente = WebClient.builder()
        .baseUrl("http://localhost:8080/api/v1/cuentas")
        .build();

// Consultar cabecera
Mono<RespuestaCuenta> cuenta = cliente.get()
        .uri("/{codigo}", "GT-106586883036")
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(RespuestaCuenta.class);

// Guardar línea con control de versión
Mono<RespuestaDetalleLinea> guardada = cliente.patch()
        .uri("/{codigo}/lineas/{referencia}", "GT-106586883036", 90114523L)
        .header("X-Auditor", "cmedina")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(new SolicitudGuardarLinea(
                2L,                            // versionEsperada
                new BigDecimal("980000.00"),   // valorConvenido (allowedAmount)
                BigDecimal.ONE,                // unidadesConvenidas
                true,                          // conservarBeneficios
                false,                         // conservarTarifacion
                "EN_CASCADA"))                 // modoRecalculo (obligatorio)
        .retrieve()
        .bodyToMono(RespuestaDetalleLinea.class);

// Seguir el proceso como flujo SSE
Flux<RespuestaEstadoProceso> proceso = cliente.get()
        .uri("/{codigo}/proceso/flujo", "GT-106586883037")
        .accept(MediaType.TEXT_EVENT_STREAM)
        .retrieve()
        .bodyToFlux(RespuestaEstadoProceso.class)
        .takeUntil(RespuestaEstadoProceso::finalizado);
```

---

## 13. Recomendaciones para el cliente

1.  **Habilitar las operaciones con `accionesDisponibles`**, nunca deduciendo permisos a partir de `estado`.
    El estado es informativo; las transiciones válidas las declara el sistema de registro.
    Trátelo como conjunto: el orden del arreglo no es estable. La edición de datos se abre o se
    cierra con `admiteCambios`, que ya trae la regla calculada: tampoco se deduce de `estado`.
    Las dos salvedades son el envío y «Pasar a Modificación»: su rótulo, su visibilidad y la
    acción que ejecutan salen del estado, y el envío no se apaga aunque falte `ENVIAR` (sección 1).
2.  **Propagar siempre `X-Auditor`** en las escrituras: sin él la traza de auditoría queda incompleta.
3.  **Guardar la `version`** de cada línea que se muestre en pantalla y enviarla como `versionEsperada`.
4.  **Tratar el `cursor` de los pendientes como opaco**: no derivar de él el número de
    página ni el total. Las líneas no usan cursor, sino posición.
5.  **No asumir resultado inmediato del envío**: tras el `202` hay que seguir el proceso por `/proceso` o `/proceso/flujo`.
6.  **Declarar siempre `modoRecalculo`**: no existe valor por defecto porque la decisión tiene impacto financiero.
7.  **Reintentar el `503`** con backoff — el circuit breaker hacia OHI se recupera solo; no reintentar `409`, `412` ni `422` sin releer el recurso.
8.  **Desarrollar contra el perfil `local`** y validar contra `dev` antes de integrar: el contrato es el mismo,
    pero `local` no reproduce errores de permisos ni de disponibilidad de OHI.

---

## Patrones y Prácticas Implementadas

*   **Arquitectura Hexagonal:** Clara separación por módulos de Gradle.
*   **Domain-Driven Design (DDD):** Vocabulario en español en todo el dominio (Lenguaje Ubicuo).
*   **Anti-Corruption Layer (ACL):** Traducción del inglés (OHI) al español (Dominio Sura) concentrado en un solo adaptador.
*   **Puertos y adaptadores:** El dominio depende de puertos; la ACL de OHI es la única implementación, y sustituirla no obligaría a tocar dominio ni API.
*   **CQRS:** Separación de comandos y consultas, puertos específicos.
*   **Trazabilidad asíncrona:** Eventos persistidos vía R2DBC y publicados por un Bus para auditar sin tumbar flujos.
*   **Resiliencia:** Uso de Resilience4J (Circuit Breaker y Retry) configurado para integraciones inestables.
*   **Enrutador Funcional:** Uso de Router Functions de Spring WebFlux en vez de @RestController para adherirse al manifiesto reactivo.
*   **Paginación Keyset:** Para alto rendimiento en listas de líneas de facturas de OHI.
