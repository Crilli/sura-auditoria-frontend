package co.sura.auditoria.configuracion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
public class ConfiguracionSeguridad {

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
            .csrf(ServerHttpSecurity.CsrfSpec::disable)
            // Toma el CorsConfigurationSource si existe. Solo el perfil local
            // publica uno; en los demás el CORS lo resuelve el API Gateway.
            .cors(Customizer.withDefaults())
            // Aquí se configuraría oauth2ResourceServer, CORS, etc., 
            // según los estándares de SURA para microservicios internos.
            // Por simplicidad, se permite todo en este template base,
            // pero en un entorno real la autenticación se delega al API Gateway
            // o se valida el JWT aquí.
            .authorizeExchange(exchanges -> exchanges
                .pathMatchers("/actuator/**").permitAll()
                .pathMatchers("/api/v1/cuentas/**").permitAll()
                // Los catálogos van aparte porque no pertenecen a ninguna cuenta.
                // Sin esta línea caen en `anyExchange().authenticated()` y el
                // selector de novedades sale siempre vacío: el front recibe un
                // 401 que no distingue de «no hay nada que ofrecer».
                .pathMatchers("/api/v1/catalogos/**").permitAll()
                .anyExchange().authenticated()
            )
            .build();
    }
}
