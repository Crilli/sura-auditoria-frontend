package co.sura.auditoria.configuracion;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

import java.util.List;

/**
 * CORS para consumo desde un navegador en otro origen.
 *
 * <p><b>Apagado por omisión.</b> Solo se activa si se declara
 * {@code integraciones.cors.origenes}; en un despliegue real el CORS lo resuelve
 * el API Gateway, que es quien publica el servicio hacia el navegador, y por eso
 * ningún perfil de servidor debe traer orígenes fijados.
 *
 * <p>El perfil {@code local} sí lo declara, porque ahí el frontend se sirve desde
 * el dev server de Angular en otro puerto. Para levantar cualquier otro perfil
 * contra ese mismo frontend, se pasa la propiedad en el arranque:
 *
 * <pre>--integraciones.cors.origenes=http://localhost:4200</pre>
 */
@Configuration
@ConditionalOnProperty(name = "integraciones.cors.origenes")
public class ConfiguracionCors {

    @Bean
    public CorsConfigurationSource corsConfigurationSource(
            @Value("${integraciones.cors.origenes}") List<String> origenes) {

        var configuracion = new CorsConfiguration();
        configuracion.setAllowedOrigins(origenes);
        configuracion.setAllowedMethods(List.of("GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"));
        configuracion.setAllowedHeaders(List.of("*"));
        configuracion.setMaxAge(3600L);

        var fuente = new UrlBasedCorsConfigurationSource();
        fuente.registerCorsConfiguration("/api/**", configuracion);
        return fuente;
    }
}
