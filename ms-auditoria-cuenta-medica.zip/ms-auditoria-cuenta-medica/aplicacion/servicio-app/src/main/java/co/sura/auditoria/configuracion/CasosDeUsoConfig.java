package co.sura.auditoria.configuracion;

import co.sura.auditoria.casodeuso.*;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * Inyecta las dependencias de los casos de uso (dominio puro).
 */
@Configuration
public class CasosDeUsoConfig {

    @Bean
    public ConsultarCuentaCasoDeUso consultarCuentaCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ConsultarCuentaCasoDeUso(consultas);
    }

    @Bean
    public ConsultarAccionesCasoDeUso consultarAccionesCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ConsultarAccionesCasoDeUso(consultas);
    }

    @Bean
    public ListarLineasCasoDeUso listarLineasCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ListarLineasCasoDeUso(consultas);
    }

    @Bean
    public ObtenerLineaSiguienteCasoDeUso obtenerLineaSiguienteCasoDeUso(
            PuertoConsultaCuentas consultas) {
        return new ObtenerLineaSiguienteCasoDeUso(consultas);
    }

    @Bean
    public ConsultarDetalleLineaCasoDeUso consultarDetalleLineaCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ConsultarDetalleLineaCasoDeUso(consultas);
    }

    @Bean
    public GuardarLineaCasoDeUso guardarLineaCasoDeUso(PuertoConsultaCuentas consultas,
                                                       PuertoComandosCuenta comandos,
                                                       PublicadorEventosAuditoria publicador,
                                                       ComprobadorDeNovedades comprobador) {
        return new GuardarLineaCasoDeUso(consultas, comandos, publicador, comprobador);
    }

    /**
     * El mismo cambio sobre varias líneas, desde la selección de la grilla.
     *
     * <p>Lleva el {@code ComprobadorDeNovedades}, igual que el de una línea: el sistema de
     * registro no comprueba ni el catálogo ni los huecos ni quién puso la novedad que se quiere
     * quitar, así que sin él el lote dejaba pasar lo que el guardado de una línea rechaza.
     */
    @Bean
    public AplicarCambiosEnLoteCasoDeUso aplicarCambiosEnLoteCasoDeUso(
            PuertoConsultaCuentas consultas,
            PuertoComandosCuenta comandos,
            PublicadorEventosAuditoria publicador,
            ComprobadorDeNovedades comprobador) {
        return new AplicarCambiosEnLoteCasoDeUso(consultas, comandos, publicador, comprobador);
    }

    /**
     * Poner un motivo de pendiente sobre unas líneas.
     *
     * <p>Lleva el catálogo porque comprueba el código antes de mandarlo: el sistema de
     * registro rechaza uno desconocido con un mensaje que no distingue «te lo inventaste» de
     * «el catálogo no responde».
     */
    /**
     * El buscador de facturas.
     *
     * <p>Lleva su propio puerto y no {@code PuertoConsultaCuentas}: aquél responde «qué tiene
     * esta cuenta» y éste «cuáles hay», que es otra pregunta y otra consulta.
     */
    @Bean
    public BuscarCuentasCasoDeUso buscarCuentasCasoDeUso(
            co.sura.auditoria.modelo.puertos.PuertoBusquedaCuentas busqueda) {
        return new BuscarCuentasCasoDeUso(busqueda);
    }

    /** La historia de la cuenta: dos recursos del sistema de registro unidos en uno. */
    @Bean
    public ConsultarHistoriaCasoDeUso consultarHistoriaCasoDeUso(
            co.sura.auditoria.modelo.puertos.PuertoHistoriaCuenta historia) {
        return new ConsultarHistoriaCasoDeUso(historia);
    }

    @Bean
    public AgregarMotivoPendienteCasoDeUso agregarMotivoPendienteCasoDeUso(
            co.sura.auditoria.modelo.puertos.PuertoPendientes pendientes,
            co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente catalogo,
            PublicadorEventosAuditoria publicador) {
        return new AgregarMotivoPendienteCasoDeUso(pendientes, catalogo, publicador);
    }

    /**
     * Las comprobaciones de novedad, compartidas por la línea y la cabecera.
     * Ver {@link ComprobadorDeNovedades}.
     */
    @Bean
    public ComprobadorDeNovedades comprobadorDeNovedades(PuertoCatalogoNovedades catalogoNovedades) {
        return new ComprobadorDeNovedades(catalogoNovedades);
    }

    @Bean
    public GuardarNovedadesDeCuentaCasoDeUso guardarNovedadesDeCuentaCasoDeUso(
            PuertoConsultaCuentas consultas,
            PuertoComandosCuenta comandos,
            PublicadorEventosAuditoria publicador,
            ComprobadorDeNovedades comprobador) {
        return new GuardarNovedadesDeCuentaCasoDeUso(consultas, comandos, publicador, comprobador);
    }

    @Bean
    public EjecutarAccionCasoDeUso ejecutarAccionCasoDeUso(
            PuertoConsultaCuentas consultas,
            PuertoComandosCuenta comandos,
            co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivos catalogoMotivos,
            PublicadorEventosAuditoria publicador) {
        return new EjecutarAccionCasoDeUso(consultas, comandos, catalogoMotivos, publicador);
    }

    @Bean
    public ConsultarCatalogoNovedadesCasoDeUso consultarCatalogoNovedadesCasoDeUso(
            PuertoCatalogoNovedades catalogoNovedades) {
        return new ConsultarCatalogoNovedadesCasoDeUso(catalogoNovedades);
    }

    @Bean
    public ListarPendientesCasoDeUso listarPendientesCasoDeUso(PuertoPendientes pendientes) {
        return new ListarPendientesCasoDeUso(pendientes);
    }

    @Bean
    public ResumirMotivosPendientesCasoDeUso resumirMotivosPendientesCasoDeUso(PuertoPendientes pendientes) {
        return new ResumirMotivosPendientesCasoDeUso(pendientes);
    }

    @Bean
    public ResolverPendientesCasoDeUso resolverPendientesCasoDeUso(PuertoConsultaCuentas consultas,
                                                                   PuertoPendientes pendientes,
                                                                   PuertoNotas notas,
                                                                   PublicadorEventosAuditoria publicador) {
        return new ResolverPendientesCasoDeUso(consultas, pendientes, notas, publicador);
    }

    /**
     * La resolución conjunta. Comparte puertos con la individual pero no la
     * envuelve: usa el recurso de OHI que acepta varios motivos a la vez, que es
     * una sola readjudicación en vez de una por motivo.
     */
    @Bean
    public ResolverPendientesEnMasaCasoDeUso resolverPendientesEnMasaCasoDeUso(
            PuertoConsultaCuentas consultas,
            PuertoPendientes pendientes,
            PuertoNotas notas,
            PublicadorEventosAuditoria publicador,
            // Cabecera y líneas a la vez por omisión (OPE-08); false las vuelve a poner en serie.
            @org.springframework.beans.factory.annotation.Value(
                    "${integraciones.ohi.resolucion-masiva.niveles-en-paralelo:true}")
            boolean nivelesEnParalelo) {
        return new ResolverPendientesEnMasaCasoDeUso(consultas, pendientes, notas, publicador,
                                                     nivelesEnParalelo);
    }

    /** Las opciones con las que se puede acotar el listado de líneas. */
    @Bean
    public ResumirFiltrosLineasCasoDeUso resumirFiltrosLineasCasoDeUso(
            PuertoConsultaCuentas consultas) {
        return new ResumirFiltrosLineasCasoDeUso(consultas);
    }

    @Bean
    public EnviarCuentaCasoDeUso enviarCuentaCasoDeUso(PuertoConsultaCuentas consultas,
                                                       PuertoComandosCuenta comandos,
                                                       PuertoPendientes pendientes,
                                                       PublicadorEventosAuditoria publicador) {
        return new EnviarCuentaCasoDeUso(consultas, comandos, pendientes, publicador);
    }

    @Bean
    public SeguirProcesoCasoDeUso seguirProcesoCasoDeUso(
            PuertoConsultaCuentas consultas,
            @Value("${auditoria.proceso.intervalo:2s}") Duration intervalo,
            @Value("${auditoria.proceso.maxima-espera:30}") long maximaEspera) {
        return new SeguirProcesoCasoDeUso(consultas, intervalo, Duration.ofSeconds(maximaEspera));
    }
}
