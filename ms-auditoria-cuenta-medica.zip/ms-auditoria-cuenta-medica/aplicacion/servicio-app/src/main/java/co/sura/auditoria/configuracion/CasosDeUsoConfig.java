package co.sura.auditoria.configuracion;

import co.sura.auditoria.casodeuso.*;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * Inyecta las dependencias de los casos de uso (dominio puro).
 */
@Configuration
public class CasosDeUsoConfig {

    @Bean
    public ConsultarCuentaCasoDeUso consultarCuentaCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ConsultarCuentaCasoDeUso(consultas);
    }

    @Bean
    public ConsultarAccionesCasoDeUso consultarAccionesCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ConsultarAccionesCasoDeUso(consultas);
    }

    @Bean
    public ListarLineasCasoDeUso listarLineasCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ListarLineasCasoDeUso(consultas);
    }

    @Bean
    public ConsultarDetalleLineaCasoDeUso consultarDetalleLineaCasoDeUso(PuertoConsultaCuentas consultas) {
        return new ConsultarDetalleLineaCasoDeUso(consultas);
    }

    @Bean
    public GuardarLineaCasoDeUso guardarLineaCasoDeUso(PuertoConsultaCuentas consultas,
                                                       PuertoComandosCuenta comandos,
                                                       PublicadorEventosAuditoria publicador) {
        return new GuardarLineaCasoDeUso(consultas, comandos, publicador);
    }

    @Bean
    public ListarPendientesCasoDeUso listarPendientesCasoDeUso(PuertoPendientes pendientes) {
        return new ListarPendientesCasoDeUso(pendientes);
    }

    @Bean
    public ResumirMotivosPendientesCasoDeUso resumirMotivosPendientesCasoDeUso(PuertoPendientes pendientes) {
        return new ResumirMotivosPendientesCasoDeUso(pendientes);
    }

    @Bean
    public ResolverPendientesCasoDeUso resolverPendientesCasoDeUso(PuertoConsultaCuentas consultas,
                                                                   PuertoPendientes pendientes,
                                                                   PuertoNotas notas,
                                                                   PublicadorEventosAuditoria publicador) {
        return new ResolverPendientesCasoDeUso(consultas, pendientes, notas, publicador);
    }

    /**
     * La resolución conjunta. Comparte puertos con la individual pero no la
     * envuelve: usa el recurso de OHI que acepta varios motivos a la vez, que es
     * una sola readjudicación en vez de una por motivo.
     */
    @Bean
    public ResolverPendientesEnMasaCasoDeUso resolverPendientesEnMasaCasoDeUso(
            PuertoConsultaCuentas consultas,
            PuertoPendientes pendientes,
            PuertoNotas notas,
            PublicadorEventosAuditoria publicador) {
        return new ResolverPendientesEnMasaCasoDeUso(consultas, pendientes, notas, publicador);
    }

    @Bean
    public EnviarCuentaCasoDeUso enviarCuentaCasoDeUso(PuertoConsultaCuentas consultas,
                                                       PuertoComandosCuenta comandos,
                                                       PuertoPendientes pendientes,
                                                       PublicadorEventosAuditoria publicador) {
        return new EnviarCuentaCasoDeUso(consultas, comandos, pendientes, publicador);
    }

    @Bean
    public SeguirProcesoCasoDeUso seguirProcesoCasoDeUso(
            PuertoConsultaCuentas consultas,
            @Value("${auditoria.proceso.intervalo:2s}") Duration intervalo,
            @Value("${auditoria.proceso.maxima-espera:30}") long maximaEspera) {
        return new SeguirProcesoCasoDeUso(consultas, intervalo, Duration.ofSeconds(maximaEspera));
    }
}
