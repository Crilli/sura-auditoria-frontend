package co.sura.auditoria.configuracion;

import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.cache.CaffeineCacheMetrics;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Publica en Micrometer las estadísticas de la caché de identidad de OHI.
 *
 * <h3>Por qué esto no es opcional</h3>
 * La caché de {@link ResolutorIdentidadOhi} decide cuántas llamadas recibe OHI: cada fallo
 * es una consulta extra, y toda operación del API pasa por ella. Es el único punto del
 * servicio donde un parámetro mal dimensionado <b>duplica el tráfico</b> sin que nada falle
 * ni aparezca en los logs.
 *
 * <p>Caffeine ya lo mide —el resolutor construye su caché con {@code recordStats()}—, pero
 * nadie lo leía. Con este enlace, {@code cache.gets{result="hit"|"miss"}} y
 * {@code cache.evictions} salen por el actuator, que es lo que permite afirmar durante una
 * prueba de carga que la caché aguanta, en vez de suponerlo.
 *
 * <p>Vive en la capa de aplicación y no en la ACL para no meter Micrometer en un adaptador:
 * la ACL expone su caché y es aquí donde se decide qué se observa.
 */
@Configuration
public class ConfiguracionMetricasCache {

    public static final String NOMBRE_CACHE_IDENTIDAD = "ohiIdentidadCuenta";

    /** La de filtros, motivos y acciones por cuenta (OPE-09). */
    public static final String NOMBRE_CACHE_AGREGADOS = "ohiAgregadosCuenta";

    /**
     * Se registra con un {@link ApplicationRunner} y no en la propia construcción del bean
     * porque el enlace tiene que ocurrir cuando el registro de métricas ya está listo.
     */
    @Bean
    public ApplicationRunner registrarMetricasDeIdentidad(ResolutorIdentidadOhi resolutor,
                                                          MeterRegistry registro) {
        return argumentos -> CaffeineCacheMetrics.monitor(
                registro, resolutor.cacheNativa(), NOMBRE_CACHE_IDENTIDAD);
    }

    /**
     * La caché de agregados: su tasa de aciertos es lo que dice, en una prueba de carga, cuántas
     * llamadas a OHI se están ahorrando de verdad.
     */
    @Bean
    public ApplicationRunner registrarMetricasDeAgregados(
            co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi agregados, MeterRegistry registro) {
        return argumentos -> CaffeineCacheMetrics.monitor(
                registro, agregados.cacheNativa(), NOMBRE_CACHE_AGREGADOS);
    }
}
