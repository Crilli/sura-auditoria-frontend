CREATE TABLE EVENTOS_AUDITORIA (
    identificador CHAR(36) NOT NULL PRIMARY KEY,
    codigo_cuenta VARCHAR(50) NOT NULL,
    referencia_linea BIGINT,
    tipo VARCHAR(50) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    detalle VARCHAR(255) NOT NULL,
    resultado VARCHAR(20) NOT NULL,
    codigo_error VARCHAR(50),
    id_correlacion VARCHAR(50),
    ocurrido_en TIMESTAMP NOT NULL,
    INDEX idx_codigo_cuenta (codigo_cuenta),
    INDEX idx_ocurrido_en (ocurrido_en)
);
