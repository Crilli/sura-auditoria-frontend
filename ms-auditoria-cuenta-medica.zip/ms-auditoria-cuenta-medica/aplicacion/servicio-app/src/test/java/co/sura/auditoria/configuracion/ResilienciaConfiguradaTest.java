package co.sura.auditoria.configuracion;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.acl.ohi.traductor.RespuestaDeErrorOhi;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.common.CompositeCustomizer;
import io.github.resilience4j.springboot3.circuitbreaker.autoconfigure.CircuitBreakerProperties;
import io.github.resilience4j.springboot3.circuitbreaker.monitoring.health.CircuitBreakersHealthIndicator;
import io.github.resilience4j.springboot3.retry.autoconfigure.RetryProperties;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.SimpleStatusAggregator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.io.ClassPathResource;

/**
 * La resiliencia tal como queda en {@code application.yml} (OPE-01, OPE-05).
 *
 * <p>Se lee el fichero real con el mismo {@code Binder} que usa Spring Boot y se construyen
 * las configuraciones con la misma fábrica que usa Resilience4j. Así, un nombre de clase mal
 * escrito en el predicado, una propiedad que no existe o una ventana que vuelve a ser por
 * conteo rompen esta prueba, y no una prueba de carga.
 */
@DisplayName("Resiliencia configurada en application.yml")
class ResilienciaConfiguradaTest {

    private static Binder binder;

    @BeforeAll
    static void cargarElFicheroReal() throws IOException {
        // El primer documento: lo que rige en todos los perfiles.
        var documentos = new YamlPropertySourceLoader()
                .load("application", new ClassPathResource("application.yml"));
        binder = new Binder(ConfigurationPropertySources.from(documentos.get(0)));
    }

    private static CircuitBreakerProperties circuitos() {
        return binder.bind("resilience4j.circuitbreaker", CircuitBreakerProperties.class).get();
    }

    private static CircuitBreakerConfig config(String nombre) {
        var propiedades = circuitos();
        return propiedades.createCircuitBreakerConfig(
                nombre, propiedades.getInstances().get(nombre), new CompositeCustomizer<>(List.of()));
    }

    private static RespuestaDeErrorOhi respuesta(int estado) {
        return new RespuestaDeErrorOhi(new ErrorDeDominio.ModificacionConcurrente("cuenta", -1), estado);
    }

    @ParameterizedTest(name = "{0}: solo las caídas cuentan y la ventana es por tiempo")
    @ValueSource(strings = {"ohiConsultas", "ohiComandos", "ohiEnvio"})
    @Tag("OPE-01")
    void cadaCircuitoCuentaSoloCaidas(String nombre) {
        var config = config(nombre);

        assertThat(config.getSlidingWindowType()).isEqualTo(CircuitBreakerConfig.SlidingWindowType.TIME_BASED);
        assertThat(config.getMinimumNumberOfCalls()).isGreaterThanOrEqualTo(10);
        assertThat(config.getRecordExceptionPredicate().test(respuesta(409))).isFalse();
        assertThat(config.getRecordExceptionPredicate().test(respuesta(422))).isFalse();
        assertThat(config.getRecordExceptionPredicate().test(respuesta(503))).isTrue();
        assertThat(config.getIgnoreExceptionPredicate().test(saturacion())).isTrue();
        assertThat(config.getIgnoreExceptionPredicate().test(respuesta(503))).isFalse();
    }

    /** La cola del pool llena, tal como llega: envuelta en la excepción de petición de WebClient. */
    private static Throwable saturacion() {
        return new org.springframework.web.reactive.function.client.WebClientRequestException(
                new reactor.netty.internal.shaded.reactor.pool.PoolAcquirePendingLimitException(60),
                org.springframework.http.HttpMethod.POST, java.net.URI.create("https://ohi.example/x"),
                new org.springframework.http.HttpHeaders());
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("con OHI colgado, la cola del pool llena no diluye las caídas: el circuito abre igual")
    void laSaturacionNoTapaLasCaidas() {
        // El caso de la revisión de la Fase 0: con las 30 conexiones retenidas hasta el
        // timeout, casi toda la demanda acaba en la cola. Si esos rechazos contaran como
        // éxitos, 25 caídas entre 125 llamadas serían un 20 % y el circuito no abriría.
        var circuito = CircuitBreaker.of("ohiConsultas", config("ohiConsultas"));

        for (int i = 0; i < 100; i++) circuito.onError(1, TimeUnit.MILLISECONDS, saturacion());
        for (int i = 0; i < 25; i++) circuito.onError(1, TimeUnit.MILLISECONDS, respuesta(503));

        assertThat(circuito.getMetrics().getNumberOfSuccessfulCalls()).isZero();
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.OPEN);
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("cada intento de una consulta pasa por el circuito: tres timeouts son tres fallos, no uno")
    void elCircuitoVaDentroDelReintento() {
        var circuitos = CircuitBreakerRegistry.ofDefaults();
        var circuito = circuitos.circuitBreaker("ohiConsultas", config("ohiConsultas"));
        var reintentos = io.github.resilience4j.retry.RetryRegistry.ofDefaults();
        reintentos.retry("ohiConsultas", binder.bind("resilience4j.retry", RetryProperties.class).get()
                .createRetryConfig("ohiConsultas", new CompositeCustomizer<>(List.of())));
        var resiliencia = new co.sura.auditoria.acl.ohi.resiliencia.ConfiguracionResiliencia(circuitos, reintentos);

        var timeout = new org.springframework.web.reactive.function.client.WebClientRequestException(
                io.netty.handler.timeout.ReadTimeoutException.INSTANCE,
                org.springframework.http.HttpMethod.POST, java.net.URI.create("https://ohi.example/x"),
                new org.springframework.http.HttpHeaders());

        reactor.test.StepVerifier.create(reactor.core.publisher.Mono.<String>error(timeout)
                        .transform(resiliencia.paraConsultasMono()))
                .expectError()
                .verify();

        assertThat(circuito.getMetrics().getNumberOfFailedCalls()).isEqualTo(3);
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("cincuenta conflictos no abren el circuito de comandos; veinticinco caídas sí")
    void losConflictosNoAbren() {
        var circuito = CircuitBreaker.of("ohiComandos", config("ohiComandos"));

        for (int i = 0; i < 50; i++) circuito.onError(1, TimeUnit.MILLISECONDS, respuesta(409));
        assertThat(circuito.getState()).isEqualTo(CircuitBreaker.State.CLOSED);
        assertThat(circuito.getMetrics().getNumberOfFailedCalls()).isZero();

        // Un conflicto es una respuesta de OHI: en la ventana cuenta como éxito. Por eso las
        // caídas se prueban en un circuito aparte, sin cincuenta éxitos que las diluyan.
        var otro = CircuitBreaker.of("ohiComandos", config("ohiComandos"));
        for (int i = 0; i < 25; i++) otro.onError(1, TimeUnit.MILLISECONDS, respuesta(503));
        assertThat(otro.getState()).isEqualTo(CircuitBreaker.State.OPEN);
    }

    @Test
    @Tag("OPE-01")
    @DisplayName("las consultas se reintentan ante caídas, nunca ante respuestas de negocio")
    void elReintentoUsaElMismoCriterio() {
        var reintento = binder.bind("resilience4j.retry", RetryProperties.class).get()
                .createRetryConfig("ohiConsultas", new CompositeCustomizer<>(List.of()));

        assertThat(reintento.getExceptionPredicate().test(respuesta(404))).isFalse();
        assertThat(reintento.getExceptionPredicate().test(respuesta(403))).isFalse();
        assertThat(reintento.getExceptionPredicate().test(respuesta(503))).isTrue();
        assertThat(reintento.getExceptionPredicate().test(respuesta(429))).isFalse();
        assertThat(reintento.getExceptionPredicate().test(saturacion())).isFalse();
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("un circuito abierto se ve en el health pero no lo pone en DOWN")
    void elHealthNoRetiraLaReplica() {
        var registro = CircuitBreakerRegistry.ofDefaults();
        registro.circuitBreaker("ohiConsultas", config("ohiConsultas")).transitionToOpenState();
        registro.circuitBreaker("ohiComandos", config("ohiComandos"));
        var agregador = new SimpleStatusAggregator();

        var salud = new CircuitBreakersHealthIndicator(registro, circuitos(), agregador).health();

        // El componente sigue en UP con un circuito abierto: para alertar está la métrica
        // resilience4j_circuitbreaker_state, no el estado del componente.
        assertThat(salud.getStatus()).isEqualTo(Status.UP);
        assertThat(((Health) salud.getDetails().get("ohiConsultas")).getStatus().getCode())
                .isEqualTo("CIRCUIT_OPEN");
        // Junto a un componente sano, el estado global sigue UP.
        assertThat(agregador.getAggregateStatus(Status.UP, salud.getStatus())).isEqualTo(Status.UP);
    }

    @Test
    @Tag("OPE-05")
    @DisplayName("hay histogramas de latencia del servicio y de las llamadas a OHI, y el health de circuitos está activo")
    void metricasParaLeerUnaPruebaDeCarga() {
        var histogramas = binder.bind("management.metrics.distribution.percentiles-histogram",
                                      Bindable.mapOf(String.class, Boolean.class)).get();

        assertThat(histogramas).containsEntry("http.server.requests", true)
                               .containsEntry("http.client.requests", true);
        assertThat(binder.bind("management.health.circuitbreakers.enabled", Boolean.class).get()).isTrue();
    }
}
