package co.sura.auditoria.configuracion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import co.sura.auditoria.acl.ohi.identidad.ResolutorIdentidadOhi;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Duration;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;

@DisplayName("ConfiguracionMetricasCache")
class ConfiguracionMetricasCacheTest {

    private final ResolutorIdentidadOhi resolutor = new ResolutorIdentidadOhi(1_000L,
            Duration.ofHours(2));

    /** Registra las métricas como lo haría el arranque y devuelve el registro. */
    private MeterRegistry registroConLaCacheEnlazada() throws Exception {
        var registro = new SimpleMeterRegistry();
        new ConfiguracionMetricasCache()
                .registrarMetricasDeIdentidad(resolutor, registro)
                .run(null);
        return registro;
    }

    @Test
    @DisplayName("publica las métricas de la caché bajo su nombre")
    void publicaLasMetricasBajoSuNombre() throws Exception {
        var registro = registroConLaCacheEnlazada();

        assertThat(registro.getMeters())
                .as("ninguna métrica se registró")
                .isNotEmpty();
        assertThat(registro.find("cache.gets")
                .tag("cache", ConfiguracionMetricasCache.NOMBRE_CACHE_IDENTIDAD)
                .meters())
                .isNotEmpty();
    }

    @Test
    @DisplayName("los fallos de caché se cuentan: es la métrica que delata el dimensionamiento")
    void losFallosDeCacheSeCuentan() throws Exception {
        var registro = registroConLaCacheEnlazada();
        var buscador = mock(ResolutorIdentidadOhi.BuscadorPorCodigo.class);
        when(buscador.buscar("CM-1")).thenReturn(Mono.just(1L));

        // Primera resolución: fallo de caché. Segunda: acierto.
        resolutor.resolverParaCuenta(new CodigoCuenta("CM-1"), buscador).block();
        resolutor.resolverParaCuenta(new CodigoCuenta("CM-1"), buscador).block();

        var fallos = registro.find("cache.gets")
                .tag("cache", ConfiguracionMetricasCache.NOMBRE_CACHE_IDENTIDAD)
                .tag("result", "miss").functionCounter();
        var aciertos = registro.find("cache.gets")
                .tag("cache", ConfiguracionMetricasCache.NOMBRE_CACHE_IDENTIDAD)
                .tag("result", "hit").functionCounter();

        assertThat(fallos).isNotNull();
        assertThat(aciertos).isNotNull();
        assertThat(fallos.count()).isEqualTo(1d);
        assertThat(aciertos.count()).isEqualTo(1d);
    }

    @Test
    @DisplayName("el nombre de la caché es estable: los tableros y las alertas dependen de él")
    void elNombreDeLaCacheEsEstable() {
        assertThat(ConfiguracionMetricasCache.NOMBRE_CACHE_IDENTIDAD)
                .isEqualTo("ohiIdentidadCuenta");
    }

    @Test
    @org.junit.jupiter.api.Tag("OPE-09")
    @DisplayName("publica también la caché de agregados: su tasa de aciertos es el ahorro de llamadas a OHI")
    void publicaLaCacheDeAgregados() throws Exception {
        var registro = new io.micrometer.core.instrument.simple.SimpleMeterRegistry();
        var agregados = new co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi();
        new ConfiguracionMetricasCache().registrarMetricasDeAgregados(agregados, registro).run(null);

        agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.ACCIONES,
                new co.sura.auditoria.modelo.cuenta.CodigoCuenta("CM-1"), () -> Mono.just("x")).block();
        agregados.obtener(co.sura.auditoria.acl.ohi.cache.CacheDeAgregadosOhi.Agregado.ACCIONES,
                new co.sura.auditoria.modelo.cuenta.CodigoCuenta("CM-1"), () -> Mono.just("y")).block();

        var aciertos = registro.find("cache.gets")
                .tag("cache", ConfiguracionMetricasCache.NOMBRE_CACHE_AGREGADOS)
                .tag("result", "hit").functionCounter();
        assertThat(aciertos).isNotNull();
        assertThat(aciertos.count()).isEqualTo(1.0);
    }
}
