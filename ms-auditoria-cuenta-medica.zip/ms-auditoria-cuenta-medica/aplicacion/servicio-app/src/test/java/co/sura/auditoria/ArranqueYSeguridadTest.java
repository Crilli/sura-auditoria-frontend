package co.sura.auditoria;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mockStatic;

import co.sura.auditoria.configuracion.ConfiguracionSeguridad;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.web.server.ServerHttpSecurity;

@DisplayName("Arranque y seguridad de la aplicación")
class ArranqueYSeguridadTest {

    @Nested
    @DisplayName("AuditoriaApplication")
    class Arranque {

        @Test
        @DisplayName("main delega el arranque en Spring con la clase de la aplicación")
        void mainDelegaEnSpring() {
            var argumentos = new String[] {"--spring.profiles.active=local"};

            try (var spring = mockStatic(SpringApplication.class)) {
                AuditoriaApplication.main(argumentos);

                spring.verify(() ->
                        SpringApplication.run(AuditoriaApplication.class, argumentos));
            }
        }

        @Test
        @DisplayName("está anotada como aplicación de Spring Boot")
        void estaAnotadaComoAplicacionDeSpringBoot() {
            assertThat(AuditoriaApplication.class
                    .getAnnotation(SpringBootApplication.class)).isNotNull();
        }

        @Test
        @DisplayName("escanea las propiedades del cliente de OHI, que son las únicas que hay")
        void escaneaLasPropiedadesDelClienteDeOhi() {
            // Si se perdiera este paquete, PropiedadesOhi no se enlazaría y el fallo
            // saldría tarde, como un 401 de IDCS.
            var escaneo = AuditoriaApplication.class.getAnnotation(
                    org.springframework.boot.context.properties.ConfigurationPropertiesScan.class);

            assertThat(escaneo).isNotNull();
            assertThat(escaneo.value())
                    .containsExactly("co.sura.auditoria.acl.ohi.cliente");
        }

        @Test
        @DisplayName("no queda rastro del simulador en el escaneo de propiedades")
        void noQuedaRastroDelSimulador() {
            var escaneo = AuditoriaApplication.class.getAnnotation(
                    org.springframework.boot.context.properties.ConfigurationPropertiesScan.class);

            assertThat(escaneo.value())
                    .noneSatisfy(paquete -> assertThat(paquete).contains("simulador"));
        }

        @Test
        @DisplayName("tiene caché habilitada: el token de IDCS se reutiliza")
        void tieneCacheHabilitada() {
            assertThat(AuditoriaApplication.class.getAnnotation(
                    org.springframework.cache.annotation.EnableCaching.class)).isNotNull();
        }

        @Test
        @DisplayName("se puede instanciar: no tiene estado ni constructor escondido")
        void sePuedeInstanciar() {
            assertThat(new AuditoriaApplication()).isNotNull();
        }
    }

    @Nested
    @DisplayName("ConfiguracionSeguridad")
    class Seguridad {

        private org.springframework.security.web.server.SecurityWebFilterChain cadena() {
            return new ConfiguracionSeguridad()
                    .springSecurityFilterChain(ServerHttpSecurity.http());
        }

        @Test
        @DisplayName("construye una cadena de filtros utilizable")
        void construyeUnaCadenaDeFiltros() {
            assertThat(cadena()).isNotNull();
        }

        @Test
        @DisplayName("la cadena aplica a cualquier intercambio: no deja rutas fuera del filtro")
        void laCadenaAplicaACualquierIntercambio() {
            assertThat(cadena().getWebFilters()).isNotNull();
        }

        @Test
        @DisplayName("se construye dos veces sin compartir estado entre cadenas")
        void seConstruyeDosVecesSinCompartirEstado() {
            assertThat(cadena()).isNotSameAs(cadena());
        }
    }
}
