package co.sura.auditoria.configuracion;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import co.sura.auditoria.casodeuso.ComprobadorDeNovedades;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivos;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

@DisplayName("Configuración de la aplicación")
class ConfiguracionDeLaAplicacionTest {

    @Nested
    @DisplayName("CasosDeUsoConfig — la raíz de composición")
    class RaizDeComposicion {

        private static final Map<Class<?>, Object> DOBLES = Map.of(
                PuertoConsultaCuentas.class,      mock(PuertoConsultaCuentas.class),
                PuertoComandosCuenta.class,       mock(PuertoComandosCuenta.class),
                PuertoPendientes.class,           mock(PuertoPendientes.class),
                PuertoNotas.class,                mock(PuertoNotas.class),
                PuertoCatalogoNovedades.class,    mock(PuertoCatalogoNovedades.class),
                PuertoCatalogoMotivos.class,      mock(PuertoCatalogoMotivos.class),
                // El de PENDIENTES, que es otro catálogo distinto del de desfinalización
                // (PuertoCatalogoMotivos) y del de mensajes (PuertoCatalogoNovedades).
                co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente.class,
                        mock(co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente.class),
                // La historia de la cuenta, que une claimstatushistory y
                // claimunfinalizereasons: dos recursos de solo lectura.
                co.sura.auditoria.modelo.puertos.PuertoHistoriaCuenta.class,
                        mock(co.sura.auditoria.modelo.puertos.PuertoHistoriaCuenta.class),
                // El buscador: «cuáles hay», otra pregunta que «qué tiene esta cuenta».
                co.sura.auditoria.modelo.puertos.PuertoBusquedaCuentas.class,
                        mock(co.sura.auditoria.modelo.puertos.PuertoBusquedaCuentas.class),
                PublicadorEventosAuditoria.class, mock(PublicadorEventosAuditoria.class));

        static List<Method> metodosBean() {
            return Arrays.stream(CasosDeUsoConfig.class.getDeclaredMethods())
                    .filter(m -> m.isAnnotationPresent(Bean.class))
                    .sorted(java.util.Comparator.comparing(Method::getName))
                    .toList();
        }

        /** Resuelve el argumento de un bean: un puerto doble, otro bean, o un valor configurado. */
        private Object argumentoPara(Parameter parametro, CasosDeUsoConfig config)
                throws Exception {
            var tipo = parametro.getType();
            var doble = DOBLES.get(tipo);
            if (doble != null) return doble;
            if (tipo == ComprobadorDeNovedades.class) {
                return config.comprobadorDeNovedades(
                        (PuertoCatalogoNovedades) DOBLES.get(PuertoCatalogoNovedades.class));
            }
            // Valores que vienen de application.yml, no del grafo de objetos.
            if (tipo == java.time.Duration.class) return java.time.Duration.ofSeconds(2);
            if (tipo == long.class || tipo == Long.class) return 60L;
            if (tipo == int.class || tipo == Integer.class) return 25;
            if (tipo == boolean.class || tipo == Boolean.class) return Boolean.FALSE;
            if (tipo == String.class) return "valor";
            throw new IllegalStateException(
                    "El bean pide un tipo que la prueba no sabe construir: " + tipo.getName());
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("metodosBean")
        @DisplayName("cada bean se construye con los puertos dobles y no devuelve null")
        void cadaBeanSeConstruye(Method metodo) throws Exception {
            var config = new CasosDeUsoConfig();
            var argumentos = new Object[metodo.getParameterCount()];
            for (int i = 0; i < argumentos.length; i++) {
                argumentos[i] = argumentoPara(metodo.getParameters()[i], config);
            }

            assertThat(metodo.invoke(config, argumentos))
                    .as("el bean %s", metodo.getName())
                    .isNotNull();
        }

        /** Paquetes de infraestructura: nada de aquí debe aparecer en la firma de un bean. */
        private static final List<String> PAQUETES_DE_INFRAESTRUCTURA = List.of(
                "co.sura.auditoria.acl",
                "co.sura.auditoria.persistencia",
                "co.sura.auditoria.eventos",
                "co.sura.auditoria.api");

        @Test
        @DisplayName("ningún bean depende de un tipo de infraestructura, solo de puertos y valores")
        void ningunBeanDependeDeInfraestructura() {
            // Aquí se cablean las implementaciones, pero la configuración debe pedirlas
            // por su puerto. Si apareciera un AdaptadorXxxOhi en una firma, la hexagonal
            // se habría roto justo en el único sitio donde parece aceptable cablear cosas.
            for (var metodo : metodosBean()) {
                for (var parametro : metodo.getParameters()) {
                    var nombre = parametro.getType().getName();
                    assertThat(PAQUETES_DE_INFRAESTRUCTURA)
                            .as("el bean %s pide %s", metodo.getName(), nombre)
                            .noneSatisfy(paquete -> assertThat(nombre).startsWith(paquete));
                }
            }
        }

        @Test
        @DisplayName("todo bean devuelve un caso de uso del dominio, no un tipo de infraestructura")
        void todoBeanDevuelveUnTipoDelDominio() {
            for (var metodo : metodosBean()) {
                assertThat(metodo.getReturnType().getName())
                        .as("el bean %s", metodo.getName())
                        .startsWith("co.sura.auditoria.");
                assertThat(PAQUETES_DE_INFRAESTRUCTURA)
                        .noneSatisfy(p -> assertThat(metodo.getReturnType().getName())
                                .startsWith(p));
            }
        }

        @Test
        @DisplayName("declara un bean por cada caso de uso que la aplicación necesita")
        void declaraUnBeanPorCadaCasoDeUso() {
            assertThat(metodosBean()).hasSizeGreaterThanOrEqualTo(16);
        }
    }

    @Nested
    @DisplayName("ConfiguracionCors")
    class Cors {

        private CorsConfigurationSource fuenteCon(List<String> origenes) {
            return new ConfiguracionCors().corsConfigurationSource(origenes);
        }

        /** Se consulta la fuente como lo hace WebFlux: por la ruta de un intercambio. */
        private org.springframework.web.cors.CorsConfiguration paraRuta(List<String> origenes,
                                                                        String ruta) {
            var peticion = mock(org.springframework.http.server.reactive.ServerHttpRequest.class);
            var rutaPeticion = mock(org.springframework.http.server.RequestPath.class);
            var intercambio = mock(org.springframework.web.server.ServerWebExchange.class);
            org.mockito.Mockito.when(intercambio.getRequest()).thenReturn(peticion);
            org.mockito.Mockito.when(peticion.getPath()).thenReturn(rutaPeticion);
            org.mockito.Mockito.when(rutaPeticion.pathWithinApplication())
                    .thenReturn(org.springframework.http.server.PathContainer.parsePath(ruta));

            return fuenteCon(origenes).getCorsConfiguration(intercambio);
        }

        private org.springframework.web.cors.CorsConfiguration configuracionDe(
                List<String> origenes) {
            return paraRuta(origenes, "/api/v1/cuentas/CM-1");
        }

        @Test
        @DisplayName("la fuente es la reactiva basada en rutas")
        void laFuenteEsLaReactivaBasadaEnRutas() {
            assertThat(fuenteCon(List.of("http://localhost:4200")))
                    .isInstanceOf(UrlBasedCorsConfigurationSource.class);
        }

        @Test
        @DisplayName("una ruta de /api sí recibe configuración CORS")
        void unaRutaDeApiRecibeCors() {
            assertThat(configuracionDe(List.of("http://localhost:4200"))).isNotNull();
        }

        @Test
        @DisplayName("una ruta FUERA de /api no recibe ninguna: el CORS no se abre en todo el servidor")
        void unaRutaFueraDeApiNoRecibeCors() {
            assertThat(paraRuta(List.of("http://localhost:4200"), "/actuator/health")).isNull();
        }

        @Test
        @DisplayName("respeta exactamente los orígenes configurados, sin añadir comodines")
        void respetaLosOrigenesConfigurados() {
            var origenes = List.of("http://localhost:4200", "https://auditoria.sura.com.co");

            assertThat(configuracionDe(origenes).getAllowedOrigins())
                    .containsExactlyElementsOf(origenes)
                    .doesNotContain("*");
        }

        @Test
        @DisplayName("permite los métodos que el API usa, incluido PATCH")
        void permiteLosMetodosDelApi() {
            assertThat(configuracionDe(List.of("http://localhost:4200")).getAllowedMethods())
                    .contains("GET", "POST", "PATCH", "OPTIONS");
        }

        @Test
        @DisplayName("el preflight se cachea una hora, para no repetirlo en cada llamada")
        void elPreflightSeCacheaUnaHora() {
            assertThat(configuracionDe(List.of("http://localhost:4200")).getMaxAge())
                    .isEqualTo(3600L);
        }
    }
}
