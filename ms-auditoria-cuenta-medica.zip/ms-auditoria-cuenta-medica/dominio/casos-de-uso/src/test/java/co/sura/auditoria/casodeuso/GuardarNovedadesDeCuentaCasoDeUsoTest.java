package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("GuardarNovedadesDeCuentaCasoDeUso")
class GuardarNovedadesDeCuentaCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final String AUTOR = "auditor@sura.com.co";
    private static final Version VERSION = new Version(26L);

    @Mock PuertoConsultaCuentas consultas;
    @Mock PuertoComandosCuenta comandos;
    @Mock PublicadorEventosAuditoria publicador;
    @Mock ComprobadorDeNovedades comprobador;
    @InjectMocks GuardarNovedadesDeCuentaCasoDeUso casoDeUso;

    private static CuentaMedica cuenta(Version version) {
        return new CuentaMedica(CODIGO, EstadoCuenta.MODIFICACION, LocalDate.now(),
                LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN, version,
                List.of(), List.of(), null, List.of());
    }

    private ErrorDeDominio errorDe(Mono<CuentaMedica> resultado) {
        var capturado = new ErrorDeDominio[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(e -> capturado[0] = ((ExcepcionDeDominio) e).error())
                .verify();
        return capturado[0];
    }

    @Test
    @DisplayName("sin cambios no se hace nada, ni siquiera se busca la cuenta")
    void sinCambiosNoSeHaceNada() {
        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, VERSION, List.of(), AUTOR)))
                .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, VERSION, null, AUTOR)))
                .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);

        verify(consultas, never()).buscarPorCodigo(any());
    }

    @Test
    @DisplayName("si la cuenta no existe, CuentaNoEncontrada")
    void siLaCuentaNoExiste() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.empty());

        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, VERSION,
                List.of(CambioNovedad.agregar("332-1")), AUTOR)))
                .isInstanceOf(ErrorDeDominio.CuentaNoEncontrada.class);
    }

    @Nested
    @DisplayName("cerrojo de versión")
    class CerrojoDeVersion {

        @Test
        @DisplayName("si la versión no coincide, ModificacionConcurrente y no se aplica nada")
        void siLaVersionNoCoincideNoSeAplicaNada() {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(new Version(27L))));
            lenient().when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
            lenient().when(comandos.aplicarCambiosDeNovedadDeCabecera(any(), any(), any()))
                    .thenReturn(Mono.just(cuenta(VERSION)));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, VERSION,
                    List.of(CambioNovedad.agregar("332-1")), AUTOR));

            assertThat(error).isInstanceOf(ErrorDeDominio.ModificacionConcurrente.class);
            assertThat(((ErrorDeDominio.ModificacionConcurrente) error).recurso())
                    .isEqualTo("cuenta:CM-108800618430");
            verify(publicador, never()).publicar(any());
        }

        @Test
        @DisplayName("con la versión correcta se sigue adelante")
        void conLaVersionCorrectaSeSigue() {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(VERSION)));
            when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
            when(comandos.aplicarCambiosDeNovedadDeCabecera(any(), any(), any()))
                    .thenReturn(Mono.just(cuenta(new Version(27L))));
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, VERSION,
                            List.of(CambioNovedad.agregar("332-1")), AUTOR))
                    .expectNextCount(1).verifyComplete();
        }
    }

    @Test
    @DisplayName("se aplica con la versión LEÍDA de la cuenta, no con la que mandó el cliente")
    void seAplicaConLaVersionLeida() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(VERSION)));
        when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
        when(comandos.aplicarCambiosDeNovedadDeCabecera(any(), any(), any()))
                .thenReturn(Mono.just(cuenta(new Version(27L))));
        when(publicador.publicar(any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, VERSION,
                        List.of(CambioNovedad.agregar("332-1")), AUTOR))
                .expectNextCount(1).verifyComplete();

        verify(comandos).aplicarCambiosDeNovedadDeCabecera(eqCodigo(), eqVersion(), any());
    }

    private static CodigoCuenta eqCodigo() {
        return org.mockito.ArgumentMatchers.eq(CODIGO);
    }

    private static Version eqVersion() {
        return org.mockito.ArgumentMatchers.eq(VERSION);
    }

    @Test
    @DisplayName("si el comprobador rechaza, no se aplica ningún cambio")
    void siElComprobadorRechazaNoSeAplicaNada() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(VERSION)));
        when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.error(
                ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida("código inválido"))));
        lenient().when(comandos.aplicarCambiosDeNovedadDeCabecera(any(), any(), any()))
                .thenReturn(Mono.just(cuenta(VERSION)));

        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, VERSION,
                List.of(CambioNovedad.agregar("INVENTADO")), AUTOR)))
                .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);

        verify(publicador, never()).publicar(any());
    }

    @Nested
    @DisplayName("traza")
    class Traza {

        private void flujoFeliz() {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(VERSION)));
            when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
            when(comandos.aplicarCambiosDeNovedadDeCabecera(any(), any(), any()))
                    .thenReturn(Mono.just(cuenta(new Version(27L))));
        }

        @Test
        @DisplayName("resume las altas por código y las bajas por cantidad")
        void resumeAltasYBajas() {
            flujoFeliz();
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, VERSION, List.of(
                            CambioNovedad.agregar("332-1"),
                            CambioNovedad.agregar("NEGACION_010"),
                            CambioNovedad.eliminar(5L)), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .contains("novedades puestas: 332-1, NEGACION_010")
                    .contains("novedades quitadas: 1");
        }

        @Test
        @DisplayName("solo altas: el detalle no menciona quitadas")
        void soloAltas() {
            flujoFeliz();
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, VERSION,
                            List.of(CambioNovedad.agregar("332-1")), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .contains("novedades puestas")
                    .doesNotContain("quitadas");
        }

        @Test
        @DisplayName("si falla la traza, el cambio ya aplicado no se pierde")
        void siFallaLaTrazaElCambioNoSePierde() {
            flujoFeliz();
            when(publicador.publicar(any()))
                    .thenReturn(Mono.error(new IllegalStateException("bus caído")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, VERSION,
                            List.of(CambioNovedad.agregar("332-1")), AUTOR))
                    .expectNextCount(1)
                    .verifyComplete();
        }
    }

    @Test
    @org.junit.jupiter.api.Tag("OPE-11")
    @DisplayName("si las novedades se aplicaron pero no se pudo releer la cuenta, la traza queda y el error sigue")
    void aplicadoSinRelecturaDejaTraza() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(VERSION)));
        when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
        when(comandos.aplicarCambiosDeNovedadDeCabecera(any(), any(), any()))
                .thenReturn(Mono.error(co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(new co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura("x", "timeout"))));
        when(publicador.publicar(any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, VERSION, List.of(CambioNovedad.agregar("332-1")), AUTOR))
                .expectErrorSatisfies(e -> assertThat(((co.sura.auditoria.modelo.error.ExcepcionDeDominio) e).error())
                        .isInstanceOf(co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura.class))
                .verify();
        verify(publicador).publicar(any());
    }
}
