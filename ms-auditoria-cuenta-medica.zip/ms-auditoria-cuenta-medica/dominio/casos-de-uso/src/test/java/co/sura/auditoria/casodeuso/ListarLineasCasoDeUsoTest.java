package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * El listado pagina por desplazamiento.
 *
 * <p>Lo que antes se comprobaba aquí y ya no está: <b>cuándo se pide el total</b>.
 * Esa decisión dejó de ser del caso de uso —no tiene con qué tomarla— y es de la
 * capa de integración, que es la única que sabe si el filtro se pudo empujar
 * entero. Su cobertura se fue con ella, a
 * {@code AdaptadorLineasDesplazadasOhiTest}.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ListarLineasCasoDeUso")
class ListarLineasCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    @Mock PuertoConsultaCuentas consultas;
    @InjectMocks ListarLineasCasoDeUso casoDeUso;

    @Captor ArgumentCaptor<Integer> tamanoCaptor;
    @Captor ArgumentCaptor<Integer> desplazamientoCaptor;
    @Captor ArgumentCaptor<FiltroLineas> filtroCaptor;

    private void devuelvePagina() {
        when(consultas.listarResumenLineasPorDesplazamiento(any(), anyInt(), anyInt(), any(), any()))
                .thenReturn(Mono.just(PaginaDesplazada.<ResumenLinea>vacia(25)));
    }

    @Nested
    @DisplayName("tamaño de página")
    class TamanoDePagina {

        @ParameterizedTest(name = "{0} cae al predeterminado")
        @NullSource
        @ValueSource(ints = {0, -5})
        @DisplayName("nulo, cero y negativos caen al predeterminado de 25")
        void nuloCeroYNegativosCaenAlPredeterminado(Integer solicitado) {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, 0, solicitado))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), anyInt(), tamanoCaptor.capture(), any(), any());
            assertThat(tamanoCaptor.getValue())
                    .isEqualTo(ListarLineasCasoDeUso.TAMANO_PAGINA_PREDETERMINADO);
        }

        @Test
        @DisplayName("por encima del máximo se recorta a 25")
        void porEncimaDelMaximoSeRecorta() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, 0, 9999))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), anyInt(), tamanoCaptor.capture(), any(), any());
            assertThat(tamanoCaptor.getValue())
                    .isEqualTo(ListarLineasCasoDeUso.TAMANO_PAGINA_MAXIMO);
        }
    }

    @Nested
    @DisplayName("desplazamiento")
    class Desplazamiento {

        @Test
        @DisplayName("viaja al puerto tal como se pidió")
        void viajaAlPuertoTalComoSePidio() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, 4025, 25))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isEqualTo(4025);
        }

        @ParameterizedTest(name = "{0} se trata como el principio")
        @ValueSource(ints = {-1, -4025})
        @DisplayName("un desplazamiento negativo no viaja: se trata como el principio")
        void unDesplazamientoNegativoSeTrataComoElPrincipio(int pedido) {
            // El sistema de registro no rechaza un offset negativo: lo interpreta
            // a su manera. Se normaliza aquí para que la página 0 sea la página 0.
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, pedido, 25))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isZero();
        }

        @Test
        @DisplayName("un desplazamiento profundo no se recorta: a la última página se llega")
        void unDesplazamientoProfundoNoSeRecorta() {
            // El tope de 200 del sistema de registro es del tamaño de página, no
            // del desplazamiento. Recortarlo aquí dejaría inalcanzable la última
            // página de una cuenta grande, que es justo lo que este cambio arregla.
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, 1_000_000, 25))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), desplazamientoCaptor.capture(), anyInt(), any(), any());
            assertThat(desplazamientoCaptor.getValue()).isEqualTo(1_000_000);
        }
    }

    @Nested
    @DisplayName("filtro")
    class Filtro {

        @Test
        @DisplayName("un filtro nulo se sustituye por NINGUNO, no viaja nulo al puerto")
        void unFiltroNuloSeSustituyePorNinguno() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, 0, 25, null))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue()).isEqualTo(FiltroLineas.NINGUNO);
        }

        @Test
        @DisplayName("la sobrecarga sin filtro usa NINGUNO")
        void laSobrecargaSinFiltroUsaNinguno() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, 0, 25))
                    .expectNextCount(1).verifyComplete();

            verify(consultas).listarResumenLineasPorDesplazamiento(
                    any(), anyInt(), anyInt(), filtroCaptor.capture(), any());
            assertThat(filtroCaptor.getValue()).isEqualTo(FiltroLineas.NINGUNO);
        }
    }
}
