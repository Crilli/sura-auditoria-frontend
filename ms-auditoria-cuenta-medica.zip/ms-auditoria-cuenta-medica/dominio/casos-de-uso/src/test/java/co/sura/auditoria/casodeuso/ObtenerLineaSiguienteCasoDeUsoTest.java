package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ObtenerLineaSiguienteCasoDeUso")
class ObtenerLineaSiguienteCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-35343660784");
    private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(46_056_167_063L);

    @Mock PuertoConsultaCuentas consultas;
    @InjectMocks ObtenerLineaSiguienteCasoDeUso casoDeUso;

    private static ResumenLinea linea(int numero) {
        return new ResumenLinea(new ReferenciaLinea(1L), numero,
                LocalDate.now(), LocalDate.now(), "CC1", "Afiliado", "873206", "desc",
                "CUPS", "AUT1", BigDecimal.TEN, BigDecimal.TEN, BigDecimal.ZERO,
                false, false, false, false, 0, List.of(), false, List.of(), new Version(1L), null, null, null, null, null);
    }

    @Test
    @DisplayName("devuelve la línea que entrega el sistema de registro")
    void devuelveLaLineaQueEntrega() {
        when(consultas.buscarLineaSiguiente(CODIGO, REFERENCIA))
                .thenReturn(Mono.just(linea(102)));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, REFERENCIA))
                .assertNext(l -> assertThat(l.numeroLinea()).isEqualTo(102))
                .verifyComplete();

        verify(consultas).buscarLineaSiguiente(CODIGO, REFERENCIA);
    }

    @Test
    @DisplayName("vacío cuando era la última: es respuesta, no error")
    void vacioCuandoEraLaUltima() {
        when(consultas.buscarLineaSiguiente(CODIGO, REFERENCIA)).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, REFERENCIA)).verifyComplete();
    }
}
