package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendienteCatalogo;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.SeleccionLineas;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("AgregarMotivoPendienteCasoDeUso")
class AgregarMotivoPendienteCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-94421");
    private static final String AUTOR = "auditor@sura.com.co";
    private static final SeleccionLineas UNA =
            SeleccionLineas.de(List.of(new ReferenciaLinea(135277L)));

    @Mock PuertoPendientes               pendientes;
    @Mock PuertoCatalogoMotivosPendiente catalogo;
    @Mock PublicadorEventosAuditoria     publicador;

    AgregarMotivoPendienteCasoDeUso casoDeUso;

    @BeforeEach
    void preparar() {
        casoDeUso = new AgregarMotivoPendienteCasoDeUso(pendientes, catalogo, publicador);
        lenient().when(publicador.publicar(any(EventoAuditoria.class))).thenReturn(Mono.empty());
    }

    private void catalogoTiene(String... codigos) {
        when(catalogo.listar()).thenReturn(Mono.just(
                java.util.Arrays.stream(codigos)
                        .map(c -> new MotivoPendienteCatalogo(c, "texto de " + c, false))
                        .toList()));
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("con líneas elegidas se pone a nivel de línea y con ese alcance")
    void conLineasSePoneANivelDeLinea() {
        catalogoTiene("MP_FATAL_SIN_GLOSA");
        when(pendientes.agregarMotivo(any(), any(), any(), any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "MP_FATAL_SIN_GLOSA", UNA, AUTOR))
                .verifyComplete();

        verify(pendientes).agregarMotivo(CODIGO, "MP_FATAL_SIN_GLOSA",
                                         NivelPendiente.LINEA, UNA);
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("sin líneas se pone en la cabecera, no en todas las líneas")
    void sinLineasSePoneEnLaCabecera() {
        // Son los dos niveles disjuntos del sistema de registro. Interpretar «sin líneas»
        // como «todas las líneas» pondría el pendiente en cada una de las 4.063 de una
        // cuenta grande, que no es lo que nadie quiso.
        catalogoTiene("MP_FATAL_SIN_GLOSA");
        when(pendientes.agregarMotivo(any(), any(), any(), any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "MP_FATAL_SIN_GLOSA",
                                               SeleccionLineas.TODAS, AUTOR))
                .verifyComplete();

        verify(pendientes).agregarMotivo(CODIGO, "MP_FATAL_SIN_GLOSA",
                                         NivelPendiente.CABECERA, SeleccionLineas.TODAS);
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("un motivo que no está en el catálogo se nombra, y no se llega a OHI")
    void unMotivoFueraDelCatalogoSeNombra() {
        // El sistema de registro lo rechazaría con «no pudo encontrar PendReason{code=…}»,
        // que no distingue «te lo inventaste» de «el catálogo no responde».
        catalogoTiene("MP_FATAL_SIN_GLOSA");

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "MP_INVENTADO", UNA, AUTOR))
                .expectErrorSatisfies(e -> assertThat(e.getMessage() + e.toString())
                        .contains("DecisionEnvioInvalida"))
                .verify();

        verify(pendientes, never()).agregarMotivo(any(), any(), any(), any());
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("el código se compara sin distinguir mayúsculas, y se manda recortado")
    void elCodigoSeComparaSinCaja() {
        catalogoTiene("MP_FATAL_SIN_GLOSA");
        when(pendientes.agregarMotivo(any(), any(), any(), any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "  mp_fatal_sin_glosa  ", UNA, AUTOR))
                .verifyComplete();

        verify(pendientes).agregarMotivo(eq(CODIGO), eq("mp_fatal_sin_glosa"), any(), any());
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("sin auditor no se pone nada: poner un pendiente frena la cuenta")
    void sinAuditorNoSePoneNada() {
        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "MP_FATAL_SIN_GLOSA", UNA, "  "))
                .expectError().verify();

        verify(pendientes, never()).agregarMotivo(any(), any(), any(), any());
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("sin motivo tampoco, y se dice antes de consultar el catálogo")
    void sinMotivoTampoco() {
        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "   ", UNA, AUTOR))
                .expectError().verify();

        verify(catalogo, never()).listar();
    }

    @Test
    @Tag("DBG-05")
    @DisplayName("si la traza falla, el pendiente puesto no se deshace")
    void siLaTrazaFallaNoSeDeshace() {
        catalogoTiene("MP_FATAL_SIN_GLOSA");
        when(pendientes.agregarMotivo(any(), any(), any(), any())).thenReturn(Mono.empty());
        when(publicador.publicar(any(EventoAuditoria.class)))
                .thenReturn(Mono.error(new IllegalStateException("el bus no responde")));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, "MP_FATAL_SIN_GLOSA", UNA, AUTOR))
                .verifyComplete();
    }
}
