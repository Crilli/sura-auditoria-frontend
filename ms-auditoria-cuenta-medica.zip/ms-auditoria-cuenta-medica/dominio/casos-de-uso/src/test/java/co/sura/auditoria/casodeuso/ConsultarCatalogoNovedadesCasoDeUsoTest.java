package co.sura.auditoria.casodeuso;

import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.Severidad;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ConsultarCatalogoNovedadesCasoDeUso")
class ConsultarCatalogoNovedadesCasoDeUsoTest {

    @Mock PuertoCatalogoNovedades catalogo;
    @InjectMocks ConsultarCatalogoNovedadesCasoDeUso casoDeUso;

    private static MensajeCatalogo mensaje(String codigo, String texto) {
        return new MensajeCatalogo(codigo, texto, Severidad.INFORMATIVA, null, null, false);
    }

    private static MensajeCatalogo clasificado(String codigo, String generico,
                                               String especifico) {
        return new MensajeCatalogo(codigo, "texto", Severidad.INFORMATIVA,
                new Novedad.Clasificacion("G", generico),
                new Novedad.Clasificacion("E", especifico), false);
    }

    private void catalogoCon(MensajeCatalogo... mensajes) {
        when(catalogo.listar()).thenReturn(Mono.just(List.of(mensajes)));
    }

    private void esperarCodigos(String busqueda, String... esperados) {
        StepVerifier.create(casoDeUso.ejecutar(busqueda)
                        .map(l -> l.stream().map(MensajeCatalogo::codigo).toList()))
                .expectNext(List.of(esperados))
                .verifyComplete();
    }

    @Nested
    @DisplayName("sin búsqueda")
    class SinBusqueda {

        @ParameterizedTest(name = "búsqueda [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        @DisplayName("devuelve el catálogo entero, ordenado por código")
        void devuelveElCatalogoEnteroOrdenado(String busqueda) {
            catalogoCon(mensaje("Z99", "uno"), mensaje("A01", "dos"), mensaje("M50", "tres"));

            esperarCodigos(busqueda, "A01", "M50", "Z99");
        }

        @Test
        @DisplayName("un catálogo vacío devuelve lista vacía, no error")
        void unCatalogoVacioDevuelveListaVacia() {
            catalogoCon();

            StepVerifier.create(casoDeUso.ejecutar(null))
                    .assertNext(l -> org.assertj.core.api.Assertions.assertThat(l).isEmpty())
                    .verifyComplete();
        }

        @Test
        @DisplayName("un código nulo se ordena al final, sin reventar la comparación")
        void unCodigoNuloSeOrdenaAlFinal() {
            catalogoCon(mensaje(null, "sin código"), mensaje("A01", "con código"));

            StepVerifier.create(casoDeUso.ejecutar(null)
                            .map(l -> l.stream().map(MensajeCatalogo::codigo).toList()))
                    .assertNext(codigos -> org.assertj.core.api.Assertions.assertThat(codigos)
                            .containsExactly("A01", null))
                    .verifyComplete();
        }
    }

    @Nested
    @DisplayName("búsqueda")
    class Busqueda {

        @Test
        @DisplayName("casa por código")
        void casaPorCodigo() {
            catalogoCon(mensaje("SURA-AUT-002", "x"), mensaje("332-1", "y"));

            esperarCodigos("aut", "SURA-AUT-002");
        }

        @Test
        @DisplayName("casa por el texto del mensaje")
        void casaPorTexto() {
            catalogoCon(mensaje("A01", "Procedimiento no autorizado"),
                        mensaje("B02", "Tarifa superior"));

            esperarCodigos("tarifa", "B02");
        }

        @Test
        @DisplayName("casa por la clasificación genérica y por la específica")
        void casaPorClasificacion() {
            catalogoCon(clasificado("A01", "Tarifas", "Ayudas diagnósticas"),
                        clasificado("B02", "Pertinencia", "Medicamentos"));

            esperarCodigos("ayudas", "A01");
            esperarCodigos("pertinencia", "B02");
        }

        @Test
        @DisplayName("no distingue mayúsculas")
        void noDistingueMayusculas() {
            catalogoCon(mensaje("A01", "Procedimiento NO AUTORIZADO"));

            esperarCodigos("autorizado", "A01");
        }

        @Test
        @DisplayName("ignora las tildes en los dos sentidos: buscar «diagnostico» encuentra «diagnóstico»")
        void ignoraLasTildes() {
            catalogoCon(mensaje("A01", "Ayuda diagnóstica no pertinente"));

            esperarCodigos("diagnostica", "A01");
        }

        @Test
        @DisplayName("y al revés: buscar con tilde encuentra lo escrito sin ella")
        void ignoraLasTildesAlReves() {
            catalogoCon(mensaje("A01", "Ayuda diagnostica"));

            esperarCodigos("diagnóstica", "A01");
        }

        @Test
        @DisplayName("los resultados filtrados también salen ordenados")
        void losFiltradosTambienSalenOrdenados() {
            catalogoCon(mensaje("Z01", "glosa"), mensaje("A01", "glosa"),
                        mensaje("M01", "otra cosa"));

            esperarCodigos("glosa", "A01", "Z01");
        }

        @Test
        @DisplayName("una búsqueda sin coincidencias devuelve lista vacía")
        void sinCoincidenciasDevuelveListaVacia() {
            catalogoCon(mensaje("A01", "texto"));

            esperarCodigos("nada-que-ver");
        }

        @Test
        @DisplayName("un mensaje con campos nulos no rompe la búsqueda")
        void unMensajeConCamposNulosNoRompe() {
            catalogoCon(new MensajeCatalogo("A01", null, null, null, null, false));

            esperarCodigos("a01", "A01");
        }
    }

    @Test
    @DisplayName("un error del catálogo se propaga")
    void unErrorDelCatalogoSePropaga() {
        var caida = new IllegalStateException("OHI no responde");
        when(catalogo.listar()).thenReturn(Mono.error(caida));

        StepVerifier.create(casoDeUso.ejecutar(null))
                .expectErrorMatches(e -> e == caida)
                .verify();
    }
}
