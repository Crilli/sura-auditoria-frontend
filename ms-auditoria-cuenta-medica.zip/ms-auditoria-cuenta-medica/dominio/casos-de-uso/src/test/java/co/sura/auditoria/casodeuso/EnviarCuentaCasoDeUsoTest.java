package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.DecisionEnvio;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.TiqueteProceso;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("EnviarCuentaCasoDeUso")
class EnviarCuentaCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final String AUTOR = "auditor@sura.com.co";

    @Mock PuertoConsultaCuentas consultas;

    /** Sin caché en las pruebas: la consulta fresca dice lo mismo que la guardada. */
    @org.junit.jupiter.api.BeforeEach
    void frescasComoLasGuardadas() {
        org.mockito.Mockito.lenient().when(consultas.consultarAccionesFrescas(org.mockito.ArgumentMatchers.any()))
                .thenAnswer(inv -> consultas.consultarAccionesDisponibles(inv.getArgument(0)));
    }
    @Mock PuertoComandosCuenta comandos;
    @Mock PuertoPendientes pendientes;
    @Mock PublicadorEventosAuditoria publicador;
    @InjectMocks EnviarCuentaCasoDeUso casoDeUso;

    private static CuentaMedica cuenta(EstadoCuenta estado) {
        return new CuentaMedica(CODIGO, estado, LocalDate.now(), LocalDate.now(),
                BigDecimal.TEN, BigDecimal.TEN, new Version(26L), List.of(), List.of(), null, List.of());
    }

    private static MotivoPendiente pendiente(boolean soloAdjudicacion) {
        return new MotivoPendiente(1L, "AUD01", "Auditoría", false, soloAdjudicacion,
                NivelPendiente.CABECERA, null, null, new Version(1L));
    }

    private final TiqueteProceso tiquete = org.mockito.Mockito.mock(TiqueteProceso.class);

    private void cuentaEnviable(EstadoCuenta estado) {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(estado)));
        when(consultas.consultarAccionesDisponibles(CODIGO))
                .thenReturn(Mono.just(new AccionesDisponibles(Set.of(AccionCuenta.ENVIAR))));
    }

    private ErrorDeDominio errorDe(Mono<TiqueteProceso> resultado) {
        var capturado = new ErrorDeDominio[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(error -> capturado[0] =
                        ((ExcepcionDeDominio) error).error())
                .verify();
        return capturado[0];
    }

    @Nested
    @DisplayName("validación de la decisión")
    class ValidacionDeLaDecision {

        @Test
        @DisplayName("denegar sin código bloqueante se rechaza antes de tocar nada")
        void denegarSinCodigoSeRechazaAntesDeTocarNada() {
            var invalida = new DecisionEnvio(DecisionEnvio.Decision.DENEGAR, Optional.empty());

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, invalida, AUTOR)))
                    .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);

            verify(consultas, never()).buscarPorCodigo(any());
            verify(comandos, never()).enviar(any(), any(), any());
        }
    }

    @Nested
    @DisplayName("cuenta y acciones")
    class CuentaYAcciones {

        @Test
        @DisplayName("si la cuenta no existe, CuentaNoEncontrada")
        void siLaCuentaNoExiste() {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.empty());
            lenient().when(consultas.consultarAccionesDisponibles(CODIGO))
                    .thenReturn(Mono.just(AccionesDisponibles.ninguna()));

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR)))
                    .isInstanceOf(ErrorDeDominio.CuentaNoEncontrada.class);
        }

        @Test
        @Tag("BTN-13.7")  // el botón ya no se apaga: el rechazo del servicio es el que informa
        @DisplayName("si OHI no ofrece la acción ENVIAR, no se intenta enviar")
        void siNoSeOfreceLaAccionNoSeEnvia() {
            when(consultas.buscarPorCodigo(CODIGO))
                    .thenReturn(Mono.just(cuenta(EstadoCuenta.FINALIZADA)));
            when(consultas.consultarAccionesDisponibles(CODIGO))
                    .thenReturn(Mono.just(AccionesDisponibles.ninguna()));

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR)))
                    .isInstanceOf(ErrorDeDominio.AccionNoDisponible.class);

            verify(comandos, never()).enviar(any(), any(), any());
        }
    }

    @Nested
    @DisplayName("pendientes que frenan")
    class PendientesQueFrenan {

        @Test
        @Tag("BTN-13.7")
        @DisplayName("al aceptar se verifican, y un pendiente bloqueante corta el envío")
        void alAceptarUnPendienteBloqueanteCorta() {
            cuentaEnviable(EstadoCuenta.MODIFICACION);
            when(pendientes.listarSinResolver(CODIGO))
                    .thenReturn(Flux.just(pendiente(false)));
            // `verificacion.then(comandos.enviar(...))` construye el Mono de envío aunque
            // la verificación vaya a fallar, así que el puerto se invoca igualmente. Eso
            // no envía nada —el Mono nunca se suscribe—, pero impide afirmar never():
            // lo que de verdad se comprueba es que no sale tiquete.
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR));

            assertThat(error).isInstanceOf(ErrorDeDominio.PendientesBloqueanEnvio.class);
            assertThat(((ErrorDeDominio.PendientesBloqueanEnvio) error).cantidad()).isEqualTo(1);
            verify(publicador, never()).publicar(any());
        }

        @Test
        @DisplayName("un pendiente que no bloquea en ese estado deja pasar el envío")
        void unPendienteQueNoBloqueaDejaPasar() {
            // soloAdjudicacion fuera de ADJUDICACION_MANUAL no frena.
            cuentaEnviable(EstadoCuenta.MODIFICACION);
            when(pendientes.listarSinResolver(CODIGO)).thenReturn(Flux.just(pendiente(true)));
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR))
                    .expectNext(tiquete).verifyComplete();
        }

        @Test
        @Tag("BTN-13.7")  // «Aceptar» en adjudicación manual con un pendiente abierto
        @DisplayName("el mismo pendiente SÍ frena en ADJUDICACION_MANUAL")
        void elMismoPendienteFrenaEnAdjudicacionManual() {
            cuentaEnviable(EstadoCuenta.ADJUDICACION_MANUAL);
            when(pendientes.listarSinResolver(CODIGO)).thenReturn(Flux.just(pendiente(true)));
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR)))
                    .isInstanceOf(ErrorDeDominio.PendientesBloqueanEnvio.class);

            verify(publicador, never()).publicar(any());
        }

        @Test
        @DisplayName("al DENEGAR no se verifican los pendientes: denegar no los necesita resueltos")
        void alDenegarNoSeVerificanLosPendientes() {
            cuentaEnviable(EstadoCuenta.MODIFICACION);
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                            DecisionEnvio.denegar("SURA-CHK-063"), AUTOR))
                    .expectNext(tiquete).verifyComplete();

            verify(pendientes, never()).listarSinResolver(any());
        }
    }

    @Nested
    @DisplayName("envío y traza")
    class EnvioYTraza {

        @Test
        @Tag("BTN-13.3")  // «Aceptar» y «Enviar» son este mismo envío
        @DisplayName("envía con la versión de la cuenta, que es el cerrojo optimista")
        void enviaConLaVersionDeLaCuenta() {
            cuentaEnviable(EstadoCuenta.MODIFICACION);
            when(pendientes.listarSinResolver(CODIGO)).thenReturn(Flux.empty());
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR))
                    .expectNext(tiquete).verifyComplete();

            verify(comandos).enviar(CODIGO, new Version(26L), DecisionEnvio.aceptar());
        }

        @Test
        @DisplayName("deja traza del envío con el autor y la decisión")
        void dejaTrazaDelEnvio() {
            cuentaEnviable(EstadoCuenta.MODIFICACION);
            when(pendientes.listarSinResolver(CODIGO)).thenReturn(Flux.empty());
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = org.mockito.ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().autor()).isEqualTo(AUTOR);
            assertThat(captor.getValue().detalle()).contains("ACEPTAR");
        }

        @Test
        @DisplayName("si falla la traza, el envío NO se pierde: ya ocurrió en OHI")
        void siFallaLaTrazaElEnvioNoSePierde() {
            cuentaEnviable(EstadoCuenta.MODIFICACION);
            when(pendientes.listarSinResolver(CODIGO)).thenReturn(Flux.empty());
            when(comandos.enviar(any(), any(), any())).thenReturn(Mono.just(tiquete));
            when(publicador.publicar(any()))
                    .thenReturn(Mono.error(new IllegalStateException("bus caído")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, DecisionEnvio.aceptar(), AUTOR))
                    .expectNext(tiquete)
                    .verifyComplete();
        }
    }
}
