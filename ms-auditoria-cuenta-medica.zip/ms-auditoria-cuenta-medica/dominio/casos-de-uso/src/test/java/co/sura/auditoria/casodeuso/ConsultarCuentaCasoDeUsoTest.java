package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ConsultarCuentaCasoDeUso")
class ConsultarCuentaCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    @Mock PuertoConsultaCuentas consultas;
    @InjectMocks ConsultarCuentaCasoDeUso casoDeUso;

    private static CuentaMedica cuenta() {
        return new CuentaMedica(CODIGO, EstadoCuenta.FINALIZADA,
                LocalDate.of(2026, 8, 11), LocalDate.of(2026, 8, 11),
                new BigDecimal("38222"), new BigDecimal("38222"),
                new Version(1L), List.of(), List.of(), null, List.of());
    }

    @Test
    @DisplayName("devuelve la cuenta que encuentra el puerto")
    void devuelveLaCuentaQueEncuentra() {
        var esperada = cuenta();
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(esperada));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO))
                .expectNext(esperada)
                .verifyComplete();

        verify(consultas).buscarPorCodigo(CODIGO);
    }

    @Test
    @DisplayName("un Mono vacío se traduce a CuentaNoEncontrada, no a un resultado vacío")
    void unMonoVacioSeTraduceACuentaNoEncontrada() {
        // El 204 de OHI llega aquí como Mono.empty(). Dejarlo pasar daría una
        // respuesta vacía con 200 en vez del 404 que corresponde.
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO))
                .expectErrorSatisfies(error -> assertThat(error)
                        .isInstanceOf(ExcepcionDeDominio.class)
                        .extracting(e -> ((ExcepcionDeDominio) e).error())
                        .isEqualTo(new ErrorDeDominio.CuentaNoEncontrada("CM-108800618430")))
                .verify();
    }

    @Test
    @DisplayName("un error del puerto se propaga tal cual, sin enmascararlo")
    void unErrorDelPuertoSePropaga() {
        var caida = ExcepcionDeDominio.de(
                new ErrorDeDominio.SistemaRegistroNoDisponible("timeout"));
        when(consultas.buscarPorCodigo(any())).thenReturn(Mono.error(caida));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO))
                .expectErrorSatisfies(error -> assertThat(error).isSameAs(caida))
                .verify();
    }

    @Test
    @DisplayName("consulta el puerto una sola vez por ejecución")
    void consultaElPuertoUnaSolaVez() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta()));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO))
                .expectNextCount(1)
                .verifyComplete();

        verify(consultas, org.mockito.Mockito.times(1)).buscarPorCodigo(CODIGO);
    }
}
