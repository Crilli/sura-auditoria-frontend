package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * El cambio que alcanza varias líneas.
 *
 * <p>Lo que se fija aquí es el desenlace, que casi nunca es «bien» o «mal»: una línea bloqueada
 * o una que otro auditor acaba de tocar no son errores de la petición sino filas que no se
 * pudieron aplicar, y tirar las buenas por ellas sería peor que no hacer nada.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AplicarCambiosEnLoteCasoDeUso")
class AplicarCambiosEnLoteCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-35343660784");
    private static final String AUTOR = "auditor@sura.com.co";
    private static final ReferenciaLinea A = new ReferenciaLinea(10L);
    private static final ReferenciaLinea B = new ReferenciaLinea(20L);

    @Mock PuertoConsultaCuentas      consultas;
    @Mock PuertoComandosCuenta       comandos;
    @Mock PublicadorEventosAuditoria publicador;
    @Mock ComprobadorDeNovedades     comprobador;
    @Mock PuertoCatalogoNovedades    catalogo;

    AplicarCambiosEnLoteCasoDeUso casoDeUso;

    @Captor ArgumentCaptor<List<EdicionLinea>> edicionesCaptor;

    @BeforeEach
    void preparar() {
        casoDeUso = new AplicarCambiosEnLoteCasoDeUso(consultas, comandos, publicador, comprobador);
        lenient().when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
        lenient().when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta()));
        lenient().when(publicador.publicar(any(EventoAuditoria.class))).thenReturn(Mono.empty());
    }

    private static CuentaMedica cuenta() {
        return cuenta(EstadoCuenta.MODIFICACION);
    }

    private static CuentaMedica cuenta(EstadoCuenta estado) {
        return new CuentaMedica(CODIGO, estado, LocalDate.now(),
                LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN, new Version(26L),
                List.of(), List.of(), null, List.of());
    }

    private static LineaCuenta linea(ReferenciaLinea referencia, int numero, boolean bloqueada) {
        return new LineaCuenta(referencia, CODIGO, numero, LocalDate.now(), LocalDate.now(),
                "CC1", "Afiliado", "873206", "Radiografía", "CUPS",
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.TEN, BigDecimal.ONE,
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ZERO, null, "AUT1",
                "900011436-001", "Prestador", false, false, false, false,
                bloqueada, false, null, null, null,
                List.of(), List.of(), List.of(), List.of(), null, new Version(3L));
    }

    private static CambiosEnLote lote(ReferenciaLinea... referencias) {
        return new CambiosEnLote(
                SeleccionLineas.de(List.of(referencias)),
                List.of(CambioGlosa.agregar("TAR01", "G", "E", new BigDecimal("1500"), "texto")),
                List.of(), ModoRecalculo.AISLADO);
    }

    private void lineaEs(ReferenciaLinea referencia, LineaCuenta linea) {
        when(consultas.buscarDetalleLinea(CODIGO, referencia))
                .thenReturn(linea == null ? Mono.empty() : Mono.just(linea));
    }

    /**
     * El lote cambia datos de la cuenta: solo en modificación (2026-10-21). Fuera de ese estado
     * es un error de toda la operación y no un fallo por línea: ninguna línea tiene la culpa.
     */
    @Nested
    @DisplayName("estado de la cuenta")
    class EstadoDeLaCuenta {

        @ParameterizedTest(name = "{0}")
        @Tag("EST-01.6")
        @Tag("EST-01.3")
        @EnumSource(value = EstadoCuenta.class, names = "MODIFICACION",
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("[EST-01.6] fuera de MODIFICACION, un solo CuentaNoModificable y ninguna línea leída ni escrita")
        void fueraDeModificacionNoSeTocaNada(EstadoCuenta estado) {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(estado)));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                            .isEqualTo(new ErrorDeDominio.CuentaNoModificable(
                                    CODIGO.valor(), estado.name())))
                    .verify();

            verify(comprobador, never()).comprobar(any(), any(), any());
            verify(consultas, never()).buscarDetalleLinea(any(), any());
            verify(comandos, never()).aplicarEdicionesDeLinea(any(), any(), any());
            verify(publicador, never()).publicar(any());
        }

        @Test
        @Tag("EST-01.6")
        @DisplayName("[EST-01.6] fuera de MODIFICACION, un alta de novedad no lee el catálogo ni cambia el 409 por un 400")
        void unAltaFueraDeModificacionNoMiraElCatalogo() {
            // Con el comprobador de verdad y no el simulado: es él quien lee el catálogo, y con la
            // caché vacía esa lectura va al sistema de registro. El catálogo no ofrece el código,
            // así que si se mirase antes que el estado el error sería suyo (400 DECISION_INVALIDA)
            // y el auditor no leería que el remedio es pasar la cuenta a modificación.
            lenient().when(catalogo.listar()).thenReturn(Mono.just(List.of()));
            when(consultas.buscarPorCodigo(CODIGO))
                    .thenReturn(Mono.just(cuenta(EstadoCuenta.ADJUDICACION_MANUAL)));
            var conCatalogo = new AplicarCambiosEnLoteCasoDeUso(consultas, comandos, publicador,
                    new ComprobadorDeNovedades(catalogo));
            var poner = new CambiosEnLote(SeleccionLineas.de(List.of(A)), List.of(),
                    List.of(CambioNovedad.agregar("XX-1")), ModoRecalculo.AISLADO);

            StepVerifier.create(conCatalogo.ejecutar(CODIGO, poner, AUTOR))
                    .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                            .isEqualTo(new ErrorDeDominio.CuentaNoModificable(
                                    CODIGO.valor(), EstadoCuenta.ADJUDICACION_MANUAL.name())))
                    .verify();

            verify(catalogo, never()).listar();
            verify(consultas, never()).buscarDetalleLinea(any(), any());
            verify(comandos, never()).aplicarEdicionesDeLinea(any(), any(), any());
        }

        @Test
        @Tag("EST-01.6")
        @DisplayName("si entre el lote y el reintento la cuenta sale de MODIFICACION, el reintento no escribe")
        void elReintentoTambienExigeElEstado() {
            // El reintento relee la cabecera por la versión; con ella vuelve a mirar el estado.
            // Nada se aplicó —el parche es atómico—, así que el 409 dice la verdad.
            when(consultas.buscarPorCodigo(CODIGO))
                    .thenReturn(Mono.just(cuenta()))
                    .thenReturn(Mono.just(cuenta(EstadoCuenta.ADJUDICACION_MANUAL)));
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, linea(B, 37, false));
            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.error(ExcepcionDeDominio.de(
                            new ErrorDeDominio.LineaDelLoteRechazada(1, "la 37 está mal"))));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                            .isInstanceOf(ErrorDeDominio.CuentaNoModificable.class))
                    .verify();

            verify(comandos, times(1)).aplicarEdicionesDeLinea(any(), any(), any());
            verify(publicador, never()).publicar(any());
        }
    }

    @Nested
    @DisplayName("el camino feliz")
    class CaminoFeliz {

        @Test
        @Tag("DBG-02")
        @DisplayName("aplica las líneas en una sola llamada y lo declara COMPLETO")
        void aplicaEnUnaSolaLlamada() {
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, linea(B, 2, false));
            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.just(linea(A, 1, false)));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
                        assertThat(resultado.aplicadas()).containsExactly(A, B);
                        assertThat(resultado.fallos()).isEmpty();
                    })
                    .verifyComplete();

            // Una sola llamada con las dos líneas dentro: es lo que ahorra un recálculo.
            verify(comandos, times(1))
                    .aplicarEdicionesDeLinea(eq(CODIGO), any(), edicionesCaptor.capture());
            assertThat(edicionesCaptor.getValue()).hasSize(2);
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("la versión que viaja es la de la cuenta: es el cerrojo de toda la operación")
        void laVersionEsLaDeLaCuenta() {
            lineaEs(A, linea(A, 1, false));
            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.just(linea(A, 1, false)));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var versionCaptor = ArgumentCaptor.forClass(Version.class);
            verify(comandos).aplicarEdicionesDeLinea(eq(CODIGO), versionCaptor.capture(), any());
            assertThat(versionCaptor.getValue().numero()).isEqualTo(26L);
        }
    }

    @Nested
    @DisplayName("lo que no se puede tocar se aparta antes")
    class LoQueNoSeToca {

        @Test
        @Tag("DBG-02")
        @DisplayName("una línea bloqueada sale como fallo y las demás se aplican igual")
        void unaBloqueadaNoTumbaLasDemas() {
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, linea(B, 37, true));
            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.just(linea(A, 1, false)));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.PARCIAL);
                        assertThat(resultado.aplicadas()).containsExactly(A);
                        assertThat(resultado.fallos()).singleElement().satisfies(f -> {
                            assertThat(f.referencia()).isEqualTo(B);
                            // El número que ve el auditor, no solo el identificador interno.
                            assertThat(f.numeroLinea()).isEqualTo(37);
                            assertThat(f.motivo()).contains("bloqueada");
                        });
                    })
                    .verifyComplete();

            // La bloqueada no gasta sitio en el parche.
            verify(comandos).aplicarEdicionesDeLinea(eq(CODIGO), any(), edicionesCaptor.capture());
            assertThat(edicionesCaptor.getValue()).hasSize(1);
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("una línea que ya no existe se nombra, no revienta la operación")
        void unaQueYaNoExisteSeNombra() {
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, null);
            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.just(linea(A, 1, false)));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> assertThat(resultado.fallos()).singleElement()
                            .satisfies(f -> assertThat(f.motivo()).contains("ya no existe")))
                    .verifyComplete();
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("si ninguna es editable no se llama al sistema de registro")
        void siNingunaEsEditableNoSeLlama() {
            lineaEs(A, linea(A, 1, true));
            lineaEs(B, linea(B, 2, true));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.FALLIDO);
                        assertThat(resultado.fallos()).hasSize(2);
                    })
                    .verifyComplete();

            verify(comandos, times(0)).aplicarEdicionesDeLinea(any(), any(), any());
        }
    }

    @Nested
    @DisplayName("cuando el lote entero falla")
    class CuandoElLoteFalla {

        private static Throwable rechaza(int indice, String detalle) {
            return ExcepcionDeDominio.de(
                    new ErrorDeDominio.LineaDelLoteRechazada(indice, detalle));
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("quita la línea que OHI señaló y reintenta el resto de una vez")
        void quitaLaSenaladaYReintentaElResto() {
            // Medido el 17-oct-2026 con escritura en el entorno de pruebas: el parche es
            // atómico —422 y no aplica nada— pero el error dice cuál falló, en
            // «o:errorPath: $.claimLineList[1]». Así que no hace falta reintentar a ciegas
            // línea por línea: se quita la señalada y se manda el resto junto.
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, linea(B, 37, false));

            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.error(rechaza(1, "la 37 tiene una glosa duplicada")))
                    .thenReturn(Mono.just(linea(A, 1, false)));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.PARCIAL);
                        assertThat(resultado.aplicadas()).containsExactly(A);
                        assertThat(resultado.fallos()).singleElement().satisfies(f -> {
                            assertThat(f.referencia()).isEqualTo(B);
                            assertThat(f.numeroLinea()).isEqualTo(37);
                            assertThat(f.motivo()).contains("glosa duplicada");
                        });
                    })
                    .verifyComplete();

            // Dos llamadas, no tres: el lote y el reintento del resto.
            verify(comandos, times(2)).aplicarEdicionesDeLinea(eq(CODIGO), any(), any());
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("un error que NO señala línea no se reintenta: sería el mismo error N veces")
        void unErrorSinLineaNoSeReintenta() {
            // El conflicto de versión de la cuenta responde «o:errorPath: $», medido. No es
            // culpa de ninguna línea y reintentar es gastar llamadas para obtener lo mismo.
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, linea(B, 37, false));

            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.error(new IllegalStateException("conflicto de versión")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.FALLIDO);
                        // Las dos salen como fallo con la misma causa: es lo que ocurrió.
                        assertThat(resultado.fallos()).hasSize(2)
                                .allSatisfy(f -> assertThat(f.motivo()).contains("versión"));
                    })
                    .verifyComplete();

            verify(comandos, times(1)).aplicarEdicionesDeLinea(eq(CODIGO), any(), any());
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("con dos malas basta una vuelta más: tres llamadas para veinte líneas")
        void conDosMalasBastaUnaVueltaMas() {
            lineaEs(A, linea(A, 1, false));
            lineaEs(B, linea(B, 37, false));

            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.error(rechaza(1, "la 37 está mal")))
                    .thenReturn(Mono.error(rechaza(0, "la 1 también")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.FALLIDO);
                        assertThat(resultado.fallos()).hasSize(2);
                    })
                    .verifyComplete();

            verify(comandos, times(2)).aplicarEdicionesDeLinea(eq(CODIGO), any(), any());
        }

        @Test
        @Tag("DBG-02")
        @DisplayName("un índice que no cuadra con lo enviado no culpa a una línea al azar")
        void unIndiceQueNoCuadraNoCulpaAlAzar() {
            lineaEs(A, linea(A, 1, false));

            when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                    .thenReturn(Mono.error(rechaza(7, "índice imposible")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A), AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace())
                                .isEqualTo(ResultadoPorLinea.Desenlace.FALLIDO);
                        assertThat(resultado.fallos()).singleElement()
                                .satisfies(f -> assertThat(f.motivo()).contains("índice imposible"));
                    })
                    .verifyComplete();

            verify(comandos, times(1)).aplicarEdicionesDeLinea(eq(CODIGO), any(), any());
        }
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("sin auditor no se aplica nada: la operación tiene que quedar firmada")
    void sinAuditorNoSeAplicaNada() {
        StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A), "  "))
                .expectError()
                .verify();

        verify(comandos, times(0)).aplicarEdicionesDeLinea(any(), any(), any());
    }

    // ── Idempotencia y escrituras ya aplicadas (OPE-11, OPE-12) ───────────────────────

    private static LineaCuenta lineaConLaGlosa(ReferenciaLinea referencia, int numero) {
        return new LineaCuenta(referencia, CODIGO, numero, LocalDate.now(), LocalDate.now(),
                "CC1", "Afiliado", "873206", "Radiografía", "CUPS",
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.TEN, BigDecimal.ONE,
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ZERO, null, "AUT1",
                "900011436-001", "Prestador", false, false, false, false,
                false, false, null, null, null,
                List.of(), List.of(new DetalleGlosa(1L, "TAR01", new BigDecimal("1500"), null, null, "G", "E", "texto")),
                List.of(), List.of(), null, new Version(3L));
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("una línea que ya tiene la glosa no viaja y sale como «ya estaba»")
    void lasQueYaEstabanNoViajan() {
        lineaEs(A, lineaConLaGlosa(A, 1));
        lineaEs(B, linea(B, 2, false));
        when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any())).thenReturn(Mono.just(linea(B, 2, false)));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                .assertNext(r -> {
                    assertThat(r.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
                    assertThat(r.aplicadas()).containsExactly(B);
                    assertThat(r.yaEstaban()).containsExactly(A);
                })
                .verifyComplete();

        verify(comandos).aplicarEdicionesDeLinea(eq(CODIGO), any(), edicionesCaptor.capture());
        assertThat(edicionesCaptor.getValue()).extracting(EdicionLinea::referencia).containsExactly(B);
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("repetir un lote ya aplicado no escribe nada y es COMPLETO")
    void repetirNoEscribe() {
        lineaEs(A, lineaConLaGlosa(A, 1));
        lineaEs(B, lineaConLaGlosa(B, 2));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                .assertNext(r -> {
                    assertThat(r.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
                    assertThat(r.aplicadas()).isEmpty();
                    assertThat(r.yaEstaban()).containsExactly(A, B);
                })
                .verifyComplete();
        verify(comandos, org.mockito.Mockito.never()).aplicarEdicionesDeLinea(any(), any(), any());
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("se leen varias líneas a la vez, pero el resultado conserva el orden de la selección")
    void lecturaEnParaleloConOrden() {
        when(consultas.buscarDetalleLinea(CODIGO, A))
                .thenReturn(Mono.delay(java.time.Duration.ofMillis(60)).thenReturn(linea(A, 1, false)));
        lineaEs(B, linea(B, 2, false));
        when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any())).thenReturn(Mono.just(linea(A, 1, false)));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                .assertNext(r -> assertThat(r.aplicadas()).containsExactly(A, B))
                .verifyComplete();
        assertThat(AplicarCambiosEnLoteCasoDeUso.LECTURAS_A_LA_VEZ).isGreaterThan(1);
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("si el PATCH se aplicó y lo que falló fue releer, las líneas están aplicadas, no fallidas")
    void aplicadoSinRelecturaEsAplicado() {
        lineaEs(A, linea(A, 1, false));
        lineaEs(B, linea(B, 2, false));
        when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                .thenReturn(Mono.error(co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(new co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura("x", "timeout"))));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                .assertNext(r -> {
                    assertThat(r.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
                    assertThat(r.aplicadas()).containsExactly(A, B);
                    assertThat(r.fallos()).isEmpty();
                })
                .verifyComplete();
        verify(comandos, times(1)).aplicarEdicionesDeLinea(any(), any(), any());
    }

    @Test
    @Tag("OPE-11")
    @DisplayName("también en el reintento: quitada la mala, si el resto se aplica sin releer, está aplicado")
    void aplicadoSinRelecturaEnElReintento() {
        lineaEs(A, linea(A, 1, false));
        lineaEs(B, linea(B, 2, false));
        when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any()))
                .thenReturn(Mono.error(co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(
                        new co.sura.auditoria.modelo.error.ErrorDeDominio.LineaDelLoteRechazada(0, "código inválido"))))
                .thenReturn(Mono.error(co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(new co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura("x", "timeout"))));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, lote(A, B), AUTOR))
                .assertNext(r -> {
                    assertThat(r.aplicadas()).containsExactly(B);
                    assertThat(r.fallos()).extracting(ResultadoPorLinea.Fallo::referencia).containsExactly(A);
                })
                .verifyComplete();
    }

    // ── Lo que encontró la revisión de las Fases 1 y 2 en el lote ──────────────────────

    private static LineaCuenta lineaConNovedad(ReferenciaLinea referencia, int numero, boolean delSistema) {
        var novedad = new Novedad(9L, "CLA-FL-PRIC-004", "desc", Severidad.INFORMATIVA,
                delSistema ? "SISTEMA" : "MANUAL", null, null, "auditor", null, delSistema, java.util.Map.of());
        return new LineaCuenta(referencia, CODIGO, numero, LocalDate.now(), LocalDate.now(),
                "CC1", "Afiliado", "873206", "Radiografía", "CUPS",
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.TEN, BigDecimal.ONE,
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ZERO, null, "AUT1",
                "900011436-001", "Prestador", false, false, false, false,
                false, false, null, null, null,
                List.of(), List.of(new DetalleGlosa(1L, "OTRA", new BigDecimal("200"), null, null, "G", "E", "t")),
                List.of(novedad), List.of(), null, new Version(3L));
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("el lote de glosas cuadra el total glosado con el desglose de cada línea")
    void elLoteCuadraElTotalGlosado() {
        lineaEs(A, lineaConNovedad(A, 1, false));
        when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any())).thenReturn(Mono.just(linea(A, 1, false)));

        casoDeUso.ejecutar(CODIGO, lote(A), AUTOR).block();

        verify(comandos).aplicarEdicionesDeLinea(eq(CODIGO), any(), edicionesCaptor.capture());
        // 200 que ya tenía + 1.500 del lote: si no viajara, OHI dejaría el total viejo.
        assertThat(edicionesCaptor.getValue().get(0).valorGlosado())
                .hasValueSatisfying(v -> assertThat(v).isEqualByComparingTo("1700"));
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("quitar en lote una novedad que levantó el sistema falla en esa línea y no se manda")
    void noSeQuitanLasDelSistema() {
        lineaEs(A, lineaConNovedad(A, 1, true));
        lineaEs(B, lineaConNovedad(B, 2, false));
        when(comandos.aplicarEdicionesDeLinea(eq(CODIGO), any(), any())).thenReturn(Mono.just(linea(B, 2, false)));
        var quitar = new CambiosEnLote(SeleccionLineas.de(List.of(A, B)), List.of(),
                List.of(CambioNovedad.eliminar(9L)), ModoRecalculo.AISLADO);

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, quitar, AUTOR))
                .assertNext(r -> {
                    assertThat(r.aplicadas()).containsExactly(B);
                    assertThat(r.fallos()).singleElement().satisfies(f -> {
                        assertThat(f.referencia()).isEqualTo(A);
                        assertThat(f.motivo()).contains("puestas a mano").contains("CLA-FL-PRIC-004");
                    });
                })
                .verifyComplete();

        verify(comandos).aplicarEdicionesDeLinea(eq(CODIGO), any(), edicionesCaptor.capture());
        // Sin glosas en el cambio, el total glosado no viaja.
        assertThat(edicionesCaptor.getValue()).singleElement()
                .satisfies(e -> assertThat(e.valorGlosado()).isEmpty());
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("las altas de novedad se comprueban contra el catálogo una vez, antes de leer ninguna línea")
    void elCatalogoSeMiraUnaVez() {
        when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.error(
                co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(
                        new co.sura.auditoria.modelo.error.ErrorDeDominio.DecisionEnvioInvalida("no ofrecible"))));
        var poner = new CambiosEnLote(SeleccionLineas.de(List.of(A, B)), List.of(),
                List.of(CambioNovedad.agregar("NO-EXISTE")), ModoRecalculo.AISLADO);

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, poner, AUTOR)).expectError().verify();
        verify(consultas, org.mockito.Mockito.never()).buscarDetalleLinea(any(), any());
    }
}
