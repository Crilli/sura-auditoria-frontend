package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.Severidad;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ComprobadorDeNovedades")
class ComprobadorDeNovedadesTest {

    private static final String DONDE = "La cuenta";

    @Mock PuertoCatalogoNovedades catalogo;
    @InjectMocks ComprobadorDeNovedades comprobador;

    private static Novedad novedad(long id, String codigo, String origen) {
        return new Novedad(id, codigo, "texto", Severidad.INFORMATIVA, origen);
    }

    private static MensajeCatalogo mensaje(String codigo, String texto) {
        return new MensajeCatalogo(codigo, texto, Severidad.INFORMATIVA, null, null, false);
    }

    private String detalleDelError(Mono<Void> resultado) {
        var detalle = new String[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(error -> {
                    var dominio = ((ExcepcionDeDominio) error).error();
                    assertThat(dominio).isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
                    detalle[0] = ((ErrorDeDominio.DecisionEnvioInvalida) dominio).detalle();
                })
                .verify();
        return detalle[0];
    }

    @Nested
    @DisplayName("sin nada que comprobar")
    class SinNadaQueComprobar {

        @Test
        @DisplayName("una lista de cambios vacía o nula pasa sin consultar el catálogo")
        void unaListaVaciaPasaSinConsultar() {
            StepVerifier.create(comprobador.comprobar(List.of(), List.of(), DONDE))
                    .verifyComplete();
            StepVerifier.create(comprobador.comprobar(null, List.of(), DONDE))
                    .verifyComplete();

            verify(catalogo, never()).listar();
        }

        @Test
        @DisplayName("solo bajas válidas no necesitan el catálogo")
        void soloBajasValidasNoNecesitanElCatalogo() {
            var actuales = List.of(novedad(1L, "332-1", Novedad.ORIGEN_MANUAL));

            StepVerifier.create(comprobador.comprobar(
                            List.of(CambioNovedad.eliminar(1L)), actuales, DONDE))
                    .verifyComplete();

            verify(catalogo, never()).listar();
        }
    }

    @Nested
    @DisplayName("bajas de novedades que ya no están")
    class BajasInexistentes {

        @Test
        @DisplayName("se rechaza y se pide volver a cargar")
        void seRechazaYSePideRecargar() {
            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.eliminar(99L)), List.of(), DONDE));

            assertThat(detalle)
                    .contains("La cuenta")
                    .contains("la novedad")
                    .contains("99")
                    .contains("Vuelva a cargarla");
        }

        @Test
        @DisplayName("con varias, el mensaje va en plural y las lista todas")
        void conVariasElMensajeVaEnPlural() {
            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.eliminar(7L), CambioNovedad.eliminar(8L)),
                    List.of(), DONDE));

            assertThat(detalle).contains("las novedades").contains("7, 8");
        }
    }

    @Nested
    @DisplayName("bajas de novedades del sistema")
    class BajasAjenas {

        @Test
        @DisplayName("no se puede eliminar lo que levantó el motor")
        void noSePuedeEliminarLoDelMotor() {
            var actuales = List.of(novedad(1L, "SURA-AUT-002", "BENEFITS"));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.eliminar(1L)), actuales, DONDE));

            assertThat(detalle)
                    .contains("puestas a mano")
                    .contains("la levantó el sistema")
                    .contains("SURA-AUT-002 (BENEFITS)");
        }

        @Test
        @DisplayName("una novedad MANUAL sí se puede eliminar, sin importar la caja del origen")
        void unaManualSiSePuedeEliminar() {
            var actuales = List.of(novedad(1L, "332-1", "manual"));

            StepVerifier.create(comprobador.comprobar(
                            List.of(CambioNovedad.eliminar(1L)), actuales, DONDE))
                    .verifyComplete();
        }

        @Test
        @DisplayName("con varias ajenas el mensaje va en plural")
        void conVariasAjenasElMensajeVaEnPlural() {
            var actuales = List.of(novedad(1L, "A", "PRICING"), novedad(2L, "B", "COVERAGE"));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.eliminar(1L), CambioNovedad.eliminar(2L)),
                    actuales, DONDE));

            assertThat(detalle).contains("No se eliminaron").contains("las levantó el sistema");
        }
    }

    @Nested
    @DisplayName("altas contra el catálogo")
    class AltasContraElCatalogo {

        @Test
        @DisplayName("un código que el catálogo no ofrece se rechaza")
        void unCodigoNoOfrecidoSeRechaza() {
            when(catalogo.listar()).thenReturn(Mono.just(List.of(mensaje("332-1", "texto"))));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.agregar("INVENTADO")), List.of(), DONDE));

            assertThat(detalle)
                    .contains("Este mensaje")
                    .contains("no se puede poner a mano")
                    .contains("INVENTADO");
        }

        @Test
        @DisplayName("con varios rechazados el mensaje va en plural")
        void conVariosRechazadosVaEnPlural() {
            when(catalogo.listar()).thenReturn(Mono.just(List.of()));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.agregar("A"), CambioNovedad.agregar("B")),
                    List.of(), DONDE));

            assertThat(detalle).contains("Estos mensajes").contains("no se pueden poner");
        }

        @Test
        @DisplayName("un alta de un mensaje sin marcadores pasa")
        void unAltaSinMarcadoresPasa() {
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(mensaje("332-1", "Procedimiento no autorizado"))));

            StepVerifier.create(comprobador.comprobar(
                            List.of(CambioNovedad.agregar("332-1")), List.of(), DONDE))
                    .verifyComplete();
        }
    }

    @Nested
    @DisplayName("datos que completan la plantilla")
    class DatosDeLaPlantilla {

        @Test
        @DisplayName("un marcador sin rellenar se rechaza: el prestador leería el hueco")
        void unMarcadorSinRellenarSeRechaza() {
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(mensaje("A", "Autorización {2} consumida"))));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.agregar("A")), List.of(), DONDE));

            assertThat(detalle)
                    .contains("queda un dato")
                    .contains("dato 2")
                    .contains("el prestador leería el hueco");
        }

        @Test
        @DisplayName("con varios huecos el mensaje va en plural y los lista")
        void conVariosHuecosVaEnPlural() {
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(mensaje("A", "{0} y {1}"))));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.agregar("A")), List.of(), DONDE));

            assertThat(detalle).contains("quedan datos").contains("dato 0, dato 1");
        }

        @Test
        @DisplayName("un dato que la plantilla no usa se rechaza: no se guardaría en ninguna parte")
        void unDatoQueSobraSeRechaza() {
            when(catalogo.listar()).thenReturn(Mono.just(List.of(mensaje("A", "Solo {0}"))));

            var detalle = detalleDelError(comprobador.comprobar(
                    List.of(CambioNovedad.agregar("A", Map.of(0, "uno", 5, "sobra"))),
                    List.of(), DONDE));

            assertThat(detalle)
                    .contains("no usa el dato 5")
                    .contains("no se guardaría en ninguna parte");
        }

        @Test
        @DisplayName("una plantilla completa y sin sobrantes pasa")
        void unaPlantillaCompletaPasa() {
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(mensaje("A", "Autorización {2}"))));

            StepVerifier.create(comprobador.comprobar(
                            List.of(CambioNovedad.agregar("A", Map.of(2, "99073568971"))),
                            List.of(), DONDE))
                    .verifyComplete();
        }
    }

    @Test
    @DisplayName("el orden de comprobación es: bajas inexistentes, bajas ajenas y luego catálogo")
    void elOrdenDeComprobacion() {
        // Hay a la vez una baja inexistente y un alta inválida: debe ganar la baja,
        // y ni siquiera llegar a consultar el catálogo.
        var detalle = detalleDelError(comprobador.comprobar(
                List.of(CambioNovedad.eliminar(99L), CambioNovedad.agregar("INVENTADO")),
                List.of(), DONDE));

        assertThat(detalle).contains("Vuelva a cargarla");
        verify(catalogo, never()).listar();
    }
}
