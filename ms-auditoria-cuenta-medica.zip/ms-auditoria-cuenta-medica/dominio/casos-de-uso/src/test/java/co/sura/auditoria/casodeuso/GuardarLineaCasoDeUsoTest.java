package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CambioGlosa;
import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.DetalleGlosa;
import co.sura.auditoria.modelo.cuenta.EdicionLinea;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ModoRecalculo;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("GuardarLineaCasoDeUso")
class GuardarLineaCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(148111592284L);
    private static final Version VERSION_LINEA = new Version(5L);
    private static final String AUTOR = "auditor@sura.com.co";

    @Mock PuertoConsultaCuentas consultas;
    @Mock PuertoComandosCuenta comandos;
    @Mock PublicadorEventosAuditoria publicador;
    @Mock ComprobadorDeNovedades comprobador;
    @InjectMocks GuardarLineaCasoDeUso casoDeUso;

    private static CuentaMedica cuenta() {
        return cuenta(EstadoCuenta.MODIFICACION);
    }

    private static CuentaMedica cuenta(EstadoCuenta estado) {
        return new CuentaMedica(CODIGO, estado, LocalDate.now(),
                LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN, new Version(26L),
                List.of(), List.of(), null, List.of());
    }

    private static LineaCuenta linea(boolean bloqueada, boolean reemplazada,
                                     Version version, List<DetalleGlosa> glosas) {
        return new LineaCuenta(REFERENCIA, CODIGO, 1, LocalDate.now(), LocalDate.now(),
                "CC1", "Afiliado", "873206", "Radiografía", "CUPS",
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.TEN, BigDecimal.ONE,
                BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ZERO, null, "AUT1",
                "900011436-001", "Prestador", false, false, false, false,
                bloqueada, reemplazada, null, null, null,
                List.of(), glosas, List.of(), List.of(), null, version);
    }

    private static LineaCuenta lineaEditable(List<DetalleGlosa> glosas) {
        return linea(false, false, VERSION_LINEA, glosas);
    }

    /** Edición mínima con un solo campo descriptivo tocado. */
    private static EdicionLinea edicion(Version versionEsperada, List<CambioGlosa> glosas,
                                        List<CambioNovedad> novedades,
                                        Optional<BigDecimal> valorGlosado) {
        return new EdicionLinea(REFERENCIA, versionEsperada,
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.of("observación"), Optional.empty(), Optional.empty(), valorGlosado,
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), glosas, novedades, ModoRecalculo.EN_CASCADA);
    }

    private static EdicionLinea edicionSimple() {
        return edicion(VERSION_LINEA, List.of(), List.of(), Optional.empty());
    }

    private static EdicionLinea edicionVacia() {
        return new EdicionLinea(REFERENCIA, VERSION_LINEA,
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), List.of(), List.of(),
                ModoRecalculo.EN_CASCADA);
    }

    private void cuentaYLinea(LineaCuenta linea) {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta()));
        when(consultas.buscarDetalleLinea(CODIGO, REFERENCIA)).thenReturn(Mono.just(linea));
    }

    private void comandoFunciona() {
        when(comandos.aplicarEdicionesDeLinea(any(), any(), any()))
                .thenReturn(Mono.just(lineaEditable(List.of())));
        when(publicador.publicar(any())).thenReturn(Mono.empty());
    }

    private ErrorDeDominio errorDe(Mono<LineaCuenta> resultado) {
        var capturado = new ErrorDeDominio[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(e -> capturado[0] = ((ExcepcionDeDominio) e).error())
                .verify();
        return capturado[0];
    }

    @Test
    @DisplayName("una edición sin cambios se rechaza antes de buscar nada")
    void unaEdicionSinCambiosSeRechazaAntesDeBuscar() {
        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, edicionVacia(), AUTOR)))
                .isInstanceOf(ErrorDeDominio.EdicionSinCambios.class);

        verify(consultas, never()).buscarPorCodigo(any());
    }

    @Test
    @DisplayName("si la cuenta no existe, CuentaNoEncontrada")
    void siLaCuentaNoExiste() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.empty());

        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR)))
                .isInstanceOf(ErrorDeDominio.CuentaNoEncontrada.class);
    }

    @Test
    @DisplayName("si la línea no existe, LineaNoEncontrada")
    void siLaLineaNoExiste() {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta()));
        when(consultas.buscarDetalleLinea(CODIGO, REFERENCIA)).thenReturn(Mono.empty());

        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR)))
                .isInstanceOf(ErrorDeDominio.LineaNoEncontrada.class);
    }

    /**
     * Solo se cambian datos con la cuenta en modificación (regla del 2026-10-21). El sistema de
     * registro no lo impone —acepta el parche en adjudicación manual—, así que si esta guarda
     * fallara, el cambio llegaría a OHI. Por eso se afirma que no se llega ni a leer la línea.
     */
    @Nested
    @DisplayName("estado de la cuenta")
    class EstadoDeLaCuenta {

        @ParameterizedTest(name = "{0}")
        @Tag("EST-01.6")
        @Tag("EST-01.3")
        @EnumSource(value = EstadoCuenta.class, names = "MODIFICACION",
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("[EST-01.6] fuera de MODIFICACION, CuentaNoModificable sin leer la línea ni escribir")
        void fueraDeModificacionNoSeTocaNada(EstadoCuenta estado) {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(cuenta(estado)));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR));

            assertThat(error).isEqualTo(
                    new ErrorDeDominio.CuentaNoModificable(CODIGO.valor(), estado.name()));
            verify(consultas, never()).buscarDetalleLinea(any(), any());
            verify(comandos, never()).aplicarEdicionesDeLinea(any(), any(), any());
            verify(publicador, never()).publicar(any());
        }

        @Test
        @Tag("EST-01.1")
        @DisplayName("[EST-01.1] en MODIFICACION se guarda como siempre")
        void enModificacionSeGuarda() {
            cuentaYLinea(lineaEditable(List.of()));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(comandos).aplicarEdicionesDeLinea(any(), any(), any());
        }

        @Test
        @Tag("EST-01.7")
        @DisplayName("[EST-01.7] en MODIFICACION una línea bloqueada sigue sin editarse")
        void enModificacionUnaBloqueadaSigueSinEditarse() {
            // Las dos reglas se suman: la de la cuenta abre, la de la línea puede seguir cerrando.
            cuentaYLinea(linea(true, false, VERSION_LINEA, List.of()));

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR)))
                    .isInstanceOf(ErrorDeDominio.LineaNoEditable.class);
            verify(comandos, never()).aplicarEdicionesDeLinea(any(), any(), any());
        }
    }

    // GRID-18: la edición en la fila confía en esta misma regla; la grilla solo esconde el botón.
    @Nested
    @Tag("GRID-18")
    @DisplayName("línea no editable")
    class LineaNoEditable {

        @Test
        @DisplayName("una línea bloqueada no se guarda, y la razón lo dice")
        void unaLineaBloqueadaNoSeGuarda() {
            cuentaYLinea(linea(true, false, VERSION_LINEA, List.of()));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR));

            assertThat(error).isInstanceOf(ErrorDeDominio.LineaNoEditable.class);
            assertThat(((ErrorDeDominio.LineaNoEditable) error).razon())
                    .isEqualTo("La línea está bloqueada");
        }

        @Test
        @DisplayName("una línea reemplazada tampoco")
        void unaLineaReemplazadaTampoco() {
            cuentaYLinea(linea(false, true, VERSION_LINEA, List.of()));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR));

            assertThat(((ErrorDeDominio.LineaNoEditable) error).razon())
                    .isEqualTo("La línea fue reemplazada");
        }
    }

    @Test
    @Tag("GRID-18")  // el conflicto que la edición en la fila resuelve releyendo la línea
    @DisplayName("si la versión de la línea no coincide, ModificacionConcurrente")
    void siLaVersionNoCoincide() {
        cuentaYLinea(lineaEditable(List.of()));

        var error = errorDe(casoDeUso.ejecutar(CODIGO,
                edicion(new Version(99L), List.of(), List.of(), Optional.empty()), AUTOR));

        assertThat(error).isInstanceOf(ErrorDeDominio.ModificacionConcurrente.class);
        assertThat(((ErrorDeDominio.ModificacionConcurrente) error).recurso())
                .isEqualTo("linea:148111592284");
    }

    @Nested
    @DisplayName("glosas")
    class Glosas {

        @Test
        @DisplayName("mandar el valor glosado a la vez que se tocan glosas se rechaza")
        void mandarElValorGlosadoConGlosasSeRechaza() {
            // El total sale de la suma de las glosas: aceptar ambos permitiría
            // guardar un total que no cuadra con su propio desglose.
            cuentaYLinea(lineaEditable(List.of()));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, edicion(VERSION_LINEA,
                    List.of(CambioGlosa.agregar("208-1", null, null, BigDecimal.TEN, null)),
                    List.of(), Optional.of(new BigDecimal("999"))), AUTOR));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("sale de la suma de sus glosas");
        }

        @Test
        @DisplayName("eliminar una glosa que ya no está se rechaza y se pide recargar")
        void eliminarUnaGlosaInexistenteSeRechaza() {
            cuentaYLinea(lineaEditable(List.of(
                    new DetalleGlosa(1L, null, BigDecimal.TEN, null, null, null, null, null))));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, edicion(VERSION_LINEA,
                    List.of(CambioGlosa.eliminar(99L)), List.of(), Optional.empty()), AUTOR));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("la glosa").contains("99").contains("Vuelva a cargarla");
        }

        @Test
        @DisplayName("al tocar glosas, el valor glosado se recalcula y viaja ya resuelto")
        void elValorGlosadoSeRecalculaYViajaResuelto() {
            cuentaYLinea(lineaEditable(List.of(
                    new DetalleGlosa(1L, null, new BigDecimal("100"), null, null, null, null, null),
                    new DetalleGlosa(2L, null, new BigDecimal("50"), null, null, null, null, null))));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicion(VERSION_LINEA,
                            List.of(CambioGlosa.eliminar(1L),
                                    CambioGlosa.agregar("208-1", null, null,
                                            new BigDecimal("30"), null)),
                            List.of(), Optional.empty()), AUTOR))
                    .expectNextCount(1).verifyComplete();

            @SuppressWarnings("unchecked")
            ArgumentCaptor<List<EdicionLinea>> captor = ArgumentCaptor.forClass(List.class);
            verify(comandos).aplicarEdicionesDeLinea(any(), any(), captor.capture());

            // Queda la 2 (50) y entra una de 30 → 80.00
            assertThat(captor.getValue().get(0).valorGlosado())
                    .hasValueSatisfying(v -> assertThat(v).isEqualByComparingTo("80.00"));
        }
    }

    @Test
    @DisplayName("al tocar novedades se pide la comprobación contra el catálogo")
    void alTocarNovedadesSePideLaComprobacion() {
        cuentaYLinea(lineaEditable(List.of()));
        when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
        comandoFunciona();

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicion(VERSION_LINEA, List.of(),
                        List.of(CambioNovedad.agregar("332-1")), Optional.empty()), AUTOR))
                .expectNextCount(1).verifyComplete();

        verify(comprobador).comprobar(any(), any(),
                org.mockito.ArgumentMatchers.eq("La línea 148111592284"));
    }

    @Test
    @DisplayName("sin novedades no se molesta al comprobador")
    void sinNovedadesNoSeMolestaAlComprobador() {
        cuentaYLinea(lineaEditable(List.of()));
        comandoFunciona();

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR))
                .expectNextCount(1).verifyComplete();

        verify(comprobador, never()).comprobar(any(), any(), any());
    }

    @Test
    @DisplayName("se aplica con la versión de la CUENTA, no con la de la línea")
    void seAplicaConLaVersionDeLaCuenta() {
        cuentaYLinea(lineaEditable(List.of()));
        comandoFunciona();

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR))
                .expectNextCount(1).verifyComplete();

        verify(comandos).aplicarEdicionesDeLinea(
                org.mockito.ArgumentMatchers.eq(CODIGO),
                org.mockito.ArgumentMatchers.eq(new Version(26L)),
                any());
    }

    @Nested
    @DisplayName("traza")
    class Traza {

        @Test
        @DisplayName("anota el modo de recálculo y si afecta al cálculo financiero")
        void anotaElModoYSiAfectaAlCalculo() {
            cuentaYLinea(lineaEditable(List.of()));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicion(VERSION_LINEA,
                            List.of(CambioGlosa.agregar("208-1", null, null,
                                    new BigDecimal("30"), null)),
                            List.of(), Optional.empty()), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .contains("Recálculo EN_CASCADA")
                    .contains("afecta cálculo financiero");
            assertThat(captor.getValue().referenciaLinea()).isEqualTo(148111592284L);
        }

        @Test
        @DisplayName("un cambio descriptivo no se marca como financiero")
        void unCambioDescriptivoNoSeMarcaComoFinanciero() {
            cuentaYLinea(lineaEditable(List.of()));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .isEqualTo("Recálculo EN_CASCADA");
        }

        @Test
        @DisplayName("resume las novedades puestas y quitadas")
        void resumeLasNovedades() {
            cuentaYLinea(lineaEditable(List.of()));
            when(comprobador.comprobar(any(), any(), any())).thenReturn(Mono.empty());
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicion(VERSION_LINEA, List.of(),
                            List.of(CambioNovedad.agregar("332-1"), CambioNovedad.eliminar(9L)),
                            Optional.empty()), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .contains("novedades puestas: 332-1")
                    .contains("novedades quitadas: 1");
        }

        @Test
        @DisplayName("si falla la traza, la línea ya guardada no se pierde")
        void siFallaLaTrazaLaLineaNoSePierde() {
            cuentaYLinea(lineaEditable(List.of()));
            when(comandos.aplicarEdicionesDeLinea(any(), any(), any()))
                    .thenReturn(Mono.just(lineaEditable(List.of())));
            when(publicador.publicar(any()))
                    .thenReturn(Mono.error(new IllegalStateException("bus caído")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR))
                    .expectNextCount(1).verifyComplete();
        }
    }

    @Test
    @org.junit.jupiter.api.Tag("OPE-11")
    @DisplayName("si el cambio se aplicó pero no se pudo releer, la traza se registra igual y el error sigue")
    void aplicadoSinRelecturaDejaTraza() {
        cuentaYLinea(lineaEditable(List.of()));
        when(comandos.aplicarEdicionesDeLinea(any(), any(), any()))
                .thenReturn(Mono.error(co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(new co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura("x", "timeout"))));
        when(publicador.publicar(any())).thenReturn(Mono.empty());

        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR)))
                .isInstanceOf(co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura.class);
        verify(publicador).publicar(any());
    }

    @Test
    @org.junit.jupiter.api.Tag("OPE-11")
    @DisplayName("cualquier otro error del comando no deja traza: no se aplicó nada")
    void otroErrorNoDejaTraza() {
        cuentaYLinea(lineaEditable(List.of()));
        when(comandos.aplicarEdicionesDeLinea(any(), any(), any()))
                .thenReturn(Mono.error(new IllegalStateException("rechazado")));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, edicionSimple(), AUTOR)).expectError().verify();
        verify(publicador, org.mockito.Mockito.never()).publicar(any());
    }
}
