package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.SeleccionLineas;
import co.sura.auditoria.modelo.cuenta.NivelResolucion;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace;
import co.sura.auditoria.modelo.cuenta.UbicacionMotivo;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ResolverPendientesEnMasaCasoDeUso")
class ResolverPendientesEnMasaCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final String AUTOR = "auditor@sura.com.co";
    private static final String JUSTIFICACION = "Revisión masiva";

    @Mock PuertoConsultaCuentas consultas;

    /** Sin caché en las pruebas: la consulta fresca dice lo mismo que la guardada. */
    @org.junit.jupiter.api.BeforeEach
    void frescasComoLasGuardadas() {
        org.mockito.Mockito.lenient().when(consultas.consultarAccionesFrescas(org.mockito.ArgumentMatchers.any()))
                .thenAnswer(inv -> consultas.consultarAccionesDisponibles(inv.getArgument(0)));
    }
    @Mock PuertoPendientes pendientes;
    @Mock PuertoNotas notas;
    @Mock PublicadorEventosAuditoria publicador;
    /** Con la configuración por omisión: cabecera y líneas a la vez (OPE-08). */
    ResolverPendientesEnMasaCasoDeUso casoDeUso;

    @BeforeEach
    void montar() {
        casoDeUso = new ResolverPendientesEnMasaCasoDeUso(consultas, pendientes, notas, publicador, true);
    }

    /** El modo conservador: los dos niveles en serie (OPE-03). */
    private ResolverPendientesEnMasaCasoDeUso enSerie() {
        return new ResolverPendientesEnMasaCasoDeUso(consultas, pendientes, notas, publicador, false);
    }

    /** Motivo que está en la cabecera y, si lineas>0, también en líneas. */
    private static UbicacionMotivo motivo(String codigo, boolean enCabecera, int lineas) {
        return new UbicacionMotivo(codigo, enCabecera, lineas > 0);
    }

    private void catalogoDeLaCuenta(AccionesDisponibles acciones, UbicacionMotivo... motivos) {
        when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.just(acciones));
        when(pendientes.ubicarMotivos(eq(CODIGO), any())).thenReturn(Mono.just(
                java.util.Arrays.stream(motivos).collect(Collectors.toMap(
                        UbicacionMotivo::codigo, m -> m, (a, b) -> a, java.util.LinkedHashMap::new))));
    }

    private static AccionesDisponibles ambasAcciones() {
        return new AccionesDisponibles(Set.of(AccionCuenta.RESOLVER_PENDIENTE,
                AccionCuenta.RESOLVER_PENDIENTE_LINEA));
    }

    private void trazaFunciona() {
        when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
        when(publicador.publicar(any())).thenReturn(Mono.empty());
    }

    private ErrorDeDominio errorDe(Mono<ResultadoResolucionMasiva> resultado) {
        var capturado = new ErrorDeDominio[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(e -> capturado[0] = ((ExcepcionDeDominio) e).error())
                .verify();
        return capturado[0];
    }

    private String detalleDe(Mono<ResultadoResolucionMasiva> resultado) {
        return ((ErrorDeDominio.DecisionEnvioInvalida) errorDe(resultado)).detalle();
    }

    @Nested
    @DisplayName("validaciones previas")
    class ValidacionesPrevias {

        @ParameterizedTest(name = "autor [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"  "})
        @DisplayName("sin auditor no se resuelve")
        void sinAuditorNoSeResuelve(String autor) {
            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, Set.of("A"),
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, autor)))
                    .contains("No se identificó al auditor");

            verify(consultas, never()).consultarAccionesDisponibles(any());
        }

        @ParameterizedTest(name = "justificación [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"  "})
        @DisplayName("sin justificación tampoco")
        void sinJustificacionTampoco(String justificacion) {
            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, Set.of("A"),
                    NivelResolucion.DONDE_APLIQUE, justificacion, AUTOR)))
                    .contains("justificación es obligatoria");
        }

        @Test
        @DisplayName("sin motivos no hay nada que resolver")
        void sinMotivosNoHayNadaQueResolver() {
            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, Set.of(),
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR)))
                    .contains("al menos un motivo");
            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, null,
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR)))
                    .contains("al menos un motivo");
        }

        @Test
        @DisplayName("motivos en blanco se descartan, y si no queda ninguno se rechaza")
        void losMotivosEnBlancoSeDescartan() {
            var soloBasura = new LinkedHashSet<String>();
            soloBasura.add("   ");
            soloBasura.add("");

            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, soloBasura,
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR)))
                    .contains("al menos un motivo");
        }

        @Test
        @DisplayName("a los motivos se les recortan los espacios")
        void alosMotivosSeLesRecortanLosEspacios() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 0));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("  AUD01  "),
                            NivelResolucion.CUENTA, JUSTIFICACION, AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS);
        }

        @Test
        @DisplayName("por encima de 50 motivos se rechaza, para no disparar una operación enorme")
        void porEncimaDelMaximoSeRechaza() {
            var demasiados = IntStream.rangeClosed(1, ResolverPendientesEnMasaCasoDeUso.MAXIMO_MOTIVOS + 1)
                    .mapToObj(i -> "M" + i)
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, demasiados,
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR)))
                    .contains("No se pueden resolver más de 50 motivos")
                    .contains("se pidieron 51");
        }
    }

    @Nested
    @DisplayName("motivos que la cuenta no tiene")
    @Tag("OPE-07")  // OPE-07.2: la validación por ubicación sigue nombrando lo desconocido
    class MotivosDesconocidos {

        @Test
        @DisplayName("se rechaza nombrando la cuenta y el motivo")
        void seRechazaNombrandoCuentaYMotivo() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 0));

            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, Set.of("INVENTADO"),
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR)))
                    .contains("CM-108800618430")
                    .contains("este motivo")
                    .contains("INVENTADO");
        }

        @Test
        @DisplayName("con varios el mensaje va en plural")
        void conVariosVaEnPlural() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 0));
            var dos = new LinkedHashSet<>(List.of("X", "Y"));

            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, dos,
                    NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR)))
                    .contains("estos motivos");
        }
    }

    @Nested
    @DisplayName("reparto por nivel")
    class RepartoPorNivel {

        @Test
        @DisplayName("CUENTA resuelve solo en cabecera")
        void cuentaResuelveSoloEnCabecera() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.CUENTA, JUSTIFICACION, AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS);
            verify(pendientes, never()).resolverMotivos(any(), any(), eq(NivelPendiente.LINEA), any());
        }

        @Test
        @DisplayName("LINEAS resuelve solo en líneas")
        void lineasResuelveSoloEnLineas() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.LINEAS, JUSTIFICACION, AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS);
            verify(pendientes, never()).resolverMotivos(any(), any(), eq(NivelPendiente.CABECERA), any());
        }

        @Test
        @org.junit.jupiter.api.Tag("OPE-03")  // OPE-03.2: con la cabecera terminada, la de líneas sale
        @DisplayName("DONDE_APLIQUE con motivo en ambos sitios emite las dos llamadas")
        void dondeApliqueEmiteLasDos() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS);
            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS);
        }

        @Test
        @DisplayName("un nivel nulo se trata como DONDE_APLIQUE")
        void unNivelNuloEsDondeAplique() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 2));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"), null,
                            JUSTIFICACION, AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS);
            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS);
        }

        @Test
        @DisplayName("pedir CUENTA sobre un motivo que solo está en líneas no resuelve nada")
        void pedirCuentaSobreMotivoDeLineasNoResuelveNada() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", false, 3));

            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                    NivelResolucion.CUENTA, JUSTIFICACION, AUTOR)))
                    .contains("en la cabecera de la cuenta")
                    .contains("no hay nada que resolver");
        }

        @Test
        @DisplayName("pedir LINEAS sobre un motivo que solo está en cabecera no resuelve nada")
        void pedirLineasSobreMotivoDeCabeceraNoResuelveNada() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 0));

            assertThat(detalleDe(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                    NivelResolucion.LINEAS, JUSTIFICACION, AUTOR)))
                    .contains("en las líneas");
        }
    }

    @Nested
    @DisplayName("permisos por nivel")
    class PermisosPorNivel {

        @Test
        @DisplayName("sin la acción de cabecera no se resuelve en cabecera")
        void sinLaAccionDeCabecera() {
            catalogoDeLaCuenta(new AccionesDisponibles(
                    Set.of(AccionCuenta.RESOLVER_PENDIENTE_LINEA)), motivo("AUD01", true, 0));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                    NivelResolucion.CUENTA, JUSTIFICACION, AUTOR));

            assertThat(((ErrorDeDominio.AccionNoDisponible) error).accion())
                    .isEqualTo("RESOLVER_PENDIENTE");
            verify(pendientes, never()).resolverMotivos(any(), any(), any(), any());
        }

        @Test
        @DisplayName("sin la acción de línea no se resuelve en líneas")
        void sinLaAccionDeLinea() {
            catalogoDeLaCuenta(new AccionesDisponibles(
                    Set.of(AccionCuenta.RESOLVER_PENDIENTE)), motivo("AUD01", false, 3));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                    NivelResolucion.LINEAS, JUSTIFICACION, AUTOR));

            assertThat(((ErrorDeDominio.AccionNoDisponible) error).accion())
                    .isEqualTo("RESOLVER_PENDIENTE_LINEA");
        }
    }

    /**
     * OPE-08: con la configuración por omisión, cabecera y líneas salen a la vez. Medido en
     * el entorno de pruebas: el sistema de registro las corre en paralelo y acaban bien.
     */
    @Nested
    @DisplayName("cabecera y líneas a la vez")
    class ALaVez {

        private static final java.time.Duration UN_RATO = java.time.Duration.ofMillis(80);

        private void conLasDos() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            trazaFunciona();
        }

        private Mono<ResultadoResolucionMasiva> ejecutar() {
            return casoDeUso.ejecutar(CODIGO, Set.of("AUD01"), NivelResolucion.DONDE_APLIQUE,
                                      JUSTIFICACION, AUTOR);
        }

        @Test
        @Tag("OPE-08")
        @DisplayName("la de líneas sale mientras la de cabecera todavía está en vuelo")
        void salenALaVez() {
            conLasDos();
            var lineasLanzada = new java.util.concurrent.atomic.AtomicBoolean();
            var lineasMientrasCabecera = new java.util.concurrent.atomic.AtomicBoolean();
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.delay(UN_RATO).map(x -> {
                        lineasMientrasCabecera.set(lineasLanzada.get());
                        return ResultadoResolucionMasiva.completo("op-cabecera");
                    }));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.fromCallable(() -> {
                        lineasLanzada.set(true);
                        return ResultadoResolucionMasiva.completo("op-lineas");
                    }));

            StepVerifier.create(ejecutar())
                    .assertNext(r -> {
                        assertThat(r.desenlace()).isEqualTo(Desenlace.COMPLETO);
                        assertThat(r.referencias()).containsExactly("op-cabecera", "op-lineas");
                    })
                    .verifyComplete();

            // En serie, la de líneas no se habría lanzado hasta que acabara la de cabecera.
            assertThat(lineasMientrasCabecera).isTrue();
        }

        @Test
        @Tag("OPE-08")
        @DisplayName("si la de cabecera sigue en curso, la de líneas sale igual: no hay nada que esperar")
        void conLaCabeceraEnCurso() {
            conLasDos();
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(new ResultadoResolucionMasiva(
                            List.of("op-cabecera"), Desenlace.EN_CURSO, List.of())));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-lineas")));

            StepVerifier.create(ejecutar())
                    .assertNext(r -> {
                        assertThat(r.desenlace()).isEqualTo(Desenlace.EN_CURSO);
                        assertThat(r.referencias()).containsExactly("op-cabecera", "op-lineas");
                        assertThat(r.fallos()).isEmpty();
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("OPE-08")
        @DisplayName("si no sale la de cabecera y sí la de líneas, es parcial y nombra el nivel")
        void noSaleLaDeCabecera() {
            conLasDos();
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.error(new IllegalStateException("OHI rechazó la cabecera")));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-lineas")));

            StepVerifier.create(ejecutar())
                    .assertNext(r -> {
                        assertThat(r.desenlace()).isEqualTo(Desenlace.PARCIAL);
                        assertThat(r.referencias()).containsExactly("op-lineas");
                        assertThat(r.fallos()).singleElement().satisfies(f -> {
                            assertThat(f.codigo()).isEqualTo("NIVEL_CABECERA");
                            assertThat(f.detalle()).startsWith("La resolución de líneas se lanzó, pero la de cabecera no")
                                                   .contains("OHI rechazó la cabecera");
                        });
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("OPE-08")
        @DisplayName("si no sale la de líneas y sí la de cabecera, es parcial y nombra el nivel")
        void noSaleLaDeLineas() {
            conLasDos();
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-cabecera")));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.error(new IllegalStateException()));

            StepVerifier.create(ejecutar())
                    .assertNext(r -> {
                        assertThat(r.desenlace()).isEqualTo(Desenlace.PARCIAL);
                        assertThat(r.fallos()).singleElement().satisfies(f -> {
                            assertThat(f.codigo()).isEqualTo("NIVEL_LINEA");
                            assertThat(f.detalle()).startsWith("La resolución de cabecera se lanzó, pero la de líneas no")
                                                   .contains("IllegalStateException");
                        });
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("OPE-08")
        @DisplayName("si no sale ninguna, es un error: no se aplicó nada")
        void noSaleNinguna() {
            // Sin traza: si no se aplicó nada, no hay nada que anotar.
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.error(ExcepcionDeDominio.de(
                            new ErrorDeDominio.SistemaRegistroNoDisponible("caído"))));

            assertThat(errorDe(ejecutar())).isInstanceOf(ErrorDeDominio.SistemaRegistroNoDisponible.class);
        }
    }

    /** OPE-06: el seguimiento de lo ya lanzado, sin estado en el servicio. */
    @Nested
    @DisplayName("seguimiento")
    class Seguimiento {

        private static ResultadoResolucionMasiva con(String ref, Desenlace desenlace) {
            return new ResultadoResolucionMasiva(List.of(ref), desenlace, List.of());
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("une el desenlace de cada referencia: si alguna sigue en curso, el conjunto también")
        void uneLosDesenlaces() {
            when(pendientes.consultarResolucion(CODIGO, "11")).thenReturn(Mono.just(con("11", Desenlace.COMPLETO)));
            when(pendientes.consultarResolucion(CODIGO, "22")).thenReturn(Mono.just(con("22", Desenlace.EN_CURSO)));

            StepVerifier.create(casoDeUso.seguir(CODIGO, List.of("11", " 22 ", "11", "")))
                    .assertNext(r -> {
                        assertThat(r.desenlace()).isEqualTo(Desenlace.EN_CURSO);
                        assertThat(r.referencias()).containsExactly("11", "22");
                    })
                    .verifyComplete();
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("cuando terminan todas, el desenlace es el final, con sus fallos")
        void cuandoTerminanTodas() {
            when(pendientes.consultarResolucion(CODIGO, "11")).thenReturn(Mono.just(con("11", Desenlace.COMPLETO)));
            when(pendientes.consultarResolucion(CODIGO, "22")).thenReturn(Mono.just(new ResultadoResolucionMasiva(
                    List.of("22"), Desenlace.PARCIAL,
                    List.of(new ResultadoResolucionMasiva.Fallo("CLA-IP-RPND-004", "135282", "ya resuelto")))));

            StepVerifier.create(casoDeUso.seguir(CODIGO, List.of("11", "22")))
                    .assertNext(r -> {
                        assertThat(r.desenlace()).isEqualTo(Desenlace.PARCIAL);
                        assertThat(r.fallos()).extracting(ResultadoResolucionMasiva.Fallo::codigo)
                                              .containsExactly("CLA-IP-RPND-004");
                    })
                    .verifyComplete();
        }

        @ParameterizedTest(name = "«{0}» no es una lista de referencias")
        @NullAndEmptySource
        @Tag("OPE-06")
        void sinReferencias(List<String> referencias) {
            StepVerifier.create(casoDeUso.seguir(CODIGO, referencias))
                    .expectErrorSatisfies(e -> assertThat(((ExcepcionDeDominio) e).error())
                            .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class))
                    .verify();
            verify(pendientes, never()).consultarResolucion(any(), any());
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("solo blancos también es no indicar nada")
        void soloBlancos() {
            assertThat(errorDe(casoDeUso.seguir(CODIGO, java.util.Arrays.asList(" ", null))))
                    .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
        }

        @Test
        @Tag("OPE-06")
        @DisplayName("hay un tope de referencias por consulta")
        void topeDeReferencias() {
            var muchas = IntStream.rangeClosed(1, ResolverPendientesEnMasaCasoDeUso.MAXIMO_REFERENCIAS + 1)
                    .mapToObj(String::valueOf).toList();

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) errorDe(casoDeUso.seguir(CODIGO, muchas))).detalle())
                    .contains("No se pueden seguir más de 10");
            verify(pendientes, never()).consultarResolucion(any(), any());
        }
    }

    /**
     * OPE-03, modo en serie: la serie se respeta también cuando la primera operación no
     * termina a tiempo.
     * Con el sistema de registro ocupado —15 operaciones de este tipo a la vez en todo el
     * entorno— la de cabecera vuelve «en curso», que es un resultado y no un error.
     */
    @Nested
    @DisplayName("cabecera todavía en curso")
    class CabeceraEnCurso {

        @Test
        @org.junit.jupiter.api.Tag("OPE-03")
        @DisplayName("no se lanza la de líneas: el resultado sigue en curso y nombra lo que no salió")
        void noSeLanzaLaDeLineas() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3), motivo("AUD02", false, 2));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA,
                                            SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(new ResultadoResolucionMasiva(
                            java.util.List.of("op-cabecera"), Desenlace.EN_CURSO, java.util.List.of())));
            trazaFunciona();

            StepVerifier.create(enSerie().ejecutar(CODIGO, new java.util.LinkedHashSet<>(
                                    java.util.List.of("AUD01", "AUD02")),
                            NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace()).isEqualTo(Desenlace.EN_CURSO);
                        assertThat(resultado.referencias()).containsExactly("op-cabecera");
                        assertThat(resultado.fallos()).singleElement().satisfies(f -> {
                            assertThat(f.codigo()).isEqualTo("LINEAS_SIN_LANZAR");
                            assertThat(f.elemento()).isEqualTo("AUD01, AUD02");
                            assertThat(f.detalle()).contains("sigue en curso")
                                                   .contains("no se lanzó");
                        });
                    })
                    .verifyComplete();

            verify(pendientes, org.mockito.Mockito.never())
                    .resolverMotivos(any(), any(), org.mockito.ArgumentMatchers.eq(NivelPendiente.LINEA), any());
        }
    }

    /** En el modo en serie la de líneas solo sale si la de cabecera terminó. */
    @Nested
    @DisplayName("fallo parcial en DONDE_APLIQUE, en serie")
    class FalloParcial {

        @Test
        @DisplayName("si la cabecera va bien y las líneas fallan, el resultado es PARCIAL y lo dice")
        void siLasLineasFallanElResultadoEsParcial() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-cabecera")));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.error(new IllegalStateException("OHI rechazó las líneas")));
            trazaFunciona();

            StepVerifier.create(enSerie().ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR))
                    .assertNext(resultado -> {
                        assertThat(resultado.desenlace()).isEqualTo(Desenlace.PARCIAL);
                        assertThat(resultado.todoResuelto()).isFalse();
                        assertThat(resultado.referencias()).contains("op-cabecera");
                        assertThat(resultado.fallos()).singleElement().satisfies(f -> {
                            assertThat(f.codigo()).isEqualTo("NIVEL_LINEA");
                            assertThat(f.detalle())
                                    .contains("Los pendientes de cabecera se resolvieron")
                                    .contains("OHI rechazó las líneas");
                        });
                    })
                    .verifyComplete();
        }

        @Test
        @DisplayName("un error sin mensaje deja al menos el nombre de la excepción")
        void unErrorSinMensajeDejaElNombreDeLaExcepcion() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.CABECERA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-cabecera")));
            when(pendientes.resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, SeleccionLineas.TODAS))
                    .thenReturn(Mono.error(new IllegalStateException()));
            trazaFunciona();

            StepVerifier.create(enSerie().ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR))
                    .assertNext(r -> assertThat(r.fallos().get(0).detalle())
                            .contains("IllegalStateException"))
                    .verifyComplete();
        }
    }

    @Nested
    @DisplayName("traza")
    class Traza {

        @Test
        @DisplayName("la nota y el evento llevan nivel, motivos, desenlace y justificación")
        void laNotaYElEventoLlevanTodo() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 0));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.CUENTA, JUSTIFICACION, AUTOR))
                    .expectNextCount(1).verifyComplete();

            var nota = ArgumentCaptor.forClass(String.class);
            verify(notas).agregarNota(eq(CODIGO), eq(AUTOR), nota.capture());
            assertThat(nota.getValue())
                    .contains("CUENTA").contains("1 motivo(s)")
                    .contains("AUD01").contains(JUSTIFICACION);

            var evento = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(evento.capture());
            assertThat(evento.getValue().detalle())
                    .contains("AUD01").contains("CUENTA").contains("COMPLETO");
        }

        @Test
        @DisplayName("si fallan la nota y el evento, la resolución ya hecha no se pierde")
        void siFallaLaTrazaLaResolucionNoSePierde() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 0));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            when(notas.agregarNota(any(), any(), any()))
                    .thenReturn(Mono.error(new IllegalStateException("nota rechazada")));
            when(publicador.publicar(any()))
                    .thenReturn(Mono.error(new IllegalStateException("bus caído")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.CUENTA, JUSTIFICACION, AUTOR))
                    .assertNext(r -> assertThat(r.todoResuelto()).isTrue())
                    .verifyComplete();
        }
    }

    @Test
    @DisplayName("si la cuenta no publica acciones, se asume que no hay ninguna")
    void siLaCuentaNoPublicaAccionesSeAsumeNinguna() {
        when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.empty());
        when(pendientes.ubicarMotivos(eq(CODIGO), any())).thenReturn(Mono.just(
                java.util.Map.of("AUD01", motivo("AUD01", true, 0))));

        assertThat(errorDe(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                NivelResolucion.CUENTA, JUSTIFICACION, AUTOR)))
                .isInstanceOf(ErrorDeDominio.AccionNoDisponible.class);
    }

    @Test
    @DisplayName("el tope de motivos por operación es 50")
    void elTopeDeMotivosEs50() {
        assertThat(ResolverPendientesEnMasaCasoDeUso.MAXIMO_MOTIVOS).isEqualTo(50);
    }
    /**
     * Acotar la resolución a unas líneas.
     *
     * <p>Es lo que el auditor pide cuando ya identificó en qué líneas se presenta el motivo:
     * resolverlo <b>donde él decidió</b>, no en toda la cuenta. La capacidad estaba en el
     * sistema de registro desde siempre y este proyecto no la usaba.
     */
    @Nested
    @DisplayName("alcance por líneas")
    class AlcancePorLineas {

        private static final SeleccionLineas TRES = SeleccionLineas.de(List.of(
                new ReferenciaLinea(46_000_000_001L),
                new ReferenciaLinea(46_000_000_002L),
                new ReferenciaLinea(46_000_000_003L)));

        @Test
        @Tag("F2-12")
        @Tag("DBG-04")
        @DisplayName("la selección viaja a la resolución de línea")
        void laSeleccionViajaALaResolucionDeLinea() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", false, 20));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.LINEAS, JUSTIFICACION, AUTOR, TRES))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"), NivelPendiente.LINEA, TRES);
        }

        @Test
        @Tag("F2-12")
        @DisplayName("a la cabecera no se le acota: un pendiente de cabecera no es de ninguna línea")
        void aLaCabeceraNoSeLeAcota() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 20));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR, TRES))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"),
                                               NivelPendiente.CABECERA, SeleccionLineas.TODAS);
            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"),
                                               NivelPendiente.LINEA, TRES);
        }

        @Test
        @Tag("F2-12")
        @DisplayName("sin selección se resuelve en toda la cuenta, como siempre")
        void sinSeleccionSeResuelveEnTodaLaCuenta() {
            catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", false, 20));
            when(pendientes.resolverMotivos(any(), any(), any(), any()))
                    .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
            trazaFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                            NivelResolucion.LINEAS, JUSTIFICACION, AUTOR, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).resolverMotivos(CODIGO, Set.of("AUD01"),
                                               NivelPendiente.LINEA, SeleccionLineas.TODAS);
        }
    }

    @Test
    @Tag("EST-03.3")
    @DisplayName("[EST-03.3] no mira el estado de la cuenta: ni lee la cabecera, solo los enlaces de OHI")
    void noMiraElEstadoDeLaCuenta() {
        // Resolver pendientes no es cambiar datos: la regla de «solo en modificación» no le
        // aplica. Lo único que la frena es que OHI no publique la acción, como antes.
        catalogoDeLaCuenta(ambasAcciones(), motivo("AUD01", true, 3));
        when(pendientes.resolverMotivos(any(), any(), any(), any()))
                .thenReturn(Mono.just(ResultadoResolucionMasiva.completo("op-1")));
        trazaFunciona();

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, Set.of("AUD01"),
                        NivelResolucion.DONDE_APLIQUE, JUSTIFICACION, AUTOR))
                .expectNextCount(1).verifyComplete();

        verify(consultas, never()).buscarPorCodigo(any());
    }
}
