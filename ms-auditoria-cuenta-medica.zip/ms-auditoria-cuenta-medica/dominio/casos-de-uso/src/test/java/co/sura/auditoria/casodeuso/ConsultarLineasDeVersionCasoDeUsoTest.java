package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoLineasDeVersion;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/** Los códigos de cuenta son de prueba; ningún dato identifica a una persona. */
@ExtendWith(MockitoExtension.class)
@DisplayName("ConsultarLineasDeVersionCasoDeUso")
class ConsultarLineasDeVersionCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-29939061906");

    @Mock PuertoLineasDeVersion versiones;

    private ConsultarLineasDeVersionCasoDeUso caso;

    @BeforeEach
    void preparar() {
        caso = new ConsultarLineasDeVersionCasoDeUso(versiones);
    }

    private static boolean esDecisionInvalida(Throwable error, String mensaje) {
        return error instanceof ExcepcionDeDominio e
            && e.error() instanceof ErrorDeDominio.DecisionEnvioInvalida d
            && d.detalle().equals(mensaje);
    }

    private static LineaDeVersion linea(int numero) {
        return new LineaDeVersion(numero, "NEGADA", null, null, "890701", null, "CUPS", null, null,
                                  null, null, null, new BigDecimal("64400"), BigDecimal.ONE, null,
                                  null, BigDecimal.ZERO, null, new BigDecimal("64400"), null, null,
                                  List.of());
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("la página de una versión que existe se entrega tal cual")
    void paginaQueExiste() {
        var pagina = PaginaDesplazada.deOhi(List.of(linea(1), linea(127)), 0, 25, 60L, true);
        when(versiones.lineasDeVersion(CODIGO, 8, 0, 25)).thenReturn(Mono.just(pagina));

        StepVerifier.create(caso.lineas(CODIGO, 8, 0, 25)).expectNext(pagina).verifyComplete();
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("una versión que existe sin líneas es una página vacía, no un error")
    void versionSinLineas() {
        var vacia = PaginaDesplazada.<LineaDeVersion>deOhi(List.of(), 0, 25, 0L, false);
        when(versiones.lineasDeVersion(new CodigoCuenta("CM-8790"), 1, 0, 25))
                .thenReturn(Mono.just(vacia));

        StepVerifier.create(caso.lineas(new CodigoCuenta("CM-8790"), 1, 0, null))
                .expectNext(vacia).verifyComplete();
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("una versión que no existe es un error que la nombra, con el mensaje de la foto")
    void versionQueNoExiste() {
        when(versiones.lineasDeVersion(eq(CODIGO), eq(9), anyInt(), anyInt())).thenReturn(Mono.empty());

        StepVerifier.create(caso.lineas(CODIGO, 9, 0, 25))
                .expectErrorMatches(e -> esDecisionInvalida(e,
                        "La cuenta CM-29939061906 no tiene versión 9 en el histórico de lo transmitido"))
                .verify();
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("las versiones empiezan en 1: la 0 se rechaza sin preguntar")
    void versionCero() {
        StepVerifier.create(caso.lineas(CODIGO, 0, 0, 25))
                .expectErrorMatches(e -> esDecisionInvalida(e, "Las versiones empiezan en 1; se pidió la 0"))
                .verify();
        StepVerifier.create(caso.detalle(CODIGO, -1, 1))
                .expectErrorMatches(e -> esDecisionInvalida(e, "Las versiones empiezan en 1; se pidió la -1"))
                .verify();

        verifyNoInteractions(versiones);
    }

    @ParameterizedTest(name = "pedido {0} → {1}")
    @CsvSource({"0, 25", "-3, 25", "1, 1", "10, 10", "25, 25", "26, 25", "500, 25"})
    @Tag("BUS-21")
    @DisplayName("el tamaño se normaliza a [1, 25], como en las líneas de la cuenta viva")
    void normalizaElTamano(int pedido, int usado) {
        when(versiones.lineasDeVersion(CODIGO, 8, 0, usado))
                .thenReturn(Mono.just(PaginaDesplazada.vacia(usado)));

        caso.lineas(CODIGO, 8, 0, pedido).block();

        verify(versiones).lineasDeVersion(CODIGO, 8, 0, usado);
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("sin tamaño, 25; y un desplazamiento negativo es el principio")
    void sinTamanoYDesplazamientoNegativo() {
        when(versiones.lineasDeVersion(CODIGO, 8, 0, 25))
                .thenReturn(Mono.just(PaginaDesplazada.vacia(25)));

        caso.lineas(CODIGO, 8, -10, null).block();

        verify(versiones).lineasDeVersion(CODIGO, 8, 0, 25);
        assertThat(ConsultarLineasDeVersionCasoDeUso.normalizar(null)).isEqualTo(25);
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("una línea que la versión tiene se entrega sin preguntar si la versión existe")
    void detalleQueExiste() {
        var detalle = new DetalleLineaDeVersion(linea(1), List.of(), List.of(), null, null);
        when(versiones.detalleDeLinea(CODIGO, 8, 1)).thenReturn(Mono.just(detalle));

        StepVerifier.create(caso.detalle(CODIGO, 8, 1)).expectNext(detalle).verifyComplete();
        verify(versiones, never()).existeVersion(CODIGO, 8);
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("una línea que la versión no tiene: el error nombra la línea y la versión")
    void lineaQueNoEsta() {
        when(versiones.detalleDeLinea(CODIGO, 8, 2)).thenReturn(Mono.empty());
        when(versiones.existeVersion(CODIGO, 8)).thenReturn(Mono.just(true));

        StepVerifier.create(caso.detalle(CODIGO, 8, 2))
                .expectErrorMatches(e -> esDecisionInvalida(e,
                        "La versión 8 de la cuenta CM-29939061906 no tiene la línea 2"))
                .verify();
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("la línea de una versión que no existe: el error es el de la versión")
    void lineaDeUnaVersionQueNoExiste() {
        when(versiones.detalleDeLinea(CODIGO, 9, 1)).thenReturn(Mono.empty());
        when(versiones.existeVersion(CODIGO, 9)).thenReturn(Mono.just(false));

        StepVerifier.create(caso.detalle(CODIGO, 9, 1))
                .expectErrorMatches(e -> esDecisionInvalida(e,
                        "La cuenta CM-29939061906 no tiene versión 9 en el histórico de lo transmitido"))
                .verify();
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("el detalle siempre trae convenio y atención, aunque vengan vacíos")
    void detalleSinConvenioNiAtencion() {
        var detalle = new DetalleLineaDeVersion(linea(1), null, null, null, null);

        assertThat(detalle.convenio().clausulas()).isEmpty();
        assertThat(detalle.atencion().tipoSala()).isNull();
        assertThat(detalle.novedades()).isEmpty();
        assertThat(detalle.diagnosticos()).isEmpty();
    }
}
