package co.sura.auditoria.casodeuso;

import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ResumirMotivosPendientesCasoDeUso")
class ResumirMotivosPendientesCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    @Mock PuertoPendientes pendientes;
    @InjectMocks ResumirMotivosPendientesCasoDeUso casoDeUso;

    private static ResumenMotivoPendiente motivo(String codigo, int sinResolver,
                                                 int lineasAfectadas) {
        return new ResumenMotivoPendiente(codigo, "desc " + codigo, sinResolver,
                lineasAfectadas, false, false, false);
    }

    @Test
    @DisplayName("ordena primero por cantidad sin resolver, de mayor a menor")
    void ordenaPrimeroPorSinResolver() {
        when(pendientes.resumirMotivos(CODIGO)).thenReturn(Flux.just(
                motivo("A", 1, 0), motivo("B", 9, 0), motivo("C", 5, 0)));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO).map(ResumenMotivoPendiente::codigo))
                .expectNext("B", "C", "A")
                .verifyComplete();
    }

    @Test
    @DisplayName("a igual cantidad sin resolver, desempata por líneas afectadas")
    void desempataPorLineasAfectadas() {
        when(pendientes.resumirMotivos(CODIGO)).thenReturn(Flux.just(
                motivo("A", 3, 1), motivo("B", 3, 7), motivo("C", 3, 4)));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO).map(ResumenMotivoPendiente::codigo))
                .expectNext("B", "C", "A")
                .verifyComplete();
    }

    @Test
    @DisplayName("a igual peso, desempata por código alfabético para que el orden sea estable")
    void desempataPorCodigoAlfabetico() {
        when(pendientes.resumirMotivos(CODIGO)).thenReturn(Flux.just(
                motivo("TAR03", 2, 2), motivo("AUD01", 2, 2), motivo("GLO02", 2, 2)));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO).map(ResumenMotivoPendiente::codigo))
                .expectNext("AUD01", "GLO02", "TAR03")
                .verifyComplete();
    }

    @Test
    @DisplayName("los tres criterios se aplican en cascada")
    void losTresCriteriosEnCascada() {
        when(pendientes.resumirMotivos(CODIGO)).thenReturn(Flux.just(
                motivo("Z", 1, 9),   // menos sin resolver: va último pese a sus 9 líneas
                motivo("B", 5, 1),
                motivo("A", 5, 1),   // mismo peso que B: gana por código
                motivo("C", 5, 8))); // mismo sinResolver, más líneas: va primero

        StepVerifier.create(casoDeUso.ejecutar(CODIGO).map(ResumenMotivoPendiente::codigo))
                .expectNext("C", "A", "B", "Z")
                .verifyComplete();
    }

    @Test
    @DisplayName("una cuenta sin motivos devuelve un flujo vacío, no un error")
    void sinMotivosDevuelveFlujoVacio() {
        when(pendientes.resumirMotivos(CODIGO)).thenReturn(Flux.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO)).verifyComplete();
    }

    @Test
    @DisplayName("un error del puerto se propaga")
    void unErrorDelPuertoSePropaga() {
        var caida = new IllegalStateException("OHI no responde");
        when(pendientes.resumirMotivos(CODIGO)).thenReturn(Flux.error(caida));

        StepVerifier.create(casoDeUso.ejecutar(CODIGO))
                .expectErrorMatches(e -> e == caida)
                .verify();
    }
}
