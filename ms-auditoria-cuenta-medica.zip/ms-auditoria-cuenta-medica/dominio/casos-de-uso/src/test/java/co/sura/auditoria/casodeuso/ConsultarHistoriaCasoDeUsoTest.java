package co.sura.auditoria.casodeuso;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.HitoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoHistoriaCuenta;
import java.time.Instant;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ConsultarHistoriaCasoDeUso")
class ConsultarHistoriaCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-117897397334");

    @Mock PuertoHistoriaCuenta historia;

    @Test
    @Tag("BTN-06")
    @DisplayName("entrega los hitos tal como los da el puerto, sin reordenarlos otra vez")
    void entregaLosHitos() {
        // El orden lo fija la capa de integración, que es quien une los dos recursos y la
        // única que sabe de qué fecha viene cada uno. Reordenar aquí duplicaría la regla.
        var caso = new ConsultarHistoriaCasoDeUso(historia);
        when(historia.consultar(any())).thenReturn(Flux.just(
                new HitoCuenta(HitoCuenta.Tipo.CAMBIO_DE_ESTADO, "INICIAL", null,
                               "Internal System User", Instant.parse("2026-10-15T11:43:29Z")),
                new HitoCuenta(HitoCuenta.Tipo.DESFINALIZACION, "PRORROGA", "Prorroga",
                               "auditor", Instant.parse("2026-10-17T16:28:34Z"))));

        StepVerifier.create(caso.ejecutar(CODIGO)).expectNextCount(2).verifyComplete();

        verify(historia).consultar(CODIGO);
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("una cuenta sin historia no es un error: son cero hitos")
    void sinHistoriaNoEsError() {
        var caso = new ConsultarHistoriaCasoDeUso(historia);
        when(historia.consultar(any())).thenReturn(Flux.empty());

        StepVerifier.create(caso.ejecutar(CODIGO)).verifyComplete();
    }
}
