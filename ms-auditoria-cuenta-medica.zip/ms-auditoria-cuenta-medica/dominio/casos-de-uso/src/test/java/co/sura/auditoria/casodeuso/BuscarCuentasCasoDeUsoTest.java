package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroCuentas;
import co.sura.auditoria.modelo.cuenta.FotoVersion;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ResumenCuenta;
import co.sura.auditoria.modelo.cuenta.VersionCuenta;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoBusquedaCuentas;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("BuscarCuentasCasoDeUso")
class BuscarCuentasCasoDeUsoTest {

    private static final CodigoCuenta A = new CodigoCuenta("CM-94421");
    private static final CodigoCuenta B = new CodigoCuenta("CM-57944424433");

    @Mock PuertoBusquedaCuentas busqueda;

    private BuscarCuentasCasoDeUso caso;

    @BeforeEach
    void preparar() {
        caso = new BuscarCuentasCasoDeUso(busqueda);
    }

    private static boolean esDecisionInvalida(Throwable error, String fragmento) {
        return error instanceof ExcepcionDeDominio e
            && e.error() instanceof ErrorDeDominio.DecisionEnvioInvalida d
            && d.detalle().contains(fragmento);
    }

    @Test
    @Tag("BUS-01")
    @DisplayName("sin criterio no sale: no es una búsqueda, es un listado de once mil cuentas")
    void sinCriterioNoSale() {
        StepVerifier.create(caso.ejecutar(new FiltroCuentas(" ", null), 0, 25))
                .expectErrorMatches(e -> esDecisionInvalida(e, "al menos un criterio"))
                .verify();
        StepVerifier.create(caso.ejecutar(null, 0, 25))
                .expectErrorMatches(e -> esDecisionInvalida(e, "al menos un criterio"))
                .verify();

        verifyNoInteractions(busqueda);
    }

    @Test
    @Tag("BUS-03")
    @DisplayName("una factura radicada tres veces devuelve las tres cuentas")
    void facturaRepetida() {
        var filas = List.of(resumen(A), resumen(B), resumen(new CodigoCuenta("CM-1")));
        when(busqueda.buscar(any(), anyInt(), anyInt()))
                .thenReturn(Mono.just(PaginaDesplazada.deOhi(filas, 0, 25, 3L, false)));

        StepVerifier.create(caso.ejecutar(new FiltroCuentas("JONATHAN201", null), 0, 25))
                .assertNext(p -> assertThat(p.elementos()).hasSize(3))
                .verifyComplete();
    }

    @Test
    @Tag("BUS-03")
    @DisplayName("una factura que no existe es una lista vacía, no un error")
    void facturaInexistente() {
        when(busqueda.buscar(any(), anyInt(), anyInt()))
                .thenReturn(Mono.just(PaginaDesplazada.vacia(25)));

        StepVerifier.create(caso.ejecutar(new FiltroCuentas("NO-EXISTE", null), 0, 25))
                .assertNext(p -> assertThat(p.elementos()).isEmpty())
                .verifyComplete();
    }

    @Test
    @Tag("BUS-01")
    @DisplayName("el tamaño de página se acota: sin pedir, 25; pidiendo de más, 50; desplazamiento negativo, 0")
    void normalizaLaPagina() {
        var filtro = new FiltroCuentas(null, "CM-9442");
        when(busqueda.buscar(any(), anyInt(), anyInt()))
                .thenReturn(Mono.just(PaginaDesplazada.vacia(25)));

        caso.ejecutar(filtro, -3, null).block();
        verify(busqueda).buscar(filtro, 0, BuscarCuentasCasoDeUso.TAMANO_PAGINA_PREDETERMINADO);

        caso.ejecutar(filtro, 50, 0).block();
        verify(busqueda).buscar(filtro, 50, BuscarCuentasCasoDeUso.TAMANO_PAGINA_PREDETERMINADO);

        caso.ejecutar(filtro, 0, 500).block();
        verify(busqueda).buscar(filtro, 0, BuscarCuentasCasoDeUso.TAMANO_PAGINA_MAXIMO);

        caso.ejecutar(filtro, 10, 10).block();
        verify(busqueda).buscar(filtro, 10, 10);
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("las versiones se agrupan por cuenta; la que no se transmitió no aparece")
    void versionesAgrupadas() {
        when(busqueda.versionesDe(any())).thenReturn(Mono.just(List.of(
                version(B, 1), version(B, 2), version(B, 3), version(A, 1))));

        StepVerifier.create(caso.versionesDe(List.of(A, B, new CodigoCuenta("CM-SIN"))))
                .assertNext(mapa -> {
                    assertThat(mapa).containsOnlyKeys(A.valor(), B.valor());
                    assertThat(mapa.get(B.valor())).extracting(VersionCuenta::numero)
                            .containsExactly(1, 2, 3);
                })
                .verifyComplete();
    }

    @Test
    @Tag("BUS-13")
    @DisplayName("sin códigos no se pregunta nada al sistema de registro")
    void sinCodigos() {
        StepVerifier.create(caso.versionesDe(List.of()))
                .assertNext(mapa -> assertThat(mapa).isEmpty()).verifyComplete();
        StepVerifier.create(caso.versionesDe(null))
                .assertNext(mapa -> assertThat(mapa).isEmpty()).verifyComplete();

        verifyNoInteractions(busqueda);
    }

    @Test
    @Tag("BUS-20")
    @DisplayName("la foto de una versión que existe se entrega tal cual")
    void fotoQueExiste() {
        var foto = new FotoVersion(B, 2, LocalDate.of(2026, 9, 2), "JONATHAN201", "Prestador",
                                   new BigDecimal("6000000"), null, null, null, null, null, List.of());
        when(busqueda.fotoDeVersion(B, 2)).thenReturn(Mono.just(foto));

        StepVerifier.create(caso.fotoDeVersion(B, 2)).expectNext(foto).verifyComplete();
    }

    @Test
    @Tag("BUS-20")
    @DisplayName("pedir una versión que no existe es un error que la nombra, no una foto en blanco")
    void fotoQueNoExiste() {
        when(busqueda.fotoDeVersion(eq(B), eq(7))).thenReturn(Mono.empty());

        StepVerifier.create(caso.fotoDeVersion(B, 7))
                .expectErrorMatches(e -> esDecisionInvalida(e, "no tiene versión 7"))
                .verify();
    }

    @Test
    @Tag("BUS-20")
    @DisplayName("las versiones empiezan en 1: la 0 se rechaza sin preguntar")
    void versionCero() {
        StepVerifier.create(caso.fotoDeVersion(B, 0))
                .expectErrorMatches(e -> esDecisionInvalida(e, "empiezan en 1"))
                .verify();

        verifyNoInteractions(busqueda);
    }

    private static ResumenCuenta resumen(CodigoCuenta codigo) {
        return new ResumenCuenta(codigo, "JONATHAN201", LocalDate.of(2026, 10, 1), "800000000",
                                 "Prestador de prueba", BigDecimal.TEN, null, "FINALIZED");
    }

    private static VersionCuenta version(CodigoCuenta codigo, int numero) {
        return new VersionCuenta(codigo, numero, LocalDate.of(2026, 9, numero), BigDecimal.TEN,
                                 "Finalizado", Instant.parse("2026-09-0" + numero + "T10:00:00Z"));
    }
}
