package co.sura.auditoria.casodeuso;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import co.sura.auditoria.modelo.cuenta.EstadoProceso.Avance;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("SeguirProcesoCasoDeUso")
class SeguirProcesoCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    /** Intervalo corto: la prueba no debe tardar más que lo que mide. */
    private static final Duration INTERVALO = Duration.ofMillis(10);
    private static final Duration ESPERA_MAXIMA = Duration.ofSeconds(5);

    @Mock PuertoConsultaCuentas consultas;

    private SeguirProcesoCasoDeUso casoDeUso() {
        return new SeguirProcesoCasoDeUso(consultas, INTERVALO, ESPERA_MAXIMA);
    }

    private static EstadoProceso estado(Avance avance, boolean finalizado) {
        return new EstadoProceso(avance, finalizado, List.of());
    }

    @Test
    @DisplayName("consultarUnaVez delega sin montar el flujo periódico")
    void consultarUnaVezDelega() {
        var unico = estado(Avance.EN_PROCESO, false);
        when(consultas.consultarEstadoProceso(CODIGO)).thenReturn(Mono.just(unico));

        StepVerifier.create(casoDeUso().consultarUnaVez(CODIGO))
                .expectNext(unico)
                .verifyComplete();
    }

    @Test
    @DisplayName("la transmisión se corta en cuanto el proceso dice que terminó")
    void laTransmisionSeCortaAlFinalizar() {
        when(consultas.consultarEstadoProceso(any()))
                .thenReturn(Mono.just(estado(Avance.EN_PROCESO, false)))
                .thenReturn(Mono.just(estado(Avance.EXITOSO, true)))
                // Si el takeUntil no funcionara, seguiría emitiendo esto:
                .thenReturn(Mono.just(estado(Avance.FALLIDO, true)));

        StepVerifier.create(casoDeUso().transmitir(CODIGO).map(EstadoProceso::avance))
                .expectNext(Avance.EN_PROCESO, Avance.EXITOSO)
                .verifyComplete();
    }

    @Test
    @DisplayName("no repite el mismo avance: solo emite cuando cambia")
    void noRepiteElMismoAvance() {
        when(consultas.consultarEstadoProceso(any()))
                .thenReturn(Mono.just(estado(Avance.EN_PROCESO, false)))
                .thenReturn(Mono.just(estado(Avance.EN_PROCESO, false)))
                .thenReturn(Mono.just(estado(Avance.EN_PROCESO, false)))
                .thenReturn(Mono.just(estado(Avance.EXITOSO, true)));

        StepVerifier.create(casoDeUso().transmitir(CODIGO).map(EstadoProceso::avance))
                .expectNext(Avance.EN_PROCESO, Avance.EXITOSO)
                .verifyComplete();
    }

    @Test
    @DisplayName("un proceso fallido también cierra la transmisión")
    void unProcesoFallidoTambienCierra() {
        when(consultas.consultarEstadoProceso(any()))
                .thenReturn(Mono.just(estado(Avance.FALLIDO, true)));

        StepVerifier.create(casoDeUso().transmitir(CODIGO).map(EstadoProceso::avance))
                .expectNext(Avance.FALLIDO)
                .verifyComplete();
    }

    @Test
    @DisplayName("la espera máxima corta la transmisión aunque el proceso no termine nunca")
    void laEsperaMaximaCortaLaTransmision() {
        // Un proceso que nunca finaliza y nunca cambia de avance: sin el tope,
        // el flujo quedaría abierto para siempre.
        when(consultas.consultarEstadoProceso(any()))
                .thenReturn(Mono.just(estado(Avance.EN_PROCESO, false)));

        var conTopeCorto = new SeguirProcesoCasoDeUso(consultas, INTERVALO,
                Duration.ofMillis(100));

        StepVerifier.create(conTopeCorto.transmitir(CODIGO))
                .expectNextCount(1)
                .verifyComplete();
    }
}
