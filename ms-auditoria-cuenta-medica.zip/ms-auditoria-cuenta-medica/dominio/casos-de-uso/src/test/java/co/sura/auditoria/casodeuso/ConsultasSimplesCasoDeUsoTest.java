package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/** Los casos de uso que solo delegan o traducen el vacío a un error de dominio. */
@ExtendWith(MockitoExtension.class)
@DisplayName("Casos de uso de consulta simple")
class ConsultasSimplesCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    @Mock PuertoConsultaCuentas consultas;

    @Nested
    @DisplayName("ConsultarDetalleLineaCasoDeUso")
    class ConsultarDetalleLinea {

        private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(148111592284L);

        @Test
        @DisplayName("devuelve el detalle que encuentra el puerto")
        void devuelveElDetalleQueEncuentra() {
            var detalle = org.mockito.Mockito.mock(LineaCuenta.class);
            when(consultas.buscarDetalleLinea(CODIGO, REFERENCIA)).thenReturn(Mono.just(detalle));

            StepVerifier.create(new ConsultarDetalleLineaCasoDeUso(consultas)
                            .ejecutar(CODIGO, REFERENCIA))
                    .expectNext(detalle)
                    .verifyComplete();
        }

        @Test
        @DisplayName("un vacío se traduce a LineaNoEncontrada, con la referencia pedida")
        void unVacioSeTraduceALineaNoEncontrada() {
            when(consultas.buscarDetalleLinea(CODIGO, REFERENCIA)).thenReturn(Mono.empty());

            StepVerifier.create(new ConsultarDetalleLineaCasoDeUso(consultas)
                            .ejecutar(CODIGO, REFERENCIA))
                    .expectErrorSatisfies(error -> assertThat(error)
                            .isInstanceOf(ExcepcionDeDominio.class)
                            .extracting(e -> ((ExcepcionDeDominio) e).error())
                            .isEqualTo(new ErrorDeDominio.LineaNoEncontrada(148111592284L)))
                    .verify();
        }
    }

    @Nested
    @DisplayName("ConsultarAccionesCasoDeUso")
    class ConsultarAcciones {

        @Test
        @DisplayName("delega en el puerto y devuelve lo que llegue")
        void delegaEnElPuerto() {
            var disponibles = new AccionesDisponibles(Set.of(AccionCuenta.ENVIAR));
            when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.just(disponibles));

            StepVerifier.create(new ConsultarAccionesCasoDeUso(consultas).ejecutar(CODIGO))
                    .expectNext(disponibles)
                    .verifyComplete();

            verify(consultas).consultarAccionesDisponibles(CODIGO);
        }

        @Test
        @DisplayName("un vacío se propaga como vacío: no hay acciones no es un error")
        void unVacioSePropagaComoVacio() {
            when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.empty());

            StepVerifier.create(new ConsultarAccionesCasoDeUso(consultas).ejecutar(CODIGO))
                    .verifyComplete();
        }
    }

    @Nested
    @DisplayName("ResumirFiltrosLineasCasoDeUso")
    class ResumirFiltrosLineas {

        @Test
        @DisplayName("delega en el puerto")
        void delegaEnElPuerto() {
            var resumen = ResumenFiltrosLineas.vacio();
            when(consultas.resumirFiltrosDeLineas(CODIGO)).thenReturn(Mono.just(resumen));

            StepVerifier.create(new ResumirFiltrosLineasCasoDeUso(consultas).ejecutar(CODIGO))
                    .expectNext(resumen)
                    .verifyComplete();

            verify(consultas).resumirFiltrosDeLineas(CODIGO);
        }
    }
}
