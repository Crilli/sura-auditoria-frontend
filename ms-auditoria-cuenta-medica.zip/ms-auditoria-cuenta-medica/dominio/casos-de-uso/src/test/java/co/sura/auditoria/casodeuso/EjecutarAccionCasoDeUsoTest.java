package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion.Ambito;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivos;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("EjecutarAccionCasoDeUso")
class EjecutarAccionCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final String AUTOR = "auditor@sura.com.co";

    @Mock PuertoConsultaCuentas consultas;

    /** Sin caché en las pruebas: la consulta fresca dice lo mismo que la guardada. */
    @org.junit.jupiter.api.BeforeEach
    void frescasComoLasGuardadas() {
        org.mockito.Mockito.lenient().when(consultas.consultarAccionesFrescas(org.mockito.ArgumentMatchers.any()))
                .thenAnswer(inv -> consultas.consultarAccionesDisponibles(inv.getArgument(0)));
    }
    @Mock PuertoComandosCuenta comandos;
    @Mock PuertoCatalogoMotivos catalogo;
    @Mock PublicadorEventosAuditoria publicador;
    @InjectMocks EjecutarAccionCasoDeUso casoDeUso;

    private static CuentaMedica cuenta() {
        return new CuentaMedica(CODIGO, EstadoCuenta.MODIFICACION, LocalDate.now(),
                LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN, new Version(1L),
                List.of(), List.of(), null, List.of());
    }

    private static MotivoDesfinalizacion motivo(String codigo, boolean exigeReferencia,
                                                Ambito ambito) {
        return new MotivoDesfinalizacion(codigo, "desc", false, exigeReferencia, ambito, null);
    }

    private void permite(AccionCuenta... acciones) {
        when(consultas.consultarAccionesDisponibles(CODIGO))
                .thenReturn(Mono.just(new AccionesDisponibles(Set.of(acciones))));
    }

    private void comandoFunciona() {
        when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.just(cuenta()));
        when(publicador.publicar(any())).thenReturn(Mono.empty());
    }

    private ErrorDeDominio errorDe(Mono<CuentaMedica> resultado) {
        var capturado = new ErrorDeDominio[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(e -> capturado[0] = ((ExcepcionDeDominio) e).error())
                .verify();
        return capturado[0];
    }

    @ParameterizedTest(name = "autor [{0}]")
    @NullAndEmptySource
    @ValueSource(strings = {"  "})
    @DisplayName("una acción sin auditor no se ejecuta: tiene que quedar firmada")
    void sinAuditorNoSeEjecuta(String autor) {
        var error = errorDe(casoDeUso.ejecutar(CODIGO,
                EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION), autor));

        assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                .contains("tiene que quedar firmada");
        verify(consultas, never()).consultarAccionesDisponibles(any());
    }

    @Test
    @DisplayName("si OHI no ofrece la acción, no se intenta ejecutar")
    void siNoSeOfreceLaAccionNoSeEjecuta() {
        permite(AccionCuenta.ENVIAR);

        var error = errorDe(casoDeUso.ejecutar(CODIGO,
                EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION), AUTOR));

        assertThat(error).isInstanceOf(ErrorDeDominio.AccionNoDisponible.class);
        verify(comandos, never()).ejecutarAccion(any(), any());
    }

    @Nested
    @DisplayName("comprobación de motivos")
    class ComprobacionDeMotivos {

        @Test
        @DisplayName("una acción sin motivos no consulta el catálogo")
        void sinMotivosNoSeConsultaElCatalogo() {
            permite(AccionCuenta.DEVOLVER_A_MODIFICACION);
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                            EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION), AUTOR))
                    .expectNextCount(1).verifyComplete();

            verify(catalogo, never()).listar();
        }

        @Test
        @DisplayName("un motivo que el catálogo no tiene se rechaza")
        void unMotivoDesconocidoSeRechaza() {
            permite(AccionCuenta.REVERTIR_FINALIZACION);
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(motivo("M1", false, Ambito.AMBAS))));
            lenient().when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.just(cuenta()));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, EjecucionAccion.conMotivos(
                    AccionCuenta.REVERTIR_FINALIZACION, List.of("INVENTADO"), null), AUTOR));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("este motivo").contains("INVENTADO");
            verify(publicador, never()).publicar(any());
        }

        @Test
        @DisplayName("con varios desconocidos el mensaje va en plural")
        void conVariosDesconocidosVaEnPlural() {
            permite(AccionCuenta.REVERTIR_FINALIZACION);
            when(catalogo.listar()).thenReturn(Mono.just(List.of()));
            lenient().when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.just(cuenta()));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, EjecucionAccion.conMotivos(
                    AccionCuenta.REVERTIR_FINALIZACION, List.of("A", "B"), null), AUTOR));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("estos motivos").contains("A, B");
        }

        @Test
        @DisplayName("un motivo que exige referencia sin ella se rechaza")
        void unMotivoQueExigeReferenciaSinEllaSeRechaza() {
            permite(AccionCuenta.REVERTIR_FINALIZACION);
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(motivo("M1", true, Ambito.AMBAS))));
            lenient().when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.just(cuenta()));

            var error = errorDe(casoDeUso.ejecutar(CODIGO, EjecucionAccion.conMotivos(
                    AccionCuenta.REVERTIR_FINALIZACION, List.of("M1"), null), AUTOR));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("El motivo").contains("referencia de origen").contains("M1");
        }

        @Test
        @DisplayName("una referencia en blanco cuenta como ausente")
        void unaReferenciaEnBlancoCuentaComoAusente() {
            permite(AccionCuenta.REVERTIR_FINALIZACION);
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(motivo("M1", true, Ambito.AMBAS))));
            lenient().when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.just(cuenta()));

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, EjecucionAccion.conMotivos(
                    AccionCuenta.REVERTIR_FINALIZACION, List.of("M1"), "   "), AUTOR)))
                    .isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
        }

        @Test
        @DisplayName("con la referencia puesta, el motivo que la exige pasa")
        void conLaReferenciaPuestaPasa() {
            permite(AccionCuenta.REVERTIR_FINALIZACION);
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(motivo("M1", true, Ambito.AMBAS))));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, EjecucionAccion.conMotivos(
                            AccionCuenta.REVERTIR_FINALIZACION, List.of("M1"), "REF-1"), AUTOR))
                    .expectNextCount(1).verifyComplete();
        }

        @Test
        @DisplayName("un motivo que NO exige referencia pasa sin ella")
        void unMotivoQueNoExigeReferenciaPasaSinElla() {
            permite(AccionCuenta.REVERTIR_FINALIZACION);
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(motivo("M1", false, Ambito.AMBAS))));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, EjecucionAccion.conMotivos(
                            AccionCuenta.REVERTIR_FINALIZACION, List.of("M1"), null), AUTOR))
                    .expectNextCount(1).verifyComplete();
        }
    }

    @Nested
    @DisplayName("traza")
    class Traza {

        @Test
        @DisplayName("marca IRREVERSIBLE la anulación, que es la que no tiene vuelta")
        void marcaIrreversibleLaAnulacion() {
            permite(AccionCuenta.ANULAR);
            when(catalogo.listar())
                    .thenReturn(Mono.just(List.of(motivo("M1", false, Ambito.AMBAS))));
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                            EjecucionAccion.anular(List.of("M1"), "REF-1", "ANULACION_010"), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .startsWith("ANULAR")
                    .contains("motivos: M1")
                    .contains("referencia: REF-1")
                    .contains("IRREVERSIBLE");
        }

        @Test
        @DisplayName("una acción simple no se marca irreversible")
        void unaAccionSimpleNoSeMarcaIrreversible() {
            permite(AccionCuenta.DEVOLVER_A_MODIFICACION);
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                            EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .isEqualTo("DEVOLVER_A_MODIFICACION");
        }

        @Test
        @DisplayName("el desbloqueo deja las líneas en la traza")
        void elDesbloqueoDejaLasLineasEnLaTraza() {
            permite(AccionCuenta.DESBLOQUEAR_LINEAS);
            comandoFunciona();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                            EjecucionAccion.desbloquear(List.of(10L, 20L)), AUTOR))
                    .expectNextCount(1).verifyComplete();

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle()).contains("líneas: 10, 20");
        }

        @Test
        @DisplayName("si falla la traza, la acción ya ejecutada no se pierde")
        void siFallaLaTrazaLaAccionNoSePierde() {
            permite(AccionCuenta.DEVOLVER_A_MODIFICACION);
            when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.just(cuenta()));
            when(publicador.publicar(any()))
                    .thenReturn(Mono.error(new IllegalStateException("bus caído")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                            EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION), AUTOR))
                    .expectNextCount(1).verifyComplete();
        }
    }

    @Nested
    @DisplayName("motivosPara")
    class MotivosPara {

        @Test
        @DisplayName("sin ámbito devuelve todos")
        void sinAmbitoDevuelveTodos() {
            when(catalogo.listar()).thenReturn(Mono.just(List.of(
                    motivo("A", false, Ambito.CUENTA_MEDICA),
                    motivo("B", false, Ambito.AUTORIZACION))));

            StepVerifier.create(casoDeUso.motivosPara(null))
                    .assertNext(l -> assertThat(l).hasSize(2))
                    .verifyComplete();
        }

        @Test
        @DisplayName("filtra por ámbito, e incluye los de ámbito AMBAS")
        void filtraPorAmbitoEIncluyeAmbas() {
            when(catalogo.listar()).thenReturn(Mono.just(List.of(
                    motivo("A", false, Ambito.CUENTA_MEDICA),
                    motivo("B", false, Ambito.AUTORIZACION),
                    motivo("C", false, Ambito.AMBAS))));

            StepVerifier.create(casoDeUso.motivosPara(Ambito.CUENTA_MEDICA)
                            .map(l -> l.stream().map(MotivoDesfinalizacion::codigo).toList()))
                    .expectNext(List.of("A", "C"))
                    .verifyComplete();
        }
    }

    @Test
    @org.junit.jupiter.api.Tag("OPE-11")
    @DisplayName("si la acción se ejecutó pero no se pudo releer la cuenta, la traza queda y el error sigue")
    void aplicadoSinRelecturaDejaTraza() {
        permite(AccionCuenta.DEVOLVER_A_MODIFICACION);
        when(comandos.ejecutarAccion(any(), any())).thenReturn(Mono.error(co.sura.auditoria.modelo.error.ExcepcionDeDominio.de(new co.sura.auditoria.modelo.error.ErrorDeDominio.AplicadoSinRelectura("x", "timeout"))));
        when(publicador.publicar(any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO,
                        EjecucionAccion.simple(AccionCuenta.DEVOLVER_A_MODIFICACION), AUTOR))
                .expectError().verify();
        verify(publicador).publicar(any());
    }
}
