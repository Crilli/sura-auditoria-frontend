package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.Pagina;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ListarPendientesCasoDeUso")
class ListarPendientesCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    @Mock PuertoPendientes pendientes;
    @InjectMocks ListarPendientesCasoDeUso casoDeUso;

    @Captor ArgumentCaptor<Integer> tamanoCaptor;
    @Captor ArgumentCaptor<Boolean> incluirTotalCaptor;
    @Captor ArgumentCaptor<String> motivoCaptor;
    @Captor ArgumentCaptor<FiltroBloqueo> bloqueoCaptor;

    private static PaginaPendientes paginaVacia() {
        return new PaginaPendientes(Pagina.<MotivoPendiente>vacia(25), EstadoCuenta.MODIFICACION);
    }

    private void devuelvePagina() {
        when(pendientes.listarPaginado(any(), any(), anyInt(), anyBoolean(), any(), any(), anyBoolean()))
                .thenReturn(Mono.just(paginaVacia()));
    }

    @Nested
    @DisplayName("tamaño de página")
    class TamanoDePagina {

        @ParameterizedTest(name = "{0} se normaliza al predeterminado de 25")
        @NullSource
        @ValueSource(ints = {0, -1, -100})
        @DisplayName("nulo, cero y negativos caen al predeterminado")
        void nuloCeroYNegativosCaenAlPredeterminado(Integer solicitado) {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, solicitado,
                            null, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), tamanoCaptor.capture(),
                    anyBoolean(), any(), any(), anyBoolean());
            assertThat(tamanoCaptor.getValue())
                    .isEqualTo(ListarPendientesCasoDeUso.TAMANO_PAGINA_PREDETERMINADO);
        }

        @Test
        @DisplayName("un tamaño por encima del máximo se recorta a 25")
        void unTamanoExcesivoSeRecorta() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 5000,
                            null, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), tamanoCaptor.capture(),
                    anyBoolean(), any(), any(), anyBoolean());
            assertThat(tamanoCaptor.getValue())
                    .isEqualTo(ListarPendientesCasoDeUso.TAMANO_PAGINA_MAXIMO);
        }

        @Test
        @DisplayName("un tamaño dentro del rango se respeta")
        void unTamanoValidoSeRespeta() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 10, null, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), tamanoCaptor.capture(),
                    anyBoolean(), any(), any(), anyBoolean());
            assertThat(tamanoCaptor.getValue()).isEqualTo(10);
        }
    }

    @Nested
    @DisplayName("total de registros")
    class TotalDeRegistros {

        @Test
        @DisplayName("solo se pide en la primera página, para no pagar un COUNT por salto")
        void soloSePideEnLaPrimeraPagina() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 25, null, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), anyInt(),
                    incluirTotalCaptor.capture(), any(), any(), anyBoolean());
            assertThat(incluirTotalCaptor.getValue()).isTrue();
        }

        @Test
        @DisplayName("en páginas siguientes no se pide")
        void enPaginasSiguientesNoSePide() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, new Cursor(148111592284L), 25,
                            null, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), anyInt(),
                    incluirTotalCaptor.capture(), any(), any(), anyBoolean());
            assertThat(incluirTotalCaptor.getValue()).isFalse();
        }
    }

    @Nested
    @DisplayName("normalización de los criterios")
    class NormalizacionDeCriterios {

        @ParameterizedTest(name = "un motivo [{0}] viaja como nulo")
        @NullSource
        @ValueSource(strings = {"", "   "})
        @DisplayName("un motivo en blanco es como no filtrar")
        void unMotivoEnBlancoEsComoNoFiltrar(String motivo) {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 25,
                            motivo, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), anyInt(), anyBoolean(),
                    motivoCaptor.capture(), any(), anyBoolean());
            assertThat(motivoCaptor.getValue()).isNull();
        }

        @Test
        @DisplayName("al motivo se le recortan los espacios")
        void alMotivoSeLeRecortanLosEspacios() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 25,
                            "  AUD01  ", null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), anyInt(), anyBoolean(),
                    motivoCaptor.capture(), any(), anyBoolean());
            assertThat(motivoCaptor.getValue()).isEqualTo("AUD01");
        }

        @Test
        @DisplayName("sin filtro de bloqueo se usa TODOS, no nulo")
        void sinFiltroDeBloqueoSeUsaTodos() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 25, null, null))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), anyInt(), anyBoolean(), any(),
                    bloqueoCaptor.capture(), anyBoolean());
            assertThat(bloqueoCaptor.getValue()).isEqualTo(FiltroBloqueo.TODOS);
        }

        @Test
        @DisplayName("el filtro de bloqueo indicado se respeta")
        void elFiltroDeBloqueoIndicadoSeRespeta() {
            devuelvePagina();

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 25, null,
                            FiltroBloqueo.BLOQUEANTES))
                    .expectNextCount(1).verifyComplete();

            verify(pendientes).listarPaginado(any(), any(), anyInt(), anyBoolean(), any(),
                    eq(FiltroBloqueo.BLOQUEANTES), anyBoolean());
        }
    }

    @Test
    @DisplayName("un Mono vacío se traduce a CuentaNoEncontrada")
    void unMonoVacioSeTraduceACuentaNoEncontrada() {
        when(pendientes.listarPaginado(any(), any(), anyInt(), anyBoolean(), any(), any(), anyBoolean()))
                .thenReturn(Mono.empty());;

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, Cursor.PRIMERA_PAGINA, 25, null, null))
                .expectErrorSatisfies(error -> assertThat(error)
                        .isInstanceOf(ExcepcionDeDominio.class)
                        .extracting(e -> ((ExcepcionDeDominio) e).error())
                        .isEqualTo(new ErrorDeDominio.CuentaNoEncontrada("CM-108800618430")))
                .verify();
    }

    @Test
    @DisplayName("el tope de página es 25, igual que el predeterminado")
    void elTopeDePaginaEs25() {
        assertThat(ListarPendientesCasoDeUso.TAMANO_PAGINA_MAXIMO).isEqualTo(25);
        assertThat(ListarPendientesCasoDeUso.TAMANO_PAGINA_PREDETERMINADO).isEqualTo(25);
    }
}
