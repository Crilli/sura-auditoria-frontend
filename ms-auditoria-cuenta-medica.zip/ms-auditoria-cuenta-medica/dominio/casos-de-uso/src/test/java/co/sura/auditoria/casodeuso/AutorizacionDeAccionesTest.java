package co.sura.auditoria.casodeuso;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/** Las acciones para autorizar: se niega solo con un dato fresco (OPE-09, revisión de las Fases 1 y 2). */
@ExtendWith(MockitoExtension.class)
@DisplayName("AutorizacionDeAcciones")
class AutorizacionDeAccionesTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-94421");

    @Mock PuertoConsultaCuentas consultas;

    @Test
    @Tag("OPE-09")
    @DisplayName("si lo guardado ya lo permite, no se vuelve a preguntar")
    void loGuardadoBasta() {
        var guardadas = new AccionesDisponibles(Set.of(AccionCuenta.ENVIAR));
        when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.just(guardadas));

        StepVerifier.create(AutorizacionDeAcciones.para(consultas, CODIGO, AccionCuenta.ENVIAR))
                .expectNext(guardadas).verifyComplete();
        verify(consultas, never()).consultarAccionesFrescas(CODIGO);
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("si lo guardado no lo permite, se confirma sin caché: un «no» desfasado no niega")
    void antesDeNegarSeConfirma() {
        when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.just(AccionesDisponibles.ninguna()));
        var frescas = new AccionesDisponibles(Set.of(AccionCuenta.ENVIAR));
        when(consultas.consultarAccionesFrescas(CODIGO)).thenReturn(Mono.just(frescas));

        StepVerifier.create(AutorizacionDeAcciones.para(consultas, CODIGO, AccionCuenta.ENVIAR))
                .expectNext(frescas).verifyComplete();
    }

    @Test
    @Tag("OPE-09")
    @DisplayName("si la consulta fresca vuelve vacía, se decide con lo guardado")
    void frescaVacia() {
        when(consultas.consultarAccionesDisponibles(CODIGO)).thenReturn(Mono.just(AccionesDisponibles.ninguna()));
        when(consultas.consultarAccionesFrescas(CODIGO)).thenReturn(Mono.empty());

        StepVerifier.create(AutorizacionDeAcciones.para(consultas, CODIGO, AccionCuenta.ENVIAR))
                .expectNext(AccionesDisponibles.ninguna()).verifyComplete();
    }
}
