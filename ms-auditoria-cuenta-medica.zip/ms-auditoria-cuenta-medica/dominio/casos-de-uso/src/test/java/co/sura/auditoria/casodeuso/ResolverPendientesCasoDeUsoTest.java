package co.sura.auditoria.casodeuso;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import co.sura.auditoria.casodeuso.ResolverPendientesCasoDeUso.Alcance;
import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EstadoCuenta;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@DisplayName("ResolverPendientesCasoDeUso")
class ResolverPendientesCasoDeUsoTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");
    private static final String AUTOR = "auditor@sura.com.co";
    private static final String JUSTIFICACION = "Soportes completos";
    private static final long MOTIVO = 4242L;

    @Mock PuertoConsultaCuentas consultas;

    /** Sin caché en las pruebas: la consulta fresca dice lo mismo que la guardada. */
    @org.junit.jupiter.api.BeforeEach
    void frescasComoLasGuardadas() {
        org.mockito.Mockito.lenient().when(consultas.consultarAccionesFrescas(org.mockito.ArgumentMatchers.any()))
                .thenAnswer(inv -> consultas.consultarAccionesDisponibles(inv.getArgument(0)));
    }
    @Mock PuertoPendientes pendientes;
    @Mock PuertoNotas notas;
    @Mock PublicadorEventosAuditoria publicador;
    @InjectMocks ResolverPendientesCasoDeUso casoDeUso;

    private void cuentaCon(AccionCuenta... permitidas) {
        cuentaEnCon(EstadoCuenta.MODIFICACION, permitidas);
    }

    private void cuentaEnCon(EstadoCuenta estado, AccionCuenta... permitidas) {
        when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.just(new CuentaMedica(
                CODIGO, estado, LocalDate.now(), LocalDate.now(),
                BigDecimal.TEN, BigDecimal.TEN, new Version(1L), List.of(), List.of(), null, List.of())));
        when(consultas.consultarAccionesDisponibles(CODIGO))
                .thenReturn(Mono.just(new AccionesDisponibles(Set.of(permitidas))));
    }

    private ErrorDeDominio errorDe(Mono<Void> resultado) {
        var capturado = new ErrorDeDominio[1];
        StepVerifier.create(resultado)
                .expectErrorSatisfies(e -> capturado[0] = ((ExcepcionDeDominio) e).error())
                .verify();
        return capturado[0];
    }

    @Nested
    @DisplayName("firma de la operación")
    class FirmaDeLaOperacion {

        @ParameterizedTest(name = "autor [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        @DisplayName("sin auditor identificado no se resuelve: la operación es irreversible")
        void sinAuditorNoSeResuelve(String autor) {
            var error = errorDe(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                    JUSTIFICACION, autor));

            assertThat(error).isInstanceOf(ErrorDeDominio.DecisionEnvioInvalida.class);
            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("No se identificó al auditor")
                    .contains("irreversible");
            verify(consultas, never()).buscarPorCodigo(any());
        }

        @ParameterizedTest(name = "justificación [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"  "})
        @DisplayName("sin justificación tampoco: es obligatoria")
        void sinJustificacionTampoco(String justificacion) {
            var error = errorDe(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                    justificacion, AUTOR));

            assertThat(((ErrorDeDominio.DecisionEnvioInvalida) error).detalle())
                    .contains("justificación es obligatoria");
            verify(pendientes, never()).resolverEnCuentaYLineas(any(), anyLong());
        }
    }

    @Nested
    @DisplayName("acción requerida según el alcance")
    class AccionRequerida {

        @Test
        @DisplayName("resolver en cuenta y líneas exige la acción de cuenta")
        void cuentaYLineasExigeLaAccionDeCuenta() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE_LINEA);   // falta la de cuenta

            var error = errorDe(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                    JUSTIFICACION, AUTOR));

            assertThat(error).isInstanceOf(ErrorDeDominio.AccionNoDisponible.class);
            assertThat(((ErrorDeDominio.AccionNoDisponible) error).accion())
                    .isEqualTo("RESOLVER_PENDIENTE");
        }

        @Test
        @DisplayName("resolver solo en líneas exige la acción de línea")
        void soloLineasExigeLaAccionDeLinea() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE);          // falta la de línea

            var error = errorDe(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.SOLO_LINEAS,
                    JUSTIFICACION, AUTOR));

            assertThat(((ErrorDeDominio.AccionNoDisponible) error).accion())
                    .isEqualTo("RESOLVER_PENDIENTE_LINEA");
        }

        @Test
        @DisplayName("si la cuenta no existe, CuentaNoEncontrada")
        void siLaCuentaNoExiste() {
            when(consultas.buscarPorCodigo(CODIGO)).thenReturn(Mono.empty());
            lenient().when(consultas.consultarAccionesDisponibles(CODIGO))
                    .thenReturn(Mono.just(AccionesDisponibles.ninguna()));

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                    JUSTIFICACION, AUTOR)))
                    .isInstanceOf(ErrorDeDominio.CuentaNoEncontrada.class);
        }
    }

    @Nested
    @DisplayName("resolución")
    class Resolucion {

        @Test
        @DisplayName("CUENTA_Y_LINEAS llama a resolverEnCuentaYLineas, no al de solo líneas")
        void cuentaYLineasLlamaAlQueCorresponde() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE);
            when(pendientes.resolverEnCuentaYLineas(CODIGO, MOTIVO)).thenReturn(Mono.empty());
            when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                            JUSTIFICACION, AUTOR))
                    .verifyComplete();

            verify(pendientes).resolverEnCuentaYLineas(CODIGO, MOTIVO);
            verify(pendientes, never()).resolverSoloEnLineas(any(), anyLong());
        }

        @Test
        @DisplayName("SOLO_LINEAS llama a resolverSoloEnLineas")
        void soloLineasLlamaAlQueCorresponde() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE_LINEA);
            when(pendientes.resolverSoloEnLineas(CODIGO, MOTIVO)).thenReturn(Mono.empty());
            when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.SOLO_LINEAS,
                            JUSTIFICACION, AUTOR))
                    .verifyComplete();

            verify(pendientes).resolverSoloEnLineas(CODIGO, MOTIVO);
            verify(pendientes, never()).resolverEnCuentaYLineas(any(), anyLong());
        }

        @Test
        @DisplayName("la justificación queda como nota en OHI y en la traza de auditoría")
        void laJustificacionQuedaEnNotaYTraza() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE);
            when(pendientes.resolverEnCuentaYLineas(any(), anyLong())).thenReturn(Mono.empty());
            when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                            JUSTIFICACION, AUTOR))
                    .verifyComplete();

            verify(notas).agregarNota(CODIGO, AUTOR, JUSTIFICACION);

            var captor = ArgumentCaptor.forClass(EventoAuditoria.class);
            verify(publicador).publicar(captor.capture());
            assertThat(captor.getValue().detalle())
                    .contains("4242").contains("CUENTA_Y_LINEAS").contains(JUSTIFICACION);
            assertThat(captor.getValue().autor()).isEqualTo(AUTOR);
        }
    }

    /**
     * Resolver no es cambiar datos (regla del 2026-10-21): queda libre en cualquier estado. Lo
     * único que la gobierna es que OHI publique la acción, como siempre. En FINALIZADA, en la
     * práctica, OHI no tiene pendientes abiertos ni publica la acción; aquí se fija que la
     * guarda de modificación no se ha colado en la resolución.
     */
    @ParameterizedTest(name = "{0}")
    @Tag("EST-03.3")
    @EnumSource(value = EstadoCuenta.class, names = {"ADJUDICACION_MANUAL", "FINALIZADA"})
    @DisplayName("[EST-03.3] con la acción publicada, se resuelve fuera de MODIFICACION: no da CuentaNoModificable")
    void seResuelveFueraDeModificacion(EstadoCuenta estado) {
        cuentaEnCon(estado, AccionCuenta.RESOLVER_PENDIENTE);
        when(pendientes.resolverEnCuentaYLineas(CODIGO, MOTIVO)).thenReturn(Mono.empty());
        when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
        when(publicador.publicar(any())).thenReturn(Mono.empty());

        StepVerifier.create(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                        JUSTIFICACION, AUTOR))
                .verifyComplete();

        verify(pendientes).resolverEnCuentaYLineas(CODIGO, MOTIVO);
    }

    @Nested
    @DisplayName("lo accesorio no tumba lo esencial")
    class LoAccesorioNoTumbaLoEsencial {

        @Test
        @DisplayName("si falla la nota, la resolución se da por buena: ya ocurrió en OHI")
        void siFallaLaNotaLaResolucionSigueSiendoBuena() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE);
            when(pendientes.resolverEnCuentaYLineas(any(), anyLong())).thenReturn(Mono.empty());
            when(notas.agregarNota(any(), any(), any()))
                    .thenReturn(Mono.error(new IllegalStateException("OHI rechazó la nota")));
            when(publicador.publicar(any())).thenReturn(Mono.empty());

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                            JUSTIFICACION, AUTOR))
                    .verifyComplete();

            verify(publicador).publicar(any());
        }

        @Test
        @DisplayName("si falla la traza, tampoco se deshace nada")
        void siFallaLaTrazaTampocoSeDeshaceNada() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE);
            when(pendientes.resolverEnCuentaYLineas(any(), anyLong())).thenReturn(Mono.empty());
            when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
            when(publicador.publicar(any()))
                    .thenReturn(Mono.error(new IllegalStateException("bus caído")));

            StepVerifier.create(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                            JUSTIFICACION, AUTOR))
                    .verifyComplete();
        }

        @Test
        @DisplayName("pero si falla la resolución, el error SÍ sale: eso no es accesorio")
        void siFallaLaResolucionElErrorSale() {
            cuentaCon(AccionCuenta.RESOLVER_PENDIENTE);
            var caida = ExcepcionDeDominio.de(
                    new ErrorDeDominio.SinPermiso("resolver", "sin privilegios"));
            when(pendientes.resolverEnCuentaYLineas(any(), anyLong())).thenReturn(Mono.error(caida));
            lenient().when(notas.agregarNota(any(), any(), any())).thenReturn(Mono.empty());
            lenient().when(publicador.publicar(any())).thenReturn(Mono.empty());

            assertThat(errorDe(casoDeUso.ejecutar(CODIGO, MOTIVO, Alcance.CUENTA_Y_LINEAS,
                    JUSTIFICACION, AUTOR)))
                    .isInstanceOf(ErrorDeDominio.SinPermiso.class);
        }
    }

    @Test
    @DisplayName("el alcance distingue los dos modos de resolución")
    void elAlcanceDistingueLosDosModos() {
        assertThat(Alcance.values())
                .containsExactly(Alcance.CUENTA_Y_LINEAS, Alcance.SOLO_LINEAS);
    }
}
