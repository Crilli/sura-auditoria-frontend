package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Caso de uso: agregar y quitar novedades en la <b>cabecera</b> de la cuenta.
 * Tipo: <em>Command</em> (modifica estado).
 *
 * <h3>Por qué es un caso de uso propio</h3>
 * Lo que se edita aquí no es una línea, y no hay ninguna otra cosa editable en
 * la cabecera: montarlo como un «guardar cuenta» con un solo campo sería
 * prometer una edición de cabecera que no existe. Y colgarlo del guardado de
 * línea obligaría a inventar una línea para poder tocar la cuenta.
 *
 * <h3>Lo que no tiene, y la línea sí</h3>
 * <ul>
 *   <li><b>Modo de recálculo.</b> Una novedad no mueve importes; no hay nada que
 *       recalcular. En la línea el modo existe porque allí se tocan valores.</li>
 *   <li><b>Comprobación de editabilidad de la línea.</b> La línea tiene
 *       {@code bloqueada} y {@code reemplazada}; la cabecera no publica nada
 *       equivalente.</li>
 * </ul>
 *
 * <h3>Lo que se exige a la cuenta: el estado</h3>
 * Solo se cambian sus datos en modificación (EST-01, regla del 2026-10-21). El
 * sistema de registro no lo impone —acepta el parche en adjudicación manual,
 * medido—, así que no se le puede dejar a él: se exige aquí, con la cabecera
 * recién leída y antes de mirar la versión, que fuera de modificación da igual.
 *
 * <h3>Lo que sí comparte</h3>
 * Las cuatro comprobaciones de {@link ComprobadorDeNovedades}, palabra por
 * palabra: una novedad es lo mismo aquí que en una línea.
 */
public class GuardarNovedadesDeCuentaCasoDeUso {

    private final PuertoConsultaCuentas consultas;
    private final PuertoComandosCuenta  comandos;
    private final PublicadorEventosAuditoria publicador;
    private final ComprobadorDeNovedades comprobador;

    public GuardarNovedadesDeCuentaCasoDeUso(PuertoConsultaCuentas consultas,
                                             PuertoComandosCuenta comandos,
                                             PublicadorEventosAuditoria publicador,
                                             ComprobadorDeNovedades comprobador) {
        this.consultas   = consultas;
        this.comandos    = comandos;
        this.publicador  = publicador;
        this.comprobador = comprobador;
    }

    /**
     * @param versionEsperada la que el cliente creía al pintar la pantalla
     * @param autor           quién hace el cambio
     */
    public Mono<CuentaMedica> ejecutar(CodigoCuenta codigo, Version versionEsperada,
                                       List<CambioNovedad> cambios, String autor) {

        if (cambios == null || cambios.isEmpty()) {
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se envió ninguna novedad que agregar o quitar")));
        }

        return consultas.buscarPorCodigo(codigo)
            .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                    new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
            .flatMap(CuentaEnModificacion::exigir)
            .flatMap(cuenta -> verificarVersion(cuenta, versionEsperada)
                    // Contra la cuenta recién leída, no contra lo que creyera el
                    // cliente: entre que pintó la pantalla y pulsó guardar, otro
                    // auditor pudo quitar la novedad que éste quiere quitar.
                    .then(comprobador.comprobar(cambios, cuenta.novedades(),
                                                "La cuenta " + codigo.valor()))
                    .then(comandos.aplicarCambiosDeNovedadDeCabecera(codigo, cuenta.version(), cambios)))
            .flatMap(actualizada -> registrarTraza(codigo, cambios, autor).thenReturn(actualizada))
            .onErrorResume(error -> aplicadoSinRelectura(error)
                    ? registrarTraza(codigo, cambios, autor).then(Mono.error(error))
                    : Mono.error(error));
    }

    /**
     * Si el sistema de registro aplicó el cambio pero no se pudo releer, la traza se registra
     * igual y el error sigue su camino (OPE-11): el cambio ocurrió y tiene que quedar firmado.
     */
    private static boolean aplicadoSinRelectura(Throwable error) {
        return error instanceof ExcepcionDeDominio excepcion
            && excepcion.error() instanceof ErrorDeDominio.AplicadoSinRelectura;
    }


    private Mono<Void> verificarVersion(CuentaMedica cuenta, Version esperada) {
        if (cuenta.version().coincideCon(esperada)) return Mono.empty();
        return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.ModificacionConcurrente(
                "cuenta:" + cuenta.codigo().valor(), esperada.numero())));
    }

    /**
     * Deja en la traza qué se puso y qué se quitó.
     *
     * <p>Nombra los códigos puestos: es lo que hace falta para entender después
     * por qué la cuenta se frenó, porque poner una novedad de severidad fatal en
     * la cabecera la detiene entera.
     */
    private Mono<Void> registrarTraza(CodigoCuenta codigo, List<CambioNovedad> cambios, String autor) {
        var puestas = cambios.stream().filter(CambioNovedad::esAlta)
                .map(CambioNovedad::codigoMensaje).toList();
        var quitadas = cambios.stream().filter(CambioNovedad::esBaja).count();

        var partes = new java.util.ArrayList<String>(2);
        if (!puestas.isEmpty()) partes.add("novedades puestas: " + String.join(", ", puestas));
        if (quitadas > 0) partes.add("novedades quitadas: " + quitadas);

        return publicador
                .publicar(EventoAuditoria.cuentaNovedadesCambiadas(
                        codigo.valor(), partes.stream().collect(Collectors.joining(" · ")), autor))
                .onErrorResume(e -> Mono.empty()); // la traza nunca tumba el comando
    }
}
