package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.*;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: enviar la cuenta al sistema de registro.
 * Tipo: <em>Command</em> (inicia el proceso asíncrono de envío en OHI).
 *
 * <h3>Flujo</h3>
 * <ol>
 *   <li>Validar que la decisión de envío es coherente.</li>
 *   <li>Consultar la cuenta y verificar que ENVIAR está disponible.</li>
 *   <li>Si la decisión es ACEPTAR, verificar que no hay pendientes bloqueantes.</li>
 *   <li>Ejecutar el envío y obtener el tiquete de seguimiento.</li>
 *   <li>Publicar el evento de auditoría.</li>
 * </ol>
 *
 * <p>La verificación previa de pendientes (paso 3) es una optimización de
 * experiencia de usuario; el rechazo real sigue siendo autoridad del sistema de registro.
 */
public class EnviarCuentaCasoDeUso {

    private final PuertoConsultaCuentas      consultas;
    private final PuertoComandosCuenta       comandos;
    private final PuertoPendientes           pendientes;
    private final PublicadorEventosAuditoria publicador;

    public EnviarCuentaCasoDeUso(PuertoConsultaCuentas consultas,
                                 PuertoComandosCuenta comandos,
                                 PuertoPendientes pendientes,
                                 PublicadorEventosAuditoria publicador) {
        this.consultas  = consultas;
        this.comandos   = comandos;
        this.pendientes = pendientes;
        this.publicador = publicador;
    }

    /**
     * @param autor identificador del auditor que autoriza el envío
     * @return tiquete de seguimiento para consultar el estado del proceso
     */
    public Mono<TiqueteProceso> ejecutar(CodigoCuenta codigo, DecisionEnvio decision, String autor) {

        if (!decision.esValida())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "Denegar exige el código de una novedad bloqueante")));

        // La cabecera y las capacidades son dos consultas distintas desde que la
        // cabecera dejó de arrastrar los enlaces HATEOAS; aquí hacen falta las dos,
        // así que se piden en paralelo y no una detrás de otra.
        return Mono.zip(
                consultas.buscarPorCodigo(codigo)
                        .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                                new ErrorDeDominio.CuentaNoEncontrada(codigo.valor())))),
                AutorizacionDeAcciones.para(consultas, codigo, AccionCuenta.ENVIAR))
            .flatMap(tupla -> {
                var cuenta   = tupla.getT1();
                var acciones = tupla.getT2();

                if (!acciones.permite(AccionCuenta.ENVIAR))
                    return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.AccionNoDisponible(
                            codigo.valor(), AccionCuenta.ENVIAR.name())));

                Mono<Void> verificacion = decision.requiereVerificarPendientes()
                        ? verificarSinPendientesBloqueantes(cuenta)
                        : Mono.empty();

                return verificacion.then(comandos.enviar(codigo, cuenta.version(), decision));
            })
            .flatMap(tiquete -> publicador
                    .publicar(EventoAuditoria.cuentaEnviada(
                            codigo.valor(), decision.decision().name(), autor))
                    .onErrorResume(e -> Mono.empty())
                    .thenReturn(tiquete));
    }

    /**
     * Anticipa el rechazo del sistema de registro para dar un mensaje accionable.
     * Es una optimización de experiencia: el rechazo real sigue siendo la autoridad.
     */
    private Mono<Void> verificarSinPendientesBloqueantes(CuentaMedica cuenta) {
        return pendientes.listarSinResolver(cuenta.codigo())
                .filter(p -> p.bloqueaEnvioEn(cuenta.estado()))
                .count()
                .flatMap(cantidad -> cantidad == 0
                        ? Mono.empty()
                        : Mono.error(ExcepcionDeDominio.de(
                              new ErrorDeDominio.PendientesBloqueanEnvio(
                                      cuenta.codigo().valor(), cantidad.intValue()))));
    }
}
