package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroCuentas;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ResumenCuenta;
import co.sura.auditoria.modelo.cuenta.VersionCuenta;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoBusquedaCuentas;
import java.util.List;
import java.util.Map;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: buscar cuentas médicas. Tipo: <em>Query</em>.
 *
 * <h3>Sin criterio no se busca</h3>
 * Una búsqueda vacía devolvería las once mil cuentas del entorno, página a página. El sistema
 * de registro no se queja —responde— pero eso no es una búsqueda: es un listado que nadie
 * pidió y que cuesta lo mismo que uno útil. Se corta aquí, antes de salir.
 */
public class BuscarCuentasCasoDeUso {

    public static final int TAMANO_PAGINA_PREDETERMINADO = 25;
    public static final int TAMANO_PAGINA_MAXIMO = 50;

    private final PuertoBusquedaCuentas busqueda;

    public BuscarCuentasCasoDeUso(PuertoBusquedaCuentas busqueda) {
        this.busqueda = busqueda;
    }

    public Mono<PaginaDesplazada<ResumenCuenta>> ejecutar(FiltroCuentas filtro, int desplazamiento,
                                                           Integer tamanoSolicitado) {
        var criterios = filtro == null ? new FiltroCuentas(null, null) : filtro;
        if (criterios.vacio()) {
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "Hay que indicar al menos un criterio: número de factura o radicado")));
        }
        return busqueda.buscar(criterios, Math.max(0, desplazamiento),
                               normalizar(tamanoSolicitado));
    }

    /**
     * Las versiones de unas cuentas, agrupadas por código.
     *
     * <p>Se devuelve un mapa y no una lista plana porque quien llama las pinta debajo de su
     * cuenta: repartirlas allí obligaría a recorrer la lista una vez por fila.
     *
     * <p>Una cuenta sin versiones <b>no aparece</b> en el mapa, y eso no es un fallo: es una
     * cuenta que todavía no se ha transmitido. Quien pinte debe distinguir «no tiene» de «no
     * se pudo preguntar».
     */
    public Mono<Map<String, List<VersionCuenta>>> versionesDe(List<CodigoCuenta> codigos) {
        if (codigos == null || codigos.isEmpty()) return Mono.just(Map.of());
        return busqueda.versionesDe(codigos)
                .map(versiones -> versiones.stream()
                        .collect(java.util.stream.Collectors.groupingBy(
                                v -> v.codigo().valor(),
                                java.util.stream.Collectors.toList())));
    }

    /**
     * La foto de una versión.
     *
     * <p>Una versión que no existe es un error que la nombra, no una foto vacía: pedir la V7
     * de una cuenta que va por la V3 es un enlace roto, y responder con importes en blanco lo
     * disfrazaría.
     */
    public Mono<co.sura.auditoria.modelo.cuenta.FotoVersion> fotoDeVersion(CodigoCuenta codigo,
                                                                         int numero) {
        if (numero < 1) return Mono.error(versionFueraDeRango(numero));
        return busqueda.fotoDeVersion(codigo, numero)
                .switchIfEmpty(Mono.error(() -> versionQueNoEsta(codigo, numero)));
    }

    /**
     * El error de una versión que no está en el histórico.
     *
     * <p>Vive aquí y lo usan también las líneas de la versión (BUS-21): la foto y sus líneas son
     * la misma versión, y si no está, la pantalla tiene que leer el mismo mensaje por los dos
     * caminos.
     */
    static ExcepcionDeDominio versionQueNoEsta(CodigoCuenta codigo, int numero) {
        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "La cuenta " + codigo.valor() + " no tiene versión " + numero
              + " en el histórico de lo transmitido"));
    }

    /** Las versiones empiezan en 1: lo demás se rechaza sin preguntar al sistema de registro. */
    static ExcepcionDeDominio versionFueraDeRango(int numero) {
        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "Las versiones empiezan en 1; se pidió la " + numero));
    }

    private int normalizar(Integer solicitado) {
        if (solicitado == null || solicitado <= 0) return TAMANO_PAGINA_PREDETERMINADO;
        return Math.min(solicitado, TAMANO_PAGINA_MAXIMO);
    }
}
