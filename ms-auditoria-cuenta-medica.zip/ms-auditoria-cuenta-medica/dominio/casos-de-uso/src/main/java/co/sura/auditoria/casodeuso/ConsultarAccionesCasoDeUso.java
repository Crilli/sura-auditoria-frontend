package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: consultar qué puede hacer el auditor sobre una cuenta.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>Existe separado de {@link ConsultarCuentaCasoDeUso} porque el sistema de registro
 * solo publica las capacidades en su representación completa del claim, mucho más
 * lenta que la cabecera. Unirlas obligaba a la interfaz a esperar por las acciones
 * para pintar datos que ya tenía.
 *
 * <p>Una cuenta inexistente no es un error aquí: devuelve
 * {@link AccionesDisponibles#ninguna()}, que es la respuesta correcta —sobre algo que
 * no existe no se puede hacer nada— y evita que la interfaz tenga que tratar un 404
 * para una consulta accesoria.
 */
public class ConsultarAccionesCasoDeUso {

    private final PuertoConsultaCuentas consultas;

    public ConsultarAccionesCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    public Mono<AccionesDisponibles> ejecutar(CodigoCuenta codigo) {
        return consultas.consultarAccionesDisponibles(codigo);
    }
}
