package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: consultar la cabecera de la cuenta médica.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>No devuelve las acciones disponibles: van en
 * {@link ConsultarAccionesCasoDeUso}, porque en el sistema de registro cuestan un
 * orden de magnitud más y no deben retrasar el pintado de la cabecera.
 */
public class ConsultarCuentaCasoDeUso {

    private final PuertoConsultaCuentas consultas;

    public ConsultarCuentaCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    /**
     * @param codigo código de negocio de la cuenta
     * @return la cabecera de la cuenta
     * @throws ExcepcionDeDominio {@link ErrorDeDominio.CuentaNoEncontrada} si no existe
     */
    public Mono<CuentaMedica> ejecutar(CodigoCuenta codigo) {
        return consultas.buscarPorCodigo(codigo)
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))));
    }
}
