package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: cuál es la línea siguiente a una dada.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>Sostiene «guardar y pasar a la siguiente», que es como se revisa una cuenta
 * de miles de líneas: de una en una, sin volver a la tabla. Lo resolvía el
 * cliente aprovechando la paginación por clave, y con ella se perdió; existe
 * aquí porque el orden en el que se revisan las líneas es una regla del negocio
 * —el número de línea— y no un efecto de cómo esté paginado el listado.
 *
 * <p>Devolver vacío es parte del contrato: significa que esa era la última.
 */
public class ObtenerLineaSiguienteCasoDeUso {

    private final PuertoConsultaCuentas consultas;

    public ObtenerLineaSiguienteCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    public Mono<ResumenLinea> ejecutar(CodigoCuenta codigo, ReferenciaLinea referencia) {
        return consultas.buscarLineaSiguiente(codigo, referencia);
    }
}
