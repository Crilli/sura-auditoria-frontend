package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.cuenta.Novedad;
import co.sura.auditoria.modelo.cuenta.TextoDeNovedad;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Las comprobaciones que hay que hacerle a un cambio de novedades, vengan de
 * una línea o de la cabecera de la cuenta.
 *
 * <h3>Por qué está aquí y no en cada caso de uso</h3>
 * Una novedad es lo mismo en los dos sitios: el sistema de registro usa la misma
 * forma, el mismo catálogo y el mismo vocabulario de orígenes para
 * {@code claimLineMessageList} y para {@code claimMessageList}. Lo único que
 * cambia es de qué cuelga. Si estas cuatro comprobaciones viven en cada caso de
 * uso, el día que una cambie —y van a cambiar, porque son reglas de negocio—
 * habrá que acordarse de tocar las dos copias, y la segunda se olvidará.
 *
 * <h3>Las cuatro, y por qué existen</h3>
 * Todas, sin excepción, están aquí porque <b>el sistema de registro no las
 * hace</b>. Comprobado contra su entorno de pruebas, acepta tan tranquilo:
 * <ol>
 *   <li>quitar una novedad que ya no está —no borra nada y responde correcto, de
 *       modo que el auditor ve un guardado bueno y la novedad sigue ahí—;</li>
 *   <li>quitar una que levantó su propio motor. Se le pidió borrar una de origen
 *       {@code BENEFITS} y la borró, y <b>un recálculo posterior no la volvió a
 *       levantar</b>: eso es destruir la evidencia de la auditoría sin dejar
 *       rastro;</li>
 *   <li>poner un mensaje de los que marca como propios del sistema, que ningún
 *       auditor usa: de las 1.962 novedades manuales de línea y las 2.071 de
 *       cabecera que ya existen allí, <b>ninguna</b> usa uno;</li>
 *   <li>poner un mensaje cuya plantilla tiene huecos y no rellenar ninguno, con
 *       lo que el prestador acaba leyendo un {@code {2}} en mitad de la frase.
 *       Esto no es hipotético: en su entorno de pruebas hay 86 novedades de
 *       línea y 97 de cabecera exactamente así.</li>
 * </ol>
 *
 * <p>Lo que <b>no</b> se comprueba es que el código exista: de eso sí se ocupa
 * el sistema de registro, que responde {@code 422 GEN-HTTP-002} nombrando el que
 * no encontró.
 */
public class ComprobadorDeNovedades {

    private final PuertoCatalogoNovedades catalogo;

    public ComprobadorDeNovedades(PuertoCatalogoNovedades catalogo) {
        this.catalogo = catalogo;
    }

    /**
     * Comprueba los cambios contra el estado recién leído.
     *
     * @param cambios  lo que se quiere aplicar
     * @param actuales las novedades tal como están ahora mismo. Se comprueban
     *     contra esto y no contra lo que creyera el cliente: entre que pintó la
     *     pantalla y pulsó guardar, otro auditor pudo quitar la que éste quiere
     *     quitar
     * @param donde    cómo nombrar al que las lleva en los mensajes de error,
     *     p. ej. {@code "La línea 84054990788"} o {@code "La cuenta CM-5855…"}.
     *     Se pide ya redactado porque quien llama sabe de qué habla y aquí daría
     *     igual
     */
    public Mono<Void> comprobar(List<CambioNovedad> cambios, List<Novedad> actuales, String donde) {
        if (cambios == null || cambios.isEmpty()) return Mono.empty();

        var fallo = bajasInexistentes(cambios, actuales, donde);
        if (fallo != null) return Mono.error(fallo);

        fallo = bajasAjenas(cambios, actuales);
        if (fallo != null) return Mono.error(fallo);

        return comprobarContraElCatalogo(cambios);
    }

    /** Lo que se quiere quitar y ya no está. */
    private static ExcepcionDeDominio bajasInexistentes(List<CambioNovedad> cambios,
                                                        List<Novedad> actuales, String donde) {
        var existentes = actuales.stream().map(Novedad::identificador).collect(Collectors.toSet());
        var inexistentes = cambios.stream().filter(CambioNovedad::esBaja)
                .map(CambioNovedad::identificador)
                .filter(id -> !existentes.contains(id))
                .toList();
        if (inexistentes.isEmpty()) return null;

        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "%s ya no tiene %s que se quiere eliminar: %s. Vuelva a cargarla."
                        .formatted(donde,
                                   inexistentes.size() == 1 ? "la novedad" : "las novedades",
                                   inexistentes.stream().map(String::valueOf)
                                           .collect(Collectors.joining(", ")))));
    }

    /** Lo que se quiere quitar y no lo puso una persona. */
    private static ExcepcionDeDominio bajasAjenas(List<CambioNovedad> cambios,
                                                  List<Novedad> actuales) {
        var aQuitar = cambios.stream().filter(CambioNovedad::esBaja)
                .map(CambioNovedad::identificador).collect(Collectors.toSet());
        var ajenas = actuales.stream()
                .filter(n -> aQuitar.contains(n.identificador()))
                .filter(n -> !n.laPusoUnaPersona())
                .toList();
        if (ajenas.isEmpty()) return null;

        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "Solo se pueden eliminar las novedades puestas a mano. %s %s porque %s: %s"
                        .formatted(ajenas.size() == 1 ? "No se eliminó" : "No se eliminaron",
                                   ajenas.size() == 1 ? "la novedad" : "las novedades",
                                   ajenas.size() == 1 ? "la levantó el sistema"
                                                      : "las levantó el sistema",
                                   ajenas.stream()
                                           .map(n -> "%s (%s)".formatted(n.codigo(), n.origen()))
                                           .collect(Collectors.joining(", ")))));
    }

    /**
     * Que el mensaje se pueda poner a mano y que sus huecos vengan rellenos.
     *
     * <p>Lee el catálogo, que es global y apenas cambia, así que el adaptador lo
     * sirve de su memoria y esto no se traduce en una llamada por guardado.
     */
    private Mono<Void> comprobarContraElCatalogo(List<CambioNovedad> cambios) {
        var altas = cambios.stream().filter(CambioNovedad::esAlta).toList();
        if (altas.isEmpty()) return Mono.empty();

        return catalogo.listar().flatMap(ofrecibles -> {
            var porCodigo = ofrecibles.stream().collect(Collectors.toMap(
                    MensajeCatalogo::codigo, m -> m, (a, b) -> a));

            var rechazados = altas.stream().map(CambioNovedad::codigoMensaje)
                    .filter(c -> !porCodigo.containsKey(c)).toList();
            if (!rechazados.isEmpty()) {
                return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "%s no se puede%s poner a mano como novedad: %s"
                                .formatted(rechazados.size() == 1 ? "Este mensaje" : "Estos mensajes",
                                           rechazados.size() == 1 ? "" : "n",
                                           String.join(", ", rechazados)))));
            }
            return comprobarLosDatos(altas, porCodigo);
        });
    }

    /** Que los datos cuadren con los huecos que la plantilla declara. */
    private static Mono<Void> comprobarLosDatos(List<CambioNovedad> altas,
                                                Map<String, MensajeCatalogo> porCodigo) {
        for (var alta : altas) {
            var plantilla = porCodigo.get(alta.codigoMensaje()).texto();

            var sinValor = TextoDeNovedad.marcadoresSinValor(plantilla, alta.valores());
            if (!sinValor.isEmpty()) {
                return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "Al mensaje %s le %s por rellenar: %s. Sin %s, el prestador leería el hueco."
                                .formatted(alta.codigoMensaje(),
                                           sinValor.size() == 1 ? "queda un dato" : "quedan datos",
                                           sinValor.stream().map(i -> "dato " + i)
                                                   .collect(Collectors.joining(", ")),
                                           sinValor.size() == 1 ? "él" : "ellos"))));
            }

            var sobrantes = TextoDeNovedad.valoresSobrantes(plantilla, alta.valores());
            if (!sobrantes.isEmpty()) {
                return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "El mensaje %s no usa %s: no se guardaría en ninguna parte."
                                .formatted(alta.codigoMensaje(),
                                           sobrantes.stream().map(i -> "el dato " + i)
                                                   .collect(Collectors.joining(", "))))));
            }
        }
        return Mono.empty();
    }
}
