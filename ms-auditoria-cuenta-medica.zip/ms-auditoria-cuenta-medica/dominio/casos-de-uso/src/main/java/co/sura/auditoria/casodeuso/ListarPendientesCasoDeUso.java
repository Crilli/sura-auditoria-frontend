package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: listar la página de pendientes sin resolver de una cuenta.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>Mismas reglas que {@link ListarLineasCasoDeUso}, y por el mismo motivo: el
 * conteo total solo se pide en la primera página. Aquí además es obligatorio —no
 * solo una optimización—, porque el total que devuelve OHI es el de las filas
 * que quedan por delante del cursor, no el del conjunto: medido contra
 * CM-55181980659, la página 1 dice 3.504 y la 2 dice 3.479. Pedirlo en cada
 * salto haría encoger el número de páginas a medida que se avanza.
 */
public class ListarPendientesCasoDeUso {

    public static final int TAMANO_PAGINA_PREDETERMINADO = 25;
    public static final int TAMANO_PAGINA_MAXIMO = 25;

    private final PuertoPendientes pendientes;

    public ListarPendientesCasoDeUso(PuertoPendientes pendientes) {
        this.pendientes = pendientes;
    }

    /**
     * @param tamanoSolicitado tamaño de página deseado; se normaliza al rango [1, 25]
     * @param codigoMotivo     {@code pendReason.code} por el que filtrar, o {@code null}
     * @param bloqueo          qué pendientes interesan según bloqueen o no el envío;
     *                         {@code null} se entiende como {@link FiltroBloqueo#TODOS}
     */
    public Mono<PaginaPendientes> ejecutar(CodigoCuenta codigo, Cursor cursor,
                                           Integer tamanoSolicitado, String codigoMotivo,
                                           FiltroBloqueo bloqueo) {
        return ejecutar(codigo, cursor, tamanoSolicitado, codigoMotivo, bloqueo, false);
    }

    /**
     * Lo mismo, pudiendo mirar atrás.
     *
     * @param incluirResueltos trae también los motivos ya resueltos. {@code false} es lo de
     *                         siempre, y es lo que recibe quien no pida nada: el cambio no
     *                         altera lo que el auditor ya veía
     */
    public Mono<PaginaPendientes> ejecutar(CodigoCuenta codigo, Cursor cursor,
                                           Integer tamanoSolicitado, String codigoMotivo,
                                           FiltroBloqueo bloqueo, boolean incluirResueltos) {
        int tamano = normalizar(tamanoSolicitado);
        boolean incluirTotal = cursor.esPrimeraPagina();
        return pendientes.listarPaginado(codigo, cursor, tamano, incluirTotal,
                                         normalizarMotivo(codigoMotivo),
                                         bloqueo == null ? FiltroBloqueo.TODOS : bloqueo,
                                         incluirResueltos)
                // Sin esto, una cuenta que no existe deja el Mono vacío y WebFlux
                // cierra el intercambio con un 200 sin cuerpo: el navegador lo lee
                // como `null` y la pantalla dice «No hay pendientes para esta
                // cuenta» sobre una cuenta inexistente. El resto de consultas del
                // dominio lo cierran igual (ver ConsultarCuentaCasoDeUso).
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))));
    }

    private int normalizar(Integer solicitado) {
        if (solicitado == null || solicitado <= 0) return TAMANO_PAGINA_PREDETERMINADO;
        return Math.min(solicitado, TAMANO_PAGINA_MAXIMO);
    }

    /** Un motivo en blanco es «sin filtro»: el cliente manda el param vacío al limpiarlo. */
    private String normalizarMotivo(String solicitado) {
        return solicitado == null || solicitado.isBlank() ? null : solicitado.trim();
    }
}
