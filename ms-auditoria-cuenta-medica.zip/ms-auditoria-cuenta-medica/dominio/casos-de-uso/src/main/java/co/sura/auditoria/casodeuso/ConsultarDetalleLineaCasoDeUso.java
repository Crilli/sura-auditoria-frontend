package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: consultar el detalle completo de una línea.
 * Tipo: <em>Query</em> (no modifica estado).
 */
public class ConsultarDetalleLineaCasoDeUso {

    private final PuertoConsultaCuentas consultas;

    public ConsultarDetalleLineaCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    /**
     * @return el detalle de la línea con novedades y pendientes
     * @throws ExcepcionDeDominio {@link ErrorDeDominio.LineaNoEncontrada} si no existe
     */
    public Mono<LineaCuenta> ejecutar(CodigoCuenta codigo, ReferenciaLinea referencia) {
        return consultas.buscarDetalleLinea(codigo, referencia)
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.LineaNoEncontrada(referencia.valor()))));
    }
}
