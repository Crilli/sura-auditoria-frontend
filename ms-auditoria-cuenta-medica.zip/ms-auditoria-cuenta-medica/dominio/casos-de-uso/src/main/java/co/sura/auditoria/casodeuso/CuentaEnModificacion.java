package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import reactor.core.publisher.Mono;

/**
 * La guarda de los cambios de datos: la cuenta tiene que estar en modificación
 * ({@link co.sura.auditoria.modelo.cuenta.EstadoCuenta#admiteCambiosDeDatos()}).
 *
 * <p>La usan los casos de uso que cambian datos —la línea, el lote, las novedades de cabecera y
 * el motivo de pendiente que se añade— siempre con la cabecera <b>recién leída</b>, nunca con
 * un estado de caché: el que pasó la cuenta a adjudicación hace un segundo desde la pantalla de
 * OHI tiene que encontrarla cerrada aquí.
 *
 * <p>Se encadena con {@code flatMap} justo después de leer la cabecera y <b>antes</b> de
 * cualquier otra lectura o escritura, no con {@code then}: con {@code then} la llamada siguiente
 * se construye aunque la guarda vaya a fallar, y la prueba no podría afirmar que no se tocó el
 * sistema de registro. El repositorio ya cayó en esa trampa una vez (ver
 * {@link AgregarMotivoPendienteCasoDeUso}).
 */
final class CuentaEnModificacion {

    private CuentaEnModificacion() {}

    /** La misma cuenta si admite cambios; si no, {@link ErrorDeDominio.CuentaNoModificable}. */
    static Mono<CuentaMedica> exigir(CuentaMedica cuenta) {
        return cuenta.estado().admiteCambiosDeDatos()
                ? Mono.just(cuenta)
                : Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.CuentaNoModificable(
                        cuenta.codigo().valor(), cuenta.estado().name())));
    }
}
