package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoNovedades;
import reactor.core.publisher.Mono;

import java.text.Normalizer;
import java.util.Comparator;
import java.util.List;

/**
 * Caso de uso: qué mensajes puede poner un auditor como novedad.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>Devuelve el catálogo <b>completo</b> —631 mensajes medidos contra el entorno
 * de pruebas, 24 kB comprimidos— y no una página por cada búsqueda. La razón es
 * lo que el auditor hace con él: teclea tres letras del texto y espera ver al
 * instante los códigos que encajan. Una búsqueda servidor-side por tecleo añade
 * una ida y vuelta a cada letra para filtrar algo que cabe de sobra en el
 * navegador. El filtro opcional existe para quien quiera acotar desde el
 * servicio, no porque la interfaz lo necesite.
 */
public class ConsultarCatalogoNovedadesCasoDeUso {

    private final PuertoCatalogoNovedades catalogo;

    public ConsultarCatalogoNovedadesCasoDeUso(PuertoCatalogoNovedades catalogo) {
        this.catalogo = catalogo;
    }

    /**
     * @param busqueda texto libre, opcional, que se busca a la vez en el código,
     *     en el texto del mensaje y en las dos clasificaciones. {@code null} o en
     *     blanco devuelve el catálogo entero
     */
    public Mono<List<MensajeCatalogo>> ejecutar(String busqueda) {
        return catalogo.listar().map(mensajes -> {
            var filtrados = aplicarBusqueda(mensajes, busqueda);
            return filtrados.stream()
                    // Por código: es el orden con el que el auditor los cita y el
                    // que agrupa a los de la misma familia normativa.
                    .sorted(Comparator.comparing(MensajeCatalogo::codigo,
                                                 Comparator.nullsLast(String::compareTo)))
                    .toList();
        });
    }

    private static List<MensajeCatalogo> aplicarBusqueda(List<MensajeCatalogo> mensajes,
                                                         String busqueda) {
        if (busqueda == null || busqueda.isBlank()) return mensajes;

        var aguja = normalizar(busqueda);
        return mensajes.stream().filter(m -> casa(m, aguja)).toList();
    }

    private static boolean casa(MensajeCatalogo m, String aguja) {
        return contiene(m.codigo(), aguja)
            || contiene(m.texto(), aguja)
            || (m.generico() != null && contiene(m.generico().descripcion(), aguja))
            || (m.especifico() != null && contiene(m.especifico().descripcion(), aguja));
    }

    private static boolean contiene(String campo, String aguja) {
        return campo != null && normalizar(campo).contains(aguja);
    }

    /**
     * Quita tildes y mayúsculas antes de comparar.
     *
     * <p>Hace falta: los textos del catálogo están acentuados —«Número de
     * autorización», «Pertinencia»— y nadie teclea las tildes al buscar. Sin
     * esto, buscar «autorizacion» no encuentra nada.
     */
    private static String normalizar(String texto) {
        return Normalizer.normalize(texto, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .toLowerCase(java.util.Locale.ROOT);
    }
}
