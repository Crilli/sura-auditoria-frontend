package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.cuenta.Pagina;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: listar el resumen paginado de líneas de una cuenta.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>El conteo total solo se incluye en la primera página para evitar
 * ejecutar un COUNT costoso en cada salto de página.
 */
public class ListarLineasCasoDeUso {

    public static final int TAMANO_PAGINA_PREDETERMINADO = 25;
    public static final int TAMANO_PAGINA_MAXIMO = 25;

    private final PuertoConsultaCuentas consultas;

    public ListarLineasCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    /** Sin filtro: el listado completo de la cuenta. */
    public Mono<Pagina<ResumenLinea>> ejecutar(CodigoCuenta codigo, Cursor cursor,
                                               Integer tamanoSolicitado) {
        return ejecutar(codigo, cursor, tamanoSolicitado, FiltroLineas.NINGUNO);
    }

    /**
     * @param tamanoSolicitado tamaño de página deseado; se normaliza al rango [1, 25]
     * @param filtro           criterios de búsqueda; nunca {@code null}
     *
     * <p>El total se pide solo en la primera página <b>y solo si el filtro se
     * puede empujar entero</b> al sistema de registro. Con un criterio que él no
     * sabe aplicar, el número que devolvería cuenta filas que después se
     * descartan: sería mayor que el de las que el auditor va a poder ver, y un
     * paginador construido sobre él ofrecería páginas vacías. Sin total, la
     * interfaz avanza con «siguiente», que es la verdad disponible.
     */
    public Mono<Pagina<ResumenLinea>> ejecutar(CodigoCuenta codigo, Cursor cursor,
                                               Integer tamanoSolicitado, FiltroLineas filtro) {
        int tamano = normalizar(tamanoSolicitado);
        var criterios = filtro == null ? FiltroLineas.NINGUNO : filtro;
        boolean incluirTotal = cursor.esPrimeraPagina() && criterios.seEmpujaEntero();
        return consultas.listarResumenLineas(codigo, cursor, tamano, incluirTotal, criterios);
    }

    private int normalizar(Integer solicitado) {
        if (solicitado == null || solicitado <= 0) return TAMANO_PAGINA_PREDETERMINADO;
        return Math.min(solicitado, TAMANO_PAGINA_MAXIMO);
    }
}
