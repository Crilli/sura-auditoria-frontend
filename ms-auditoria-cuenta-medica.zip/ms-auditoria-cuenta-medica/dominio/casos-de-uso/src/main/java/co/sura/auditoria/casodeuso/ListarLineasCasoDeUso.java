package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroLineas;
import co.sura.auditoria.modelo.cuenta.OrdenLineas;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: listar el resumen paginado de líneas de una cuenta.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <h3>Por desplazamiento y no por cursor</h3>
 * Antes este listado paginaba por clave: llevaba un cursor opaco y solo sabía
 * avanzar a la siguiente página. En una cuenta de cuatro mil líneas eso deja
 * ciento sesenta páginas a las que no se puede llegar sin pasar por todas las
 * anteriores, y ninguna forma de ir a la última. El sistema de registro sí
 * admite desplazamiento —y en profundidad, medido contra producción— así que lo
 * que decide la página es ahora una posición.
 *
 * <p>El cursor sigue existiendo en el puerto porque la capa de integración lo
 * usa para recorrer la cuenta entera cuando tiene que resumir sus filtros. Lo
 * que ya no existe es un listado paginado por cursor de cara al cliente.
 */
public class ListarLineasCasoDeUso {

    public static final int TAMANO_PAGINA_PREDETERMINADO = 25;
    public static final int TAMANO_PAGINA_MAXIMO = 25;

    private final PuertoConsultaCuentas consultas;

    public ListarLineasCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    /** Sin filtro: el listado completo de la cuenta. */
    public Mono<PaginaDesplazada<ResumenLinea>> ejecutar(CodigoCuenta codigo, int desplazamiento,
                                                         Integer tamanoSolicitado) {
        return ejecutar(codigo, desplazamiento, tamanoSolicitado, FiltroLineas.NINGUNO, null);
    }

    /** Sin orden explícito: el número de línea, que es como se lee una cuenta. */
    public Mono<PaginaDesplazada<ResumenLinea>> ejecutar(CodigoCuenta codigo, int desplazamiento,
                                                         Integer tamanoSolicitado,
                                                         FiltroLineas filtro) {
        return ejecutar(codigo, desplazamiento, tamanoSolicitado, filtro, null);
    }

    /**
     * @param desplazamiento   cuántas líneas saltar; un valor negativo se trata
     *                         como el principio
     * @param tamanoSolicitado tamaño de página deseado; se normaliza al rango [1, 25]
     * @param filtro           criterios de búsqueda; nunca {@code null}
     *
     * <p>Aquí no se decide si pedir el total: lo decide la capa de integración,
     * que es la única que sabe si el filtro se pudo empujar entero. Con un
     * criterio que el sistema de registro no sabe aplicar, el número que él
     * devolvería cuenta filas que después se descartan —sería mayor que el de
     * las que el auditor va a poder ver— y un paginador construido sobre él
     * ofrecería páginas vacías. En ese caso la página llega sin total y la
     * pantalla avanza con «siguiente», que es la verdad disponible. Ver
     * {@link PaginaDesplazada#totalEsDeFiar()}.
     */
    public Mono<PaginaDesplazada<ResumenLinea>> ejecutar(CodigoCuenta codigo, int desplazamiento,
                                                         Integer tamanoSolicitado,
                                                         FiltroLineas filtro, OrdenLineas orden) {
        int tamano = normalizar(tamanoSolicitado);
        var criterios = filtro == null ? FiltroLineas.NINGUNO : filtro;
        var ordenPedido = orden == null ? OrdenLineas.PREDETERMINADO : orden;
        return consultas.listarResumenLineasPorDesplazamiento(
                codigo, Math.max(0, desplazamiento), tamano, criterios, ordenPedido);
    }

    private int normalizar(Integer solicitado) {
        if (solicitado == null || solicitado <= 0) return TAMANO_PAGINA_PREDETERMINADO;
        return Math.min(solicitado, TAMANO_PAGINA_MAXIMO);
    }
}
