package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.Pagina;
import co.sura.auditoria.modelo.cuenta.ResumenLinea;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: listar el resumen paginado de líneas de una cuenta.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>El conteo total solo se incluye en la primera página para evitar
 * ejecutar un COUNT costoso en cada salto de página.
 */
public class ListarLineasCasoDeUso {

    public static final int TAMANO_PAGINA_PREDETERMINADO = 25;
    public static final int TAMANO_PAGINA_MAXIMO = 25;

    private final PuertoConsultaCuentas consultas;

    public ListarLineasCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    /**
     * @param tamanoSolicitado tamaño de página deseado; se normaliza al rango [1, 25]
     */
    public Mono<Pagina<ResumenLinea>> ejecutar(CodigoCuenta codigo, Cursor cursor,
                                               Integer tamanoSolicitado) {
        int tamano = normalizar(tamanoSolicitado);
        boolean incluirTotal = cursor.esPrimeraPagina();
        return consultas.listarResumenLineas(codigo, cursor, tamano, incluirTotal);
    }

    private int normalizar(Integer solicitado) {
        if (solicitado == null || solicitado <= 0) return TAMANO_PAGINA_PREDETERMINADO;
        return Math.min(solicitado, TAMANO_PAGINA_MAXIMO);
    }
}
