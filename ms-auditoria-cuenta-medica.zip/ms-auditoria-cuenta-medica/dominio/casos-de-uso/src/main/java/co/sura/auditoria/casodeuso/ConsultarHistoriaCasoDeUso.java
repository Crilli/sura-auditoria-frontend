package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.HitoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoHistoriaCuenta;
import reactor.core.publisher.Flux;

/**
 * Caso de uso: por dónde ha pasado la cuenta. Tipo: <em>Query</em>.
 *
 * <p>No comprueba que la cuenta exista antes de preguntar: una cuenta sin historia y una
 * cuenta que no existe se ven igual desde aquí —las dos dan cero hitos— y añadir una consulta
 * para distinguirlas costaría una llamada en el camino normal para mejorar un caso que el
 * auditor no alcanza: llega a esta pantalla desde una cuenta que ya tiene abierta.
 */
public class ConsultarHistoriaCasoDeUso {

    private final PuertoHistoriaCuenta historia;

    public ConsultarHistoriaCasoDeUso(PuertoHistoriaCuenta historia) {
        this.historia = historia;
    }

    public Flux<HitoCuenta> ejecutar(CodigoCuenta codigo) {
        return historia.consultar(codigo);
    }
}
