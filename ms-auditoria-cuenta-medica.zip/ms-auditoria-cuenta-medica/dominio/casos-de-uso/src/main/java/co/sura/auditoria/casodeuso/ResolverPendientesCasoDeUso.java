package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.*;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: resolver un pendiente de la cuenta médica.
 * Tipo: <em>Command</em> (modifica estado en OHI).
 *
 * <h3>Flujo</h3>
 * <ol>
 *   <li>Verificar justificación no vacía.</li>
 *   <li>Consultar la cuenta y verificar que la acción está disponible.</li>
 *   <li>Resolver el pendiente en OHI según el alcance.</li>
 *   <li>Agregar la nota de justificación (mejor esfuerzo, ver más abajo).</li>
 *   <li>Publicar el evento de auditoría (mejor esfuerzo).</li>
 * </ol>
 *
 * <p><b>La resolución en sí es todo o nada:</b> si {@code pendientes.resolver*}
 * falla, no se intenta nada más. Pero una vez que OHI confirma la resolución, el
 * efecto es irreversible desde este comando —no hay forma de deshacerlo aquí—, así
 * que un fallo en los pasos posteriores (nota, evento) no debe reportarse como si
 * la resolución no hubiera ocurrido: el auditor vería un error y podría reintentar
 * una operación que ya tuvo efecto, además de contradecir el hecho consumado en OHI.
 */
public class ResolverPendientesCasoDeUso {

    public enum Alcance { CUENTA_Y_LINEAS, SOLO_LINEAS }

    private final PuertoConsultaCuentas      consultas;
    private final PuertoPendientes           pendientes;
    private final PuertoNotas                notas;
    private final PublicadorEventosAuditoria publicador;

    public ResolverPendientesCasoDeUso(PuertoConsultaCuentas consultas,
                                       PuertoPendientes pendientes,
                                       PuertoNotas notas,
                                       PublicadorEventosAuditoria publicador) {
        this.consultas  = consultas;
        this.pendientes = pendientes;
        this.notas      = notas;
        this.publicador = publicador;
    }

    /**
     * @param identificadorMotivo identificador del motivo pendiente a resolver
     * @param alcance             CUENTA_Y_LINEAS o SOLO_LINEAS
     * @param justificacion       texto obligatorio que se agrega como nota en OHI
     * @param autor               identificador del auditor
     */
    public Mono<Void> ejecutar(CodigoCuenta codigo, long identificadorMotivo,
                               Alcance alcance, String justificacion, String autor) {

        // Misma guarda que en la resolución conjunta: resolver un motivo es
        // irreversible y se lleva por delante todas sus filas de la cuenta, así
        // que no se hace sin saber quién lo pide.
        if (autor == null || autor.isBlank())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se identificó al auditor que resuelve: la operación es "
                  + "irreversible y tiene que quedar firmada")));

        if (justificacion == null || justificacion.isBlank())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "La justificación es obligatoria para resolver un pendiente")));

        // Igual que en el envío: la cuenta confirma que existe y las acciones
        // autorizan la operación; son dos consultas y se piden a la vez.
        return Mono.zip(
                consultas.buscarPorCodigo(codigo)
                        .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                                new ErrorDeDominio.CuentaNoEncontrada(codigo.valor())))),
                consultas.consultarAccionesDisponibles(codigo))
            .flatMap(tupla -> {
                var acciones = tupla.getT2();
                var accionRequerida = alcance == Alcance.CUENTA_Y_LINEAS
                        ? AccionCuenta.RESOLVER_PENDIENTE
                        : AccionCuenta.RESOLVER_PENDIENTE_LINEA;

                if (!acciones.permite(accionRequerida))
                    return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.AccionNoDisponible(
                            codigo.valor(), accionRequerida.name())));

                Mono<Void> resolucion = alcance == Alcance.CUENTA_Y_LINEAS
                        ? pendientes.resolverEnCuentaYLineas(codigo, identificadorMotivo)
                        : pendientes.resolverSoloEnLineas(codigo, identificadorMotivo);

                // La resolución es todo o nada: si falla no se agrega la nota.
                return resolucion
                        .then(notas.agregarNota(codigo, autor, justificacion)
                              // Mejor esfuerzo: la resolución ya se aplicó en OHI y es
                              // irreversible desde aquí. El adaptador registra el fallo.
                              .onErrorResume(e -> Mono.empty()))
                        .then(publicador.publicar(EventoAuditoria.pendienteResuelto(
                                codigo.valor(), identificadorMotivo,
                                alcance.name(), justificacion, autor))
                              .onErrorResume(e -> Mono.empty()));
            });
    }
}
