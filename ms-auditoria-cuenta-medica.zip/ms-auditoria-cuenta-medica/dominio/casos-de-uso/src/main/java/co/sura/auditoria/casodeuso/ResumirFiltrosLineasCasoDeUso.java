package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: con qué se puede acotar el listado de líneas de una cuenta.
 * Tipo: <em>Query</em>.
 *
 * <p>Alimenta los controles de búsqueda —la lista de afiliados, los catálogos de
 * prestación presentes y los extremos de fecha y de glosa— con lo que la cuenta
 * tiene de verdad, no con una lista fija. Es lo que hace que el filtro de
 * catálogo siga siendo correcto si mañana aparece uno que hoy no existe, y lo
 * que evita ofrecer opciones que no devolverían ninguna fila.
 *
 * <p>No tiene lógica propia: el recorrido y el conteo viven en el adaptador,
 * que es quien sabe cuántas consultas cuesta y cómo pedirlas. Aquí solo se
 * nombra la operación para que la capa web no hable con el puerto.
 */
public class ResumirFiltrosLineasCasoDeUso {

    private final PuertoConsultaCuentas consultas;

    public ResumirFiltrosLineasCasoDeUso(PuertoConsultaCuentas consultas) {
        this.consultas = consultas;
    }

    public Mono<ResumenFiltrosLineas> ejecutar(CodigoCuenta codigo) {
        return consultas.resumirFiltrosDeLineas(codigo);
    }
}
