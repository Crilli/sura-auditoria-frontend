package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoLineasDeVersion;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: las líneas de una versión de la cuenta, en solo lectura (BUS-21). Tipo:
 * <em>Query</em>.
 *
 * <h3>Una versión que no existe es un error, no una lista vacía</h3>
 * Pedir las líneas de la V7 de una cuenta que va por la V3 es un enlace roto, y responder con
 * cero líneas lo disfrazaría de «versión sin líneas», que también existe —las madres de large
 * claim— y significa otra cosa (BUS-21.6). Por eso las dos respuestas son distintas, y el
 * mensaje es el mismo que el de la foto (BUS-20): la pantalla habla de una sola versión que no
 * está, la pida por donde la pida.
 *
 * <h3>La versión en curso no está</h3>
 * El histórico solo guarda versiones finalizadas. La que una cuenta reabierta está trabajando
 * —la siguiente a la última del histórico— es la cuenta viva, y aquí responde como inexistente:
 * quien la quiera ver va a las líneas de la cuenta.
 */
public class ConsultarLineasDeVersionCasoDeUso {

    /** Los mismos que las líneas de la cuenta viva: la grilla es la misma pantalla. */
    public static final int TAMANO_PAGINA_PREDETERMINADO = ListarLineasCasoDeUso.TAMANO_PAGINA_PREDETERMINADO;
    public static final int TAMANO_PAGINA_MAXIMO = ListarLineasCasoDeUso.TAMANO_PAGINA_MAXIMO;

    private final PuertoLineasDeVersion versiones;

    public ConsultarLineasDeVersionCasoDeUso(PuertoLineasDeVersion versiones) {
        this.versiones = versiones;
    }

    /**
     * @param desplazamiento   cuántas líneas saltar; un valor negativo se trata como el principio
     * @param tamanoSolicitado se normaliza al rango [1, 25]; ver {@link #normalizar}
     */
    public Mono<PaginaDesplazada<LineaDeVersion>> lineas(CodigoCuenta codigo, int numero,
                                                         int desplazamiento,
                                                         Integer tamanoSolicitado) {
        if (numero < 1) return Mono.error(BuscarCuentasCasoDeUso.versionFueraDeRango(numero));
        return versiones.lineasDeVersion(codigo, numero, Math.max(0, desplazamiento),
                                         normalizar(tamanoSolicitado))
                .switchIfEmpty(Mono.error(() -> BuscarCuentasCasoDeUso.versionQueNoEsta(codigo, numero)));
    }

    /**
     * Una línea de la versión, con sus novedades, diagnósticos y convenio de entonces.
     *
     * <p>Si no llega, se averigua por qué <b>solo entonces</b>: si es la versión la que no está o
     * es la línea. Son dos enlaces rotos distintos y la pantalla los explica distinto —en uno no
     * hay foto que enseñar, en el otro sí—.
     */
    public Mono<DetalleLineaDeVersion> detalle(CodigoCuenta codigo, int numero, int numeroLinea) {
        if (numero < 1) return Mono.error(BuscarCuentasCasoDeUso.versionFueraDeRango(numero));
        return versiones.detalleDeLinea(codigo, numero, numeroLinea)
                .switchIfEmpty(Mono.defer(() -> versiones.existeVersion(codigo, numero)
                        .defaultIfEmpty(false)
                        .flatMap(existe -> Mono.error(existe
                                ? lineaQueNoEsta(codigo, numero, numeroLinea)
                                : BuscarCuentasCasoDeUso.versionQueNoEsta(codigo, numero)))));
    }

    /**
     * El tamaño de página que de verdad se va a usar.
     *
     * <p>Público porque quien traduce «página N» a una posición tiene que multiplicar por este y
     * no por el que llegó: con {@code tamano=100&pagina=2} la posición es 50, no 200, porque la
     * página será de 25.
     */
    public static int normalizar(Integer solicitado) {
        if (solicitado == null || solicitado <= 0) return TAMANO_PAGINA_PREDETERMINADO;
        return Math.min(solicitado, TAMANO_PAGINA_MAXIMO);
    }

    private static ExcepcionDeDominio lineaQueNoEsta(CodigoCuenta codigo, int numero,
                                                     int numeroLinea) {
        return ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                "La versión " + numero + " de la cuenta " + codigo.valor()
              + " no tiene la línea " + numeroLinea));
    }
}
