package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Caso de uso: guardar la edición de una línea de cuenta médica.
 * Tipo: <em>Command</em> (modifica estado).
 *
 * <h3>Flujo de validación</h3>
 * <ol>
 *   <li>Verificar que la edición tenga al menos un campo.</li>
 *   <li>Consultar la cuenta (para obtener la versión de la cabecera).</li>
 *   <li>Consultar la línea (para verificar editabilidad y versión).</li>
 *   <li>Aplicar la edición en el sistema de registro.</li>
 *   <li>Publicar el evento de auditoría (nunca hace fallar el comando).</li>
 * </ol>
 */
public class GuardarLineaCasoDeUso {

    private final PuertoConsultaCuentas consultas;
    private final PuertoComandosCuenta  comandos;
    private final PublicadorEventosAuditoria publicador;

    public GuardarLineaCasoDeUso(PuertoConsultaCuentas consultas,
                                 PuertoComandosCuenta comandos,
                                 PublicadorEventosAuditoria publicador) {
        this.consultas  = consultas;
        this.comandos   = comandos;
        this.publicador = publicador;
    }

    /**
     * @param autor identificador del auditor que realiza la edición
     * @return la línea actualizada
     */
    public Mono<LineaCuenta> ejecutar(CodigoCuenta codigo, EdicionLinea edicion, String autor) {

        if (edicion.sinCambios())
            return Mono.error(ExcepcionDeDominio.de(
                    new ErrorDeDominio.EdicionSinCambios(edicion.referencia().valor())));

        return consultas.buscarPorCodigo(codigo)
            .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                    new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
            .flatMap(cuenta -> consultas.buscarDetalleLinea(codigo, edicion.referencia())
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.LineaNoEncontrada(edicion.referencia().valor()))))
                .flatMap(this::verificarEditable)
                .flatMap(linea -> verificarVersion(linea, edicion))
                .then(comandos.aplicarEdicionesDeLinea(codigo, cuenta.version(), List.of(edicion))))
            .flatMap(actualizada -> registrarTraza(codigo, edicion, autor).thenReturn(actualizada));
    }

    private Mono<LineaCuenta> verificarEditable(LineaCuenta linea) {
        if (linea.esEditable()) return Mono.just(linea);
        return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.LineaNoEditable(
                linea.referencia().valor(), linea.razonNoEditable())));
    }

    private Mono<LineaCuenta> verificarVersion(LineaCuenta linea, EdicionLinea edicion) {
        if (linea.version().coincideCon(edicion.versionEsperada())) return Mono.just(linea);
        return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.ModificacionConcurrente(
                "linea:" + linea.referencia().valor(), edicion.versionEsperada().numero())));
    }

    private Mono<Void> registrarTraza(CodigoCuenta codigo, EdicionLinea edicion, String autor) {
        var detalle = "Recálculo %s%s".formatted(
                edicion.modoRecalculo(),
                edicion.afectaCalculoFinanciero() ? " · afecta cálculo financiero" : "");
        return publicador
                .publicar(EventoAuditoria.lineaGuardada(
                        codigo.valor(), edicion.referencia().valor(), detalle, autor))
                .onErrorResume(e -> Mono.empty()); // la traza nunca tumba el comando
    }
}
