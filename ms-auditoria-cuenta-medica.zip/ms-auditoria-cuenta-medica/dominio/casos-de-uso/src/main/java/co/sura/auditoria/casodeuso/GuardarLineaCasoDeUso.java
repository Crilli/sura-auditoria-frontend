package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.*;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Caso de uso: guardar la edición de una línea de cuenta médica.
 * Tipo: <em>Command</em> (modifica estado).
 *
 * <h3>Flujo de validación</h3>
 * <ol>
 *   <li>Verificar que la edición tenga al menos un campo.</li>
 *   <li>Consultar la cuenta (para obtener la versión de la cabecera) y exigir que esté en
 *       modificación (EST-01): fuera de ese estado no se lee la línea ni se escribe nada.</li>
 *   <li>Consultar la línea (para verificar editabilidad y versión).</li>
 *   <li>Aplicar la edición en el sistema de registro.</li>
 *   <li>Publicar el evento de auditoría (nunca hace fallar el comando).</li>
 * </ol>
 */
public class GuardarLineaCasoDeUso {

    private final PuertoConsultaCuentas consultas;
    private final PuertoComandosCuenta  comandos;
    private final PublicadorEventosAuditoria publicador;
    private final ComprobadorDeNovedades comprobador;

    public GuardarLineaCasoDeUso(PuertoConsultaCuentas consultas,
                                 PuertoComandosCuenta comandos,
                                 PublicadorEventosAuditoria publicador,
                                 ComprobadorDeNovedades comprobador) {
        this.consultas   = consultas;
        this.comandos    = comandos;
        this.publicador  = publicador;
        this.comprobador = comprobador;
    }

    /**
     * @param autor identificador del auditor que realiza la edición
     * @return la línea actualizada
     */
    public Mono<LineaCuenta> ejecutar(CodigoCuenta codigo, EdicionLinea edicion, String autor) {

        if (edicion.sinCambios())
            return Mono.error(ExcepcionDeDominio.de(
                    new ErrorDeDominio.EdicionSinCambios(edicion.referencia().valor())));

        return consultas.buscarPorCodigo(codigo)
            .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                    new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
            // Antes de leer la línea: si la cuenta no admite cambios, la línea da igual, y se
            // ahorran sus ocho lecturas. Es la cabecera recién leída, sin coste añadido.
            .flatMap(CuentaEnModificacion::exigir)
            .flatMap(cuenta -> consultas.buscarDetalleLinea(codigo, edicion.referencia())
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.LineaNoEncontrada(edicion.referencia().valor()))))
                .flatMap(this::verificarEditable)
                .flatMap(linea -> verificarVersion(linea, edicion))
                // El desglose se comprueba contra la línea recién leída, no
                // contra lo que creyera el cliente: entre que pintó la pantalla
                // y pulsó guardar, otro auditor pudo quitar la glosa que este
                // quiere quitar.
                .flatMap(linea -> prepararGlosas(linea, edicion)
                        // Las novedades se comprueban contra la misma línea recién
                        // leída, y después de las glosas para no perder el total
                        // que aquéllas cuadran.
                        .flatMap(preparada -> prepararNovedades(linea, preparada)))
                .flatMap(preparada ->
                        comandos.aplicarEdicionesDeLinea(codigo, cuenta.version(), List.of(preparada))))
            .flatMap(actualizada -> registrarTraza(codigo, edicion, autor).thenReturn(actualizada))
            .onErrorResume(error -> aplicadoSinRelectura(error)
                    ? registrarTraza(codigo, edicion, autor).then(Mono.error(error))
                    : Mono.error(error));
    }

    /**
     * Si el sistema de registro aplicó el cambio pero no se pudo releer, la traza se registra
     * igual y el error sigue su camino (OPE-11): el cambio ocurrió y tiene que quedar firmado.
     */
    private static boolean aplicadoSinRelectura(Throwable error) {
        return error instanceof ExcepcionDeDominio excepcion
            && excepcion.error() instanceof ErrorDeDominio.AplicadoSinRelectura;
    }


    /**
     * Comprueba las bajas y deja el total glosado cuadrado con el desglose.
     *
     * <p>El total de la línea es, por definición, la suma de sus glosas. Si la
     * edición toca el desglose, aquí se recalcula y se impone: aceptar además un
     * {@code valorGlosado} del cliente permitiría guardar una línea cuyo total
     * no coincide con lo que la compone, y nadie sabría cuál de los dos números
     * es el bueno.
     */
    private Mono<EdicionLinea> prepararGlosas(LineaCuenta linea, EdicionLinea edicion) {
        if (!edicion.tocaGlosas()) return Mono.just(edicion);

        if (edicion.valorGlosado().isPresent()) {
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "El valor glosado de la línea sale de la suma de sus glosas: no se puede "
                  + "enviar a la vez que se agregan o eliminan glosas")));
        }

        var inexistentes = edicion.bajasInexistentes(linea.glosas());
        if (!inexistentes.isEmpty()) {
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "La línea %d ya no tiene %s que se quiere eliminar: %s. Vuelva a cargarla."
                            .formatted(linea.referencia().valor(),
                                       inexistentes.size() == 1 ? "la glosa" : "las glosas",
                                       inexistentes.stream().map(String::valueOf)
                                               .collect(java.util.stream.Collectors.joining(", "))))));
        }

        return Mono.just(edicion.conValorGlosado(edicion.valorGlosadoResultante(linea.glosas())));
    }

    /**
     * Comprueba las altas y bajas de novedad.
     *
     * <p>No cuadra ningún total —la novedad no tiene importe— así que devuelve la
     * edición tal cual. Lo que hace es imponer tres cosas que <b>el sistema de
     * registro no impone</b>, cada una comprobada contra su entorno de pruebas:
     * <ol>
     *   <li><b>no se quita lo que ya no está</b>: acepta el parche y no borra
     *       nada, de modo que el auditor vería un guardado correcto;</li>
     *   <li><b>no se quita lo que puso el motor</b>: le pedimos borrar una
     *       novedad de origen {@code BENEFITS} y la borró, y un recálculo
     *       posterior <b>no la volvió a levantar</b>. Eso es destruir la
     *       evidencia de la auditoría sin dejar rastro;</li>
     *   <li><b>no se pone un mensaje que no es para ponerse a mano</b>: los
     *       marcados como propios del sistema los acepta igual, y los que llevan
     *       marcadores de sustitución acabarían enseñándole al prestador un
     *       {@code {2}} literal.</li>
     * </ol>
     *
     * <p>Lo que <b>no</b> se comprueba aquí es que el código exista: de eso sí se
     * ocupa el sistema de registro, que responde {@code 422 GEN-HTTP-002}
     * nombrando el código que no encontró. Repetir esa comprobación costaría una
     * lectura más y daría el mismo resultado.
     */
    private Mono<EdicionLinea> prepararNovedades(LineaCuenta linea, EdicionLinea edicion) {
        if (!edicion.tocaNovedades()) return Mono.just(edicion);

        // Las comprobaciones son las mismas que para la cabecera de la cuenta y
        // viven en un solo sitio: ver ComprobadorDeNovedades.
        return comprobador
                .comprobar(edicion.novedades(), linea.novedades(),
                           "La línea " + linea.referencia().valor())
                .thenReturn(edicion);
    }

    /**
     * Resume para la traza qué se hizo con las novedades. Nombra los códigos que
     * se pusieron, porque es lo que hace falta para entender después por qué la
     * cuenta se frenó.
     */
    private String resumirNovedades(EdicionLinea edicion) {
        var puestas = edicion.novedades().stream().filter(CambioNovedad::esAlta)
                .map(CambioNovedad::codigoMensaje).toList();
        var quitadas = edicion.novedades().stream().filter(CambioNovedad::esBaja).count();

        var partes = new java.util.ArrayList<String>(2);
        if (!puestas.isEmpty()) partes.add("novedades puestas: " + String.join(", ", puestas));
        if (quitadas > 0) partes.add("novedades quitadas: " + quitadas);
        return String.join(" · ", partes);
    }

    private Mono<LineaCuenta> verificarEditable(LineaCuenta linea) {
        if (linea.esEditable()) return Mono.just(linea);
        return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.LineaNoEditable(
                linea.referencia().valor(), linea.razonNoEditable())));
    }

    private Mono<LineaCuenta> verificarVersion(LineaCuenta linea, EdicionLinea edicion) {
        if (linea.version().coincideCon(edicion.versionEsperada())) return Mono.just(linea);
        return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.ModificacionConcurrente(
                "linea:" + linea.referencia().valor(), edicion.versionEsperada().numero())));
    }

    private Mono<Void> registrarTraza(CodigoCuenta codigo, EdicionLinea edicion, String autor) {
        var detalle = "Recálculo %s%s%s".formatted(
                edicion.modoRecalculo(),
                edicion.afectaCalculoFinanciero() ? " · afecta cálculo financiero" : "",
                // Las novedades se nombran en la traza aunque no muevan dinero:
                // poner una de severidad fatal frena la cuenta, y quitar una es
                // retirar algo que un compañero había objetado.
                edicion.tocaNovedades() ? " · " + resumirNovedades(edicion) : "");
        return publicador
                .publicar(EventoAuditoria.lineaGuardada(
                        codigo.valor(), edicion.referencia().valor(), detalle, autor))
                .onErrorResume(e -> Mono.empty()); // la traza nunca tumba el comando
    }
}
