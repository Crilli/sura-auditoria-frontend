package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EjecucionAccion;
import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivos;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Caso de uso: ejecutar una de las acciones que el sistema de registro habilita
 * sobre la cuenta. Tipo: <em>Command</em> (modifica estado).
 *
 * <h3>La lista de acciones habilitadas es la autorización</h3>
 * Antes de ejecutar nada se le pregunta al sistema de registro qué permite ahora
 * mismo, y se rechaza lo que no esté en esa lista. No es una comodidad: él
 * publica esas acciones como enlaces precisamente porque dependen del estado, y
 * construir la ruta a mano para una que no publicó devuelve un error de negocio
 * que no dice nada. Preguntando antes, el auditor recibe un «en este estado no
 * se puede» en lugar de un conflicto críptico.
 *
 * <p>Cuesta una lectura más por acción. Se paga de buena gana: son operaciones
 * que mueven la cuenta de estado y una de ellas no tiene vuelta atrás.
 */
public class EjecutarAccionCasoDeUso {

    private final PuertoConsultaCuentas consultas;
    private final PuertoComandosCuenta  comandos;
    private final PuertoCatalogoMotivos catalogo;
    private final PublicadorEventosAuditoria publicador;

    public EjecutarAccionCasoDeUso(PuertoConsultaCuentas consultas,
                                   PuertoComandosCuenta comandos,
                                   PuertoCatalogoMotivos catalogo,
                                   PublicadorEventosAuditoria publicador) {
        this.consultas  = consultas;
        this.comandos   = comandos;
        this.catalogo   = catalogo;
        this.publicador = publicador;
    }

    public Mono<CuentaMedica> ejecutar(CodigoCuenta codigo, EjecucionAccion ejecucion, String autor) {
        if (autor == null || autor.isBlank()) {
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "Una acción sobre la cuenta tiene que quedar firmada: falta el auditor")));
        }

        return AutorizacionDeAcciones.para(consultas, codigo, ejecucion.accion())
                .flatMap(disponibles -> {
                    if (!disponibles.acciones().contains(ejecucion.accion())) {
                        return Mono.<CuentaMedica>error(ExcepcionDeDominio.de(
                                new ErrorDeDominio.AccionNoDisponible(
                                        codigo.valor(), ejecucion.accion().name())));
                    }
                    return comprobarMotivos(ejecucion)
                            .then(comandos.ejecutarAccion(codigo, ejecucion));
                })
                .flatMap(cuenta -> registrarTraza(codigo, ejecucion, autor).thenReturn(cuenta))
                .onErrorResume(error -> aplicadoSinRelectura(error)
                        ? registrarTraza(codigo, ejecucion, autor).then(Mono.error(error))
                        : Mono.error(error));
    }

    /**
     * Si el sistema de registro aplicó el cambio pero no se pudo releer, la traza se registra
     * igual y el error sigue su camino (OPE-11): el cambio ocurrió y tiene que quedar firmado.
     */
    private static boolean aplicadoSinRelectura(Throwable error) {
        return error instanceof ExcepcionDeDominio excepcion
            && excepcion.error() instanceof ErrorDeDominio.AplicadoSinRelectura;
    }


    /**
     * Comprueba los motivos contra el catálogo antes de mandarlos.
     *
     * <p>Dos cosas que el sistema de registro solo dice cuando ya es tarde:
     * <ul>
     *   <li>un motivo que no existe, o que no aplica a este tipo de proceso
     *       —los hay solo de cuenta médica y solo de autorización—;</li>
     *   <li>un motivo que <b>exige referencia de origen</b> y llega sin ella: su
     *       respuesta es un 422 que no nombra el campo.</li>
     * </ul>
     *
     * <p>Lo que <b>no</b> se comprueba aquí es el permiso: cada motivo tiene el
     * suyo y quien lo sabe es el sistema de registro, que responde que el
     * usuario no tiene derechos «sobre todos los motivos especificados». Ese
     * error se traduce tal cual, nombrando los motivos que se pidieron.
     */
    private Mono<Void> comprobarMotivos(EjecucionAccion ejecucion) {
        if (ejecucion.motivos().isEmpty()) return Mono.empty();

        return catalogo.listar().flatMap(motivos -> {
            var porCodigo = motivos.stream().collect(Collectors.toMap(
                    MotivoDesfinalizacion::codigo, m -> m, (a, b) -> a));

            var desconocidos = ejecucion.motivos().stream()
                    .filter(c -> !porCodigo.containsKey(c)).toList();
            if (!desconocidos.isEmpty()) {
                return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "El catálogo no tiene %s: %s"
                                .formatted(desconocidos.size() == 1 ? "este motivo" : "estos motivos",
                                           String.join(", ", desconocidos)))));
            }

            var sinReferencia = ejecucion.motivos().stream()
                    .map(porCodigo::get)
                    .filter(MotivoDesfinalizacion::exigeReferencia)
                    .map(MotivoDesfinalizacion::codigo)
                    .toList();
            if (!sinReferencia.isEmpty()
                    && (ejecucion.referencia() == null || ejecucion.referencia().isBlank())) {
                return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                        "%s exige una referencia de origen: %s"
                                .formatted(sinReferencia.size() == 1 ? "El motivo" : "Los motivos",
                                           String.join(", ", sinReferencia)))));
            }
            return Mono.empty();
        });
    }

    /**
     * Deja la acción en la traza <b>siempre</b>, y nombrando los motivos.
     *
     * <p>Es lo único que queda de quién anuló una cuenta: el estado resultante
     * no lo dice, y anular no tiene vuelta atrás.
     */
    private Mono<Void> registrarTraza(CodigoCuenta codigo, EjecucionAccion ejecucion, String autor) {
        var detalle = new StringBuilder(ejecucion.accion().name());
        if (!ejecucion.motivos().isEmpty()) {
            detalle.append(" · motivos: ").append(String.join(", ", ejecucion.motivos()));
        }
        if (ejecucion.referencia() != null && !ejecucion.referencia().isBlank()) {
            detalle.append(" · referencia: ").append(ejecucion.referencia());
        }
        if (!ejecucion.lineas().isEmpty()) {
            detalle.append(" · líneas: ").append(ejecucion.lineas().stream()
                    .map(String::valueOf).collect(Collectors.joining(", ")));
        }
        if (ejecucion.esIrreversible()) detalle.append(" · IRREVERSIBLE");

        return publicador
                .publicar(EventoAuditoria.accionEjecutada(codigo.valor(), detalle.toString(), autor))
                .onErrorResume(e -> Mono.empty()); // la traza nunca tumba el comando
    }

    /**
     * Los motivos que se le pueden ofrecer a algo de este tipo de proceso.
     *
     * <p><b>{@code null} quiere decir «sin filtrar», no «los que valen para
     * ambas»</b>: son dos cosas distintas y confundirlas deja fuera a los diez
     * motivos que son específicos de un tipo. Pedir el catálogo entero devuelve
     * los dieciséis; pedirlo para una cuenta médica, los doce que le aplican.
     */
    public Mono<List<MotivoDesfinalizacion>> motivosPara(MotivoDesfinalizacion.Ambito ambito) {
        return catalogo.listar().map(todos -> ambito == null
                ? todos
                : todos.stream().filter(m -> m.aplicaA().alcanza(ambito)).toList());
    }
}
