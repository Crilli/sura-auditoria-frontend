package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendienteCatalogo;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.SeleccionLineas;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoCatalogoMotivosPendiente;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import java.util.List;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: poner un motivo de pendiente sobre unas líneas. Tipo: <em>Command</em>.
 *
 * <h3>Por qué se comprueba el código contra el catálogo antes de mandarlo</h3>
 * Porque el sistema de registro rechaza un código desconocido con
 * {@code GEN-HTTP-002: no pudo encontrar PendReason{code=…}} —medido—, y ese mensaje no
 * distingue «te lo inventaste» de «el catálogo no responde». Comprobarlo aquí convierte el
 * primero en un error que nombra el motivo y deja el segundo donde está.
 *
 * <p>Poner un pendiente es, por diseño, <b>frenar</b> la cuenta: es lo contrario de resolver.
 * Por eso exige firma igual que la resolución, aunque sea más barato de deshacer.
 */
public class AgregarMotivoPendienteCasoDeUso {

    private final PuertoPendientes                pendientes;
    private final PuertoCatalogoMotivosPendiente  catalogo;
    private final PublicadorEventosAuditoria      publicador;

    public AgregarMotivoPendienteCasoDeUso(PuertoPendientes pendientes,
                                           PuertoCatalogoMotivosPendiente catalogo,
                                           PublicadorEventosAuditoria publicador) {
        this.pendientes = pendientes;
        this.catalogo   = catalogo;
        this.publicador = publicador;
    }

    public Mono<Void> ejecutar(CodigoCuenta codigo, String codigoMotivo,
                               SeleccionLineas seleccion, String autor) {
        if (autor == null || autor.isBlank())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se identificó al auditor: poner un pendiente frena la cuenta y tiene "
                  + "que quedar firmado")));

        if (codigoMotivo == null || codigoMotivo.isBlank())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "Hay que indicar qué motivo de pendiente agregar")));

        var pedido = codigoMotivo.trim();
        var alcance = seleccion == null ? SeleccionLineas.TODAS : seleccion;

        // El encadenado va dentro del flatMap y no con `then`: así la llamada al puerto se
        // construye DESPUÉS de comprobar el catálogo, no antes. Con `then` se armaba siempre,
        // aunque la comprobación fuera a fallar. Lo encontró la prueba del motivo inventado.
        return catalogo.listar()
                .flatMap(motivos -> {
                    if (!existe(motivos, pedido)) {
                        return Mono.<Void>error(ExcepcionDeDominio.de(
                                new ErrorDeDominio.DecisionEnvioInvalida(
                                        "El motivo de pendiente '" + pedido + "' no está en el "
                                      + "catálogo del sistema de registro")));
                    }
                    return pendientes.agregarMotivo(codigo, pedido, nivelDe(alcance), alcance)
                            .then(registrar(codigo, pedido, alcance, autor));
                });
    }

    private static boolean existe(List<MotivoPendienteCatalogo> motivos, String codigo) {
        return motivos.stream().anyMatch(m -> m.codigo().equalsIgnoreCase(codigo));
    }

    /**
     * A qué nivel se pone.
     *
     * <p>Con líneas elegidas es de línea; sin ellas, de cabecera. No es una convención: son
     * los dos niveles disjuntos del sistema de registro, y poner un pendiente «de línea» sin
     * decir cuáles lo pondría en todas, que casi nunca es lo que se quiere desde la grilla.
     */
    private static NivelPendiente nivelDe(SeleccionLineas seleccion) {
        return seleccion.esTodaLaCuenta() ? NivelPendiente.CABECERA : NivelPendiente.LINEA;
    }

    /** El rastro, a mejor esfuerzo: el pendiente ya está puesto y no se deshace por esto. */
    private Mono<Void> registrar(CodigoCuenta codigo, String motivo,
                                 SeleccionLineas seleccion, String autor) {
        var detalle = "Motivo %s | Alcance: %s".formatted(motivo,
                seleccion.esTodaLaCuenta() ? "toda la cuenta"
                                           : seleccion.cuantas() + " línea(s)");
        return publicador.publicar(
                        EventoAuditoria.lineasCambiadasEnLote(codigo.valor(), detalle, autor))
                .onErrorResume(e -> Mono.empty())
                .then();
    }
}
