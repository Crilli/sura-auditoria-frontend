package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.EstadoProceso;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;

/**
 * Caso de uso: seguir el estado del proceso de envío de una cuenta.
 * Tipo: <em>Query</em> — emite un flujo de estados para SSE.
 *
 * <p>El flujo termina cuando el proceso finaliza o cuando se supera
 * la espera máxima configurada. Solo emite cuando el estado cambia
 * ({@code distinctUntilChanged}) para no saturar el cliente.
 */
public class SeguirProcesoCasoDeUso {

    private final PuertoConsultaCuentas consultas;
    private final Duration intervaloConsulta;
    private final Duration esperaMaxima;

    public SeguirProcesoCasoDeUso(PuertoConsultaCuentas consultas,
                                  Duration intervaloConsulta,
                                  Duration esperaMaxima) {
        this.consultas        = consultas;
        this.intervaloConsulta = intervaloConsulta;
        this.esperaMaxima      = esperaMaxima;
    }

    /**
     * Flujo de estado para SSE.
     * Termina al finalizar el proceso o al vencer la espera máxima.
     */
    public Flux<EstadoProceso> transmitir(CodigoCuenta codigo) {
        return Flux.interval(Duration.ZERO, intervaloConsulta)
                .concatMap(tic -> consultas.consultarEstadoProceso(codigo))
                .distinctUntilChanged(EstadoProceso::avance)
                .takeUntil(EstadoProceso::finalizado)
                .take(esperaMaxima);
    }

    /** Consulta puntual del estado (sin streaming). */
    public Mono<EstadoProceso> consultarUnaVez(CodigoCuenta codigo) {
        return consultas.consultarEstadoProceso(codigo);
    }
}
