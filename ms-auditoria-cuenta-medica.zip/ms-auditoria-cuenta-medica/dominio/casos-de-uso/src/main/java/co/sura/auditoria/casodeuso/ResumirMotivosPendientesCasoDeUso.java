package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import reactor.core.publisher.Flux;

import java.util.Comparator;

/**
 * Caso de uso: qué motivos distintos tiene pendientes la cuenta.
 * Tipo: <em>Query</em> (no modifica estado).
 *
 * <p>Alimenta el filtro de la pantalla de pendientes. El orden es el del
 * trabajo, no el alfabético: primero lo que más queda por resolver, y a
 * igualdad lo que toca más líneas; el código desempata para que dos cargas
 * seguidas devuelvan lo mismo.
 */
public class ResumirMotivosPendientesCasoDeUso {

    private static final Comparator<ResumenMotivoPendiente> POR_PESO =
            Comparator.comparingInt(ResumenMotivoPendiente::sinResolver).reversed()
                    .thenComparing(Comparator.comparingInt(ResumenMotivoPendiente::lineasAfectadas).reversed())
                    .thenComparing(ResumenMotivoPendiente::codigo);

    private final PuertoPendientes pendientes;

    public ResumirMotivosPendientesCasoDeUso(PuertoPendientes pendientes) {
        this.pendientes = pendientes;
    }

    /**
     * <p>Aquí no se puede poner un {@code switchIfEmpty} que distinga la cuenta
     * inexistente: una cuenta perfectamente válida y sin pendientes produce
     * exactamente el mismo flujo vacío. Esa distinción la hace el adaptador, que
     * es quien sabe si la cuenta se resolvió.
     */
    public Flux<ResumenMotivoPendiente> ejecutar(CodigoCuenta codigo) {
        return pendientes.resumirMotivos(codigo).sort(POR_PESO);
    }
}
