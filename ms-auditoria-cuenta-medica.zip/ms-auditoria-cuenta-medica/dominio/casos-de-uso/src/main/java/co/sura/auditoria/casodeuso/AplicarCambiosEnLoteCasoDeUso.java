package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.CambioNovedad;
import co.sura.auditoria.modelo.cuenta.CambiosEnLote;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.CuentaMedica;
import co.sura.auditoria.modelo.cuenta.EdicionLinea;
import co.sura.auditoria.modelo.cuenta.LineaCuenta;
import co.sura.auditoria.modelo.cuenta.ReferenciaLinea;
import co.sura.auditoria.modelo.cuenta.ResultadoPorLinea;
import co.sura.auditoria.modelo.cuenta.Version;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoComandosCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.util.ArrayList;
import java.util.List;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Caso de uso: aplicar el mismo cambio a varias líneas. Tipo: <em>Command</em>.
 *
 * <h3>Una llamada si todo va bien, y quitar la mala si no</h3>
 * El contrato de escritura del sistema de registro acepta varias líneas en un solo parche, y
 * ese es el camino normal: una llamada, un recálculo.
 *
 * <p>Medido el 2026-10-17 contra el entorno de pruebas, con escritura: <b>el parche es
 * atómico</b>. Un lote con una línea inválida responde 422 y <b>no aplica nada</b> —se
 * comprobó contando las novedades antes y después: nueve y nueve—. Así que no hay fallo
 * parcial que leer de la respuesta: hay que construirlo.
 *
 * <p>Lo que sí regala el sistema de registro es <b>cuál</b> falló:
 * {@code "o:errorPath": "$.claimLineList[1]"}. Con eso, el lote que falla no se reintenta a
 * ciegas línea por línea: se quita la señalada, se anota su porqué y se reintenta el resto de
 * una vez. Un lote de veinte con dos malas cuesta tres llamadas, no veintiuna.
 *
 * <p>Cuando el error <b>no</b> señala línea —el conflicto de versión de la cuenta responde
 * {@code "o:errorPath": "$"}— no se reintenta nada: el problema no es de las líneas y repetir
 * daría el mismo error tantas veces como líneas haya. Se informa y se acabó.
 *
 * <h3>Qué se comprueba antes de tocar nada</h3>
 * Cada línea se lee y se descarta aquí si no es editable —bloqueada o reemplazada—. Son fallos
 * previsibles y nombrarlos antes evita gastar el parche en ellos. Lo que NO se comprueba aquí es
 * la concurrencia línea a línea: el parche lleva <b>una</b> versión, la de la cuenta, y esa es
 * la que protege la operación entera. Si otro auditor tocó cualquier línea entre la lectura y
 * el envío, la versión de la cuenta ya no cuadra y el sistema de registro rechaza el parche
 * completo. Es el comportamiento correcto y es el que describe el criterio de aceptación.
 */
public class AplicarCambiosEnLoteCasoDeUso {

    private final PuertoConsultaCuentas      consultas;
    private final PuertoComandosCuenta       comandos;
    private final PublicadorEventosAuditoria publicador;

    /**
     * Las mismas reglas de novedades que al guardar una línea: el sistema de registro no hace
     * ninguna de esas comprobaciones. El catálogo se mira una vez por lote; las bajas, por línea.
     */
    private final ComprobadorDeNovedades comprobador;

    public AplicarCambiosEnLoteCasoDeUso(PuertoConsultaCuentas consultas,
                                         PuertoComandosCuenta comandos,
                                         PublicadorEventosAuditoria publicador,
                                         ComprobadorDeNovedades comprobador) {
        this.consultas   = consultas;
        this.comandos    = comandos;
        this.publicador  = publicador;
        this.comprobador = comprobador;
    }

    public Mono<ResultadoPorLinea> ejecutar(CodigoCuenta codigo, CambiosEnLote cambios,
                                            String autor) {
        if (autor == null || autor.isBlank())
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.DecisionEnvioInvalida(
                    "No se identificó al auditor: la operación alcanza varias líneas y tiene "
                  + "que quedar firmada")));

        // Las altas, contra el catálogo y una sola vez: si el código no se puede poner a mano o
        // le faltan datos, no vale para ninguna línea y el lote entero se rechaza antes de leer.
        var altas = cambios.novedades().stream().filter(CambioNovedad::esAlta).toList();
        return comprobador.comprobar(altas, List.of(), "El lote")
                .then(consultas.buscarPorCodigo(codigo))
                .switchIfEmpty(Mono.error(ExcepcionDeDominio.de(
                        new ErrorDeDominio.CuentaNoEncontrada(codigo.valor()))))
                .flatMap(cuenta -> leerLineas(codigo, cambios)
                        .flatMap(leidas -> aplicar(codigo, cuenta.version(), cambios, leidas)))
                .flatMap(resultado -> registrar(codigo, cambios, autor, resultado));
    }

    /**
     * Cuántas líneas se leen a la vez antes de aplicar (OPE-12). Una a una, 500 líneas eran
     * unas 2.000 llamadas en serie; con cuatro a la vez el lote tarda una cuarta parte sin
     * ocupar más de unas pocas conexiones del pool que comparten todos los auditores.
     */
    static final int LECTURAS_A_LA_VEZ = 4;

    /** Lee las líneas elegidas y aparta las que no se pueden tocar, con su porqué. */
    private Mono<Leidas> leerLineas(CodigoCuenta codigo, CambiosEnLote cambios) {
        return Flux.fromIterable(cambios.seleccion().referencias())
                // flatMapSequential y no flatMap: varias a la vez, pero el resultado en el orden
                // de la selección, que es el que se informa.
                .flatMapSequential(referencia -> consultas.buscarDetalleLinea(codigo, referencia)
                        .map(linea -> (Object) linea)
                        .defaultIfEmpty(new ResultadoPorLinea.Fallo(
                                referencia, null, "La línea ya no existe en la cuenta")),
                        LECTURAS_A_LA_VEZ)
                .collectList()
                .map(Leidas::repartir);
    }

    private Mono<ResultadoPorLinea> aplicar(CodigoCuenta codigo, Version versionCuenta,
                                            CambiosEnLote cambios, Leidas leidas) {
        if (leidas.editables.isEmpty())
            return Mono.just(ResultadoPorLinea.de(List.of(), leidas.fallos));

        // Solo lo que de verdad falta en cada línea: repetir un lote no duplica nada (OPE-12).
        var ediciones = new ArrayList<EdicionLinea>();
        var yaEstaban = new ArrayList<co.sura.auditoria.modelo.cuenta.ReferenciaLinea>();
        var fallos    = new ArrayList<>(leidas.fallos);
        for (var linea : leidas.editables) {
            var pendiente = cambios.pendienteParaLinea(linea);
            if (pendiente.isEmpty()) { yaEstaban.add(linea.referencia()); continue; }

            var ajenas = bajasAjenas(pendiente.get(), linea);
            if (!ajenas.isEmpty()) {
                // Las del motor no se quitan a mano: sería borrar una objeción que no se rehace.
                fallos.add(new ResultadoPorLinea.Fallo(linea.referencia(), linea.numeroLinea(),
                        "Solo se pueden eliminar las novedades puestas a mano; la levantó el sistema: "
                        + String.join(", ", ajenas)));
                continue;
            }
            // El total glosado es la suma del desglose y el sistema de registro no lo recalcula:
            // se cuadra aquí contra la línea recién leída, igual que al guardar una sola.
            ediciones.add(pendiente.get().tocaGlosas()
                    ? pendiente.get().conValorGlosado(pendiente.get().valorGlosadoResultante(linea.glosas()))
                    : pendiente.get());
        }
        if (ediciones.isEmpty())
            return Mono.just(ResultadoPorLinea.de(List.of(), fallos, yaEstaban));

        var referencias = ediciones.stream().map(EdicionLinea::referencia).toList();
        return comandos.aplicarEdicionesDeLinea(codigo, versionCuenta, ediciones)
                .thenReturn(ResultadoPorLinea.de(referencias, fallos, yaEstaban))
                .onErrorResume(error -> aplicadoSinRelectura(error)
                        // El PATCH se aplicó y lo que falló fue releer: están aplicadas (OPE-11).
                        ? Mono.just(ResultadoPorLinea.de(referencias, fallos, yaEstaban))
                        // El lote falló: se repite línea a línea para poder decir cuál.
                        : quitandoLaRechazada(codigo, cambios, ediciones, fallos, leidas,
                                              yaEstaban, error));
    }

    /** Los códigos de las novedades que la edición quiere quitar y que no puso una persona. */
    private static List<String> bajasAjenas(EdicionLinea edicion, LineaCuenta linea) {
        var aQuitar = edicion.novedades().stream().filter(CambioNovedad::esBaja)
                .map(CambioNovedad::identificador).toList();
        return linea.novedades().stream()
                .filter(n -> aQuitar.contains(n.identificador()))
                .filter(n -> !n.laPusoUnaPersona())
                .map(n -> n.codigo())
                .toList();
    }

    private static boolean aplicadoSinRelectura(Throwable error) {
        return error instanceof ExcepcionDeDominio excepcion
            && excepcion.error() instanceof ErrorDeDominio.AplicadoSinRelectura;
    }

    /**
     * El camino de atribución: quitar la línea que el sistema de registro señaló y reintentar.
     *
     * <p>Recursivo a propósito, y con el conjunto menguando en cada vuelta: cada intento o
     * aplica el resto o nombra otra mala. Termina siempre, porque cada vuelta tiene al menos
     * una línea menos que la anterior.
     *
     * <p>Si el error no señala línea, se para: el problema es de la cuenta —típicamente su
     * versión— y las líneas que quedaban no se aplicaron. Salen todas como fallo con la misma
     * causa, que es exactamente lo que pasó.
     */
    private Mono<ResultadoPorLinea> quitandoLaRechazada(
            CodigoCuenta codigo, CambiosEnLote cambios, List<EdicionLinea> ediciones,
            List<ResultadoPorLinea.Fallo> fallosPrevios, Leidas leidas,
            List<co.sura.auditoria.modelo.cuenta.ReferenciaLinea> yaEstaban, Throwable error) {

        var rechazada = indiceRechazado(error);
        if (rechazada.isEmpty() || ediciones.isEmpty()) {
            var fallos = new ArrayList<>(fallosPrevios);
            ediciones.forEach(e -> fallos.add(new ResultadoPorLinea.Fallo(
                    e.referencia(), numeroDe(leidas, e.referencia()), explicar(error))));
            return Mono.just(ResultadoPorLinea.de(List.of(), fallos, yaEstaban));
        }

        int indice = rechazada.getAsInt();
        if (indice < 0 || indice >= ediciones.size()) {
            // El índice no cuadra con lo que se envió. No se adivina: se informa del error tal
            // cual, que es menos útil pero cierto, en vez de culpar a una línea al azar.
            var fallos = new ArrayList<>(fallosPrevios);
            ediciones.forEach(e -> fallos.add(new ResultadoPorLinea.Fallo(
                    e.referencia(), numeroDe(leidas, e.referencia()), explicar(error))));
            return Mono.just(ResultadoPorLinea.de(List.of(), fallos, yaEstaban));
        }

        var mala = ediciones.get(indice);
        var fallos = new ArrayList<>(fallosPrevios);
        fallos.add(new ResultadoPorLinea.Fallo(
                mala.referencia(), numeroDe(leidas, mala.referencia()), explicar(error)));

        var quedan = new ArrayList<>(ediciones);
        quedan.remove(indice);
        if (quedan.isEmpty()) return Mono.just(ResultadoPorLinea.de(List.of(), fallos, yaEstaban));

        // La versión se relee: el intento anterior no aplicó nada, pero entre medias pudo
        // moverla otro. Pedirla nunca sobra y evita un conflicto que no es nuestro.
        return consultas.buscarPorCodigo(codigo)
                .map(CuentaMedica::version)
                .flatMap(version -> comandos.aplicarEdicionesDeLinea(codigo, version, quedan)
                        .thenReturn(ResultadoPorLinea.de(
                                quedan.stream().map(EdicionLinea::referencia).toList(), fallos, yaEstaban))
                        .onErrorResume(siguiente -> aplicadoSinRelectura(siguiente)
                                ? Mono.just(ResultadoPorLinea.de(
                                        quedan.stream().map(EdicionLinea::referencia).toList(), fallos, yaEstaban))
                                : quitandoLaRechazada(codigo, cambios, quedan, fallos, leidas,
                                                      yaEstaban, siguiente)));
    }

    /** El índice que el sistema de registro señaló, si lo señaló. */
    private static java.util.OptionalInt indiceRechazado(Throwable error) {
        if (error instanceof ExcepcionDeDominio excepcion
                && excepcion.error() instanceof ErrorDeDominio.LineaDelLoteRechazada rechazo) {
            return java.util.OptionalInt.of(rechazo.indice());
        }
        return java.util.OptionalInt.empty();
    }

    private static Integer numeroDe(Leidas leidas, ReferenciaLinea referencia) {
        return leidas.editables.stream()
                .filter(l -> l.referencia().equals(referencia))
                .map(LineaCuenta::numeroLinea)
                .findFirst().orElse(null);
    }

    /**
     * El porqué, en palabras que el auditor pueda leer.
     *
     * <p>El rechazo de una línea trae su detalle dentro del error de dominio, no en el
     * mensaje de la excepción: sin este caso, el informe decía «LineaDelLoteRechazada» —el
     * nombre del tipo— donde tenía que decir qué pasó. Lo encontró la prueba.
     */
    private static String explicar(Throwable error) {
        if (error instanceof ExcepcionDeDominio excepcion
                && excepcion.error() instanceof ErrorDeDominio.LineaDelLoteRechazada rechazo) {
            return rechazo.detalle();
        }
        var mensaje = error.getMessage();
        return mensaje == null || mensaje.isBlank() ? error.getClass().getSimpleName() : mensaje;
    }

    /**
     * Deja el rastro, a mejor esfuerzo.
     *
     * <p>Si la traza falla no se deshace lo aplicado ni se convierte en error: el cambio en el
     * sistema de registro ya ocurrió y es irreversible, así que decir que falló haría que el
     * auditor lo repitiera sobre una cuenta que ya cambió.
     */
    private Mono<ResultadoPorLinea> registrar(CodigoCuenta codigo, CambiosEnLote cambios,
                                              String autor, ResultadoPorLinea resultado) {
        var detalle = "%d línea(s) aplicadas, %d ya estaban, %d fallo(s); glosas=%d, novedades=%d"
                .formatted(resultado.cuantasAplicadas(), resultado.yaEstaban().size(),
                           resultado.fallos().size(), cambios.glosas().size(), cambios.novedades().size());

        return publicador.publicar(EventoAuditoria.lineasCambiadasEnLote(codigo.valor(), detalle, autor))
                .onErrorResume(e -> Mono.empty())
                .thenReturn(resultado);
    }

    /** Lo leído, repartido entre lo que se puede tocar y lo que no. */
    private record Leidas(List<LineaCuenta> editables, List<ResultadoPorLinea.Fallo> fallos) {

        static Leidas repartir(List<Object> leidas) {
            var editables = new ArrayList<LineaCuenta>();
            var fallos    = new ArrayList<ResultadoPorLinea.Fallo>();
            for (var cada : leidas) {
                if (cada instanceof ResultadoPorLinea.Fallo fallo) { fallos.add(fallo); continue; }
                var linea = (LineaCuenta) cada;
                if (linea.esEditable()) editables.add(linea);
                else fallos.add(new ResultadoPorLinea.Fallo(
                        linea.referencia(), linea.numeroLinea(), linea.razonNoEditable()));
            }
            return new Leidas(editables, fallos);
        }
    }
}
