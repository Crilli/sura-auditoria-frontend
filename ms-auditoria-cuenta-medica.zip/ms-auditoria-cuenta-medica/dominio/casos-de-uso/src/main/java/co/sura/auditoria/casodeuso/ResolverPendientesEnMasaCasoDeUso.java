package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.NivelResolucion;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import reactor.core.publisher.Mono;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Caso de uso: resolver varios motivos pendientes de una cuenta en una sola
 * operación. Tipo: <em>Command</em>.
 *
 * <h3>Por qué no es un bucle sobre la resolución individual</h3>
 * Resolver un motivo dispara la readjudicación de la cuenta entera. Nueve
 * motivos uno a uno son nueve readjudicaciones en serie de la misma cuenta, cada
 * una con su propio tiempo de espera largo; el sistema de registro tiene para
 * esto un recurso que acepta la lista de motivos y la procesa en una sola
 * operación de larga duración, de las que ya hay decenas de miles en el sistema
 * de registro lanzadas por sus propios usuarios, con duraciones del orden de 5 s.
 *
 * <h3>Flujo</h3>
 * <ol>
 *   <li>Verificar justificación y lista de motivos.</li>
 *   <li>Consultar a la vez las acciones disponibles y el agregado de motivos de
 *       la cuenta.</li>
 *   <li>Rechazar lo que no se puede: motivos que la cuenta no tiene, y niveles
 *       que no están autorizados o que no aplican a los motivos pedidos.</li>
 *   <li>Repartir los motivos por nivel y emitir una operación por nivel, <b>en
 *       serie</b>.</li>
 *   <li>Agregar la nota de justificación y publicar el evento de auditoría, los
 *       dos a mejor esfuerzo.</li>
 * </ol>
 *
 * <p>Las validaciones de los puntos 1 y 3 son deliberadamente estrictas y van
 * <em>antes</em> de tocar el sistema de registro. No es desconfianza del
 * cliente: el recurso conjunto rechaza la petición entera si un solo código de
 * motivo es desconocido, y lo hace con un código de mensaje que no dice cuál.
 * Comprobarlo aquí convierte eso en un error que nombra el motivo.
 *
 * <p><b>El resultado no es un booleano.</b> Que el sistema de registro acepte la
 * petición no significa que todo quedara resuelto: un motivo que otro auditor
 * acababa de resolver sale como fallo parcial dentro de la operación, no como
 * error de la llamada. Ver {@link ResultadoResolucionMasiva}.
 */
public class ResolverPendientesEnMasaCasoDeUso {

    /**
     * Tope de motivos por operación.
     *
     * <p>No viene de un límite del sistema de registro —no publica ninguno— sino
     * del radio de impacto: cada motivo arrastra todas sus filas, y la cuenta
     * mayor medida tiene 3.507 pendientes repartidos en 24 motivos. Un tope
     * obliga a que una resolución de toda la cuenta sea una decisión explícita y
     * repetida, en vez de un clic.
     */
    public static final int MAXIMO_MOTIVOS = 50;

    private final PuertoConsultaCuentas      consultas;
    private final PuertoPendientes           pendientes;
    private final PuertoNotas                notas;
    private final PublicadorEventosAuditoria publicador;

    public ResolverPendientesEnMasaCasoDeUso(PuertoConsultaCuentas consultas,
                                             PuertoPendientes pendientes,
                                             PuertoNotas notas,
                                             PublicadorEventosAuditoria publicador) {
        this.consultas  = consultas;
        this.pendientes = pendientes;
        this.notas      = notas;
        this.publicador = publicador;
    }

    /**
     * @param codigosMotivo códigos de motivo a resolver; se normalizan y se
     *                      eliminan duplicados antes de validar
     * @param nivel         a qué nivel resolverlos, o {@code DONDE_APLIQUE}
     * @param justificacion texto obligatorio que se agrega como nota en la cuenta
     * @param autor         identificador del auditor
     */
    public Mono<ResultadoResolucionMasiva> ejecutar(CodigoCuenta codigo,
                                                    Set<String> codigosMotivo,
                                                    NivelResolucion nivel,
                                                    String justificacion,
                                                    String autor) {

        if (justificacion == null || justificacion.isBlank())
            return invalida("La justificación es obligatoria para resolver pendientes");

        var pedidos = normalizar(codigosMotivo);
        if (pedidos.isEmpty())
            return invalida("Hay que indicar al menos un motivo a resolver");
        if (pedidos.size() > MAXIMO_MOTIVOS)
            return invalida(("No se pueden resolver más de %d motivos en una sola operación; "
                           + "se pidieron %d").formatted(MAXIMO_MOTIVOS, pedidos.size()));

        var nivelEfectivo = nivel == null ? NivelResolucion.DONDE_APLIQUE : nivel;

        // Dos consultas independientes, a la vez: las acciones autorizan la
        // operación y el agregado dice qué motivos tiene la cuenta y dónde.
        //
        // El agregado es además la comprobación de que la cuenta existe: su
        // adaptador traduce el vacío a CuentaNoEncontrada. Y las acciones llevan
        // `defaultIfEmpty` porque un `Mono.zip` con una fuente vacía se completa
        // vacío, y eso saldría por el canal web como un 200 sin cuerpo en vez de
        // como un error.
        return Mono.zip(consultas.consultarAccionesDisponibles(codigo)
                                 .defaultIfEmpty(AccionesDisponibles.ninguna()),
                        pendientes.resumirMotivos(codigo).collectList())
                .flatMap(tupla -> resolver(codigo, pedidos, nivelEfectivo,
                                           justificacion, autor,
                                           tupla.getT1(), tupla.getT2()));
    }

    private Mono<ResultadoResolucionMasiva> resolver(CodigoCuenta codigo,
                                                     Set<String> pedidos,
                                                     NivelResolucion nivel,
                                                     String justificacion,
                                                     String autor,
                                                     AccionesDisponibles acciones,
                                                     List<ResumenMotivoPendiente> motivos) {

        // Un código que la cuenta no tiene se nombra. El recurso conjunto
        // rechazaría la petición entera sin decir cuál.
        var conocidos = motivos.stream().map(ResumenMotivoPendiente::codigo)
                               .collect(java.util.stream.Collectors.toSet());
        var desconocidos = pedidos.stream().filter(c -> !conocidos.contains(c)).toList();
        if (!desconocidos.isEmpty())
            return invalida(("La cuenta %s no tiene pendientes sin resolver de %s: %s")
                    .formatted(codigo.valor(),
                               desconocidos.size() == 1 ? "este motivo" : "estos motivos",
                               String.join(", ", desconocidos)));

        // El reparto es por dónde está puesto cada motivo, no por lo que se pidió:
        // así «cuenta» sobre un motivo que solo está en las líneas no se queda en
        // una operación vacía que parecería haberlo resuelto.
        var deCabecera = nivel.alcanzaCabecera()
                ? seleccion(motivos, pedidos, ResumenMotivoPendiente::enCabecera)
                : Set.<String>of();
        var deLineas = nivel.alcanzaLineas()
                ? seleccion(motivos, pedidos, m -> m.lineasAfectadas() > 0)
                : Set.<String>of();

        if (deCabecera.isEmpty() && deLineas.isEmpty())
            return invalida(sinNivelAplicable(nivel, pedidos));

        if (!deCabecera.isEmpty() && !acciones.permite(AccionCuenta.RESOLVER_PENDIENTE))
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.AccionNoDisponible(
                    codigo.valor(), AccionCuenta.RESOLVER_PENDIENTE.name())));
        if (!deLineas.isEmpty() && !acciones.permite(AccionCuenta.RESOLVER_PENDIENTE_LINEA))
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.AccionNoDisponible(
                    codigo.valor(), AccionCuenta.RESOLVER_PENDIENTE_LINEA.name())));

        return emitir(codigo, deCabecera, deLineas)
                .flatMap(resultado -> registrar(codigo, pedidos, nivel, justificacion,
                                                autor, resultado));
    }

    /**
     * Emite una operación por nivel, <b>una después de otra</b>.
     *
     * <p>En serie a propósito: las dos readjudican la misma cuenta, y lanzarlas a
     * la vez es pedirle al sistema de registro que reprocese dos veces en
     * paralelo el mismo expediente. El coste de la espera es conocido y pequeño;
     * el de una colisión, no.
     *
     * <p><b>Si falla la segunda, el fallo no se propaga.</b> La primera ya se
     * aplicó y es irreversible: dejar salir el error haría que la llamada
     * respondiera como si no hubiera pasado nada, cuando el pendiente de
     * cabecera sí quedó resuelto. El auditor volvería a intentarlo sobre una
     * cuenta que ya cambió. Lo que de verdad ocurrió es un resultado
     * <em>parcial</em>, así que se devuelve como tal, con el motivo del fallo
     * dentro. Si falla la primera, en cambio, no se aplicó nada y el error sí
     * sale: es la única forma de decir «no se hizo nada».
     */
    private Mono<ResultadoResolucionMasiva> emitir(CodigoCuenta codigo,
                                                   Set<String> deCabecera,
                                                   Set<String> deLineas) {
        if (deCabecera.isEmpty())
            return pendientes.resolverMotivos(codigo, deLineas, NivelPendiente.LINEA);
        if (deLineas.isEmpty())
            return pendientes.resolverMotivos(codigo, deCabecera, NivelPendiente.CABECERA);

        return pendientes.resolverMotivos(codigo, deCabecera, NivelPendiente.CABECERA)
                .flatMap(cabecera -> pendientes
                        .resolverMotivos(codigo, deLineas, NivelPendiente.LINEA)
                        .map(cabecera::y)
                        .onErrorResume(error -> Mono.just(
                                cabecera.y(soloFallo(deLineas, error)))));
    }

    /**
     * Un resultado que solo lleva el fallo de una de las dos operaciones, para
     * unirlo con el de la que sí salió.
     *
     * <p>Lleva el mensaje del error tal cual: perderlo dejaría al auditor con un
     * «parcial» sin causa, y la causa puede ser muy distinta —sin permiso sobre
     * esos motivos, el sistema de registro caído— y llevar a acciones distintas.
     */
    private static ResultadoResolucionMasiva soloFallo(Set<String> motivos, Throwable error) {
        var detalle = error.getMessage() == null || error.getMessage().isBlank()
                ? error.getClass().getSimpleName()
                : error.getMessage();
        return new ResultadoResolucionMasiva(
                List.of(),
                ResultadoResolucionMasiva.Desenlace.FALLIDO,
                List.of(new ResultadoResolucionMasiva.Fallo(
                        "NIVEL_LINEA", String.join(", ", motivos),
                        "Los pendientes de cabecera se resolvieron, pero los de línea no: "
                        + detalle)));
    }

    /**
     * Deja el rastro de la operación: la nota en la cuenta y el evento de
     * auditoría, los dos a mejor esfuerzo.
     *
     * <p>Mismo criterio que la resolución individual: una vez que el sistema de
     * registro aceptó la operación, el efecto es irreversible desde aquí. Fallar
     * la llamada porque no se pudo escribir la nota le haría creer al auditor que
     * no se aplicó nada, y podría repetir una operación que ya tuvo efecto.
     */
    private Mono<ResultadoResolucionMasiva> registrar(CodigoCuenta codigo,
                                                      Set<String> pedidos,
                                                      NivelResolucion nivel,
                                                      String justificacion,
                                                      String autor,
                                                      ResultadoResolucionMasiva resultado) {
        var nota = ("Resolución masiva (%s) de %d motivo(s): %s. %s")
                .formatted(nivel.name(), pedidos.size(),
                           String.join(", ", pedidos), justificacion);

        return notas.agregarNota(codigo, autor, nota)
                .onErrorResume(e -> Mono.empty())
                .then(publicador.publicar(EventoAuditoria.pendientesResueltosEnMasa(
                                codigo.valor(), pedidos, nivel.name(),
                                resultado.desenlace().name(), justificacion, autor))
                        .onErrorResume(e -> Mono.empty()))
                .thenReturn(resultado);
    }

    /** Los códigos pedidos que cumplen la condición, en el orden del agregado. */
    private static Set<String> seleccion(List<ResumenMotivoPendiente> motivos,
                                         Set<String> pedidos,
                                         java.util.function.Predicate<ResumenMotivoPendiente> donde) {
        return motivos.stream()
                .filter(m -> pedidos.contains(m.codigo()))
                .filter(donde)
                .map(ResumenMotivoPendiente::codigo)
                .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));
    }

    /** Quita espacios y vacíos, y deduplica conservando el orden recibido. */
    private static Set<String> normalizar(Set<String> codigos) {
        if (codigos == null) return Set.of();
        return codigos.stream()
                .filter(java.util.Objects::nonNull)
                .map(String::trim)
                .filter(c -> !c.isEmpty())
                .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));
    }

    private static String sinNivelAplicable(NivelResolucion nivel, Set<String> pedidos) {
        var donde = switch (nivel) {
            case CUENTA -> "en la cabecera de la cuenta";
            case LINEAS -> "en las líneas";
            case DONDE_APLIQUE -> "en ningún nivel";
        };
        return ("Ninguno de los motivos pedidos (%s) está puesto %s, así que no hay nada "
              + "que resolver con ese alcance").formatted(String.join(", ", pedidos), donde);
    }

    private static <T> Mono<T> invalida(String detalle) {
        return Mono.error(ExcepcionDeDominio.de(
                new ErrorDeDominio.DecisionEnvioInvalida(detalle)));
    }
}
