package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.NivelResolucion;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.SeleccionLineas;
import co.sura.auditoria.modelo.cuenta.UbicacionMotivo;
import co.sura.auditoria.modelo.error.ErrorDeDominio;
import co.sura.auditoria.modelo.error.ExcepcionDeDominio;
import co.sura.auditoria.modelo.puertos.PublicadorEventosAuditoria;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import co.sura.auditoria.modelo.puertos.PuertoNotas;
import co.sura.auditoria.modelo.puertos.PuertoPendientes;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Caso de uso: resolver varios motivos pendientes de una cuenta en una sola
 * operación. Tipo: <em>Command</em>.
 *
 * <h3>Por qué no es un bucle sobre la resolución individual</h3>
 * Resolver un motivo dispara la readjudicación de la cuenta entera. Nueve
 * motivos uno a uno son nueve readjudicaciones en serie de la misma cuenta, cada
 * una con su propio tiempo de espera largo; el sistema de registro tiene para
 * esto un recurso que acepta la lista de motivos y la procesa en una sola
 * operación de larga duración, de las que ya hay decenas de miles en el sistema
 * de registro lanzadas por sus propios usuarios, con duraciones del orden de 5 s.
 *
 * <h3>Flujo</h3>
 * <ol>
 *   <li>Verificar justificación y lista de motivos.</li>
 *   <li>Consultar a la vez las acciones disponibles y dónde tiene la cuenta cada
 *       motivo pedido —dos consultas de existencia por motivo, no el recorrido de
 *       la cuenta (OPE-07)—.</li>
 *   <li>Rechazar lo que no se puede: motivos que la cuenta no tiene, y niveles
 *       que no están autorizados o que no aplican a los motivos pedidos.</li>
 *   <li>Repartir los motivos por nivel y emitir una operación por nivel: <b>a la
 *       vez</b> por omisión (OPE-08), o en serie si así se configura.</li>
 *   <li>Agregar la nota de justificación y publicar el evento de auditoría, los
 *       dos a mejor esfuerzo.</li>
 * </ol>
 *
 * <h3>Asíncrona</h3>
 * La respuesta no espera a que el sistema de registro termine: espera unos pocos
 * segundos y, si no ha acabado, devuelve {@code EN_CURSO} con las referencias de
 * las operaciones. {@link #seguir(CodigoCuenta, List)} dice después cómo acabaron, preguntándolo
 * al sistema de registro: no se guarda nada aquí (OPE-06).
 *
 * <p>Las validaciones de los puntos 1 y 3 son deliberadamente estrictas y van
 * <em>antes</em> de tocar el sistema de registro. No es desconfianza del
 * cliente: el recurso conjunto rechaza la petición entera si un solo código de
 * motivo es desconocido, y lo hace con un código de mensaje que no dice cuál.
 * Comprobarlo aquí convierte eso en un error que nombra el motivo.
 *
 * <p><b>El resultado no es un booleano.</b> Que el sistema de registro acepte la
 * petición no significa que todo quedara resuelto: un motivo que otro auditor
 * acababa de resolver sale como fallo parcial dentro de la operación, no como
 * error de la llamada. Ver {@link ResultadoResolucionMasiva}.
 */
public class ResolverPendientesEnMasaCasoDeUso {

    /**
     * Tope de motivos por operación.
     *
     * <p>No viene de un límite del sistema de registro —no publica ninguno— sino
     * del radio de impacto: cada motivo arrastra todas sus filas, y la cuenta
     * mayor medida tiene 3.507 pendientes repartidos en 24 motivos. Un tope
     * obliga a que una resolución de toda la cuenta sea una decisión explícita y
     * repetida, en vez de un clic.
     */
    public static final int MAXIMO_MOTIVOS = 50;

    /**
     * Tope de referencias por consulta de seguimiento. Una resolución lanza como mucho dos
     * operaciones; el margen es para quien siga varias a la vez, no para recorrer el
     * sistema de registro a base de identificadores.
     */
    public static final int MAXIMO_REFERENCIAS = 10;

    private final PuertoConsultaCuentas      consultas;
    private final PuertoPendientes           pendientes;
    private final PuertoNotas                notas;
    private final PublicadorEventosAuditoria publicador;
    private final boolean                    nivelesEnParalelo;

    /**
     * @param nivelesEnParalelo si la operación de cabecera y la de líneas salen a la vez.
     *                          Medido el 2026-10-17 en el entorno de pruebas: el sistema de
     *                          registro corre las dos en paralelo sobre la misma cuenta y
     *                          acaban bien, así que es lo que va por omisión. Con
     *                          {@code false} vuelven a ir en serie: es el interruptor por si
     *                          en una cuenta grande o con el sistema cargado chocaran, que
     *                          con una sola muestra en una cuenta de 9 líneas no se descarta.
     */
    public ResolverPendientesEnMasaCasoDeUso(PuertoConsultaCuentas consultas,
                                             PuertoPendientes pendientes,
                                             PuertoNotas notas,
                                             PublicadorEventosAuditoria publicador,
                                             boolean nivelesEnParalelo) {
        this.consultas         = consultas;
        this.pendientes        = pendientes;
        this.notas             = notas;
        this.publicador        = publicador;
        this.nivelesEnParalelo = nivelesEnParalelo;
    }

    /**
     * @param codigosMotivo códigos de motivo a resolver; se normalizan y se
     *                      eliminan duplicados antes de validar
     * @param nivel         a qué nivel resolverlos, o {@code DONDE_APLIQUE}
     * @param justificacion texto obligatorio que se agrega como nota en la cuenta
     * @param autor         identificador del auditor
     */
    public Mono<ResultadoResolucionMasiva> ejecutar(CodigoCuenta codigo,
                                                    Set<String> codigosMotivo,
                                                    NivelResolucion nivel,
                                                    String justificacion,
                                                    String autor) {
        return ejecutar(codigo, codigosMotivo, nivel, justificacion, autor,
                        SeleccionLineas.TODAS);
    }

    /**
     * Lo mismo, acotado a unas líneas concretas.
     *
     * @param seleccion a qué líneas limitar la parte de línea; {@link SeleccionLineas#TODAS}
     *                  para no acotar. <b>No afecta a la parte de cabecera</b>: un pendiente
     *                  de cabecera no pertenece a ninguna línea, así que acotarla no
     *                  significa nada y el adaptador descarta el alcance ahí.
     */
    public Mono<ResultadoResolucionMasiva> ejecutar(CodigoCuenta codigo,
                                                    Set<String> codigosMotivo,
                                                    NivelResolucion nivel,
                                                    String justificacion,
                                                    String autor,
                                                    SeleccionLineas seleccion) {

        // Sin firma no se resuelve. El cliente ya lo bloquea, pero la guarda vive
        // también aquí: la operación es irreversible y alcanza todas las filas de
        // cada motivo, así que no puede depender de que la pantalla esté bien
        // configurada. Sin autor, la traza no sirve para nada y la nota tampoco.
        if (autor == null || autor.isBlank())
            return invalida("No se identificó al auditor que resuelve: la operación es "
                          + "irreversible y tiene que quedar firmada");

        if (justificacion == null || justificacion.isBlank())
            return invalida("La justificación es obligatoria para resolver pendientes");

        var pedidos = normalizar(codigosMotivo);
        if (pedidos.isEmpty())
            return invalida("Hay que indicar al menos un motivo a resolver");
        if (pedidos.size() > MAXIMO_MOTIVOS)
            return invalida(("No se pueden resolver más de %d motivos en una sola operación; "
                           + "se pidieron %d").formatted(MAXIMO_MOTIVOS, pedidos.size()));

        var nivelEfectivo = nivel == null ? NivelResolucion.DONDE_APLIQUE : nivel;

        // Dos consultas independientes, a la vez: las acciones autorizan la
        // operación y la ubicación dice qué motivos tiene la cuenta y dónde.
        //
        // La ubicación es además la comprobación de que la cuenta existe: su
        // adaptador traduce el vacío a CuentaNoEncontrada. Y las dos llevan
        // `defaultIfEmpty` porque un `Mono.zip` con una fuente vacía se completa
        // vacío, y eso saldría por el canal web como un 200 sin cuerpo en vez de
        // como un error.
        // Se piden las dos acciones posibles: si lo guardado no permite alguna, se confirma sin
        // caché antes de negar (ver AutorizacionDeAcciones).
        return Mono.zip(AutorizacionDeAcciones.para(consultas, codigo, AccionCuenta.RESOLVER_PENDIENTE,
                                                    AccionCuenta.RESOLVER_PENDIENTE_LINEA)
                                 .defaultIfEmpty(AccionesDisponibles.ninguna()),
                        pendientes.ubicarMotivos(codigo, pedidos)
                                  .defaultIfEmpty(Map.of()))
                .flatMap(tupla -> resolver(codigo, pedidos, nivelEfectivo,
                                           justificacion, autor,
                                           seleccion == null ? SeleccionLineas.TODAS : seleccion,
                                           tupla.getT1(), tupla.getT2()));
    }

    private Mono<ResultadoResolucionMasiva> resolver(CodigoCuenta codigo,
                                                     Set<String> pedidos,
                                                     NivelResolucion nivel,
                                                     String justificacion,
                                                     String autor,
                                                     SeleccionLineas seleccion,
                                                     AccionesDisponibles acciones,
                                                     Map<String, UbicacionMotivo> ubicaciones) {

        // Un código que la cuenta no tiene se nombra. El recurso conjunto
        // rechazaría la petición entera sin decir cuál.
        var desconocidos = pedidos.stream().filter(c -> !ubicaciones.containsKey(c)).toList();
        if (!desconocidos.isEmpty())
            return invalida(("La cuenta %s no tiene pendientes sin resolver de %s: %s")
                    .formatted(codigo.valor(),
                               desconocidos.size() == 1 ? "este motivo" : "estos motivos",
                               String.join(", ", desconocidos)));

        // El reparto es por dónde está puesto cada motivo, no por lo que se pidió:
        // así «cuenta» sobre un motivo que solo está en las líneas no se queda en
        // una operación vacía que parecería haberlo resuelto.
        var deCabecera = nivel.alcanzaCabecera()
                ? seleccion(ubicaciones, pedidos, UbicacionMotivo::enCabecera)
                : Set.<String>of();
        var deLineas = nivel.alcanzaLineas()
                ? seleccion(ubicaciones, pedidos, UbicacionMotivo::enLineas)
                : Set.<String>of();

        if (deCabecera.isEmpty() && deLineas.isEmpty())
            return invalida(sinNivelAplicable(nivel, pedidos));

        if (!deCabecera.isEmpty() && !acciones.permite(AccionCuenta.RESOLVER_PENDIENTE))
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.AccionNoDisponible(
                    codigo.valor(), AccionCuenta.RESOLVER_PENDIENTE.name())));
        if (!deLineas.isEmpty() && !acciones.permite(AccionCuenta.RESOLVER_PENDIENTE_LINEA))
            return Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.AccionNoDisponible(
                    codigo.valor(), AccionCuenta.RESOLVER_PENDIENTE_LINEA.name())));

        return emitir(codigo, deCabecera, deLineas, seleccion)
                .flatMap(resultado -> registrar(codigo, pedidos, nivel, justificacion,
                                                autor, resultado));
    }

    /**
     * Emite una operación por nivel, <b>una después de otra</b>.
     *
     * <p>En serie a propósito: las dos readjudican la misma cuenta, y lanzarlas a
     * la vez es pedirle al sistema de registro que reprocese dos veces en
     * paralelo el mismo expediente. El coste de la espera es conocido y pequeño;
     * el de una colisión, no. Y «una después de otra» quiere decir después de que
     * la primera <em>termine</em>: si vuelve en curso, la segunda no se lanza.
     *
     * <p><b>Si falla la segunda, el fallo no se propaga.</b> La primera ya se
     * aplicó y es irreversible: dejar salir el error haría que la llamada
     * respondiera como si no hubiera pasado nada, cuando el pendiente de
     * cabecera sí quedó resuelto. El auditor volvería a intentarlo sobre una
     * cuenta que ya cambió. Lo que de verdad ocurrió es un resultado
     * <em>parcial</em>, así que se devuelve como tal, con el motivo del fallo
     * dentro. Si falla la primera, en cambio, no se aplicó nada y el error sí
     * sale: es la única forma de decir «no se hizo nada».
     */
    private Mono<ResultadoResolucionMasiva> emitir(CodigoCuenta codigo,
                                                   Set<String> deCabecera,
                                                   Set<String> deLineas,
                                                   SeleccionLineas seleccion) {
        if (deCabecera.isEmpty())
            return pendientes.resolverMotivos(codigo, deLineas, NivelPendiente.LINEA, seleccion);
        if (deLineas.isEmpty())
            return pendientes.resolverMotivos(codigo, deCabecera, NivelPendiente.CABECERA,
                                              SeleccionLineas.TODAS);

        return nivelesEnParalelo
                ? emitirALaVez(codigo, deCabecera, deLineas, seleccion)
                : emitirEnSerie(codigo, deCabecera, deLineas, seleccion);
    }

    /**
     * Las dos operaciones a la vez (OPE-08).
     *
     * <p>Cada una puede fallar al lanzarse sin arrastrar a la otra: si sale una, lo que
     * ocurrió es un resultado parcial que nombra el nivel que no salió; si no sale ninguna,
     * no se aplicó nada y el error sí se propaga, que es la única forma de decir «no se hizo
     * nada».
     */
    private Mono<ResultadoResolucionMasiva> emitirALaVez(CodigoCuenta codigo,
                                                         Set<String> deCabecera,
                                                         Set<String> deLineas,
                                                         SeleccionLineas seleccion) {
        return Mono.zip(
                        intento(pendientes.resolverMotivos(codigo, deCabecera,
                                                           NivelPendiente.CABECERA,
                                                           SeleccionLineas.TODAS)),
                        intento(pendientes.resolverMotivos(codigo, deLineas,
                                                           NivelPendiente.LINEA, seleccion)))
                .flatMap(par -> {
                    var cabecera = par.getT1();
                    var lineas   = par.getT2();
                    if (cabecera.fallo() != null && lineas.fallo() != null)
                        return Mono.error(cabecera.fallo());
                    if (cabecera.fallo() != null)
                        return Mono.just(lineas.resultado().y(falloDeNivel(
                                "NIVEL_CABECERA", deCabecera, cabecera.fallo(),
                                "La resolución de líneas se lanzó, pero la de cabecera no: ")));
                    if (lineas.fallo() != null)
                        return Mono.just(cabecera.resultado().y(falloDeNivel(
                                "NIVEL_LINEA", deLineas, lineas.fallo(),
                                "La resolución de cabecera se lanzó, pero la de líneas no: ")));
                    return Mono.just(cabecera.resultado().y(lineas.resultado()));
                });
    }

    /** Una operación lanzada: su resultado o el error con el que no salió. */
    private record Intento(ResultadoResolucionMasiva resultado, Throwable fallo) {}

    private static Mono<Intento> intento(Mono<ResultadoResolucionMasiva> operacion) {
        return operacion.map(resultado -> new Intento(resultado, null))
                        .onErrorResume(error -> Mono.just(new Intento(null, error)));
    }

    /** Las dos operaciones en serie: el modo conservador (OPE-03). */
    private Mono<ResultadoResolucionMasiva> emitirEnSerie(CodigoCuenta codigo,
                                                          Set<String> deCabecera,
                                                          Set<String> deLineas,
                                                          SeleccionLineas seleccion) {
        return pendientes.resolverMotivos(codigo, deCabecera, NivelPendiente.CABECERA,
                                          SeleccionLineas.TODAS)
                .flatMap(cabecera -> cabecera.desenlace() == ResultadoResolucionMasiva.Desenlace.EN_CURSO
                        // La de cabecera sigue corriendo: lanzar ya la de líneas sería el
                        // reproceso doble de la misma cuenta que la serie quiere evitar
                        // (OPE-03). «En curso» es un resultado, no un error, así que sin esta
                        // comprobación el flatMap seguía adelante.
                        ? Mono.just(cabecera.y(lineasSinLanzar(deLineas)))
                        : pendientes
                                .resolverMotivos(codigo, deLineas, NivelPendiente.LINEA, seleccion)
                                .map(cabecera::y)
                                .onErrorResume(error -> Mono.just(cabecera.y(falloDeNivel(
                                        "NIVEL_LINEA", deLineas, error,
                                        "Los pendientes de cabecera se resolvieron, pero los de línea no: ")))));
    }

    /**
     * Los motivos de línea que no se lanzaron porque la operación de cabecera seguía en curso.
     *
     * <p>Va como fallo para que el auditor lo lea junto al resultado: sin decirlo, «en curso»
     * le haría creer que también se están resolviendo los de línea. El desenlace del conjunto
     * sigue siendo «en curso», que es lo único cierto.
     *
     * <p>Pasa cuando el sistema de registro está ocupado: ejecuta como mucho 15 operaciones de
     * este tipo a la vez en todo el entorno, y las demás esperan en cola.
     */
    private static ResultadoResolucionMasiva lineasSinLanzar(Set<String> motivos) {
        return new ResultadoResolucionMasiva(
                List.of(),
                ResultadoResolucionMasiva.Desenlace.EN_CURSO,
                List.of(new ResultadoResolucionMasiva.Fallo(
                        "LINEAS_SIN_LANZAR", String.join(", ", motivos),
                        "La resolución de cabecera sigue en curso en el sistema de registro, así "
                        + "que la de líneas no se lanzó para no reprocesar la cuenta dos veces a "
                        + "la vez. Cuando termine, vuelva a resolver estos motivos de línea.")));
    }

    /**
     * Un resultado que solo lleva el fallo de una de las dos operaciones, para
     * unirlo con el de la que sí salió.
     *
     * <p>Lleva el mensaje del error tal cual: perderlo dejaría al auditor con un
     * «parcial» sin causa, y la causa puede ser muy distinta —sin permiso sobre
     * esos motivos, el sistema de registro caído— y llevar a acciones distintas.
     */
    private static ResultadoResolucionMasiva falloDeNivel(String codigoNivel, Set<String> motivos,
                                                          Throwable error, String prefijo) {
        var detalle = error.getMessage() == null || error.getMessage().isBlank()
                ? error.getClass().getSimpleName()
                : error.getMessage();
        return new ResultadoResolucionMasiva(
                List.of(),
                ResultadoResolucionMasiva.Desenlace.FALLIDO,
                List.of(new ResultadoResolucionMasiva.Fallo(
                        codigoNivel, String.join(", ", motivos), prefijo + detalle)));
    }

    /**
     * Cómo van unas resoluciones lanzadas antes (OPE-06).
     *
     * <p>Se pregunta al sistema de registro por cada referencia y se unen los desenlaces con
     * las mismas reglas que al lanzarlas: si alguna sigue en curso, el conjunto sigue en
     * curso. No se guarda nada en el servicio, así que da igual qué réplica conteste.
     *
     * @param codigo      la cuenta sobre la que se lanzaron
     * @param referencias las que devolvió la resolución; se ignoran las vacías y repetidas
     */
    public Mono<ResultadoResolucionMasiva> seguir(CodigoCuenta codigo, List<String> referencias) {
        var limpias = referencias == null ? List.<String>of() : referencias.stream()
                .filter(java.util.Objects::nonNull)
                .map(String::trim)
                .filter(r -> !r.isEmpty())
                .distinct()
                .toList();
        if (limpias.isEmpty())
            return invalida("Hay que indicar al menos una referencia de operación que seguir");
        if (limpias.size() > MAXIMO_REFERENCIAS)
            return invalida(("No se pueden seguir más de %d operaciones a la vez; se pidieron %d")
                    .formatted(MAXIMO_REFERENCIAS, limpias.size()));

        return Flux.fromIterable(limpias)
                .flatMapSequential(referencia -> pendientes.consultarResolucion(codigo, referencia))
                .reduce(ResultadoResolucionMasiva::y);
    }

    /**
     * Deja el rastro de la operación: la nota en la cuenta y el evento de
     * auditoría, los dos a mejor esfuerzo.
     *
     * <p>Mismo criterio que la resolución individual: una vez que el sistema de
     * registro aceptó la operación, el efecto es irreversible desde aquí. Fallar
     * la llamada porque no se pudo escribir la nota le haría creer al auditor que
     * no se aplicó nada, y podría repetir una operación que ya tuvo efecto.
     */
    private Mono<ResultadoResolucionMasiva> registrar(CodigoCuenta codigo,
                                                      Set<String> pedidos,
                                                      NivelResolucion nivel,
                                                      String justificacion,
                                                      String autor,
                                                      ResultadoResolucionMasiva resultado) {
        var nota = ("Resolución masiva (%s) de %d motivo(s): %s. %s")
                .formatted(nivel.name(), pedidos.size(),
                           String.join(", ", pedidos), justificacion);

        return notas.agregarNota(codigo, autor, nota)
                .onErrorResume(e -> Mono.empty())
                .then(publicador.publicar(EventoAuditoria.pendientesResueltosEnMasa(
                                codigo.valor(), pedidos, nivel.name(),
                                resultado.desenlace().name(), resultado.referencias(),
                                resultado.fallos().stream()
                                        .map(f -> f.codigo() + (f.elemento().isBlank() ? "" : "[" + f.elemento() + "]"))
                                        .toList(),
                                justificacion, autor))
                        .onErrorResume(e -> Mono.empty()))
                .thenReturn(resultado);
    }

    /** Los códigos pedidos que cumplen la condición, en el orden en que se pidieron. */
    private static Set<String> seleccion(Map<String, UbicacionMotivo> ubicaciones,
                                         Set<String> pedidos,
                                         java.util.function.Predicate<UbicacionMotivo> donde) {
        return pedidos.stream()
                .filter(c -> donde.test(ubicaciones.get(c)))
                .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));
    }

    /** Quita espacios y vacíos, y deduplica conservando el orden recibido. */
    private static Set<String> normalizar(Set<String> codigos) {
        if (codigos == null) return Set.of();
        return codigos.stream()
                .filter(java.util.Objects::nonNull)
                .map(String::trim)
                .filter(c -> !c.isEmpty())
                .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));
    }

    private static String sinNivelAplicable(NivelResolucion nivel, Set<String> pedidos) {
        var donde = switch (nivel) {
            case CUENTA -> "en la cabecera de la cuenta";
            case LINEAS -> "en las líneas";
            case DONDE_APLIQUE -> "en ningún nivel";
        };
        return ("Ninguno de los motivos pedidos (%s) está puesto %s, así que no hay nada "
              + "que resolver con ese alcance").formatted(String.join(", ", pedidos), donde);
    }

    private static <T> Mono<T> invalida(String detalle) {
        return Mono.error(ExcepcionDeDominio.de(
                new ErrorDeDominio.DecisionEnvioInvalida(detalle)));
    }
}
