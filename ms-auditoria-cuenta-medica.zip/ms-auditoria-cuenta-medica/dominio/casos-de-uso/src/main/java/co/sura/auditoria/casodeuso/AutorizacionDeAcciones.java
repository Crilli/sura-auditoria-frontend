package co.sura.auditoria.casodeuso;

import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.puertos.PuertoConsultaCuentas;
import java.util.Arrays;
import reactor.core.publisher.Mono;

/**
 * Las acciones de una cuenta para decidir si se permite algo.
 *
 * <p>Las acciones pueden venir de una caché corta (OPE-09). Si lo guardado ya permite lo que
 * se pide, vale: lo peor que puede pasar es que el sistema de registro lo rechace, y eso ya se
 * traduce. Pero si no lo permite, antes de negar se pregunta otra vez sin caché: negar por un
 * dato desfasado sería decir «no disponible» de algo que ya se puede hacer. Encontrado en la
 * revisión de las Fases 1 y 2.
 */
final class AutorizacionDeAcciones {

    private AutorizacionDeAcciones() {}

    /** Las acciones, confirmadas sin caché si lo guardado no permite todas las requeridas. */
    static Mono<AccionesDisponibles> para(PuertoConsultaCuentas consultas, CodigoCuenta codigo,
                                          AccionCuenta... requeridas) {
        return consultas.consultarAccionesDisponibles(codigo)
                .flatMap(guardadas -> Arrays.stream(requeridas).allMatch(guardadas::permite)
                        ? Mono.just(guardadas)
                        : consultas.consultarAccionesFrescas(codigo).defaultIfEmpty(guardadas));
    }
}
