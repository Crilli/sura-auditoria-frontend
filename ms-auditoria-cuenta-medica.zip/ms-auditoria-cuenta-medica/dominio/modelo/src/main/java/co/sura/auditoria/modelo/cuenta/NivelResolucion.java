package co.sura.auditoria.modelo.cuenta;

/**
 * A qué nivel de la cuenta se quiere resolver un motivo pendiente.
 *
 * <p>Los dos niveles son <b>disjuntos</b>: resolver en la cuenta no toca las
 * líneas, y resolver en las líneas no toca la cabecera. Verificado contra la
 * descripción que publica el propio sistema de registro para sus dos
 * operaciones —una dice «at claim level» y la otra «at claim line level»—, así
 * que para que un motivo desaparezca de una cuenta donde está en los dos sitios
 * hacen falta <b>dos</b> operaciones.
 *
 * <p>Por eso existe {@link #DONDE_APLIQUE}, que es lo que el auditor quiere casi
 * siempre: «que este motivo deje de frenar la cuenta», sin tener que averiguar
 * antes en qué niveles está puesto. Quien lo resuelve reparte los motivos por
 * nivel y emite las operaciones que hagan falta.
 *
 * <p>No se reutiliza {@code ResolverPendientesCasoDeUso.Alcance} a propósito:
 * su valor {@code CUENTA_Y_LINEAS} promete los dos niveles y en realidad solo
 * resuelve el de cuenta. Mientras ese nombre siga en la ruta individual, mezclar
 * los dos vocabularios haría pasar el error de uno al otro.
 */
public enum NivelResolucion {

    /** Solo el pendiente de la cabecera de la cuenta. */
    CUENTA,

    /** Solo los pendientes de las líneas. */
    LINEAS,

    /**
     * Donde cada motivo esté puesto: cabecera, líneas o ambos.
     *
     * <p>Se traduce a uno o dos niveles concretos según dónde viva cada motivo,
     * de modo que el auditor no pueda pedir «cuenta» sobre un motivo que solo
     * está en las líneas y quedarse con la sensación de haberlo resuelto.
     */
    DONDE_APLIQUE;

    /** Si hay que emitir la operación de nivel cuenta para este nivel. */
    public boolean alcanzaCabecera() {
        return this == CUENTA || this == DONDE_APLIQUE;
    }

    /** Si hay que emitir la operación de nivel línea para este nivel. */
    public boolean alcanzaLineas() {
        return this == LINEAS || this == DONDE_APLIQUE;
    }
}
