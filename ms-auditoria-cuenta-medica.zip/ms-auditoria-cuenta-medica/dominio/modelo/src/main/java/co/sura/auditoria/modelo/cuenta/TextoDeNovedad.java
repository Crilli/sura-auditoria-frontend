package co.sura.auditoria.modelo.cuenta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * La plantilla de un mensaje y los valores que la completan.
 *
 * <h3>Por qué existe esto</h3>
 * El sistema de registro guarda el texto de una novedad <b>en dos piezas</b>: la
 * plantilla, que vive en el catálogo y lleva marcadores {@code {0}}…{@code {9}},
 * y hasta diez valores sueltos en la propia novedad —los que su interfaz rotula
 * «Valor 0»…«Valor 9»—. <b>Él no las junta</b>: se comprobó contra su entorno de
 * pruebas que al leer una novedad devuelve la plantilla tal cual, con las llaves,
 * y los valores aparte. Juntarlas es cosa de quien lo pinta.
 *
 * <p>Por eso la regla vive aquí y en un solo sitio: la usan la novedad guardada,
 * la vista previa del catálogo y el caso de uso al validar. <b>La interfaz web
 * repite esta misma regla</b> para la vista previa mientras se teclea —no puede
 * preguntar al servicio por un texto que todavía no existe— así que si esto
 * cambia hay que cambiarla también allí; el fichero del navegador lo dice.
 *
 * @see #resolver(String, Map)
 */
public final class TextoDeNovedad {

    /**
     * Un marcador es una llave con <b>un solo dígito</b> dentro.
     *
     * <p>Un solo dígito y no varios porque el sistema de registro tiene
     * exactamente diez valores: un {@code {10}} no es un marcador suyo, es texto,
     * y tratarlo como marcador lo haría desaparecer del mensaje.
     */
    private static final Pattern MARCADOR = Pattern.compile("\\{([0-9])\\}");

    /** El máximo que admite cada valor. Pasarse da {@code 422 GEN-ORA-12899}. */
    public static final int LARGO_MAXIMO_VALOR = 300;

    /** Cuántos valores tiene una novedad: {@code value0}…{@code value9}. */
    public static final int CUANTOS_VALORES = 10;

    private TextoDeNovedad() {}

    /**
     * Qué marcadores usa una plantilla, en orden y sin repetir.
     *
     * <p><b>Los índices son dispersos</b>, no van de cero en adelante: medido en
     * el catálogo, {@code SURA-AUT-002} usa solo el 1 y el 2, y
     * {@code SURA-AUT-022} usa el 0, 1, 2, 4 y 6. Por eso hay que preguntarle a
     * la plantilla cuáles son en vez de contarlos.
     */
    public static List<Integer> marcadores(String plantilla) {
        if (plantilla == null) return List.of();
        var vistos = new ArrayList<Integer>(CUANTOS_VALORES);
        var buscador = MARCADOR.matcher(plantilla);
        while (buscador.find()) {
            var indice = Integer.parseInt(buscador.group(1));
            if (!vistos.contains(indice)) vistos.add(indice);
        }
        return List.copyOf(vistos);
    }

    /** @return si la plantilla necesita que alguien le ponga datos. */
    public static boolean pideDatos(String plantilla) {
        return !marcadores(plantilla).isEmpty();
    }

    /**
     * Compone el texto final sustituyendo cada marcador por su valor.
     *
     * <p><b>Un marcador sin valor se deja tal cual, con sus llaves.</b> Es
     * deliberado y es la decisión importante de este método: la alternativa
     * —dejarlo en blanco— produciría una frase que se lee entera y correcta a la
     * que le falta justo el dato («Autorización  encontrada y consumida»), y
     * nadie se daría cuenta. Con las llaves a la vista, el hueco se ve. Aun así
     * el caso de uso no deja guardar una novedad con marcadores sin rellenar:
     * esto es la red de abajo, no la puerta.
     *
     * <p>Un valor para un marcador que la plantilla no usa se ignora al
     * componer. El sistema de registro lo aceptaría y lo guardaría —se comprobó—
     * pero no se vería en ninguna parte.
     *
     * @param plantilla el texto del catálogo; {@code null} devuelve {@code null}
     * @param valores   por índice de marcador; {@code null} o vacío deja la
     *                  plantilla sin tocar
     */
    public static String resolver(String plantilla, Map<Integer, String> valores) {
        if (plantilla == null || valores == null || valores.isEmpty()) return plantilla;

        var buscador = MARCADOR.matcher(plantilla);
        var resultado = new StringBuilder(plantilla.length());
        while (buscador.find()) {
            var valor = valores.get(Integer.parseInt(buscador.group(1)));
            // appendReplacement interpreta $ y \ del reemplazo: un valor que
            // traiga un «$1» reventaría. Se cita para que viaje literal.
            buscador.appendReplacement(resultado,
                    java.util.regex.Matcher.quoteReplacement(
                            valor == null || valor.isBlank() ? buscador.group() : valor));
        }
        buscador.appendTail(resultado);
        return resultado.toString();
    }

    /**
     * Los marcadores de la plantilla que se quedaron sin valor.
     *
     * <p>Lo usa el caso de uso para no dejar guardar una novedad a medias: el
     * sistema de registro acepta tan contento un mensaje con las llaves sin
     * rellenar, y eso acaba leyéndolo el prestador.
     */
    public static List<Integer> marcadoresSinValor(String plantilla, Map<Integer, String> valores) {
        return marcadores(plantilla).stream()
                .filter(i -> valores == null
                          || valores.get(i) == null
                          || valores.get(i).isBlank())
                .toList();
    }

    /**
     * Los valores que sobran: los que no corresponden a ningún marcador de la
     * plantilla. Se rechazan en vez de guardarlos porque serían dato invisible.
     */
    public static List<Integer> valoresSobrantes(String plantilla, Map<Integer, String> valores) {
        if (valores == null || valores.isEmpty()) return List.of();
        var usados = marcadores(plantilla);
        return valores.keySet().stream().filter(i -> !usados.contains(i)).sorted().toList();
    }
}
