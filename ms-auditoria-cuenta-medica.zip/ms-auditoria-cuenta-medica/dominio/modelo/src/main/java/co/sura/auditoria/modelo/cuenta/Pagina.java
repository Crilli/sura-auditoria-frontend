package co.sura.auditoria.modelo.cuenta;

import java.util.List;
import java.util.Optional;
import java.util.function.ToLongFunction;

/**
 * Página de resultados con soporte para paginación keyset.
 *
 * <p>La regla de corte es simple: una página con menos elementos que
 * {@code tamanoPagina} significa que es la última página.
 *
 * @param <T> tipo del elemento de la página
 */
public record Pagina<T>(
        List<T> elementos,
        Optional<Cursor> cursorSiguiente,
        /** Total de registros — {@code null} excepto en la primera página, para evitar COUNT por cada salto. */
        Optional<Long> totalRegistros,
        int tamanoPagina
) {
    /**
     * Construye una página calculando automáticamente el cursor siguiente.
     *
     * @param elementos          elementos de la página actual
     * @param tamanoPagina       tamaño de página configurado
     * @param total              total de registros (puede ser {@code null})
     * @param extractorReferencia función que extrae la referencia (clave) de cada elemento
     */
    public static <T> Pagina<T> construir(List<T> elementos, int tamanoPagina, Long total,
                                           ToLongFunction<T> extractorReferencia) {
        // El cursor es el MÁXIMO de referencia entre todos los elementos de la
        // página, no el del último de la lista: el orden de entrega puede ser
        // por un campo de negocio (p. ej. numeroLinea) distinto de la referencia
        // que gobierna el avance del keyset. Tomar el último asumiría que la
        // lista viene ordenada por esa referencia, lo que rompería la paginación
        // en cuanto el orden de presentación cambiara.
        var siguiente = elementos.size() < tamanoPagina
                ? Optional.<Cursor>empty()
                : elementos.stream()
                        .mapToLong(extractorReferencia)
                        .max()
                        .stream().mapToObj(Cursor::new)
                        .findFirst();

        return new Pagina<>(
                List.copyOf(elementos),
                siguiente,
                Optional.ofNullable(total),
                tamanoPagina);
    }

    /** Página vacía (sin elementos, sin cursor, sin total). */
    public static <T> Pagina<T> vacia(int tamanoPagina) {
        return new Pagina<>(List.of(), Optional.empty(), Optional.of(0L), tamanoPagina);
    }
}
