package co.sura.auditoria.modelo.auditoria;

/** Resultado de la acción registrada en la traza de auditoría. */
public enum ResultadoEvento {
    EXITOSO,
    RECHAZADO,
    ERROR
}
