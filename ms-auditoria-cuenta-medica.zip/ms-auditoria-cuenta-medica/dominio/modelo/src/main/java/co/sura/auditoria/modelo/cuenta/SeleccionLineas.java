package co.sura.auditoria.modelo.cuenta;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Sobre qué líneas actúa una operación.
 *
 * <h3>Por qué un tipo y no una lista</h3>
 * Porque «ninguna línea» y «todas las líneas» son cosas distintas y una lista vacía las
 * confunde. En el cuerpo que espera el sistema de registro, {@code claimLineList} ausente
 * significa <b>todas las líneas aplicables de la cuenta</b>
 * ({@code OhiResolverPendientesRequest}), y lo mismo pasa con el desbloqueo: con la lista
 * vacía OHI desbloquea las de toda la cuenta. Así que una selección vacía que llegara como
 * lista vacía haría justo lo contrario de lo que el auditor pidió, sin error y sin aviso.
 *
 * <p>Este tipo obliga a decirlo: {@link #TODAS} es explícito y {@link #de(List)} rechaza el
 * vacío. Quien quiera «todas» tiene que escribirlo.
 *
 * @param referencias las líneas elegidas, sin repetidos y en el orden en que se eligieron;
 *                    vacío <b>solo</b> en {@link #TODAS}
 */
public record SeleccionLineas(Set<ReferenciaLinea> referencias) {

    /**
     * Todas las líneas aplicables de la cuenta.
     *
     * <p>No es «la selección está vacía»: es «no se acota». Ver el javadoc de la clase.
     */
    public static final SeleccionLineas TODAS = new SeleccionLineas(Set.of());

    public SeleccionLineas {
        // LinkedHashSet y no Set.copyOf: este conserva el orden de inserción y aquel no.
        // Importa porque el informe de fallo parcial enumera las líneas, y leerlo en el
        // orden en que se marcaron es lo que permite seguirlo contra la pantalla.
        referencias = referencias == null || referencias.isEmpty()
                ? Set.of()
                : java.util.Collections.unmodifiableSet(new LinkedHashSet<>(referencias));
    }

    /**
     * Una selección concreta.
     *
     * @throws IllegalArgumentException si viene vacía. Es un error de programación, no de
     *         dato: dejarlo pasar convertiría «estas tres» en «todas».
     */
    public static SeleccionLineas de(List<ReferenciaLinea> referencias) {
        if (referencias == null || referencias.isEmpty()) {
            throw new IllegalArgumentException(
                    "Una selección de líneas no puede ir vacía. Para no acotar, use SeleccionLineas.TODAS: "
                    + "el sistema de registro entiende la lista vacía como «todas las líneas de la cuenta».");
        }
        return new SeleccionLineas(new LinkedHashSet<>(referencias));
    }

    /** Si la operación alcanza toda la cuenta. */
    public boolean esTodaLaCuenta() {
        return referencias.isEmpty();
    }

    public int cuantas() {
        return referencias.size();
    }

    public List<Long> identificadores() {
        return referencias.stream().map(ReferenciaLinea::valor).toList();
    }
}
