package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;

/**
 * Un alta o una baja en el desglose de glosas de una línea.
 *
 * <h3>Por qué una lista de cambios y no el estado deseado</h3>
 * Se podría pedir «déjame el desglose así» y que el servicio dedujera qué
 * añadir y qué quitar. No se hace, por dos razones:
 * <ul>
 *   <li>el sistema de registro no admite esa forma: su colección
 *       {@code detallesGlosa} se modifica elemento a elemento con un atributo
 *       {@code op}, de modo que traducir un estado deseado obligaría a calcular
 *       el diff aquí y a confiar en que nadie tocó la línea en medio;</li>
 *   <li>una lista vacía sería ambigua —«bórralo todo» o «no toques nada»— y esa
 *       ambigüedad, sobre un dato con valor económico, es exactamente lo que no
 *       conviene dejar al azar.</li>
 * </ul>
 *
 * <p>Una glosa no se edita: se quita y se pone otra. El sistema de registro sí
 * tiene un {@code replace}, pero cambiar el importe o el causal de una glosa ya
 * aplicada borra el rastro de lo que se había objetado antes; separar el alta de
 * la baja deja las dos cosas en la traza.
 *
 * @param operacion    qué hacer
 * @param identificador de la glosa a eliminar; {@code null} en un alta, porque
 *                      el identificador lo asigna el sistema de registro
 * @param codigoGlosa  el causal, p. ej. {@code 208-1} o {@code TA0201}. No se
 *                      valida contra un catálogo: el sistema de registro no
 *                      publica ninguno y en producción conviven dos
 *                      convenciones distintas
 * @param generico     clasificación normativa de primer nivel («Tarifas»)
 * @param especifico   de segundo nivel («Ayudas diagnósticas»)
 * @param valor        lo que se descuenta. No negativo
 * @param texto        la redacción que ve el prestador
 */
public record CambioGlosa(Operacion operacion,
                          Long identificador,
                          String codigoGlosa,
                          String generico,
                          String especifico,
                          BigDecimal valor,
                          String texto) {

    public enum Operacion { AGREGAR, ELIMINAR }

    /**
     * Las dos formas son excluyentes y se comprueban aquí, no en la capa web:
     * una baja con importe o un alta con identificador son solicitudes que no
     * significan nada, y dejarlas pasar las convertiría en un parche que el
     * sistema de registro interpretaría a su manera.
     */
    public CambioGlosa {
        if (operacion == null)
            throw new IllegalArgumentException("Hay que decir si la glosa se agrega o se elimina");

        if (operacion == Operacion.ELIMINAR) {
            if (identificador == null)
                throw new IllegalArgumentException(
                        "Para eliminar una glosa hace falta su identificador");
            if (valor != null || codigoGlosa != null || texto != null)
                throw new IllegalArgumentException(
                        "Eliminar una glosa solo admite su identificador");
        } else {
            if (identificador != null)
                throw new IllegalArgumentException(
                        "El identificador de una glosa lo asigna el sistema de registro");
            if (codigoGlosa == null || codigoGlosa.isBlank())
                throw new IllegalArgumentException("La glosa necesita un código de causal");
            if (valor == null || valor.signum() < 0)
                throw new IllegalArgumentException(
                        "La glosa necesita un valor, y no puede ser negativo");
        }
    }

    public static CambioGlosa agregar(String codigoGlosa, String generico, String especifico,
                                      BigDecimal valor, String texto) {
        return new CambioGlosa(Operacion.AGREGAR, null, codigoGlosa, generico,
                               especifico, valor, texto);
    }

    public static CambioGlosa eliminar(long identificador) {
        return new CambioGlosa(Operacion.ELIMINAR, identificador, null, null, null, null, null);
    }

    public boolean esAlta()  { return operacion == Operacion.AGREGAR; }
    public boolean esBaja()  { return operacion == Operacion.ELIMINAR; }
}
