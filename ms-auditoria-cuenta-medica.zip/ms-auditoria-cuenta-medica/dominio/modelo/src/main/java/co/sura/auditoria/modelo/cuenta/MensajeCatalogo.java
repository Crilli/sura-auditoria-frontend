package co.sura.auditoria.modelo.cuenta;

/**
 * Un mensaje del catálogo, de los que un auditor puede poner como novedad.
 *
 * <p>El catálogo es la autoridad: el texto que acaba leyendo el prestador y la
 * severidad que decide si la cuenta sigue su curso salen de aquí y no de lo que
 * teclee nadie. Por eso un alta de novedad solo lleva el {@link #codigo}: ver
 * {@link CambioNovedad}.
 *
 * <h3>Qué queda fuera del catálogo ofrecible</h3>
 * El sistema de registro publica 2.029 mensajes, pero no todos son elegibles a
 * mano. Medido contra el entorno de pruebas, el filtro deja 696:
 * <ul>
 *   <li><b>los suyos propios</b> —1.325 marcados como específicos del sistema—
 *       los levanta su motor de reglas en sus propias etapas. El sistema de
 *       registro <b>no impide</b> que se pongan a mano (se comprobó: los acepta),
 *       pero de las 1.962 novedades manuales que ya existen allí no hay
 *       <b>ninguna</b> con un mensaje de ese grupo. El freno es nuestro;</li>
 *   <li><b>los obsoletos o inactivos</b> —9 y 8—, que son códigos retirados.</li>
 * </ul>
 *
 * <h3>Los que piden datos sí entran, y antes no</h3>
 * Sesenta y cinco de esos 696 llevan marcadores en el texto ({@code {0}}…
 * {@code {9}}) que alguien tiene que rellenar. Estuvieron fuera del catálogo con
 * el argumento de que, elegidos a mano, el prestador leería las llaves. <b>Ese
 * argumento se cayó</b> en cuanto la pantalla dejó de limitarse a elegir el
 * código y pasó a pedir también sus datos.
 *
 * <p>Y los datos dicen que hacen falta: de las 264 novedades manuales que usan
 * uno de esos 65 mensajes, <b>86 las puso una persona con nombre y apellido</b>
 * —85 un mismo auditor— y no la integración. Excluirlos le estaba quitando al
 * auditor mensajes que ya venía usando. Lo que sí hace falta es exigir que los
 * rellene: ver {@link #pideDatos()} y {@link TextoDeNovedad}.
 *
 * @param codigo     el que el auditor reconoce y la normativa cita, p. ej. {@code 332-1}
 * @param texto      la redacción que verá el prestador
 * @param severidad  la que el catálogo le asigna; de ella depende si frena la cuenta
 * @param generico   clasificación normativa de primer nivel; {@code null} si no la trae
 * @param especifico de segundo nivel; {@code null} si no la trae
 * @param esDelSistema lo que el sistema de registro rotula «Específico de
 *                     Sistema?»
 */
public record MensajeCatalogo(String codigo,
                              String texto,
                              Severidad severidad,
                              Novedad.Clasificacion generico,
                              Novedad.Clasificacion especifico,
                              boolean esDelSistema) {

    /**
     * @return los marcadores que hay que rellenar para poder usar este mensaje,
     *     en el orden en que aparecen. Vacío si el texto está completo.
     *
     * <p>Los índices son dispersos: ver {@link TextoDeNovedad#marcadores}.
     */
    public java.util.List<Integer> datosQuePide() {
        return TextoDeNovedad.marcadores(texto);
    }

    /** @return si hay que darle datos para que el texto se lea entero. */
    public boolean pideDatos() {
        return !datosQuePide().isEmpty();
    }

    /** El texto como quedaría con estos datos. Ver {@link TextoDeNovedad#resolver}. */
    public String textoCon(java.util.Map<Integer, String> valores) {
        return TextoDeNovedad.resolver(texto, valores);
    }

    /** @return si al ponerla la cuenta deja de poder avanzar. */
    public boolean frenaLaCuenta() {
        return severidad != null && severidad.frenaLaCuenta();
    }
}
