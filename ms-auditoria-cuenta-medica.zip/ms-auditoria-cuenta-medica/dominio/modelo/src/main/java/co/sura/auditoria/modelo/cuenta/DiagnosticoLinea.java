package co.sura.auditoria.modelo.cuenta;

/**
 * Diagnóstico asociado a una línea de la cuenta.
 *
 * <p>Viene de {@code claimLineDiagnosisList}. El código es CIE-10 y el tipo
 * distingue el principal de los relacionados.
 */
public record DiagnosticoLinea(
        int secuencia,
        String tipo,
        String descripcionTipo,
        String codigo,
        String descripcion
) {}
