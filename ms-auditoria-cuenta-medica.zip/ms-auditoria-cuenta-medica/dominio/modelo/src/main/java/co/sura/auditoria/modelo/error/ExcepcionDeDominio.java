package co.sura.auditoria.modelo.error;

/**
 * Excepción que envuelve un {@link ErrorDeDominio} para propagarlo
 * a través de la cadena reactiva hasta el manejador de errores HTTP.
 *
 * <p>Es la <em>única</em> excepción que cruza la frontera del dominio
 * hacia la capa de presentación. Todas las demás excepciones de dominio
 * se envuelven en esta antes de emitirse.
 */
public class ExcepcionDeDominio extends RuntimeException {

    private final transient ErrorDeDominio error;

    public ExcepcionDeDominio(ErrorDeDominio error) {
        super(error.getClass().getSimpleName());
        this.error = error;
    }

    public ErrorDeDominio error() {
        return error;
    }

    /** Método de fábrica para uso fluido: {@code Mono.error(ExcepcionDeDominio.de(new ErrorDeDominio.XXX(...)))}. */
    public static ExcepcionDeDominio de(ErrorDeDominio error) {
        return new ExcepcionDeDominio(error);
    }
}
