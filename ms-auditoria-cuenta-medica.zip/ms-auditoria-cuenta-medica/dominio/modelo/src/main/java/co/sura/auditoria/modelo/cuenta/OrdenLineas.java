package co.sura.auditoria.modelo.cuenta;

/**
 * Por qué columna y en qué sentido se ordena el listado de líneas.
 *
 * <h3>Una lista cerrada, y no el nombre que llegue</h3>
 * El campo no viaja como texto libre hasta el sistema de registro: se elige de esta lista. Dos
 * motivos, y el segundo pesa más que el primero. Uno, que un nombre inventado en la petición se
 * convertiría en un {@code orderBy} inventado y el sistema de registro contesta 500 con un error
 * que parece del dato. Dos, que **no todos los campos se pueden ordenar allí**, y la diferencia
 * no se adivina: hay que saberla.
 *
 * <h3>Lo que se puede y lo que no, medido</h3>
 * Comprobado contra el entorno de pruebas el 2026-10-16: ordenan bien {@code sequence},
 * {@code person.code}, {@code startDate}, {@code authorizationCode}, {@code procedure.code} y
 * {@code valorGlosado} —este último pese a que su propio metadato diga que no es filtrable—.
 * En cambio {@code claimedAmount} responde **500**, igual que {@code allowedAmount} y
 * {@code coveredAmount}: los importes de tipo monto llevan moneda y el motor no sabe ordenarlos.
 *
 * <p>De ahí que {@link Campo#VALOR_CARGADO} no tenga equivalente que empujar y haya que
 * resolverlo aquí, con la consecuencia de que esa página llega sin total.
 */
public record OrdenLineas(Campo campo, Sentido sentido) {

    /** El orden con el que el auditor lee una cuenta, y el que se usa si no se pide otro. */
    public static final OrdenLineas PREDETERMINADO =
            new OrdenLineas(Campo.NUMERO_LINEA, Sentido.ASCENDENTE);

    public OrdenLineas {
        if (campo == null) campo = Campo.NUMERO_LINEA;
        if (sentido == null) sentido = Sentido.ASCENDENTE;
    }

    public enum Sentido {
        ASCENDENTE("asc"), DESCENDENTE("desc");

        private final String enOhi;

        Sentido(String enOhi) { this.enOhi = enOhi; }

        public String enOhi() { return enOhi; }
    }

    public enum Campo {
        NUMERO_LINEA("sequence"),
        CEDULA_AFILIADO("person.code"),
        FECHA_ATENCION("startDate"),
        CODIGO_AUTORIZACION("authorizationCode"),
        CODIGO_PRESTACION("procedure.code"),
        VALOR_GLOSADO("valorGlosado"),
        /**
         * El único de los siete que el sistema de registro no sabe ordenar. Ver el javadoc de
         * la clase: aquí no hay campo que empujar, y quien lo pida tiene que ordenar en casa.
         */
        VALOR_CARGADO(null);

        private final String campoEnOhi;

        Campo(String campoEnOhi) { this.campoEnOhi = campoEnOhi; }

        /** @return el nombre del campo en el sistema de registro, o {@code null} si no se puede. */
        public String campoEnOhi() { return campoEnOhi; }

        public boolean seEmpuja() { return campoEnOhi != null; }
    }

    /**
     * @return si este orden lo puede resolver el sistema de registro.
     *
     * <p>Quien llame debe mirarlo <b>antes</b> de prometer un total: ordenar aquí obliga a
     * traerse el conjunto entero, y entonces el total que el sistema de registro devolvería
     * para una sola página ya no describe lo que se está enseñando.
     */
    public boolean seEmpuja() {
        return campo.seEmpuja();
    }

    /** La expresión tal como la espera el sistema de registro, p. ej. {@code "sequence asc"}. */
    public String expresionOhi() {
        if (!seEmpuja()) {
            throw new IllegalStateException(
                    "El orden por " + campo + " no se puede pedir al sistema de registro: "
                    + "los importes de tipo monto responden 500. Hay que ordenar en casa.");
        }
        return campo.campoEnOhi() + " " + sentido.enOhi();
    }
}
