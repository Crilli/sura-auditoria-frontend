package co.sura.auditoria.modelo.cuenta;

/**
 * Identificador de negocio de la cuenta médica.
 * Es el código que el auditor ve, usa y conoce (ej. GT-106586883036).
 * El identificador técnico interno de OHI NUNCA entra al dominio.
 */
public record CodigoCuenta(String valor) {

    public CodigoCuenta {
        if (valor == null || valor.isBlank())
            throw new IllegalArgumentException("El código de cuenta es obligatorio");
    }

    @Override
    public String toString() { return valor; }
}
