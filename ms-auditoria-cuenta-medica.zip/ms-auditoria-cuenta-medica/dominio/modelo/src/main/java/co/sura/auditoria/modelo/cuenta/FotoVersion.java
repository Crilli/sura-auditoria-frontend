package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

/**
 * Una versión de la cuenta tal como quedó al transmitirse: una foto, no la cuenta viva.
 *
 * <h3>Por qué importa decir que es una foto</h3>
 * Los importes de aquí son los de esa versión y pueden no parecerse a los de hoy —medido sobre
 * {@code CM-57944424433}: el valor de la factura pasó de 4.000.001 a 6.000.000 y a 8.800.000
 * entre la versión 1 y la 3—. Si la pantalla los enseñara junto a la cuenta viva sin decirlo,
 * el auditor tomaría por actual un importe de hace semanas.
 *
 * @param historial los estados por los que pasó <b>esta versión</b>, ordenados: desde el cierre
 *                  de la anterior hasta el suyo. En el sistema de registro llegan desordenados, en
 *                  español y acumulados —la versión N trae la historia de toda la cuenta—; el
 *                  adaptador los ordena, se queda con la vuelta de esta versión y los traduce al
 *                  nombre del dominio (FINALIZADA, ADJUDICACION_MANUAL…), o deja la palabra tal
 *                  cual si no la conoce
 */
public record FotoVersion(CodigoCuenta codigo,
                          int numero,
                          LocalDate fechaEntrada,
                          String numeroFactura,
                          String prestador,
                          BigDecimal valorFactura,
                          BigDecimal totalCargado,
                          BigDecimal totalAutorizado,
                          BigDecimal totalCubierto,
                          BigDecimal totalGlosado,
                          BigDecimal totalNotasCredito,
                          List<EstadoDeVersion> historial) {

    public FotoVersion {
        historial = historial == null ? List.of() : List.copyOf(historial);
    }

    /** Un estado de la versión, con cuándo entró en él. */
    public record EstadoDeVersion(String estado, Instant desde) {}

    /** El estado actual de la versión: el último del historial. */
    public String estadoActual() {
        return historial.isEmpty() ? null : historial.get(historial.size() - 1).estado();
    }
}
