package co.sura.auditoria.modelo.cuenta;

/** Datos de la atención y del siniestro que acompañan a la línea. */
public record OtrosDatosLinea(
        String tipoSala,
        String viaDeAcceso,
        String unidadEstrategicaNegocio,
        String codigoSiniestro
) {}
