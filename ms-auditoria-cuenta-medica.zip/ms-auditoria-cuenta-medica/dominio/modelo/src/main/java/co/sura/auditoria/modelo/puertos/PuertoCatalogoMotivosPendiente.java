package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.MotivoPendienteCatalogo;
import java.util.List;
import reactor.core.publisher.Mono;

/**
 * El catálogo de motivos de pendiente.
 *
 * <p>Va aparte de {@code PuertoCatalogoMotivos} —que es el de <b>desfinalización</b>— y de
 * {@code PuertoCatalogoNovedades} —que es el de mensajes—. Tres catálogos distintos que el
 * documento del MVP nombra todos «motivos».
 */
public interface PuertoCatalogoMotivosPendiente {

    /**
     * Todos los motivos que se pueden poner.
     *
     * <p>Son <b>237</b> medidos el 2026-10-17 en el entorno de pruebas, y el tope de página
     * del sistema de registro es 200 <b>sin avisar de que hay más</b>: quien lo implemente
     * tiene que recorrerlo por clave, no pedirlo de un tirón.
     */
    Mono<List<MotivoPendienteCatalogo>> listar();
}
