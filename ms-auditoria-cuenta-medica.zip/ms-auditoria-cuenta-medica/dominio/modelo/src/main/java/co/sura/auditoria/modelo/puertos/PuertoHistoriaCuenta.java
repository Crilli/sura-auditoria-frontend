package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.HitoCuenta;
import reactor.core.publisher.Flux;

/**
 * Por dónde ha pasado una cuenta.
 *
 * <p>Solo lectura: la historia la escribe el sistema de registro, no este servicio.
 */
public interface PuertoHistoriaCuenta {

    /**
     * Los hitos de la cuenta, del más antiguo al más reciente.
     *
     * <p>Une dos recursos del sistema de registro porque la historia vive repartida entre
     * ellos; ver {@link HitoCuenta}.
     */
    Flux<HitoCuenta> consultar(CodigoCuenta codigo);
}
