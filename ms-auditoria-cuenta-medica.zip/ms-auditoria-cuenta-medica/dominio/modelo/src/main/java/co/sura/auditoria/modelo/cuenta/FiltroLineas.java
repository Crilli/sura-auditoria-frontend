package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Por qué acotar el listado de líneas de una cuenta.
 *
 * <h3>La división que manda</h3>
 * Los criterios <b>no son equivalentes</b>, y el reparto no es una decisión de
 * diseño sino lo que acepta el sistema de registro, medido contra producción el
 * 13-oct-2026 sobre una cuenta de 4.063 líneas:
 *
 * <table border="1">
 *   <caption>Qué se puede pedirle al sistema de registro</caption>
 *   <tr><th>criterio</th><th>campo externo</th><th></th></tr>
 *   <tr><td>{@code cedulaAfiliado}</td><td>{@code person.code}</td><td>se empuja</td></tr>
 *   <tr><td>{@code desde} / {@code hasta}</td><td>{@code startDate}</td><td>se empuja</td></tr>
 *   <tr><td>{@code codigoAutorizacion}</td><td>{@code authorizationCode}</td><td>se empuja</td></tr>
 *   <tr><td>{@code codigoPrestacion}</td><td>{@code procedure.code}</td><td>se empuja</td></tr>
 *   <tr><td>{@code catalogo}</td><td>{@code procedure.flexCodeDefinitionCode}</td><td><b>no se puede</b></td></tr>
 *   <tr><td>{@code glosaDesde} / {@code glosaHasta}</td><td>{@code valorGlosado}</td><td><b>no se puede</b></td></tr>
 * </table>
 *
 * Los dos últimos responden {@code GEN-PROC-ERR}. Y no es que sean campos raros:
 * <b>ningún importe</b> de la línea admite filtro — {@code claimedAmount},
 * {@code allowedAmount} y {@code coveredAmount} fallan igual.
 *
 * <h3>Por qué importa tanto</h3>
 * El listado se pagina por keyset. Un criterio que no se puede empujar y se
 * aplica con un {@code filter} sobre la página <b>solo filtraría las filas a la
 * vista</b>, y el auditor leería «3 resultados» donde hay trescientos. Es el
 * mismo fallo que se cerró en la pantalla de pendientes, donde se veían 203 de
 * 3.507. Por eso este tipo distingue explícitamente las dos mitades con
 * {@link #seEmpujaEntero()}: quien resuelve la consulta pide al sistema de
 * registro lo que puede y sigue trayendo páginas hasta llenar la suya con el
 * resto, en vez de recortar la que tenga a mano.
 *
 * @param cedulaAfiliado     documento del afiliado, tal como lo publica el
 *                           sistema de registro ({@code CC43973184})
 * @param desde              primera fecha de atención incluida
 * @param hasta              última fecha de atención incluida
 * @param codigoAutorizacion código de autorización, exacto o por prefijo
 * @param codigoPrestacion   código de la prestación, exacto o por prefijo
 * @param catalogo           de qué catálogo sale el código de la prestación
 * @param glosaDesde         valor glosado mínimo, incluido
 * @param glosaHasta         valor glosado máximo, incluido
 */
public record FiltroLineas(String cedulaAfiliado,
                           LocalDate desde,
                           LocalDate hasta,
                           String codigoAutorizacion,
                           String codigoPrestacion,
                           CatalogoPrestacion catalogo,
                           BigDecimal glosaDesde,
                           BigDecimal glosaHasta) {

    /** Sin ningún criterio: el listado completo de la cuenta. */
    public static final FiltroLineas NINGUNO =
            new FiltroLineas(null, null, null, null, null, null, null, null);

    /** Normaliza los textos: un criterio en blanco es no haber filtrado. */
    public FiltroLineas {
        cedulaAfiliado     = enBlancoEsNada(cedulaAfiliado);
        codigoAutorizacion = enBlancoEsNada(codigoAutorizacion);
        codigoPrestacion   = enBlancoEsNada(codigoPrestacion);
    }

    private static String enBlancoEsNada(String valor) {
        if (valor == null) return null;
        var limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    /** No hay nada que acotar. */
    public boolean vacio() {
        return cedulaAfiliado == null && desde == null && hasta == null
            && codigoAutorizacion == null && codigoPrestacion == null
            && catalogo == null && glosaDesde == null && glosaHasta == null;
    }

    /**
     * Si todo lo pedido se le puede pedir al sistema de registro.
     *
     * <p>Cuando es {@code true} la página que devuelve el sistema de registro ya
     * es la página final, su total es el total de verdad y no hace falta traer
     * nada de más. Cuando es {@code false} hay que seguir pidiendo páginas hasta
     * llenar la propia, y <b>el total que publica el sistema de registro deja de
     * valer</b>: cuenta las filas de antes de aplicar lo que él no sabe aplicar.
     */
    public boolean seEmpujaEntero() {
        return catalogo == null && glosaDesde == null && glosaHasta == null;
    }

    /** Si hay algún criterio que el sistema de registro no sabe resolver. */
    public boolean exigeFiltradoLocal() {
        return !seEmpujaEntero();
    }

    /**
     * Si esta línea cumple los criterios que el sistema de registro no sabe
     * aplicar.
     *
     * <p>Solo evalúa esa mitad, a propósito: la otra ya viene resuelta en la
     * consulta, y volver a comprobarla aquí duplicaría la regla en dos sitios que
     * podrían separarse.
     */
    public boolean cumpleLoQueNoSeEmpuja(ResumenLinea linea) {
        if (catalogo != null && CatalogoPrestacion.de(linea.catalogoProcedimiento()) != catalogo) {
            return false;
        }
        if (glosaDesde != null || glosaHasta != null) {
            // Sin valor glosado se interpreta como cero: una línea sin glosa no
            // es «desconocida», es una línea que no tiene glosa, y quien busca
            // «glosadas por más de X» no la quiere ver.
            var glosa = linea.valorGlosado() == null ? BigDecimal.ZERO : linea.valorGlosado();
            if (glosaDesde != null && glosa.compareTo(glosaDesde) < 0) return false;
            if (glosaHasta != null && glosa.compareTo(glosaHasta) > 0) return false;
        }
        return true;
    }

    /** El mismo filtro sin la parte que el sistema de registro no sabe aplicar. */
    public FiltroLineas soloLoQueSeEmpuja() {
        return new FiltroLineas(cedulaAfiliado, desde, hasta,
                                codigoAutorizacion, codigoPrestacion, null, null, null);
    }
}
