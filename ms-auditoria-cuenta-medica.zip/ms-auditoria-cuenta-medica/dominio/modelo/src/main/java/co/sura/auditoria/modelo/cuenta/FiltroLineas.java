package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Por qué acotar el listado de líneas de una cuenta.
 *
 * <h3>La división que manda</h3>
 * Los criterios <b>no son equivalentes</b>, y el reparto no es una decisión de
 * diseño sino lo que acepta el sistema de registro, medido contra producción el
 * 13-oct-2026 sobre una cuenta de 4.063 líneas:
 *
 * <table border="1">
 *   <caption>Qué se puede pedirle al sistema de registro</caption>
 *   <tr><th>criterio</th><th>campo externo</th><th></th></tr>
 *   <tr><td>{@code cedulaAfiliado}</td><td>{@code person.code}</td><td>se empuja</td></tr>
 *   <tr><td>{@code desde} / {@code hasta}</td><td>{@code startDate}</td><td>se empuja</td></tr>
 *   <tr><td>{@code codigoAutorizacion}</td><td>{@code authorizationCode}</td><td>se empuja</td></tr>
 *   <tr><td>{@code codigoPrestacion}</td><td>{@code procedure.code}</td><td>se empuja</td></tr>
 *   <tr><td>{@code catalogo}</td><td>{@code procedure.flexCodeDefinitionCode}</td><td><b>no se puede</b></td></tr>
 *   <tr><td>{@code glosaDesde} / {@code glosaHasta}</td><td>{@code valorGlosado}</td><td><b>no se puede</b></td></tr>
 *   <tr><td>{@code conNovedad}</td><td>{@code claimLineMessageList.id}</td><td>se empuja</td></tr>
 *   <tr><td>{@code motivoPendiente}</td><td>{@code claimLinePendReasonList.pendReason.code}</td><td>se empuja</td></tr>
 *   <tr><td>{@code bloqueo}</td><td>{@code …pendReason.adjudicationOnly}</td><td>se empuja, sabiendo el estado</td></tr>
 * </table>
 *
 * Los dos últimos responden {@code GEN-PROC-ERR}. Y no es que sean campos raros:
 * <b>ningún importe</b> de la línea admite filtro — {@code claimedAmount},
 * {@code allowedAmount} y {@code coveredAmount} fallan igual.
 *
 * <h3>Por qué importa tanto</h3>
 * El listado se pagina por keyset. Un criterio que no se puede empujar y se
 * aplica con un {@code filter} sobre la página <b>solo filtraría las filas a la
 * vista</b>, y el auditor leería «3 resultados» donde hay trescientos. Es el
 * mismo fallo que se cerró en la pantalla de pendientes, donde se veían 203 de
 * 3.507. Por eso este tipo distingue explícitamente las dos mitades con
 * {@link #seEmpujaEntero()}: quien resuelve la consulta pide al sistema de
 * registro lo que puede y sigue trayendo páginas hasta llenar la suya con el
 * resto, en vez de recortar la que tenga a mano.
 *
 * @param cedulaAfiliado     documento del afiliado, tal como lo publica el
 *                           sistema de registro ({@code CC43973184})
 * @param desde              primera fecha de atención incluida
 * @param hasta              última fecha de atención incluida
 * @param codigoAutorizacion código de autorización, exacto o por prefijo
 * @param codigoPrestacion   código de la prestación, exacto o por prefijo
 * @param catalogo           de qué catálogo sale el código de la prestación
 * @param glosaDesde         valor glosado mínimo, incluido
 * @param glosaHasta         valor glosado máximo, incluido
 * @param conNovedad         solo las líneas con alguna novedad
 * @param motivoPendiente    código del motivo de pendiente sin resolver
 * @param bloqueo            si se quieren las que frenan la cuenta, las que no, o todas
 *
 * <h3>Las colecciones hijas sí se pueden filtrar, y la nota anterior era falsa</h3>
 * Los tres últimos criterios viven en colecciones hijas de la línea, y durante un tiempo este
 * proyecto creyó que filtrarlas no funcionaba —que pedir las líneas de una cuenta cuyo
 * {@code claimLineMessageList} tuviera un código concreto devolvía la cuenta entera—. Era un
 * error de medición, corregido el 17-oct-2026: la verdad de referencia contra la que se comparaba
 * se había leído con {@code limit=200} sobre 823 filas de mensaje, así que el conteo por código
 * salía truncado y el filtro parecía devolver de más. Es el tope de 200 de siempre, que no avisa.
 *
 * <p>Repetida la medición con recorrido por clave sobre {@code CM-35343660784} (212 líneas, 823
 * mensajes, 1.035 pendientes), el filtro acierta los cinco códigos de mensaje y los seis motivos
 * de pendiente, uno a uno. Y las dos condiciones de un mismo criterio compuesto caen sobre la
 * <b>misma fila hija</b>, que es lo que hace falta para que «este motivo, sin resolver» signifique
 * eso: medido contra la cuenta 54546131436, cuyas 200 líneas tienen una fila de
 * {@code MP_FATAL_SIN_GLOSA} —90 sin resolver y 110 resuelta—, el filtro devuelve 90 con
 * {@code resolved.eq(false)}, 110 con {@code true} y 200 sin la condición.
 *
 * <p>Consecuencia práctica: estos tres criterios <b>no</b> degradan la paginación. El total del
 * servidor es correcto y el desplazamiento sigue funcionando encima, al contrario que el catálogo
 * y el techo de la glosa. Por eso {@link #seEmpujaEntero()} no los menciona.
 */
public record FiltroLineas(/** Número de línea exacto. El auditor lo teclea cuando alguien se lo dicta. */
                           Integer numeroLinea,
                           String cedulaAfiliado,
                           LocalDate desde,
                           LocalDate hasta,
                           String codigoAutorizacion,
                           String codigoPrestacion,
                           CatalogoPrestacion catalogo,
                           BigDecimal glosaDesde,
                           BigDecimal glosaHasta,
                           /**
                            * Solo las líneas que tienen alguna novedad. El auditor persigue
                            * causas, no líneas: esto es «enséñame lo que el motor objetó».
                            */
                           boolean conNovedad,
                           /** Solo las líneas con este motivo de pendiente sin resolver. */
                           String motivoPendiente,
                           /**
                            * Si se quieren solo las líneas con un pendiente que frena la cuenta,
                            * solo las que no, o es igual.
                            *
                            * <p>Es el mismo tipo que usa la pantalla de pendientes, y a propósito:
                            * bloquear no es una propiedad del motivo sino del par motivo-estado, así
                            * que la regla no puede estar escrita dos veces. Ver {@link FiltroBloqueo}.
                            */
                           FiltroBloqueo bloqueo,
                           /**
                            * Contra qué estado de la cuenta se resolvió {@link #bloqueo}.
                            *
                            * <p>No es un criterio: es la pieza que le falta al filtro de bloqueo
                            * para poder escribirse como una condición. Llega {@code null} cuando
                            * el filtro viene de la petición y se rellena con
                            * {@link #resueltoEn(EstadoCuenta)} justo antes de consultar. Así el
                            * filtro viaja completo y no hay que pasar el estado en paralelo por
                            * todo el camino de la consulta, donde se podría olvidar en una rama.
                            */
                           EstadoCuenta estadoResuelto) {

    /** Sin ningún criterio: el listado completo de la cuenta. */
    public static final FiltroLineas NINGUNO =
            new FiltroLineas(null, null, null, null, null, null, null, null, null,
                             false, null, FiltroBloqueo.TODOS, null);

    /** Normaliza los textos: un criterio en blanco es no haber filtrado. */
    public FiltroLineas {
        cedulaAfiliado     = enBlancoEsNada(cedulaAfiliado);
        codigoAutorizacion = enBlancoEsNada(codigoAutorizacion);
        codigoPrestacion   = enBlancoEsNada(codigoPrestacion);
        motivoPendiente    = enBlancoEsNada(motivoPendiente);
        if (bloqueo == null) bloqueo = FiltroBloqueo.TODOS;
    }

    private static String enBlancoEsNada(String valor) {
        if (valor == null) return null;
        var limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    /** No hay nada que acotar. */
    public boolean vacio() {
        return numeroLinea == null && cedulaAfiliado == null && desde == null && hasta == null
            && codigoAutorizacion == null && codigoPrestacion == null
            && catalogo == null && glosaDesde == null && glosaHasta == null
            && !conNovedad && motivoPendiente == null && bloqueo == FiltroBloqueo.TODOS;
    }

    /**
     * Si todo lo pedido se le puede pedir al sistema de registro.
     *
     * <p>Cuando es {@code true} la página que devuelve el sistema de registro ya
     * es la página final, su total es el total de verdad y no hace falta traer
     * nada de más. Cuando es {@code false} hay que seguir pidiendo páginas hasta
     * llenar la propia, y <b>el total que publica el sistema de registro deja de
     * valer</b>: cuenta las filas de antes de aplicar lo que él no sabe aplicar.
     */
    public boolean seEmpujaEntero() {
        return catalogo == null && glosaHasta == null;
    }

    /**
     * Si hace falta saber el estado de la cuenta antes de consultar.
     *
     * <p>Lo exige únicamente {@link #bloqueo}, porque bloquear depende del par motivo-estado:
     * en {@code ADJUDICACION_MANUAL} bloquea todo pendiente sin resolver y entonces el filtro
     * no se puede expresar como una condición sobre el indicador del catálogo. Quien resuelve
     * la consulta pregunta el estado solo en ese caso, y no en el camino corriente.
     */
    public boolean exigeEstadoDeLaCuenta() {
        return bloqueo != FiltroBloqueo.TODOS && estadoResuelto == null;
    }

    /** El mismo filtro, ya resuelto contra el estado de la cuenta. */
    public FiltroLineas resueltoEn(EstadoCuenta estado) {
        return new FiltroLineas(numeroLinea, cedulaAfiliado, desde, hasta, codigoAutorizacion,
                                codigoPrestacion, catalogo, glosaDesde, glosaHasta,
                                conNovedad, motivoPendiente, bloqueo, estado);
    }

    /**
     * El valor de {@code adjudicationOnly} que hay que exigir, si el filtro de bloqueo acota.
     *
     * @throws IllegalStateException si el filtro pide bloqueo y nadie lo resolvió todavía. Es un
     *         error de programación y no de dato: dejarlo pasar devolvería la página sin ese
     *         criterio, o sea más líneas de las pedidas, y nadie se enteraría.
     */
    public java.util.Optional<Boolean> soloAdjudicacionExigida() {
        if (bloqueo == FiltroBloqueo.TODOS) return java.util.Optional.empty();
        if (estadoResuelto == null) {
            throw new IllegalStateException(
                    "El filtro pide bloqueo " + bloqueo + " pero no se resolvió contra el estado "
                    + "de la cuenta. Hay que llamar a resueltoEn(estado) antes de consultar.");
        }
        return bloqueo.soloAdjudicacionExigida(estadoResuelto);
    }

    /** Si en el estado contra el que se resolvió, este filtro no puede casar con ninguna línea. */
    public boolean vacioPorDefinicion() {
        return estadoResuelto != null && bloqueo.vacioPorDefinicionEn(estadoResuelto);
    }

    /** Si hay algún criterio que el sistema de registro no sabe resolver. */
    public boolean exigeFiltradoLocal() {
        return !seEmpujaEntero();
    }

    /**
     * Si esta línea cumple los criterios que el sistema de registro no sabe
     * aplicar.
     *
     * <p>Solo evalúa esa mitad, a propósito: la otra ya viene resuelta en la
     * consulta, y volver a comprobarla aquí duplicaría la regla en dos sitios que
     * podrían separarse.
     */
    public boolean cumpleLoQueNoSeEmpuja(ResumenLinea linea) {
        if (catalogo != null && CatalogoPrestacion.de(linea.catalogoProcedimiento()) != catalogo) {
            return false;
        }
        if (glosaHasta != null) {
            // Sin valor glosado se interpreta como cero: una línea sin glosa no es
            // «desconocida», es una línea que no tiene glosa, y está por debajo de
            // cualquier techo. Es justo lo que el sistema de registro no sabe hacer.
            var glosa = linea.valorGlosado() == null ? BigDecimal.ZERO : linea.valorGlosado();
            if (glosa.compareTo(glosaHasta) > 0) return false;
        }
        return true;
    }

    /** El mismo filtro sin la parte que el sistema de registro no sabe aplicar. */
    public FiltroLineas soloLoQueSeEmpuja() {
        return new FiltroLineas(numeroLinea, cedulaAfiliado, desde, hasta,
                                codigoAutorizacion, codigoPrestacion, null,
                                glosaDesde, null, conNovedad, motivoPendiente, bloqueo,
                                estadoResuelto);
    }
}
