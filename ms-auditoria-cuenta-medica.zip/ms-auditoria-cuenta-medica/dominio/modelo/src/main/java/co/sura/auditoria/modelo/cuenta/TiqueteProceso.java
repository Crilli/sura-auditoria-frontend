package co.sura.auditoria.modelo.cuenta;

/**
 * Tiquete de seguimiento devuelto al iniciar el envío de una cuenta.
 * El envío en OHI es asíncrono: solo se obtiene una referencia de seguimiento
 * que el auditor usa para consultar el progreso.
 */
public record TiqueteProceso(
        CodigoCuenta codigoCuenta,
        /** URL o identificador de seguimiento devuelto por el sistema de registro. */
        String referenciaSeguimiento
) {}
