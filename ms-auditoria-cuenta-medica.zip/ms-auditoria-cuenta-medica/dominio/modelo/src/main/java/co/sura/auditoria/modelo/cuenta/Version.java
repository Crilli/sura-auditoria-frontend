package co.sura.auditoria.modelo.cuenta;

/**
 * Versión para control optimista de concurrencia.
 * Corresponde al {@code objectVersionNumber} de OHI, pero el dominio
 * lo expresa como un concepto propio: la versión del recurso.
 */
public record Version(long numero) {

    /** Verifica si esta versión coincide con la esperada por quien edita. */
    public boolean coincideCon(Version otra) {
        return otra != null && numero == otra.numero;
    }
}
