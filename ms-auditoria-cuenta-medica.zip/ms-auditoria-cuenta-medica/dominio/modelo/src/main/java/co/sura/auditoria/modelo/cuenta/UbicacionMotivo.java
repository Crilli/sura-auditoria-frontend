package co.sura.auditoria.modelo.cuenta;

/**
 * Dónde tiene una cuenta pendientes sin resolver de un motivo: en la cabecera, en las líneas
 * o en las dos (OPE-07).
 *
 * <p>Es lo único que necesita saber una resolución masiva antes de lanzarse: qué motivos
 * existen y a qué nivel hay que mandar cada uno. Antes se obtenía recorriendo todos los
 * pendientes de la cuenta —18 a 21 consultas en serie en la cuenta grande— para quedarse con
 * esto; ahora sale de dos consultas de existencia por motivo.
 *
 * @param codigo     el código del motivo
 * @param enCabecera si tiene una fila sin resolver en la cabecera
 * @param enLineas   si tiene al menos una fila sin resolver en alguna línea
 */
public record UbicacionMotivo(String codigo, boolean enCabecera, boolean enLineas) {

    /** Si la cuenta lo tiene en algún sitio. Un motivo que no está en ninguno es desconocido. */
    public boolean existe() {
        return enCabecera || enLineas;
    }
}
