package co.sura.auditoria.modelo.cuenta;

/**
 * El desenlace de una línea en la adjudicación: aprobada o negada.
 *
 * <p>Hoy solo lo publica la línea de una <b>versión</b> (BUS-21): en el histórico de lo
 * transmitido cada línea quedó con uno de los dos —medido en UAT el 2026-10-21, las 38.983
 * líneas de versión son 14.215 «Aprobado» y 24.768 «Negado», ninguna sin estado—. La línea
 * viva no lo publica, y en una cuenta reabierta lo tiene vacío mientras se trabaja: el estado
 * de la línea es una conclusión de la versión, no algo que se edite.
 *
 * <p>El sistema de registro lo escribe en español en el histórico y en inglés en la cuenta
 * viva; la traducción vive en el diccionario de la capa de integración.
 */
public enum EstadoLinea {
    APROBADA,
    NEGADA,
    /** Una palabra que el diccionario no conoce. Quien publica el estado la enseña tal cual. */
    DESCONOCIDO
}
