package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import reactor.core.publisher.Mono;

/**
 * Puerto de publicación de eventos de auditoría al bus de eventos.
 *
 * <p>La publicación es desacoplada y <em>nunca</em> hace fallar el caso de uso.
 * Los implementadores deben garantizar que los errores de publicación se manejen
 * internamente y no se propaguen al llamador.
 */
public interface PublicadorEventosAuditoria {

    /**
     * Publica el evento en el bus de mensajería.
     * El retorno es {@code Mono<Void>} para encadenarlo reactivamente,
     * pero los errores deben manejarse con {@code onErrorResume} en el llamador.
     */
    Mono<Void> publicar(EventoAuditoria evento);
}
