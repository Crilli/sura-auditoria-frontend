package co.sura.auditoria.modelo.cuenta;

/**
 * Modo de recálculo al guardar una línea.
 *
 * <p>Esta decisión tiene impacto financiero directo sobre la cuenta:
 * <ul>
 *   <li>{@link #EN_CASCADA} — propaga el recálculo de tarifación, coberturas y
 *       consumos de límites a toda la cuenta.</li>
 *   <li>{@link #AISLADO} — aplica únicamente los campos enviados sin propagar
 *       el recálculo.</li>
 * </ul>
 *
 * <p>El campo es obligatorio y <em>nunca</em> tiene valor por defecto,
 * para obligar a quien origina la edición a tomar una decisión consciente.
 */
public enum ModoRecalculo {
    EN_CASCADA,
    AISLADO
}
