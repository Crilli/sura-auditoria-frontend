package co.sura.auditoria.modelo.cuenta;

import java.util.List;
import java.util.Optional;

/**
 * Página localizada por desplazamiento, no por clave.
 *
 * <h3>Por qué existe junto a {@link Pagina}</h3>
 * {@link Pagina} pagina por clave: lleva un cursor opaco y solo sabe avanzar al
 * siguiente. Eso bastaba mientras lo único que se pedía fuera «la siguiente»,
 * pero no permite <b>saltar a una página cualquiera</b> ni decir <b>cuántas
 * hay</b>, y en una cuenta de 4.063 líneas eso son 163 páginas a las que no se
 * podía llegar.
 *
 * <p>El sistema de registro sí admite desplazamiento, y en profundidad: medido
 * contra producción, pedir la posición 4.025 de esa cuenta devuelve sus filas
 * sin rechistar, y el total que acompaña es el verdadero y no el de la primera
 * página. El tope de 200 que hay que respetar es el del tamaño de página, no el
 * del desplazamiento.
 *
 * <p>No sustituye a {@link Pagina}: los pendientes siguen con ella. Migrarlos es
 * otra conversación, porque ahí el problema de fondo es que la cabecera y las
 * líneas compartan una sola lista paginada.
 *
 * @param elementos      los de esta página
 * @param desplazamiento cuántos elementos se saltaron para llegar aquí
 * @param tamanoPagina   cuántos se pidieron
 * @param total          cuántos hay en total. <b>Vacío cuando no es de fiar</b>:
 *                       ver {@link #totalEsDeFiar()}
 * @param hayMas         si queda algo después de esta página. Siempre fiable,
 *                       incluso cuando el total no lo es
 */
public record PaginaDesplazada<T>(
        List<T> elementos,
        int desplazamiento,
        int tamanoPagina,
        Optional<Long> total,
        boolean hayMas
) {

    public PaginaDesplazada {
        elementos = List.copyOf(elementos);
        total = total == null ? Optional.empty() : total;
    }

    /**
     * Una página tal como la devuelve el sistema de registro, con su total.
     *
     * <p>Solo para cuando <b>todo</b> el filtro se pudo empujar: entonces lo que
     * él cuenta es lo mismo que se va a enseñar.
     */
    public static <T> PaginaDesplazada<T> deOhi(List<T> elementos, int desplazamiento,
                                                int tamanoPagina, Long total, boolean hayMas) {
        return new PaginaDesplazada<>(elementos, desplazamiento, tamanoPagina,
                                      Optional.ofNullable(total), hayMas);
    }

    /**
     * Una página que se armó descartando filas aquí.
     *
     * <p><b>Sin total, a propósito.</b> Cuando hay criterios que el sistema de
     * registro no sabe aplicar —el catálogo de la prestación y los dos de valor
     * glosado— lo que él cuenta son las filas de antes de descartar, así que su
     * total diría de más. Publicar ese número sería peor que no publicar
     * ninguno: la pantalla prometería páginas que no existen.
     */
    public static <T> PaginaDesplazada<T> filtradaAqui(List<T> elementos, int desplazamiento,
                                                       int tamanoPagina, boolean hayMas) {
        return new PaginaDesplazada<>(elementos, desplazamiento, tamanoPagina,
                                      Optional.empty(), hayMas);
    }

    public static <T> PaginaDesplazada<T> vacia(int tamanoPagina) {
        return new PaginaDesplazada<>(List.of(), 0, tamanoPagina, Optional.of(0L), false);
    }

    /**
     * @return si se puede confiar en el total para calcular cuántas páginas hay.
     *
     * <p>Quien pinte el paginador debe preguntarlo: sin total no se pueden
     * ofrecer números de página, solo «siguiente» y «anterior», y eso es
     * correcto —no un fallo— cuando se filtra por algo que el sistema de
     * registro no sabe resolver.
     */
    public boolean totalEsDeFiar() {
        return total.isPresent();
    }

    /** Cuántas páginas hay, si se sabe. */
    public Optional<Long> totalPaginas() {
        return total.map(t -> tamanoPagina <= 0 ? 1L : (t + tamanoPagina - 1) / tamanoPagina);
    }

    /** En qué página estamos, contando desde cero. */
    public int numeroDePagina() {
        return tamanoPagina <= 0 ? 0 : desplazamiento / tamanoPagina;
    }
}
