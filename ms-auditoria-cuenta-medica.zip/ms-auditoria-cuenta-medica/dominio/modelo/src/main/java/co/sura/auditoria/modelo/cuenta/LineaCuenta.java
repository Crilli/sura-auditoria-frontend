package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Detalle completo de una línea de cuenta médica.
 * Incluye novedades y pendientes de la línea.
 */
public record LineaCuenta(
        ReferenciaLinea referencia,
        CodigoCuenta codigoCuenta,
        int numeroLinea,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si el sistema de registro no lo tiene. */
        String nombreAfiliado,
        String codigoProcedimiento,
        /** Descripción de la prestación; {@code null} si el código no está en el catálogo. */
        String descripcionProcedimiento,
        /** Catálogo del que sale el código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        BigDecimal valorAutorizado,
        BigDecimal unidadesAutorizadas,
        BigDecimal valorCubierto,
        BigDecimal unidadesCubiertas,
        /** Lo que el prestador facturó, antes de valorizar y auditar. */
        BigDecimal valorCargado,
        BigDecimal unidadesCargadas,
        /** Lo descontado en auditoría. El desglose está en {@link #glosas}. */
        BigDecimal valorGlosado,
        /** Texto libre que el auditor dejó al glosar. */
        String observacionesGlosa,
        /** Autorización con la que se prestó el servicio. */
        String codigoAutorizacion,
        /** Prestador que atendió, que puede no ser el que factura. */
        String prestadorAtencionCodigo,
        String prestadorAtencionNombre,
        boolean conservarBeneficios,
        boolean conservarTarifacion,
        boolean beneficiosManuales,
        boolean tarifacionManual,
        boolean bloqueada,
        boolean reemplazada,
        /** Qué se prestó: código, catálogo y descripción. Nunca {@code null}. */
        Prestacion prestacion,
        /** Tarifas y contrato que aplican a la línea. Nunca {@code null}. */
        DatosConvenio convenio,
        /** Sala, vía de acceso, UEN y siniestro. Nunca {@code null}. */
        OtrosDatosLinea otrosDatos,
        List<DiagnosticoLinea> diagnosticos,
        List<DetalleGlosa> glosas,
        List<Novedad> novedades,
        List<MotivoPendiente> pendientes,
        Version version
) {
    public LineaCuenta {
        novedades    = novedades    == null ? List.of() : List.copyOf(novedades);
        pendientes   = pendientes   == null ? List.of() : List.copyOf(pendientes);
        diagnosticos = diagnosticos == null ? List.of() : List.copyOf(diagnosticos);
        glosas       = glosas       == null ? List.of() : List.copyOf(glosas);
        prestacion   = prestacion   == null
                ? new Prestacion(null, null, null, null, null, null, null, null) : prestacion;
        convenio     = convenio     == null
                ? new DatosConvenio(null, null, null, null, null, null, null, null, null) : convenio;
        otrosDatos   = otrosDatos   == null
                ? new OtrosDatosLinea(null, null, null, null) : otrosDatos;
    }

    /** Diagnóstico principal de la línea, si lo hay. */
    public DiagnosticoLinea diagnosticoPrincipal() {
        return diagnosticos.stream()
                .filter(d -> "PRINCIPAL".equalsIgnoreCase(d.tipo()))
                .findFirst()
                .orElse(diagnosticos.isEmpty() ? null : diagnosticos.get(0));
    }

    /** @return {@code true} si la línea puede ser editada por el auditor. */
    public boolean esEditable() {
        return !bloqueada && !reemplazada;
    }

    /** @return {@code true} si hay al menos una novedad bloqueante en la línea. */
    public boolean tieneNovedadBloqueante() {
        return novedades.stream().anyMatch(n -> n.severidad() == Severidad.BLOQUEANTE);
    }

    /** @return mensaje de razón si la línea no es editable; {@code null} si es editable. */
    public String razonNoEditable() {
        if (bloqueada)   return "La línea está bloqueada";
        if (reemplazada) return "La línea fue reemplazada";
        return null;
    }
}
