package co.sura.auditoria.modelo.cuenta;

import java.util.Optional;

/**
 * Por qué pendientes se quiere filtrar: los que bloquean el envío, los que no,
 * o todos.
 *
 * <p>Bloquear no es una propiedad del motivo sino del par motivo-estado, así que
 * este filtro no se puede traducir a una condición fija: hay que preguntárselo
 * al estado de la cuenta. En {@code ADJUDICACION_MANUAL} bloquea todo pendiente
 * sin resolver, y entonces {@link #NO_BLOQUEANTES} no puede casar con nada —hay
 * que decirlo, no devolver una lista vacía sin explicación—. No es un caso raro:
 * de 120 cuentas grandes vivas medidas el 12-oct-2026, 53 estaban en ese estado.
 */
public enum FiltroBloqueo {

    TODOS,
    BLOQUEANTES,
    NO_BLOQUEANTES;

    /**
     * El valor de {@code adjudicationOnly} que hay que exigir para quedarse solo
     * con las filas que pide este filtro.
     *
     * @return vacío si en ese estado el filtro no acota nada — ya sea porque es
     *         {@link #TODOS} o porque el estado hace que todo bloquee
     */
    public Optional<Boolean> soloAdjudicacionExigida(EstadoCuenta estado) {
        if (this == TODOS || estado.todoPendienteBloqueaEnvio()) return Optional.empty();
        // Fuera de adjudicación manual, bloquea exactamente lo que no es de sola
        // adjudicación: el filtro es ese indicador, invertido.
        return Optional.of(this == NO_BLOQUEANTES);
    }

    /**
     * @return {@code true} si en ese estado el filtro no puede casar con ninguna
     *         fila, y por tanto no vale la pena preguntarle a OHI
     */
    public boolean vacioPorDefinicionEn(EstadoCuenta estado) {
        return this == NO_BLOQUEANTES && estado.todoPendienteBloqueaEnvio();
    }
}
