package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

/**
 * Una línea tal como quedó en una versión de la cuenta: una foto, no la línea viva (BUS-21).
 *
 * <h3>Por qué no es un {@link ResumenLinea}</h3>
 * No lleva {@link ReferenciaLinea}, ni {@link Version}, ni nada que diga si se puede editar, y
 * es a propósito. El identificador de la línea de versión no es el de la línea viva —medido el
 * 2026-10-21 en UAT: la misma línea es 37488517725 en la cuenta viva y 44093511586 en su
 * versión—; si esta fila llevara una referencia, una pantalla que reutilizara la grilla viva podría
 * mandarla a guardar contra la cuenta actual. Una foto se lee y nada más: para emparejar una
 * línea de versión con la viva vale el {@link #numeroLinea}, que es el mismo en las dos.
 *
 * <h3>Los importes que faltan son nulos, no cero</h3>
 * Una línea negada no tiene valor convenido ({@code allowedAmount}) —medido: en CM-29939061906
 * V8 ninguna de las 60 lo trae— y eso no es lo mismo que convenir cero; su valor autorizado
 * ({@code coveredAmount}) sí llega, en cero. Lo que el sistema de registro no publica viaja como
 * {@code null} y la pantalla pinta una raya.
 *
 * <h3>Convenido y autorizado</h3>
 * La tabla que fijó negocio el 2026-10-21: {@link #valorConvenido} y {@link #unidadesConvenidas}
 * son {@code allowedAmount} y {@code allowedNumberOfUnits}; {@link #valorAutorizado} y
 * {@link #unidadesAutorizadas} son {@code coveredAmount} y {@code coveredNumberOfUnits}. Hasta
 * ese día el primer par se llamaba «autorizado» y el segundo «cubierto».
 *
 * @param numeroLinea el número que ve el auditor ({@code sequence}). No es correlativo: en
 *                    CM-29939061906 van 1, 127, 128…
 * @param estado      el desenlace de la línea en esa versión con el nombre del dominio
 *                    ({@link EstadoLinea#APROBADA}, {@link EstadoLinea#NEGADA}); si el histórico
 *                    trae una palabra que no se conoce, esa palabra tal cual; {@code null} si no
 *                    trae ninguna
 * @param nombreAfiliado lo que el histórico guarda del afiliado, que es <b>solo el primer
 *                    apellido</b> («Vera»): no hay identificador con el que resolver el nombre
 *                    completo contra el padrón
 * @param glosas      el desglose de lo glosado en esa versión, ordenado por su secuencia
 */
public record LineaDeVersion(
        int numeroLinea,
        String estado,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        String codigoProcedimiento,
        String descripcionProcedimiento,
        String catalogoProcedimiento,
        String codigoAfiliado,
        String nombreAfiliado,
        String codigoAutorizacion,
        String prestadorCodigo,
        String prestadorNombre,
        BigDecimal valorCargado,
        BigDecimal unidadesCargadas,
        BigDecimal valorConvenido,
        BigDecimal unidadesConvenidas,
        BigDecimal valorAutorizado,
        BigDecimal unidadesAutorizadas,
        BigDecimal valorGlosado,
        BigDecimal valorIva,
        BigDecimal porcentajeIva,
        List<GlosaDeVersion> glosas
) {

    public LineaDeVersion {
        glosas = glosas == null ? List.of()
                : glosas.stream()
                        .sorted(Comparator.comparing(GlosaDeVersion::secuencia,
                                                     Comparator.nullsLast(Comparator.naturalOrder())))
                        .toList();
    }

    /**
     * Una glosa del desglose, tal como quedó en la versión.
     *
     * <p>Comparada con {@link DetalleGlosa} —la de la línea viva— no tiene identificador que
     * sirva para editarla y sí tiene su secuencia y su tipo: el histórico publica
     * {@code numeroSecuencia} y {@code descripcionTipoGlosa}, y no publica la clasificación por
     * código.
     *
     * @param concepto           la clasificación de primer nivel en palabras («Tarifas»,
     *                           «Autorizaciones»); vacía en muchas cuentas del entorno de pruebas
     * @param conceptoEspecifico la de segundo nivel («Procedimiento o actividad»)
     * @param texto              la redacción que ve el prestador
     * @param tipo               cómo se puso la glosa, en palabras del sistema de registro
     */
    public record GlosaDeVersion(
            Integer secuencia,
            String codigo,
            BigDecimal valor,
            String codigoNotaCredito,
            BigDecimal valorNotaCredito,
            String concepto,
            String conceptoEspecifico,
            String texto,
            String tipo
    ) {}
}
