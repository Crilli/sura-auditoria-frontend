package co.sura.auditoria.modelo.error;

/**
 * Jerarquía sellada de errores de dominio.
 *
 * <p>Cada variante encapsula el contexto necesario para que la capa de presentación
 * traduzca el error a la respuesta HTTP adecuada. El {@code switch} sobre esta
 * interfaz sellada es exhaustivo: agregar una variante sin traducirla rompe la compilación.
 *
 * <p>Equivalencias con códigos de OHI (solo relevantes en la ACL):
 * <ul>
 *   <li>{@link PendientesBloqueanEnvio} ← {@code 409 CLA-CLAI-035}</li>
 *   <li>{@link SinPermiso} ← {@code 403 CLA-IP-CLAI-023}</li>
 *   <li>{@link AccionNoDisponible} ← {@code CLA-IP-CLAI-024, CLA-IP-SUBC-001}</li>
 *   <li>{@link DecisionEnvioInvalida} ← {@code CLA-IP-SBMT-001..004}</li>
 * </ul>
 */
public sealed interface ErrorDeDominio {

    record CuentaNoEncontrada(String codigoCuenta) implements ErrorDeDominio {}

    record LineaNoEncontrada(long referencia) implements ErrorDeDominio {}

    /** El sistema de registro no habilita esta acción para la cuenta en su estado actual. */
    record AccionNoDisponible(String codigoCuenta, String accion) implements ErrorDeDominio {}

    record PendientesBloqueanEnvio(String codigoCuenta, int cantidad) implements ErrorDeDominio {}

    /**
     * La cuenta no está en modificación, el único estado en que se cambian sus datos
     * (regla de negocio del 2026-10-21, ver {@code EstadoCuenta#admiteCambiosDeDatos}).
     *
     * <p>Es de la familia de {@link AccionNoDisponible} —«no en su estado actual»— y no de
     * {@link LineaNoEditable}: el problema es de la cuenta y el remedio también, pasarla a
     * modificación. Mezclarlo con lo de la línea dejaría al auditor sin saber qué hacer.
     *
     * <p>Lleva el estado como texto, igual que {@link AccionNoDisponible} lleva la acción, para
     * que esta jerarquía no dependa del modelo de la cuenta.
     *
     * @param estado el nombre del estado en el dominio ({@code ADJUDICACION_MANUAL}); quien lo
     *               traduzca lo pone en palabras
     */
    record CuentaNoModificable(String codigoCuenta, String estado) implements ErrorDeDominio {}

    record ModificacionConcurrente(String recurso, long versionEsperada) implements ErrorDeDominio {}

    record SinPermiso(String operacion, String detalle) implements ErrorDeDominio {}

    record LimiteAprobacionExcedido(String codigoCuenta) implements ErrorDeDominio {}

    record LineaNoEditable(long referencia, String razon) implements ErrorDeDominio {}

    record DecisionEnvioInvalida(String detalle) implements ErrorDeDominio {}

    record EdicionSinCambios(long referencia) implements ErrorDeDominio {}

    record SistemaRegistroNoDisponible(String detalle) implements ErrorDeDominio {}

    /**
     * Una línea concreta de un cambio en lote que el sistema de registro rechazó.
     *
     * <h3>Por qué lleva el índice y no la referencia</h3>
     * Porque es lo que el sistema de registro informa. Medido el 2026-10-17 contra el entorno
     * de pruebas: un parche de varias líneas con una inválida responde <b>422 y no aplica
     * nada</b> —el parche es atómico— y el error trae
     * {@code "o:errorPath": "$.claimLineList[1]"}, que señala la <b>posición</b> dentro del
     * parche enviado. Traducirla a una referencia es cosa de quien armó el parche y sabe en
     * qué orden lo mandó; hacerlo en la capa de integración obligaría a pasarle la lista.
     *
     * <p>Que el parche sea atómico es lo que hace necesario este error: sin él, un lote con
     * una línea mala se quedaría en «falló todo» y habría que reintentarlo a ciegas una por
     * una. Con él se sabe cuál quitar y se reintenta el resto de una vez.
     *
     * @param indice posición de la línea dentro del parche, empezando en cero
     */
    record LineaDelLoteRechazada(int indice, String detalle) implements ErrorDeDominio {}

    /**
     * El sistema de registro aplicó la escritura, pero no se pudo releer el resultado (OPE-11).
     *
     * <p>No es un fallo de la escritura y no se puede tratar como tal: decir «no se pudo» haría
     * que el auditor la repitiera sobre algo que ya cambió. Quien lo reciba debe recargar.
     *
     * @param recurso lo que se escribió, para el mensaje (p. ej. {@code "linea:148111592284"})
     * @param detalle por qué falló la relectura
     */
    record AplicadoSinRelectura(String recurso, String detalle) implements ErrorDeDominio {}
}
