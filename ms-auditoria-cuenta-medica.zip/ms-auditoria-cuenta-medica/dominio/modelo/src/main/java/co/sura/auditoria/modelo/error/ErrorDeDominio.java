package co.sura.auditoria.modelo.error;

/**
 * Jerarquía sellada de errores de dominio.
 *
 * <p>Cada variante encapsula el contexto necesario para que la capa de presentación
 * traduzca el error a la respuesta HTTP adecuada. El {@code switch} sobre esta
 * interfaz sellada es exhaustivo: agregar una variante sin traducirla rompe la compilación.
 *
 * <p>Equivalencias con códigos de OHI (solo relevantes en la ACL):
 * <ul>
 *   <li>{@link PendientesBloqueanEnvio} ← {@code 409 CLA-CLAI-035}</li>
 *   <li>{@link SinPermiso} ← {@code 403 CLA-IP-CLAI-023}</li>
 *   <li>{@link AccionNoDisponible} ← {@code CLA-IP-CLAI-024, CLA-IP-SUBC-001}</li>
 *   <li>{@link DecisionEnvioInvalida} ← {@code CLA-IP-SBMT-001..004}</li>
 * </ul>
 */
public sealed interface ErrorDeDominio {

    record CuentaNoEncontrada(String codigoCuenta) implements ErrorDeDominio {}

    record LineaNoEncontrada(long referencia) implements ErrorDeDominio {}

    /** El sistema de registro no habilita esta acción para la cuenta en su estado actual. */
    record AccionNoDisponible(String codigoCuenta, String accion) implements ErrorDeDominio {}

    record PendientesBloqueanEnvio(String codigoCuenta, int cantidad) implements ErrorDeDominio {}

    record ModificacionConcurrente(String recurso, long versionEsperada) implements ErrorDeDominio {}

    record SinPermiso(String operacion, String detalle) implements ErrorDeDominio {}

    record LimiteAprobacionExcedido(String codigoCuenta) implements ErrorDeDominio {}

    record LineaNoEditable(long referencia, String razon) implements ErrorDeDominio {}

    record DecisionEnvioInvalida(String detalle) implements ErrorDeDominio {}

    record EdicionSinCambios(long referencia) implements ErrorDeDominio {}

    record SistemaRegistroNoDisponible(String detalle) implements ErrorDeDominio {}
}
