package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.auditoria.EventoAuditoria;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** Puerto de persistencia de la traza de auditoría (R2DBC). */
public interface RepositorioTrazaAuditoria {

    /** Persiste un evento de auditoría. */
    Mono<EventoAuditoria> guardar(EventoAuditoria evento);

    /**
     * Busca los eventos más recientes de una cuenta.
     *
     * @param limite número máximo de eventos a retornar
     */
    Flux<EventoAuditoria> buscarPorCuenta(String codigoCuenta, int limite);
}
