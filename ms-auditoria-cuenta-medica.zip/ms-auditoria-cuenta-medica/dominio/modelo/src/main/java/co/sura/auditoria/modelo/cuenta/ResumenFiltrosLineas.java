package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Con qué se puede acotar el listado de <b>esta</b> cuenta, ya contado.
 *
 * <p>Existe por lo mismo que el agregado de motivos pendientes: el listado se
 * pagina, así que el cliente nunca ve la cuenta entera y no puede deducir de la
 * página qué afiliados hay ni qué catálogos aparecen. Si las opciones se
 * sacaran de las veinticinco filas a la vista, el filtro ofrecería un afiliado y
 * escondería los otros, que es peor que no ofrecer el filtro.
 *
 * <p>Se calcula recorriendo la cuenta una vez con la proyección estrecha, y
 * viaja como un puñado de filas aunque la cuenta tenga miles de líneas.
 *
 * @param afiliados       los afiliados distintos de la cuenta, con cuántas
 *                        líneas tiene cada uno. Casi siempre es uno —de 40
 *                        cuentas revisadas en producción el 13-oct-2026 ninguna
 *                        tenía más de uno—, pero el negocio admite cuentas
 *                        multiafiliado y por eso es una lista
 * @param catalogos       los catálogos de prestación presentes, ya agrupados:
 *                        los diecisiete códigos propios de prestador distintos
 *                        que hay en producción colapsan en un solo
 *                        {@link CatalogoPrestacion#PROPIO}
 * @param primeraAtencion fecha de atención más temprana; {@code null} si ninguna
 *                        línea la trae
 * @param ultimaAtencion  fecha de atención más tardía
 * @param glosaMaxima     mayor valor glosado de la cuenta; {@code null} si
 *                        ninguna línea tiene glosa
 * @param lineasConGlosa  cuántas líneas tienen glosa mayor que cero. Es la
 *                        pregunta que de verdad se hace el auditor —«¿qué está
 *                        glosado?»— y permite ofrecerla sin que tenga que
 *                        inventarse un rango
 * @param totalLineas     líneas recorridas, para poder decir sobre cuántas se
 *                        calculó todo esto
 */
public record ResumenFiltrosLineas(List<AfiliadoConLineas> afiliados,
                                   List<CatalogoConLineas> catalogos,
                                   LocalDate primeraAtencion,
                                   LocalDate ultimaAtencion,
                                   BigDecimal glosaMaxima,
                                   int lineasConGlosa,
                                   int totalLineas) {

    public ResumenFiltrosLineas {
        afiliados = afiliados == null ? List.of() : List.copyOf(afiliados);
        catalogos = catalogos == null ? List.of() : List.copyOf(catalogos);
    }

    /** Vacío: la cuenta no tiene líneas, o no se pudo recorrer. */
    public static ResumenFiltrosLineas vacio() {
        return new ResumenFiltrosLineas(List.of(), List.of(), null, null, null, 0, 0);
    }

    /**
     * @param cedula el documento tal como lo publica el sistema de registro
     * @param nombre nombre del afiliado; {@code null} si no se pudo resolver
     */
    public record AfiliadoConLineas(String cedula, String nombre, int lineas) {}

    public record CatalogoConLineas(CatalogoPrestacion catalogo, int lineas) {}

    /** La cuenta tiene más de un afiliado: el caso multiafiliado de verdad. */
    public boolean esMultiafiliado() {
        return afiliados.size() > 1;
    }

    /** Ninguna línea tiene glosa, así que filtrar por ella solo daría vacío. */
    public boolean sinGlosas() {
        return lineasConGlosa == 0;
    }
}
