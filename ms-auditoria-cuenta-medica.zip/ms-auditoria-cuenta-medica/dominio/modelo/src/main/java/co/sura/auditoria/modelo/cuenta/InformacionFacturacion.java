package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Información de facturación y radicación de la cuenta médica.
 *
 * <p>Es la ficha administrativa con la que el prestador radica la cuenta: quién
 * factura, con qué número, cuándo se prestó y cuándo vence el pago. Se agrupa
 * aparte de los campos operativos de {@link CuentaMedica} (estado, totales de
 * auditoría) porque describe el trámite documental, no el resultado de la
 * auditoría.
 *
 * <p>{@code totalAutorizado} ya vive en {@link CuentaMedica}; no se repite aquí
 * para no tener dos fuentes del mismo dato.
 *
 * <p>{@code totalConvenido} queda siempre en {@code null}: el sistema de registro
 * no expone una tarifa convenida a nivel de cuenta en su modelo actual. El campo
 * se conserva en el dominio para cuando exista esa fuente.
 */
public record InformacionFacturacion(
        /** NIT (con sucursal) del prestador que radica la factura. */
        String prestadorFacturacionNit,
        String numeroFactura,
        /** Código de negocio con el que el auditor identifica la cuenta; es el radicado. */
        String numeroRadicado,
        LocalDate fechaRadicacion,
        LocalDate fechaEmision,
        LocalDate fechaVencimiento,
        LocalDate fechaIngreso,
        LocalDate fechaEgreso,
        BigDecimal valorFactura,
        BigDecimal valorTotalFactura,
        BigDecimal totalCargado,
        /** Sin fuente en el sistema de registro actual; ver javadoc de la clase. */
        BigDecimal totalConvenido,
        BigDecimal totalValorGlosado,
        BigDecimal valorNotaCredito,
        String tipoServicio,
        String acuseRecibido,
        String marcaRadicadoAtep,
        String marcaMulticore,
        String marcaPendienteManual,
        String observacionesInternas,
        String observacionesExternas,
        /** NIT (con sucursal) del prestador al que se le paga; puede diferir del que factura. */
        String pagarAPrestadorNit
) {
    private static final InformacionFacturacion VACIA = new InformacionFacturacion(
            null, null, null, null, null, null, null, null,
            null, null, null, null, null, null,
            null, null, null, null, null, null, null, null);

    /** Instancia sin datos: todos los campos en {@code null}. */
    public static InformacionFacturacion vacia() {
        return VACIA;
    }
}
