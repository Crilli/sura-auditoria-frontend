package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Información de facturación y radicación de la cuenta médica.
 *
 * <p>Es la ficha administrativa con la que el prestador radica la cuenta: quién
 * factura, con qué número, cuándo se prestó y cuándo vence el pago. Se agrupa
 * aparte de los campos operativos de {@link CuentaMedica} (estado, totales de
 * auditoría) porque describe el trámite documental, no el resultado de la
 * auditoría.
 *
 * <p>El total convenido y el total autorizado viven en {@link CuentaMedica} y no se
 * repiten aquí, para no tener dos fuentes del mismo dato. Aquí hubo un
 * {@code totalConvenido} que iba siempre en {@code null} («sin fuente»); se quitó el
 * 2026-10-21, cuando negocio fijó que el convenido es {@code totalAllowedAmount}: dejarlo
 * habría publicado dos «total convenido», uno con cifra y otro vacío.
 */
public record InformacionFacturacion(
        /** NIT (con sucursal) del prestador que radica la factura. */
        String prestadorFacturacionNit,
        /**
         * Razón social del que factura. Puede ser {@code null}: el NIT viene de la cuenta y
         * el nombre del padrón de prestadores, que es otra consulta y puede no tenerlo.
         * Un nombre que falta no invalida la cabecera; el NIT sigue ahí.
         */
        String prestadorFacturacionNombre,
        String numeroFactura,
        /** Código de negocio con el que el auditor identifica la cuenta; es el radicado. */
        String numeroRadicado,
        LocalDate fechaRadicacion,
        LocalDate fechaEmision,
        LocalDate fechaVencimiento,
        LocalDate fechaIngreso,
        LocalDate fechaEgreso,
        BigDecimal valorFactura,
        BigDecimal valorTotalFactura,
        BigDecimal totalCargado,
        BigDecimal totalValorGlosado,
        BigDecimal valorNotaCredito,
        String tipoServicio,
        String acuseRecibido,
        String marcaRadicadoAtep,
        String marcaMulticore,
        String marcaPendienteManual,
        String observacionesInternas,
        String observacionesExternas,
        /** NIT (con sucursal) del prestador al que se le paga; puede diferir del que factura. */
        String pagarAPrestadorNit,
        /** Razón social del que cobra. Ver {@link #prestadorFacturacionNombre}. */
        String pagarAPrestadorNombre
) {
    private static final InformacionFacturacion VACIA = new InformacionFacturacion(
            null, null, null, null, null, null, null, null,
            null, null, null, null, null, null,
            null, null, null, null, null, null, null, null, null);

    /** Instancia sin datos: todos los campos en {@code null}. */
    public static InformacionFacturacion vacia() {
        return VACIA;
    }
}
