package co.sura.auditoria.modelo.cuenta;

/**
 * Un motivo del catálogo de pendientes, para poder elegirlo.
 *
 * <h3>Tres cosas que se llaman parecido y no son lo mismo</h3>
 * <ul>
 *   <li>este, que es el <b>catálogo</b>: los motivos que existen;</li>
 *   <li>{@link MotivoPendiente}, que es una fila <b>puesta</b> en una cuenta concreta;</li>
 *   <li>{@link ResumenMotivoPendiente}, que es el agregado de una cuenta.</li>
 * </ul>
 * Y un cuarto que tampoco: el catálogo de <b>desfinalización</b>, que se publica en
 * {@code /catalogos/motivos} y no tiene nada que ver con esto.
 *
 * @param soloAdjudicacion el {@code adjudicationOnly} del sistema de registro. No se traduce a
 *                         «bloqueante» aquí a propósito: bloquear depende del par motivo-estado
 *                         y el catálogo no conoce ninguna cuenta. Ver {@link EstadoCuenta}
 */
public record MotivoPendienteCatalogo(String codigo, String descripcion,
                                      boolean soloAdjudicacion) {

    public MotivoPendienteCatalogo {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("Un motivo del catálogo necesita su código");
        }
    }

    /** Lo que se lee en el selector: el texto si lo hay, y si no el código. */
    public String etiqueta() {
        return descripcion == null || descripcion.isBlank() ? codigo : descripcion;
    }
}
