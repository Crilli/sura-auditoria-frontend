package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.DetalleLineaDeVersion;
import co.sura.auditoria.modelo.cuenta.LineaDeVersion;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import reactor.core.publisher.Mono;

/**
 * Las líneas de una versión de la cuenta: lo que se auditó en ella (BUS-21).
 *
 * <p>Va aparte de {@link PuertoConsultaCuentas} —las líneas de la cuenta viva— porque es otro
 * recurso del sistema de registro, con otra forma y de solo lectura: aquí no hay referencias que
 * editar, ni pendientes, ni versión de bloqueo. Y aparte de {@link PuertoBusquedaCuentas}, que
 * responde «cuáles hay»: esto responde «qué tenía esta versión», y crecerá por su lado.
 *
 * <p>Una versión es una fila del histórico de lo transmitido identificada por código y número,
 * sin su gemela de reversión (BUS-20). Solo existen las versiones finalizadas: la que una cuenta
 * reabierta está trabajando es la cuenta viva y aquí no está.
 */
public interface PuertoLineasDeVersion {

    /**
     * Una página de las líneas de la versión, en el orden del número de línea.
     *
     * @return vacío si la versión no está en el histórico; una página sin elementos y con total
     *         cero si está y no tiene líneas —medido el 2026-10-21: las madres de large claim
     *         tienen versiones con importes y sin una sola línea—
     */
    Mono<PaginaDesplazada<LineaDeVersion>> lineasDeVersion(CodigoCuenta codigo, int numero,
                                                           int desplazamiento, int tamanoPagina);

    /**
     * Una línea de la versión con todo lo que se auditó en ella.
     *
     * @return vacío si esa versión no tiene esa línea, <b>o si la versión no existe</b>: para
     *         distinguirlo está {@link #existeVersion}, que solo hace falta preguntar entonces
     */
    Mono<DetalleLineaDeVersion> detalleDeLinea(CodigoCuenta codigo, int numero, int numeroLinea);

    /** Si la versión está en el histórico de lo transmitido. */
    Mono<Boolean> existeVersion(CodigoCuenta codigo, int numero);
}
