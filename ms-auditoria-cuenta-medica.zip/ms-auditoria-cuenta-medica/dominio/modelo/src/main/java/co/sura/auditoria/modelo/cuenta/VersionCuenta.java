package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

/**
 * Una versión de negocio de una cuenta médica.
 *
 * <h3>Qué es una «versión», y qué no</h3>
 * <b>No</b> es el {@code objectVersionNumber} que la cabecera enseña hoy con el rótulo
 * «Versión»: aquél es el contador de bloqueo optimista, sube con cada escritura y no significa
 * nada para el auditor. Esta es la versión del documento transmitido: cada vez que la cuenta se
 * desfinaliza y vuelve a cerrarse, nace una nueva.
 *
 * <h3>Las dos reglas que hay que respetar al leerlas</h3>
 * Medido el 2026-10-17 contra el entorno de pruebas sobre {@code CM-57944424433}, que tiene
 * cinco filas y <b>tres</b> versiones:
 * <ul>
 *   <li>cada versión tiene una <b>gemela de reversión</b> ({@code reversal = true}) salvo la
 *       última. Contarlas todas daría cinco versiones donde hay tres, y los importes saldrían
 *       duplicados;</li>
 *   <li>el estado vive en {@code ctrStatusHistoryList} y <b>viene desordenado</b>: el de la
 *       versión es el de la fecha más reciente, no el primero de la lista. Y está en español
 *       —«Finalizado», «Pendiente»— mientras que {@code claims.status} está en inglés. El mismo
 *       estado se escribe distinto según dónde se mire, y por eso el adaptador lo traduce al mismo
 *       nombre del dominio que el de la cuenta.</li>
 * </ul>
 *
 * @param numero    el número de versión del sistema de registro, empezando en 1
 * @param valor     el valor de la factura <b>en esa versión</b>: cambia entre versiones
 *                  —medido: 4.000.001 → 6.000.000 → 8.800.000—, que es justo lo que se quiere ver
 * @param estado    el estado de la versión con el mismo nombre del dominio que el de la cuenta
 *                  viva (FINALIZADA, ADJUDICACION_MANUAL…); si el histórico trae una palabra que
 *                  no se conoce, esa palabra tal cual
 */
public record VersionCuenta(CodigoCuenta codigo, int numero, LocalDate fechaEntrada,
                            BigDecimal valor, String estado, Instant estadoDesde) {

    /**
     * La vigente de un conjunto: la de mayor número.
     *
     * <p>Quien llame debe haber descartado ya las filas de reversión; si no, el máximo podría
     * salir de una gemela. Es lo que hace {@code AdaptadorVersionesOhi}.
     *
     * @return vacío si no hay ninguna, que es el caso de una cuenta que aún no se transmitió
     */
    public static java.util.Optional<VersionCuenta> vigente(List<VersionCuenta> versiones) {
        if (versiones == null) return java.util.Optional.empty();
        return versiones.stream().max(Comparator.comparingInt(VersionCuenta::numero));
    }
}
