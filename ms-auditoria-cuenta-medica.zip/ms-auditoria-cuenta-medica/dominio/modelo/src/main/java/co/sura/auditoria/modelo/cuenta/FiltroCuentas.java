package co.sura.auditoria.modelo.cuenta;

/**
 * Por qué buscar una cuenta médica cuando todavía no se sabe su radicado.
 *
 * <h3>El filtro que no se pide y siempre viaja</h3>
 * El universo del sistema de registro no son cuentas médicas: son cuentas <b>y reservas</b>, y
 * las reservas son mayoría —medido el 2026-10-17 en el entorno de pruebas: 11.395 cuentas
 * frente a 66.223 reservas, el 85 %—. Una búsqueda sin acotar el tipo de proceso devolvería
 * sobre todo cosas que el auditor no está buscando, sin ningún aviso. Por eso el tipo no es un
 * criterio opcional de este filtro sino una condición que la capa de integración añade
 * siempre; ver {@code AdaptadorBusquedaCuentasOhi}.
 *
 * @param numeroFactura número de factura, exacto. Una misma factura puede estar radicada
 *                      varias veces —medido: JONATHAN201 tiene tres cuentas— y eso no es un
 *                      error del dato: es lo que el auditor necesita ver
 * @param radicado      consecutivo de la cuenta médica; busca por <b>prefijo</b>, porque quien
 *                      lo teclea suele tener solo el principio
 */
public record FiltroCuentas(String numeroFactura, String radicado) {

    public FiltroCuentas {
        numeroFactura = enBlancoEsNada(numeroFactura);
        radicado      = enBlancoEsNada(radicado);
    }

    private static String enBlancoEsNada(String valor) {
        if (valor == null) return null;
        var limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    /**
     * Si no hay por dónde empezar.
     *
     * <p>Buscar sin criterio devolvería las once mil cuentas del entorno, página a página.
     * No es un error del sistema de registro —responde— pero tampoco es una búsqueda: quien
     * llame debe negarse antes de salir.
     */
    public boolean vacio() {
        return numeroFactura == null && radicado == null;
    }
}
