package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.*;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Puerto de comandos sobre la cuenta médica.
 * Solo operaciones que <em>modifican</em> el estado (Command side de CQRS).
 *
 * <p><b>Los comandos NO se reintentan</b> (ADR-004): modificar una línea con
 * recálculo en cascada reintentado tras un timeout puede recalcular dos veces.
 */
public interface PuertoComandosCuenta {

    /**
     * Aplica las ediciones de una o varias líneas a la cuenta.
     *
     * @param versionCuenta versión de la cabecera para el control de concurrencia
     * @param ediciones     ediciones a aplicar (al menos una)
     * @return la línea actualizada tras la operación
     */
    Mono<LineaCuenta> aplicarEdicionesDeLinea(CodigoCuenta codigo, Version versionCuenta,
                                              List<EdicionLinea> ediciones);

    /**
     * Inicia el envío de la cuenta al sistema de registro.
     * El proceso es asíncrono: se devuelve un tiquete de seguimiento.
     *
     * @param version  versión de la cabecera para el control de concurrencia
     * @param decision ACEPTAR o DENEGAR con el código de novedad correspondiente
     */
    Mono<TiqueteProceso> enviar(CodigoCuenta codigo, Version version, DecisionEnvio decision);
}
