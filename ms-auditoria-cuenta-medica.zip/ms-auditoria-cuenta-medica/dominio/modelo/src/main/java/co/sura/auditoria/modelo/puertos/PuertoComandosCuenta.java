package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.*;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Puerto de comandos sobre la cuenta médica.
 * Solo operaciones que <em>modifican</em> el estado (Command side de CQRS).
 *
 * <p><b>Los comandos NO se reintentan</b> (ADR-004): modificar una línea con
 * recálculo en cascada reintentado tras un timeout puede recalcular dos veces.
 */
public interface PuertoComandosCuenta {

    /**
     * Aplica las ediciones de una o varias líneas a la cuenta.
     *
     * @param versionCuenta versión de la cabecera para el control de concurrencia
     * @param ediciones     ediciones a aplicar (al menos una)
     * @return la línea actualizada tras la operación
     */
    Mono<LineaCuenta> aplicarEdicionesDeLinea(CodigoCuenta codigo, Version versionCuenta,
                                              List<EdicionLinea> ediciones);

    /**
     * Inicia el envío de la cuenta al sistema de registro.
     * El proceso es asíncrono: se devuelve un tiquete de seguimiento.
     *
     * @param version  versión de la cabecera para el control de concurrencia
     * @param decision ACEPTAR o DENEGAR con el código de novedad correspondiente
     */
    Mono<TiqueteProceso> enviar(CodigoCuenta codigo, Version version, DecisionEnvio decision);

    /**
     * Aplica altas y bajas de novedad sobre la <b>cabecera</b> de la cuenta.
     *
     * <p>Va aparte de {@link #aplicarEdicionesDeLinea} y no como un caso suyo:
     * son dos colecciones distintas del sistema de registro
     * —{@code claimMessageList} cuelga de la cuenta, {@code claimLineMessageList}
     * de la línea— y mezclarlas obligaría a inventar una edición de línea vacía
     * para poder tocar la cabecera.
     *
     * <p>Sin modo de recálculo, al contrario que la edición de línea: una
     * novedad de cabecera no mueve ningún importe, así que no hay nada que
     * recalcular.
     *
     * @param version la de la cuenta, para el bloqueo optimista
     * @return la cuenta releída, con sus novedades ya actualizadas
     */
    Mono<CuentaMedica> aplicarCambiosDeNovedadDeCabecera(CodigoCuenta codigo, Version version,
                                               List<CambioNovedad> cambios);

    /**
     * Ejecuta una de las acciones que el sistema de registro habilita sobre la
     * cuenta: anularla, devolverla a modificación, revertir su finalización,
     * desbloquear sus líneas…
     *
     * <p><b>Una sola operación para las nueve</b>, y no una por acción: ver el
     * porqué en {@link EjecucionAccion}. Quedan fuera {@link #enviar}, que es la
     * única que no es síncrona —arranca un proceso y devuelve un tiquete— y el
     * seguimiento del proceso, que es de lectura.
     *
     * <p>Sin versión esperada: estas operaciones no parchean el contenido de la
     * cuenta sino que la mueven de estado, y su contrato no tiene bloqueo
     * optimista. Si el estado ya no admite la acción, el sistema de registro
     * responde con un conflicto.
     *
     * @return la cuenta releída: al cambiar de estado cambian también las
     *     acciones que quedan habilitadas
     */
    Mono<CuentaMedica> ejecutarAccion(CodigoCuenta codigo, EjecucionAccion ejecucion);
}
