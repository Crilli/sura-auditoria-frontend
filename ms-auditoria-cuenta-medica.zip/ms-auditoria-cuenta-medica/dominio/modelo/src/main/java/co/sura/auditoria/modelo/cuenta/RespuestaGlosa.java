package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una respuesta del prestador a las glosas de la cuenta.
 *
 * <h3>Qué es y qué no</h3>
 * Es lo que el prestador contesta cuando se le glosa: llega con fecha, un importe y un plazo.
 * <b>Solo se lee</b> —así se decidió el alcance del MVP—, de modo que aquí no hay nada que
 * validar ni que escribir.
 *
 * <p>Medido el 2026-10-17 contra el entorno de pruebas: {@code claims.respuestaGlosa} existe y
 * viene poblada, con {@code fechaLlegada}, {@code numeroSecuencia}, {@code versionamiento},
 * {@code valor} y {@code fechaVencimiento}. Una cuenta puede tener varias: la medida tenía dos,
 * de junio y de noviembre.
 *
 * @param secuencia     el orden en que llegaron, tal como lo numera el sistema de registro
 * @param versionAbierta la versión de la cuenta que esta respuesta abrió, con la forma
 *                      {@code CM-94421-V4}. Es el dato de VIS-11, y <b>no hace falta consultar
 *                      {@code ctrclaims} para tenerlo</b>: viene en la misma respuesta
 * @param valor         el importe respondido
 * @param fechaLlegada  cuándo entró
 * @param fechaVencimiento hasta cuándo hay para resolverla
 */
public record RespuestaGlosa(String secuencia,
                             String versionAbierta,
                             BigDecimal valor,
                             LocalDate fechaLlegada,
                             LocalDate fechaVencimiento) {

    /**
     * Si el plazo ya pasó, medido contra el día que se indique.
     *
     * <p>La fecha de referencia se recibe y no se toma del reloj: así la respuesta de una
     * consulta es la misma se pida cuando se pida, y la prueba no depende de qué día corra.
     *
     * @return {@code false} si no hay vencimiento: no se puede afirmar que algo venció sin saber cuándo
     */
    public boolean vencida(LocalDate hoy) {
        return fechaVencimiento != null && hoy != null && fechaVencimiento.isBefore(hoy);
    }
}
