package co.sura.auditoria.modelo.cuenta;

import java.util.List;

/**
 * El mismo cambio, sobre varias líneas.
 *
 * <h3>Qué se puede repetir y qué no</h3>
 * Solo lo que tiene sentido idéntico en todas: el desglose de glosa y las novedades. <b>No</b>
 * los importes de la línea —valor autorizado, unidades, valor cargado—, que son propios de cada
 * una: aplicar «38.222» a veinte líneas distintas no es una operación masiva sino veinte errores.
 * Por eso este tipo no es un {@link EdicionLinea} con una lista de referencias pegada: es un
 * subconjunto deliberado.
 *
 * <p>El valor glosado tampoco viaja, por la misma razón de siempre: el total de una línea es la
 * suma de su desglose y se calcula contra el desglose que esa línea tenga hoy, que no es el mismo
 * en todas.
 *
 * @param seleccion     sobre qué líneas. Nunca {@link SeleccionLineas#TODAS}: ver el javadoc
 * @param glosas        altas y bajas del desglose, iguales para todas
 * @param novedades     altas y bajas de novedad, iguales para todas
 * @param modoRecalculo si el motor recalcula tras aplicar
 */
public record CambiosEnLote(SeleccionLineas seleccion,
                            List<CambioGlosa> glosas,
                            List<CambioNovedad> novedades,
                            ModoRecalculo modoRecalculo) {

    /**
     * Tope de líneas por operación.
     *
     * <p>No sale de un límite publicado por el sistema de registro —no publica ninguno— sino de
     * dos cosas medidas: el cuerpo crece con cada línea, y el recálculo de una cuenta grande ya
     * es la parte lenta de la petición. Un tope obliga a que tocar media cuenta sea una decisión
     * repetida en vez de un clic.
     */
    public static final int MAXIMO_LINEAS = 500;

    public CambiosEnLote {
        glosas    = glosas == null ? List.of() : List.copyOf(glosas);
        novedades = novedades == null ? List.of() : List.copyOf(novedades);
        // Sin valor por omisión, igual que en la edición de una línea: el modo tiene impacto
        // financiero —en cascada propaga tarifación, coberturas y consumos a toda la cuenta—
        // y elegirlo por el auditor sería tomar su decisión. Y aquí pesa más, porque multiplica.
        if (modoRecalculo == null) {
            throw new IllegalArgumentException(
                    "Hay que decir si el motor recalcula: en un lote la decisión se multiplica "
                    + "por el número de líneas");
        }

        if (seleccion == null || seleccion.esTodaLaCuenta()) {
            throw new IllegalArgumentException(
                    "Un cambio en lote necesita las líneas, una a una. «Todas las de la cuenta» no "
                    + "es un alcance válido aquí: habría que enumerarlas, y el tope existe por algo.");
        }
        if (seleccion.cuantas() > MAXIMO_LINEAS) {
            throw new IllegalArgumentException(
                    "No se pueden cambiar más de %d líneas en una operación; se pidieron %d"
                            .formatted(MAXIMO_LINEAS, seleccion.cuantas()));
        }
        if (glosas.isEmpty() && novedades.isEmpty()) {
            throw new IllegalArgumentException(
                    "El lote no cambia nada: no lleva ni glosas ni novedades");
        }
    }

    public boolean tocaGlosas()    { return !glosas.isEmpty(); }
    public boolean tocaNovedades() { return !novedades.isEmpty(); }

    /** La edición concreta para una línea, con la versión que esa línea tiene ahora. */
    public EdicionLinea paraLinea(LineaCuenta linea) {
        return EdicionLinea.soloCambiosDeColeccion(
                linea.referencia(), linea.version(), glosas, novedades, modoRecalculo);
    }

    /**
     * Lo que de verdad falta hacer en una línea, o vacío si ya está como se pide (OPE-12).
     *
     * <h3>Por qué</h3>
     * La versión que lleva la edición es la de la línea recién leída, así que el bloqueo
     * optimista no frena un lote repetido: tras un corte, reintentarlo volvía a añadir las
     * glosas, y con el valor glosado como suma del desglose la línea quedaba descuadrada. Como
     * la línea ya está leída, comparar con lo que tiene no cuesta ninguna llamada y vale igual
     * desde cualquier réplica.
     *
     * <h3>Qué se considera «ya está»</h3>
     * <ul>
     *   <li>alta de glosa: la línea ya tiene una con el <b>mismo código y el mismo valor</b>.
     *       Dos glosas idénticas en una línea no son un caso de negocio, y sí lo que deja un
     *       reintento;</li>
     *   <li>alta de novedad: la línea ya tiene una <b>puesta a mano</b> con ese código y los
     *       mismos datos. Una del motor con el mismo código no cuenta: el auditor quiere dejar
     *       su objeción, y si el recálculo retirara la del motor la suya no puede faltar;</li>
     *   <li>baja de cualquiera de las dos: la línea ya no tiene esa fila.</li>
     * </ul>
     */
    public java.util.Optional<EdicionLinea> pendienteParaLinea(LineaCuenta linea) {
        var glosasQueFaltan = glosas.stream()
                .filter(cambio -> cambio.esAlta()
                        ? linea.glosas().stream().noneMatch(g -> mismaGlosa(g, cambio))
                        : linea.glosas().stream().anyMatch(g -> mismoId(g.identificador(), cambio.identificador())))
                .toList();
        var novedadesQueFaltan = novedades.stream()
                .filter(cambio -> cambio.esAlta()
                        ? linea.novedades().stream().noneMatch(n -> mismaNovedadManual(n, cambio))
                        : linea.novedades().stream().anyMatch(n -> mismoId(n.identificador(), cambio.identificador())))
                .toList();
        if (glosasQueFaltan.isEmpty() && novedadesQueFaltan.isEmpty()) return java.util.Optional.empty();
        return java.util.Optional.of(EdicionLinea.soloCambiosDeColeccion(
                linea.referencia(), linea.version(), glosasQueFaltan, novedadesQueFaltan, modoRecalculo));
    }

    private static boolean mismaGlosa(DetalleGlosa existente, CambioGlosa alta) {
        return java.util.Objects.equals(existente.codigoGlosa(), alta.codigoGlosa())
            && existente.valor() != null && alta.valor() != null
            && existente.valor().compareTo(alta.valor()) == 0;
    }

    private static boolean mismaNovedadManual(Novedad existente, CambioNovedad alta) {
        return existente.laPusoUnaPersona()
            && java.util.Objects.equals(existente.codigo(), alta.codigoMensaje())
            && sinNulos(existente.valores()).equals(sinNulos(alta.valores()));
    }

    private static java.util.Map<Integer, String> sinNulos(java.util.Map<Integer, String> valores) {
        return valores == null ? java.util.Map.of() : valores;
    }

    private static boolean mismoId(long existente, Long pedido) {
        return pedido != null && existente == pedido;
    }
}
