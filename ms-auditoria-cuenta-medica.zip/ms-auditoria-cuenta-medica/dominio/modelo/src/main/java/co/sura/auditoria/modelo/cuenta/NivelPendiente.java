package co.sura.auditoria.modelo.cuenta;

public enum NivelPendiente {
    /** Pendiente que aplica a la cabecera de la cuenta. */
    CABECERA,
    /** Pendiente que aplica a una línea específica de la cuenta. */
    LINEA
}
