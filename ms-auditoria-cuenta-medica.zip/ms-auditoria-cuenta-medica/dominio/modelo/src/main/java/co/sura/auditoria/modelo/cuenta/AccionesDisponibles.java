package co.sura.auditoria.modelo.cuenta;

import java.util.Set;

/**
 * Capacidades que el sistema de registro declaró disponibles para esta cuenta
 * en este instante.
 *
 * <p>El dominio <em>nunca</em> deduce las acciones del estado de la cuenta;
 * siempre las obtiene del sistema de registro a través de este objeto.
 * Esto garantiza que cambios en las reglas de transición de OHI se absorban
 * sin modificar el dominio.
 */
public record AccionesDisponibles(Set<AccionCuenta> acciones) {

    public AccionesDisponibles {
        acciones = acciones == null ? Set.of() : Set.copyOf(acciones);
    }

    /** Instancia vacía: ninguna acción disponible. */
    public static AccionesDisponibles ninguna() {
        return new AccionesDisponibles(Set.of());
    }

    /** @return {@code true} si la acción fue habilitada por el sistema de registro. */
    public boolean permite(AccionCuenta accion) {
        return acciones.contains(accion);
    }
}
