package co.sura.auditoria.modelo.cuenta;

import java.util.List;

/**
 * Cómo acabó una operación que alcanza varias líneas.
 *
 * <h3>Por qué no basta un código de éxito</h3>
 * Porque el desenlace normal de una operación sobre veinte líneas no es «bien» o «mal»: es
 * «dieciocho sí y dos no, y estas son». Una línea bloqueada, una reemplazada o una que otro
 * auditor acaba de tocar no son errores de la petición —la petición era correcta— sino filas
 * que no se pudieron aplicar. Devolver un 500 por ellas tiraría también las dieciocho buenas;
 * devolver un 200 a secas escondería las dos.
 *
 * @param aplicadas las líneas que quedaron con el cambio
 * @param fallos    las que no, cada una con su porqué en lenguaje del auditor
 * @param yaEstaban las que ya tenían lo pedido y no se tocaron: repetir un lote no duplica
 *                  nada (OPE-12). No son fallos —el estado pedido se cumple— ni aplicadas
 *                  —no se escribió nada en ellas—
 */
public record ResultadoPorLinea(List<ReferenciaLinea> aplicadas,
                                List<Fallo> fallos,
                                Desenlace desenlace,
                                List<ReferenciaLinea> yaEstaban) {

    public enum Desenlace { COMPLETO, PARCIAL, FALLIDO }

    /**
     * Una línea que no se pudo cambiar.
     *
     * @param numeroLinea el que ve el auditor en la grilla. Va junto a la referencia porque
     *                    la referencia es el identificador interno de OHI y no le dice nada:
     *                    un informe que solo lleve referencias obliga a traducirlas a mano.
     */
    public record Fallo(ReferenciaLinea referencia, Integer numeroLinea, String motivo) {}

    public ResultadoPorLinea {
        aplicadas = aplicadas == null ? List.of() : List.copyOf(aplicadas);
        fallos    = fallos    == null ? List.of() : List.copyOf(fallos);
        yaEstaban = yaEstaban == null ? List.of() : List.copyOf(yaEstaban);
    }

    /** Arma el resultado deduciendo el desenlace, para que no se pueda declarar uno que no cuadre. */
    public static ResultadoPorLinea de(List<ReferenciaLinea> aplicadas, List<Fallo> fallos) {
        return de(aplicadas, fallos, List.of());
    }

    /**
     * Lo mismo, con las líneas que ya estaban como se pedía. Cuentan del lado bueno: un lote
     * repetido en el que todas ya estaban es COMPLETO, no FALLIDO.
     */
    public static ResultadoPorLinea de(List<ReferenciaLinea> aplicadas, List<Fallo> fallos,
                                       List<ReferenciaLinea> yaEstaban) {
        var ok = aplicadas == null ? List.<ReferenciaLinea>of() : aplicadas;
        var mal = fallos == null ? List.<Fallo>of() : fallos;
        var igual = yaEstaban == null ? List.<ReferenciaLinea>of() : yaEstaban;
        Desenlace desenlace;
        if (mal.isEmpty())                        desenlace = Desenlace.COMPLETO;
        else if (ok.isEmpty() && igual.isEmpty()) desenlace = Desenlace.FALLIDO;
        else                                      desenlace = Desenlace.PARCIAL;
        return new ResultadoPorLinea(ok, mal, desenlace, igual);
    }

    public int cuantasAplicadas() { return aplicadas.size(); }
}
