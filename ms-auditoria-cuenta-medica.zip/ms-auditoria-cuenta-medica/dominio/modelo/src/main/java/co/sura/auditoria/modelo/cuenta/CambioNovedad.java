package co.sura.auditoria.modelo.cuenta;

/**
 * Un alta o una baja de novedad en una línea.
 *
 * <h3>Por qué solo viaja el código</h3>
 * Al revés que {@link CambioGlosa}, aquí <b>sí hay catálogo</b>: el sistema de
 * registro publica los mensajes en {@code /generic/messages} y de ahí salen el
 * texto, la severidad y la clasificación normativa. Por eso este comando no los
 * recibe. Aceptarlos permitiría guardar una novedad cuyo texto no es el de su
 * código —o cuya severidad no es la que el catálogo le asigna—, y el prestador
 * acabaría leyendo una objeción que el catálogo no respalda.
 *
 * <p>Se identifica el mensaje <b>por su código</b> y no por el identificador
 * interno del sistema de registro. Las dos formas funcionan —se comprobó contra
 * el entorno de pruebas que {@code {"code":"332-1"}} resuelve al mismo mensaje
 * que {@code {"id":"282641"}}—, y se escoge el código porque es el que el
 * auditor reconoce, el que aparece en la normativa y el que no cambia si el
 * catálogo se recarga.
 *
 * <h3>Lo que no se recibe nunca: el origen</h3>
 * El sistema de registro marca cada novedad con el origen que la produjo
 * ({@code MANUAL}, {@code BENEFITS}, {@code PRICING}, {@code COVERAGE}…). Un alta
 * hecha por un auditor es {@code MANUAL} y la capa de integración lo impone como
 * constante. <b>No es un campo de este comando a propósito:</b> si el cliente
 * pudiera elegirlo, podría fabricar una novedad que aparenta haberla levantado
 * el motor de beneficios, y el origen es justo el dato con el que se distingue
 * lo que decidió una persona de lo que decidió el sistema.
 *
 * @param operacion      qué hacer
 * @param identificador  de la novedad a eliminar; {@code null} en un alta, porque
 *                       lo asigna el sistema de registro
 * @param codigoMensaje  el código del catálogo, p. ej. {@code 332-1} o
 *                       {@code NEGACION_010}; {@code null} en una baja
 * @param valores        los datos que completan los marcadores de la plantilla,
 *                       por índice de marcador. Vacío si el mensaje no pide
 *                       ninguno. Es lo que el sistema de registro guarda como
 *                       «Valor 0»…«Valor 9»; ver {@link TextoDeNovedad}
 */
public record CambioNovedad(Operacion operacion,
                            Long identificador,
                            String codigoMensaje,
                            java.util.Map<Integer, String> valores) {

    public enum Operacion { AGREGAR, ELIMINAR }

    /**
     * Las dos formas son excluyentes y se comprueban aquí, igual que en
     * {@link CambioGlosa}: una baja con código o un alta con identificador no
     * significan nada, y dejarlas pasar las convertiría en un parche que el
     * sistema de registro interpretaría a su manera.
     */
    public CambioNovedad {
        // Se comprueba ANTES de copiar: `Map.copyOf` revienta con
        // NullPointerException ante una clave o un valor nulos, y eso sale por
        // la capa web como un 500 en vez del 400 que describe el error.
        if (valores != null) {
            for (var entrada : valores.entrySet()) {
                if (entrada.getKey() == null) {
                    throw new IllegalArgumentException(
                            "Cada dato de la novedad tiene que decir a qué hueco va");
                }
                if (entrada.getValue() == null) {
                    throw new IllegalArgumentException(
                            ("El dato %d de la novedad llegó vacío: un hueco sin rellenar se "
                           + "le enseña al prestador tal cual").formatted(entrada.getKey()));
                }
            }
        }
        valores = valores == null ? java.util.Map.of() : java.util.Map.copyOf(valores);
        if (operacion == null) {
            throw new IllegalArgumentException("Hay que decir si la novedad se agrega o se elimina");
        }
        if (operacion == Operacion.ELIMINAR) {
            if (identificador == null) {
                throw new IllegalArgumentException(
                        "Para eliminar una novedad hace falta su identificador");
            }
            if (codigoMensaje != null || !valores.isEmpty()) {
                throw new IllegalArgumentException(
                        "Eliminar una novedad solo admite su identificador");
            }
        } else {
            if (identificador != null) {
                throw new IllegalArgumentException(
                        "El identificador de una novedad lo asigna el sistema de registro");
            }
            if (codigoMensaje == null || codigoMensaje.isBlank()) {
                throw new IllegalArgumentException(
                        "La novedad necesita el código del mensaje del catálogo");
            }
            // Lo que se puede comprobar sin el catálogo se comprueba aquí; que
            // los índices sean los que la plantilla pide necesita el texto del
            // mensaje y lo hace el caso de uso.
            for (var entrada : valores.entrySet()) {
                var indice = entrada.getKey();
                if (indice == null || indice < 0 || indice >= TextoDeNovedad.CUANTOS_VALORES) {
                    throw new IllegalArgumentException(
                            "El dato de la novedad va numerado del 0 al "
                          + (TextoDeNovedad.CUANTOS_VALORES - 1) + ", no " + indice);
                }
                var valor = entrada.getValue();
                if (valor != null && valor.length() > TextoDeNovedad.LARGO_MAXIMO_VALOR) {
                    throw new IllegalArgumentException(
                            "El dato %d de la novedad no puede pasar de %d caracteres"
                                    .formatted(indice, TextoDeNovedad.LARGO_MAXIMO_VALOR));
                }
            }
        }
    }

    public static CambioNovedad agregar(String codigoMensaje) {
        return agregar(codigoMensaje, java.util.Map.of());
    }

    /**
     * @param valores los datos que completan los marcadores de la plantilla,
     *     por índice. Ver {@link TextoDeNovedad}
     */
    public static CambioNovedad agregar(String codigoMensaje,
                                        java.util.Map<Integer, String> valores) {
        return new CambioNovedad(Operacion.AGREGAR, null, codigoMensaje, valores);
    }

    public static CambioNovedad eliminar(long identificador) {
        return new CambioNovedad(Operacion.ELIMINAR, identificador, null, java.util.Map.of());
    }

    public boolean esAlta() { return operacion == Operacion.AGREGAR; }

    public boolean esBaja() { return operacion == Operacion.ELIMINAR; }
}
