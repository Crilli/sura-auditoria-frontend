package co.sura.auditoria.modelo.cuenta;

/**
 * Cursor de paginación por clave (keyset pagination).
 *
 * <p>Opaco para el cliente: solo lo devuelve y lo envía de vuelta.
 * El valor interno es la referencia del último elemento de la página anterior,
 * que la ACL usa para construir la cláusula {@code id.gt(ultimaReferencia)}.
 */
public record Cursor(long ultimaReferencia) {

    /** Cursor especial que indica la primera página (sin filtro de cursor). */
    public static final Cursor PRIMERA_PAGINA = new Cursor(0L);

    /** @return {@code true} si este cursor corresponde al inicio de la paginación. */
    public boolean esPrimeraPagina() {
        return ultimaReferencia <= 0L;
    }
}
