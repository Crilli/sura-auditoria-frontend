package co.sura.auditoria.modelo.cuenta;

public enum Severidad {
    INFORMATIVA,
    ADVERTENCIA,
    BLOQUEANTE,
    /** Valor devuelto cuando OHI reporta una severidad no mapeada. */
    DESCONOCIDA
}
