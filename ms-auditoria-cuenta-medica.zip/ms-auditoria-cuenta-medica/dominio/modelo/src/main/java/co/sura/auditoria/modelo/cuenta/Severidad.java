package co.sura.auditoria.modelo.cuenta;

/**
 * Gravedad de una novedad.
 *
 * <p>El sistema de registro publica su severidad como <b>un solo carácter</b>
 * —{@code I}, {@code F} o {@code D}, con los significados «Informativo»,
 * «Fatal» y «Negar»—, no como las palabras {@code INFO} / {@code WARNING} /
 * {@code FATAL} que se supusieron al escribir esto. La traducción vive en el
 * diccionario de la capa de integración; aquí solo importa que son tres y que
 * dos de ellas frenan la cuenta.
 *
 * <p><b>{@link #ADVERTENCIA} no tiene equivalente en el sistema de registro.</b>
 * Se conserva porque el simulador local la genera para poder pintar los tres
 * niveles sin depender de la red; ninguna novedad real llega con ese valor.
 */
public enum Severidad {
    INFORMATIVA,
    /** Solo la produce el simulador local: el sistema de registro no tiene este nivel. */
    ADVERTENCIA,
    /** {@code F} — impide que la cuenta avance mientras no se resuelva. */
    BLOQUEANTE,
    /**
     * {@code D} — niega lo facturado, no solo lo frena.
     *
     * <p>Se distingue de {@link #BLOQUEANTE} a propósito: son dos desenlaces
     * distintos y juntarlos haría que la pantalla dijera «falta resolver» donde
     * el sistema de registro ya decidió negar. Es poco frecuente —2 de los 631
     * mensajes que un auditor puede elegir— pero es el más grave de los tres.
     */
    NEGACION,
    /** Valor devuelto cuando el sistema de registro reporta una severidad no mapeada. */
    DESCONOCIDA;

    /**
     * @return si una novedad con esta severidad impide que la cuenta siga su curso.
     *     {@link #NEGACION} cuenta: negar es más fuerte que bloquear, no menos.
     */
    public boolean frenaLaCuenta() {
        return this == BLOQUEANTE || this == NEGACION;
    }
}
