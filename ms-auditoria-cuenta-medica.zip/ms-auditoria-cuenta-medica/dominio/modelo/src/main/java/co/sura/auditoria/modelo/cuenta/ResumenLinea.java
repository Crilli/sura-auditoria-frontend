package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Proyección liviana de una línea para la grilla de auditoría.
 * Nunca carga novedades completas ni pendientes completos;
 * solo los contadores necesarios para pintar la interfaz de usuario.
 */
public record ResumenLinea(
        ReferenciaLinea referencia,
        int numeroLinea,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si el sistema de registro no lo tiene. */
        String nombreAfiliado,
        String codigoProcedimiento,
        /** Descripción de la prestación; {@code null} si el código no está en el catálogo. */
        String descripcionProcedimiento,
        /** Catálogo del que sale el código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        /**
         * Código de autorización de la atención; {@code null} si la línea no lo
         * trae.
         *
         * <p>Está en el resumen y no solo en el detalle porque es uno de los
         * criterios por los que se busca: filtrar por él exige poder leerlo en la
         * grilla, y una columna que no se puede ver pero sí filtrar deja al
         * auditor sin saber por qué una fila salió.
         */
        String codigoAutorizacion,
        BigDecimal valorAutorizado,
        BigDecimal valorCubierto,
        /**
         * Valor glosado de la línea; {@code null} si no tiene glosa.
         *
         * <p>Igual que {@code codigoAutorizacion}: sube al resumen porque es
         * criterio de búsqueda. Además, el sistema de registro <b>no sabe
         * filtrar por él</b> —ni por ningún otro importe de la línea—, así que es
         * aquí, sobre la fila ya traída, donde se puede evaluar.
         */
        BigDecimal valorGlosado,
        boolean conservarBeneficios,
        boolean conservarTarifacion,
        boolean bloqueada,
        boolean reemplazada,
        int cantidadPendientes,
        /**
         * Motivos pendientes sin resolver de esta línea. Van en el resumen porque
         * el adaptador ya los trae para contarlos: pintar el porqué junto al
         * número no cuesta ninguna consulta más.
         */
        java.util.List<MotivoPendiente> pendientes,
        boolean tieneNovedadBloqueante,
        /**
         * Las novedades de esta línea, con su texto.
         *
         * <p>Van en el resumen por la misma razón que los pendientes: el adaptador <b>ya las
         * trae</b> para poder calcular {@link #tieneNovedadBloqueante}, y descartaba sus textos.
         * Publicarlas no cuesta ninguna consulta más, y a cambio el auditor lee en la fila qué
         * objetó el motor en vez de un «⚠ Bloqueada» que no dice ni qué campo ni por qué.
         */
        java.util.List<Novedad> novedades,
        Version version,

        // ── Lo que el MVP pide ver sin abrir la línea ──────────────────────
        // Van al final y no junto a los otros importes para no reordenar un record que
        // ya construyen siete sitios: insertar en medio los rompe todos en silencio
        // —el compilador avisa, pero solo si los tipos no casan—.
        /** Lo que el prestador cobró. */
        BigDecimal valorCargado,
        /** Unidades cobradas. */
        BigDecimal unidadesCargadas,
        /** Unidades autorizadas. OHI la omite en el 7,5 % de las líneas: puede ser nula. */
        BigDecimal unidadesAutorizadas,
        /** Importe de IVA que calcula el motor; casi siempre nulo. */
        BigDecimal valorIva,
        /** Porcentaje de IVA. */
        BigDecimal porcentajeIva
) {
    public ResumenLinea {
        pendientes = pendientes == null ? java.util.List.of() : java.util.List.copyOf(pendientes);
    }
    /**
     * Una línea bloqueada o reemplazada es ignorada por el sistema de registro;
     * no tiene sentido intentar editarla.
     */
    public boolean esEditable() {
        return !bloqueada && !reemplazada;
    }
}
