package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Proyección liviana de una línea para la grilla de auditoría.
 * Nunca carga novedades completas ni pendientes completos;
 * solo los contadores necesarios para pintar la interfaz de usuario.
 */
public record ResumenLinea(
        ReferenciaLinea referencia,
        int numeroLinea,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        String codigoAfiliado,
        /** Nombre del afiliado; {@code null} si el sistema de registro no lo tiene. */
        String nombreAfiliado,
        String codigoProcedimiento,
        /** Descripción de la prestación; {@code null} si el código no está en el catálogo. */
        String descripcionProcedimiento,
        /** Catálogo del que sale el código: CUPS, CUM, SURACUPS o el propio del prestador. */
        String catalogoProcedimiento,
        BigDecimal valorAutorizado,
        BigDecimal valorCubierto,
        boolean conservarBeneficios,
        boolean conservarTarifacion,
        boolean bloqueada,
        boolean reemplazada,
        int cantidadPendientes,
        /**
         * Motivos pendientes sin resolver de esta línea. Van en el resumen porque
         * el adaptador ya los trae para contarlos: pintar el porqué junto al
         * número no cuesta ninguna consulta más.
         */
        java.util.List<MotivoPendiente> pendientes,
        boolean tieneNovedadBloqueante,
        Version version
) {
    public ResumenLinea {
        pendientes = pendientes == null ? java.util.List.of() : java.util.List.copyOf(pendientes);
    }
    /**
     * Una línea bloqueada o reemplazada es ignorada por el sistema de registro;
     * no tiene sentido intentar editarla.
     */
    public boolean esEditable() {
        return !bloqueada && !reemplazada;
    }
}
