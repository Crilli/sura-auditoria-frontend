package co.sura.auditoria.modelo.auditoria;

import java.time.Instant;
import java.util.UUID;

/**
 * Evento de auditoría generado por el dominio cuando el auditor ejecuta
 * una acción con impacto en la cuenta médica.
 *
 * <p>Este concepto es propio del dominio y <em>no existe</em> en OHI.
 * Se persiste en la base de trazabilidad y/o se publica en el bus de eventos.
 */
public record EventoAuditoria(
        UUID identificador,
        String codigoCuenta,
        Long referenciaLinea,       // null para eventos de cabecera
        TipoEvento tipo,
        String autor,
        String detalle,
        ResultadoEvento resultado,
        String codigoError,         // null si resultado == EXITOSO
        String idCorrelacion,
        Instant ocurridoEn
) {
    /** Evento generado al guardar exitosamente una línea. */
    public static EventoAuditoria lineaGuardada(String codigoCuenta, long referencia,
                                                String detalle, String autor) {
        return new EventoAuditoria(
                UUID.randomUUID(), codigoCuenta, referencia,
                TipoEvento.LINEA_GUARDADA, autor, detalle,
                ResultadoEvento.EXITOSO, null, null, Instant.now());
    }

    /** Evento generado al resolver un pendiente. */
    public static EventoAuditoria pendienteResuelto(String codigoCuenta, long motivo,
                                                    String alcance, String justificacion,
                                                    String autor) {
        return new EventoAuditoria(
                UUID.randomUUID(), codigoCuenta, null,
                TipoEvento.PENDIENTE_RESUELTO, autor,
                "Motivo: %d | Alcance: %s | Justificación: %s".formatted(motivo, alcance, justificacion),
                ResultadoEvento.EXITOSO, null, null, Instant.now());
    }

    /**
     * Evento generado al resolver varios motivos en una sola operación.
     *
     * <p>Guarda el desenlace además de lo pedido: la operación es de larga
     * duración y puede acabar en parcial, así que un evento que solo dijera qué
     * se pidió haría pensar que todo se resolvió.
     */
    public static EventoAuditoria pendientesResueltosEnMasa(String codigoCuenta,
                                                            java.util.Set<String> motivos,
                                                            String nivel, String desenlace,
                                                            String justificacion, String autor) {
        return new EventoAuditoria(
                UUID.randomUUID(), codigoCuenta, null,
                TipoEvento.PENDIENTES_RESUELTOS_EN_MASA, autor,
                "Motivos (%d): %s | Nivel: %s | Desenlace: %s | Justificación: %s"
                        .formatted(motivos.size(), String.join(", ", motivos),
                                   nivel, desenlace, justificacion),
                ResultadoEvento.EXITOSO, null, null, Instant.now());
    }

    /** Evento generado al cambiar las novedades de la cabecera de la cuenta. */
    public static EventoAuditoria cuentaNovedadesCambiadas(String codigoCuenta, String detalle,
                                                           String autor) {
        return new EventoAuditoria(
                UUID.randomUUID(), codigoCuenta, null,
                TipoEvento.CUENTA_NOVEDADES_CAMBIADAS, autor,
                detalle,
                ResultadoEvento.EXITOSO, null, null, Instant.now());
    }

    /** Evento generado al ejecutar una acción habilitada sobre la cuenta. */
    public static EventoAuditoria accionEjecutada(String codigoCuenta, String detalle, String autor) {
        return new EventoAuditoria(
                UUID.randomUUID(), codigoCuenta, null,
                TipoEvento.ACCION_EJECUTADA, autor, detalle,
                ResultadoEvento.EXITOSO, null, null, Instant.now());
    }

    /** Evento generado al enviar una cuenta al sistema de registro. */
    public static EventoAuditoria cuentaEnviada(String codigoCuenta, String decision, String autor) {
        return new EventoAuditoria(
                UUID.randomUUID(), codigoCuenta, null,
                TipoEvento.CUENTA_ENVIADA, autor,
                "Decisión: " + decision,
                ResultadoEvento.EXITOSO, null, null, Instant.now());
    }
}
