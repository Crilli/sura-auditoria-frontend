package co.sura.auditoria.modelo.cuenta;

import java.util.List;

/**
 * Estado puntual del proceso de envío de una cuenta médica.
 * Se obtiene consultando el sistema de registro tras recibir el {@link TiqueteProceso}.
 */
public record EstadoProceso(
        Avance avance,
        boolean finalizado,
        List<String> errores
) {
    public enum Avance {
        NO_INICIADO,
        EN_PROCESO,
        EXITOSO,
        FALLIDO
    }

    public EstadoProceso {
        errores = errores == null ? List.of() : List.copyOf(errores);
    }
}
