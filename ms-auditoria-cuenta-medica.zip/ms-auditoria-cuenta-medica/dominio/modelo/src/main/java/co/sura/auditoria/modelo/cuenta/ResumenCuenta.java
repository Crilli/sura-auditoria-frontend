package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Una cuenta médica en una lista de resultados.
 *
 * <p>Es lo justo para reconocerla y decidir si es la que se busca: las seis columnas que pide
 * el documento. Nada más, porque la lista puede traer cientos de filas y cada campo de más es
 * una proyección más ancha en una consulta que ya recorre todo el sistema de registro.
 *
 * @param prestadorNombre razón social del prestador de facturación. Va junto al NIT y no en su
 *                        lugar: dos NIT no se comparan a ojo
 * @param estado          el estado ya traducido al vocabulario del auditor
 */
public record ResumenCuenta(CodigoCuenta codigo,
                            String numeroFactura,
                            LocalDate fechaRadicacion,
                            String prestadorNit,
                            String prestadorNombre,
                            BigDecimal valorFactura,
                            EstadoCuenta estado,
                            /**
                             * El literal del sistema de registro, por si el diccionario no lo
                             * conoce. Enseñar «DESCONOCIDO» en una lista de resultados deja al
                             * auditor sin saber qué tiene delante; el nombre feo al menos informa.
                             */
                            String estadoLiteral) {

    /** Lo que se pinta en la columna de estado. */
    public String estadoLegible() {
        return estado == EstadoCuenta.DESCONOCIDO && estadoLiteral != null
                ? estadoLiteral
                : estado.name();
    }
}
