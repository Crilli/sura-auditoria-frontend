package co.sura.auditoria.modelo.cuenta;

import java.time.Instant;

/**
 * Novedad (mensaje) adjunta a una línea de cuenta médica.
 *
 * <p>Una novedad la puede haber levantado el motor de reglas del sistema de
 * registro —en cualquiera de sus etapas: coberturas, beneficios, tarifación…— o
 * la puede haber puesto un auditor a mano. Esa diferencia la marca
 * {@link #origen} y es la más importante de este registro: ver
 * {@link #laPusoUnaPersona()}.
 *
 * @param identificador el que asigna el sistema de registro
 * @param codigo        código del mensaje del catálogo; {@code null} si la
 *                      novedad quedó huérfana de mensaje
 * @param descripcion   el texto que ve el prestador
 * @param severidad     la que el catálogo asigna al código, no una elección
 *                      de quien la puso
 * @param origen        la etapa que la produjo, o {@value #ORIGEN_MANUAL}
 * @param generico      clasificación normativa de primer nivel, p. ej.
 *                      {@code TA · TARIFAS}; {@code null} si el mensaje no la trae
 * @param especifico    de segundo nivel; {@code null} si no la trae
 * @param autor         quién la creó, tal como lo publica el sistema de registro
 * @param fecha         cuándo se creó
 * @param esDelSistema  lo que el sistema de registro rotula «Específico de
 *                      Sistema?»: si el mensaje es de los que levanta su propio
 *                      motor por cuestiones técnicas. Es del catálogo, no de
 *                      esta novedad
 * @param valores       los datos que completan los marcadores de
 *                      {@link #descripcion}, por índice. Ver {@link TextoDeNovedad}
 */
public record Novedad(
        long identificador,
        String codigo,
        String descripcion,
        Severidad severidad,
        String origen,
        Clasificacion generico,
        Clasificacion especifico,
        String autor,
        Instant fecha,
        boolean esDelSistema,
        java.util.Map<Integer, String> valores
) {

    public Novedad {
        valores = valores == null ? java.util.Map.of() : java.util.Map.copyOf(valores);
    }

    /**
     * El origen que el sistema de registro usa para lo que pone una persona.
     * Los otros catorce valores de su vocabulario son etapas de su propio motor.
     */
    public static final String ORIGEN_MANUAL = "MANUAL";

    /** Una clasificación normativa: el código y cómo se lee. */
    public record Clasificacion(String codigo, String descripcion) {}

    /**
     * Constructor reducido para los casos en que solo se conoce lo que pinta la
     * lista de novedades. Evita tener que pasar seis nulos en los sitios —el
     * pruebas, sobre todo— que no tienen de dónde sacar el resto.
     */
    public Novedad(long identificador, String codigo, String descripcion,
                   Severidad severidad, String origen) {
        this(identificador, codigo, descripcion, severidad, origen,
             null, null, null, null, false, java.util.Map.of());
    }

    /**
     * El texto tal como debe leerse: la plantilla con sus marcadores ya
     * sustituidos por los valores.
     *
     * <p>Se compone aquí porque el sistema de registro <b>no lo compone</b>:
     * devuelve la plantilla con las llaves y los valores aparte. Si a un
     * marcador le falta su valor se deja la llave a la vista; ver
     * {@link TextoDeNovedad#resolver}.
     */
    public String textoResuelto() {
        return TextoDeNovedad.resolver(descripcion, valores);
    }

    /**
     * @return si la novedad la puso una persona y no el motor de reglas.
     *
     * <p>De esto depende que se pueda quitar: lo que objetó el motor es
     * evidencia de la auditoría y no se borra desde esta aplicación. El sistema
     * de registro no distingue —acepta que le borren las suyas— así que la
     * distinción se hace aquí.
     */
    public boolean laPusoUnaPersona() {
        return ORIGEN_MANUAL.equalsIgnoreCase(origen);
    }
}
