package co.sura.auditoria.modelo.cuenta;

/**
 * Novedad (mensaje) adjunta a una línea de cuenta médica.
 * Puede ser informativa, de advertencia o bloqueante.
 */
public record Novedad(
        long identificador,
        String codigo,
        String descripcion,
        Severidad severidad,
        String origen
) {}
