package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.FiltroCuentas;
import co.sura.auditoria.modelo.cuenta.PaginaDesplazada;
import co.sura.auditoria.modelo.cuenta.ResumenCuenta;
import co.sura.auditoria.modelo.cuenta.VersionCuenta;
import java.util.List;
import reactor.core.publisher.Mono;

/**
 * Buscar cuentas médicas sin saber todavía cuál es.
 *
 * <p>Va aparte de {@code PuertoConsultaCuentas} —que trabaja siempre sobre una cuenta ya
 * identificada— porque la pregunta es distinta: aquélla responde «qué tiene esta cuenta» y
 * ésta «cuáles hay».
 */
public interface PuertoBusquedaCuentas {

    /** Las cuentas que cumplen el filtro, paginadas por desplazamiento. */
    Mono<PaginaDesplazada<ResumenCuenta>> buscar(FiltroCuentas filtro, int desplazamiento,
                                                 int tamanoPagina);

    /**
     * Las versiones de unas cuentas, por código.
     *
     * <p>Recibe varios códigos a propósito: la pantalla despliega las versiones de todas las
     * filas de una página, y pedirlas de una en una serían veinticinco llamadas.
     *
     * <p>Ojo al contrato: en el histórico <b>no se puede filtrar por número de factura</b>
     * —medido: responde 500— así que el camino es siempre buscar las cuentas primero y
     * preguntar por sus códigos después.
     */
    Mono<List<VersionCuenta>> versionesDe(List<CodigoCuenta> codigos);

    /**
     * La foto de una versión concreta: cabecera, importes y los estados por los que pasó.
     *
     * @return vacío si esa versión no existe, o si la cuenta todavía no se ha transmitido
     */
    Mono<co.sura.auditoria.modelo.cuenta.FotoVersion> fotoDeVersion(CodigoCuenta codigo, int numero);
}
