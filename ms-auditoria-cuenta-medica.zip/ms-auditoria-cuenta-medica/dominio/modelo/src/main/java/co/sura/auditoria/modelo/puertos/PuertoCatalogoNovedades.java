package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.MensajeCatalogo;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Puerto de lectura del catálogo de mensajes que un auditor puede poner como
 * novedad.
 *
 * <p>Va aparte de {@link PuertoConsultaCuentas} porque el catálogo <b>no es de
 * una cuenta</b>: es global, lo comparten todas y cambia muy de tarde en tarde.
 */
public interface PuertoCatalogoNovedades {

    /**
     * Trae el catálogo completo de lo ofrecible, ya filtrado según
     * {@link MensajeCatalogo}.
     *
     * <p><b>Entero y no paginado, a propósito.</b> Son 631 mensajes y pesan 24 kB
     * comprimidos, así que caben de una vez y la interfaz puede buscar sin ir y
     * volver por cada tecla. Lo que el auditor necesita es justo lo que una
     * búsqueda servidor-side hace peor: teclear tres letras del texto y ver al
     * instante los diez códigos que encajan.
     *
     * <p>Ojo al traerlo: el sistema de registro corta cualquier búsqueda en 200
     * registros <b>sin avisar</b>, así que el adaptador tiene que recorrerlo por
     * páginas y no fiarse de una sola llamada.
     */
    Mono<List<MensajeCatalogo>> listar();
}
