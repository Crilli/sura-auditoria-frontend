package co.sura.auditoria.modelo.cuenta;

/**
 * Un motivo del catálogo por el que se desfinaliza o se anula una cuenta.
 *
 * <p>No es solo un código: el sistema de registro declara como obligatorios
 * {@code code}, {@code descr}, {@code lockClaimLines}, {@code tipoProceso},
 * {@code sourceReferenceMandatory} y {@code accessRestriction}, y las cuatro
 * banderas cambian lo que la pantalla tiene que hacer. Medido sobre los 16 que
 * hay en el entorno de pruebas:
 *
 * <ul>
 *   <li><b>{@link #bloqueaLineas()} — 5 de 16.</b> Desfinalizar con uno de ellos
 *       deja las líneas bloqueadas, y hace falta un <i>desbloquear líneas</i>
 *       después. Es la razón de ser de esa acción, y hay que avisarlo
 *       <b>antes</b> de elegir el motivo, no descubrirlo luego;</li>
 *   <li><b>{@link #exigeReferencia()} — 1 de 16.</b> Sin la referencia de origen
 *       el sistema de registro responde un 422 que no se entiende;</li>
 *   <li><b>{@link #permiso()} — 6 de 16 tienen el suyo propio</b>
 *       ({@code RA_DESFINALIZA_ANULACION}, {@code RA_CONCILIACION_GLOSAS}…).
 *       De ahí que su error de permiso hable de «todos los motivos
 *       especificados»: se comprueba <b>motivo a motivo</b>, no por operación;</li>
 *   <li><b>{@link #aplicaA()}</b> separa los de cuenta médica (6) de los de
 *       autorización o reserva (4); 6 valen para ambas.</li>
 * </ul>
 *
 * @param codigo      el que viaja en la petición
 * @param descripcion cómo se lee
 */
public record MotivoDesfinalizacion(String codigo,
                                    String descripcion,
                                    boolean bloqueaLineas,
                                    boolean exigeReferencia,
                                    Ambito aplicaA,
                                    String permiso) {

    /**
     * A qué se le puede aplicar el motivo.
     *
     * <p>El sistema de registro lo publica como un código de un carácter y es de
     * los dinámicos, así que <b>no se puede filtrar en la consulta</b>: se
     * proyecta y se filtra aquí.
     */
    public enum Ambito {
        /** {@code C} — solo cuentas médicas. */
        CUENTA_MEDICA,
        /** {@code R} — solo autorizaciones y reservas. */
        AUTORIZACION,
        /** {@code A} — las dos. */
        AMBAS,
        /** Valor que el sistema de registro no publicó o no se reconoce. */
        DESCONOCIDO;

        /** @return si el motivo se puede usar sobre algo de este tipo de proceso. */
        public boolean alcanza(Ambito queEs) {
            return this == AMBAS || this == queEs;
        }
    }

    /** @return si al usarlo habrá que desbloquear las líneas después. */
    public boolean dejaLineasBloqueadas() {
        return bloqueaLineas;
    }
}
