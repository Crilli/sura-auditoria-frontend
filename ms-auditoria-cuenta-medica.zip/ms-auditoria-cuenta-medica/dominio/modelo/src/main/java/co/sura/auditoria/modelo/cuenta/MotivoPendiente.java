package co.sura.auditoria.modelo.cuenta;

/**
 * Motivo pendiente que puede bloquear el avance de la cuenta médica.
 *
 * <p>Un pendiente de sola adjudicación ({@code soloAdjudicacion = true}) solo
 * bloquea el envío cuando la cuenta está en estado {@code ADJUDICACION_MANUAL}.
 * En los demás estados manuales, estos pendientes no bloquean.
 */
public record MotivoPendiente(
        long identificador,
        String codigo,
        String descripcion,
        boolean resuelto,
        boolean soloAdjudicacion,
        NivelPendiente nivel,
        /** {@code null} cuando {@code nivel == CABECERA}. */
        ReferenciaLinea referenciaLinea,
        /**
         * Número de línea que ve el auditor. {@code null} en los de cabecera.
         * Va aparte de {@link #referenciaLinea}, que es el identificador interno
         * de OHI y no significa nada para quien lee la pantalla.
         */
        Integer numeroLinea,
        Version version
) {
    /**
     * Determina si este pendiente bloquea el envío de la cuenta dado su estado actual.
     *
     * @param estado estado actual de la cuenta
     * @return {@code true} si el pendiente impide el envío
     */
    public boolean bloqueaEnvioEn(EstadoCuenta estado) {
        if (resuelto) return false;
        return estado.todoPendienteBloqueaEnvio() || !soloAdjudicacion;
    }
}
