package co.sura.auditoria.modelo.auditoria;

/** Tipo de acción registrada en la traza de auditoría. */
public enum TipoEvento {
    LINEA_GUARDADA,
    PENDIENTE_RESUELTO,
    /**
     * Resolución de varios motivos en una sola operación.
     *
     * <p>Va aparte de {@link #PENDIENTE_RESUELTO} porque no es lo mismo de lo
     * que hay más: arrastra todas las filas de cada motivo —cientos, en las
     * cuentas grandes—, es irreversible y se decide de una vez. Quien revise la
     * traza necesita poder encontrarlas sin leer el detalle de cada evento.
     */
    PENDIENTES_RESUELTOS_EN_MASA,
    /**
     * Novedades puestas o quitadas en la cabecera de la cuenta.
     *
     * <p>Va aparte de {@link #LINEA_GUARDADA} aunque la novedad sea la misma
     * cosa en los dos sitios: una en cabecera, si es de severidad fatal, frena
     * la cuenta entera, y quien revise la traza necesita poder separar eso de
     * una edición de línea.
     */
    CUENTA_NOVEDADES_CAMBIADAS,
    /**
     * Una de las acciones que el sistema de registro habilita sobre la cuenta:
     * anular, devolver a modificación, revertir la finalización…
     *
     * <p>Va aparte porque es lo único que queda de quién movió la cuenta de
     * estado —el estado resultante no lo dice— y porque una de ellas, anular,
     * no tiene vuelta atrás.
     */
    ACCION_EJECUTADA,
    CUENTA_ENVIADA,
    /**
     * El mismo cambio aplicado a varias líneas desde la grilla.
     *
     * <p>Va aparte de {@link #LINEA_GUARDADA} y no como N eventos de ese tipo porque lo que
     * hay que poder reconstruir después es la <b>decisión</b> —«glosó estas dieciocho líneas
     * de una vez»— y no dieciocho guardados que parecerían independientes.
     */
    LINEAS_CAMBIADAS_EN_LOTE,
    CUENTA_CONSULTADA
}
