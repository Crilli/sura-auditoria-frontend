package co.sura.auditoria.modelo.auditoria;

/** Tipo de acción registrada en la traza de auditoría. */
public enum TipoEvento {
    LINEA_GUARDADA,
    PENDIENTE_RESUELTO,
    /**
     * Resolución de varios motivos en una sola operación.
     *
     * <p>Va aparte de {@link #PENDIENTE_RESUELTO} porque no es lo mismo de lo
     * que hay más: arrastra todas las filas de cada motivo —cientos, en las
     * cuentas grandes—, es irreversible y se decide de una vez. Quien revise la
     * traza necesita poder encontrarlas sin leer el detalle de cada evento.
     */
    PENDIENTES_RESUELTOS_EN_MASA,
    CUENTA_ENVIADA,
    CUENTA_CONSULTADA
}
