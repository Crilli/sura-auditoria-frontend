package co.sura.auditoria.modelo.auditoria;

/** Tipo de acción registrada en la traza de auditoría. */
public enum TipoEvento {
    LINEA_GUARDADA,
    PENDIENTE_RESUELTO,
    CUENTA_ENVIADA,
    CUENTA_CONSULTADA
}
