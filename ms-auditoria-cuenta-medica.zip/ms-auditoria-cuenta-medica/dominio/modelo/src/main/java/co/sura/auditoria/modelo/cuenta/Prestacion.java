package co.sura.auditoria.modelo.cuenta;

/**
 * Qué se le prestó al afiliado en esta línea.
 *
 * <p>{@code catalogo} es imprescindible para leer el código sin ambigüedad: el
 * mismo número significa cosas distintas en CUPS (procedimientos), CUM
 * (medicamentos), SURACUPS o en el catálogo propio de un prestador.
 *
 * <p>{@code codigoNoDefinido} aparece cuando el prestador facturó un código que
 * no está en el catálogo; entonces la única descripción disponible suele ser
 * {@code descripcionRips}, el texto literal del archivo RIPS.
 */
public record Prestacion(
        String codigo,
        String descripcion,
        String catalogo,
        String codigoNoDefinido,
        String codigoNoDefinidoDef,
        String descripcionRips,
        String claseServicio,
        String especialidad
) {}
