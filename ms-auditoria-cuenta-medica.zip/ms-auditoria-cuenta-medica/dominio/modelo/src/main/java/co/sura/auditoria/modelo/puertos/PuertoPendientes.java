package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.Cursor;
import co.sura.auditoria.modelo.cuenta.FiltroBloqueo;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import co.sura.auditoria.modelo.cuenta.NivelPendiente;
import co.sura.auditoria.modelo.cuenta.PaginaPendientes;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva;
import co.sura.auditoria.modelo.cuenta.ResumenMotivoPendiente;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;

/**
 * Puerto de gestión de pendientes.
 * Operaciones de resolución (Command) y listado (Query) sobre los motivos pendientes.
 */
public interface PuertoPendientes {

    /**
     * Todos los pendientes sin resolver de la cuenta, de cabecera y de líneas.
     *
     * <p>Es la consulta de la <b>decisión de envío</b>, que por definición los
     * necesita todos: no se puede decidir si una cuenta puede enviarse mirando
     * una página. Para pintarlos está {@link #listarPaginado}, que es lo que usa
     * la pantalla.
     */
    Flux<MotivoPendiente> listarSinResolver(CodigoCuenta codigo);

    /**
     * Una página de pendientes sin resolver, con el mismo keyset que las líneas.
     *
     * <p>La página mezcla dos recursos de OHI con espacios de identificador
     * distintos: los de cabecera ({@code claimpendreasons}) y los de línea
     * ({@code claimlinependreasons}). <b>El cursor avanza solo sobre los de
     * línea</b>; los de cabecera —de 1 a 3 en todo lo medido en producción— van
     * como prefijo de la primera página y consumen sus primeros huecos, de modo
     * que toda página mide {@code tamanoPagina} salvo la última y
     * {@code ceil(total / tamanoPagina)} sigue siendo el número real de páginas.
     *
     * @param codigoMotivo filtra por ese {@code pendReason.code} en los dos
     *                     niveles; {@code null} para no filtrar. Un motivo que
     *                     solo existe en la cabecera deja la parte de líneas
     *                     vacía, y al revés, sin que haya que decidirlo aquí.
     * @param bloqueo      deja solo los que bloquean el envío, solo los que no, o
     *                     todos. Se traduce contra el estado de la cuenta, que es
     *                     lo que decide qué bloquea, y por eso la página vuelve
     *                     acompañada de ese estado.
     */
    Mono<PaginaPendientes> listarPaginado(CodigoCuenta codigo, Cursor cursor,
                                          int tamanoPagina, boolean incluirTotal,
                                          String codigoMotivo, FiltroBloqueo bloqueo);

    /**
     * Los motivos distintos que tiene la cuenta, agregados, para poder filtrar
     * sin haber visto antes la lista entera.
     *
     * <p>Recorre la cuenta: OHI no agrega. Sale barato porque la proyección es
     * estrecha y las filas son diminutas, pero no es gratis —18 consultas en la
     * cuenta mayor medida—, así que va en su propia llamada y no colgando de la
     * primera página, para que la tabla pinte sin esperarlo.
     */
    Flux<ResumenMotivoPendiente> resumirMotivos(CodigoCuenta codigo);

    /**
     * Resuelve de una vez todos los pendientes de los motivos indicados, a un
     * solo nivel.
     *
     * <p>Es una operación distinta de {@link #resolverEnCuentaYLineas}, no un
     * bucle sobre ella: el sistema de registro tiene un recurso propio para
     * varios motivos a la vez que se procesa en <b>una</b> operación de larga
     * duración y, por tanto, <b>una</b> readjudicación. Resolver nueve motivos
     * uno a uno son nueve readjudicaciones de la misma cuenta. Las operaciones
     * conjuntas que ya existen en el sistema de registro, lanzadas por sus
     * propios usuarios, tardan del orden de 5 s de principio a fin.
     *
     * <p>El nivel es uno de los dos niveles reales, nunca los dos: así es como
     * lo acepta el sistema de registro. Quien quiera «donde aplique» llama dos
     * veces — ver {@link co.sura.auditoria.modelo.cuenta.NivelResolucion NivelResolucion}.
     *
     * <p>Los motivos se identifican por <b>código</b>, no por identificador de
     * fila: es lo que acepta la operación conjunta, y además es lo que de verdad
     * se resuelve —un motivo, con todas sus filas—, así que pasar códigos quita
     * de en medio la traducción de identificadores que necesita la ruta
     * individual.
     *
     * @return cómo acabó, incluidos los fallos parciales. Un motivo que ya
     *         estaba resuelto o una línea que ya no existe no hacen fracasar la
     *         operación: salen como fallos dentro del resultado.
     */
    Mono<ResultadoResolucionMasiva> resolverMotivos(CodigoCuenta codigo,
                                                   Set<String> codigosMotivo,
                                                   NivelPendiente nivel);

    /**
     * Resuelve el motivo <b>solo en la cabecera</b> de la cuenta.
     * Corresponde al {@code rel claim:resolvepend} de OHI.
     *
     * <p><b>El nombre engaña y se conserva por compatibilidad.</b> La descripción
     * que publica el propio sistema de registro para ese recurso es «Resolves a
     * pend reason <em>at claim level</em>», y la del recurso hermano es «at claim
     * <em>line</em> level»: son niveles disjuntos, así que esta operación no toca
     * las líneas. Para resolver un motivo en los dos sitios está
     * {@link #resolverMotivos}.
     */
    Mono<Void> resolverEnCuentaYLineas(CodigoCuenta codigo, long identificadorMotivo);

    /**
     * Resuelve el motivo únicamente a nivel de las líneas.
     * Corresponde al {@code rel claim:resolveclaimlinepend} de OHI.
     */
    Mono<Void> resolverSoloEnLineas(CodigoCuenta codigo, long identificadorMotivo);

    /** Resuelve un pendiente de cabecera por su identificador. */
    Mono<Void> resolverPendienteCabecera(long identificadorPendiente);

    /** Resuelve un pendiente de línea por su identificador. */
    Mono<Void> resolverPendienteLinea(long identificadorPendiente);
}
