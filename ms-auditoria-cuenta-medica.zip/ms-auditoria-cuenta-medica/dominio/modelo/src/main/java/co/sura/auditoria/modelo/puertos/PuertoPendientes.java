package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import co.sura.auditoria.modelo.cuenta.MotivoPendiente;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Puerto de gestión de pendientes.
 * Operaciones de resolución (Command) y listado (Query) sobre los motivos pendientes.
 */
public interface PuertoPendientes {

    /** Lista todos los pendientes sin resolver de la cuenta (cabecera y líneas). */
    Flux<MotivoPendiente> listarSinResolver(CodigoCuenta codigo);

    /**
     * Resuelve el motivo en la cabecera y en todas las líneas de la cuenta.
     * Corresponde al {@code rel claim:resolvepend} de OHI.
     */
    Mono<Void> resolverEnCuentaYLineas(CodigoCuenta codigo, long identificadorMotivo);

    /**
     * Resuelve el motivo únicamente a nivel de las líneas.
     * Corresponde al {@code rel claim:resolveclaimlinepend} de OHI.
     */
    Mono<Void> resolverSoloEnLineas(CodigoCuenta codigo, long identificadorMotivo);

    /** Resuelve un pendiente de cabecera por su identificador. */
    Mono<Void> resolverPendienteCabecera(long identificadorPendiente);

    /** Resuelve un pendiente de línea por su identificador. */
    Mono<Void> resolverPendienteLinea(long identificadorPendiente);
}
