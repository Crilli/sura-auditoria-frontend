package co.sura.auditoria.modelo.cuenta;

import java.util.Optional;

/**
 * Decisión del auditor al enviar una cuenta médica.
 *
 * <ul>
 *   <li>{@link Decision#ACEPTAR} — acepta la cuenta; el código de novedad es opcional
 *       (solo informativo si se envía).</li>
 *   <li>{@link Decision#DENEGAR} — deniega la cuenta; el código de novedad bloqueante
 *       es <em>obligatorio</em>.</li>
 * </ul>
 */
public record DecisionEnvio(Decision decision, Optional<String> codigoNovedad) {

    public enum Decision { ACEPTAR, DENEGAR }

    /** @return {@code true} si la combinación decisión/novedad es válida. */
    public boolean esValida() {
        return decision == Decision.ACEPTAR || codigoNovedad.isPresent();
    }

    /** @return {@code true} si se deben verificar los pendientes antes de enviar. */
    public boolean requiereVerificarPendientes() {
        return decision == Decision.ACEPTAR;
    }

    // — Constructores de fábrica —

    public static DecisionEnvio aceptar() {
        return new DecisionEnvio(Decision.ACEPTAR, Optional.empty());
    }

    public static DecisionEnvio aceptarConNovedad(String codigoInformativo) {
        return new DecisionEnvio(Decision.ACEPTAR, Optional.of(codigoInformativo));
    }

    /**
     * Admite un código nulo <strong>a propósito</strong>. Con {@code Optional.of} esto
     * lanzaba {@link NullPointerException} al mapear la solicitud, y el cliente que
     * omitía el código recibía un 500 en vez del 400 que describe el problema: la
     * comprobación de {@link #esValida()} que hay en el caso de uso de envío —y el
     * mensaje «Denegar exige el código de una novedad bloqueante»— quedaban
     * inalcanzables para justo la entrada que los motivó.
     */
    public static DecisionEnvio denegar(String codigoBloqueante) {
        return new DecisionEnvio(Decision.DENEGAR, Optional.ofNullable(codigoBloqueante));
    }
}
