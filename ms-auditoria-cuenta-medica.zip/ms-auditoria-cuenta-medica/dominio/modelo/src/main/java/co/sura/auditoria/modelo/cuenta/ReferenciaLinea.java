package co.sura.auditoria.modelo.cuenta;

/**
 * Referencia opaca a una línea de la cuenta médica.
 * El dominio no asume su origen ni su formato; solo la transporta.
 * La ACL es la única que sabe que este valor corresponde al id técnico de OHI.
 */
public record ReferenciaLinea(long valor) {

    public ReferenciaLinea {
        if (valor <= 0)
            throw new IllegalArgumentException("Referencia de línea inválida: " + valor);
    }
}
