package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;

/** Datos del convenio con el prestador que aplican a la línea. */
public record DatosConvenio(
        String codigoTarifarioIss2001,
        String codigoTarifarioIss2000,
        String codigoTarifarioSoat,
        String numeroContrato,
        String homologoCups,
        String multiplesCupsHomologos,
        String codigoUnicoContratoSiifa,
        /**
         * Tarifa pactada con el prestador, antes de los ajustes de regla.
         *
         * <p>No es un campo de la línea: sale de la cláusula de tarifación del
         * contrato. Es genuinamente distinta del valor cargado y del autorizado
         * —medido, difiere del autorizado en el 14% de las líneas con
         * tarifación automática y en casi todas las de tarifación manual—.
         * {@code null} en el 35% de las líneas, que no tienen cláusula.
         */
        BigDecimal valorConvenido,
        /** Texto de la cláusula: prestador, propuesta y manual tarifario aplicado. */
        String tarifaAplicada
) {}
