package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;

/** Datos del convenio con el prestador que aplican a la línea. */
public record DatosConvenio(
        String codigoTarifarioIss2001,
        String codigoTarifarioIss2000,
        String codigoTarifarioSoat,
        String numeroContrato,
        String homologoCups,
        String multiplesCupsHomologos,
        String codigoUnicoContratoSiifa,
        /**
         * Tarifa de contrato: el importe de la cláusula del contrato con el prestador, antes de
         * los ajustes de regla.
         *
         * <p><b>No es el valor convenido.</b> El convenido es {@code allowedAmount} de la línea
         * —decisión de negocio del 2026-10-21— y vive en {@link LineaCuenta#valorConvenido()};
         * este importe es su punto de partida: la tarifa de contrato más las cláusulas de regla
         * (que empiezan por {@code REGLA_}, {@code RM_} o {@code RA_}) da el convenido. Hasta
         * esa decisión se llamaba {@code valorConvenido}; se renombró para que el JSON del
         * detalle no lleve dos «convenido» con cifras distintas —medido, difieren en el 14% de
         * las líneas con tarifación automática y en casi todas las de tarifación manual—.
         *
         * <p>No es un campo de la línea: sale de la cláusula de tarifación, que es otra
         * consulta. {@code null} en el 35% de las líneas, que no tienen cláusula.
         */
        BigDecimal valorTarifaContrato,
        /** Texto de la cláusula: prestador, propuesta y manual tarifario aplicado. */
        String tarifaAplicada
) {}
