package co.sura.auditoria.modelo.cuenta;

import java.util.ArrayList;
import java.util.List;

/**
 * Cómo acabó una resolución de varios motivos a la vez.
 *
 * <p>El sistema de registro no resuelve en la respuesta: acepta la petición y la
 * procesa en una operación de larga duración, cuyo desenlace puede ser «todo»,
 * «parte» o «nada». Un fallo parcial es lo normal, no la excepción —un motivo
 * que otro auditor acababa de resolver, una línea que ya no existe—, y no viaja
 * en el código HTTP de la aceptación: solo en los mensajes de la operación. Por
 * eso este resultado existe: sin él, el único sitio donde cabría la noticia
 * sería un 2xx, que el auditor leería como «hecho».
 *
 * @param referencias identificadores de las operaciones en el sistema de
 *                    registro. Son más de una cuando el nivel pedido obliga a
 *                    emitir la de cabecera y la de líneas. Sirven para rastrear
 *                    la operación fuera de esta pantalla.
 * @param desenlace   qué se consiguió, visto en conjunto.
 * @param fallos      lo que no se pudo resolver, tal como lo reportó el sistema
 *                    de registro. Vacío cuando el desenlace es {@code COMPLETO}.
 */
public record ResultadoResolucionMasiva(List<String> referencias,
                                        Desenlace desenlace,
                                        List<Fallo> fallos) {

    public ResultadoResolucionMasiva {
        referencias = List.copyOf(referencias);
        fallos      = List.copyOf(fallos);
    }

    public enum Desenlace {
        /** Todo lo pedido quedó resuelto. */
        COMPLETO,
        /** Parte quedó resuelto y parte no; el detalle está en los fallos. */
        PARCIAL,
        /** No se aplicó nada. */
        FALLIDO,
        /**
         * El sistema de registro aceptó la petición y sigue trabajando.
         *
         * <p>No es un error: la operación va a terminar. Pero todavía no se sabe
         * en qué, así que decir «resuelto» sería adelantarse. Lo medido en
         * producción es ~5 s, de modo que este desenlace es el caso raro.
         */
        EN_CURSO
    }

    /**
     * Un motivo o un elemento que no se pudo resolver.
     *
     * @param codigo   el código de mensaje del sistema de registro, que es lo
     *                 único estable para distinguir una causa de otra.
     * @param elemento el identificador del elemento al que se refiere, si lo
     *                 trae el mensaje; cadena vacía si no.
     * @param detalle  la explicación ya redactada para el auditor.
     */
    public record Fallo(String codigo, String elemento, String detalle) {}

    /** Resultado de una operación que terminó sin nada que reportar. */
    public static ResultadoResolucionMasiva completo(String referencia) {
        return new ResultadoResolucionMasiva(List.of(referencia), Desenlace.COMPLETO, List.of());
    }

    /**
     * Une el desenlace de las dos operaciones que hacen falta cuando se resuelve
     * «donde aplique».
     *
     * <p>Las reglas, en orden:
     * <ol>
     *   <li>si alguna sigue en curso, el conjunto sigue en curso — lo que ya se
     *       sabe de la otra no autoriza a afirmar nada del total;</li>
     *   <li>si las dos fallaron por completo, el conjunto falló;</li>
     *   <li>si una falló o alguna reportó fallos, el conjunto es parcial;</li>
     *   <li>si no, completo.</li>
     * </ol>
     */
    public ResultadoResolucionMasiva y(ResultadoResolucionMasiva otro) {
        var referenciasUnidas = new ArrayList<>(this.referencias);
        referenciasUnidas.addAll(otro.referencias);

        var fallosUnidos = new ArrayList<>(this.fallos);
        fallosUnidos.addAll(otro.fallos);

        return new ResultadoResolucionMasiva(referenciasUnidas,
                                             combinar(this.desenlace, otro.desenlace, fallosUnidos),
                                             fallosUnidos);
    }

    private static Desenlace combinar(Desenlace uno, Desenlace otro, List<Fallo> fallos) {
        if (uno == Desenlace.EN_CURSO || otro == Desenlace.EN_CURSO) return Desenlace.EN_CURSO;
        if (uno == Desenlace.FALLIDO && otro == Desenlace.FALLIDO)   return Desenlace.FALLIDO;
        if (uno == Desenlace.FALLIDO || otro == Desenlace.FALLIDO
            || !fallos.isEmpty())                                    return Desenlace.PARCIAL;
        return Desenlace.COMPLETO;
    }

    /** Si el auditor puede dar por hecho todo lo que pidió. */
    public boolean todoResuelto() {
        return desenlace == Desenlace.COMPLETO;
    }
}
