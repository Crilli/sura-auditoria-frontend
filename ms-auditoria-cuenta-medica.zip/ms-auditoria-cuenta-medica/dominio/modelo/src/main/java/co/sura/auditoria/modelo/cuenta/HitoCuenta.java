package co.sura.auditoria.modelo.cuenta;

import java.time.Instant;

/**
 * Un hito de la historia de la cuenta: por dónde ha pasado y quién la movió.
 *
 * <h3>Dos orígenes, una historia</h3>
 * El sistema de registro no publica «la historia» en un sitio. Publica dos cosas que hay que
 * unir, y lo que las separa importa:
 * <ul>
 *   <li>{@code claimstatushistory}, los cambios de estado. <b>No guarda el motivo de la
 *       desfinalización</b>, así que una historia hecha solo con esto enseña que la cuenta se
 *       desfinalizó y no por qué.</li>
 *   <li>{@code claimunfinalizereasons}, que sí lo guarda, con su fecha y su usuario.</li>
 * </ul>
 *
 * <h3>No confundir con «Seguimiento»</h3>
 * La pestaña de seguimiento es el estado del <b>envío asíncrono</b> —si la operación que se
 * lanzó terminó o falló—. Esto es por dónde ha pasado la cuenta desde que llegó. Son dos
 * preguntas distintas y este proyecto ya tenía la primera.
 *
 * @param tipo     de cuál de los dos recursos salió
 * @param etiqueta el estado, o el motivo de la desfinalización
 * @param autor    quién lo hizo. El sistema de registro escribe «Internal System User» cuando
 *                 fue él, y un identificador opaco cuando fue una persona
 */
public record HitoCuenta(Tipo tipo, String etiqueta, String detalle, String autor,
                         Instant ocurridoEn) {

    public enum Tipo {
        /** Un cambio de estado de {@code claimstatushistory}. */
        CAMBIO_DE_ESTADO,
        /** Una desfinalización, con su motivo, de {@code claimunfinalizereasons}. */
        DESFINALIZACION
    }

    /** Si lo hizo el propio sistema de registro y no una persona. */
    public boolean loHizoElSistema() {
        return autor != null && autor.equalsIgnoreCase("Internal System User");
    }
}
