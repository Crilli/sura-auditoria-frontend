package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Agregado raíz del dominio de auditoría de cuentas médicas.
 *
 * <p>Contiene <b>solo</b> los datos de cabecera. Las líneas y las acciones
 * disponibles se consultan por separado:
 * <ul>
 *   <li>Las líneas, para no cargar toda la cuenta en memoria.</li>
 *   <li>Las acciones, porque OHI solo las publica —como enlaces HATEOAS— en la
 *       representación completa del claim, que tarda ~8 s. Pedirlas aquí ataba el
 *       pintado de la cabecera a esa espera. Ver
 *       {@code PuertoConsultaCuentas.consultarAccionesDisponibles}.</li>
 * </ul>
 */
public record CuentaMedica(
        CodigoCuenta codigo,
        EstadoCuenta estado,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        BigDecimal totalAutorizado,
        BigDecimal totalCubierto,
        Version version,
        List<MotivoPendiente> pendientesCabecera,
        /**
         * Novedades de la cabecera: lo que el sistema de registro guarda en
         * {@code claimMessageList}.
         *
         * <p>Son las mismas que las de una línea —mismo catálogo, mismo
         * vocabulario de orígenes, misma forma— y de ahí que se reutilice
         * {@link Novedad}. Lo único que cambia es de qué cuelgan.
         *
         * <p>En el entorno de pruebas pesan mucho más que las de línea en
         * proporción: 2.071 de 24.611 son manuales, frente a 1.962 de 753.483.
         * Y el vocabulario es otro —aquí mandan los códigos de anulación y la
         * nota crédito—, aunque el catálogo sea el mismo.
         */
        List<Novedad> novedades,
        /** Ficha de radicación y facturación del prestador. Ver {@link InformacionFacturacion}. */
        InformacionFacturacion informacionFacturacion
) {
    public CuentaMedica {
        pendientesCabecera = pendientesCabecera == null ? List.of() : List.copyOf(pendientesCabecera);
        informacionFacturacion = informacionFacturacion == null
                ? InformacionFacturacion.vacia()
                : informacionFacturacion;
    }

    /** @return {@code true} si hay al menos un pendiente sin resolver en la cabecera. */
    public boolean tienePendientesSinResolver() {
        return pendientesCabecera.stream().anyMatch(p -> !p.resuelto());
    }
}
