package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Agregado raíz del dominio de auditoría de cuentas médicas.
 *
 * <p>Contiene <b>solo</b> los datos de cabecera. Las líneas y las acciones
 * disponibles se consultan por separado:
 * <ul>
 *   <li>Las líneas, para no cargar toda la cuenta en memoria.</li>
 *   <li>Las acciones, porque OHI solo las publica —como enlaces HATEOAS— en la
 *       representación completa del claim, que tarda ~8 s. Pedirlas aquí ataba el
 *       pintado de la cabecera a esa espera. Ver
 *       {@code PuertoConsultaCuentas.consultarAccionesDisponibles}.</li>
 * </ul>
 */
public record CuentaMedica(
        CodigoCuenta codigo,
        EstadoCuenta estado,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        BigDecimal totalAutorizado,
        BigDecimal totalCubierto,
        Version version,
        List<MotivoPendiente> pendientesCabecera,
        /** Ficha de radicación y facturación del prestador. Ver {@link InformacionFacturacion}. */
        InformacionFacturacion informacionFacturacion
) {
    public CuentaMedica {
        pendientesCabecera = pendientesCabecera == null ? List.of() : List.copyOf(pendientesCabecera);
        informacionFacturacion = informacionFacturacion == null
                ? InformacionFacturacion.vacia()
                : informacionFacturacion;
    }

    /** @return {@code true} si hay al menos un pendiente sin resolver en la cabecera. */
    public boolean tienePendientesSinResolver() {
        return pendientesCabecera.stream().anyMatch(p -> !p.resuelto());
    }
}
