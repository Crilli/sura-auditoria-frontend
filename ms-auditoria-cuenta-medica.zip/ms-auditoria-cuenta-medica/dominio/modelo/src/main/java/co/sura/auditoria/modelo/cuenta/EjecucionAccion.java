package co.sura.auditoria.modelo.cuenta;

import java.util.List;

/**
 * Lo que hay que saber para ejecutar una acción sobre la cuenta.
 *
 * <h3>Un comando y no once métodos</h3>
 * El sistema de registro publica once acciones con tres formas distintas: seis
 * no llevan nada, dos llevan motivos de desfinalización y una lleva una lista de
 * líneas. Un método por acción daría once firmas casi idénticas en el puerto, en
 * el adaptador y en el simulador; un único comando las recoge y deja la variedad
 * donde está de verdad, que es en la traducción.
 *
 * <p>Lo que <b>no</b> lleva es la versión de la cuenta: estas operaciones no son
 * un parche sobre su contenido —no hay bloqueo optimista en su contrato— sino
 * transiciones de estado, y el sistema de registro responde con un conflicto si
 * el estado ya no las admite.
 *
 * @param accion     qué hacer
 * @param motivos    por qué, cuando la acción lo exige. Ver {@link #exigeMotivos()}
 * @param referencia referencia de origen, si alguno de los motivos la pide
 * @param lineas     qué líneas desbloquear; vacío significa todas
 * @param codigoMensajeAnulacion mensaje con el que se marca una anulación.
 *                   Opcional, y solo lo admite {@link AccionCuenta#ANULAR}
 */
public record EjecucionAccion(AccionCuenta accion,
                              List<String> motivos,
                              String referencia,
                              List<Long> lineas,
                              String codigoMensajeAnulacion) {

    public EjecucionAccion {
        motivos = motivos == null ? List.of() : List.copyOf(motivos);
        lineas  = lineas  == null ? List.of() : List.copyOf(lineas);

        if (accion == null) {
            throw new IllegalArgumentException("Hay que decir qué acción se quiere ejecutar");
        }
        if (exigeMotivos(accion) && motivos.isEmpty()) {
            throw new IllegalArgumentException(
                    "%s exige al menos un motivo: el sistema de registro la rechaza sin ellos"
                            .formatted(accion));
        }
        if (!exigeMotivos(accion) && !motivos.isEmpty()) {
            throw new IllegalArgumentException(
                    "%s no admite motivos".formatted(accion));
        }
        if (!lineas.isEmpty() && accion != AccionCuenta.DESBLOQUEAR_LINEAS) {
            throw new IllegalArgumentException(
                    "%s no admite una lista de líneas".formatted(accion));
        }
        if (codigoMensajeAnulacion != null && accion != AccionCuenta.ANULAR) {
            throw new IllegalArgumentException(
                    "Solo la anulación admite un mensaje de anulación");
        }
    }

    /**
     * Las dos que piden motivos.
     *
     * <p>No es una decisión nuestra: el contrato de las dos declara obligatoria
     * la lista, y sin ella responden que no se especificó ninguno.
     */
    public static boolean exigeMotivos(AccionCuenta accion) {
        return accion == AccionCuenta.ANULAR
            || accion == AccionCuenta.REVERTIR_FINALIZACION;
    }

    /** Acción sin nada más: las seis transiciones de estado a secas. */
    public static EjecucionAccion simple(AccionCuenta accion) {
        return new EjecucionAccion(accion, List.of(), null, List.of(), null);
    }

    public static EjecucionAccion conMotivos(AccionCuenta accion, List<String> motivos,
                                             String referencia) {
        return new EjecucionAccion(accion, motivos, referencia, List.of(), null);
    }

    public static EjecucionAccion anular(List<String> motivos, String referencia,
                                         String codigoMensaje) {
        return new EjecucionAccion(AccionCuenta.ANULAR, motivos, referencia, List.of(), codigoMensaje);
    }

    public static EjecucionAccion desbloquear(List<Long> lineas) {
        return new EjecucionAccion(AccionCuenta.DESBLOQUEAR_LINEAS, List.of(), null,
                                   lineas, null);
    }

    /**
     * @return si la acción es de las que no se pueden deshacer.
     *
     * <p>Anular lleva la cuenta a un estado terminal: no hay transición de
     * salida. Es el único caso, y de ahí que la pantalla tenga que pedir una
     * confirmación distinta.
     */
    public boolean esIrreversible() {
        return accion == AccionCuenta.ANULAR;
    }
}
