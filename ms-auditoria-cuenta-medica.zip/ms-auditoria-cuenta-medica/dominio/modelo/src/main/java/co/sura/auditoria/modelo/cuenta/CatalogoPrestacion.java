package co.sura.auditoria.modelo.cuenta;

/**
 * De qué catálogo sale el código de una prestación.
 *
 * <p>No es una lista cerrada por gusto: es lo que hay en producción, medido el
 * 13-oct-2026 sobre 1.000 líneas recientes — {@code CUPS} 506, {@code CUM} 194,
 * {@code SURACUPS} 129 y 68 líneas repartidas en <b>17</b> códigos distintos de
 * catálogo propio del prestador.
 *
 * <p>De ahí las dos cosas que este tipo existe para decir:
 *
 * <ul>
 *   <li><b>«Propio» no es un catálogo, es una familia.</b> Cada prestador tiene
 *       el suyo, nombrado por su NIT ({@code NI_8110078325_PROPIO},
 *       {@code NI_9003856281_MOSYMMQ_PROPIO}…). Agruparlos es lo que permite
 *       ofrecer «Propio» como una sola opción en vez de diecisiete.</li>
 *   <li><b>{@code SURACUPS} existe y pesa.</b> Es el tercero más frecuente, por
 *       delante de todos los propios juntos, aunque no suela nombrarse al pedir
 *       «CUPS, CUM y propio».</li>
 * </ul>
 *
 * <p>No hay ningún catálogo llamado {@code IUM}: no aparece en la muestra, y el
 * sistema de registro no publica un recurso de definiciones de catálogo
 * ({@code /generic/flexcodedefinitions} responde 404) donde pudiera comprobarse
 * otra cosa. Si algún día aparece, cae en {@link #OTRO} y sigue siendo
 * filtrable: por eso el agregado que puebla el filtro se calcula de los datos de
 * la cuenta y no de esta lista.
 */
public enum CatalogoPrestacion {

    CUPS,
    CUM,
    SURACUPS,

    /** Catálogo propio de un prestador. Agrupa todos los {@code NI_…_PROPIO}. */
    PROPIO,

    /**
     * Cualquier otro, incluido el caso en que la línea no trae catálogo.
     *
     * <p>Se ofrece igual en el filtro cuando la cuenta tiene líneas así: callarlo
     * dejaría filas imposibles de encontrar por este criterio.
     */
    OTRO;

    private static final String SUFIJO_PROPIO = "_PROPIO";

    /**
     * Clasifica el {@code flexCodeDefinitionCode} que publica el sistema de
     * registro.
     *
     * @param codigoExterno el valor crudo; {@code null} o en blanco dan {@link #OTRO}
     */
    public static CatalogoPrestacion de(String codigoExterno) {
        if (codigoExterno == null || codigoExterno.isBlank()) return OTRO;

        var normalizado = codigoExterno.trim().toUpperCase();
        if (normalizado.endsWith(SUFIJO_PROPIO)) return PROPIO;

        for (var catalogo : values()) {
            if (catalogo != PROPIO && catalogo != OTRO && catalogo.name().equals(normalizado)) {
                return catalogo;
            }
        }
        return OTRO;
    }

    /** Etiqueta para el auditor. El resto se llaman igual que su catálogo. */
    public String etiqueta() {
        return this == PROPIO ? "Propio del prestador"
             : this == OTRO   ? "Otro"
             : name();
    }
}
