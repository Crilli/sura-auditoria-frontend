package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Puerto de consulta hacia el sistema de registro.
 * Solo operaciones de <em>lectura</em> (Query side de CQRS).
 */
public interface PuertoConsultaCuentas {

    /**
     * Busca la cabecera de la cuenta por código de negocio. Devuelve vacío si no existe.
     *
     * <p>No trae las acciones disponibles: ver {@link #consultarAccionesDisponibles}.
     */
    Mono<CuentaMedica> buscarPorCodigo(CodigoCuenta codigo);

    /**
     * Qué puede hacer el auditor sobre la cuenta ahora mismo.
     *
     * <p>Va aparte de {@link #buscarPorCodigo} a propósito. El sistema de registro solo
     * publica las capacidades en la representación completa del claim, que es un orden
     * de magnitud más lenta que la cabecera proyectada; unirlas obligaba a la interfaz a
     * esperar por las acciones para pintar datos que ya tenía.
     *
     * <p>Devuelve {@link AccionesDisponibles#ninguna()} si la cuenta no existe: quien
     * decide sobre una cuenta inexistente no puede hacer nada con ella.
     */
    Mono<AccionesDisponibles> consultarAccionesDisponibles(CodigoCuenta codigo);

    /**
     * Lista el resumen paginado de líneas de una cuenta.
     *
     * @param incluirTotal si {@code true}, incluye el total de registros (solo primera página)
     */
    Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                   int tamanoPagina, boolean incluirTotal);

    /** Busca el detalle completo de una línea. Devuelve vacío si no existe. */
    Mono<LineaCuenta> buscarDetalleLinea(CodigoCuenta codigo, ReferenciaLinea referencia);

    /**
     * Recorre todas las líneas de la cuenta con contrapresión.
     * Uso interno; no para la interfaz de usuario.
     */
    Flux<ResumenLinea> recorrerTodasLasLineas(CodigoCuenta codigo, int tamanoPagina);

    /** Consulta el estado puntual del proceso de envío. */
    Mono<EstadoProceso> consultarEstadoProceso(CodigoCuenta codigo);
}
