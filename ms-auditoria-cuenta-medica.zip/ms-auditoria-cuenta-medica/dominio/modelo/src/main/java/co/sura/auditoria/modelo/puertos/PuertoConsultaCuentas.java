package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Puerto de consulta hacia el sistema de registro.
 * Solo operaciones de <em>lectura</em> (Query side de CQRS).
 */
public interface PuertoConsultaCuentas {

    /**
     * Busca la cabecera de la cuenta por código de negocio. Devuelve vacío si no existe.
     *
     * <p>No trae las acciones disponibles: ver {@link #consultarAccionesDisponibles}.
     */
    Mono<CuentaMedica> buscarPorCodigo(CodigoCuenta codigo);

    /**
     * Qué puede hacer el auditor sobre la cuenta ahora mismo.
     *
     * <p>Va aparte de {@link #buscarPorCodigo} a propósito. El sistema de registro solo
     * publica las capacidades en la representación completa del claim, que es un orden
     * de magnitud más lenta que la cabecera proyectada; unirlas obligaba a la interfaz a
     * esperar por las acciones para pintar datos que ya tenía.
     *
     * <p>Devuelve {@link AccionesDisponibles#ninguna()} si la cuenta no existe: quien
     * decide sobre una cuenta inexistente no puede hacer nada con ella.
     */
    Mono<AccionesDisponibles> consultarAccionesDisponibles(CodigoCuenta codigo);

    /**
     * Las acciones, preguntadas ahora mismo al sistema de registro, sin lo guardado.
     *
     * <p>{@link #consultarAccionesDisponibles} puede servirlas de una caché corta. Para pintar
     * eso basta; para <b>negar</b> una acción no: un dato desfasado convertiría en
     * «no disponible» algo que ya se puede hacer. Quien vaya a negar pregunta antes por aquí.
     * Por omisión es lo mismo que la otra, para quien no guarde nada.
     */
    default Mono<AccionesDisponibles> consultarAccionesFrescas(CodigoCuenta codigo) {
        return consultarAccionesDisponibles(codigo);
    }

    /**
     * Lista el resumen paginado de líneas de una cuenta, acotado por un filtro.
     *
     * <p>El filtro tiene dos mitades que se resuelven de forma distinta, y la
     * división la impone el sistema de registro, no el gusto: ver
     * {@link FiltroLineas}. Lo que él sabe filtrar viaja en la consulta; lo que
     * no —el catálogo de la prestación y el valor glosado— obliga a traer más
     * filas de las que caben en la página e ir descartando hasta llenarla.
     *
     * <p>De ahí una consecuencia que quien llama debe respetar: cuando
     * {@link FiltroLineas#exigeFiltradoLocal()} es cierto, <b>el total deja de
     * ser fiable</b> y esta operación devuelve la página sin él, aunque se pida.
     * El total que publica el sistema de registro cuenta las filas de antes de
     * aplicar lo que él no supo aplicar, y publicarlo sería afirmar un número
     * mayor que el de las filas que el auditor va a poder ver.
     *
     * @param incluirTotal si {@code true}, incluye el total de registros (solo
     *                     primera página, y solo si el filtro se empuja entero)
     * @param filtro       criterios de búsqueda; {@link FiltroLineas#NINGUNO}
     *                     para el listado completo
     */
    Mono<Pagina<ResumenLinea>> listarResumenLineas(CodigoCuenta codigo, Cursor cursor,
                                                   int tamanoPagina, boolean incluirTotal,
                                                   FiltroLineas filtro);

    /**
     * Una página de líneas localizada por desplazamiento.
     *
     * <p>La alternativa al recorrido por clave de
     * {@link #listarResumenLineas}: permite saltar a una página cualquiera y
     * saber cuántas hay, que es lo que la pantalla necesita para una cuenta de
     * miles de líneas.
     *
     * <p>Va aparte y no sustituye a la otra porque los pendientes siguen
     * paginando por clave; ver {@link PaginaDesplazada}.
     *
     * @param desplazamiento cuántas líneas saltar. Es sobre el resultado ya
     *     filtrado, no sobre el bruto
     */
    Mono<PaginaDesplazada<ResumenLinea>> listarResumenLineasPorDesplazamiento(
            CodigoCuenta codigo, int desplazamiento, int tamanoPagina, FiltroLineas filtro,
            OrdenLineas orden);

    /**
     * La línea que sigue a una dada <b>en el orden en que se revisan</b>.
     *
     * <p>Existe para «guardar y pasar a la siguiente». Lo resolvía el cliente
     * aprovechando el recorrido por clave: pedía una página de una fila usando
     * la referencia actual como cursor. Eso daba la siguiente <b>por
     * identificador</b>, que no es la siguiente que el auditor está leyendo —en
     * la cuenta mayor, las primeras filas por identificador son las secuencias
     * 2106, 2477, 2805…— así que el avance saltaba a una línea cualquiera. Aquí
     * la siguiente es la de número de línea inmediatamente mayor.
     *
     * <p>Devuelve vacío cuando la línea dada es la última de la cuenta, que es
     * respuesta y no error.
     */
    Mono<ResumenLinea> buscarLineaSiguiente(CodigoCuenta codigo, ReferenciaLinea referencia);

    /**
     * Con qué se puede acotar el listado de esta cuenta: los afiliados que
     * tiene, los catálogos de prestación que aparecen y los extremos de fecha y
     * de glosa.
     *
     * <p>Va en su propia operación por lo mismo que el agregado de motivos
     * pendientes: recorre la cuenta entera, así que no puede colgar de la página
     * —la tabla pintaría tarde— y no cambia al pasar de página, así que el
     * cliente lo pide una vez.
     */
    Mono<ResumenFiltrosLineas> resumirFiltrosDeLineas(CodigoCuenta codigo);

    /** Busca el detalle completo de una línea. Devuelve vacío si no existe. */
    Mono<LineaCuenta> buscarDetalleLinea(CodigoCuenta codigo, ReferenciaLinea referencia);

    /**
     * Recorre todas las líneas de la cuenta con contrapresión.
     * Uso interno; no para la interfaz de usuario.
     */
    Flux<ResumenLinea> recorrerTodasLasLineas(CodigoCuenta codigo, int tamanoPagina);

    /** Consulta el estado puntual del proceso de envío. */
    Mono<EstadoProceso> consultarEstadoProceso(CodigoCuenta codigo);
}
