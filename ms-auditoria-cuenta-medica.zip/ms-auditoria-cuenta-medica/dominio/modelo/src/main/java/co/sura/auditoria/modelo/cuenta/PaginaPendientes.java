package co.sura.auditoria.modelo.cuenta;

/**
 * Una página de pendientes junto al estado de la cuenta que la produjo.
 *
 * <p>El estado viaja con la página porque sin él no se puede decir si una fila
 * bloquea el envío, y quien pinta la página necesita saberlo. Va aquí y no como
 * un campo más de {@link MotivoPendiente} porque bloquear no es una propiedad de
 * la fila: es del par fila-estado, y meterlo en el registro invitaría a leerlo
 * fuera de contexto.
 */
public record PaginaPendientes(Pagina<MotivoPendiente> pagina, EstadoCuenta estado) {

    /** @return {@code true} si ese pendiente bloquea el envío en este estado. */
    public boolean bloquea(MotivoPendiente pendiente) {
        return pendiente.bloqueaEnvioEn(estado);
    }
}
