package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;

/**
 * Una glosa concreta aplicada a la línea.
 *
 * <p>Viene de {@code detallesGlosa}. Una línea puede acumular varias: el
 * {@code valorGlosado} de la línea es la suma de los {@code valor} de estas.
 * {@code generico} y {@code especifico} son la clasificación normativa
 * (p.ej. «Tarifas» / «Procedimiento o actividad») y {@code texto} es la
 * redacción completa que ve el prestador.
 */
public record DetalleGlosa(
        long identificador,
        /**
         * El causal que se eligió al glosar, p. ej. {@code AU0202}.
         *
         * <p>Estaba en el contrato del sistema de registro desde siempre y este proyecto no
         * lo pedía en la proyección, así que el auditor escribía un causal y al guardar
         * dejaba de verlo: la pantalla solo recibía las descripciones genérica y específica,
         * que no identifican cuál fue. Medido en producción el 2026-10-17.
         */
        String codigoGlosa,
        BigDecimal valor,
        String codigoNotaCredito,
        /** Importe de la nota crédito; {@code null} porque no toda glosa lleva una. */
        BigDecimal valorNotaCredito,
        String generico,
        String especifico,
        String texto
) {}
