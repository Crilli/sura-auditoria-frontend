package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;

/**
 * Una glosa concreta aplicada a la línea.
 *
 * <p>Viene de {@code detallesGlosa}. Una línea puede acumular varias: el
 * {@code valorGlosado} de la línea es la suma de los {@code valor} de estas.
 * {@code generico} y {@code especifico} son la clasificación normativa
 * (p.ej. «Tarifas» / «Procedimiento o actividad») y {@code texto} es la
 * redacción completa que ve el prestador.
 */
public record DetalleGlosa(
        long identificador,
        BigDecimal valor,
        String codigoNotaCredito,
        String generico,
        String especifico,
        String texto
) {}
