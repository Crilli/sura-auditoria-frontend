package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.util.List;

/**
 * Una línea de una versión abierta: lo de la grilla y, además, lo que se auditó en ella
 * (BUS-21.5). Todo es de solo lectura.
 *
 * <p>Va aparte de {@link LineaDeVersion} porque pesa: las novedades son casi todo el volumen de
 * una línea de versión —medido el 2026-10-21 sobre CM-12520 V2, unos 1,7 KB por línea con
 * ellas—, así que la grilla no las pide y se traen al abrir una sola línea.
 *
 * @param linea        la fila de la grilla, con su desglose de glosa
 * @param novedades    las de esa versión, agrupadas: ver {@link NovedadDeVersion#repeticiones()}
 * @param diagnosticos ordenados por su secuencia; el primero suele ser el principal
 * @param convenio     tarifas y cláusulas de entonces; nunca {@code null}
 * @param atencion     sala, vía de acceso y unidad de negocio; nunca {@code null}
 */
public record DetalleLineaDeVersion(
        LineaDeVersion linea,
        List<NovedadDeVersion> novedades,
        List<DiagnosticoDeVersion> diagnosticos,
        ConvenioDeVersion convenio,
        AtencionDeVersion atencion
) {

    public DetalleLineaDeVersion {
        novedades    = novedades    == null ? List.of() : List.copyOf(novedades);
        diagnosticos = diagnosticos == null ? List.of() : List.copyOf(diagnosticos);
        convenio     = convenio     == null
                ? new ConvenioDeVersion(null, null, null, null, List.of()) : convenio;
        atencion     = atencion     == null ? new AtencionDeVersion(null, null, null) : atencion;
    }

    /**
     * Una novedad de la línea tal como quedó en la versión.
     *
     * <p>Es otra cosa que la {@link Novedad} de la línea viva, en tres puntos medidos el
     * 2026-10-21 en UAT:
     * <ul>
     *   <li>el <b>texto ya viene resuelto</b> y congelado a la fecha de la foto —{@code
     *       CLA-FL-PPRI-003} llega con la edad y los límites puestos—, así que no hay plantilla
     *       ni valores que sustituir, y puede no coincidir con el catálogo de hoy;</li>
     *   <li><b>no hay autor ni fecha</b>: el histórico las firma todas con el usuario del
     *       sistema y la hora de la foto, de modo que no se publica quién la puso;</li>
     *   <li>el sistema de registro <b>repite novedades idénticas</b> —en la línea 1 de CM-4146
     *       V6, la 223-1A doce veces—. Se agrupan por código, texto y anulación, y
     *       {@code repeticiones} dice cuántas eran: doce filas iguales no informan más que una
     *       con «×12».</li>
     * </ul>
     *
     * @param severidad la del catálogo, traducida igual que la de la línea viva
     * @param origen    la etapa que la levantó ({@code MANUAL} si la puso una persona), tal cual
     * @param anulada   si se anuló ({@code overturned}): sigue en la foto, pero ya no frenaba
     */
    public record NovedadDeVersion(
            String codigo,
            Severidad severidad,
            String texto,
            String origen,
            boolean anulada,
            int repeticiones
    ) {}

    /** Un diagnóstico de la línea en esa versión; el tipo va en palabras («Diagnóstico principal»). */
    public record DiagnosticoDeVersion(
            Integer secuencia,
            String codigo,
            String descripcion,
            String tipo
    ) {}

    /**
     * El convenio que aplicó en esa versión.
     *
     * <p>Las tarifas llegan como una cadena —en la línea viva son un código con su descriptor—
     * y las cláusulas vienen dentro de la propia línea, sin consulta aparte.
     *
     * <p>No lleva número de contrato, aunque la línea viva sí: la foto de producción no lo guarda
     * (solo la de UAT). Publicarlo lo dejaría vacío en todas las líneas, como si se hubieran
     * tarifado sin contrato.
     *
     * @param clausulas las cláusulas de tarifación, en su orden: la tarifa de contrato y los
     *                  ajustes de regla (un monto negativo es un descuento). Su suma es el valor
     *                  convenido de la línea ({@code allowedAmount}); ninguna de ellas lo es sola
     */
    public record ConvenioDeVersion(
            String tarifaIss2000,
            String tarifaIss2001,
            String tarifaSoat,
            String homologoCups,
            List<ClausulaDeVersion> clausulas
    ) {
        public ConvenioDeVersion {
            clausulas = clausulas == null ? List.of() : List.copyOf(clausulas);
        }
    }

    /**
     * @param descripcion el texto de la cláusula: prestador, propuesta y manual tarifario
     * @param regla       el método o regla que la produjo ({@code ISS2000_COP}…)
     */
    public record ClausulaDeVersion(BigDecimal monto, String descripcion, String regla) {}

    /** @param uen la unidad estratégica de negocio con la que se aprobó la línea */
    public record AtencionDeVersion(String tipoSala, String viaAcceso, String uen) {}
}
