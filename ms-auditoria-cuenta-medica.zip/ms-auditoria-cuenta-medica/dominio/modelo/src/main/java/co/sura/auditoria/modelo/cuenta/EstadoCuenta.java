package co.sura.auditoria.modelo.cuenta;

/**
 * Estado de ciclo de vida de la cuenta médica.
 * Los valores corresponden a la traducción del vocabulario de OHI
 * definida en el diccionario canónico (§2.3 del documento de arquitectura).
 *
 * <p><b>Importante:</b> este enum es <em>informativo</em>.
 * Las transiciones válidas en cada instante las declara el sistema de registro
 * mediante enlaces HATEOAS, representados en {@link AccionesDisponibles}.
 * La única regla propia que se deduce de él es {@link #admiteCambiosDeDatos()},
 * y solo quita.
 */
public enum EstadoCuenta {
    INICIAL("Inicial"),
    DIGITACION("Digitación"),
    MODIFICACION("Modificación"),
    TARIFACION_MANUAL("Tarifación manual"),
    BENEFICIOS_MANUALES("Beneficios manuales"),
    ADJUDICACION_MANUAL("Adjudicación manual"),
    TARIFACION_ADJUDICACION_MANUAL("Tarifación y adjudicación manual"),
    TARIFACION_COMPLETA("Tarifación hecha"),
    BENEFICIOS_COMPLETOS("Beneficios hechos"),
    ADJUDICACION_COMPLETA("Adjudicación hecha"),
    TARIFACION_ADJUDICACION_COMPLETA("Tarifación y adjudicación hechas"),
    TARIFACION_FINALIZADA("Tarifación finalizada"),
    ENVIADA_A_PREPROCESO("Enviada a preproceso"),
    ENVIADA_A_TARIFACION("Enviada a tarifación"),
    FINALIZADA("Finalizada"),
    /**
     * {@code IN PROCESS} — la cuenta está corriendo por el motor.
     *
     * <p>Faltaba en el diccionario y caía en {@link #DESCONOCIDO}: son 137
     * cuentas en el entorno de pruebas, y en producción se contaron 38.
     */
    EN_PROCESO("En proceso"),
    /**
     * {@code CANCELLED} — anulada.
     *
     * <p><b>Es terminal:</b> de aquí no sale ninguna transición, y por eso
     * anular es la única acción sin vuelta atrás. Faltaba también.
     */
    ANULADA("Anulada"),
    /** Valor devuelto cuando OHI reporta un estado no mapeado en el diccionario. */
    DESCONOCIDO("Estado no reconocido");

    private final String enPalabras;

    EstadoCuenta(String enPalabras) {
        this.enPalabras = enPalabras;
    }

    /**
     * El estado como lo escribe la aplicación («Adjudicación manual»), para los mensajes
     * que lee el auditor.
     *
     * <p>Son, letra por letra, los de la columna {@code texto} de {@code NOMBRES} en
     * {@code estado-cuenta.model.ts} del frontend: la pantalla enseña el {@code mensaje} de un
     * error tal cual, y un estado escrito de dos maneras en la misma pantalla haría creer que
     * son dos estados distintos. Si se cambia uno, se cambia el otro.
     */
    public String enPalabras() {
        return enPalabras;
    }

    /** @return si la cuenta ya no admite ninguna transición. */
    public boolean esTerminal() {
        return this == ANULADA;
    }

    /**
     * Si en este estado se pueden cambiar los datos de la cuenta: solo en {@link #MODIFICACION}.
     *
     * <p>Son datos los valores, glosas y novedades de las líneas (una a una o en lote), las
     * novedades de la cabecera y los motivos de pendiente que se añaden. <b>No</b> lo son
     * resolver pendientes, enviar ni las acciones de estado: ésas las gobiernan los enlaces que
     * publica el sistema de registro, como siempre.
     *
     * <h3>Por qué no choca con ADR-003</h3>
     * El dominio no deduce del estado lo que se puede hacer: eso lo dice el sistema de registro
     * en {@link AccionesDisponibles}. Esto es otra cosa, una restricción de negocio propia del
     * 2026-10-21 que <b>solo quita</b> sobre lo que el sistema de registro permite y nunca
     * habilita nada. Hacía falta porque el sistema de registro no la impone: medido ese día,
     * acepta el parche de una línea con la cuenta en adjudicación manual. No se «corrige» en
     * nombre del ADR.
     *
     * <p>Con {@link #DESCONOCIDO} da falso: ante la duda, no se edita.
     */
    public boolean admiteCambiosDeDatos() {
        return this == MODIFICACION;
    }

    /**
     * En adjudicación manual, cualquier pendiente sin resolver bloquea el envío,
     * incluyendo los de {@code soloAdjudicacion = true}.
     * En los demás estados solo bloquean los que no son de sola adjudicación.
     */
    public boolean todoPendienteBloqueaEnvio() {
        return this == ADJUDICACION_MANUAL;
    }

    /**
     * Si un pendiente sin resolver bloquea el envío en este estado.
     *
     * <p>Es <b>la</b> regla de «bloqueante», y vive aquí porque bloquear no es
     * una propiedad del motivo: el mismo motivo bloquea o no según el estado en
     * que esté la cuenta. La usan {@link MotivoPendiente#bloqueaEnvioEn} para una
     * fila y la ACL para marcar el agregado por motivo, de modo que la pantalla y
     * la decisión de envío no puedan discrepar.
     *
     * @param soloAdjudicacion el {@code adjudicationOnly} del catálogo de OHI
     */
    public boolean bloqueaPendiente(boolean soloAdjudicacion) {
        return todoPendienteBloqueaEnvio() || !soloAdjudicacion;
    }
}
