package co.sura.auditoria.modelo.cuenta;

/**
 * Estado de ciclo de vida de la cuenta médica.
 * Los valores corresponden a la traducción del vocabulario de OHI
 * definida en el diccionario canónico (§2.3 del documento de arquitectura).
 *
 * <p><b>Importante:</b> este enum es <em>informativo</em>.
 * Las transiciones válidas en cada instante las declara el sistema de registro
 * mediante enlaces HATEOAS, representados en {@link AccionesDisponibles}.
 */
public enum EstadoCuenta {
    INICIAL,
    DIGITACION,
    MODIFICACION,
    TARIFACION_MANUAL,
    BENEFICIOS_MANUALES,
    ADJUDICACION_MANUAL,
    TARIFACION_ADJUDICACION_MANUAL,
    TARIFACION_COMPLETA,
    BENEFICIOS_COMPLETOS,
    ADJUDICACION_COMPLETA,
    TARIFACION_ADJUDICACION_COMPLETA,
    TARIFACION_FINALIZADA,
    ENVIADA_A_PREPROCESO,
    ENVIADA_A_TARIFACION,
    FINALIZADA,
    /** Valor devuelto cuando OHI reporta un estado no mapeado en el diccionario. */
    DESCONOCIDO;

    /**
     * Estados en los que el auditor puede intervenir manualmente
     * (editar líneas, resolver pendientes, enviar).
     */
    public boolean permiteIntervencionManual() {
        return this == MODIFICACION
            || this == TARIFACION_MANUAL
            || this == BENEFICIOS_MANUALES
            || this == ADJUDICACION_MANUAL
            || this == TARIFACION_ADJUDICACION_MANUAL;
    }

    /**
     * En adjudicación manual, cualquier pendiente sin resolver bloquea el envío,
     * incluyendo los de {@code soloAdjudicacion = true}.
     * En los demás estados solo bloquean los que no son de sola adjudicación.
     */
    public boolean todoPendienteBloqueaEnvio() {
        return this == ADJUDICACION_MANUAL;
    }
}
