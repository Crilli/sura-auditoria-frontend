package co.sura.auditoria.modelo.cuenta;

/**
 * Un motivo distinto de los que tiene pendientes la cuenta, con lo justo para
 * decidir si filtrar por él sin tener que filtrar primero.
 *
 * <p>Existe porque el listado de pendientes se pagina: con 3.507 pendientes en
 * la cuenta mayor medida, el cliente ya no ve la lista entera y no puede
 * agrupar por su cuenta. El agregado se calcula aquí, recorriendo la cuenta una
 * vez con la proyección estrecha, y viaja como un puñado de filas —24 en el peor
 * caso medido— en vez de miles.
 *
 * <p>Lleva los dos lados de «bloqueante»: el indicador crudo del catálogo
 * ({@code soloAdjudicacion}) y la conclusión ya sacada contra el estado de la
 * cuenta ({@code bloqueante}). El segundo es lo que se pinta; el primero es lo
 * que explica por qué, y por qué el mismo motivo puede no bloquear en otra
 * cuenta.
 *
 * @param codigo           el {@code pendReason.code} de OHI
 * @param descripcion      texto del catálogo; {@code null} si OHI no lo publica
 * @param sinResolver      filas sin resolver del motivo, de cabecera y de línea
 * @param lineasAfectadas  cuántas líneas distintas lo tienen; 0 si es solo de cabecera
 * @param enCabecera       {@code true} si el motivo está también —o solo— en la cabecera
 * @param soloAdjudicacion el {@code adjudicationOnly} del catálogo de OHI
 * @param bloqueante       si impide enviar la cuenta en el estado en que está hoy
 */
public record ResumenMotivoPendiente(
        String codigo,
        String descripcion,
        int sinResolver,
        int lineasAfectadas,
        boolean enCabecera,
        boolean soloAdjudicacion,
        boolean bloqueante
) {}
