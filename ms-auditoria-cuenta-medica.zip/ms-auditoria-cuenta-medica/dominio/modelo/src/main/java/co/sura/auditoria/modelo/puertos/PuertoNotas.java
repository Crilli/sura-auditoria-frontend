package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import reactor.core.publisher.Mono;

/** Puerto para agregar notas de auditoría a la cuenta en el sistema de registro. */
public interface PuertoNotas {

    /**
     * Agrega una nota textual a la cuenta.
     *
     * @param codigo código de la cuenta médica
     * @param autor  identificador del auditor
     * @param texto  justificación o nota libre
     */
    Mono<Void> agregarNota(CodigoCuenta codigo, String autor, String texto);
}
