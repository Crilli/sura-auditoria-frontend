package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Comando de edición de una línea de cuenta médica.
 *
 * <p>Usa {@link Optional#empty()} para los campos que <em>no</em> deben modificarse.
 * Un {@link Optional} presente significa «asignar este valor».
 * Este enfoque evita la ambigüedad entre «no envío el campo» y «envío nulo».
 *
 * <p>El juego de campos es exactamente el que OHI abre a escritura en la definición
 * {@code claimline} de {@code GET /claimsupdate/definition}. Lo que no está aquí es
 * porque OHI no lo acepta —{@code coveredAmount} y {@code coveredNumberOfUnits} son
 * la salida del motor de coberturas—, porque es derivado (descripción de la
 * prestación, nombre del prestador, UEN, tarifación del convenio) o porque exige
 * elegir de un catálogo y un texto libre dejaría escribir un código inválido (los
 * flex code y las referencias). El afiliado se deja fuera por decisión de negocio,
 * no por el contrato: ver {@code SolicitudGuardarLinea}.
 */
public record EdicionLinea(
        ReferenciaLinea referencia,
        Version versionEsperada,
        Optional<BigDecimal> valorAutorizado,
        Optional<BigDecimal> unidadesAutorizadas,
        Optional<Boolean> conservarBeneficios,
        Optional<Boolean> conservarTarifacion,
        /**
         * Texto libre que el auditor deja al glosar: {@code observacionesGlosa},
         * cadena de hasta 1000 caracteres en el contrato {@code /claimsupdate}.
         */
        Optional<String> observacionesGlosa,
        /** Lo facturado por el prestador. Se corrige cuando la factura venía mal digitada. */
        Optional<BigDecimal> valorCargado,
        Optional<BigDecimal> unidadesCargadas,
        /** Lo descontado en auditoría. El desglose por causal vive en la lista de glosas. */
        Optional<BigDecimal> valorGlosado,
        Optional<String> codigoAutorizacion,
        Optional<LocalDate> fechaInicio,
        Optional<LocalDate> fechaFin,
        /** Código que el prestador facturó y no está en el catálogo, y su definición. */
        Optional<String> codigoNoDefinido,
        Optional<String> codigoNoDefinidoDef,
        /** Descripción literal de la prestación tal como venía en el archivo RIPS. */
        Optional<String> descripcionRips,
        Optional<String> numeroContrato,
        Optional<String> homologoCups,
        Optional<String> codigoUnicoContratoSiifa,
        Optional<String> codigoSiniestro,
        /**
         * Altas y bajas del desglose de glosa.
         *
         * <p>Lista y no {@code Optional<List<…>>}: la ausencia de cambios es la
         * lista vacía, no un envoltorio vacío, y así no hay dos formas de decir
         * «no toques el desglose».
         */
        List<CambioGlosa> glosas,
        /**
         * Altas y bajas de novedades de la línea.
         *
         * <p>Misma forma que {@link #glosas} y por el mismo motivo. Lo que no
         * comparten es el cálculo: la novedad no tiene importe, así que no hay
         * ningún total que cuadrar después de aplicarlas.
         */
        List<CambioNovedad> novedades,
        ModoRecalculo modoRecalculo
) {

    public EdicionLinea {
        glosas = glosas == null ? List.of() : List.copyOf(glosas);
        novedades = novedades == null ? List.of() : List.copyOf(novedades);
    }

    /** Si la edición toca el desglose de glosas. */
    public boolean tocaGlosas() {
        return !glosas.isEmpty();
    }

    /** Si la edición agrega o quita novedades. */
    public boolean tocaNovedades() {
        return !novedades.isEmpty();
    }

    /**
     * El valor glosado que debe quedar en la línea tras aplicar estos cambios.
     *
     * <p>Se calcula, no se recibe: el total de la línea es por definición la
     * suma de su desglose, y dejar que el cliente mande los dos por separado
     * permite que se contradigan. Las glosas sin importe cuentan como cero.
     *
     * @param actuales el desglose tal como está hoy en el sistema de registro
     */
    public BigDecimal valorGlosadoResultante(List<DetalleGlosa> actuales) {
        var bajas = glosas.stream().filter(CambioGlosa::esBaja)
                .map(CambioGlosa::identificador).collect(java.util.stream.Collectors.toSet());

        var queQuedan = actuales.stream()
                .filter(d -> !bajas.contains(d.identificador()))
                .map(DetalleGlosa::valor)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        var queEntran = glosas.stream().filter(CambioGlosa::esAlta)
                .map(CambioGlosa::valor)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return queQuedan.add(queEntran).setScale(2, java.math.RoundingMode.HALF_UP);
    }

    /**
     * Las bajas que apuntan a una glosa que la línea no tiene.
     *
     * <p>Se comprueba antes de mandar nada: el sistema de registro aceptaría el
     * parche y se limitaría a no borrar nada, de modo que el auditor vería un
     * guardado correcto y la glosa seguiría ahí.
     */
    public List<Long> bajasInexistentes(List<DetalleGlosa> actuales) {
        var existentes = actuales.stream().map(DetalleGlosa::identificador)
                .collect(java.util.stream.Collectors.toSet());
        return glosas.stream().filter(CambioGlosa::esBaja)
                .map(CambioGlosa::identificador)
                .filter(id -> !existentes.contains(id))
                .toList();
    }
    /**
     * La misma edición con el valor glosado impuesto.
     *
     * <p>Lo usa el caso de uso para cuadrar el total con el desglose después de
     * aplicar altas y bajas. No es un «setter»: devuelve otra edición, porque la
     * que llegó del cliente describe lo que él pidió y conviene no reescribirla.
     */
    public EdicionLinea conValorGlosado(BigDecimal total) {
        return new EdicionLinea(referencia, versionEsperada, valorAutorizado, unidadesAutorizadas,
                conservarBeneficios, conservarTarifacion, observacionesGlosa,
                valorCargado, unidadesCargadas, Optional.ofNullable(total), codigoAutorizacion,
                fechaInicio, fechaFin, codigoNoDefinido, codigoNoDefinidoDef, descripcionRips,
                numeroContrato, homologoCups, codigoUnicoContratoSiifa, codigoSiniestro,
                glosas, novedades, modoRecalculo);
    }

    /** @return {@code true} si ningún campo fue enviado para modificar. */
    public boolean sinCambios() {
        return camposEditables().allMatch(Optional::isEmpty)
            && glosas.isEmpty()
            && novedades.isEmpty();
    }

    // Aquí vivían `bajasDeNovedadInexistentes` y `bajasDeNovedadAjena`. Se
    // fueron a `ComprobadorDeNovedades` en cuanto la cabecera de la cuenta
    // necesitó las mismas comprobaciones: dejarlas aquí era además dejar dos
    // formas de decidir lo mismo, y la que nadie llama es la que se queda
    // atrás cuando la regla cambia.

    /**
     * @return {@code true} si la edición modifica valores monetarios o de unidades,
     *         lo que afecta consumos de límites de prestador.
     */
    public boolean afectaCalculoFinanciero() {
        return valorAutorizado.isPresent()
            || unidadesAutorizadas.isPresent()
            || valorCargado.isPresent()
            || unidadesCargadas.isPresent()
            || valorGlosado.isPresent()
            // Tocar el desglose mueve el total glosado de la línea, que es
            // justamente un valor monetario.
            || tocaGlosas();
    }

    /**
     * Todos los campos modificables en un solo sitio: así {@link #sinCambios()}
     * no se queda atrás cuando el contrato de OHI abra un campo más.
     */
    private Stream<Optional<?>> camposEditables() {
        return Stream.of(
                valorAutorizado, unidadesAutorizadas,
                conservarBeneficios, conservarTarifacion,
                observacionesGlosa,
                valorCargado, unidadesCargadas, valorGlosado,
                codigoAutorizacion,
                fechaInicio, fechaFin,
                codigoNoDefinido, codigoNoDefinidoDef, descripcionRips,
                numeroContrato, homologoCups, codigoUnicoContratoSiifa,
                codigoSiniestro);
    }
}
