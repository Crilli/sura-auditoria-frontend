package co.sura.auditoria.modelo.cuenta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Comando de edición de una línea de cuenta médica.
 *
 * <p>Usa {@link Optional#empty()} para los campos que <em>no</em> deben modificarse.
 * Un {@link Optional} presente significa «asignar este valor».
 * Este enfoque evita la ambigüedad entre «no envío el campo» y «envío nulo».
 *
 * <p>El juego de campos es exactamente el que OHI abre a escritura en la definición
 * {@code claimline} de {@code GET /claimsupdate/definition}. Lo que no está aquí es
 * porque OHI no lo acepta —{@code coveredAmount} y {@code coveredNumberOfUnits} son
 * la salida del motor de coberturas—, porque es derivado (descripción de la
 * prestación, nombre del prestador, UEN, tarifación del convenio) o porque exige
 * elegir de un catálogo y un texto libre dejaría escribir un código inválido (los
 * flex code y las referencias). El afiliado se deja fuera por decisión de negocio,
 * no por el contrato: ver {@code SolicitudGuardarLinea}.
 */
public record EdicionLinea(
        ReferenciaLinea referencia,
        Version versionEsperada,
        Optional<BigDecimal> valorAutorizado,
        Optional<BigDecimal> unidadesAutorizadas,
        Optional<Boolean> conservarBeneficios,
        Optional<Boolean> conservarTarifacion,
        /**
         * Texto libre que el auditor deja al glosar: {@code observacionesGlosa},
         * cadena de hasta 1000 caracteres en el contrato {@code /claimsupdate}.
         */
        Optional<String> observacionesGlosa,
        /** Lo facturado por el prestador. Se corrige cuando la factura venía mal digitada. */
        Optional<BigDecimal> valorCargado,
        Optional<BigDecimal> unidadesCargadas,
        /** Lo descontado en auditoría. El desglose por causal vive en la lista de glosas. */
        Optional<BigDecimal> valorGlosado,
        Optional<String> codigoAutorizacion,
        Optional<LocalDate> fechaInicio,
        Optional<LocalDate> fechaFin,
        /** Código que el prestador facturó y no está en el catálogo, y su definición. */
        Optional<String> codigoNoDefinido,
        Optional<String> codigoNoDefinidoDef,
        /** Descripción literal de la prestación tal como venía en el archivo RIPS. */
        Optional<String> descripcionRips,
        Optional<String> numeroContrato,
        Optional<String> homologoCups,
        Optional<String> codigoUnicoContratoSiifa,
        Optional<String> codigoSiniestro,
        ModoRecalculo modoRecalculo
) {
    /** @return {@code true} si ningún campo fue enviado para modificar. */
    public boolean sinCambios() {
        return camposEditables().allMatch(Optional::isEmpty);
    }

    /**
     * @return {@code true} si la edición modifica valores monetarios o de unidades,
     *         lo que afecta consumos de límites de prestador.
     */
    public boolean afectaCalculoFinanciero() {
        return valorAutorizado.isPresent()
            || unidadesAutorizadas.isPresent()
            || valorCargado.isPresent()
            || unidadesCargadas.isPresent()
            || valorGlosado.isPresent();
    }

    /**
     * Todos los campos modificables en un solo sitio: así {@link #sinCambios()}
     * no se queda atrás cuando el contrato de OHI abra un campo más.
     */
    private Stream<Optional<?>> camposEditables() {
        return Stream.of(
                valorAutorizado, unidadesAutorizadas,
                conservarBeneficios, conservarTarifacion,
                observacionesGlosa,
                valorCargado, unidadesCargadas, valorGlosado,
                codigoAutorizacion,
                fechaInicio, fechaFin,
                codigoNoDefinido, codigoNoDefinidoDef, descripcionRips,
                numeroContrato, homologoCups, codigoUnicoContratoSiifa,
                codigoSiniestro);
    }
}
