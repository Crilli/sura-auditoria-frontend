package co.sura.auditoria.modelo.puertos;

import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Puerto de lectura del catálogo de motivos de desfinalización y anulación.
 *
 * <p>Aparte de {@link PuertoConsultaCuentas} porque el catálogo no es de ninguna
 * cuenta: es global y cambia muy de tarde en tarde. Son dieciséis en el entorno
 * de pruebas, así que se trae entero.
 */
public interface PuertoCatalogoMotivos {

    Mono<List<MotivoDesfinalizacion>> listar();
}
