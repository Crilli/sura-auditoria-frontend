package co.sura.auditoria.modelo.cuenta;

/**
 * Acciones que el sistema de registro puede habilitar sobre una cuenta médica.
 * Se corresponden con los {@code rel} HATEOAS publicados por OHI (§2.4 del documento).
 *
 * <p>El dominio declara estas acciones con semántica de negocio en español.
 * La traducción a los {@code rel} externos vive exclusivamente en la ACL.
 */
public enum AccionCuenta {
    ENVIAR,
    SEGUIR_PROCESO,
    RESOLVER_PENDIENTE,
    RESOLVER_PENDIENTE_LINEA,
    DEVOLVER_A_MODIFICACION,
    DEVOLVER_A_BENEFICIOS_MANUALES,
    DEVOLVER_A_TARIFACION_MANUAL,
    REVERTIR_FINALIZACION,
    DESBLOQUEAR_LINEAS,
    DESHACER_REEMPLAZOS,
    ANULAR
}
