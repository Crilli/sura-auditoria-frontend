package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * El modelo del buscador: el filtro, la fila de resultados, las versiones y la foto de una.
 *
 * <p>Los datos de cuenta son códigos y números de factura de prueba; ninguno identifica a una
 * persona.
 */
@DisplayName("Modelo de la búsqueda de cuentas")
class BusquedaDeCuentasModeloTest {

    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-57944424433");

    @Nested
    @DisplayName("FiltroCuentas")
    class Filtro {

        @Test
        @Tag("BUS-03")
        @DisplayName("recorta los espacios del número de factura y del radicado")
        void recorta() {
            var filtro = new FiltroCuentas("  JONATHAN201 ", " CM-9442 ");

            assertThat(filtro.numeroFactura()).isEqualTo("JONATHAN201");
            assertThat(filtro.radicado()).isEqualTo("CM-9442");
            assertThat(filtro.vacio()).isFalse();
        }

        @Test
        @Tag("BUS-01")
        @DisplayName("un criterio en blanco no es un criterio: el filtro queda vacío")
        void enBlancoEsVacio() {
            // Si «   » contara como criterio, la búsqueda saldría sin acotar y recorrería
            // las once mil cuentas del entorno.
            assertThat(new FiltroCuentas("   ", "").vacio()).isTrue();
            assertThat(new FiltroCuentas(null, null).vacio()).isTrue();
        }

        @Test
        @Tag("BUS-05")
        @DisplayName("basta uno de los dos criterios")
        void bastaUno() {
            assertThat(new FiltroCuentas(null, "CM-9442").vacio()).isFalse();
            assertThat(new FiltroCuentas("JONATHAN201", null).vacio()).isFalse();
        }
    }

    @Nested
    @DisplayName("ResumenCuenta")
    class Resumen {

        private ResumenCuenta conEstado(EstadoCuenta estado, String literal) {
            return new ResumenCuenta(CODIGO, "JONATHAN201", LocalDate.of(2026, 10, 1),
                                     "800000000", "Prestador de prueba",
                                     new BigDecimal("8800000"), estado, literal);
        }

        @Test
        @Tag("BUS-19")
        @DisplayName("un estado conocido se pinta en el vocabulario del auditor")
        void estadoConocido() {
            assertThat(conEstado(EstadoCuenta.ADJUDICACION_MANUAL, "MANUAL ADJUDICATION")
                    .estadoLegible()).isEqualTo("ADJUDICACION_MANUAL");
        }

        @Test
        @Tag("BUS-19")
        @DisplayName("un estado que el diccionario no traduce se enseña tal cual")
        void estadoDesconocidoSeEnsena() {
            assertThat(conEstado(EstadoCuenta.DESCONOCIDO, "IN PROCESS").estadoLegible())
                    .isEqualTo("IN PROCESS");
        }

        @Test
        @Tag("BUS-19")
        @DisplayName("si tampoco hay literal, se dice que es desconocido en vez de dejarlo en blanco")
        void sinLiteral() {
            assertThat(conEstado(EstadoCuenta.DESCONOCIDO, null).estadoLegible())
                    .isEqualTo("DESCONOCIDO");
        }
    }

    @Nested
    @DisplayName("VersionCuenta")
    class Versiones {

        private VersionCuenta version(int numero, String valor) {
            return new VersionCuenta(CODIGO, numero, LocalDate.of(2026, 9, numero),
                                     new BigDecimal(valor), "FINALIZADA",
                                     Instant.parse("2026-09-0" + numero + "T10:00:00Z"));
        }

        @Test
        @Tag("BTN-04")
        @DisplayName("la vigente es la de mayor número, llegue en el orden que llegue")
        void vigenteEsLaMayor() {
            var vigente = VersionCuenta.vigente(List.of(
                    version(2, "6000000"), version(3, "8800000"), version(1, "4000001")));

            assertThat(vigente).map(VersionCuenta::numero).contains(3);
            assertThat(vigente).map(VersionCuenta::valor).contains(new BigDecimal("8800000"));
        }

        @Test
        @Tag("BUS-13")
        @DisplayName("una cuenta sin transmitir no tiene vigente, y eso no es un fallo")
        void sinVersiones() {
            assertThat(VersionCuenta.vigente(List.of())).isEmpty();
            assertThat(VersionCuenta.vigente(null)).isEmpty();
        }
    }

    @Nested
    @DisplayName("FotoVersion")
    class Foto {

        private FotoVersion foto(List<FotoVersion.EstadoDeVersion> historial) {
            return new FotoVersion(CODIGO, 2, LocalDate.of(2026, 9, 2), "JONATHAN201",
                                   "Prestador de prueba", new BigDecimal("6000000"),
                                   new BigDecimal("6000000"), new BigDecimal("5000000"),
                                   new BigDecimal("5000000"), new BigDecimal("1000000"),
                                   BigDecimal.ZERO, historial);
        }

        @Test
        @Tag("BUS-20")
        @DisplayName("el estado actual de la versión es el último de su historial")
        void estadoActual() {
            var foto = foto(List.of(
                    new FotoVersion.EstadoDeVersion("ADJUDICACION_MANUAL", Instant.parse("2026-09-02T10:00:00Z")),
                    new FotoVersion.EstadoDeVersion("FINALIZADA", Instant.parse("2026-09-03T10:00:00Z"))));

            assertThat(foto.estadoActual()).isEqualTo("FINALIZADA");
        }

        @Test
        @Tag("BUS-20")
        @DisplayName("sin historial no hay estado, y no revienta")
        void sinHistorial() {
            assertThat(foto(null).historial()).isEmpty();
            assertThat(foto(null).estadoActual()).isNull();
        }

        @Test
        @Tag("BUS-20")
        @DisplayName("es una foto: cambiar la lista de origen no la altera")
        void inmutable() {
            var origen = new ArrayList<FotoVersion.EstadoDeVersion>();
            origen.add(new FotoVersion.EstadoDeVersion("FINALIZADA", Instant.parse("2026-09-03T10:00:00Z")));
            var foto = foto(origen);

            origen.clear();

            assertThat(foto.historial()).hasSize(1);
        }
    }
}
