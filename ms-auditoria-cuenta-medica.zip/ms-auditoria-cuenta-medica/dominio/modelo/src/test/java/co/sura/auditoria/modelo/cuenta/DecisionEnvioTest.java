package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("DecisionEnvio")
class DecisionEnvioTest {

    @Test
    @DisplayName("aceptar no necesita novedad y es válida")
    void aceptarNoNecesitaNovedad() {
        var decision = DecisionEnvio.aceptar();

        assertThat(decision.decision()).isEqualTo(DecisionEnvio.Decision.ACEPTAR);
        assertThat(decision.codigoNovedad()).isEmpty();
        assertThat(decision.esValida()).isTrue();
    }

    @Test
    @DisplayName("aceptar con novedad informativa conserva el código y sigue siendo válida")
    void aceptarConNovedadConservaElCodigo() {
        var decision = DecisionEnvio.aceptarConNovedad("SURA-INF-001");

        assertThat(decision.decision()).isEqualTo(DecisionEnvio.Decision.ACEPTAR);
        assertThat(decision.codigoNovedad()).contains("SURA-INF-001");
        assertThat(decision.esValida()).isTrue();
    }

    @Test
    @DisplayName("denegar exige un código bloqueante")
    void denegarExigeCodigoBloqueante() {
        var decision = DecisionEnvio.denegar("SURA-CHK-063");

        assertThat(decision.decision()).isEqualTo(DecisionEnvio.Decision.DENEGAR);
        assertThat(decision.codigoNovedad()).contains("SURA-CHK-063");
        assertThat(decision.esValida()).isTrue();
    }

    @Test
    @DisplayName("denegar SIN código no es una decisión válida: hay que decir por qué se deniega")
    void denegarSinCodigoNoEsValida() {
        var invalida = new DecisionEnvio(DecisionEnvio.Decision.DENEGAR, Optional.empty());

        assertThat(invalida.esValida()).isFalse();
    }

    @Test
    @DisplayName("la fábrica admite un código nulo y produce la decisión inválida, sin reventar")
    void laFabricaAdmiteCodigoNuloYProduceDecisionInvalida() {
        // Con Optional.of esto lanzaba NullPointerException al mapear la solicitud,
        // y el cliente recibía un 500 en vez del 400 que explica qué falta.
        var denegarSinCodigo = DecisionEnvio.denegar(null);

        assertThat(denegarSinCodigo.decision()).isEqualTo(DecisionEnvio.Decision.DENEGAR);
        assertThat(denegarSinCodigo.codigoNovedad()).isEmpty();
        assertThat(denegarSinCodigo.esValida()).isFalse();
    }

    @Test
    @DisplayName("solo al aceptar hay que verificar los pendientes")
    void soloAlAceptarHayQueVerificarPendientes() {
        assertThat(DecisionEnvio.aceptar().requiereVerificarPendientes()).isTrue();
        assertThat(DecisionEnvio.aceptarConNovedad("X").requiereVerificarPendientes()).isTrue();
        assertThat(DecisionEnvio.denegar("X").requiereVerificarPendientes()).isFalse();
    }
}
