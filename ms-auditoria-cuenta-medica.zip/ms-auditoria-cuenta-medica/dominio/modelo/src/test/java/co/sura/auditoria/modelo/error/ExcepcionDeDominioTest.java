package co.sura.auditoria.modelo.error;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

@DisplayName("ExcepcionDeDominio")
class ExcepcionDeDominioTest {

    @Test
    @DisplayName("transporta el error de dominio sin perderlo")
    void transportaElErrorSinPerderlo() {
        var error = new ErrorDeDominio.CuentaNoEncontrada("CM-108800618430");

        assertThat(ExcepcionDeDominio.de(error).error()).isSameAs(error);
    }

    @Test
    @DisplayName("su mensaje es el nombre del error, para que el log diga de qué se trata")
    void suMensajeEsElNombreDelError() {
        assertThat(ExcepcionDeDominio.de(new ErrorDeDominio.CuentaNoEncontrada("CM-1")))
                .hasMessage("CuentaNoEncontrada");
    }

    @Test
    @DisplayName("es no comprobada: no obliga a declararla en cada firma del dominio")
    void esNoComprobada() {
        assertThat(RuntimeException.class)
                .isAssignableFrom(ExcepcionDeDominio.class);
    }

    @Test
    @DisplayName("el constructor y la fábrica producen lo mismo")
    void elConstructorYLaFabricaProducenLoMismo() {
        var error = new ErrorDeDominio.LineaNoEncontrada(148111592284L);

        assertThat(ExcepcionDeDominio.de(error).error())
                .isEqualTo(new ExcepcionDeDominio(error).error());
    }

    @ParameterizedTest
    @MethodSource("todosLosErrores")
    @DisplayName("cualquier error de dominio se puede envolver y recuperar")
    void cualquierErrorSePuedeEnvolverYRecuperar(ErrorDeDominio error) {
        var excepcion = ExcepcionDeDominio.de(error);

        assertThat(excepcion.error()).isEqualTo(error);
        assertThat(excepcion.getMessage()).isEqualTo(error.getClass().getSimpleName());
    }

    static java.util.stream.Stream<ErrorDeDominio> todosLosErrores() {
        return java.util.stream.Stream.of(
                new ErrorDeDominio.CuentaNoEncontrada("CM-1"),
                new ErrorDeDominio.LineaNoEncontrada(1L),
                new ErrorDeDominio.AccionNoDisponible("CM-1", "ENVIAR"),
                new ErrorDeDominio.PendientesBloqueanEnvio("CM-1", 3),
                new ErrorDeDominio.ModificacionConcurrente("linea", 26L),
                new ErrorDeDominio.SinPermiso("enviar", "sin rol"),
                new ErrorDeDominio.LimiteAprobacionExcedido("CM-1"),
                new ErrorDeDominio.LineaNoEditable(1L, "bloqueada"),
                new ErrorDeDominio.DecisionEnvioInvalida("sin código"),
                new ErrorDeDominio.EdicionSinCambios(1L),
                new ErrorDeDominio.SistemaRegistroNoDisponible("timeout"),
                // El rechazo de una línea dentro de un lote: lleva la POSICIÓN dentro del
                // parche, que es lo que el sistema de registro informa en «o:errorPath».
                new ErrorDeDominio.LineaDelLoteRechazada(1, "la línea está mal"));
    }

    @Test
    @DisplayName("el catálogo es sellado: añadir un error obliga a revisar quien lo traduce a HTTP")
    void elCatalogoEsSellado() {
        assertThat(ErrorDeDominio.class.isSealed()).isTrue();
        assertThat(ErrorDeDominio.class.getPermittedSubclasses()).hasSize(13);
    }

    @org.junit.jupiter.api.Test
    @org.junit.jupiter.api.Tag("OPE-11")
    @org.junit.jupiter.api.DisplayName("«aplicado sin releer» lleva qué se escribió y por qué no se pudo releer")
    void aplicadoSinRelectura() {
        var error = new ErrorDeDominio.AplicadoSinRelectura("linea:148111592284", "timeout");
        var excepcion = ExcepcionDeDominio.de(error);

        org.assertj.core.api.Assertions.assertThat(excepcion.error()).isEqualTo(error);
        org.assertj.core.api.Assertions.assertThat(error.recurso()).isEqualTo("linea:148111592284");
        org.assertj.core.api.Assertions.assertThat(error.detalle()).isEqualTo("timeout");
    }
}
