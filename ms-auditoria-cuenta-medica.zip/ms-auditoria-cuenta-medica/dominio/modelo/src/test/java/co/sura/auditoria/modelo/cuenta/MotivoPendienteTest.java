package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("MotivoPendiente")
class MotivoPendienteTest {

    private static MotivoPendiente pendiente(boolean resuelto, boolean soloAdjudicacion) {
        return new MotivoPendiente(1L, "AUD01", "Auditoría médica", resuelto, soloAdjudicacion,
                NivelPendiente.CABECERA, null, null, new Version(1L));
    }

    @ParameterizedTest
    @EnumSource(EstadoCuenta.class)
    @DisplayName("un pendiente ya resuelto no bloquea en ningún estado")
    void unPendienteResueltoNoBloqueaNunca(EstadoCuenta estado) {
        assertThat(pendiente(true, true).bloqueaEnvioEn(estado)).isFalse();
        assertThat(pendiente(true, false).bloqueaEnvioEn(estado)).isFalse();
    }

    @ParameterizedTest
    @EnumSource(EstadoCuenta.class)
    @DisplayName("un pendiente vivo que no es solo de adjudicación bloquea en cualquier estado")
    void unPendienteGeneralBloqueaSiempre(EstadoCuenta estado) {
        assertThat(pendiente(false, false).bloqueaEnvioEn(estado)).isTrue();
    }

    @Test
    @DisplayName("un pendiente solo de adjudicación bloquea en ADJUDICACION_MANUAL")
    void soloAdjudicacionBloqueaEnAdjudicacionManual() {
        assertThat(pendiente(false, true).bloqueaEnvioEn(EstadoCuenta.ADJUDICACION_MANUAL))
                .isTrue();
    }

    @Test
    @DisplayName("un pendiente solo de adjudicación NO bloquea fuera de ADJUDICACION_MANUAL")
    void soloAdjudicacionNoBloqueaFueraDeAdjudicacionManual() {
        assertThat(pendiente(false, true).bloqueaEnvioEn(EstadoCuenta.MODIFICACION)).isFalse();
        assertThat(pendiente(false, true).bloqueaEnvioEn(EstadoCuenta.FINALIZADA)).isFalse();
    }

    @Test
    @DisplayName("un pendiente de línea lleva su referencia y su número")
    void unPendienteDeLineaLlevaSuReferencia() {
        var deLinea = new MotivoPendiente(2L, "GLO01", "Glosa", false, false,
                NivelPendiente.LINEA, new ReferenciaLinea(148111592284L), 3, new Version(1L));

        assertThat(deLinea.nivel()).isEqualTo(NivelPendiente.LINEA);
        assertThat(deLinea.referenciaLinea().valor()).isEqualTo(148111592284L);
        assertThat(deLinea.numeroLinea()).isEqualTo(3);
    }
}
