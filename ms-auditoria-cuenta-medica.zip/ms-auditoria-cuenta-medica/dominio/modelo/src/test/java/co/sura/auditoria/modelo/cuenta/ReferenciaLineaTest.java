package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("ReferenciaLinea")
class ReferenciaLineaTest {

    @Test
    @DisplayName("conserva el valor que recibe")
    void conservaElValorQueRecibe() {
        assertThat(new ReferenciaLinea(148111592284L).valor()).isEqualTo(148111592284L);
    }

    @ParameterizedTest(name = "rechaza {0}")
    @ValueSource(longs = {0L, -1L, Long.MIN_VALUE})
    @DisplayName("rechaza cero y negativos: no son referencias de línea")
    void rechazaCeroYNegativos(long invalido) {
        assertThatThrownBy(() -> new ReferenciaLinea(invalido))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("inválida");
    }

    @Test
    @DisplayName("dos referencias con el mismo valor son iguales")
    void dosReferenciasConElMismoValorSonIguales() {
        assertThat(new ReferenciaLinea(10L)).isEqualTo(new ReferenciaLinea(10L))
                .hasSameHashCodeAs(new ReferenciaLinea(10L));
    }
}
