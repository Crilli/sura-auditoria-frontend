package co.sura.auditoria.modelo.auditoria;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("EventoAuditoria")
class EventoAuditoriaTest {

    private static final String CUENTA = "CM-108800618430";
    private static final String AUTOR = "auditor@sura.com.co";

    @Nested
    @DisplayName("todas las fábricas")
    class TodasLasFabricas {

        @Test
        @DisplayName("dan un identificador único a cada evento")
        void danIdentificadorUnico() {
            var uno = EventoAuditoria.accionEjecutada(CUENTA, "x", AUTOR);
            var otro = EventoAuditoria.accionEjecutada(CUENTA, "x", AUTOR);

            assertThat(uno.identificador()).isNotNull().isNotEqualTo(otro.identificador());
        }

        @Test
        @DisplayName("marcan el momento en que ocurrieron")
        void marcanElMomento() {
            var antes = Instant.now();
            var evento = EventoAuditoria.accionEjecutada(CUENTA, "x", AUTOR);

            assertThat(evento.ocurridoEn()).isBetween(antes, Instant.now());
        }

        @Test
        @DisplayName("nacen exitosas y sin código de error")
        void nacenExitosasYSinCodigoDeError() {
            var evento = EventoAuditoria.cuentaEnviada(CUENTA, "ACEPTAR", AUTOR);

            assertThat(evento.resultado()).isEqualTo(ResultadoEvento.EXITOSO);
            assertThat(evento.codigoError()).isNull();
        }

        @Test
        @DisplayName("conservan el autor: sin él la traza no sirve de nada")
        void conservanElAutor() {
            assertThat(EventoAuditoria.accionEjecutada(CUENTA, "x", AUTOR).autor())
                    .isEqualTo(AUTOR);
        }
    }

    @Test
    @DisplayName("lineaGuardada es el único evento que lleva referencia de línea")
    void lineaGuardadaEsElUnicoConReferenciaDeLinea() {
        assertThat(EventoAuditoria.lineaGuardada(CUENTA, 148111592284L, "detalle", AUTOR))
                .satisfies(e -> {
                    assertThat(e.tipo()).isEqualTo(TipoEvento.LINEA_GUARDADA);
                    assertThat(e.referenciaLinea()).isEqualTo(148111592284L);
                });

        assertThat(EventoAuditoria.accionEjecutada(CUENTA, "x", AUTOR).referenciaLinea()).isNull();
        assertThat(EventoAuditoria.cuentaEnviada(CUENTA, "x", AUTOR).referenciaLinea()).isNull();
    }

    @Test
    @DisplayName("pendienteResuelto deja en el detalle el motivo, el alcance y la justificación")
    void pendienteResueltoDejaMotivoAlcanceYJustificacion() {
        var evento = EventoAuditoria.pendienteResuelto(CUENTA, 4242L, "CUENTA",
                "Soportes completos", AUTOR);

        assertThat(evento.tipo()).isEqualTo(TipoEvento.PENDIENTE_RESUELTO);
        assertThat(evento.detalle())
                .contains("4242")
                .contains("CUENTA")
                .contains("Soportes completos");
    }

    @Test
    @DisplayName("pendientesResueltosEnMasa cuenta los motivos y los lista")
    void pendientesEnMasaCuentaYLista() {
        var motivos = new LinkedHashSet<>(java.util.List.of("AUD01", "GLO02", "TAR03"));

        var evento = EventoAuditoria.pendientesResueltosEnMasa(CUENTA, motivos, "DONDE_APLIQUE",
                "COMPLETO", "Revisión masiva", AUTOR);

        assertThat(evento.tipo()).isEqualTo(TipoEvento.PENDIENTES_RESUELTOS_EN_MASA);
        assertThat(evento.detalle())
                .contains("(3)")
                .contains("AUD01, GLO02, TAR03")
                .contains("DONDE_APLIQUE")
                .contains("COMPLETO");
    }

    @Test
    @DisplayName("pendientesResueltosEnMasa soporta el conjunto vacío sin romperse")
    void pendientesEnMasaSoportaConjuntoVacio() {
        var evento = EventoAuditoria.pendientesResueltosEnMasa(CUENTA, java.util.Set.of(),
                "CUENTA", "FALLIDO", "nada que resolver", AUTOR);

        assertThat(evento.detalle()).contains("(0)");
    }

    @Test
    @DisplayName("cuentaEnviada deja la decisión en el detalle")
    void cuentaEnviadaDejaLaDecision() {
        assertThat(EventoAuditoria.cuentaEnviada(CUENTA, "DENEGAR", AUTOR).detalle())
                .isEqualTo("Decisión: DENEGAR");
    }

    @Test
    @DisplayName("cuentaNovedadesCambiadas conserva el detalle tal cual")
    void novedadesCambiadasConservaElDetalle() {
        var evento = EventoAuditoria.cuentaNovedadesCambiadas(CUENTA, "alta 332-1", AUTOR);

        assertThat(evento.tipo()).isEqualTo(TipoEvento.CUENTA_NOVEDADES_CAMBIADAS);
        assertThat(evento.detalle()).isEqualTo("alta 332-1");
    }

    @Test
    @DisplayName("el catálogo de tipos cubre las ocho operaciones trazadas")
    void elCatalogoDeTiposCubreLasOcho() {
        // La octava es el cambio en lote, que va aparte de LINEA_GUARDADA a propósito: lo que
        // hay que poder reconstruir después es la decisión —«glosó estas dieciocho de una
        // vez»— y no dieciocho guardados que parecerían independientes.
        assertThat(TipoEvento.values()).hasSize(8)
                .contains(TipoEvento.LINEA_GUARDADA, TipoEvento.CUENTA_ENVIADA,
                          TipoEvento.CUENTA_CONSULTADA, TipoEvento.LINEAS_CAMBIADAS_EN_LOTE);
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("lineasCambiadasEnLote no cuelga de ninguna línea: el evento es de la operación")
    void lineasCambiadasEnLoteNoCuelgaDeUnaLinea() {
        var evento = EventoAuditoria.lineasCambiadasEnLote(
                CUENTA, "18 línea(s) aplicadas, 2 fallo(s)", AUTOR);

        assertThat(evento.tipo()).isEqualTo(TipoEvento.LINEAS_CAMBIADAS_EN_LOTE);
        assertThat(evento.referenciaLinea()).isNull();
        assertThat(evento.detalle()).contains("18").contains("2 fallo");
        assertThat(evento.autor()).isEqualTo(AUTOR);
    }

    @Test
    @DisplayName("el resultado distingue éxito, rechazo y error")
    void elResultadoDistingueLosTresDesenlaces() {
        assertThat(ResultadoEvento.values()).containsExactly(
                ResultadoEvento.EXITOSO, ResultadoEvento.RECHAZADO, ResultadoEvento.ERROR);
    }

    @org.junit.jupiter.api.Test
    @org.junit.jupiter.api.Tag("OPE-06")
    @DisplayName("la resolución masiva deja las operaciones y los fallos, y su resultado sigue al desenlace")
    void resolucionMasivaConOperacionesYFallos() {
        var parcial = EventoAuditoria.pendientesResueltosEnMasa(CUENTA, java.util.Set.of("MP_A"), "DONDE_APLIQUE",
                "PARCIAL", java.util.List.of("2214360299", "2218360566"),
                java.util.List.of("LINEAS_SIN_LANZAR[MP_A]"), "justificación", AUTOR);
        var fallida = EventoAuditoria.pendientesResueltosEnMasa(CUENTA, java.util.Set.of("MP_A"), "DONDE_APLIQUE",
                "FALLIDO", java.util.List.of(), java.util.List.of(), "j", AUTOR);
        var enCurso = EventoAuditoria.pendientesResueltosEnMasa(CUENTA, java.util.Set.of("MP_A"), "DONDE_APLIQUE",
                null, java.util.List.of(), java.util.List.of(), "j", AUTOR);

        org.assertj.core.api.Assertions.assertThat(parcial.resultado()).isEqualTo(ResultadoEvento.RECHAZADO);
        org.assertj.core.api.Assertions.assertThat(parcial.detalle())
                .contains("Operaciones: 2214360299, 2218360566").contains("Fallos: LINEAS_SIN_LANZAR[MP_A]");
        org.assertj.core.api.Assertions.assertThat(fallida.resultado()).isEqualTo(ResultadoEvento.ERROR);
        org.assertj.core.api.Assertions.assertThat(fallida.detalle()).contains("Operaciones: -").contains("Fallos: -");
        org.assertj.core.api.Assertions.assertThat(enCurso.resultado()).isEqualTo(ResultadoEvento.EXITOSO);
    }
}
