package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

@DisplayName("ResumenLinea")
class ResumenLineaTest {

    private static ResumenLinea linea(boolean bloqueada, boolean reemplazada,
                                      List<MotivoPendiente> pendientes) {
        return new ResumenLinea(new ReferenciaLinea(1L), 1, LocalDate.now(), LocalDate.now(),
                "CC1000000001", "Afiliado", "873206", "Radiografía de muñeca", "CUPS", "AUT1",
                BigDecimal.TEN, BigDecimal.TEN, BigDecimal.ZERO,
                false, false, bloqueada, reemplazada, 0, pendientes, false, List.of(), new Version(1L), null, null, null, null, null);
    }

    @ParameterizedTest(name = "bloqueada={0} reemplazada={1} -> editable={2}")
    @CsvSource({
            "false, false, true",
            "true,  false, false",
            "false, true,  false",
            "true,  true,  false"
    })
    @DisplayName("solo es editable si no está bloqueada ni reemplazada")
    void soloEsEditableSiNoEstaBloqueadaNiReemplazada(boolean bloqueada, boolean reemplazada,
                                                      boolean editable) {
        assertThat(linea(bloqueada, reemplazada, List.of()).esEditable()).isEqualTo(editable);
    }

    @Test
    @DisplayName("unos pendientes nulos se normalizan a lista vacía, no revientan")
    void pendientesNulosSeNormalizanAListaVacia() {
        assertThat(linea(false, false, null).pendientes()).isEmpty();
    }

    @Test
    @DisplayName("los pendientes quedan inmutables")
    void losPendientesQuedanInmutables() {
        var original = new ArrayList<MotivoPendiente>();
        var resumen = linea(false, false, original);

        assertThatThrownBy(() -> resumen.pendientes().add(null))
                .isInstanceOf(UnsupportedOperationException.class);
    }
}
