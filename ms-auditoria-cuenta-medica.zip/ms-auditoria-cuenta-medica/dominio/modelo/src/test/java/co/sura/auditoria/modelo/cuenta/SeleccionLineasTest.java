package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * El tipo existe por una razón concreta: en el sistema de registro, «ninguna línea» y «todas
 * las líneas» se escriben casi igual, y confundirlas hace lo contrario de lo que se pidió.
 */
@DisplayName("SeleccionLineas")
class SeleccionLineasTest {

    private static ReferenciaLinea ref(long valor) {
        return new ReferenciaLinea(valor);
    }

    @Test
    @Tag("F2-12")
    @DisplayName("TODAS no acota, y se dice en vez de deducirse de una lista vacía")
    void todasNoAcota() {
        assertThat(SeleccionLineas.TODAS.esTodaLaCuenta()).isTrue();
        assertThat(SeleccionLineas.TODAS.cuantas()).isZero();
        assertThat(SeleccionLineas.TODAS.identificadores()).isEmpty();
    }

    @Test
    @Tag("F2-12")
    @DisplayName("una selección concreta acota y conserva sus identificadores")
    void unaSeleccionConcretaAcota() {
        var seleccion = SeleccionLineas.de(List.of(ref(10L), ref(20L), ref(30L)));

        assertThat(seleccion.esTodaLaCuenta()).isFalse();
        assertThat(seleccion.cuantas()).isEqualTo(3);
        assertThat(seleccion.identificadores()).containsExactly(10L, 20L, 30L);
    }

    @Test
    @Tag("DBG-04")
    @DisplayName("una selección vacía no se acepta: convertiría «estas tres» en «todas»")
    void unaSeleccionVaciaNoSeAcepta() {
        // Es el fallo que este tipo existe para impedir. Con la lista vacía, el cuerpo que
        // viaja al sistema de registro queda sin claimLineList y la operación alcanza la
        // cuenta entera, sin error y sin aviso.
        assertThatThrownBy(() -> SeleccionLineas.de(List.of()))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("TODAS");
        assertThatThrownBy(() -> SeleccionLineas.de(null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @Tag("DBG-01")
    @DisplayName("los repetidos no cuentan dos veces, y se conserva el orden de elección")
    void losRepetidosNoCuentanDosVeces() {
        // La pantalla puede mandar la misma referencia dos veces —marcar, desmarcar y volver
        // a marcar— y eso no debe inflar el contador que ve el auditor.
        var seleccion = SeleccionLineas.de(List.of(ref(30L), ref(10L), ref(30L), ref(20L)));

        assertThat(seleccion.cuantas()).isEqualTo(3);
        assertThat(seleccion.identificadores()).containsExactly(30L, 10L, 20L);
    }

    @Test
    @Tag("DBG-01")
    @DisplayName("el conjunto no se puede modificar por fuera")
    void elConjuntoNoSeModificaPorFuera() {
        var mutable = new java.util.ArrayList<>(List.of(ref(1L)));
        var seleccion = SeleccionLineas.de(mutable);
        mutable.add(ref(2L));

        assertThat(seleccion.cuantas()).isEqualTo(1);
    }
}
