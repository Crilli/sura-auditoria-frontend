package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("FiltroBloqueo")
class FiltroBloqueoTest {

    /** El estado en el que cualquier pendiente frena el envío. */
    private static final EstadoCuenta ADJUDICACION = EstadoCuenta.ADJUDICACION_MANUAL;
    /** Un estado corriente, donde el bloqueo depende de `soloAdjudicacion`. */
    private static final EstadoCuenta CORRIENTE = EstadoCuenta.MODIFICACION;

    @Nested
    @DisplayName("soloAdjudicacionExigida")
    class SoloAdjudicacionExigida {

        @ParameterizedTest
        @EnumSource(EstadoCuenta.class)
        @DisplayName("TODOS nunca exige nada: no filtra por bloqueo")
        void todosNuncaExigeNada(EstadoCuenta estado) {
            assertThat(FiltroBloqueo.TODOS.soloAdjudicacionExigida(estado)).isEmpty();
        }

        @Test
        @DisplayName("en ADJUDICACION_MANUAL no se exige nada, porque ahí todo pendiente bloquea")
        void enAdjudicacionManualNoSeExigeNada() {
            // Si todos bloquean, el filtro no puede distinguir: no hay predicado que empujar.
            assertThat(FiltroBloqueo.BLOQUEANTES.soloAdjudicacionExigida(ADJUDICACION)).isEmpty();
            assertThat(FiltroBloqueo.NO_BLOQUEANTES.soloAdjudicacionExigida(ADJUDICACION)).isEmpty();
        }

        @Test
        @DisplayName("en un estado corriente, BLOQUEANTES pide los que NO son solo de adjudicación")
        void bloqueantesPideLosQueNoSonSoloDeAdjudicacion() {
            assertThat(FiltroBloqueo.BLOQUEANTES.soloAdjudicacionExigida(CORRIENTE))
                    .contains(false);
        }

        @Test
        @DisplayName("en un estado corriente, NO_BLOQUEANTES pide los que sí son solo de adjudicación")
        void noBloqueantesPideLosDeAdjudicacion() {
            assertThat(FiltroBloqueo.NO_BLOQUEANTES.soloAdjudicacionExigida(CORRIENTE))
                    .contains(true);
        }
    }

    @Nested
    @DisplayName("vacioPorDefinicion")
    class VacioPorDefinicion {

        @Test
        @DisplayName("pedir NO_BLOQUEANTES en ADJUDICACION_MANUAL no puede devolver nada")
        void noBloqueantesEnAdjudicacionManualEsVacio() {
            // Ahí todo pendiente bloquea, así que «los que no bloquean» es el conjunto vacío.
            // Saberlo evita una consulta inútil contra OHI.
            assertThat(FiltroBloqueo.NO_BLOQUEANTES.vacioPorDefinicionEn(ADJUDICACION)).isTrue();
        }

        @Test
        @DisplayName("en un estado corriente NO_BLOQUEANTES sí puede devolver algo")
        void noBloqueantesEnEstadoCorrienteNoEsVacio() {
            assertThat(FiltroBloqueo.NO_BLOQUEANTES.vacioPorDefinicionEn(CORRIENTE)).isFalse();
        }

        @ParameterizedTest
        @EnumSource(value = FiltroBloqueo.class, names = {"TODOS", "BLOQUEANTES"})
        @DisplayName("TODOS y BLOQUEANTES nunca son vacíos por definición")
        void todosYBloqueantesNuncaSonVacios(FiltroBloqueo filtro) {
            assertThat(filtro.vacioPorDefinicionEn(ADJUDICACION)).isFalse();
            assertThat(filtro.vacioPorDefinicionEn(CORRIENTE)).isFalse();
        }
    }
}
