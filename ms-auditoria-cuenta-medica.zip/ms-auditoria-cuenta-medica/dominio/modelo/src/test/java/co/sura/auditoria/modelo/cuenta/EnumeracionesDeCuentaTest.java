package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

/** Las enumeraciones pequeñas del dominio de cuenta, con su regla cuando la tienen. */
@DisplayName("Enumeraciones de cuenta")
class EnumeracionesDeCuentaTest {

    @Nested
    @DisplayName("Severidad")
    class SeveridadTest {

        @ParameterizedTest
        @EnumSource(value = Severidad.class, names = {"BLOQUEANTE", "NEGACION"})
        @DisplayName("bloqueante y negación frenan la cuenta")
        void bloqueanteYNegacionFrenan(Severidad severidad) {
            assertThat(severidad.frenaLaCuenta()).isTrue();
        }

        @ParameterizedTest
        @EnumSource(value = Severidad.class,
                names = {"INFORMATIVA", "ADVERTENCIA", "DESCONOCIDA"})
        @DisplayName("informativa, advertencia y desconocida no frenan")
        void lasDemasNoFrenan(Severidad severidad) {
            assertThat(severidad.frenaLaCuenta()).isFalse();
        }

        @Test
        @DisplayName("DESCONOCIDA no frena: una severidad que no se supo leer no debe parar la cuenta")
        void desconocidaNoFrena() {
            assertThat(Severidad.DESCONOCIDA.frenaLaCuenta()).isFalse();
        }
    }

    @Nested
    @DisplayName("NivelResolucion")
    class NivelResolucionTest {

        @Test
        @DisplayName("CUENTA alcanza la cabecera pero no las líneas")
        void cuentaAlcanzaSoloCabecera() {
            assertThat(NivelResolucion.CUENTA.alcanzaCabecera()).isTrue();
            assertThat(NivelResolucion.CUENTA.alcanzaLineas()).isFalse();
        }

        @Test
        @DisplayName("LINEAS alcanza las líneas pero no la cabecera")
        void lineasAlcanzaSoloLineas() {
            assertThat(NivelResolucion.LINEAS.alcanzaCabecera()).isFalse();
            assertThat(NivelResolucion.LINEAS.alcanzaLineas()).isTrue();
        }

        @Test
        @DisplayName("DONDE_APLIQUE alcanza ambos")
        void dondeApliqueAlcanzaAmbos() {
            assertThat(NivelResolucion.DONDE_APLIQUE.alcanzaCabecera()).isTrue();
            assertThat(NivelResolucion.DONDE_APLIQUE.alcanzaLineas()).isTrue();
        }

        @ParameterizedTest
        @EnumSource(NivelResolucion.class)
        @DisplayName("todo nivel alcanza al menos un ámbito: ninguno es inútil")
        void todoNivelAlcanzaAlgo(NivelResolucion nivel) {
            assertThat(nivel.alcanzaCabecera() || nivel.alcanzaLineas()).isTrue();
        }
    }

    @Nested
    @DisplayName("catálogos sin lógica")
    class CatalogosSinLogica {

        @Test
        @DisplayName("NivelPendiente distingue cabecera de línea, que son los dos niveles de OHI")
        void nivelPendienteTieneLosDosNiveles() {
            assertThat(NivelPendiente.values())
                    .containsExactly(NivelPendiente.CABECERA, NivelPendiente.LINEA);
        }

        @Test
        @DisplayName("ModoRecalculo distingue cascada de aislado")
        void modoRecalculoTieneLosDosModos() {
            assertThat(ModoRecalculo.values())
                    .containsExactly(ModoRecalculo.EN_CASCADA, ModoRecalculo.AISLADO);
        }

        @Test
        @DisplayName("AccionCuenta cubre las once acciones que el auditor puede ejecutar")
        void accionCuentaCubreLasOnceAcciones() {
            assertThat(AccionCuenta.values()).hasSize(11)
                    .contains(AccionCuenta.ENVIAR,
                              AccionCuenta.RESOLVER_PENDIENTE,
                              AccionCuenta.REVERTIR_FINALIZACION,
                              AccionCuenta.ANULAR);
        }
    }
}
