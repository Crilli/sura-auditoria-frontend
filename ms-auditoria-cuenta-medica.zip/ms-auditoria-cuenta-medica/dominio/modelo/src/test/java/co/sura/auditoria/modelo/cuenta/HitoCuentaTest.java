package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("HitoCuenta")
class HitoCuentaTest {

    private static HitoCuenta de(String autor) {
        return new HitoCuenta(HitoCuenta.Tipo.CAMBIO_DE_ESTADO, "FINALIZADA", null,
                              autor, Instant.parse("2026-10-15T11:43:29Z"));
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("distingue lo que movió el motor de lo que movió una persona")
    void distingueElMotorDeLaPersona() {
        // La pantalla no debería tener que conocer el literal del sistema de registro para
        // saberlo: aquí se traduce una vez y allí se lee un booleano.
        assertThat(de("Internal System User").loHizoElSistema()).isTrue();
        assertThat(de("b71e73c701ba4bf5b15a0e9c75e164df").loHizoElSistema()).isFalse();
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("el literal se compara sin distinguir mayúsculas")
    void elLiteralSeComparaSinCaja() {
        assertThat(de("INTERNAL SYSTEM USER").loHizoElSistema()).isTrue();
    }

    @ParameterizedTest(name = "autor = [{0}]")
    @NullSource
    @ValueSource(strings = {"", "   "})
    @Tag("BTN-06")
    @DisplayName("sin autor no se afirma que lo hizo el sistema")
    void sinAutorNoSeAfirma(String autor) {
        assertThat(de(autor).loHizoElSistema()).isFalse();
    }

    @Test
    @Tag("BTN-06")
    @DisplayName("una desfinalización lleva el motivo y su texto, que el historial de estados no guarda")
    void laDesfinalizacionLlevaElMotivo() {
        // Es la razón de que la historia se arme de dos recursos: claimstatushistory enseña
        // que la cuenta se desfinalizó y no por qué.
        var hito = new HitoCuenta(HitoCuenta.Tipo.DESFINALIZACION, "PRORROGA", "Prorroga",
                                  "auditor", Instant.parse("2026-10-17T16:28:34Z"));

        assertThat(hito.tipo()).isEqualTo(HitoCuenta.Tipo.DESFINALIZACION);
        assertThat(hito.etiqueta()).isEqualTo("PRORROGA");
        assertThat(hito.detalle()).isEqualTo("Prorroga");
    }
}
