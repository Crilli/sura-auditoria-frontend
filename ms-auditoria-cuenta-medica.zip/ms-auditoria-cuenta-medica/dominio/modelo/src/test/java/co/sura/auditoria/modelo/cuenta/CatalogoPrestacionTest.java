package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("CatalogoPrestacion")
class CatalogoPrestacionTest {

    @ParameterizedTest(name = "[{0}] -> {1}")
    @CsvSource({
            "CUPS,     CUPS",
            "CUM,      CUM",
            "SURACUPS, SURACUPS"
    })
    @DisplayName("reconoce los catálogos nombrados")
    void reconoceLosCatalogosNombrados(String externo, CatalogoPrestacion esperado) {
        assertThat(CatalogoPrestacion.de(externo)).isEqualTo(esperado);
    }

    @ParameterizedTest(name = "[{0}] -> CUPS")
    @ValueSource(strings = {"cups", "Cups", "  CUPS  ", "cUpS"})
    @DisplayName("no distingue mayúsculas ni respeta espacios sobrantes")
    void noDistingueMayusculasNiEspacios(String externo) {
        assertThat(CatalogoPrestacion.de(externo)).isEqualTo(CatalogoPrestacion.CUPS);
    }

    @ParameterizedTest(name = "[{0}] -> PROPIO")
    @ValueSource(strings = {"8600073361_PROPIO", "900011436_propio", "  X_PROPIO  "})
    @DisplayName("el sufijo _PROPIO marca el catálogo propio del prestador, sea cual sea el NIT")
    void elSufijoPropioMarcaCatalogoPropio(String externo) {
        // «Propio» es una familia por NIT, no un catálogo único.
        assertThat(CatalogoPrestacion.de(externo)).isEqualTo(CatalogoPrestacion.PROPIO);
    }

    @ParameterizedTest(name = "[{0}] -> OTRO")
    @NullAndEmptySource
    @ValueSource(strings = {"   ", "IUM", "desconocido", "PROPIO_X"})
    @DisplayName("lo que no reconoce cae en OTRO, incluidos nulo y vacío")
    void loQueNoReconoceCaeEnOtro(String externo) {
        assertThat(CatalogoPrestacion.de(externo)).isEqualTo(CatalogoPrestacion.OTRO);
    }

    @Test
    @DisplayName("el literal PROPIO sin sufijo también cae en OTRO: PROPIO no se nombra, se deduce")
    void elLiteralPropioCaeEnOtro() {
        assertThat(CatalogoPrestacion.de("PROPIO")).isEqualTo(CatalogoPrestacion.OTRO);
    }

    @Test
    @DisplayName("las etiquetas legibles distinguen PROPIO y OTRO del resto")
    void lasEtiquetasLegibles() {
        assertThat(CatalogoPrestacion.PROPIO.etiqueta()).isEqualTo("Propio del prestador");
        assertThat(CatalogoPrestacion.OTRO.etiqueta()).isEqualTo("Otro");
        assertThat(CatalogoPrestacion.CUPS.etiqueta()).isEqualTo("CUPS");
        assertThat(CatalogoPrestacion.CUM.etiqueta()).isEqualTo("CUM");
        assertThat(CatalogoPrestacion.SURACUPS.etiqueta()).isEqualTo("SURACUPS");
    }
}
