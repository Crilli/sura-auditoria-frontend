package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * El desenlace se deduce, no se declara.
 *
 * <p>Si fuera un parámetro, nada impediría construir un resultado que dijera COMPLETO con
 * fallos dentro, y la pantalla lo creería. Aquí sale de lo que de verdad pasó.
 */
@DisplayName("ResultadoPorLinea")
class ResultadoPorLineaTest {

    private static final ReferenciaLinea A = new ReferenciaLinea(10L);
    private static final ReferenciaLinea B = new ReferenciaLinea(20L);

    private static ResultadoPorLinea.Fallo fallo(ReferenciaLinea referencia, int numero) {
        return new ResultadoPorLinea.Fallo(referencia, numero, "La línea está bloqueada");
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("sin fallos es COMPLETO")
    void sinFallosEsCompleto() {
        var resultado = ResultadoPorLinea.de(List.of(A, B), List.of());

        assertThat(resultado.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
        assertThat(resultado.cuantasAplicadas()).isEqualTo(2);
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("con algo aplicado y algo fallido es PARCIAL, que es el desenlace normal")
    void conAlgoDeCadaEsParcial() {
        var resultado = ResultadoPorLinea.de(List.of(A), List.of(fallo(B, 37)));

        assertThat(resultado.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.PARCIAL);
        assertThat(resultado.fallos()).singleElement()
                .satisfies(f -> assertThat(f.numeroLinea()).isEqualTo(37));
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("sin nada aplicado es FALLIDO")
    void sinNadaAplicadoEsFallido() {
        var resultado = ResultadoPorLinea.de(List.of(), List.of(fallo(A, 1), fallo(B, 2)));

        assertThat(resultado.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.FALLIDO);
        assertThat(resultado.cuantasAplicadas()).isZero();
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("un resultado vacío del todo es COMPLETO: no había nada que hacer y no falló nada")
    void unResultadoVacioEsCompleto() {
        assertThat(ResultadoPorLinea.de(List.of(), List.of()).desenlace())
                .isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("los nulos se tratan como vacíos, y las listas no se pueden modificar por fuera")
    void losNulosSeTratanComoVacios() {
        var resultado = ResultadoPorLinea.de(null, null);
        assertThat(resultado.aplicadas()).isEmpty();
        assertThat(resultado.fallos()).isEmpty();
        assertThat(resultado.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);

        var mutable = new ArrayList<>(List.of(A));
        var copiado = new ResultadoPorLinea(mutable, null, ResultadoPorLinea.Desenlace.COMPLETO, null);
        mutable.add(B);
        assertThat(copiado.aplicadas()).containsExactly(A);
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("un fallo sin número de línea es legítimo: la línea pudo dejar de existir")
    void unFalloSinNumeroEsLegitimo() {
        var resultado = ResultadoPorLinea.de(List.of(),
                List.of(new ResultadoPorLinea.Fallo(A, null, "La línea ya no existe en la cuenta")));

        assertThat(resultado.fallos()).singleElement()
                .satisfies(f -> assertThat(f.numeroLinea()).isNull());
    }

    @org.junit.jupiter.api.Test
    @org.junit.jupiter.api.Tag("OPE-12")
    @org.junit.jupiter.api.DisplayName("las que ya estaban cuentan del lado bueno: un lote repetido entero es COMPLETO")
    void lasQueYaEstabanNoSonFallos() {
        var r1 = new ReferenciaLinea(1L);
        var r2 = new ReferenciaLinea(2L);
        var fallo = new ResultadoPorLinea.Fallo(r2, 2, "bloqueada");

        var todasYaEstaban = ResultadoPorLinea.de(java.util.List.of(), java.util.List.of(), java.util.List.of(r1));
        var algunaFallo = ResultadoPorLinea.de(java.util.List.of(), java.util.List.of(fallo), java.util.List.of(r1));
        var soloFallos = ResultadoPorLinea.de(java.util.List.of(), java.util.List.of(fallo), null);

        org.assertj.core.api.Assertions.assertThat(todasYaEstaban.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.COMPLETO);
        org.assertj.core.api.Assertions.assertThat(todasYaEstaban.yaEstaban()).containsExactly(r1);
        org.assertj.core.api.Assertions.assertThat(algunaFallo.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.PARCIAL);
        org.assertj.core.api.Assertions.assertThat(soloFallos.desenlace()).isEqualTo(ResultadoPorLinea.Desenlace.FALLIDO);
        org.assertj.core.api.Assertions.assertThat(soloFallos.yaEstaban()).isEmpty();
    }
}
