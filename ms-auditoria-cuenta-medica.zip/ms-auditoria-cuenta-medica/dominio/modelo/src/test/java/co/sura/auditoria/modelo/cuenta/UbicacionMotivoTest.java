package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("UbicacionMotivo")
class UbicacionMotivoTest {

    @Test
    @Tag("OPE-07")
    @DisplayName("un motivo existe si está en la cabecera, en las líneas o en las dos")
    void existe() {
        assertThat(new UbicacionMotivo("MP_A", true, false).existe()).isTrue();
        assertThat(new UbicacionMotivo("MP_A", false, true).existe()).isTrue();
        assertThat(new UbicacionMotivo("MP_A", true, true).existe()).isTrue();
    }

    @Test
    @Tag("OPE-07")
    @DisplayName("si no está en ningún sitio es desconocido para esa cuenta")
    void noExiste() {
        assertThat(new UbicacionMotivo("MP_A", false, false).existe()).isFalse();
    }
}
