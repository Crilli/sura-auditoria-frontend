package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Desenlace;
import co.sura.auditoria.modelo.cuenta.ResultadoResolucionMasiva.Fallo;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("ResultadoResolucionMasiva")
class ResultadoResolucionMasivaTest {

    private static ResultadoResolucionMasiva con(Desenlace desenlace, Fallo... fallos) {
        return new ResultadoResolucionMasiva(List.of("ref"), desenlace, List.of(fallos));
    }

    private static final Fallo UN_FALLO = new Fallo("CLA-CLAI-035", "CM-1", "pendientes vivos");

    @Test
    @DisplayName("completo lleva su referencia y ningún fallo")
    void completoLlevaSuReferenciaYNingunFallo() {
        var resultado = ResultadoResolucionMasiva.completo("op-123");

        assertThat(resultado.referencias()).containsExactly("op-123");
        assertThat(resultado.fallos()).isEmpty();
        assertThat(resultado.desenlace()).isEqualTo(Desenlace.COMPLETO);
        assertThat(resultado.todoResuelto()).isTrue();
    }

    @Nested
    @DisplayName("al combinar dos resultados")
    class AlCombinar {

        @Test
        @DisplayName("completo + completo sigue siendo completo")
        void completoMasCompletoEsCompleto() {
            var unido = ResultadoResolucionMasiva.completo("a")
                    .y(ResultadoResolucionMasiva.completo("b"));

            assertThat(unido.desenlace()).isEqualTo(Desenlace.COMPLETO);
            assertThat(unido.referencias()).containsExactly("a", "b");
            assertThat(unido.todoResuelto()).isTrue();
        }

        @Test
        @DisplayName("fallido + fallido es fallido: nada salió")
        void fallidoMasFallidoEsFallido() {
            var unido = con(Desenlace.FALLIDO, UN_FALLO).y(con(Desenlace.FALLIDO, UN_FALLO));

            assertThat(unido.desenlace()).isEqualTo(Desenlace.FALLIDO);
            assertThat(unido.fallos()).hasSize(2);
        }

        @Test
        @DisplayName("completo + fallido es PARCIAL: algo salió y algo no")
        void completoMasFallidoEsParcial() {
            var unido = ResultadoResolucionMasiva.completo("a").y(con(Desenlace.FALLIDO, UN_FALLO));

            assertThat(unido.desenlace()).isEqualTo(Desenlace.PARCIAL);
            assertThat(unido.todoResuelto()).isFalse();
        }

        @Test
        @DisplayName("en curso contagia a todo: aún no se puede concluir")
        void enCursoContagia() {
            assertThat(ResultadoResolucionMasiva.completo("a").y(con(Desenlace.EN_CURSO))
                    .desenlace()).isEqualTo(Desenlace.EN_CURSO);
            assertThat(con(Desenlace.EN_CURSO).y(con(Desenlace.FALLIDO, UN_FALLO))
                    .desenlace()).isEqualTo(Desenlace.EN_CURSO);
        }

        @Test
        @DisplayName("dos completos CON fallos acumulados se degradan a parcial")
        void dosCompletosConFallosSeDegradanAParcial() {
            // El desenlace no se cree a sí mismo: si hay fallos acumulados, es parcial.
            var unido = con(Desenlace.COMPLETO, UN_FALLO).y(con(Desenlace.COMPLETO));

            assertThat(unido.desenlace()).isEqualTo(Desenlace.PARCIAL);
        }

        @Test
        @DisplayName("combinar acumula referencias y fallos de ambos lados")
        void combinarAcumulaReferenciasYFallos() {
            var uno = new ResultadoResolucionMasiva(List.of("a"), Desenlace.COMPLETO, List.of());
            var otro = new ResultadoResolucionMasiva(List.of("b", "c"), Desenlace.FALLIDO,
                    List.of(UN_FALLO));

            var unido = uno.y(otro);

            assertThat(unido.referencias()).containsExactly("a", "b", "c");
            assertThat(unido.fallos()).containsExactly(UN_FALLO);
        }
    }

    @Test
    @DisplayName("las listas quedan inmutables")
    void lasListasQuedanInmutables() {
        var resultado = ResultadoResolucionMasiva.completo("a");

        assertThatThrownBy(() -> resultado.referencias().add("b"))
                .isInstanceOf(UnsupportedOperationException.class);
        assertThatThrownBy(() -> resultado.fallos().add(UN_FALLO))
                .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    @DisplayName("solo COMPLETO cuenta como todo resuelto")
    void soloCompletoCuentaComoTodoResuelto() {
        assertThat(con(Desenlace.COMPLETO).todoResuelto()).isTrue();
        assertThat(con(Desenlace.PARCIAL).todoResuelto()).isFalse();
        assertThat(con(Desenlace.FALLIDO).todoResuelto()).isFalse();
        assertThat(con(Desenlace.EN_CURSO).todoResuelto()).isFalse();
    }
}
