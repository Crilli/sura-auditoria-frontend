package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("OrdenLineas")
class OrdenLineasTest {

    @Nested
    @DisplayName("qué se le puede pedir al sistema de registro")
    class QueSeLePuedePedir {

        @ParameterizedTest(name = "{0} → {1}")
        @CsvSource({
                "NUMERO_LINEA,        sequence",
                "CEDULA_AFILIADO,     person.code",
                "FECHA_ATENCION,      startDate",
                "CODIGO_AUTORIZACION, authorizationCode",
                "CODIGO_PRESTACION,   procedure.code",
                "VALOR_GLOSADO,       valorGlosado",
        })
        @Tag("F3-ORD-02")
        @Tag("F3-ORD-03")
        @Tag("F3-ORD-04")
        @Tag("F3-ORD-05")
        @Tag("F3-ORD-06")
        @DisplayName("seis de los siete campos del documento se resuelven allí")
        void seisDeLosSieteSeResuelvenAlli(OrdenLineas.Campo campo, String enOhi) {
            // Medido contra el entorno de pruebas: los seis responden 200 y ordenan de verdad.
            assertThat(campo.seEmpuja()).isTrue();
            assertThat(campo.campoEnOhi()).isEqualTo(enOhi);
        }

        @Test
        @Tag("F3-ORD-07")
        @DisplayName("el valor cargado no: los importes de tipo monto dan 500 al ordenarlos")
        void elValorCargadoNo() {
            assertThat(OrdenLineas.Campo.VALOR_CARGADO.seEmpuja()).isFalse();
            assertThat(OrdenLineas.Campo.VALOR_CARGADO.campoEnOhi()).isNull();
        }

        @Test
        @Tag("F3-ORD-07")
        @DisplayName("pedirle a OHI un orden que no sabe hacer falla aquí, no allí")
        void pedirUnOrdenImposibleFallaAqui() {
            // Antes de gastar una llamada. El 500 de OHI habla de un error del motor y no
            // dice que el problema sea el campo; esto sí lo dice.
            var imposible = new OrdenLineas(OrdenLineas.Campo.VALOR_CARGADO,
                                            OrdenLineas.Sentido.ASCENDENTE);

            assertThatThrownBy(imposible::expresionOhi)
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("VALOR_CARGADO");
        }
    }

    @Nested
    @DisplayName("la expresión que viaja")
    class LaExpresion {

        @Test
        @Tag("F3-ORD-06")
        @DisplayName("es «campo sentido», como la espera el sistema de registro")
        void esCampoYSentido() {
            assertThat(new OrdenLineas(OrdenLineas.Campo.VALOR_GLOSADO,
                                       OrdenLineas.Sentido.DESCENDENTE).expresionOhi())
                    .isEqualTo("valorGlosado desc");
            assertThat(new OrdenLineas(OrdenLineas.Campo.CEDULA_AFILIADO,
                                       OrdenLineas.Sentido.ASCENDENTE).expresionOhi())
                    .isEqualTo("person.code asc");
        }

        @ParameterizedTest
        @EnumSource(OrdenLineas.Campo.class)
        @DisplayName("todo campo que se empuja produce una expresión, y ninguno la deja a medias")
        void todoCampoQueSeEmpujaProduceExpresion(OrdenLineas.Campo campo) {
            var orden = new OrdenLineas(campo, OrdenLineas.Sentido.ASCENDENTE);
            if (campo.seEmpuja()) {
                assertThat(orden.expresionOhi()).isEqualTo(campo.campoEnOhi() + " asc");
            } else {
                assertThatThrownBy(orden::expresionOhi).isInstanceOf(IllegalStateException.class);
            }
        }
    }

    @Nested
    @DisplayName("el orden por omisión")
    class ElOrdenPorOmision {

        @Test
        @Tag("F3-ORD-01")
        @DisplayName("es el número de línea ascendente, que es como se lee una cuenta")
        void esElNumeroDeLineaAscendente() {
            assertThat(OrdenLineas.PREDETERMINADO.campo())
                    .isEqualTo(OrdenLineas.Campo.NUMERO_LINEA);
            assertThat(OrdenLineas.PREDETERMINADO.sentido())
                    .isEqualTo(OrdenLineas.Sentido.ASCENDENTE);
            assertThat(OrdenLineas.PREDETERMINADO.expresionOhi()).isEqualTo("sequence asc");
        }

        @Test
        @DisplayName("un campo o un sentido nulos caen al predeterminado, no revientan")
        void losNulosCaenAlPredeterminado() {
            assertThat(new OrdenLineas(null, null)).isEqualTo(OrdenLineas.PREDETERMINADO);
            assertThat(new OrdenLineas(OrdenLineas.Campo.VALOR_GLOSADO, null).sentido())
                    .isEqualTo(OrdenLineas.Sentido.ASCENDENTE);
        }
    }

    @Test
    @DisplayName("el sentido se escribe como lo espera OHI")
    void elSentidoSeEscribeComoLoEsperaOhi() {
        assertThat(OrdenLineas.Sentido.ASCENDENTE.enOhi()).isEqualTo("asc");
        assertThat(OrdenLineas.Sentido.DESCENDENTE.enOhi()).isEqualTo("desc");
    }
}
