package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Version")
class VersionTest {

    @Test
    @DisplayName("dos versiones con el mismo número coinciden")
    void dosVersionesConElMismoNumeroCoinciden() {
        assertThat(new Version(26L).coincideCon(new Version(26L))).isTrue();
    }

    @Test
    @DisplayName("números distintos no coinciden: es el cerrojo optimista")
    void numerosDistintosNoCoinciden() {
        assertThat(new Version(26L).coincideCon(new Version(27L))).isFalse();
    }

    @Test
    @DisplayName("comparar contra nulo no coincide ni lanza excepción")
    void compararContraNuloNoCoincide() {
        assertThat(new Version(1L).coincideCon(null)).isFalse();
    }

    @Test
    @DisplayName("dos versiones con el mismo número son iguales como valor")
    void dosVersionesConElMismoNumeroSonIguales() {
        assertThat(new Version(5L)).isEqualTo(new Version(5L))
                .hasSameHashCodeAs(new Version(5L));
    }
}
