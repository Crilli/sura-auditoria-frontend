package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("TextoDeNovedad")
class TextoDeNovedadTest {

    @Nested
    @DisplayName("marcadores")
    class Marcadores {

        @Test
        @DisplayName("los devuelve en orden de aparición y sin repetir")
        void losDevuelveEnOrdenYSinRepetir() {
            assertThat(TextoDeNovedad.marcadores("{2} vale {0} y otra vez {2}"))
                    .containsExactly(2, 0);
        }

        @Test
        @DisplayName("los índices son dispersos: SURA-AUT-022 usa 0, 1, 2, 4 y 6")
        void losIndicesSonDispersos() {
            assertThat(TextoDeNovedad.marcadores("{0} {1} {2} y {4} con {6}"))
                    .containsExactly(0, 1, 2, 4, 6);
        }

        @Test
        @DisplayName("una llave de dos dígitos NO es marcador: es texto, y hay solo diez valores")
        void unaLlaveDeDosDigitosNoEsMarcador() {
            assertThat(TextoDeNovedad.marcadores("quedan {10} unidades")).isEmpty();
        }

        @Test
        @DisplayName("una plantilla nula da lista vacía, no explota")
        void unaPlantillaNulaDaListaVacia() {
            assertThat(TextoDeNovedad.marcadores(null)).isEmpty();
        }

        @Test
        @DisplayName("una plantilla sin marcadores da lista vacía")
        void unaPlantillaSinMarcadoresDaListaVacia() {
            assertThat(TextoDeNovedad.marcadores("Procedimiento no autorizado")).isEmpty();
        }
    }

    @Nested
    @DisplayName("pideDatos")
    class PideDatos {

        @Test
        @DisplayName("es cierto cuando hay al menos un marcador")
        void esCiertoCuandoHayMarcador() {
            assertThat(TextoDeNovedad.pideDatos("Autorización {2} consumida")).isTrue();
        }

        @Test
        @DisplayName("es falso cuando la plantilla es texto fijo")
        void esFalsoCuandoEsTextoFijo() {
            assertThat(TextoDeNovedad.pideDatos("Sin autorización")).isFalse();
        }
    }

    @Nested
    @DisplayName("resolver")
    class Resolver {

        @Test
        @DisplayName("sustituye cada marcador por su valor")
        void sustituyeCadaMarcadorPorSuValor() {
            var resuelto = TextoDeNovedad.resolver(
                    "Autorización {2} encontrada, restante {6}",
                    Map.of(2, "99073568971", 6, "0"));

            assertThat(resuelto).isEqualTo("Autorización 99073568971 encontrada, restante 0");
        }

        @Test
        @DisplayName("un marcador SIN valor se deja con sus llaves, para que el hueco se vea")
        void unMarcadorSinValorSeDejaConSusLlaves() {
            // La alternativa —dejarlo en blanco— daría una frase que se lee entera
            // y correcta a la que le falta justo el dato, y nadie se daría cuenta.
            var resuelto = TextoDeNovedad.resolver("Autorización {2} encontrada", Map.of());

            assertThat(resuelto).isEqualTo("Autorización {2} encontrada");
        }

        @Test
        @DisplayName("un valor en blanco se trata como ausente: deja el marcador visible")
        void unValorEnBlancoSeTrataComoAusente() {
            var valores = new LinkedHashMap<Integer, String>();
            valores.put(2, "   ");

            assertThat(TextoDeNovedad.resolver("Autorización {2}", valores))
                    .isEqualTo("Autorización {2}");
        }

        @Test
        @DisplayName("un valor con $ viaja literal y no revienta el reemplazo")
        void unValorConDolarViajaLiteral() {
            assertThat(TextoDeNovedad.resolver("Importe {0}", Map.of(0, "$1.500")))
                    .isEqualTo("Importe $1.500");
        }

        @Test
        @DisplayName("un valor con barra invertida viaja literal")
        void unValorConBarraInvertidaViajaLiteral() {
            assertThat(TextoDeNovedad.resolver("Ruta {0}", Map.of(0, "C:\\temp")))
                    .isEqualTo("Ruta C:\\temp");
        }

        @Test
        @DisplayName("un valor para un marcador que la plantilla no usa se ignora")
        void unValorParaMarcadorInexistenteSeIgnora() {
            assertThat(TextoDeNovedad.resolver("Solo {0}", Map.of(0, "uno", 5, "sobra")))
                    .isEqualTo("Solo uno");
        }

        @Test
        @DisplayName("una plantilla nula devuelve nulo")
        void unaPlantillaNulaDevuelveNulo() {
            assertThat(TextoDeNovedad.resolver(null, Map.of(0, "x"))).isNull();
        }

        @Test
        @DisplayName("valores nulos o vacíos dejan la plantilla sin tocar")
        void valoresNulosODeVacioDejanLaPlantillaSinTocar() {
            assertThat(TextoDeNovedad.resolver("Autorización {2}", null))
                    .isEqualTo("Autorización {2}");
            assertThat(TextoDeNovedad.resolver("Autorización {2}", Map.of()))
                    .isEqualTo("Autorización {2}");
        }
    }

    @Nested
    @DisplayName("marcadoresSinValor")
    class MarcadoresSinValor {

        @Test
        @DisplayName("lista los marcadores a los que nadie puso dato")
        void listaLosMarcadoresSinDato() {
            assertThat(TextoDeNovedad.marcadoresSinValor("{0} y {1} y {2}", Map.of(1, "hay")))
                    .containsExactly(0, 2);
        }

        @Test
        @DisplayName("un valor en blanco cuenta como sin valor")
        void unValorEnBlancoCuentaComoSinValor() {
            assertThat(TextoDeNovedad.marcadoresSinValor("{0}", Map.of(0, "  ")))
                    .containsExactly(0);
        }

        @Test
        @DisplayName("con valores nulos, todos los marcadores están sin valor")
        void conValoresNulosTodosEstanSinValor() {
            assertThat(TextoDeNovedad.marcadoresSinValor("{0} {3}", null))
                    .containsExactly(0, 3);
        }

        @Test
        @DisplayName("una plantilla completa no deja ninguno")
        void unaPlantillaCompletaNoDejaNinguno() {
            assertThat(TextoDeNovedad.marcadoresSinValor("{0}", Map.of(0, "dato"))).isEmpty();
        }
    }

    @Nested
    @DisplayName("valoresSobrantes")
    class ValoresSobrantes {

        @Test
        @DisplayName("lista ordenada de los valores que no corresponden a ningún marcador")
        void listaOrdenadaDeLosQueSobran() {
            assertThat(TextoDeNovedad.valoresSobrantes("{1}", Map.of(5, "a", 1, "b", 3, "c")))
                    .containsExactly(3, 5);
        }

        @Test
        @DisplayName("sin valores no sobra nada")
        void sinValoresNoSobraNada() {
            assertThat(TextoDeNovedad.valoresSobrantes("{0}", null)).isEmpty();
            assertThat(TextoDeNovedad.valoresSobrantes("{0}", Map.of())).isEmpty();
        }

        @Test
        @DisplayName("si la plantilla no usa marcadores, todos los valores sobran")
        void siNoHayMarcadoresTodoSobra() {
            assertThat(TextoDeNovedad.valoresSobrantes("texto fijo", Map.of(0, "a", 2, "b")))
                    .containsExactly(0, 2);
        }
    }

    @Test
    @DisplayName("las constantes describen el contrato del sistema de registro")
    void lasConstantesDescribenElContrato() {
        assertThat(TextoDeNovedad.CUANTOS_VALORES).isEqualTo(10);
        assertThat(TextoDeNovedad.LARGO_MAXIMO_VALOR).isEqualTo(300);
    }
}
