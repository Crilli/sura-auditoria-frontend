package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import co.sura.auditoria.modelo.cuenta.MotivoDesfinalizacion.Ambito;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas.AfiliadoConLineas;
import co.sura.auditoria.modelo.cuenta.ResumenFiltrosLineas.CatalogoConLineas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;

/** El resto del modelo de dominio: las piezas de datos y sus reglas pequeñas. */
@DisplayName("Modelo de dominio — resto")
class ModeloRestanteTest {

    private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(148111592284L);
    private static final CodigoCuenta CODIGO = new CodigoCuenta("CM-108800618430");

    // ─────────────────────────────── Novedad ───────────────────────────────

    @Nested
    @DisplayName("Novedad")
    class DeNovedad {

        private static Novedad conValores(String descripcion, Map<Integer, String> valores,
                                          String origen) {
            return new Novedad(1L, "332-1", descripcion, Severidad.INFORMATIVA, origen,
                    new Novedad.Clasificacion("G", "Tarifas"),
                    new Novedad.Clasificacion("E", "Ayudas"),
                    "autor", java.time.Instant.now(), false, valores);
        }

        @Test
        @DisplayName("el texto resuelto completa la plantilla con sus valores")
        void elTextoResueltoCompletaLaPlantilla() {
            assertThat(conValores("Autorización {2} consumida", Map.of(2, "99073568971"), "MANUAL")
                    .textoResuelto())
                    .isEqualTo("Autorización 99073568971 consumida");
        }

        @Test
        @DisplayName("sin valores, el texto resuelto deja los marcadores a la vista")
        void sinValoresDejaLosMarcadores() {
            assertThat(conValores("Autorización {2}", Map.of(), "MANUAL").textoResuelto())
                    .isEqualTo("Autorización {2}");
        }

        @ParameterizedTest(name = "origen [{0}] -> la puso una persona: {1}")
        @CsvSource({"MANUAL, true", "manual, true", "BENEFITS, false",
                    "PRICING, false", "COVERAGE, false"})
        @DisplayName("solo el origen MANUAL es de una persona, sin distinguir mayúsculas")
        void soloManualEsDeUnaPersona(String origen, boolean deUnaPersona) {
            assertThat(conValores("t", Map.of(), origen).laPusoUnaPersona())
                    .isEqualTo(deUnaPersona);
        }

        @Test
        @DisplayName("un origen nulo no es de una persona, y no revienta")
        void unOrigenNuloNoEsDeUnaPersona() {
            assertThat(conValores("t", Map.of(), null).laPusoUnaPersona()).isFalse();
        }

        @Test
        @DisplayName("el constructor corto deja valores vacíos y la marca de sistema en falso")
        void elConstructorCortoDejaValoresVacios() {
            var corta = new Novedad(1L, "332-1", "texto", Severidad.INFORMATIVA, "MANUAL");

            assertThat(corta.valores()).isEmpty();
            assertThat(corta.esDelSistema()).isFalse();
            assertThat(corta.generico()).isNull();
        }

        @Test
        @DisplayName("unos valores nulos se normalizan a mapa vacío")
        void valoresNulosSeNormalizan() {
            assertThat(conValores("t", null, "MANUAL").valores()).isEmpty();
        }

        @Test
        @DisplayName("la clasificación lleva código y descripción")
        void laClasificacionLlevaCodigoYDescripcion() {
            var clasificacion = new Novedad.Clasificacion("208", "Tarifas");

            assertThat(clasificacion.codigo()).isEqualTo("208");
            assertThat(clasificacion.descripcion()).isEqualTo("Tarifas");
        }

        @Test
        @DisplayName("la constante de origen manual es «MANUAL»")
        void laConstanteDeOrigenManual() {
            assertThat(Novedad.ORIGEN_MANUAL).isEqualTo("MANUAL");
        }
    }

    // ─────────────────────────── MensajeCatalogo ───────────────────────────

    @Nested
    @DisplayName("MensajeCatalogo")
    class DeMensajeCatalogo {

        private static MensajeCatalogo mensaje(String texto, Severidad severidad) {
            return new MensajeCatalogo("332-1", texto, severidad, null, null, false);
        }

        @Test
        @DisplayName("sabe qué datos pide su plantilla, en orden y sin repetir")
        void sabeQueDatosPide() {
            assertThat(mensaje("{2} y {0} y {2}", Severidad.INFORMATIVA).datosQuePide())
                    .containsExactly(2, 0);
        }

        @Test
        @DisplayName("un mensaje de texto fijo no pide datos")
        void unMensajeDeTextoFijoNoPideDatos() {
            assertThat(mensaje("Sin autorización", Severidad.INFORMATIVA).pideDatos()).isFalse();
        }

        @Test
        @DisplayName("un mensaje con marcadores sí los pide")
        void unMensajeConMarcadoresLosPide() {
            assertThat(mensaje("Autorización {2}", Severidad.INFORMATIVA).pideDatos()).isTrue();
        }

        @Test
        @DisplayName("textoCon compone el mensaje final")
        void textoConComponeElMensaje() {
            assertThat(mensaje("Autorización {2}", Severidad.INFORMATIVA)
                    .textoCon(Map.of(2, "99073568971")))
                    .isEqualTo("Autorización 99073568971");
        }

        @ParameterizedTest(name = "{0} frena la cuenta: {1}")
        @CsvSource({"BLOQUEANTE, true", "NEGACION, true", "INFORMATIVA, false",
                    "ADVERTENCIA, false", "DESCONOCIDA, false"})
        @DisplayName("frena la cuenta según su severidad")
        void frenaLaCuentaSegunSuSeveridad(Severidad severidad, boolean frena) {
            assertThat(mensaje("t", severidad).frenaLaCuenta()).isEqualTo(frena);
        }

        @Test
        @DisplayName("una severidad nula no frena: ante la duda, no se para la cuenta")
        void unaSeveridadNulaNoFrena() {
            assertThat(mensaje("t", null).frenaLaCuenta()).isFalse();
        }
    }

    // ─────────────────────────── AccionesDisponibles ───────────────────────

    @Nested
    @DisplayName("AccionesDisponibles")
    class DeAccionesDisponibles {

        @Test
        @DisplayName("ninguna no permite nada")
        void ningunaNoPermiteNada() {
            var ninguna = AccionesDisponibles.ninguna();

            assertThat(ninguna.acciones()).isEmpty();
            assertThat(ninguna.permite(AccionCuenta.ENVIAR)).isFalse();
        }

        @Test
        @DisplayName("permite solo lo que contiene")
        void permiteSoloLoQueContiene() {
            var disponibles = new AccionesDisponibles(java.util.Set.of(AccionCuenta.ENVIAR));

            assertThat(disponibles.permite(AccionCuenta.ENVIAR)).isTrue();
            assertThat(disponibles.permite(AccionCuenta.ANULAR)).isFalse();
        }

        @Test
        @DisplayName("un conjunto nulo se normaliza a vacío")
        void unConjuntoNuloSeNormaliza() {
            assertThat(new AccionesDisponibles(null).acciones()).isEmpty();
        }
    }

    // ──────────────────────── MotivoDesfinalizacion ────────────────────────

    @Nested
    @DisplayName("MotivoDesfinalizacion")
    class DeMotivoDesfinalizacion {

        @Test
        @DisplayName("dice si deja las líneas bloqueadas")
        void diceSiDejaLineasBloqueadas() {
            assertThat(new MotivoDesfinalizacion("M1", "d", true, false, Ambito.AMBAS, null)
                    .dejaLineasBloqueadas()).isTrue();
            assertThat(new MotivoDesfinalizacion("M1", "d", false, false, Ambito.AMBAS, null)
                    .dejaLineasBloqueadas()).isFalse();
        }

        @ParameterizedTest
        @EnumSource(Ambito.class)
        @DisplayName("AMBAS alcanza cualquier ámbito")
        void ambasAlcanzaCualquiera(Ambito queEs) {
            assertThat(Ambito.AMBAS.alcanza(queEs)).isTrue();
        }

        @Test
        @DisplayName("un ámbito concreto solo se alcanza a sí mismo")
        void unAmbitoConcretoSoloSeAlcanzaASiMismo() {
            assertThat(Ambito.CUENTA_MEDICA.alcanza(Ambito.CUENTA_MEDICA)).isTrue();
            assertThat(Ambito.CUENTA_MEDICA.alcanza(Ambito.AUTORIZACION)).isFalse();
            assertThat(Ambito.AUTORIZACION.alcanza(Ambito.CUENTA_MEDICA)).isFalse();
        }

        @Test
        @DisplayName("DESCONOCIDO no alcanza nada salvo a sí mismo")
        void desconocidoNoAlcanzaNada() {
            assertThat(Ambito.DESCONOCIDO.alcanza(Ambito.CUENTA_MEDICA)).isFalse();
            assertThat(Ambito.DESCONOCIDO.alcanza(Ambito.DESCONOCIDO)).isTrue();
        }
    }

    // ───────────────────────────── CuentaMedica ────────────────────────────

    @Nested
    @DisplayName("CuentaMedica")
    class DeCuentaMedica {

        private static MotivoPendiente pendiente(boolean resuelto) {
            return new MotivoPendiente(1L, "AUD01", "d", resuelto, false,
                    NivelPendiente.CABECERA, null, null, new Version(1L));
        }

        private static CuentaMedica cuenta(List<MotivoPendiente> pendientes,
                                           InformacionFacturacion facturacion) {
            return new CuentaMedica(CODIGO, EstadoCuenta.MODIFICACION, LocalDate.now(),
                    LocalDate.now(), BigDecimal.TEN, BigDecimal.TEN, new Version(1L),
                    pendientes, List.of(), facturacion, List.of());
        }

        @Test
        @DisplayName("tiene pendientes sin resolver si queda al menos uno vivo")
        void tienePendientesSinResolverSiQuedaUnoVivo() {
            assertThat(cuenta(List.of(pendiente(true), pendiente(false)), null)
                    .tienePendientesSinResolver()).isTrue();
        }

        @Test
        @DisplayName("con todos resueltos, no tiene pendientes")
        void conTodosResueltosNoTienePendientes() {
            assertThat(cuenta(List.of(pendiente(true)), null)
                    .tienePendientesSinResolver()).isFalse();
        }

        @Test
        @DisplayName("sin pendientes, tampoco")
        void sinPendientesTampoco() {
            assertThat(cuenta(List.of(), null).tienePendientesSinResolver()).isFalse();
        }

        @Test
        @DisplayName("unos pendientes nulos se normalizan a lista vacía")
        void pendientesNulosSeNormalizan() {
            assertThat(cuenta(null, null).pendientesCabecera()).isEmpty();
        }

        @Test
        @DisplayName("una facturación nula se sustituye por la vacía, nunca queda null")
        void facturacionNulaSeSustituyePorLaVacia() {
            assertThat(cuenta(List.of(), null).informacionFacturacion())
                    .isSameAs(InformacionFacturacion.vacia());
        }

        @Test
        @DisplayName("una facturación dada se conserva")
        void unaFacturacionDadaSeConserva() {
            var propia = new InformacionFacturacion(
                    "860007336", "CLINICA UNO",          // prestador de facturación: NIT y nombre
                    "MEDI1", null,                        // factura y radicado
                    null, null, null, null, null,         // las cinco fechas
                    BigDecimal.TEN,                       // valor factura
                    null, null, null, null, null,         // el resto de importes
                    null, null, null, null, null,         // tipo de servicio, acuse y marcas
                    null, null,                           // observaciones
                    null, null);                          // pagar a: NIT y nombre

            assertThat(cuenta(List.of(), propia).informacionFacturacion()).isSameAs(propia);
        }
    }

    @Test
    @DisplayName("InformacionFacturacion.vacia es un único ejemplar reutilizado")
    void laFacturacionVaciaEsUnicoEjemplar() {
        assertThat(InformacionFacturacion.vacia()).isSameAs(InformacionFacturacion.vacia());
        assertThat(InformacionFacturacion.vacia().numeroFactura()).isNull();
    }

    // ─────────────────────────── PaginaPendientes ──────────────────────────

    @Nested
    @DisplayName("PaginaPendientes")
    class DePaginaPendientes {

        private static MotivoPendiente pendiente(boolean soloAdjudicacion) {
            return new MotivoPendiente(1L, "AUD01", "d", false, soloAdjudicacion,
                    NivelPendiente.CABECERA, null, null, new Version(1L));
        }

        @Test
        @DisplayName("pregunta al pendiente si bloquea EN EL ESTADO de esta página")
        void preguntaSiBloqueaEnElEstadoDeLaPagina() {
            var enAdjudicacion = new PaginaPendientes(
                    Pagina.<MotivoPendiente>vacia(25), EstadoCuenta.ADJUDICACION_MANUAL);
            var enModificacion = new PaginaPendientes(
                    Pagina.<MotivoPendiente>vacia(25), EstadoCuenta.MODIFICACION);

            // El mismo pendiente bloquea o no según el estado de la cuenta.
            assertThat(enAdjudicacion.bloquea(pendiente(true))).isTrue();
            assertThat(enModificacion.bloquea(pendiente(true))).isFalse();
        }

        @Test
        @DisplayName("conserva la página y el estado que se le dieron")
        void conservaLaPaginaYElEstado() {
            var pagina = Pagina.<MotivoPendiente>vacia(25);
            var pendientes = new PaginaPendientes(pagina, EstadoCuenta.FINALIZADA);

            assertThat(pendientes.pagina()).isSameAs(pagina);
            assertThat(pendientes.estado()).isEqualTo(EstadoCuenta.FINALIZADA);
        }
    }

    // ────────────────────────── ResumenFiltrosLineas ───────────────────────

    @Nested
    @DisplayName("ResumenFiltrosLineas")
    class DeResumenFiltros {

        @Test
        @DisplayName("el vacío no tiene nada y no es multiafiliado")
        void elVacioNoTieneNada() {
            var vacio = ResumenFiltrosLineas.vacio();

            assertThat(vacio.afiliados()).isEmpty();
            assertThat(vacio.catalogos()).isEmpty();
            assertThat(vacio.totalLineas()).isZero();
            assertThat(vacio.esMultiafiliado()).isFalse();
            assertThat(vacio.sinGlosas()).isTrue();
        }

        @Test
        @DisplayName("con más de un afiliado, la cuenta es multiafiliado")
        void conMasDeUnAfiliadoEsMultiafiliado() {
            var dos = new ResumenFiltrosLineas(
                    List.of(new AfiliadoConLineas("CC1", "Uno", 3),
                            new AfiliadoConLineas("CC2", "Dos", 2)),
                    List.of(), null, null, null, 0, 5);

            assertThat(dos.esMultiafiliado()).isTrue();
        }

        @Test
        @DisplayName("con un solo afiliado, no lo es")
        void conUnSoloAfiliadoNoLoEs() {
            var uno = new ResumenFiltrosLineas(
                    List.of(new AfiliadoConLineas("CC1", "Uno", 3)),
                    List.of(), null, null, null, 0, 3);

            assertThat(uno.esMultiafiliado()).isFalse();
        }

        @Test
        @DisplayName("hay glosas en cuanto una línea las tenga")
        void hayGlosasEnCuantoUnaLineaLasTenga() {
            var conGlosa = new ResumenFiltrosLineas(List.of(), List.of(), null, null,
                    BigDecimal.TEN, 1, 5);

            assertThat(conGlosa.sinGlosas()).isFalse();
        }

        @Test
        @DisplayName("las listas nulas se normalizan a vacías")
        void lasListasNulasSeNormalizan() {
            var conNulos = new ResumenFiltrosLineas(null, null, null, null, null, 0, 0);

            assertThat(conNulos.afiliados()).isEmpty();
            assertThat(conNulos.catalogos()).isEmpty();
        }

        @Test
        @DisplayName("los conteos por afiliado y por catálogo llevan su cifra")
        void losConteosLlevanSuCifra() {
            assertThat(new AfiliadoConLineas("CC1", "Uno", 7).lineas()).isEqualTo(7);
            assertThat(new CatalogoConLineas(CatalogoPrestacion.CUPS, 4).lineas()).isEqualTo(4);
            assertThat(new CatalogoConLineas(CatalogoPrestacion.CUM, 1).catalogo())
                    .isEqualTo(CatalogoPrestacion.CUM);
        }
    }

    // ───────────────────────────── LineaCuenta ─────────────────────────────

    @Nested
    @DisplayName("LineaCuenta")
    class DeLineaCuenta {

        private static Novedad novedad(Severidad severidad) {
            return new Novedad(1L, "332-1", "t", severidad, "MANUAL");
        }

        private static LineaCuenta linea(boolean bloqueada, boolean reemplazada,
                                         List<DiagnosticoLinea> diagnosticos,
                                         List<Novedad> novedades) {
            return new LineaCuenta(REFERENCIA, CODIGO, 1, LocalDate.now(), LocalDate.now(),
                    "CC1", "Afiliado", "873206", "Radiografía", "CUPS",
                    BigDecimal.TEN, BigDecimal.ONE, BigDecimal.TEN, BigDecimal.ONE,
                    BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ZERO, "obs", "AUT1",
                    "900011436-001", "Prestador", false, false, false, false,
                    bloqueada, reemplazada, null, null, null,
                    diagnosticos, List.of(), novedades, List.of(), null, new Version(1L));
        }

        @Test
        @DisplayName("es editable solo si no está bloqueada ni reemplazada, y entonces no hay razón")
        void esEditableSoloSiNoEstaBloqueadaNiReemplazada() {
            var editable = linea(false, false, List.of(), List.of());

            assertThat(editable.esEditable()).isTrue();
            assertThat(editable.razonNoEditable()).isNull();
        }

        @Test
        @DisplayName("si está bloqueada, la razón lo dice y gana sobre reemplazada")
        void siEstaBloqueadaLaRazonLoDice() {
            assertThat(linea(true, true, List.of(), List.of()).razonNoEditable())
                    .isEqualTo("La línea está bloqueada");
        }

        @Test
        @DisplayName("si solo está reemplazada, la razón es esa")
        void siSoloEstaReemplazadaLaRazonEsEsa() {
            assertThat(linea(false, true, List.of(), List.of()).razonNoEditable())
                    .isEqualTo("La línea fue reemplazada");
        }

        @Test
        @DisplayName("tiene novedad bloqueante si alguna frena la cuenta")
        void tieneNovedadBloqueanteSiAlgunaFrena() {
            assertThat(linea(false, false, List.of(),
                    List.of(novedad(Severidad.INFORMATIVA), novedad(Severidad.NEGACION)))
                    .tieneNovedadBloqueante()).isTrue();
        }

        @Test
        @DisplayName("sin novedades que frenen, no la tiene")
        void sinNovedadesQueFrenenNoLaTiene() {
            assertThat(linea(false, false, List.of(), List.of(novedad(Severidad.ADVERTENCIA)))
                    .tieneNovedadBloqueante()).isFalse();
            assertThat(linea(false, false, List.of(), List.of())
                    .tieneNovedadBloqueante()).isFalse();
        }

        @Test
        @DisplayName("el diagnóstico principal es el marcado como tal, aunque no sea el primero")
        void elDiagnosticoPrincipalEsElMarcado() {
            var secundario = new DiagnosticoLinea(1, "SECUNDARIO", "Secundario", "S61", "d");
            var principal = new DiagnosticoLinea(2, "principal", "Principal", "S62", "d");

            assertThat(linea(false, false, List.of(secundario, principal), List.of())
                    .diagnosticoPrincipal()).isEqualTo(principal);
        }

        @Test
        @DisplayName("si ninguno está marcado, se toma el primero antes que devolver nada")
        void siNingunoEstaMarcadoSeTomaElPrimero() {
            var uno = new DiagnosticoLinea(1, "SECUNDARIO", "S", "S61", "d");
            var otro = new DiagnosticoLinea(2, "SECUNDARIO", "S", "S62", "d");

            assertThat(linea(false, false, List.of(uno, otro), List.of())
                    .diagnosticoPrincipal()).isEqualTo(uno);
        }

        @Test
        @DisplayName("sin diagnósticos no hay principal, y no revienta")
        void sinDiagnosticosNoHayPrincipal() {
            assertThat(linea(false, false, List.of(), List.of()).diagnosticoPrincipal()).isNull();
        }

        @Test
        @DisplayName("las colecciones nulas se normalizan y los bloques opcionales nunca quedan null")
        void lasColeccionesNulasSeNormalizan() {
            var conNulos = new LineaCuenta(REFERENCIA, CODIGO, 1, null, null, null, null,
                    null, null, null, null, null, null, null, null, null, null, null, null,
                    null, null, false, false, false, false, false, false,
                    null, null, null, null, null, null, null, null, new Version(1L));

            assertThat(conNulos.novedades()).isEmpty();
            assertThat(conNulos.pendientes()).isEmpty();
            assertThat(conNulos.diagnosticos()).isEmpty();
            assertThat(conNulos.glosas()).isEmpty();
            assertThat(conNulos.prestacion()).isNotNull();
            assertThat(conNulos.convenio()).isNotNull();
            assertThat(conNulos.otrosDatos()).isNotNull();
        }
    }

    // ──────────────────── piezas de datos sin lógica propia ────────────────

    @Nested
    @DisplayName("piezas de datos")
    class PiezasDeDatos {

        @Test
        @DisplayName("Prestacion transporta la identificación de lo prestado")
        void prestacion() {
            var p = new Prestacion("873206", "Radiografía", "CUPS", "ND", "NDD",
                    "rips", "clase", "especialidad");

            assertThat(p.codigo()).isEqualTo("873206");
            assertThat(p.descripcion()).isEqualTo("Radiografía");
            assertThat(p.catalogo()).isEqualTo("CUPS");
            assertThat(p.especialidad()).isEqualTo("especialidad");
        }

        @Test
        @DisplayName("DatosConvenio transporta tarifas y contrato")
        void datosConvenio() {
            var c = new DatosConvenio("iss2001", "iss2000", "soat", "contrato", "cups",
                    "multiples", "siifa", BigDecimal.TEN, "tarifa");

            assertThat(c.numeroContrato()).isEqualTo("contrato");
            assertThat(c.valorConvenido()).isEqualByComparingTo(BigDecimal.TEN);
            assertThat(c.codigoUnicoContratoSiifa()).isEqualTo("siifa");
        }

        @Test
        @DisplayName("OtrosDatosLinea transporta sala, vía, UEN y siniestro")
        void otrosDatosLinea() {
            var o = new OtrosDatosLinea("sala", "via", "uen", "siniestro");

            assertThat(o.tipoSala()).isEqualTo("sala");
            assertThat(o.unidadEstrategicaNegocio()).isEqualTo("uen");
            assertThat(o.codigoSiniestro()).isEqualTo("siniestro");
        }

        @Test
        @DisplayName("DiagnosticoLinea transporta secuencia, tipo y código")
        void diagnosticoLinea() {
            var d = new DiagnosticoLinea(1, "PRINCIPAL", "Principal", "S61", "Herida");

            assertThat(d.secuencia()).isEqualTo(1);
            assertThat(d.tipo()).isEqualTo("PRINCIPAL");
            assertThat(d.codigo()).isEqualTo("S61");
            assertThat(d.descripcion()).isEqualTo("Herida");
        }

        @Test
        @DisplayName("TiqueteProceso ata la cuenta con su referencia de seguimiento")
        void tiqueteProceso() {
            var t = new TiqueteProceso(CODIGO, "PROC-2026-1016-000178");

            assertThat(t.codigoCuenta()).isEqualTo(CODIGO);
            assertThat(t.referenciaSeguimiento()).isEqualTo("PROC-2026-1016-000178");
        }

        @Test
        @DisplayName("ResumenMotivoPendiente transporta el conteo y las marcas del motivo")
        void resumenMotivoPendiente() {
            var r = new ResumenMotivoPendiente("AUD01", "Auditoría", 3, 7, true, false, true);

            assertThat(r.codigo()).isEqualTo("AUD01");
            assertThat(r.sinResolver()).isEqualTo(3);
            assertThat(r.lineasAfectadas()).isEqualTo(7);
            assertThat(r.enCabecera()).isTrue();
            assertThat(r.soloAdjudicacion()).isFalse();
            assertThat(r.bloqueante()).isTrue();
        }

        @Test
        @DisplayName("EstadoProceso normaliza los errores nulos a lista vacía")
        void estadoProceso() {
            var sinErrores = new EstadoProceso(EstadoProceso.Avance.EXITOSO, true, null);

            assertThat(sinErrores.errores()).isEmpty();
            assertThat(sinErrores.avance()).isEqualTo(EstadoProceso.Avance.EXITOSO);
            assertThat(sinErrores.finalizado()).isTrue();
        }

        @Test
        @DisplayName("los cuatro avances del proceso existen")
        void losCuatroAvances() {
            assertThat(EstadoProceso.Avance.values()).containsExactly(
                    EstadoProceso.Avance.NO_INICIADO, EstadoProceso.Avance.EN_PROCESO,
                    EstadoProceso.Avance.EXITOSO, EstadoProceso.Avance.FALLIDO);
        }

        @Test
        @DisplayName("InformacionFacturacion transporta los datos de la factura")
        void informacionFacturacion() {
            var f = new InformacionFacturacion("860007336", "CLINICA UNO", "MEDI26795756", "RAD1",
                    LocalDate.of(2026, 8, 13), LocalDate.of(2026, 8, 12),
                    LocalDate.of(2026, 9, 12), null, null,
                    new BigDecimal("93000"), new BigDecimal("93000"), null, null,
                    BigDecimal.ZERO, null, "servicio", "000032183953", "N", "N", "N",
                    "internas", "externas", "900011436", "IPS QUE COBRA");

            assertThat(f.numeroFactura()).isEqualTo("MEDI26795756");
            assertThat(f.valorFactura()).isEqualByComparingTo("93000");
            assertThat(f.acuseRecibido()).isEqualTo("000032183953");
            assertThat(f.pagarAPrestadorNit()).isEqualTo("900011436");
            assertThat(f.fechaEmision()).isEqualTo(LocalDate.of(2026, 8, 12));
        }
    }
}
