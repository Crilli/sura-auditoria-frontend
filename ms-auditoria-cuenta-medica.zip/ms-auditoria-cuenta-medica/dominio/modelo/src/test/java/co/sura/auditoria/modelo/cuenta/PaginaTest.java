package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;
import java.util.function.ToLongFunction;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("Pagina")
class PaginaTest {

    /** Elemento mínimo con una referencia, para no depender de una entidad real. */
    private record Elemento(long referencia) {}

    private static final ToLongFunction<Elemento> REFERENCIA = Elemento::referencia;

    private static List<Elemento> elementos(long... referencias) {
        return java.util.Arrays.stream(referencias).mapToObj(Elemento::new).toList();
    }

    @Nested
    @DisplayName("regla de corte")
    class ReglaDeCorte {

        @Test
        @DisplayName("una página incompleta es la última: no hay cursor siguiente")
        void unaPaginaIncompletaEsLaUltima() {
            var pagina = Pagina.construir(elementos(10, 20, 30), 5, null, REFERENCIA);

            assertThat(pagina.cursorSiguiente()).isEmpty();
        }

        @Test
        @DisplayName("una página llena ofrece cursor siguiente, porque puede haber más")
        void unaPaginaLlenaOfreceCursorSiguiente() {
            var pagina = Pagina.construir(elementos(10, 20, 30), 3, null, REFERENCIA);

            assertThat(pagina.cursorSiguiente()).isPresent();
        }

        @Test
        @DisplayName("una página vacía con tamaño cero no ofrece cursor, pese a estar «llena»")
        void unaPaginaVaciaConTamanoCeroNoOfreceCursor() {
            var pagina = Pagina.construir(List.of(), 0, null, REFERENCIA);

            assertThat(pagina.cursorSiguiente()).isEmpty();
            assertThat(pagina.elementos()).isEmpty();
        }
    }

    @Nested
    @DisplayName("cálculo del cursor")
    class CalculoDelCursor {

        @Test
        @DisplayName("el cursor es el MÁXIMO de referencia, no el del último elemento de la lista")
        void elCursorEsElMaximoNoElUltimo() {
            // Entregados por un campo de negocio (p. ej. numeroLinea) que NO coincide
            // con la referencia que gobierna el keyset: el último es el 7, el máximo el 99.
            var pagina = Pagina.construir(elementos(99, 42, 7), 3, null, REFERENCIA);

            assertThat(pagina.cursorSiguiente())
                    .contains(new Cursor(99L));
        }

        @Test
        @DisplayName("con un solo elemento el cursor es su propia referencia")
        void conUnSoloElementoElCursorEsSuReferencia() {
            var pagina = Pagina.construir(elementos(5), 1, null, REFERENCIA);

            assertThat(pagina.cursorSiguiente()).contains(new Cursor(5L));
        }
    }

    @Nested
    @DisplayName("total de registros")
    class TotalDeRegistros {

        @Test
        @DisplayName("un total nulo se traduce a vacío, no a cero")
        void unTotalNuloSeTraduceAVacio() {
            var pagina = Pagina.construir(elementos(1), 10, null, REFERENCIA);

            assertThat(pagina.totalRegistros()).isEmpty();
        }

        @Test
        @DisplayName("un total presente se conserva")
        void unTotalPresenteSeConserva() {
            var pagina = Pagina.construir(elementos(1), 10, 3507L, REFERENCIA);

            assertThat(pagina.totalRegistros()).contains(3507L);
        }
    }

    @Nested
    @DisplayName("página vacía")
    class PaginaVacia {

        @Test
        @DisplayName("no tiene elementos ni cursor, y su total es cero")
        void noTieneElementosNiCursorYSuTotalEsCero() {
            Pagina<Elemento> pagina = Pagina.vacia(50);

            assertThat(pagina.elementos()).isEmpty();
            assertThat(pagina.cursorSiguiente()).isEmpty();
            assertThat(pagina.totalRegistros()).contains(0L);
            assertThat(pagina.tamanoPagina()).isEqualTo(50);
        }
    }

    @Test
    @DisplayName("los elementos quedan inmutables: modificar la lista original no la afecta")
    void losElementosQuedanInmutables() {
        var original = new java.util.ArrayList<>(elementos(1, 2));
        var pagina = Pagina.construir(original, 10, null, REFERENCIA);

        original.add(new Elemento(3));

        assertThat(pagina.elementos()).hasSize(2);
        assertThatThrownBy(() -> pagina.elementos().add(new Elemento(4)))
                .isInstanceOf(UnsupportedOperationException.class);
    }
}
