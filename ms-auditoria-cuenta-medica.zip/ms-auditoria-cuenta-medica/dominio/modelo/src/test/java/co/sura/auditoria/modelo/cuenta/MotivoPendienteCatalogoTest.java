package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("MotivoPendienteCatalogo")
class MotivoPendienteCatalogoTest {

    @Test
    @Tag("DBG-05")
    @DisplayName("lleva su código, su texto y el indicador del sistema de registro")
    void llevaCodigoTextoEIndicador() {
        var motivo = new MotivoPendienteCatalogo(
                "MP_VALIDAR_INFORMACION", "Validar información de la línea", true);

        assertThat(motivo.codigo()).isEqualTo("MP_VALIDAR_INFORMACION");
        assertThat(motivo.etiqueta()).isEqualTo("Validar información de la línea");
        assertThat(motivo.soloAdjudicacion()).isTrue();
    }

    @ParameterizedTest(name = "descripcion = [{0}]")
    @NullSource
    @ValueSource(strings = {"", "   "})
    @Tag("DBG-05")
    @DisplayName("sin texto se lee el código: un selector con huecos no sirve para elegir")
    void sinTextoSeLeeElCodigo(String descripcion) {
        var motivo = new MotivoPendienteCatalogo("MP_SIN_TEXTO", descripcion, false);

        assertThat(motivo.etiqueta()).isEqualTo("MP_SIN_TEXTO");
    }

    @ParameterizedTest(name = "codigo = [{0}]")
    @NullSource
    @ValueSource(strings = {"", "   "})
    @Tag("DBG-05")
    @DisplayName("sin código no hay motivo: es lo único con lo que se le pide al sistema")
    void sinCodigoNoHayMotivo(String codigo) {
        assertThatThrownBy(() -> new MotivoPendienteCatalogo(codigo, "texto", false))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("código");
    }
}
