package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.HashSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("EstadoCuenta")
class EstadoCuentaTest {

    @Nested
    @DisplayName("esTerminal")
    class EsTerminal {

        @Test
        @DisplayName("solo ANULADA es terminal")
        void soloAnuladaEsTerminal() {
            assertThat(EstadoCuenta.ANULADA.esTerminal()).isTrue();
        }

        @ParameterizedTest
        @EnumSource(value = EstadoCuenta.class, names = "ANULADA", mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("ninguno de los demás lo es, ni siquiera FINALIZADA")
        void ningunOtroEsTerminal(EstadoCuenta estado) {
            // FINALIZADA no es terminal: una cuenta finalizada se puede desfinalizar.
            assertThat(estado.esTerminal()).isFalse();
        }
    }

    /**
     * La regla del 2026-10-21: los datos de la cuenta solo se cambian en modificación.
     *
     * <p>Sustituye a {@code permiteIntervencionManual}, que daba por editables cinco estados y
     * por eso contradecía la regla; nadie la usaba fuera de su prueba.
     */
    @Nested
    @DisplayName("admiteCambiosDeDatos")
    class AdmiteCambiosDeDatos {

        @Test
        @Tag("EST-01.1")
        @DisplayName("[EST-01.1] en MODIFICACION se admiten")
        void enModificacionSeAdmiten() {
            assertThat(EstadoCuenta.MODIFICACION.admiteCambiosDeDatos()).isTrue();
        }

        @ParameterizedTest(name = "{0}")
        @Tag("EST-01.2")
        @Tag("EST-01.3")
        @EnumSource(value = EstadoCuenta.class, names = "MODIFICACION",
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("[EST-01.2][EST-01.3] en cualquier otro estado no, tampoco en los manuales ni en DESCONOCIDO")
        void enCualquierOtroNo(EstadoCuenta estado) {
            // Incluye ADJUDICACION_MANUAL, donde el sistema de registro SÍ acepta el parche
            // (medido): la regla es nuestra y solo quita. Y DESCONOCIDO: ante la duda, no se edita.
            assertThat(estado.admiteCambiosDeDatos()).isFalse();
        }
    }

    /**
     * Las palabras de cada estado, letra por letra las de la columna {@code texto} de
     * {@code NOMBRES} en {@code estado-cuenta.model.ts} del frontend. El mensaje de
     * CUENTA_NO_MODIFICABLE las usa, y la pantalla lo enseña tal cual junto a su propio
     * rótulo del estado: escritas distinto, parecerían dos estados.
     */
    @Nested
    @Tag("EST-01.6")  // las palabras del mensaje del 409 CUENTA_NO_MODIFICABLE
    @DisplayName("enPalabras")
    class EnPalabras {

        @ParameterizedTest(name = "{0} → {1}")
        @CsvSource(delimiter = '|', textBlock = """
                INICIAL                          | Inicial
                DIGITACION                       | Digitación
                MODIFICACION                     | Modificación
                TARIFACION_MANUAL                | Tarifación manual
                BENEFICIOS_MANUALES              | Beneficios manuales
                ADJUDICACION_MANUAL              | Adjudicación manual
                TARIFACION_ADJUDICACION_MANUAL   | Tarifación y adjudicación manual
                TARIFACION_COMPLETA              | Tarifación hecha
                BENEFICIOS_COMPLETOS             | Beneficios hechos
                ADJUDICACION_COMPLETA            | Adjudicación hecha
                TARIFACION_ADJUDICACION_COMPLETA | Tarifación y adjudicación hechas
                TARIFACION_FINALIZADA            | Tarifación finalizada
                ENVIADA_A_PREPROCESO             | Enviada a preproceso
                ENVIADA_A_TARIFACION             | Enviada a tarifación
                EN_PROCESO                       | En proceso
                FINALIZADA                       | Finalizada
                ANULADA                          | Anulada
                DESCONOCIDO                      | Estado no reconocido
                """)
        @DisplayName("cada estado se escribe como en la pantalla")
        void cadaEstadoComoEnLaPantalla(EstadoCuenta estado, String palabras) {
            assertThat(estado.enPalabras()).isEqualTo(palabras);
        }

        @Test
        @DisplayName("no hay dos estados con las mismas palabras: se distinguirían solo por el enum")
        void noHayDosIguales() {
            var vistas = new HashSet<String>();
            assertThat(Arrays.stream(EstadoCuenta.values()).map(EstadoCuenta::enPalabras))
                    .allSatisfy(palabras -> assertThat(vistas.add(palabras))
                            .as("repetida: %s", palabras).isTrue());
        }
    }

    @Nested
    @DisplayName("bloqueo por pendientes")
    class BloqueoPorPendientes {

        @Test
        @DisplayName("en ADJUDICACION_MANUAL cualquier pendiente frena el envío")
        void enAdjudicacionManualTodoPendienteFrena() {
            assertThat(EstadoCuenta.ADJUDICACION_MANUAL.todoPendienteBloqueaEnvio()).isTrue();
        }

        @ParameterizedTest
        @EnumSource(value = EstadoCuenta.class, names = "ADJUDICACION_MANUAL",
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("en el resto de estados no todos los pendientes frenan")
        void enElRestoNoTodosFrenan(EstadoCuenta estado) {
            assertThat(estado.todoPendienteBloqueaEnvio()).isFalse();
        }

        @Test
        @DisplayName("en ADJUDICACION_MANUAL bloquea incluso un pendiente solo de adjudicación")
        void enAdjudicacionManualBloqueaAunSiendoSoloDeAdjudicacion() {
            assertThat(EstadoCuenta.ADJUDICACION_MANUAL.bloqueaPendiente(true)).isTrue();
        }

        @Test
        @DisplayName("fuera de ADJUDICACION_MANUAL, un pendiente solo de adjudicación NO bloquea")
        void fueraDeAdjudicacionManualUnPendienteDeAdjudicacionNoBloquea() {
            assertThat(EstadoCuenta.MODIFICACION.bloqueaPendiente(true)).isFalse();
        }

        @ParameterizedTest
        @EnumSource(EstadoCuenta.class)
        @DisplayName("un pendiente que no es solo de adjudicación bloquea siempre")
        void unPendienteGeneralBloqueaSiempre(EstadoCuenta estado) {
            assertThat(estado.bloqueaPendiente(false)).isTrue();
        }
    }

    @Test
    @DisplayName("existe DESCONOCIDO: el estado IN PROCESS de OHI no está en el diccionario")
    void existeDesconocido() {
        // Sin este valor, un estado que OHI devuelve y el diccionario no contempla
        // obligaría a fallar en vez de degradar.
        assertThat(EstadoCuenta.valueOf("DESCONOCIDO")).isNotNull();
    }
}
