package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.EnumSet;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("EstadoCuenta")
class EstadoCuentaTest {

    /** Los estados en los que el auditor puede meter mano. */
    private static final EnumSet<EstadoCuenta> MANUALES = EnumSet.of(
            EstadoCuenta.MODIFICACION,
            EstadoCuenta.TARIFACION_MANUAL,
            EstadoCuenta.BENEFICIOS_MANUALES,
            EstadoCuenta.ADJUDICACION_MANUAL,
            EstadoCuenta.TARIFACION_ADJUDICACION_MANUAL);

    @Nested
    @DisplayName("esTerminal")
    class EsTerminal {

        @Test
        @DisplayName("solo ANULADA es terminal")
        void soloAnuladaEsTerminal() {
            assertThat(EstadoCuenta.ANULADA.esTerminal()).isTrue();
        }

        @ParameterizedTest
        @EnumSource(value = EstadoCuenta.class, names = "ANULADA", mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("ninguno de los demás lo es, ni siquiera FINALIZADA")
        void ningunOtroEsTerminal(EstadoCuenta estado) {
            // FINALIZADA no es terminal: una cuenta finalizada se puede desfinalizar.
            assertThat(estado.esTerminal()).isFalse();
        }
    }

    @Nested
    @DisplayName("permiteIntervencionManual")
    class PermiteIntervencionManual {

        @ParameterizedTest
        @EnumSource(EstadoCuenta.class)
        @DisplayName("exactamente los cinco estados manuales la permiten")
        void exactamenteLosCincoManuales(EstadoCuenta estado) {
            assertThat(estado.permiteIntervencionManual())
                    .isEqualTo(MANUALES.contains(estado));
        }

        @Test
        @DisplayName("EN_PROCESO no la permite, pese a que suene a estado vivo")
        void enProcesoNoLaPermite() {
            assertThat(EstadoCuenta.EN_PROCESO.permiteIntervencionManual()).isFalse();
        }

        @Test
        @DisplayName("DESCONOCIDO no la permite: ante la duda, no se interviene")
        void desconocidoNoLaPermite() {
            assertThat(EstadoCuenta.DESCONOCIDO.permiteIntervencionManual()).isFalse();
        }
    }

    @Nested
    @DisplayName("bloqueo por pendientes")
    class BloqueoPorPendientes {

        @Test
        @DisplayName("en ADJUDICACION_MANUAL cualquier pendiente frena el envío")
        void enAdjudicacionManualTodoPendienteFrena() {
            assertThat(EstadoCuenta.ADJUDICACION_MANUAL.todoPendienteBloqueaEnvio()).isTrue();
        }

        @ParameterizedTest
        @EnumSource(value = EstadoCuenta.class, names = "ADJUDICACION_MANUAL",
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("en el resto de estados no todos los pendientes frenan")
        void enElRestoNoTodosFrenan(EstadoCuenta estado) {
            assertThat(estado.todoPendienteBloqueaEnvio()).isFalse();
        }

        @Test
        @DisplayName("en ADJUDICACION_MANUAL bloquea incluso un pendiente solo de adjudicación")
        void enAdjudicacionManualBloqueaAunSiendoSoloDeAdjudicacion() {
            assertThat(EstadoCuenta.ADJUDICACION_MANUAL.bloqueaPendiente(true)).isTrue();
        }

        @Test
        @DisplayName("fuera de ADJUDICACION_MANUAL, un pendiente solo de adjudicación NO bloquea")
        void fueraDeAdjudicacionManualUnPendienteDeAdjudicacionNoBloquea() {
            assertThat(EstadoCuenta.MODIFICACION.bloqueaPendiente(true)).isFalse();
        }

        @ParameterizedTest
        @EnumSource(EstadoCuenta.class)
        @DisplayName("un pendiente que no es solo de adjudicación bloquea siempre")
        void unPendienteGeneralBloqueaSiempre(EstadoCuenta estado) {
            assertThat(estado.bloqueaPendiente(false)).isTrue();
        }
    }

    @Test
    @DisplayName("existe DESCONOCIDO: el estado IN PROCESS de OHI no está en el diccionario")
    void existeDesconocido() {
        // Sin este valor, un estado que OHI devuelve y el diccionario no contempla
        // obligaría a fallar en vez de degradar.
        assertThat(EstadoCuenta.valueOf("DESCONOCIDO")).isNotNull();
    }
}
