package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("EdicionLinea")
class EdicionLineaTest {

    private static final ReferenciaLinea REFERENCIA = new ReferenciaLinea(148111592284L);
    private static final Version VERSION = new Version(1L);

    /** Edición vacía, a la que cada prueba le pone solo lo que quiere probar. */
    private static Constructor vacia() {
        return new Constructor();
    }

    /** Pequeño constructor fluido: el record tiene 23 componentes. */
    private static final class Constructor {
        private Optional<BigDecimal> valorAutorizado = Optional.empty();
        private Optional<BigDecimal> unidadesAutorizadas = Optional.empty();
        private Optional<Boolean> conservarBeneficios = Optional.empty();
        private Optional<String> observacionesGlosa = Optional.empty();
        private Optional<BigDecimal> valorCargado = Optional.empty();
        private Optional<BigDecimal> valorGlosado = Optional.empty();
        private Optional<LocalDate> fechaInicio = Optional.empty();
        private List<CambioGlosa> glosas = List.of();
        private List<CambioNovedad> novedades = List.of();

        Constructor valorAutorizado(String v) {
            this.valorAutorizado = Optional.of(new BigDecimal(v)); return this;
        }
        Constructor unidadesAutorizadas(String v) {
            this.unidadesAutorizadas = Optional.of(new BigDecimal(v)); return this;
        }
        Constructor conservarBeneficios(boolean v) {
            this.conservarBeneficios = Optional.of(v); return this;
        }
        Constructor observacionesGlosa(String v) {
            this.observacionesGlosa = Optional.of(v); return this;
        }
        Constructor valorCargado(String v) {
            this.valorCargado = Optional.of(new BigDecimal(v)); return this;
        }
        Constructor valorGlosado(String v) {
            this.valorGlosado = Optional.of(new BigDecimal(v)); return this;
        }
        Constructor fechaInicio(LocalDate v) { this.fechaInicio = Optional.of(v); return this; }
        Constructor glosas(CambioGlosa... g) { this.glosas = List.of(g); return this; }
        Constructor novedades(CambioNovedad... n) { this.novedades = List.of(n); return this; }

        EdicionLinea construir() {
            return new EdicionLinea(REFERENCIA, VERSION, valorAutorizado, unidadesAutorizadas,
                    conservarBeneficios, Optional.empty(), observacionesGlosa,
                    valorCargado, Optional.empty(), valorGlosado, Optional.empty(),
                    fechaInicio, Optional.empty(), Optional.empty(), Optional.empty(),
                    Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                    Optional.empty(), glosas, novedades, ModoRecalculo.EN_CASCADA);
        }
    }

    private static DetalleGlosa glosaActual(long id, String valor) {
        return new DetalleGlosa(id, null, new BigDecimal(valor), null, null, null, null, null);
    }

    @Nested
    @DisplayName("sinCambios")
    class SinCambios {

        @Test
        @DisplayName("una edición que no trae nada no tiene nada que guardar")
        void unaEdicionVaciaNoTieneNadaQueGuardar() {
            assertThat(vacia().construir().sinCambios()).isTrue();
        }

        @Test
        @DisplayName("cualquier campo presente ya es un cambio")
        void cualquierCampoPresenteYaEsUnCambio() {
            assertThat(vacia().observacionesGlosa("algo").construir().sinCambios()).isFalse();
            assertThat(vacia().fechaInicio(LocalDate.now()).construir().sinCambios()).isFalse();
            assertThat(vacia().conservarBeneficios(false).construir().sinCambios()).isFalse();
        }

        @Test
        @DisplayName("una glosa o una novedad también cuentan como cambio")
        void unaGlosaOUnaNovedadTambienCuentan() {
            assertThat(vacia().glosas(CambioGlosa.eliminar(1L)).construir().sinCambios())
                    .isFalse();
            assertThat(vacia().novedades(CambioNovedad.eliminar(1L)).construir().sinCambios())
                    .isFalse();
        }
    }

    @Nested
    @DisplayName("afectaCalculoFinanciero")
    class AfectaCalculoFinanciero {

        @Test
        @DisplayName("los importes y las unidades lo afectan")
        void losImportesYUnidadesLoAfectan() {
            assertThat(vacia().valorAutorizado("100").construir().afectaCalculoFinanciero())
                    .isTrue();
            assertThat(vacia().unidadesAutorizadas("2").construir().afectaCalculoFinanciero())
                    .isTrue();
            assertThat(vacia().valorCargado("100").construir().afectaCalculoFinanciero())
                    .isTrue();
            assertThat(vacia().valorGlosado("50").construir().afectaCalculoFinanciero())
                    .isTrue();
        }

        @Test
        @DisplayName("tocar las glosas lo afecta")
        void tocarLasGlosasLoAfecta() {
            assertThat(vacia().glosas(CambioGlosa.eliminar(1L)).construir()
                    .afectaCalculoFinanciero()).isTrue();
        }

        @Test
        @DisplayName("un cambio puramente descriptivo NO lo afecta")
        void unCambioDescriptivoNoLoAfecta() {
            assertThat(vacia().observacionesGlosa("texto").construir()
                    .afectaCalculoFinanciero()).isFalse();
            assertThat(vacia().novedades(CambioNovedad.agregar("332-1")).construir()
                    .afectaCalculoFinanciero()).isFalse();
        }
    }

    @Nested
    @DisplayName("valorGlosadoResultante")
    class ValorGlosadoResultante {

        @Test
        @DisplayName("suma lo que queda más lo que entra")
        void sumaLoQueQuedaMasLoQueEntra() {
            var actuales = List.of(glosaActual(1L, "100"), glosaActual(2L, "50"));
            var edicion = vacia()
                    .glosas(CambioGlosa.eliminar(1L),
                            CambioGlosa.agregar("208-1", null, null, new BigDecimal("30"), null))
                    .construir();

            // Queda la 2 (50) y entra una de 30.
            assertThat(edicion.valorGlosadoResultante(actuales))
                    .isEqualByComparingTo("80.00");
        }

        @Test
        @DisplayName("eliminarlas todas deja cero, no nulo")
        void eliminarlasTodasDejaCero() {
            var actuales = List.of(glosaActual(1L, "100"));
            var edicion = vacia().glosas(CambioGlosa.eliminar(1L)).construir();

            assertThat(edicion.valorGlosadoResultante(actuales)).isEqualByComparingTo("0.00");
        }

        @Test
        @DisplayName("sin glosas actuales, el total es lo que entra")
        void sinGlosasActualesElTotalEsLoQueEntra() {
            var edicion = vacia()
                    .glosas(CambioGlosa.agregar("208-1", null, null, new BigDecimal("1500"), null))
                    .construir();

            assertThat(edicion.valorGlosadoResultante(List.of()))
                    .isEqualByComparingTo("1500.00");
        }

        @Test
        @DisplayName("una glosa actual con valor nulo se ignora en la suma")
        void unaGlosaActualConValorNuloSeIgnora() {
            var actuales = List.of(new DetalleGlosa(1L, null, null, null, null, null, null, null),
                                   glosaActual(2L, "40"));

            assertThat(vacia().construir().valorGlosadoResultante(actuales))
                    .isEqualByComparingTo("40.00");
        }

        @Test
        @DisplayName("el resultado viene con dos decimales, que es la escala del importe")
        void elResultadoVieneConDosDecimales() {
            var actuales = List.of(glosaActual(1L, "33.333"));

            assertThat(vacia().construir().valorGlosadoResultante(actuales).scale())
                    .isEqualTo(2);
        }
    }

    @Nested
    @DisplayName("bajasInexistentes")
    class BajasInexistentes {

        @Test
        @DisplayName("lista las glosas que se quieren borrar y ya no están")
        void listaLasQueYaNoEstan() {
            var actuales = List.of(glosaActual(1L, "100"));
            var edicion = vacia()
                    .glosas(CambioGlosa.eliminar(1L), CambioGlosa.eliminar(99L))
                    .construir();

            assertThat(edicion.bajasInexistentes(actuales)).containsExactly(99L);
        }

        @Test
        @DisplayName("si todas existen, no hay ninguna inexistente")
        void siTodasExistenNoHayNinguna() {
            var actuales = List.of(glosaActual(1L, "100"));

            assertThat(vacia().glosas(CambioGlosa.eliminar(1L)).construir()
                    .bajasInexistentes(actuales)).isEmpty();
        }

        @Test
        @DisplayName("las altas no cuentan: no tienen identificador que comprobar")
        void lasAltasNoCuentan() {
            var edicion = vacia()
                    .glosas(CambioGlosa.agregar("208-1", null, null, BigDecimal.TEN, null))
                    .construir();

            assertThat(edicion.bajasInexistentes(List.of())).isEmpty();
        }
    }

    @Test
    @DisplayName("conValorGlosado deja el total y conserva todo lo demás")
    void conValorGlosadoDejaElTotalYConservaLoDemas() {
        var original = vacia().observacionesGlosa("texto")
                .glosas(CambioGlosa.eliminar(1L)).construir();

        var conTotal = original.conValorGlosado(new BigDecimal("80.00"));

        assertThat(conTotal.valorGlosado()).contains(new BigDecimal("80.00"));
        assertThat(conTotal.observacionesGlosa()).contains("texto");
        assertThat(conTotal.glosas()).isEqualTo(original.glosas());
        assertThat(conTotal.referencia()).isEqualTo(REFERENCIA);
        assertThat(conTotal.modoRecalculo()).isEqualTo(ModoRecalculo.EN_CASCADA);
    }

    @Test
    @DisplayName("las listas nulas se normalizan a vacías")
    void lasListasNulasSeNormalizan() {
        var edicion = new EdicionLinea(REFERENCIA, VERSION,
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), null, null, ModoRecalculo.AISLADO);

        assertThat(edicion.glosas()).isEmpty();
        assertThat(edicion.novedades()).isEmpty();
        assertThat(edicion.tocaGlosas()).isFalse();
        assertThat(edicion.tocaNovedades()).isFalse();
    }
}
