package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("CodigoCuenta")
class CodigoCuentaTest {

    @Test
    @DisplayName("conserva el valor que recibe")
    void conservaElValorQueRecibe() {
        assertThat(new CodigoCuenta("GT-106586883036").valor()).isEqualTo("GT-106586883036");
    }

    @Test
    @DisplayName("su representación en texto es el propio código, para que los logs sean legibles")
    void suRepresentacionEnTextoEsElPropioCodigo() {
        assertThat(new CodigoCuenta("CM-108800618430")).hasToString("CM-108800618430");
    }

    @ParameterizedTest(name = "rechaza [{0}]")
    @NullAndEmptySource
    @ValueSource(strings = {" ", "   ", "\t", "\n"})
    @DisplayName("rechaza nulo, vacío y solo espacios")
    void rechazaNuloVacioYSoloEspacios(String invalido) {
        assertThatThrownBy(() -> new CodigoCuenta(invalido))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("obligatorio");
    }

    @Test
    @DisplayName("dos códigos con el mismo valor son iguales")
    void dosCodigosConElMismoValorSonIguales() {
        assertThat(new CodigoCuenta("CM-1")).isEqualTo(new CodigoCuenta("CM-1"))
                .hasSameHashCodeAs(new CodigoCuenta("CM-1"));
    }
}
