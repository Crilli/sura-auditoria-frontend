package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("CambioNovedad")
class CambioNovedadTest {

    @Nested
    @DisplayName("alta")
    class Alta {

        @Test
        @DisplayName("basta el código del catálogo; sin valores queda con el mapa vacío")
        void bastaElCodigoDelCatalogo() {
            var alta = CambioNovedad.agregar("332-1");

            assertThat(alta.esAlta()).isTrue();
            assertThat(alta.codigoMensaje()).isEqualTo("332-1");
            assertThat(alta.valores()).isEmpty();
            assertThat(alta.identificador()).isNull();
        }

        @Test
        @DisplayName("acepta los valores que completan la plantilla")
        void aceptaLosValoresQueCompletanLaPlantilla() {
            var alta = CambioNovedad.agregar("SURA-AUT-002", Map.of(1, "99073568971", 2, "0"));

            assertThat(alta.valores()).containsOnlyKeys(1, 2);
        }

        @ParameterizedTest(name = "rechaza código [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        @DisplayName("sin código de mensaje no hay novedad")
        void sinCodigoDeMensajeNoHayNovedad(String codigo) {
            assertThatThrownBy(() -> CambioNovedad.agregar(codigo))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("código del mensaje");
        }

        @Test
        @DisplayName("un alta con identificador se rechaza: lo asigna el sistema de registro")
        void unAltaConIdentificadorSeRechaza() {
            assertThatThrownBy(() -> new CambioNovedad(CambioNovedad.Operacion.AGREGAR, 7L,
                    "332-1", Map.of()))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("identificador");
        }
    }

    @Nested
    @DisplayName("índices de los valores")
    class IndicesDeLosValores {

        @ParameterizedTest(name = "acepta el índice {0}")
        @ValueSource(ints = {0, 5, 9})
        @DisplayName("van del 0 al 9, que son los diez valores del sistema de registro")
        void vanDelCeroAlNueve(int indice) {
            assertThat(CambioNovedad.agregar("332-1", Map.of(indice, "dato")).valores())
                    .containsKey(indice);
        }

        @ParameterizedTest(name = "rechaza el índice {0}")
        @ValueSource(ints = {-1, 10, 42})
        @DisplayName("fuera del rango 0..9 se rechaza")
        void fueraDeRangoSeRechaza(int indice) {
            assertThatThrownBy(() -> CambioNovedad.agregar("332-1", Map.of(indice, "dato")))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("del 0 al 9");
        }
    }

    @Nested
    @DisplayName("largo de los valores")
    class LargoDeLosValores {

        @Test
        @DisplayName("admite justo el máximo de 300 caracteres")
        void admiteJustoElMaximo() {
            var enElLimite = "x".repeat(TextoDeNovedad.LARGO_MAXIMO_VALOR);

            assertThat(CambioNovedad.agregar("332-1", Map.of(0, enElLimite)).valores())
                    .containsEntry(0, enElLimite);
        }

        @Test
        @DisplayName("pasarse de 300 se rechaza aquí, porque el sistema daría 422 GEN-ORA-12899")
        void pasarseDelMaximoSeRechaza() {
            var pasado = "x".repeat(TextoDeNovedad.LARGO_MAXIMO_VALOR + 1);

            assertThatThrownBy(() -> CambioNovedad.agregar("332-1", Map.of(0, pasado)))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("300 caracteres");
        }
    }

    @Nested
    @DisplayName("valores nulos")
    class ValoresNulos {

        @Test
        @DisplayName("una clave nula da 400 descriptivo, no el 500 de Map.copyOf")
        void unaClaveNulaDaErrorDescriptivo() {
            var conClaveNula = new HashMap<Integer, String>();
            conClaveNula.put(null, "dato");

            assertThatThrownBy(() -> CambioNovedad.agregar("332-1", conClaveNula))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("a qué hueco va");
        }

        @Test
        @DisplayName("un valor nulo da 400 descriptivo, no el 500 de Map.copyOf")
        void unValorNuloDaErrorDescriptivo() {
            var conValorNulo = new HashMap<Integer, String>();
            conValorNulo.put(3, null);

            assertThatThrownBy(() -> CambioNovedad.agregar("332-1", conValorNulo))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("llegó vacío");
        }
    }

    @Nested
    @DisplayName("baja")
    class Baja {

        @Test
        @DisplayName("solo lleva el identificador")
        void soloLlevaElIdentificador() {
            var baja = CambioNovedad.eliminar(8080L);

            assertThat(baja.esBaja()).isTrue();
            assertThat(baja.esAlta()).isFalse();
            assertThat(baja.identificador()).isEqualTo(8080L);
            assertThat(baja.codigoMensaje()).isNull();
            assertThat(baja.valores()).isEmpty();
        }

        @Test
        @DisplayName("sin identificador no se puede eliminar")
        void sinIdentificadorNoSePuedeEliminar() {
            assertThatThrownBy(() -> new CambioNovedad(CambioNovedad.Operacion.ELIMINAR, null,
                    null, Map.of()))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("identificador");
        }

        @Test
        @DisplayName("una baja con código se rechaza")
        void unaBajaConCodigoSeRechaza() {
            assertThatThrownBy(() -> new CambioNovedad(CambioNovedad.Operacion.ELIMINAR, 1L,
                    "332-1", Map.of()))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("solo admite su identificador");
        }

        @Test
        @DisplayName("una baja con valores se rechaza")
        void unaBajaConValoresSeRechaza() {
            assertThatThrownBy(() -> new CambioNovedad(CambioNovedad.Operacion.ELIMINAR, 1L,
                    null, Map.of(0, "dato")))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("solo admite su identificador");
        }
    }

    @Test
    @DisplayName("sin operación no se sabe qué hacer")
    void sinOperacionNoSeSabeQueHacer() {
        assertThatThrownBy(() -> new CambioNovedad(null, null, "332-1", Map.of()))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("agrega o se elimina");
    }

    @Test
    @DisplayName("los valores quedan inmutables: modificar el mapa original no la afecta")
    void losValoresQuedanInmutables() {
        var original = new HashMap<Integer, String>();
        original.put(0, "uno");
        var novedad = CambioNovedad.agregar("332-1", original);

        original.put(1, "dos");

        assertThat(novedad.valores()).containsOnlyKeys(0);
        assertThatThrownBy(() -> novedad.valores().put(2, "tres"))
                .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    @DisplayName("el origen no es un campo del comando: no se puede fingir una novedad del motor")
    void elOrigenNoEsUnCampoDelComando() {
        // Si el cliente pudiera elegir el origen, podría fabricar una novedad que
        // aparenta venir del motor de beneficios. La capa de integración impone MANUAL.
        assertThat(CambioNovedad.class.getRecordComponents())
                .extracting(java.lang.reflect.RecordComponent::getName)
                .containsExactly("operacion", "identificador", "codigoMensaje", "valores");
    }
}
