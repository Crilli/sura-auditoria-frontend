package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("FiltroLineas")
class FiltroLineasTest {

    private static FiltroLineas conCatalogo(CatalogoPrestacion catalogo) {
        return new FiltroLineas(null, null, null, null, null, null, catalogo, null, null, false, null, FiltroBloqueo.TODOS, null);
    }

    private static FiltroLineas conGlosa(BigDecimal desde, BigDecimal hasta) {
        return new FiltroLineas(null, null, null, null, null, null, null, desde, hasta, false, null, FiltroBloqueo.TODOS, null);
    }

    private static ResumenLinea linea(String catalogo, BigDecimal glosa) {
        return new ResumenLinea(new ReferenciaLinea(1L), 1, LocalDate.now(), LocalDate.now(),
                "CC1", "Afiliado", "873206", "Radiografía", catalogo, "AUT1",
                BigDecimal.TEN, BigDecimal.TEN, glosa,
                false, false, false, false, 0, List.of(), false, List.of(), new Version(1L), null, null, null, null, null);
    }

    @Nested
    @DisplayName("normalización")
    class Normalizacion {

        @ParameterizedTest(name = "[{0}] se normaliza a nulo")
        @NullAndEmptySource
        @ValueSource(strings = {"   ", "\t"})
        @DisplayName("un texto en blanco es como no filtrar")
        void unTextoEnBlancoEsComoNoFiltrar(String enBlanco) {
            var filtro = new FiltroLineas(null, enBlanco, null, null, enBlanco, enBlanco,
                    null, null, null, false, null, FiltroBloqueo.TODOS, null);

            assertThat(filtro.cedulaAfiliado()).isNull();
            assertThat(filtro.codigoAutorizacion()).isNull();
            assertThat(filtro.codigoPrestacion()).isNull();
            assertThat(filtro.vacio()).isTrue();
        }

        @Test
        @DisplayName("los espacios de alrededor se recortan")
        void losEspaciosSeRecortan() {
            var filtro = new FiltroLineas(null, "  CC1033766347  ", null, null, null, null,
                    null, null, null, false, null, FiltroBloqueo.TODOS, null);

            assertThat(filtro.cedulaAfiliado()).isEqualTo("CC1033766347");
        }

        @Test
        @DisplayName("NINGUNO está vacío")
        void ningunoEstaVacio() {
            assertThat(FiltroLineas.NINGUNO.vacio()).isTrue();
        }
    }

    @Nested
    @DisplayName("reparto entre OHI y filtrado local")
    class RepartoEntreOhiYLocal {

        @Test
        @DisplayName("cédula, fechas, autorización y prestación se empujan enteros a OHI")
        void loQueSeEmpujaEntero() {
            var filtro = new FiltroLineas(7, "CC1", LocalDate.of(2026, 1, 1),
                    LocalDate.of(2026, 2, 1), "AUT1", "873206", null, null, null, false, null, FiltroBloqueo.TODOS, null);

            assertThat(filtro.seEmpujaEntero()).isTrue();
            assertThat(filtro.exigeFiltradoLocal()).isFalse();
        }

        @Test
        @DisplayName("el catálogo NO se puede empujar: exige filtrado local")
        void elCatalogoExigeFiltradoLocal() {
            assertThat(conCatalogo(CatalogoPrestacion.CUPS).exigeFiltradoLocal()).isTrue();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("la cota INFERIOR de glosa sí se empuja, pese a lo que diga su metadato")
        void laCotaInferiorDeGlosaSeEmpuja() {
            // OHI publica valorGlosado como no filtrable y durante un tiempo se le creyó: el
            // filtro se resolvía recorriendo la cuenta y esas páginas llegaban sin total.
            // Medido el 2026-10-16: gte(0)→212, gte(100000)→50, gte(571294)→20,
            // gte(999999999)→204. Discrimina sin un fallo.
            assertThat(conGlosa(BigDecimal.ONE, null).exigeFiltradoLocal()).isFalse();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("la cota SUPERIOR no: una de cada tres líneas no trae el campo y se perderían")
        void laCotaSuperiorNoSeEmpuja() {
            // Medido el 2026-10-17 sobre 200 líneas de UAT: 63 no traen valorGlosado. Una
            // comparación en OHI no las devuelve, y una línea sin glosa SÍ está por debajo
            // de cualquier techo. Empujar el «hasta» cambiaría el resultado a peor.
            assertThat(conGlosa(null, BigDecimal.TEN).exigeFiltradoLocal()).isTrue();
            assertThat(conGlosa(BigDecimal.ONE, BigDecimal.TEN).exigeFiltradoLocal()).isTrue();
        }

        @Test
        @Tag("F3-FIL-01")
        @DisplayName("el número de línea se empuja: es el filtro más barato de todos")
        void elNumeroDeLineaSeEmpuja() {
            var filtro = new FiltroLineas(101, null, null, null, null, null, null, null, null, false, null, FiltroBloqueo.TODOS, null);

            assertThat(filtro.vacio()).isFalse();
            assertThat(filtro.seEmpujaEntero()).isTrue();
            assertThat(filtro.numeroLinea()).isEqualTo(101);
        }

        @Test
        @DisplayName("soloLoQueSeEmpuja conserva lo empujable y descarta lo local")
        void soloLoQueSeEmpujaConservaLoEmpujable() {
            var completo = new FiltroLineas(7, "CC1", LocalDate.of(2026, 1, 1), null, "AUT1",
                    "873206", CatalogoPrestacion.CUM, BigDecimal.ONE, BigDecimal.TEN, false, null, FiltroBloqueo.TODOS, null);

            var empujable = completo.soloLoQueSeEmpuja();

            assertThat(empujable.cedulaAfiliado()).isEqualTo("CC1");
            assertThat(empujable.desde()).isEqualTo(LocalDate.of(2026, 1, 1));
            assertThat(empujable.codigoAutorizacion()).isEqualTo("AUT1");
            assertThat(empujable.codigoPrestacion()).isEqualTo("873206");
            assertThat(empujable.catalogo())
                    .as("el catálogo es lo único que no se puede empujar")
                    .isNull();
            assertThat(empujable.glosaDesde())
                    .as("la cota inferior de glosa se empuja: se conserva")
                    .isEqualTo(BigDecimal.ONE);
            assertThat(empujable.glosaHasta())
                    .as("la superior no se empuja: se resuelve aquí")
                    .isNull();
            assertThat(empujable.numeroLinea()).isEqualTo(7);
            assertThat(empujable.seEmpujaEntero()).isTrue();
        }
    }

    @Nested
    @DisplayName("cumpleLoQueNoSeEmpuja")
    class CumpleLoQueNoSeEmpuja {

        @Test
        @DisplayName("sin criterios locales, cualquier línea pasa")
        void sinCriteriosLocalesTodoPasa() {
            assertThat(FiltroLineas.NINGUNO.cumpleLoQueNoSeEmpuja(linea("CUPS", BigDecimal.TEN)))
                    .isTrue();
        }

        @Test
        @DisplayName("el catálogo se compara ya normalizado")
        void elCatalogoSeComparaNormalizado() {
            var filtro = conCatalogo(CatalogoPrestacion.CUPS);

            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("cups", BigDecimal.ZERO))).isTrue();
            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("CUM", BigDecimal.ZERO))).isFalse();
        }

        @Test
        @DisplayName("una línea sin catálogo cuenta como OTRO")
        void unaLineaSinCatalogoCuentaComoOtro() {
            assertThat(conCatalogo(CatalogoPrestacion.OTRO)
                    .cumpleLoQueNoSeEmpuja(linea(null, BigDecimal.ZERO))).isTrue();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("el techo de glosa incluye su extremo")
        void elTechoDeGlosaIncluyeSuExtremo() {
            var filtro = conGlosa(null, new BigDecimal("200"));

            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("200")))).isTrue();
            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("150")))).isTrue();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("por encima del techo, la línea no pasa")
        void porEncimaDelTechoNoPasa() {
            assertThat(conGlosa(null, new BigDecimal("200"))
                    .cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("201")))).isFalse();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("el suelo ya no se comprueba aquí: lo resuelve el sistema de registro")
        void elSueloNoSeCompruebaAqui() {
            // Desde el 2026-10-17 la cota inferior viaja como valorGlosado.gte. Este método
            // solo mira lo que NO se empujó; comprobar el suelo otra vez daría a entender
            // que el filtro cuesta un recorrido, y ya no lo cuesta.
            assertThat(conGlosa(new BigDecimal("100"), null)
                    .cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("99")))).isTrue();
        }

        @Test
        @Tag("F3-CNT-01")
        @DisplayName("una glosa nula está por debajo de cualquier techo, y por eso el techo no se empuja")
        void unaGlosaNulaEstaPorDebajoDeCualquierTecho() {
            // Es la razón medida de todo el reparto: 63 de 200 líneas de UAT no traen el
            // campo. Si el techo viajara a OHI, esas 63 desaparecerían del resultado.
            assertThat(conGlosa(null, BigDecimal.TEN)
                    .cumpleLoQueNoSeEmpuja(linea("CUPS", null))).isTrue();
        }

        @Test
        @DisplayName("la comparación de importes es por valor, no por escala: 100 == 100.00")
        void laComparacionDeImportesEsPorValor() {
            var filtro = conGlosa(new BigDecimal("100.00"), new BigDecimal("100.00"));

            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("100"))))
                    .isTrue();
        }

        @Test
        @DisplayName("sin techo, nada se descarta por importe")
        void sinTechoNadaSeDescartaPorImporte() {
            var filtro = conGlosa(new BigDecimal("100"), null);

            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("1000000"))))
                    .isTrue();
            assertThat(filtro.cumpleLoQueNoSeEmpuja(linea("CUPS", new BigDecimal("99"))))
                    .as("el suelo lo aplica el sistema de registro, no este método")
                    .isTrue();
        }
    }
    @Nested
    @DisplayName("los criterios que viven en una colección hija")
    class ColeccionesHijas {

        @Test
        @Tag("F3-NOV-01")
        @DisplayName("«con novedad» se empuja: la página conserva su total")
        void conNovedadSeEmpuja() {
            // Medido el 17-oct-2026 contra el entorno de pruebas: el filtro por la colección
            // hija es exacto y el total del servidor también. La nota anterior del proyecto
            // decía lo contrario por un error de medición (tope de 200 en la verdad de
            // referencia); ver el javadoc de FiltroLineas.
            var filtro = new FiltroLineas(null, null, null, null, null, null, null, null, null,
                                          true, null, FiltroBloqueo.TODOS, null);

            assertThat(filtro.vacio()).isFalse();
            assertThat(filtro.seEmpujaEntero()).isTrue();
            assertThat(filtro.exigeFiltradoLocal()).isFalse();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("el motivo de pendiente también se empuja")
        void elMotivoSeEmpuja() {
            var filtro = conMotivo("MP_EVALUAR_UEN");

            assertThat(filtro.vacio()).isFalse();
            assertThat(filtro.seEmpujaEntero()).isTrue();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("un motivo en blanco es no haber filtrado")
        void unMotivoEnBlancoEsNoFiltrar() {
            assertThat(conMotivo("   ").motivoPendiente()).isNull();
            assertThat(conMotivo("   ").vacio()).isTrue();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("sin pedir bloqueo no hace falta el estado de la cuenta")
        void sinBloqueoNoHaceFaltaElEstado() {
            // Importa porque el estado cuesta una consulta: no se paga si nadie lo pidió.
            assertThat(conMotivo("MP_EVALUAR_UEN").exigeEstadoDeLaCuenta()).isFalse();
            assertThat(FiltroLineas.NINGUNO.exigeEstadoDeLaCuenta()).isFalse();
        }
    }

    @Nested
    @DisplayName("el filtro de bloqueo, que no se puede escribir sin el estado")
    class Bloqueo {

        private static FiltroLineas conBloqueo(FiltroBloqueo bloqueo) {
            return new FiltroLineas(null, null, null, null, null, null, null, null, null,
                                    false, null, bloqueo, null);
        }

        @Test
        @Tag("F2-06")
        @DisplayName("pedir bloqueo exige el estado, y resolverlo lo satisface")
        void pedirBloqueoExigeElEstado() {
            var pedido = conBloqueo(FiltroBloqueo.BLOQUEANTES);

            assertThat(pedido.exigeEstadoDeLaCuenta()).isTrue();
            assertThat(pedido.resueltoEn(EstadoCuenta.MODIFICACION).exigeEstadoDeLaCuenta())
                    .isFalse();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("preguntar por el indicador sin resolver el estado revienta aquí, no allí")
        void preguntarSinResolverRevienta() {
            // Dejarlo pasar devolvería la página sin ese criterio: más líneas de las pedidas,
            // y nadie se enteraría. Es el fallo silencioso que este proyecto persigue.
            assertThatThrownBy(() -> conBloqueo(FiltroBloqueo.BLOQUEANTES).soloAdjudicacionExigida())
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("resueltoEn");
        }

        @Test
        @Tag("F2-06")
        @DisplayName("fuera de adjudicación manual, «bloqueantes» son los que no son de sola adjudicación")
        void fueraDeAdjudicacionManual() {
            var resuelto = conBloqueo(FiltroBloqueo.BLOQUEANTES)
                    .resueltoEn(EstadoCuenta.MODIFICACION);

            assertThat(resuelto.soloAdjudicacionExigida()).contains(false);
            assertThat(resuelto.vacioPorDefinicion()).isFalse();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("en adjudicación manual «bloqueantes» no acota: allí bloquea todo")
        void enAdjudicacionManualBloqueantesNoAcota() {
            var resuelto = conBloqueo(FiltroBloqueo.BLOQUEANTES)
                    .resueltoEn(EstadoCuenta.ADJUDICACION_MANUAL);

            assertThat(resuelto.soloAdjudicacionExigida()).isEmpty();
            assertThat(resuelto.vacioPorDefinicion()).isFalse();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("en adjudicación manual «no bloqueantes» es el conjunto vacío, y se dice")
        void enAdjudicacionManualNoBloqueantesEsVacio() {
            var resuelto = conBloqueo(FiltroBloqueo.NO_BLOQUEANTES)
                    .resueltoEn(EstadoCuenta.ADJUDICACION_MANUAL);

            assertThat(resuelto.vacioPorDefinicion()).isTrue();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("sin resolver, nadie puede afirmar que el filtro es vacío")
        void sinResolverNadiePuedeAfirmarQueEsVacio() {
            assertThat(conBloqueo(FiltroBloqueo.NO_BLOQUEANTES).vacioPorDefinicion()).isFalse();
        }

        @Test
        @Tag("F2-06")
        @DisplayName("soloLoQueSeEmpuja conserva el estado ya resuelto")
        void soloLoQueSeEmpujaConservaElEstado() {
            // Si lo perdiera, el camino de filtrado local reventaría al preguntar el indicador.
            var resuelto = conBloqueo(FiltroBloqueo.BLOQUEANTES)
                    .resueltoEn(EstadoCuenta.MODIFICACION);

            assertThat(resuelto.soloLoQueSeEmpuja().soloAdjudicacionExigida()).contains(false);
        }
    }

    private static FiltroLineas conMotivo(String motivo) {
        return new FiltroLineas(null, null, null, null, null, null, null, null, null,
                                false, motivo, FiltroBloqueo.TODOS, null);
    }
}
