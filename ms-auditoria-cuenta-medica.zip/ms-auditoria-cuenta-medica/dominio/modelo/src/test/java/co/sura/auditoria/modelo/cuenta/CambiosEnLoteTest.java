package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("CambiosEnLote")
class CambiosEnLoteTest {

    private static final SeleccionLineas DOS = SeleccionLineas.de(List.of(
            new ReferenciaLinea(10L), new ReferenciaLinea(20L)));

    private static List<CambioGlosa> unaGlosa() {
        return List.of(CambioGlosa.agregar("TAR01", "G", "E", new BigDecimal("1500"), "texto"));
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("un lote con glosas es válido y las conserva para todas las líneas")
    void unLoteConGlosasEsValido() {
        var lote = new CambiosEnLote(DOS, unaGlosa(), List.of(), ModoRecalculo.EN_CASCADA);

        assertThat(lote.tocaGlosas()).isTrue();
        assertThat(lote.tocaNovedades()).isFalse();
        assertThat(lote.seleccion().cuantas()).isEqualTo(2);
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("«todas las de la cuenta» no es un alcance válido para un lote")
    void todasNoEsAlcanceValido() {
        // Habría que enumerarlas, y el tope existe por algo. Además es justo el valor que el
        // sistema de registro entiende como «sin acotar», así que dejarlo pasar sería escribir
        // sobre toda la cuenta creyendo que se escribe sobre una selección.
        assertThatThrownBy(() -> new CambiosEnLote(
                SeleccionLineas.TODAS, unaGlosa(), List.of(), ModoRecalculo.EN_CASCADA))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("una a una");
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("un lote que no cambia nada se rechaza")
    void unLoteQueNoCambiaNadaSeRechaza() {
        assertThatThrownBy(() -> new CambiosEnLote(DOS, List.of(), List.of(),
                                                   ModoRecalculo.EN_CASCADA))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("no cambia nada");
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("el modo de recálculo es obligatorio: en un lote la decisión se multiplica")
    void elModoDeRecalculoEsObligatorio() {
        assertThatThrownBy(() -> new CambiosEnLote(DOS, unaGlosa(), List.of(), null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("recalcula");
    }

    @Test
    @Tag("DBG-02")
    @DisplayName("por encima del tope se rechaza antes de tocar nada")
    void porEncimaDelTopeSeRechaza() {
        var muchas = SeleccionLineas.de(
                java.util.stream.LongStream.rangeClosed(1, CambiosEnLote.MAXIMO_LINEAS + 1)
                        .mapToObj(ReferenciaLinea::new).toList());

        assertThatThrownBy(() -> new CambiosEnLote(muchas, unaGlosa(), List.of(),
                                                   ModoRecalculo.EN_CASCADA))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining(String.valueOf(CambiosEnLote.MAXIMO_LINEAS));
    }

    @Test
    @Tag("DBG-06")
    @DisplayName("la edición por línea lleva la versión de esa línea y ningún importe suyo")
    void laEdicionPorLineaNoLlevaImportes() {
        // Es la razón de que el lote no sea una EdicionLinea con referencias pegadas: repetir
        // el mismo importe en veinte líneas distintas no es una operación masiva.
        var lote = new CambiosEnLote(DOS, unaGlosa(), List.of(), ModoRecalculo.AISLADO);
        var linea = lineaConVersion(10L, 7L);

        var edicion = lote.paraLinea(linea);

        assertThat(edicion.referencia()).isEqualTo(linea.referencia());
        assertThat(edicion.versionEsperada()).isEqualTo(linea.version());
        assertThat(edicion.glosas()).hasSize(1);
        assertThat(edicion.valorConvenido()).isEmpty();
        assertThat(edicion.valorCargado()).isEmpty();
        assertThat(edicion.valorGlosado()).isEmpty();
        assertThat(edicion.unidadesConvenidas()).isEmpty();
        assertThat(edicion.modoRecalculo()).isEqualTo(ModoRecalculo.AISLADO);
    }

    /** Una línea con lo justo: aquí solo importan su referencia y su versión. */
    private static LineaCuenta lineaConVersion(long referencia, long version) {
        return new LineaCuenta(
                new ReferenciaLinea(referencia), new CodigoCuenta("CM-1"), 3,
                null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null,
                false, false, false, false, false, false,
                null, null, null,
                List.of(), List.of(), List.of(), List.of(), null, new Version(version));
    }

    // ── Lo que de verdad falta en cada línea (OPE-12) ──────────────────────────────────

    private static LineaCuenta lineaCon(List<DetalleGlosa> glosas, List<Novedad> novedades) {
        return new LineaCuenta(
                new ReferenciaLinea(10L), new CodigoCuenta("CM-1"), 3,
                null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null,
                false, false, false, false, false, false,
                null, null, null,
                List.of(), glosas, novedades, List.of(), null, new Version(7L));
    }

    private static DetalleGlosa glosa(long id, String codigo, String valor) {
        return new DetalleGlosa(id, codigo, valor == null ? null : new BigDecimal(valor),
                                null, null, "G", "E", "texto");
    }

    private static Novedad novedad(long id, String codigo) {
        return new Novedad(id, codigo, "desc", Severidad.INFORMATIVA, "MANUAL", null, null,
                           "auditor", null, false, java.util.Map.of());
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("una línea sin la glosa la recibe; con la misma glosa ya puesta, no le queda nada")
    void altaDeGlosaIdempotente() {
        var lote = new CambiosEnLote(DOS, unaGlosa(), List.of(), ModoRecalculo.AISLADO);

        assertThat(lote.pendienteParaLinea(lineaCon(List.of(), List.of())))
                .hasValueSatisfying(e -> assertThat(e.glosas()).hasSize(1));
        assertThat(lote.pendienteParaLinea(lineaCon(List.of(glosa(1, "TAR01", "1500.00")), List.of())))
                .as("mismo código y mismo valor, aunque con otra escala").isEmpty();
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("una glosa del mismo código pero otro valor no cuenta como «ya está»")
    void otroValorSiSeAplica() {
        var lote = new CambiosEnLote(DOS, unaGlosa(), List.of(), ModoRecalculo.AISLADO);

        assertThat(lote.pendienteParaLinea(lineaCon(List.of(glosa(1, "TAR01", "900")), List.of()))).isPresent();
        assertThat(lote.pendienteParaLinea(lineaCon(List.of(glosa(1, "TAR01", null)), List.of()))).isPresent();
        assertThat(lote.pendienteParaLinea(lineaCon(List.of(glosa(1, "OTRA", "1500")), List.of()))).isPresent();
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("la baja de una glosa que ya no está no se manda; la de una que está, sí")
    void bajaDeGlosa() {
        var lote = new CambiosEnLote(DOS, List.of(CambioGlosa.eliminar(5L)), List.of(), ModoRecalculo.AISLADO);

        assertThat(lote.pendienteParaLinea(lineaCon(List.of(glosa(5, "TAR01", "1")), List.of()))).isPresent();
        assertThat(lote.pendienteParaLinea(lineaCon(List.of(glosa(6, "TAR01", "1")), List.of()))).isEmpty();
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("con las novedades pasa lo mismo: alta de una que ya está o baja de una que ya no, nada")
    void novedadesIdempotentes() {
        var alta = new CambiosEnLote(DOS, List.of(), List.of(CambioNovedad.agregar("332-1")), ModoRecalculo.AISLADO);
        var baja = new CambiosEnLote(DOS, List.of(), List.of(CambioNovedad.eliminar(9L)), ModoRecalculo.AISLADO);

        assertThat(alta.pendienteParaLinea(lineaCon(List.of(), List.of()))).isPresent();
        assertThat(alta.pendienteParaLinea(lineaCon(List.of(), List.of(novedad(1, "332-1"))))).isEmpty();
        assertThat(baja.pendienteParaLinea(lineaCon(List.of(), List.of(novedad(9, "332-1"))))).isPresent();
        assertThat(baja.pendienteParaLinea(lineaCon(List.of(), List.of(novedad(8, "332-1"))))).isEmpty();
    }

    @Test
    @Tag("OPE-12")
    @DisplayName("si solo falta una parte, se manda solo esa parte, con la versión de la línea")
    void soloLoQueFalta() {
        var lote = new CambiosEnLote(DOS, unaGlosa(), List.of(CambioNovedad.agregar("332-1")),
                                     ModoRecalculo.EN_CASCADA);

        var pendiente = lote.pendienteParaLinea(lineaCon(List.of(glosa(1, "TAR01", "1500")), List.of()));

        assertThat(pendiente).hasValueSatisfying(e -> {
            assertThat(e.glosas()).isEmpty();
            assertThat(e.novedades()).extracting(CambioNovedad::codigoMensaje).containsExactly("332-1");
            assertThat(e.versionEsperada()).isEqualTo(new Version(7L));
            assertThat(e.modoRecalculo()).isEqualTo(ModoRecalculo.EN_CASCADA);
        });
    }
}
