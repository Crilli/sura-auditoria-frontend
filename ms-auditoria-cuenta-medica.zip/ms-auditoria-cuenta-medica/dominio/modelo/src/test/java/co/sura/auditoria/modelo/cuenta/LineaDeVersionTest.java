package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * El modelo de las líneas de una versión (BUS-21): la fila de la foto y su detalle.
 *
 * <p>Los documentos y apellidos son inventados; ningún dato identifica a una persona.
 */
@DisplayName("Modelo de las líneas de una versión")
class LineaDeVersionTest {

    private static LineaDeVersion.GlosaDeVersion glosa(Integer secuencia, String codigo) {
        return new LineaDeVersion.GlosaDeVersion(secuencia, codigo, new BigDecimal("1000"), null,
                                                 null, "Tarifas", null, null, "Manual");
    }

    private static LineaDeVersion linea(List<LineaDeVersion.GlosaDeVersion> glosas) {
        return new LineaDeVersion(1, EstadoLinea.NEGADA.name(), null, null, "890701", null, "CUPS",
                                  "CC0000000001", "Apellido", null, null, null,
                                  new BigDecimal("64400"), BigDecimal.ONE, null, null,
                                  BigDecimal.ZERO, null, new BigDecimal("64400"), null, null,
                                  glosas);
    }

    @Nested
    @DisplayName("LineaDeVersion")
    class Fila {

        @Test
        @Tag("BUS-21")
        @DisplayName("el desglose de glosa queda en el orden de su secuencia, las sin secuencia al final")
        void glosasOrdenadas() {
            var l = linea(List.of(glosa(null, "C"), glosa(1, "B"), glosa(0, "A")));

            assertThat(l.glosas()).extracting(LineaDeVersion.GlosaDeVersion::codigo)
                    .containsExactly("A", "B", "C");
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("sin desglose, lista vacía; y cambiar la lista de origen no altera la foto")
        void sinDesgloseEInmutable() {
            assertThat(linea(null).glosas()).isEmpty();

            var origen = new ArrayList<LineaDeVersion.GlosaDeVersion>();
            origen.add(glosa(0, "A"));
            var l = linea(origen);
            origen.clear();

            assertThat(l.glosas()).hasSize(1);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("un importe que no llegó es nulo, no cero")
        void importeAusente() {
            var l = linea(List.of());

            assertThat(l.valorConvenido()).isNull();
            assertThat(l.valorAutorizado()).isEqualByComparingTo("0");
        }
    }

    @Nested
    @DisplayName("DetalleLineaDeVersion")
    class Detalle {

        @Test
        @Tag("BUS-21")
        @DisplayName("sin novedades, diagnósticos, convenio ni atención: vacíos, nunca nulos")
        void vaciosNuncaNulos() {
            var d = new DetalleLineaDeVersion(linea(null), null, null, null, null);

            assertThat(d.novedades()).isEmpty();
            assertThat(d.diagnosticos()).isEmpty();
            assertThat(d.convenio().clausulas()).isEmpty();
            assertThat(d.convenio().tarifaIss2000()).isNull();
            assertThat(d.atencion().uen()).isNull();
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("conserva lo que trae, con las repeticiones de cada novedad")
        void conservaLoQueTrae() {
            var novedad = new DetalleLineaDeVersion.NovedadDeVersion(
                    "223-1A", Severidad.INFORMATIVA, "Texto de la novedad", "MANUAL", false, 12);
            var diagnostico = new DetalleLineaDeVersion.DiagnosticoDeVersion(
                    1, "S099", "TRAUMATISMO DE LA CABEZA, NO ESPECIFICADO", "Diagnóstico principal");
            var convenio = new DetalleLineaDeVersion.ConvenioDeVersion(
                    "25100", null, "38325", "871020", null);
            var atencion = new DetalleLineaDeVersion.AtencionDeVersion("No Aplica", "NO APLICA", null);

            var d = new DetalleLineaDeVersion(linea(null), List.of(novedad), List.of(diagnostico),
                                              convenio, atencion);

            assertThat(d.novedades()).singleElement()
                    .satisfies(n -> assertThat(n.repeticiones()).isEqualTo(12));
            assertThat(d.diagnosticos()).containsExactly(diagnostico);
            assertThat(d.convenio().clausulas()).isEmpty();
            assertThat(d.convenio().tarifaSoat()).isEqualTo("38325");
            assertThat(d.atencion().tipoSala()).isEqualTo("No Aplica");
            assertThat(d.linea().numeroLinea()).isEqualTo(1);
        }

        @Test
        @Tag("BUS-21")
        @DisplayName("las cláusulas del convenio se conservan en su orden, descuentos incluidos")
        void clausulas() {
            var convenio = new DetalleLineaDeVersion.ConvenioDeVersion(null, null, null, null,
                    List.of(new DetalleLineaDeVersion.ClausulaDeVersion(
                                    new BigDecimal("38758.16"), "Manual tarifario ISS2000", "ISS2000_COP"),
                            new DetalleLineaDeVersion.ClausulaDeVersion(
                                    new BigDecimal("-9689.16"), "REGLA_CUENTA_MEDICA",
                                    "RVI_CUENTAS_MEDICAS")));

            assertThat(convenio.clausulas()).extracting(DetalleLineaDeVersion.ClausulaDeVersion::regla)
                    .containsExactly("ISS2000_COP", "RVI_CUENTAS_MEDICAS");
        }
    }

    @Test
    @Tag("BUS-21")
    @DisplayName("el estado de una línea tiene los dos desenlaces y el desconocido")
    void estadosDeLinea() {
        assertThat(EstadoLinea.values()).extracting(Enum::name)
                .containsExactly("APROBADA", "NEGADA", "DESCONOCIDO");
    }
}
