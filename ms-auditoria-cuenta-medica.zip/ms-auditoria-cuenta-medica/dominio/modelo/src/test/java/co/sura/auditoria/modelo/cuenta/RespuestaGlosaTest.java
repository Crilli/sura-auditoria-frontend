package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * La respuesta del prestador a las glosas.
 *
 * <p>Medido el 2026-10-17 sobre CM-94421, que tiene dos: una de junio y otra de noviembre,
 * con sus versiones CM-94421-V4 y CM-94421-V6.
 */
@DisplayName("RespuestaGlosa")
class RespuestaGlosaTest {

    private static RespuestaGlosa deJunio() {
        return new RespuestaGlosa("1", "CM-94421-V4", new BigDecimal("3534729"),
                LocalDate.of(2023, 6, 30), LocalDate.of(2023, 7, 12));
    }

    @Test
    @Tag("VIS-11")
    @DisplayName("trae la versión que abrió: no hay que ir al histórico de versiones a buscarla")
    void traeLaVersionQueAbrio() {
        assertThat(deJunio().versionAbierta()).isEqualTo("CM-94421-V4");
        assertThat(deJunio().secuencia()).isEqualTo("1");
    }

    @Test
    @Tag("VIS-08")
    @DisplayName("una respuesta cuyo plazo ya pasó está vencida")
    void unaConPlazoPasadoEstaVencida() {
        assertThat(deJunio().vencida(LocalDate.of(2023, 7, 13))).isTrue();
    }

    @Test
    @Tag("VIS-08")
    @DisplayName("el mismo día del vencimiento todavía no está vencida")
    void elMismoDiaNoEstaVencida() {
        // El plazo es «hasta», inclusive: dar por vencida una respuesta el día en que aún se
        // puede contestar haría que el auditor la tratara como perdida teniéndola a tiempo.
        assertThat(deJunio().vencida(LocalDate.of(2023, 7, 12))).isFalse();
    }

    @Test
    @Tag("VIS-08")
    @DisplayName("sin fecha de vencimiento no se afirma que venció")
    void sinFechaNoSeAfirmaQueVencio() {
        var sinPlazo = new RespuestaGlosa("1", "CM-1-V2", BigDecimal.TEN,
                LocalDate.of(2023, 6, 30), null);

        assertThat(sinPlazo.vencida(LocalDate.of(2030, 1, 1))).isFalse();
    }

    @Test
    @Tag("VIS-08")
    @DisplayName("sin fecha de referencia tampoco: no hay contra qué comparar")
    void sinFechaDeReferenciaTampoco() {
        assertThat(deJunio().vencida(null)).isFalse();
    }
}
