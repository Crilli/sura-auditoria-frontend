package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

@DisplayName("EjecucionAccion")
class EjecucionAccionTest {

    @Nested
    @DisplayName("qué acciones exigen motivos")
    class QueAccionesExigenMotivos {

        @ParameterizedTest
        @EnumSource(value = AccionCuenta.class, names = {"ANULAR", "REVERTIR_FINALIZACION"})
        @DisplayName("anular y desfinalizar los exigen: OHI las rechaza sin ellos")
        void anularYDesfinalizarLosExigen(AccionCuenta accion) {
            assertThat(EjecucionAccion.exigeMotivos(accion)).isTrue();

            assertThatThrownBy(() -> new EjecucionAccion(accion, List.of(), null, List.of(),
                    accion == AccionCuenta.ANULAR ? "MSG" : null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("exige al menos un motivo");
        }

        @ParameterizedTest
        @EnumSource(value = AccionCuenta.class,
                names = {"ANULAR", "REVERTIR_FINALIZACION"}, mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("las demás no los admiten")
        void lasDemasNoLosAdmiten(AccionCuenta accion) {
            assertThat(EjecucionAccion.exigeMotivos(accion)).isFalse();

            assertThatThrownBy(() -> EjecucionAccion.conMotivos(accion, List.of("M1"), null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("no admite motivos");
        }

        @ParameterizedTest
        @EnumSource(value = AccionCuenta.class,
                names = {"ANULAR", "REVERTIR_FINALIZACION", "DESBLOQUEAR_LINEAS"},
                mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("una acción simple se construye sin nada más")
        void unaAccionSimpleSeConstruyeSinNadaMas(AccionCuenta accion) {
            assertThatCode(() -> EjecucionAccion.simple(accion)).doesNotThrowAnyException();
        }
    }

    @Nested
    @DisplayName("anulación")
    class Anulacion {

        @Test
        @DisplayName("lleva motivos, referencia y mensaje, y es irreversible")
        void llevaMotivosReferenciaYMensaje() {
            var anular = EjecucionAccion.anular(List.of("M1", "M2"), "REF-1", "ANULACION_010");

            assertThat(anular.accion()).isEqualTo(AccionCuenta.ANULAR);
            assertThat(anular.motivos()).containsExactly("M1", "M2");
            assertThat(anular.referencia()).isEqualTo("REF-1");
            assertThat(anular.codigoMensajeAnulacion()).isEqualTo("ANULACION_010");
            assertThat(anular.esIrreversible()).isTrue();
        }

        @Test
        @DisplayName("es la única acción que admite mensaje de anulación")
        void esLaUnicaQueAdmiteMensaje() {
            assertThatThrownBy(() -> new EjecucionAccion(AccionCuenta.REVERTIR_FINALIZACION,
                    List.of("M1"), null, List.of(), "ANULACION_010"))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("Solo la anulación admite un mensaje");
        }

        @ParameterizedTest
        @EnumSource(value = AccionCuenta.class, names = "ANULAR", mode = EnumSource.Mode.EXCLUDE)
        @DisplayName("ninguna otra acción es irreversible")
        void ningunaOtraEsIrreversible(AccionCuenta accion) {
            var ejecucion = EjecucionAccion.exigeMotivos(accion)
                    ? EjecucionAccion.conMotivos(accion, List.of("M1"), null)
                    : accion == AccionCuenta.DESBLOQUEAR_LINEAS
                        ? EjecucionAccion.desbloquear(List.of(1L))
                        : EjecucionAccion.simple(accion);

            assertThat(ejecucion.esIrreversible()).isFalse();
        }
    }

    @Nested
    @DisplayName("desbloqueo de líneas")
    class DesbloqueoDeLineas {

        @Test
        @DisplayName("es la única que admite una lista de líneas")
        void esLaUnicaQueAdmiteLineas() {
            assertThat(EjecucionAccion.desbloquear(List.of(1L, 2L)).lineas())
                    .containsExactly(1L, 2L);

            assertThatThrownBy(() -> new EjecucionAccion(AccionCuenta.ENVIAR, List.of(), null,
                    List.of(1L), null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("no admite una lista de líneas");
        }

        @Test
        @DisplayName("admite la lista vacía: desbloquear nada no es un error de forma")
        void admiteLaListaVacia() {
            assertThatCode(() -> EjecucionAccion.desbloquear(List.of()))
                    .doesNotThrowAnyException();
        }
    }

    @Test
    @DisplayName("sin acción no se sabe qué ejecutar")
    void sinAccionNoSeSabeQueEjecutar() {
        assertThatThrownBy(() -> new EjecucionAccion(null, List.of(), null, List.of(), null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("qué acción");
    }

    @Test
    @DisplayName("las listas nulas se normalizan a vacías y quedan inmutables")
    void lasListasNulasSeNormalizanYQuedanInmutables() {
        var ejecucion = new EjecucionAccion(AccionCuenta.ENVIAR, null, null, null, null);

        assertThat(ejecucion.motivos()).isEmpty();
        assertThat(ejecucion.lineas()).isEmpty();

        var original = new ArrayList<>(List.of(1L));
        var desbloqueo = EjecucionAccion.desbloquear(original);
        original.add(2L);

        assertThat(desbloqueo.lineas()).containsExactly(1L);
    }
}
