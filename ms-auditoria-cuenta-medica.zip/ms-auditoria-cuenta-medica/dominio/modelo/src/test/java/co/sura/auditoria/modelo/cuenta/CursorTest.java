package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("Cursor")
class CursorTest {

    @Test
    @DisplayName("PRIMERA_PAGINA vale cero y se reconoce como inicio")
    void primeraPaginaValeCeroYSeReconoce() {
        assertThat(Cursor.PRIMERA_PAGINA.ultimaReferencia()).isZero();
        assertThat(Cursor.PRIMERA_PAGINA.esPrimeraPagina()).isTrue();
    }

    @ParameterizedTest(name = "{0} es primera página")
    @ValueSource(longs = {0L, -1L, Long.MIN_VALUE})
    @DisplayName("cero y negativos cuentan como inicio: no hay filtro de cursor que aplicar")
    void ceroYNegativosCuentanComoInicio(long referencia) {
        assertThat(new Cursor(referencia).esPrimeraPagina()).isTrue();
    }

    @ParameterizedTest(name = "{0} NO es primera página")
    @ValueSource(longs = {1L, 148111592284L, Long.MAX_VALUE})
    @DisplayName("una referencia positiva es un avance real del keyset")
    void unaReferenciaPositivaEsUnAvance(long referencia) {
        assertThat(new Cursor(referencia).esPrimeraPagina()).isFalse();
    }

    @Test
    @DisplayName("dos cursores con la misma referencia son iguales")
    void dosCursoresConLaMismaReferenciaSonIguales() {
        assertThat(new Cursor(99L)).isEqualTo(new Cursor(99L))
                .hasSameHashCodeAs(new Cursor(99L));
    }
}
