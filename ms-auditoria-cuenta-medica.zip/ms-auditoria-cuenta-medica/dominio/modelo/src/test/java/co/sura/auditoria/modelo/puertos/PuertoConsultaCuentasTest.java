package co.sura.auditoria.modelo.puertos;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.withSettings;

import co.sura.auditoria.modelo.cuenta.AccionCuenta;
import co.sura.auditoria.modelo.cuenta.AccionesDisponibles;
import co.sura.auditoria.modelo.cuenta.CodigoCuenta;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@DisplayName("PuertoConsultaCuentas")
class PuertoConsultaCuentasTest {

    @Test
    @Tag("OPE-09")
    @DisplayName("quien no guarda nada responde las acciones frescas igual que las de siempre")
    void frescasPorOmision() {
        var puerto = mock(PuertoConsultaCuentas.class, withSettings().defaultAnswer(Mockito.CALLS_REAL_METHODS));
        var acciones = new AccionesDisponibles(Set.of(AccionCuenta.ENVIAR));
        doReturn(Mono.just(acciones)).when(puerto).consultarAccionesDisponibles(any());

        StepVerifier.create(puerto.consultarAccionesFrescas(new CodigoCuenta("CM-94421")))
                .expectNext(acciones).verifyComplete();
    }
}
