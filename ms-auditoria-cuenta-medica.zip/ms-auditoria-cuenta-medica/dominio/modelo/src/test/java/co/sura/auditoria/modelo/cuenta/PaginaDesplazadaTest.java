package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

@DisplayName("PaginaDesplazada")
class PaginaDesplazadaTest {

    @Nested
    @DisplayName("cuántas páginas hay")
    class CuantasPaginasHay {

        @ParameterizedTest(name = "{0} elementos de {1} en {1} son {2} páginas")
        @CsvSource({
                "4063, 25, 163",   // la cuenta mayor medida: la última va a medias
                "212,  25, 9",     // la del entorno de pruebas
                "100,  25, 4",     // divisible exacto: no sobra una página vacía
                "1,    25, 1",
                "0,    25, 0",
        })
        @DisplayName("se redondea hacia arriba, porque la última página cuenta aunque esté a medias")
        void seRedondeaHaciaArriba(long total, int tamano, long esperadas) {
            var pagina = PaginaDesplazada.deOhi(List.of(), 0, tamano, total, false);

            assertThat(pagina.totalPaginas()).contains(esperadas);
        }

        @Test
        @DisplayName("sin total no se puede decir cuántas hay, y no se inventa")
        void sinTotalNoSePuedeDecirCuantasHay() {
            var pagina = PaginaDesplazada.filtradaAqui(List.of("a"), 0, 25, true);

            assertThat(pagina.totalEsDeFiar()).isFalse();
            assertThat(pagina.totalPaginas()).isEmpty();
        }

        @Test
        @DisplayName("un tamaño de página de cero no divide por cero")
        void unTamanoDeCeroNoDividePorCero() {
            var pagina = PaginaDesplazada.deOhi(List.of(), 0, 0, 10L, false);

            assertThat(pagina.totalPaginas()).contains(1L);
            assertThat(pagina.numeroDePagina()).isZero();
        }
    }

    @Nested
    @DisplayName("en qué página estamos")
    class EnQuePaginaEstamos {

        @ParameterizedTest(name = "desplazamiento {0} con tamaño {1} es la página {2}")
        @CsvSource({"0, 25, 0", "25, 25, 1", "4025, 25, 161", "4050, 25, 162"})
        @DisplayName("sale de dividir la posición entre el tamaño")
        void saleDeDividirLaPosicion(int desplazamiento, int tamano, int esperada) {
            var pagina = PaginaDesplazada.deOhi(List.of(), desplazamiento, tamano, 4063L, true);

            assertThat(pagina.numeroDePagina()).isEqualTo(esperada);
        }
    }

    @Nested
    @DisplayName("el total")
    class ElTotal {

        @Test
        @DisplayName("deOhi conserva el total que dio el sistema de registro")
        void deOhiConservaElTotal() {
            assertThat(PaginaDesplazada.deOhi(List.of("a"), 0, 25, 4063L, true).total())
                    .contains(4063L);
        }

        @Test
        @DisplayName("deOhi sin total lo deja vacío, no en cero")
        void deOhiSinTotalLoDejaVacio() {
            // Pasa en el 204 de un desplazamiento pasado del final: no hay total.
            // Vacío y cero dicen cosas distintas, y confundirlos es enseñar una
            // cuenta de 212 líneas como si no tuviera ninguna.
            assertThat(PaginaDesplazada.deOhi(List.of(), 300, 25, null, false).total())
                    .isEmpty();
        }

        @Test
        @DisplayName("filtradaAqui nunca lleva total, aunque el de OHI estuviera a mano")
        void filtradaAquiNuncaLlevaTotal() {
            assertThat(PaginaDesplazada.filtradaAqui(List.of("a", "b"), 0, 25, true).total())
                    .isEmpty();
        }

        @Test
        @DisplayName("la página vacía dice cero de total: es la respuesta correcta, no una ausencia")
        void laPaginaVaciaDiceCero() {
            var vacia = PaginaDesplazada.<String>vacia(25);

            assertThat(vacia.elementos()).isEmpty();
            assertThat(vacia.total()).contains(0L);
            assertThat(vacia.hayMas()).isFalse();
            assertThat(vacia.desplazamiento()).isZero();
        }
    }

    @Nested
    @DisplayName("hayMas")
    class HayMas {

        @Test
        @DisplayName("es independiente del total: con total vacío sigue siendo de fiar")
        void esIndependienteDelTotal() {
            // Es lo único que permite ofrecer «siguiente» cuando se filtra por algo
            // que el sistema de registro no sabe aplicar.
            var pagina = PaginaDesplazada.filtradaAqui(List.of("a"), 0, 25, true);

            assertThat(pagina.totalEsDeFiar()).isFalse();
            assertThat(pagina.hayMas()).isTrue();
        }

        @Test
        @DisplayName("una página corta no implica por sí misma que se acabó")
        void unaPaginaCortaNoImplicaQueSeAcabo() {
            // Bajo desplazamiento el fin lo dice el sistema de registro, no la
            // aritmética: con un filtro aplicado aquí, un lote puede dar pocas
            // filas y quedar cuenta por recorrer.
            var corta = PaginaDesplazada.filtradaAqui(List.of("a"), 0, 25, true);

            assertThat(corta.elementos()).hasSize(1);
            assertThat(corta.hayMas()).isTrue();
        }
    }

    @Nested
    @DisplayName("la lista de elementos")
    class LaLista {

        @Test
        @DisplayName("se copia: quien la pasó no puede cambiarla después")
        void seCopia() {
            var original = new ArrayList<String>(List.of("a"));
            var pagina = PaginaDesplazada.deOhi(original, 0, 25, 1L, false);

            original.add("b");

            assertThat(pagina.elementos()).containsExactly("a");
        }

        @Test
        @DisplayName("no se puede modificar desde fuera")
        void noSePuedeModificarDesdeFuera() {
            var pagina = PaginaDesplazada.deOhi(List.of("a"), 0, 25, 1L, false);

            assertThatThrownBy(() -> pagina.elementos().add("b"))
                    .isInstanceOf(UnsupportedOperationException.class);
        }

        @Test
        @DisplayName("un total nulo en el constructor se normaliza a vacío, no explota")
        void unTotalNuloSeNormaliza() {
            var pagina = new PaginaDesplazada<>(List.of("a"), 0, 25, null, false);

            assertThat(pagina.total()).isEqualTo(Optional.empty());
        }
    }
}
