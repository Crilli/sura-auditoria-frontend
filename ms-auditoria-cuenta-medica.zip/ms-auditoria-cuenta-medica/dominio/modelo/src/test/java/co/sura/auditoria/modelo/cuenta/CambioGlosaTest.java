package co.sura.auditoria.modelo.cuenta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("CambioGlosa")
class CambioGlosaTest {

    @Nested
    @DisplayName("alta")
    class Alta {

        @Test
        @DisplayName("se construye con causal y valor, y el identificador lo pone el sistema")
        void seConstruyeConCausalYValor() {
            var alta = CambioGlosa.agregar("208-1", "Tarifas", "Ayudas diagnósticas",
                    new BigDecimal("1500.00"), "Tarifa superior a la pactada");

            assertThat(alta.esAlta()).isTrue();
            assertThat(alta.esBaja()).isFalse();
            assertThat(alta.identificador()).isNull();
            assertThat(alta.codigoGlosa()).isEqualTo("208-1");
            assertThat(alta.valor()).isEqualByComparingTo("1500.00");
        }

        @Test
        @DisplayName("admite valor cero: glosar por cero es objetar sin descontar")
        void admiteValorCero() {
            assertThat(CambioGlosa.agregar("TA0201", null, null, BigDecimal.ZERO, null).valor())
                    .isEqualByComparingTo(BigDecimal.ZERO);
        }

        @ParameterizedTest(name = "rechaza causal [{0}]")
        @NullAndEmptySource
        @ValueSource(strings = {"  "})
        @DisplayName("sin código de causal no se puede glosar")
        void sinCodigoDeCausalNoSePuedeGlosar(String causal) {
            assertThatThrownBy(() ->
                    CambioGlosa.agregar(causal, null, null, BigDecimal.TEN, null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("código de causal");
        }

        @Test
        @DisplayName("sin valor no se puede glosar")
        void sinValorNoSePuedeGlosar() {
            assertThatThrownBy(() -> CambioGlosa.agregar("208-1", null, null, null, null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("valor");
        }

        @Test
        @DisplayName("un valor negativo no es una glosa")
        void unValorNegativoNoEsUnaGlosa() {
            assertThatThrownBy(() ->
                    CambioGlosa.agregar("208-1", null, null, new BigDecimal("-1"), null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("negativo");
        }

        @Test
        @DisplayName("un alta con identificador se rechaza: lo asigna el sistema de registro")
        void unAltaConIdentificadorSeRechaza() {
            assertThatThrownBy(() -> new CambioGlosa(CambioGlosa.Operacion.AGREGAR, 99L,
                    "208-1", null, null, BigDecimal.TEN, null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("identificador");
        }
    }

    @Nested
    @DisplayName("baja")
    class Baja {

        @Test
        @DisplayName("solo lleva el identificador")
        void soloLlevaElIdentificador() {
            var baja = CambioGlosa.eliminar(4242L);

            assertThat(baja.esBaja()).isTrue();
            assertThat(baja.esAlta()).isFalse();
            assertThat(baja.identificador()).isEqualTo(4242L);
            assertThat(baja.codigoGlosa()).isNull();
            assertThat(baja.valor()).isNull();
        }

        @Test
        @DisplayName("sin identificador no se puede eliminar")
        void sinIdentificadorNoSePuedeEliminar() {
            assertThatThrownBy(() -> new CambioGlosa(CambioGlosa.Operacion.ELIMINAR, null,
                    null, null, null, null, null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("identificador");
        }

        @Test
        @DisplayName("una baja con importe se rechaza: sería un parche ambiguo")
        void unaBajaConImporteSeRechaza() {
            assertThatThrownBy(() -> new CambioGlosa(CambioGlosa.Operacion.ELIMINAR, 1L,
                    null, null, null, BigDecimal.TEN, null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("solo admite su identificador");
        }

        @Test
        @DisplayName("una baja con causal se rechaza")
        void unaBajaConCausalSeRechaza() {
            assertThatThrownBy(() -> new CambioGlosa(CambioGlosa.Operacion.ELIMINAR, 1L,
                    "208-1", null, null, null, null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("solo admite su identificador");
        }

        @Test
        @DisplayName("una baja con texto se rechaza")
        void unaBajaConTextoSeRechaza() {
            assertThatThrownBy(() -> new CambioGlosa(CambioGlosa.Operacion.ELIMINAR, 1L,
                    null, null, null, null, "motivo"))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("solo admite su identificador");
        }
    }

    @Test
    @DisplayName("sin operación no se sabe qué hacer")
    void sinOperacionNoSeSabeQueHacer() {
        assertThatThrownBy(() -> new CambioGlosa(null, null, "208-1", null, null,
                BigDecimal.TEN, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("agrega o se elimina");
    }
}
