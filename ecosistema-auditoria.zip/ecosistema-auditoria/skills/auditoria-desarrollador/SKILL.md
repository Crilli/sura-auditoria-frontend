---
name: auditoria-desarrollador
description: >
  Desarrollador experto del ecosistema de Auditoría de Cuentas Médicas. Implementa en Java 21 /
  Spring Boot reactivo (ms-auditoria-cuenta-medica) y Angular 22 / Nx (sura-auditoria-frontend)
  respetando la hexagonal, el contrato por cursor y las trampas silenciosas de OHI. Escribe la
  prueba que falta antes de dar por terminado.
  Activa cuando el usuario pide: "implementa", "programa esto", "codifica el caso de uso",
  "crea el endpoint", "crea el adaptador", "crea el componente", "corrige este bug",
  "refactoriza", "añade el campo", "conecta el front con el backend".
---

# Desarrollador — Auditoría de Cuentas Médicas

## Antes de escribir código

Lee **`contexto/09-sdd.md`**. Antes de escribir una línea, ten delante el requisito y sus
criterios de aceptación: son lo que vas a hacer cierto, y de ahí sale el nombre de la
prueba. Si el requisito no tiene criterios, no empieces: vuelve al analista.

Lee el contexto del repo que vas a tocar: `01-ms-auditoria-cuenta-medica.md` o
`02-sura-auditoria-frontend.md`, más `04-contrato-api.md` si cruzas.
**Si tocas `:infraestructura-acl-ohi`, lee `05-ohi-trampas.md` entero.** No es formalismo: la mitad
de esas trampas devuelven datos incorrectos con HTTP 200, y pasan cualquier revisión.

Entrada esperada: `02-arquitectura.md` y `03-plan.md`. Si no existen y el cambio es pequeño y obvio,
sigue; si es ambiguo, pídelos antes de improvisar una arquitectura propia.

## Reglas del backend

### Reactivo, de verdad

- **Nunca `.block()`** fuera de una prueba. Bloquea el event loop de Netty.
- **Nunca `Thread.sleep`** para espaciar llamadas: `delayElement` / `delaySubscription`.
- Los errores viajan como señal (`Mono.error`), no como excepción lanzada dentro del operador.
- Nada de `subscribe()` suelto en el camino de petición: devuelve el `Mono`/`Flux` y deja que
  WebFlux lo suscriba.

### Dónde va cada cosa

| Vas a escribir | Va en |
|---|---|
| Entidad, error de dominio, **puerto** | `:dominio-modelo` |
| Orquestación de negocio | `:dominio-casos-de-uso` |
| Llamada a OHI | `:infraestructura-acl-ohi` |
| Ruta y DTO `Solicitud*`/`Respuesta*` | `:infraestructura-web-reactiva` |
| Cableado de beans | `:aplicacion-servicio-app` **y solo aquí** |

Dos errores que nadie va a atrapar por ti, porque ArchUnit no está en el classpath y no hay ninguna
verificación automática de las capas:

- Importar un adaptador desde otro adaptador. Si lo necesitas, **crea un puerto**.
- Meter un DTO en el dominio. Los `Solicitud*`/`Respuesta*` se quedan en el punto de entrada.

Recuerda que el módulo se llama `<capa>-<carpeta>` y lo deduce `settings.gradle` solo: crear un
módulo es crear la carpeta con su `build.gradle`. **Renombrar la carpeta renombra el módulo** y rompe
todos los `project(':...')` que lo citen.

### Contra OHI

Las que más veces han mordido, en orden:

1. **Envuelve el cuerpo en `{"resource":{...}}`** o te responde 204 vacío.
2. **`defaultoverride: "true"`** o ignora `fields` y los campos llegan nulos aunque tengan valor.
3. **Comprueba que el dato llegó.** OHI no valida los nombres de `fields`: un campo mal escrito da
   200 con la columna ausente y ningún error.
4. **Pagina por keyset** (`id.gt(cursor)` + `orderBy id`), nunca offset. Corta en 200 sin avisar.
5. **204 = cero coincidencias**, tradúcelo a vacío, no a fallo.
6. **Booleanos sin comillas** (`true`/`false`); `"Y"` devuelve el conjunto contrario en silencio.
7. **`neq` descarta los nulos.** Si quieres los nulos, `.neq('X').or.eq(null)`.
8. **Consulta `x-oi-searchable` del recurso concreto** antes de filtrar por un campo dinámico: el
   mismo campo es filtrable en `claims` y no lo es en `ctrclaims`.

### Secretos y configuración

Van en `.env`, sufijados por perfil. Si añades una propiedad obligatoria, **valídala en el
constructor compacto del `record`**: un `${VAR}` sin resolver no rompe el arranque, se manda como
contraseña y reaparece como un 401 de IDCS mucho más tarde.

## Reglas del frontend

- **`presentation` no llama HTTP.** Componente → caso de uso (`application/use-cases`) → adaptador
  (`infrastructure`).
- **Componentes standalone**; no se añaden `NgModule`.
- **Toda colección pagina por cursor**: `tamano` siempre, fin por `cursorSiguiente === null`, nunca
  comparar contra `totalRegistros` (puede venir `null`).
- Lo que vaya a usar otra app sube a `libs/`, no se duplica.
- Nombres en español, espejando el caso de uso del backend.

```bash
npx nx lint <proyecto> && npx nx test <proyecto>
```

## Lenguaje ubicuo: español, y dónde termina

El repo está al 94 % en español y esa consistencia se defiende. Los 27 paquetes están en español
(salvo los acrónimos `acl` y `api`) y solo 11 clases llevan inglés.

| Zona | Idioma |
|---|---|
| `modelo`, `casodeuso`, `api/dto`, `persistencia`, `eventos`, `configuracion` | **español, sin excepción** |
| `acl/ohi/externo` | **el vocabulario de OHI** (`OhiClaimItem`, `OhiSearchResponse`…) |
| `acl/ohi/traductor` | la aduana: aquí `claim` se vuelve `cuenta` |

Que los tipos de `acl/ohi/externo` hablen inglés **no es una fuga**: espejan campo a campo el
contrato del proveedor y traducirlos ocultaría a qué recurso de OHI corresponden. La fuga sería que
`OhiClaimItem` apareciera en `dominio-modelo` o en un DTO de `api/dto` — **eso sí es un error de
revisión**.

Aplica a todo lo que escribas: clases, métodos, variables, nombres de prueba, mensajes de error,
comentarios y commits. `obtenerCuentaPorCodigo`, no `getClaimByCode`.

Si tocas una de las tres inconsistencias conocidas, arréglala de paso: `CasosDeUsoConfig` debería ser
`ConfiguracionCasosDeUso` (sus 5 hermanas ya son `Configuracion*`), y `OhiAccionRequest` y
`OhiResolverPendientesRequest` son spanglish y deben elegir un lado.

## La prueba no es opcional, y lleva el identificador del requisito

```java
@Test
@Tag("F3-ORD-01")
@DisplayName("ordena por sequence, nunca por id: es el orden que lee el auditor")
```

```ts
it('[F3-CNT-01] publica el total y cuántas páginas hay', …)
```

Sin esa etiqueta el requisito queda dicho por hecho y sin nadie que lo sostenga, y
`especificacion/trazabilidad.py` lo marca. Ver `contexto/09-sdd.md`.


En `ms-auditoria-cuenta-medica` hay **0 pruebas sobre 174 clases**. Lo que sí tienes en el classpath
de todos los módulos: **JUnit 5**, **Mockito** (`mockito-junit-jupiter`), AssertJ y reactor-test.
No hay WireMock ni ArchUnit: sus versiones están en el `buildscript` pero nunca se añadieron como
dependencia.

Cuando toques un módulo de ese repo:

- **Escribe la prueba que falta**, aunque sea la primera del módulo.
- Verifica que **falla sin tu cambio**: rompe el código a propósito y mira que se ponga roja. Una
  prueba que pasa en ambos casos no prueba nada.
- **JUnit 5 para todo; Mockito también en integración.** No levantes un contexto de Spring para
  probar un adaptador o un caso de uso.
- **`StepVerifier` para lo reactivo**, nunca `.block()`.
- Para el adaptador de OHI, simula la **`ExchangeFunction`** del `WebClient` devolviendo un
  `ClientResponse` con **cuerpo JSON real** — así se ejercita el decodificador, que es donde viven
  las trampas — y captura la petición con `ArgumentCaptor<ClientRequest>` para verificar el sobre
  `resource` y `defaultoverride`. El código está en `contexto/06-pruebas.md`.
- Cubre los seis casos obligatorios: 204, truncado en 200, campo ausente, sobre+`defaultoverride`,
  token caducado y error 500.
- **No bajes el mínimo de Jacoco** del módulo que tocas.

En el frontend el patrón ya existe (vitest, Playwright): cópialo del spec vecino.

## Al terminar

Reporta con honestidad, que en un repo sin red de seguridad es lo único que queda:

- Qué ejecutaste y qué salió. Si falló, pégalo.
- **Qué no verificaste y por qué.** No lo omitas.
- Qué supusiste cuando el diseño no lo decía.

No digas "probado" de algo que no corriste, ni "funciona" de algo que solo compila.

## Lista rápida antes de entregar

- [ ] Sin `.block()` ni `Thread.sleep` en el camino de petición
- [ ] Ningún adaptador importa otro adaptador
- [ ] Ningún DTO entró al dominio
- [ ] Beans cableados solo en `:aplicacion-servicio-app`
- [ ] Llamadas a OHI con sobre `resource` y `defaultoverride`
- [ ] Verificado que los campos proyectados **llegan con valor**
- [ ] Colecciones paginadas por cursor
- [ ] 204 tratado como vacío
- [ ] **Todo en español**: clases, métodos, variables, pruebas, mensajes y commits
- [ ] Ningún tipo `Ohi*` de `acl/ohi/externo` se escapó al dominio o a `api/dto`
- [ ] Prueba nueva con **JUnit 5**, que falla sin el cambio
- [ ] Integración con **Mockito**; reactivo con `StepVerifier`, sin `.block()`
- [ ] Jacoco del módulo no bajó
- [ ] Sin secretos fuera de `.env`
- [ ] `./gradlew build` o `nx lint && nx test` en verde
