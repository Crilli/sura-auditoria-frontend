# Plan de pruebas — Paginado de líneas por desplazamiento

Cambio: el listado de líneas deja de paginar por clave (cursor) y pasa a paginar por
desplazamiento, con el `offset` / `totalResults` / `hasMore` que publica OHI.

## Qué se prueba y qué no

**Se prueba**

- Que se pueda ir a **cualquier** página, y a la última, con **una** petición. Era el fallo
  reportado: «No funciona el offset en el front cuando me quiero ir a la última página».
- Que el **orden** de la grilla sea el número de línea y no el identificador.
- Que el **total** que acompaña a una página profunda sea el verdadero.
- Que la ausencia de total —filtro que OHI no sabe aplicar— se propague y no se invente.
- Que un desplazamiento **pasado del final** no se lea como «la cuenta no tiene líneas».
- Que «guardar y pasar a la siguiente», que iba montado sobre el cursor, siga funcionando y
  además avance en el orden correcto.

**No se prueba aquí**

| Qué | Por qué |
|---|---|
| Renovación del token caducado (caso obligatorio 5) | No vive en este adaptador sino en el filtro de autenticación del cliente; ya está cubierto en `TokenOhiTest` |
| «Guardar y avanzar» de extremo a extremo | Escribe en OHI, y las pruebas no escriben en producción. Se verificó el `GET …/siguiente` en lectura (200 → línea 2; 204 en la última) y el guardado no cambió |
| Pendientes | Siguen paginando por clave: su paginación son **dos** recursos concatenados y un `offset` de OHI es por recurso. Es otra conversación |

## Casos

| ID | Criterio | Escenario | Nivel | Automatizado |
|---|---|---|---|---|
| CP-01 | Ir a cualquier página | `offset` y `limit` viajan dentro de `resource` | integración (JUnit 5 + Mockito sobre `ExchangeFunction`) | sí |
| CP-02 | Orden del auditor | Se ordena por `sequence asc`, nunca por `id` | integración | sí |
| CP-03 | Proyección | `fields` va en `resourceRepresentation` **con** `defaultoverride`, no en `resource` | integración | sí |
| CP-04 | Sobre limpio | Una consulta sin desplazamiento no manda `"offset": null` | integración + unitaria | sí |
| CP-05 | Total profundo | En `offset=200` de una cuenta de 212, el total es 212 y las páginas 9 | integración | sí |
| CP-06 | Fin de lista | `hasMore=false` corta el avance en la última página | integración | sí |
| CP-07 | Red de seguridad | Si faltara `hasMore`, `hayMas` se deduce del total | integración | sí |
| CP-08 | Cuenta vacía | 204 en la posición 0 es «no tiene líneas», no un error | integración | sí |
| CP-09 | **Pasado del final** | 204 en `offset=300` **no** dice que la cuenta esté vacía: pregunta el total aparte y devuelve 212 / 9 páginas | integración | sí |
| CP-10 | Campo ausente | Sin `objectVersionNumber` en la proyección, el listado **falla a la vista** en vez de inventar una versión | integración | sí |
| CP-11 | Error del registro | Un 500 llega como `ExcepcionDeDominio` | integración | sí |
| CP-12 | Filtro local | Con catálogo: no se publica total, se pide por lotes de 200 y el criterio no viaja en `q` | integración | sí |
| CP-13 | Siguiente línea | Busca por `sequence.gt(N)`, no por identificador | integración | sí |
| CP-14 | Última línea | No hay siguiente → vacío, y el API responde 204 | integración + web | sí |
| CP-15 | Traducción de la página | Posición, número de página, total y `hayMas` al DTO | unitaria (web) | sí |
| CP-16 | Parámetros | `pagina` se traduce con el tamaño **resuelto**; `desplazamiento` manda sobre `pagina`; negativos caen al principio | unitaria (web) | sí |
| CP-17 | Entrada inválida | `pagina=abc` se rechaza en vez de caer en la página 1 en silencio | unitaria (web) | sí |
| CP-18 | Normalización | Tamaño fuera de [1,25] se recorta; el desplazamiento **no** se recorta nunca | unitaria (caso de uso) | sí |
| CP-19 | Aritmética de páginas | 4.063 ÷ 25 = 163 páginas; sin total, ninguna | unitaria (dominio) | sí |
| CP-20 | Front: última página | Ir a la última cuesta **una** petición y deja «siguiente» apagado | integración (vitest, repositorio simulado) | sí |
| CP-21 | Front: salto al medio | Saltar a la página 5 no pasa por las anteriores | integración (vitest) | sí |
| CP-22 | Front: sin total | Sin total no hay números de página, pero sí «siguiente» | integración (vitest) | sí |
| CP-23 | Front: parpadeo | El total sobrevive mientras llega la página siguiente | integración (vitest) | sí |
| CP-24 | Front: reinicio | Cambiar el filtro vuelve a la página 1 y borra el total anterior | integración (vitest) | sí |

Ejemplo, en el formato de la skill:

```
CP-09 · Desplazamiento pasado del final
Dado    que OHI responde 204 sin cuerpo a offset=300 sobre una cuenta de 212 líneas
Cuando  el auditor vuelve a una página que ya no existe
Entonces la respuesta llega vacía PERO con total 212 y 9 páginas, no con cero
Nivel   integración (JUnit 5 + Mockito sobre ExchangeFunction)
```

## Fallos silenciosos cubiertos

| # | Caso | Dónde |
|---|---|---|
| 1 | **204 vacío** | CP-08 (principio) y CP-09 (pasado del final, que es el caso nuevo y el peligroso) |
| 2 | **Truncado en 200** | CP-12: el recorrido que descarta pide lotes de 200 y encadena por desplazamiento |
| 3 | **Campo ausente** | CP-10: la prueba exige que **falle**, no que acepte un nulo |
| 4 | **Sobre y `defaultoverride`** | CP-03 y CP-04, con el cuerpo serializado de verdad (ver nota abajo) |
| 5 | **Token caducado** | Fuera de alcance: vive en el filtro del cliente, cubierto en `TokenOhiTest` |
| 6 | **Error 500** | CP-11 |

### Nota: ahora sí se puede afirmar sobre el cuerpo enviado

Las pruebas existentes del adaptador declaraban que el cuerpo serializado no se podía
inspeccionar porque `MockClientHttpRequest` vive en `spring-test`, que no está en el
classpath. Se resolvió **sin añadir dependencias**: `CuerpoEnviado` (unas cuarenta líneas de
prueba) escribe el `BodyInserter` en un destino en memoria y devuelve el JSON. Es lo que hace
que CP-01 a CP-04 y CP-13 afirmen sobre lo que sale al cable y no sobre lo que se cree que sale.

## Lo que se midió contra OHI (lectura)

| Qué | Entorno | Resultado |
|---|---|---|
| `hasMore`, `count`, `offset`, `limit` en la respuesta | UAT, `CM-35343660784` (212 líneas) | Existen. `hasMore` cierto hasta la última página y falso en ella |
| `totalResults` a cualquier profundidad | UAT | 212 en `offset` 0, 100, 200 y 210 |
| Desplazamiento pasado del final | UAT, `offset=212` | **204 sin cuerpo**: ni total ni `hasMore` → de ahí CP-09 |
| `sequence.gt(100)` | UAT | Funciona; total coherente (113) → de ahí el endpoint de «siguiente» |
| Listado completo por el API | **producción**, `CM-55181980659` | Página 0: líneas 1,2,3…; total 4.063; 163 páginas |
| Última página por el API | producción | Página 162: 13 filas (4402–4414), `hayMas=false` |
| Más allá del final por el API | producción, `pagina=200` | 0 filas **con** total 4.063 y 163 páginas |
| `GET …/siguiente` | producción | De la línea 1 → línea 2 (200). De la última → 204 |
| Filtro por catálogo | producción | 25 filas, `totalRegistros: null`, `hayMas: true` |
| Pantalla | producción, navegador | Botón «última» **habilitado**, paginador 1…162 163, rango «4051–4063 de 4063 líneas» |

Ninguna de estas consultas escribe. Las pruebas automatizadas no tocan OHI.

## Cobertura

El trinquete de Jacoco ya estaba puesto (`jacocoTestCoverageVerification` encadenado a `check`,
mínimo por módulo en `build.gradle`).

| Módulo | Mínimo antes | Medido después | Mínimo después |
|---|---|---|---|
| `dominio-modelo` | 1.00 | 100 % | 1.00 |
| `dominio-casos-de-uso` | 1.00 | 100 % | 1.00 |
| `infraestructura-web-reactiva` | 1.00 | 100 % | 1.00 |
| `infraestructura-acl-ohi` | 0.18 | **37,8 %** | **0.37** ← sube |
| resto | 1.00 | 100 % | 1.00 |

`./gradlew check` pasa. 64 ficheros de prueba en el backend; 11 casos nuevos en el frontend.

## Comprobación de que las pruebas sirven

Se rompió el código a propósito y se verificó que se ponen rojas las que deben, y solo esas:

| Defecto inyectado | Qué se puso rojo |
|---|---|
| Quitar la consulta del total cuando la página sale vacía | CP-09 |
| `ORDEN_POR_LINEA = "id asc"` | CP-02 |
| Quitar `@JsonInclude(NON_NULL)` del sobre | CP-04 (las dos, la de integración y la unitaria) |
| Leer el total del recurso en vez de conservarlo | CP-23 |
| `ultimaPagina()` inerte | CP-20 y la de «en la última no se ofrece avanzar» |

Al restaurar, todo vuelve a verde.

Una prueba que se había escrito **no servía** y se rehízo: «un total que deja de venir no se
hereda del filtro anterior» pasaba con el defecto inyectado, porque el reinicio del filtro ya
pone el total a nulo antes de que llegue la respuesta. Se sustituyó por dos que sí se sostienen
(CP-23 y CP-24).

## Lo que quedó sin cubrir

| Qué | Riesgo |
|---|---|
| «Guardar y avanzar» de extremo a extremo | Bajo: el guardado no cambió y el nuevo `…/siguiente` está probado en los dos extremos. Queda por ver en un entorno donde se pueda escribir |
| Que `sequence` sea única y monótona en **toda** cuenta | Medio-bajo: comprobado recorriendo las 4.063 de la cuenta mayor y las 212 de la de pruebas. Si en alguna se repitiera, dos líneas caerían en la misma posición |
| El tope de 100 lotes al descartar (20.000 filas) | Bajo: ninguna cuenta vista se acerca. No hay prueba de qué se ve al alcanzarlo |
| Concurrencia: paginar mientras otro borra líneas | Cubierto el síntoma (CP-09), no la carrera |

## Trazabilidad contra la especificación

Este trabajo es anterior a que existiera la especificación del MVP, así que se ató después. De sus
pruebas, cuatro requisitos del MVP quedaron cubiertos:

| Requisito | Qué dice | Prueba que lo cita |
|---|---|---|
| `F3-ORD-01` | Ordenamiento por el campo Secuencia | `AdaptadorLineasDesplazadasOhiTest.ordenaPorSequenceNuncaPorId` |
| `F3-FIL-00` | El filtro no se queda en la página a la vista; alcanza toda la paginación | `AdaptadorLineasDesplazadasOhiTest.elDesplazamientoVaDentroDeResource` |
| `F3-CNT-01` | Que indique la cantidad de resultados encontrados | tres pruebas del adaptador y del mapeo, más `linea.facade.spec.ts` |
| `F3-CNT-03` | …y que se muestren en la paginación | `MapeadoresTest` y `linea.facade.spec.ts` |

El resto de las pruebas de esta entrega **no cubren ningún requisito del MVP**, y es correcto: «poder
ir a la última página» no está en el documento, que lo da por supuesto. Queda dicho en vez de
disimulado.

```bash
python3 especificacion/trazabilidad.py      # 4 de 114 dados por hechos tienen prueba que los cite
```

Ver [contexto/09-sdd.md](../../contexto/09-sdd.md).
