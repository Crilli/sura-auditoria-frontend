# Plan — MVP del módulo de cuentas médicas

> Actualizado el **2026-10-17** con las seis decisiones de negocio que se respondieron. El alcance se
> expresa en identificadores de requisito de
> [`especificacion/mvp-cuentas-medicas.yaml`](../../especificacion/mvp-cuentas-medicas.yaml);
> para ver cualquiera entero: `python3 especificacion/consultar.py BUS-13`.

## Alcance de esta entrega

| | |
|---|---|
| Requisitos del MVP | 196 |
| Ya cumplidos al hacer el plan | −88 |
| Opcionales o retirados por decisión | −31 |
| Reemplazo masivo (bloque F1), excluido por el encargo | −10 |
| **En alcance** | **67** |
| Cumplidos desde entonces (las siete entregas) | −61 |
| **Quedan** | **6** |

> **Avance al 2026-10-17, al cerrar la entrega 5 —la última—.** La especificación cuenta ya **149
> requisitos en `CUMPLE`** (los 88 de partida más 61 entregados). De los 67 en alcance quedan **6**, y
> **ninguno depende ya del código**: las siete entregas están hechas y lo que falta espera una
> respuesta o una decisión.
>
> - **4 bloqueados por la pregunta de «convenido» y «autorizado»** (`GRID-10` `GRID-11` `LIN-08`
>   `ENC-12`), igual que cuando se escribió el plan.
> - **`BTN-05` (notas), bloqueado por OHI**: medido en la entrega 6, OHI no ofrece ninguna forma de
>   crear una nota ligada a la cuenta —el recurso al que escribía el adaptador, `/generic/claimnotes`,
>   responde 404—. Lo tiene que abrir el equipo de integración de OHI.
> - **`BUS-02` en `PARCIAL`**: la paridad con el buscador de OHI depende de la decisión 4 de abajo
>   (los siete criterios opcionales). Lo que sí pide su criterio —abrir un resultado lleva a la vista
>   360 de siempre— está hecho.
>
> **Fuera de esta cuenta: el bloque `operacion` (`OPE-01`…`OPE-12`).** Se añadió a la especificación el
> 2026-10-17, después del plan, a raíz de la revisión de rendimiento y concurrencia: resolución masiva
> asíncrona con seguimiento, caché de agregados por cuenta, reparto de los pools y escrituras que no se
> informan como fallidas cuando OHI ya las aplicó. Los 12 están en `CUMPLE` y no cambian las cifras de
> arriba (la especificación pasa de 196 a 208 requisitos). Medido en UAT con 20 usuarios: de 5,7 a 11,5
> aperturas de cuenta por segundo y de 44 aperturas fallidas a ninguna.

| # | Entrega | Req. | Estado | Dónde pesa | Por qué va aquí |
|---|---|---|---|---|---|
| 1 | Lo barato que se ve el primer día | 6 | ✅ 6/6 | front, backend ligero | Devuelve valor en días y no bloquea a nadie |
| 2 | La grilla: columnas, orden y filtros | 18 | ✅ 18/18 | backend + front | Es la pantalla donde el auditor pasa el día, y desbloquea la 4 y la 5 |
| 3 | Del motivo a la línea | 6 | ✅ 6/6 | backend | Cierra el circuito «veo el motivo → corrijo la línea» |
| 4 | Selección múltiple y acciones masivas | 10 | ✅ 10/10 | front + 4 endpoints | Escribe en producción: va después de que la grilla esté quieta |
| 5 | Edición en línea sobre la grilla | 1 | ✅ 1/1 | front + backend | El requisito más caro del MVP y el de más riesgo de escritura |
| 6 | Respuesta a glosa, historia, notas y detalle de glosa | 8 | 7/8 · `BTN-05` bloqueado por OHI | backend + front | Todo lectura; se puede intercalar donde haya hueco |
| 7 | **Buscador de facturas y versiones** (vía paralela) | 14 | 13/14 · `BUS-02` parcial | 1 endpoint nuevo · rehacer una pantalla | No toca ningún fichero de las otras seis: es el trabajo de la segunda persona |

> **Las entregas 1→2→3→4→5 son una cadena** sobre la misma pantalla. La 7 es independiente desde el
> primer día y la 6 se puede intercalar. Con dos personas, la vía A hace la cadena y la vía B hace la
> 7 y luego la 6.

---

## Lo que se decidió el 2026-10-17

Seis respuestas que cerraron 12 requisitos y desbloquearon 5. Quedan anotadas en la especificación,
no solo aquí.

| Pregunta | Respuesta | Efecto |
|---|---|---|
| **¿Qué es «mono usuario»?** | Una cuenta cuyas líneas tienen **todas el mismo afiliado** | `GRID-17` desbloqueado. No hace falta ningún dato nuevo: el agregado de filtros ya lo calcula |
| **¿Qué son «Número autorizado» y «Detalle del servicio»?** | Son el **código de autorización** y la **clase de servicio** | `LIN-11` y `LIN-14` **cerrados sin trabajo**: el documento los enumera dos veces con dos nombres y los dos ya se pintan |
| **¿«Liquidar» es el submit?** | Sí: es nuestro **«Enviar»** | `BTN-08` **cerrado**. Se conserva el rótulo «Enviar», que es el lenguaje del proyecto |
| **¿Qué es una «versión» de la CM?** | Una fila de **`ctrclaims`** por `(code, version)` con `reversal=false` | `BUS-13` `BUS-20` `BTN-04` `VIS-11` desbloqueados. Ver el recuadro de abajo |
| **La respuesta a glosa** | Por ahora **solo se lee** | `VIS-09` y `VIS-10` fuera. Leerla sigue dentro (`VIS-08`, `DBG-13`) |
| **¿Beneficios aplicados y alta/baja de líneas?** | Se quitan de las aplicaciones | `BTN-07` y `DBG-09` fuera |

> ### Qué es una versión, en una frase que se puede programar
>
> **Una fila de `ctrclaims` identificada por `(code, version)` con `reversal.eq(false)`.** No es el
> `objectVersionNumber`, que es el contador de bloqueo optimista y es —confusamente— lo que la
> pantalla rotula hoy como «Versión».
>
> No hay que redescubrirlo: está verificado contra producción en `pagos-cuenta-transmitida-java`, y
> de ahí salen cuatro reglas que ahorran días de tropiezos.
>
> - **`reversal.eq(false)` es obligatorio.** Cada versión tiene una gemela de reverso que repite sus
>   sellos con otros identificadores; sin el predicado todo se cuenta por duplicado.
> - **El estado de cada versión vive en `ctrStatusHistoryList`** (status + fecha), y **la fecha que
>   cuenta es la de entrada al estado**, no la del último sello: el proceso vuelve a sellar la misma
>   transmisión durante días.
> - **`code.in(...)` sí funciona en `ctrclaims`** —a diferencia de `claim.in(...)`—, así que las
>   versiones de varias cuentas se piden en lotes y no una por una.
> - **En `ctrclaims` se pagina por keyset, no por desplazamiento**: es una tabla global que se mueve,
>   y ahí el desplazamiento sí se salta filas. (Lo contrario que en las líneas de una cuenta.)

---

## Qué NO entra, y por qué

### Excluido por el encargo o retirado por decisión (41 requisitos sin cumplir)

- **Bloque de alertas y trazabilidad** (14): opcional en el documento.
- **Siete criterios del buscador**: opcionales en el documento.
- **Reemplazo masivo** (10): el bloque entero, excluido por el encargo.
- **Enlace P8 a los soportes** (`ENC-24`): opcional, no prioritario. Cuando se retome es trabajo de
  horas: la plantilla de la URL ya está en la configuración de OHI, busca por número de factura.
- **La botonera superior y la pestaña de mensajes** (`BTN-01` `BTN-09` `BTN-10` `VIS-06`, y con ellos
  `BTN-02`): lo que esas tareas cambiaban era **el sitio, no la capacidad**. Las acciones existen y
  son accionables, y los mensajes de cabecera se ven y se editan donde están. `BTN-02` cae con la
  botonera y además no tiene dato: no hay convenio a nivel de cuenta, solo de línea. `BTN-03`
  (desfinalizar con motivos) **no sale: se cierra como cumplido** — funcionalmente ya estaba
  completo y lo único que le faltaba era el sitio.
- **Capturar la respuesta a glosa** (`VIS-09` `VIS-10`): por ahora solo se lee.
- **Beneficios aplicados y alta/baja de líneas** (`BTN-07` `DBG-09`): se quitan de las aplicaciones.
  Lo segundo coincide con la decisión de diseño que ya estaba escrita: en auditoría no se borra, se
  resuelve o se devuelve.

### Bloqueado: queda **una** pregunta, y vale por cuatro requisitos

| Pregunta | Bloquea | Quién responde |
|---|---|---|
| **¿Qué es «convenido» y qué es «autorizado»?** La pantalla de OHI rotula `allowedAmount` como *convenido* y `coveredAmount` como *autorizado*; el servicio y nuestra pantalla hacen lo contrario, y hay un tercer «valor convenido» que sale de las cláusulas de tarifación. Pegada a ella: **¿de dónde sale el «Total convenido» de la cabecera?**, que OHI no publica y hoy sale con un guion en todas las cuentas | `GRID-10` `GRID-11` `LIN-08` `ENC-12` | Negocio, con el equipo de OHI |

**Es la pregunta urgente del plan**, y no solo por los cuatro requisitos: **contamina las columnas de
importes que ya existen**. La entrega 2 añade cinco columnas más de valores; si se hace antes de
cerrar esto, se multiplica un error de rótulos en vez de corregirlo. Conviene responderla antes de la
tarea 2.2.

---

## Entrega 1 — Lo barato que se ve el primer día

`ENC-01` `ENC-16` `ENC-23` `VIS-02` `VIS-04` `VIS-07`

Nada aquí es difícil y todo se nota al abrir una cuenta. Sirve además para rodar el ciclo de SDD con
requisitos pequeños antes de meterse en lo grande.

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 1.1 | Resolver la **razón social** del prestador de facturación y del de pago en la cabecera | backend · `acl-ohi` + `web-reactiva` | — | La cabecera trae nombre además de NIT. `AdaptadorPrestadoresOhi.nombresPorCodigo` ya resuelve por lote y con caché: hoy solo se invoca para la línea, hay que cablearlo a la cabecera |
| 1.2 | Pintar prestador y pagar-a como «Nombre · NIT» | front · `cuenta-detalle` | 1.1 | `ENC-01` y `ENC-23` en verde. En el de pago es donde más se nota: su valor está en detectar que quien cobra no es quien factura, y dos NIT no se comparan a ojo |
| 1.3 | Comprobar que «Tipo de servicio» del documento es `claseServicio` y pintarlo | backend + front | — | `ENC-16` en verde, o convertido en pregunta a negocio si no coinciden |
| 1.4 | **Contadores en el rótulo de las pestañas** | front · `cuenta-detalle` | — | «Líneas (4063)», «Pendientes (7)», «Mensajes (3)». Los tres números ya viajan: es pintarlos |

---

## Entrega 2 — La grilla: columnas, orden y filtros

`GRID-08` `GRID-09` `GRID-13` `GRID-15` `GRID-16` `GRID-17` · `F3-ORD-00` a `F3-ORD-08` ·
`F3-FIL-01` · `F3-CNT-01` `F3-CNT-03`

La entrega con más requisitos y la que más cambia el día del auditor. **Empieza por una decisión de
diseño, no por código**: la grilla ya va con scroll horizontal con 10 columnas y el documento pide 17.

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 2.0 | **Diseño de la grilla con 17 campos**: celdas de dos renglones, columnas plegables o una vista «importes» aparte | front · diseño | — | Hay una maqueta acordada. Ayuda el mono usuario (2.6): en la práctica libera dos columnas casi siempre |
| 2.1 | Ensanchar la proyección de la línea: `claimedAmount`, `claimedNumberOfUnits`, `allowedNumberOfUnits`, `montoIVACalculado`, `porcentajeIVA` | backend · `acl-ohi` → `dominio` → `web-reactiva` | — | Los cinco campos viajan en el resumen. Los cinco existen en OHI y están medidos; el IVA no estaba porque nunca se pidió |
| 2.2 | Pintar las cinco columnas | front · `lineas-list` | 2.0, 2.1 | `GRID-08` `GRID-09` `GRID-13` `GRID-15` `GRID-16` en verde. **Antes hay que cerrar la pregunta de convenido/autorizado**, o se añaden columnas con el rótulo cruzado |
| 2.3 | **Parámetro de orden** en `GET /lineas` (campo + sentido) con lista blanca | backend · `web-reactiva` → `dominio` → `acl-ohi` | — | Seis campos se resuelven en el `orderBy` de OHI: `sequence`, `person.code`, `startDate`, `authorizationCode`, `procedure.code` y `valorGlosado`. Medido que ordenan y que se combinan con el desplazamiento |
| 2.4 | **Valor cargado**: el séptimo campo, que OHI no sabe ordenar | backend · `acl-ohi` | 2.1, 2.3 | Ordenar por `claimedAmount` da **500** en OHI (medido, igual que los otros importes). Se resuelve trayendo y ordenando aquí, y en ese régimen la página sale **sin total**, que la pantalla ya sabe representar |
| 2.5 | Cabeceras ordenables en la grilla | front · `lineas-list` | 2.3 | `F3-ORD-00` a `F3-ORD-08` en verde. `F3-ORD-08` sale gratis: el orden viaja al servidor, así que alcanza toda la paginación |
| 2.6 | **Mono usuario**: ocultar cédula y nombre cuando todas las líneas comparten afiliado | front · `lineas-list` | 2.0 | `GRID-17` en verde. El dato ya se calcula en el agregado de filtros. Ojo al efecto medido: de 40 cuentas de producción revisadas ninguna tenía más de un afiliado, así que **las dos columnas quedarán ocultas casi siempre** |
| 2.7 | Filtro por **secuencia** y empujar el de **valor glosado** a OHI | backend · `dominio` + `acl-ohi` | — | `F3-FIL-01` en verde, y el filtro de glosa recupera el total: `valorGlosado` **sí** se filtra en OHI aunque su metadato diga que no (medido: 212 → 50 → 20 → 0 según el umbral) |
| 2.8 | Contador de resultados en el paginador, también sin total | front · `lineas-list` | 2.7 | `F3-CNT-01` y `F3-CNT-03` en verde |

---

## Entrega 3 — Del motivo a la línea

`F2-04` `F2-05` `F2-06` `F2-11` · `F3-NOV-01` `F3-NOV-02`

El auditor no persigue líneas: persigue causas. Hoy ve el motivo y no puede saltar a las líneas que lo
tienen. **Hay una trampa de OHI medida que define toda la entrega**: filtrar las líneas por su
colección hija devuelve la cuenta entera (212 de 212 cuando el mensaje está en 199). Hay que ir por el
recurso hijo y volver con `id.in(...)`.

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 3.1 | Consulta en dos pasos: del motivo / del mensaje a los `claimLine.id`, y de ahí a las líneas | backend · `acl-ohi` | — | Devuelve exactamente las líneas afectadas. Partir en lotes: `id.in(...)` con cientos de identificadores no cabe en un cuerpo |
| 3.2 | Criterios nuevos en el filtro de líneas: `motivoPendiente`, `soloBloqueantes`, `conNovedad` | backend · `dominio` + `web-reactiva` | 3.1 | `F2-06` y `F3-NOV-01` en verde |
| 3.3 | Enlace «ver las N líneas afectadas» desde el motivo | front · `pendientes-list` → `lineas-list` | 3.2 | `F2-04` y `F2-05` en verde, sin el tope de páginas encadenadas de hoy |
| 3.4 | Breve detalle de la novedad en la fila de la grilla | front · `lineas-list` | 3.2 | `F3-NOV-02` en verde |
| 3.5 | Marca de bloqueante en los pendientes **de la línea** | backend + front | — | `F2-11` en verde. El veredicto depende del par motivo-estado, que hoy solo se evalúa en la pantalla de pendientes |

---

## Entrega 4 — Selección múltiple y acciones masivas

`DBG-01` `DBG-02` `DBG-04` `DBG-05` `DBG-06` `DBG-07` `DBG-08` `DBG-11` · `F2-12` · `F3-CNT-02`

**Aquí se empieza a escribir en producción sobre muchas filas a la vez.** La nota crítica del documento
—«no se debe quedar solo en las líneas de la página consultada»— significa que la selección tiene que
poder ser *todas las que cumplen el filtro*, no solo las 25 a la vista. Sobre una cuenta de 4.063
líneas eso es una operación que toca miles de filas.

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 4.1 | Selección en la grilla: casilla por fila, casilla de cabecera y **«seleccionar las N que cumplen el filtro»** | front · `lineas-list` | Entrega 2 | `DBG-01` y `F3-CNT-02` en verde, con el contador de seleccionadas a la vista |
| 4.2 | Barra de acciones sobre la selección | front · `lineas-list` | 4.1 | `DBG-08` en verde |
| 4.3 | **Aplicar una glosa a la selección** | backend (endpoint + caso de uso) + front | 4.1 | `DBG-02` en verde. Valida editabilidad y versión de cada línea y devuelve el fallo parcial legible |
| 4.4 | **Añadir y quitar mensajes** sobre la selección | backend + front | 4.1 | `DBG-06` y `DBG-07` en verde. El contrato de novedades por línea ya existe; falta el alcance múltiple |
| 4.5 | **Añadir motivo de pendiente** sobre la selección | backend + front + catálogo | 4.1 | `DBG-05` en verde. Necesita publicar el catálogo de motivos **de pendiente**: el de hoy, `/catalogos/motivos`, es el de desfinalización |
| 4.6 | Acotar **resolver pendiente** y **desbloquear líneas** a la selección | backend (ya soportado) + front | 4.1 | `F2-12`, `DBG-04` y `DBG-11` en verde. El campo de líneas ya existe en los dos requests: es trabajo de pantalla |

**Frenos obligatorios de esta entrega**: inventario previo de lo que se va a tocar, piloto de una línea
antes del lote, corte automático tras N fallos seguidos, registro llamada a llamada y **confirmación
humana con el alcance real a la vista** («va a glosar 1.847 líneas»).

---

## Entrega 5 — Edición en línea sobre la grilla

`GRID-18`

Un solo requisito, y es el más caro del MVP: *«estos campos se deben dejar editar sin que se abra toda
la línea y guardar los cambios»*. Va después de la 2 (necesita las columnas) y después de la 4 (para no
rehacer la grilla dos veces).

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 5.1 | Llevar al resumen los campos editables: valor y unidades cargadas, autorizadas y glosado | backend | Entrega 2 | Viajan en el resumen con su `version` |
| 5.2 | Celdas editables con un formulario por fila | front · `lineas-list` | 5.1 | Se edita sin navegar |
| 5.3 | Guardado por fila contra el PATCH que ya existe | front | 5.2 | Manda `versionEsperada`; un conflicto se resuelve en la fila, no recargando la pantalla |
| 5.4 | Recálculo y refresco de la fila | front + backend | 5.3 | Lo que el motor recalcula vuelve a la fila. `valorGlosado` es la suma de los detalles y **OHI no lo recalcula**: no se teclea suelto |

---

## Entrega 6 — Respuesta a glosa, historia, notas y detalle de glosa

`VIS-05` `VIS-08` `VIS-11` `DBG-13` · `BTN-05` `BTN-06` · `PES-06` `PES-09`

Todo lectura. Se puede intercalar donde haya hueco.

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 6.1 | **Pestaña «Respuesta glosa»** (solo lectura) | backend · `acl-ohi` + `web-reactiva` · front | — | `VIS-08` y `DBG-13` en verde. Medido: `claims.respuestaGlosa` existe y está poblada, con fecha de llegada, secuencia, valor y vencimiento |
| 6.2 | Columna **«versión que abrió»** en esa pestaña | backend (mismo payload) + front | 6.1 | `VIS-11` en verde. El dato viene en la misma respuesta, en `versionamiento` (medido: valores como «CM-94421-V4»): no hace falta consultar `ctrclaims` para esto |
| 6.3 | **Notas**: lectura y alta desde la cabecera | backend (falta el GET) + front | — | `BTN-05` en verde. Hoy solo hay escritura interna, como rastro de la resolución de pendientes |
| 6.4 | **Historia**: cambios de estado y motivos de desfinalización | backend · `acl-ohi` + front | — | `BTN-06` en verde. `claimstatushistory` está disponible y es de solo lectura: 2,6 millones de filas, ~9,6 cambios por cuenta |
| 6.5 | Ver los motivos de pendiente **ya resueltos** | backend (parámetro) + front | — | `VIS-05` en verde |
| 6.6 | **Código de glosa** y **valor de nota crédito** en el detalle de glosa de la línea | backend · proyección + DTO · front | — | `PES-06` y `PES-09` en verde. Hoy el auditor escribe un causal y al guardar deja de verlo |

---

## Entrega 7 — Buscador de facturas y versiones · vía paralela

`BUS-01` `BUS-02` `BUS-03` `BUS-05` `BUS-12` `BUS-13` `BUS-14` `BUS-15` `BUS-16` `BUS-17` `BUS-18`
`BUS-19` `BUS-20` · `BTN-04`

El documento la llama «la pantalla principal». Con la definición de versión cerrada, entra completa.

### Qué hay y qué falta de verdad

Conviene ser preciso, porque «backend nuevo + pantalla nueva» —como decía la versión anterior de este
plan— se lee peor de lo que es.

**En el backend no hay un servicio nuevo: hay un endpoint nuevo**, y es el primero de colección sobre
cuentas. Las quince rutas actuales cuelgan de `/cuentas/{codigo}` o de `/catalogos`, y las tres que
devuelven colección —líneas, pendientes, novedades— están anidadas bajo una cuenta que ya conoces. En
el puerto de consulta pasa lo mismo: de sus nueve operaciones, ocho reciben un `CodigoCuenta` y la
novena, `buscarPorCodigo`, devuelve una. **Nadie sabe preguntar «¿qué cuentas cumplen esto?».**

Lo que hay que escribir es: un método de puerto, un caso de uso, un manejador con su ruta y dos DTO.
Lo que se reutiliza tal cual es casi todo lo demás —el cliente de OHI con su resiliencia y su token,
el constructor de consultas, el sobre de búsqueda con desplazamiento, el traductor de cuenta, el
resolutor de nombres de prestador y el modelo de página que ya usan las líneas—.

**En el frontend la pantalla existe**: `cuenta-busqueda` son 50 líneas de TypeScript y 48 de plantilla,
con su ruta, su estilo y su sitio en el `facade`. Lo que pasa es que **no es un buscador**: es un campo
de texto que, en cuanto llega la cuenta, navega al detalle. No tiene formulario de criterios ni grilla
de resultados, y tampoco hay caso de uso de listar cuentas —hay quince casos de uso y ninguno es ese—.
Así que no se crea una pantalla: se convierte la que hay en lo que el documento pide.

**«Vía paralela» no significa que no comparta nada**: reutiliza el modelo de paginación por
desplazamiento y necesita el nombre del prestador de la tarea 1.1. Significa que **no toca ningún
fichero de las otras seis entregas**, que es lo que de verdad permite que dos personas avancen sin
pisarse.

| # | Tarea | Repo · módulo | Depende de | Listo cuando |
|---|---|---|---|---|
| 7.0 | **Congelar el contrato** del endpoint de colección y del de versiones | backend · diseño | — | Escrito y acordado antes de que las dos orillas empiecen. Sin contrato congelado, paralelizar garantiza reproceso |
| 7.1 | `GET /api/v1/cuentas` paginado **por desplazamiento** | backend · `dominio` + `acl-ohi` + `web-reactiva` | 7.0 | Devuelve página con total. **Filtra `processType.eq('C')` o salen también las reservas, que son el 73 % de las filas** |
| 7.2 | Criterios: número de factura y radicado | backend | 7.1 | `BUS-03` y `BUS-05` en verde. Medido: `numeroFactura` filtra en `claims` |
| 7.3 | Columnas del resultado: radicado, fecha de llegada, factura, prestador con nombre, valor y estado | backend · proyección + DTO | 7.1, tarea 1.1 | `BUS-14` a `BUS-18` en verde |
| 7.4 | **Vocabulario de estados** legible | backend · diccionario + catálogo | 7.1 | `BUS-19` en verde. Ojo: «Pendiente», que el documento lista como estado, **no lo es**; y el mismo estado se escribe de tres formas según dónde se mire |
| 7.5 | Pantalla de búsqueda con su grilla de resultados | front · pantalla nueva | 7.0 | `BUS-01`, `BUS-02` y `BUS-12` en verde. Deja de rebotar al detalle: muestra resultados |
| 7.6 | **Adaptador de versiones**: leer `ctrclaims` por `code.in(...)` con `reversal.eq(false)`, paginado **por keyset** | backend · `acl-ohi` | 7.0 | Devuelve las versiones de cada cuenta con su estado y su fecha de entrada. Las cuatro reglas del recuadro de arriba son el contrato: respetarlas es la tarea |
| 7.7 | Versiones bajo cada factura en los resultados | backend DTO + front | 7.2, 7.6 | `BUS-13` en verde. Son dos pasos: `claims` por factura da los códigos —en `ctrclaims` ese campo no es filtrable— y `ctrclaims` por `code.in(...)` da las versiones |
| 7.8 | **Seleccionar una versión y consultarla** | backend (endpoint por versión) + front | 7.6, 7.7 | `BUS-20` en verde. «Consultar una versión» es abrir su foto: cabecera e importes de `ctrclaims` y, si se quiere el detalle, sus líneas de `ctrclaimlines`. No es la cuenta viva |
| 7.9 | **Versión vigente en la cabecera** de la vista 360 | backend + front | 7.6 | `BTN-04` en verde: la mayor `version` con `reversal=false`, como campo distinto del `objectVersionNumber`. Y **renombrar el rótulo «Versión» que hay hoy**, que es el contador de bloqueo optimista y se lee como si fuera esto |

---

## Orden de despliegue

**Siempre el backend primero, y en todas las entregas es compatible hacia atrás**: lo que se añade son
campos nuevos en respuestas existentes, criterios nuevos opcionales y endpoints nuevos. Ninguna
entrega quita ni renombra nada del contrato, así que el front viejo sigue funcionando contra el
backend nuevo.

Tres excepciones que hay que vigilar:

- **Entrega 7**: el contrato es nuevo entero. Se congela en 7.0 antes de que nadie programe.
- **Entrega 2, tarea 2.4**: cuando se ordena por valor cargado la página llega **sin total**. No es
  incompatible —la pantalla ya sabe vivir sin total— pero es un régimen que hay que probar antes de
  soltarlo.
- **Tarea 7.9**: renombrar el rótulo «Versión» de la cabecera es el único cambio visible que puede
  desconcertar a quien ya usa la pantalla. Conviene avisarlo, no colarlo.

## Riesgos y frenos

| Riesgo | Freno |
|---|---|
| **Las acciones masivas tocan miles de líneas de producción** y no se deshacen | Inventario, piloto de una, corte tras N fallos, registro y confirmación humana con el alcance a la vista. Sin las cinco, la entrega 4 no sale |
| **«Convenido» y «autorizado» están cruzados** respecto de OHI, y la entrega 2 añade cinco columnas de importes | Cerrar la pregunta **antes** de la tarea 2.2. Es la única que queda y es la que más daño hace si se posterga |
| **La grilla no da más de sí**: 10 columnas y ya hay scroll horizontal; el documento pide 17 | La tarea 2.0 es una decisión de diseño con maqueta acordada, y es lo primero de la entrega. El mono usuario ayuda: libera dos columnas casi siempre |
| **Contar las versiones por duplicado** al leer `ctrclaims` | `reversal.eq(false)` en todas las consultas, y una prueba que lo fije. Es el error clásico de esa tabla y ya costó una vez |
| **Paginar `ctrclaims` por desplazamiento** | Ahí va por keyset: es una tabla global que se mueve. Lo contrario que en las líneas de una cuenta, y por eso se confunde |
| **OHI devuelve el dato equivocado con HTTP 200** en varias formas ya medidas | Las pruebas de adaptador cubren los seis casos obligatorios, incluidos el 204 y el campo ausente. El trinquete de Jacoco no baja |
| **`id.in(...)` con cientos de identificadores** en la entrega 3 | Partir en lotes y probar con el motivo más grande de una cuenta real, no con tres filas |
| **Un requisito se da por hecho sin nada que lo sostenga** | `python3 especificacion/trazabilidad.py` antes de cerrar cada entrega |

## Definición de terminado

Por tarea, además de lo que diga la tarea:

> Estas tres son del ciclo de SDD y no se negocian: la prueba **cita el `id`** del requisito, el
> `estado` del requisito está actualizado en el YAML, y `python3 especificacion/trazabilidad.py` pasa.

- [ ] Los criterios de aceptación del requisito existen **antes** de escribir código
- [ ] Sin `.block()` en el camino de petición
- [ ] Colecciones nuevas paginadas por desplazamiento (`pagina` + `tamano`), salvo `ctrclaims`, que va por keyset
- [ ] DTO nombrados `Solicitud*` / `Respuesta*` y fuera del dominio
- [ ] Todo en español; ningún tipo `Ohi*` escapado de `acl/ohi/externo`
- [ ] Prueba nueva con JUnit 5 que **falla sin el cambio** y pasa con él
- [ ] Integración con Mockito sobre la `ExchangeFunction`; reactivo con `StepVerifier`
- [ ] Caso de vacío (204) y de error cubiertos
- [ ] El mínimo de Jacoco del módulo tocado no bajó
- [ ] Sin secretos fuera de `.env`
- [ ] `./gradlew check` y `npx nx lint && nx test` en verde

## Lo primero que haría yo

1. **Hacer la pregunta que queda** —convenido y autorizado— antes de la tarea 2.2. Es una reunión y
   libera cuatro requisitos, pero sobre todo evita multiplicar un error de rótulos por cinco columnas.
2. **Arrancar la entrega 1**: no depende de nada y se nota al día siguiente.
3. **Poner a la segunda persona en la entrega 7** desde el primer día, empezando por congelar el
   contrato.
4. **Decidir si el buscador lleva los siete criterios opcionales.** Sigue siendo la decisión de alcance
   con mejor relación valor/coste del plan: el endpoint nace preparado para los nueve y cada criterio
   que falte después es un parámetro y un control.
