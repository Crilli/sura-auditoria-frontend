# Contexto 05 — OHI: lo que devuelve mal sin dar error

Oracle Health Insurance en producción: `https://prod.sura.ohi.ocs.oraclecloud.com/prod/claims/api`
(`X-Ohi-App-Id: CLA`, `X-Ohi-App-Version: 4.25.1.0.23`).

**Léelo entero antes de tocar `:infraestructura-acl-ohi`.** Casi todo lo que sigue produce una
respuesta *incorrecta* con HTTP 200 — no una excepción. Son fallos que pasan la revisión de código,
pasan el despliegue y aparecen semanas después como un reporte que no cuadra.

La documentación larga está en `ms-auditoria-cuenta-medica/docs/ohi/` (7 documentos + 4 anexos
generados del propio API). Esto es el resumen operativo.

## OHI se autodescribe

No hay que adivinar nada. Seis endpoints publican el modelo completo:

```
GET /generic                          catálogo de recursos (453 en prod)
GET /generic/<recurso>/definition     esquema con los x-oi-* y los $ref
GET /generic/<recurso>/metadata       el OpenAPI 3.0.1 del recurso — dice los VERBOS reales
GET /specific                         endpoints de operación de negocio
GET /currentproperties                propiedades vigentes del entorno
GET /outboundintegrationpoints        puntos salientes con sus URLs y auth
```

Antes de preguntar "¿se puede filtrar por X?" o "¿existe DELETE aquí?", consúltalo. Es más rápido que
discutirlo.

## Las trampas

### 1. El sobre `{"resource":{...}}` es obligatorio

Sin él, `/search` responde **204 con cuerpo vacío**: interpreta que no se pidió nada. Es lo primero que
comprobar cuando una consulta que debería traer miles de filas vuelve vacía. La proyección va en el
hermano `resourceRepresentation`.

### 2. `defaultoverride` o la proyección se ignora

Sin `defaultoverride: "true"`, OHI **ignora `fields`** y devuelve la representación por defecto: campos
como `numeroFactura` o `cufe` llegan **nulos aunque tengan valor**. Acelera además entre 10× y 19×,
a cambio de borrar los links de acciones.

### 3. OHI no valida los nombres de `fields`

Un campo mal escrito da **HTTP 200 con la columna ausente** y ningún error. Cualquier cambio en una
proyección hay que comprobarlo mirando que el dato llegue, no que la llamada no falle.

### 4. El tope de 200 trunca y calla

Devuelve 200 filas y no dice que hay más (medido: 3.507 pendientes donde se veían 203). La única
paginación correcta es **keyset**: `id.gt(cursor)` con `orderBy: id asc`, y los dos campos deben
coincidir. Offset no sirve: un alta por debajo del cursor desplaza la ventana y salta filas.

### 5. `groupBy` devuelve etiquetas; `q` filtra por el código almacenado

El mismo campo se ve de dos formas y solo una sirve para filtrar:

| campo | en `q` | en `groupBy` |
|---|---|---|
| `claims.status` | `FINALIZED`, `MANUAL ADJUDICATION` (¡con espacio!) | `Finalized`, `ManualAdjudication` |
| `claims.processType` | `C` / `R` | `Claim` / `Reservation` |
| `claims.processCategory` | `L` / `S` | `LargeClaimSystem` / `SubClaim` |
| `tasks.status` | `ERRORED`, `COMPLETE` | `Errored`, `Complete` |

Y en `ctrclaims` el `processType` de reserva es **`A`**, no `R`.

### 6. `neq` descarta los nulos

Aunque Oracle los llame «null-safe». Medido: `processCategory.neq('L')` → **305** filas de ~276.100;
`.eq(null)` → 275.730. Es decir, `neq` devuelve el 0,1 % de lo que uno cree pedir.

### 7. Un booleano filtrado con `"Y"` no filtra: devuelve el conjunto entero

Se filtran con `true`/`false` **sin comillas**; cualquier cadena se convierte a `false` en silencio.
Medido sobre `pendreasons.autoResolve`: `eq(true)`→23, `eq("Y")`→210, `eq("N")`→210 (iguales).

Y medido de nuevo el 2026-10-16 sobre `claimlines.locked` en una cuenta de 212 líneas cuyas filas
traen todas `locked: false`:

```
claim.id.eq(X).and.locked.eq('N')  → 212
claim.id.eq(X).and.locked.eq('Y')  → 212
```

Las dos devuelven **todo**. No es que dé el conjunto contrario: **el predicado se ignora**. Da igual
`locked`, `replaced` o `resolved`. Si necesitas «solo las bloqueadas», tráetelas y descarta en cliente.

Excepción: en `ctrclaims`/`ctrclaimlines` los indicadores **sí** son cadenas `"Y"`/`"N"`.

### 8. Dinámico ≠ no filtrable, y varía por recurso

`x-oi-dynamic` dice la clase de campo; **`x-oi-searchable` dice si entra en `q`**, y no van juntos.
El mismo campo cambia según el recurso:

| campo | en `claims` | en `ctrclaims` |
|---|---|---|
| `numeroFactura` | `searchable: true` → se filtra | `searchable: false` → solo se proyecta |

La clase **`DYNR`** (p. ej. la colección `estadoCuentaMedica`) no se filtra nunca: se proyecta y se
filtra en cliente. Consulta el `/definition` **del recurso concreto** antes de asumir.

Y hay falsos negativos: **`x-oi-searchable` puede decir `no` sobre un campo que sí filtra**. Medido el
2026-10-16 sobre `claimlines.valorGlosado`, que el `/definition` declara no filtrable:

```
valorGlosado.gte(0)          → 212     valorGlosado.gte(100000)   → 50
valorGlosado.gte(571294)     →  20     valorGlosado.gte(999999999)→ 204
```

Discrimina sin un fallo, y además **ordena** (`orderBy valorGlosado desc` empieza en 571.294). O sea:
el atributo sirve para descartar, no para dar por imposible. Si un campo dice `no` y lo necesitas,
**pruébalo**: cuesta una consulta.

### 9. Filtrar por una colección hija devuelve la cuenta entera

Parece que funciona y es de los peores: un 200 con el dato equivocado. Medido sobre una cuenta de
212 líneas en la que el mensaje `SURA-CHK-065` está en 199:

```
/generic/claimlines/search
q = claim.id.eq(X).and.claimLineMessageList.message.code.eq('SURA-CHK-065')   → 212 líneas
```

Devuelve **todas** las líneas de la cuenta, no las 199 que tienen el mensaje. Y con un código
inexistente devuelve 204, así que parece que discrimina. Lo mismo con `claimLinePendReasonList`.

La vía que sí da el conjunto correcto son dos consultas, por el recurso hijo y de vuelta:

```
/generic/claimlinemessages/search   q=claimLine.claim.id.eq(X).and.message.code.eq('SURA-CHK-065')
                                    fields=claimLine.id              → 199 líneas distintas
/generic/claimlines/search          q=id.in('…','…')  orderBy=sequence asc
```

Es el patrón que ya usa la ACL para traer pendientes y novedades por lote.

### 10. En `q` los nombres **sí** se validan; en `fields` no

Un campo inventado en `q` da **500 GEN-PROC-ERR**. El mismo campo inventado en `fields` llega
ausente con 200 y sin aviso (trampa 3). Conviene saberlo: si una consulta con filtro responde 500
hablando del campo, probablemente el campo está mal escrito y no es un problema del dato.

### 11. Un 204 es cero coincidencias, no un error

Resultado vacío en OHI es **HTTP 204 con cuerpo vacío**, no un 200 con `items: []`. Tradúcelo a
"ninguna coincidencia", nunca a fallo.

### 12. Los importes no se pueden ordenar

`orderBy` sobre un campo de tipo «monto» (importe + moneda) da **500 GEN-ORA-ERR**. Medido sobre
`claimlines`: `claimedAmount`, `allowedAmount` y `coveredAmount` fallan; `sequence`, `person.code`,
`startDate`, `authorizationCode`, `procedure.code` y **`valorGlosado`** ordenan bien.

`valorGlosado` es la excepción útil: es una extensión de Sura de tipo número, así que **sí** se
ordena y **sí** se filtra (`gte`, `bet`). Si hace falta ordenar por valor cargado, hay que traer y
ordenar en cliente — y entonces el total deja de ser fiable.

### 13. `creationDate` no se puede filtrar

HTTP 500 con un `ParseException`. Para "creado en el mes" hay que filtrar por `entryDate`, ensanchar
la ventana y recortar en cliente. Operadores válidos: `gte, lte, gt, lt, eq, in, like`.
**`ge`, `le` y `ne` dan 500** con un error que parece del campo y es del operador.

## Al cerrar el cliente HTTP

`HttpClient.close()` espera a que se cierren todas las conexiones del pool, y si alguna queda a medias
esa espera se va a **minutos**. Si el cierre está en un try-with-resources que termina antes de
escribir el resultado, el proceso parece colgado justo después de acabar: sin archivo, sin error y sin
nada en el log. Ocurrió de verdad el 2026-09-27.

El remedio, ya aplicado en los clientes de escritorio del ecosistema: `shutdownNow()` para cancelar lo
que quede en vuelo, cerrar en un hilo **demonio** aparte y esperarlo con un tope de 10 s, dejando la
limpieza en segundo plano y registrando un `warn` si no acaba.

## Escritura: el contrato real

- El camino de escritura de líneas es **`/claimsupdate`**, no `/generic/claimlines`. La colección se
  llama `claimLineList`; mandar `claimLines` **no aplica nada** y no da error.
- Mover a modificable: `POST /claims/{id}/tochange` → 303 y la cuenta pasa a `CHANGE`. **No funciona
  desde `IN PROCESS`** (devuelve 409), ni desde `CHANGE` (ya está).
- Resolver pendientes **no** saca la cuenta de `CHANGE`; solo `submit` finaliza.
- Resolución masiva nativa: `/claims/resolvependreasons` (201 + `Location`), ~5 s. Lee con cuidado los
  fallos parciales.
