# Contexto 09 — SDD: la especificación manda

> Cómo se trabaja en este ecosistema desde el 2026-10-16. No es una metodología importada: es la
> consecuencia de tener ya escrita la especificación del MVP y querer que sirva para algo más que
> para leerla.

## El problema que resuelve

Antes de esto, cada encargo traía sus propios criterios de aceptación en su propio
`entregables/<feature>/01-analisis.md`. Funcionaba, pero deja tres agujeros que en este ecosistema
cuestan caro:

1. **Nadie sabía cuánto falta.** Había 196 requisitos repartidos en un PDF y ninguna forma de
   preguntar «¿cuántos cumplimos?» sin volver a leerlo entero.
2. **«Esto ya está» no se podía comprobar.** La mitad de los defectos de este dominio son un 200 con
   el dato equivocado: un campo que dejó de llegar no rompe nada, solo desaparece de la pantalla. Sin
   una prueba atada al requisito, «cumple» es una opinión con fecha de caducidad.
3. **El trabajo sin requisito no se distinguía del trabajo con requisito.** Y en un MVP con alcance
   cerrado, eso es lo que se come el calendario.

SDD aquí significa una cosa concreta: **la especificación es un fichero, tiene identificadores, y
todo lo demás —el diseño, el código, las pruebas, el estado— cuelga de ellos.**

## La fuente de verdad

```
agents/ecosistema-auditoria/
├── especificacion/
│   ├── mvp-cuentas-medicas.yaml   ← LA FUENTE DE VERDAD. Se edita a mano.
│   ├── consultar.py               ← pregúntale a la especificación (lo primero de cualquier encargo)
│   ├── trazabilidad.py            ← comprueba que el código y la especificación se corresponden
│   └── generar_catalogo.py        ← rehace el catálogo legible desde el YAML
└── contexto/
    ├── 07-mvp-cuentas-medicas.md  el veredicto y las decisiones abiertas (se escribe a mano)
    └── 08-mvp-requisitos.md       el catálogo legible — SE GENERA del YAML, no se edita
```

Lo primero ante cualquier encargo es situarlo:

```bash
python3 especificacion/consultar.py glosa          # ¿de qué requisitos me están hablando?
python3 especificacion/consultar.py F3-ORD-02      # uno entero, con sus criterios y su riesgo
python3 especificacion/consultar.py --pendientes   # qué falta, por bloque
python3 especificacion/consultar.py --bloqueados   # qué espera una decisión de negocio
```

Cada requisito del YAML es así:

```yaml
- id: F3-ORD-02
  bloque: filtros
  requisito: Ordenamiento por el campo Cédula afiliado.
  obligatorio: true
  estado: NO_CUMPLE
  falta: "No existe el mecanismo de ordenamiento…"
  riesgo_ohi: "person.code sí se ordena en OHI (medido)…"
  criterios:
    - id: F3-ORD-02.1
      dado: "…"
      cuando: "…"
      entonces: "…"
      nivel: integracion
```

El `id` es lo único que no se cambia nunca. Todo lo demás se corrige cuando el repo o el negocio
digan otra cosa.

## El ciclo

```
   requisito del YAML  (id + criterios de aceptación)
          │
          ▼
   1. ¿tiene criterios?  ─── no ──►  escríbelos ANTES de diseñar. Si no se pueden escribir
          │ sí                       porque falta una decisión de negocio, el requisito queda
          ▼                          bloqueado y se pregunta. No se programa a ciegas.
   2. diseño e implementación        (las cinco fases de siempre, ver el agente)
          │
          ▼
   3. prueba que CITA el id          @Tag("F3-ORD-02")  ·  it('[F3-ORD-02] …')
          │
          ▼
   4. actualizar `estado` en el YAML y regenerar el catálogo
          │
          ▼
   5. python3 especificacion/trazabilidad.py   ─── falla ──►  no está terminado
```

El paso 3 no es burocracia: es lo que convierte el requisito en algo que el build defiende. Una
prueba sin identificador sigue siendo una buena prueba —hay 75 ficheros de pruebas y casi ninguno lo
lleva—, pero **un requisito en CUMPLE sin ninguna prueba que lo cite es una afirmación que nadie
sostiene**.

## Cómo se cita un requisito

Dos formas, una por lenguaje, y las dos dejan el identificador en el texto del fichero:

```java
@Test
@Tag("F3-ORD-01")
@DisplayName("ordena por sequence, nunca por id: es el orden que lee el auditor")
void ordenaPorSequenceNuncaPorId() { … }
```

```ts
it('[F3-CNT-01] publica el total y cuántas páginas hay', async () => { … })
```

Reglas:

- **La etiqueta va en la prueba, no en la clase**, salvo que la clase entera sea de ese requisito.
- **Un requisito puede tener varias pruebas** y una prueba puede citar varios requisitos.
- **No se cita en el código de producción.** El código no se documenta con identificadores: se
  documenta explicando por qué. El vínculo vive en la prueba, que es lo ejecutable.

## El gate

```bash
python3 agents/ecosistema-auditoria/especificacion/trazabilidad.py            # informe
python3 .../trazabilidad.py --detalle                                        # y qué falta
python3 .../trazabilidad.py --minimo 0.11                                    # con trinquete
```

Falla —salida distinta de cero— cuando:

- **una prueba cita un requisito que no existe**: o el identificador está mal escrito o el requisito
  se borró. Las dos cosas se arreglan, no se discuten;
- **la cobertura baja del suelo** que se le pase en `--minimo`.

Y avisa, sin fallar, de dos cosas que casi siempre son un despiste:

- **un requisito en `NO_CUMPLE` que ya tiene pruebas que lo citan** — suele significar que se
  implementó y nadie actualizó el estado;
- **requisitos sin criterios de aceptación**, que es el contador que mide cuánto de la especificación
  es todavía una frase y no algo comprobable.

**El trinquete.** Hoy el suelo es **0.11** (15 de los 131 requisitos dados por hechos tienen prueba
que los cite: 11,5 %; empezó en 3,5 % el día que se montó esto). Nace donde estamos y **nunca baja**. Cada cambio sube su parte o la deja igual,
exactamente como el mínimo de Jacoco del backend. Subirlo de golpe a 1.00 sería mentir: significaría
escribir 110 pruebas de regresión antes de tocar nada.

## Las reglas que no se negocian

1. **No se programa un requisito sin criterios de aceptación.** Si no se pueden escribir, es que
   falta una decisión: pregúntala. Hay siete decisiones así ya identificadas en el contexto 07.
2. **No se marca `estado: CUMPLE` sin una prueba que cite el requisito.** Es la única regla que la
   máquina comprueba sola.
3. **Primero el requisito, después el código.** Si al implementar aparece algo que el requisito no
   dice, el requisito se corrige en el YAML y se dice en voz alta. Un requisito que se entera después
   de que el código exista no es una especificación, es documentación.
4. **El catálogo legible se genera, no se edita.** `contexto/08` sale del YAML. Editarlo a mano
   garantiza que los dos digan cosas distintas en una semana.
5. **Si el repo contradice la especificación, gana el repo** —y corregir el YAML es parte del trabajo
   que lo descubrió—. Es la misma regla que ya tiene el resto del contexto.

## El trabajo que no tiene requisito

Existe y es legítimo: deuda técnica, arreglos de un fallo, mejoras de rendimiento, refactores. SDD no
lo prohíbe; lo que hace es **que se note**.

El ejemplo está en el repo: el paginado de líneas por desplazamiento que entró el 2026-10-16 arregló
un fallo real —no se podía llegar a la última página— y de paso ordenó la grilla por número de línea.
Al etiquetarlo contra la especificación, tres de sus pruebas encajaron en requisitos del MVP
(`F3-ORD-01`, `F3-FIL-00`, `F3-CNT-01`, `F3-CNT-03`) y el resto no encaja en ninguno, porque «poder ir
a la última página» no es un requisito del documento: es algo que el documento da por supuesto.

Eso está bien. Lo que no estaría bien es no saberlo.

## Cómo encaja con los cinco roles

El flujo de `agente/auditoria-feature.md` no cambia; lo que cambia es de dónde sale cada cosa:

| Fase | Antes | Ahora |
|---|---|---|
| Analista | inventaba los criterios de aceptación | **los lee del YAML**; si faltan, los escribe ahí y los somete a revisión |
| Arquitecto | diseñaba contra el análisis | diseña contra los criterios, y cita los `id` que cubre |
| Líder técnico | recortaba alcance a ojo | recorta por `id`: lo que entra y lo que no son listas de identificadores |
| Desarrollador | implementaba | igual, pero sabe qué requisito está cerrando |
| QA | diseñaba las pruebas | **las ata**: cada prueba nueva cita su `id`, y el trinquete sube |

## Lo que falta para cerrar el ciclo

**Los 196 requisitos todavía no tienen criterios de aceptación.** Se generaron el 2026-10-16 con un
workflow de 22 agentes —once escriben los criterios, once los revisan rechazando lo que no se puede
comprobar— y se quedó a mitad al agotarse el presupuesto de la sesión: diez de los once bloques
tienen criterios escritos y ninguno ha pasado todavía por la revisión.

Están en el rastro del workflow y el script que los vuelca ya existe:

```bash
python3 especificacion/fusionar_criterios.py   # mete los criterios en el YAML
python3 especificacion/generar_catalogo.py     # rehace contexto/08 con ellos
python3 especificacion/trazabilidad.py         # el contador de «sin criterios» debería desplomarse
```

Mientras tanto el ciclo funciona igual: lo que no tiene criterios **no se programa**, se escriben
primero. Es lo que marca `consultar.py --sin-criterios`.

## Mantenimiento

- Cuando cambie el alcance, se edita el YAML y se regenera el catálogo. El PDF original es la fuente
  histórica; el YAML es la vigente.
- Cuando una de las siete decisiones abiertas del contexto 07 se cierre, deja de ser pregunta y pasa
  a ser criterio de aceptación. Muévela.
- El trinquete sube. Si lleva meses en 0.03, el problema no es el trinquete.
