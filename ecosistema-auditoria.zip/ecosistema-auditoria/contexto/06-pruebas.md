# Contexto 06 — Estándar de pruebas del backend

Aplica a `ms-auditoria-cuenta-medica`. Para el frontend, ver `02-sura-auditoria-frontend.md`
(vitest + Playwright, que ya funcionan).

## El stack real

Declarado en el bloque `subprojects` del `build.gradle` raíz, así que **todos los módulos lo tienen
sin añadir nada**:

| Librería | Para qué |
|---|---|
| `org.junit.jupiter:junit-jupiter` | **JUnit 5. Es el marco de pruebas, único y sin alternativas.** |
| `org.mockito:mockito-junit-jupiter` | **Mockito. El doble de prueba, también en integración.** |
| `org.assertj:assertj-core` | aserciones fluidas |
| `io.projectreactor:reactor-test` | `StepVerifier`, obligatorio para `Mono`/`Flux` |
| plugin `jacoco` | informe de cobertura **y umbral por módulo**, encadenado a `check` |

> **No hay WireMock, ni ArchUnit, ni Testcontainers, ni Cucumber.** El `buildscript.ext` reserva sus
> versiones, pero ninguna se usa como dependencia. Si alguna vez hiciera falta, es una decisión de
> arquitectura con su justificación, no un `testImplementation` que se añade de pasada.
>
> Las 66 pruebas que ya existen se escribieron con esto y bastó, **incluida la inspección del cuerpo
> que se envía a OHI**: lo que faltaba era un destino en memoria para el `BodyInserter`, no una
> dependencia. Está en `infraestructura/adaptadores/acl-ohi/src/test/java/.../CuerpoEnviado.java`.

## La regla: JUnit 5 para todo, Mockito para la integración

- **Todo se prueba con JUnit 5.** `@Test`, `@ParameterizedTest`, `@Nested` para agrupar escenarios.
  Nada de JUnit 4, nada de `@RunWith`.
- **Las pruebas de integración usan Mockito** (`@ExtendWith(MockitoExtension.class)`, `@Mock`,
  `@InjectMocks`, `ArgumentCaptor`). No se levanta un contexto de Spring para probar un adaptador ni
  un caso de uso.
- **Reactivo se verifica con `StepVerifier`**, nunca con `.block()`:

```java
StepVerifier.create(adaptador.buscarLineas("CM-108800618430", 50, null))
    .assertNext(pagina -> assertThat(pagina.elementos()).hasSize(50))
    .verifyComplete();
```

## Cómo se prueba el adaptador de OHI con Mockito

Es el punto que más importa, porque ahí vive el riesgo. El cliente está construido sobre **`WebClient`**
(49 usos) con `ExchangeFilterFunction`. La costura correcta para Mockito es la **`ExchangeFunction`**:

```java
@ExtendWith(MockitoExtension.class)
class AdaptadorOhiTest {

    @Mock ExchangeFunction intercambio;

    private WebClient clienteCon(String cuerpoJson, HttpStatus estado) {
        ClientResponse respuesta = ClientResponse.create(estado)
                .header("Content-Type", "application/json")
                .body(cuerpoJson)          // ← cuerpo REAL: se ejerce el decodificador
                .build();
        when(intercambio.exchange(any())).thenReturn(Mono.just(respuesta));
        return WebClient.builder().exchangeFunction(intercambio).build();
    }
}
```

Esto es importante y no es un detalle: al devolver un `ClientResponse` con **cuerpo JSON real**, la
prueba ejercita la deserialización de Jackson, que es exactamente donde se manifiestan las trampas de
OHI. Un `@Mock` del adaptador entero no probaría nada de eso.

Y con un `ArgumentCaptor<ClientRequest>` se verifica **lo que se envía**, que es la otra mitad:

```java
ArgumentCaptor<ClientRequest> captor = ArgumentCaptor.forClass(ClientRequest.class);
verify(intercambio).exchange(captor.capture());
// el cuerpo lleva el sobre "resource" y defaultoverride=true
```

## Los seis casos que no pueden faltar

Para cualquier cambio que lea de OHI (ver `05-ohi-trampas.md`):

| # | Caso | Cómo se monta con Mockito |
|---|---|---|
| 1 | **204 vacío** | `ClientResponse.create(NO_CONTENT)` sin cuerpo → debe dar colección vacía, **no** error |
| 2 | **Truncado en 200** | cuerpo con 200 elementos → verificar que el keyset avanza con `id.gt(ultimo)` |
| 3 | **Campo ausente** | JSON sin el campo proyectado → la prueba debe **fallar**, no aceptar `null` en silencio |
| 4 | **Sobre y `defaultoverride`** | `ArgumentCaptor` sobre la petición enviada |
| 5 | **Token caducado** | `thenReturn(401).thenReturn(200)` → verificar renovación y reintento |
| 6 | **Error 500 / timeout** | `Mono.error(...)` → verificar el error de dominio que llega al caso de uso |

## Cerrar la cobertura

**Esto ya está hecho.** Queda escrito porque explica por qué el `build.gradle` es como es y cómo se
sube el listón, no como trabajo pendiente. Estado al 2026-10-16: 66 ficheros de prueba sobre 165
clases; seis módulos al 1.00 y `infraestructura-acl-ohi` en 0.37.

**Paso 1 — el suelo.** `jacocoTestCoverageVerification` con un mínimo por módulo encadenado a
`check`, para que la cobertura no sea opcional:

```groovy
jacocoTestCoverageVerification {
    violationRules {
        rule {
            limit { counter = 'LINE'; minimum = 0.00 }   // se sube según la tabla
        }
    }
}
check.dependsOn jacocoTestCoverageVerification
```

**Paso 2 — el trinquete.** El mínimo arranca donde esté hoy cada módulo y **nunca baja**. Cada cambio
que entra sube su módulo o lo deja igual; ninguno lo baja.

**Paso 3 — las metas por capa**, en orden de retorno:

| Módulo | Mínimo hoy | Por qué |
|---|---|---|
| `dominio-modelo` | **1.00** | Java puro sin dependencias: es lo más barato de cubrir |
| `dominio-casos-de-uso` | **1.00** | la lógica de negocio, con puertos dobles de Mockito |
| `infraestructura-web-reactiva` | **1.00** | rutas y DTO: validación de entrada y mapeo |
| `aplicacion-servicio-app` | **1.00** | es cableado, y cubrirlo salió casi gratis |
| `infraestructura-bus-eventos` | **1.00** | |
| `infraestructura-r2dbc-trazabilidad` | **1.00** | |
| `infraestructura-acl-ohi` | **0.37**, subiendo | el riesgo real vive aquí; los 6 casos de arriba son obligatorios |

Un mínimo de 1.00 significa que **cualquier línea nueva sin prueba rompe el build**. Es deliberado.

**Paso 4 — la prioridad.** No se empieza por lo fácil, se empieza por lo que más duele:
`acl-ohi` primero (es donde los fallos son silenciosos), después `casos-de-uso`, después el resto.

## Reglas que no se negocian

- **Una prueba que no falla sin el cambio no prueba nada.** Compruébalo: rompe el código a propósito
  y mira que la prueba se ponga roja. Ya ha pasado que una prueba pasara con el defecto inyectado
  —comprobaba algo que otra línea del código ya garantizaba— y hubo que rehacerla.
- **Ninguna prueba escribe en OHI producción.** Nunca, ni como preparación ni como limpieza.
- **Nada de `.block()`** fuera de un `StepVerifier` con intención explícita.
- **Sin datos personales en los fixtures.** Códigos de cuenta sí; cédulas y nombres de afiliados no.
- **Los nombres de las pruebas, en español**, como el resto del repo:
  `devuelveColeccionVaciaCuandoOhiResponde204()`.
