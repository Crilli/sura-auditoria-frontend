# Contexto 07 — El MVP del módulo de cuentas médicas

> Qué tienen que hacer `sura-auditoria-frontend` y `ms-auditoria-cuenta-medica`, qué hacen ya, y qué
> hay que decidir antes de construir lo que falta.

## De dónde sale esto

Del documento **«Módulo visualización y gestión de cuentas médicas — CORE»** (ARL SURA, PDF de 9
páginas fechado 25/08/2026). Es la especificación funcional del MVP: no es una lista de deseos, es
el alcance con el que se mide el producto.

Su objetivo, en una frase suya:

> Disminuir tiempos operativos, consultas sobre múltiples pantallas y reprocesos mediante una
> experiencia única donde el usuario pueda gestionar una factura **de punta a punta sin navegar entre
> diferentes aplicaciones**.

Eso fija el listón y explica por qué el documento repite tanto «las visualizaciones deben contar con
las mismas funcionalidades que se ejecutan actualmente»: las capturas que ilustra son de la pantalla
de OHI, y el MVP es **sustituirla**, no complementarla. Un campo que el auditor hoy ve en OHI y no vea
aquí es un motivo para volver a OHI, y entonces el objetivo no se cumplió.

**Lo resaltado en amarillo en el PDF es desarrollo opcional.** Son dos cosas: siete de los nueve
criterios del buscador, y el bloque entero de alertas y trazabilidad. Lo demás es obligatorio.

## El veredicto, al 2026-10-16

196 requisitos desglosados del documento, auditados contra el código de los dos repos el
2026-10-16. Las 119 afirmaciones de «esto ya está» o «está a medias» pasaron después por un
verificador cuyo encargo era **tumbarlas**: 16 se cayeron y están corregidas. Lo que sigue es el
resultado después de esa poda.

| Bloque | Total | ✅ | 🟡 | ❌ | Lectura |
|---|---|---|---|---|---|
| Buscador de facturas | 20 | 0 | 2 | 18 | **No existe.** Hoy hay «abrir la cuenta por su código», no un buscador |
| Vista 360 · encabezado | 25 | 20 | 3 | 2 | Casi completo |
| Vista 360 · botones | 10 | 0 | 4 | 6 | Las acciones existen; la botonera que pide el documento, no |
| Vista 360 · pestañas | 12 | 3 | 5 | 4 | Faltan contadores y la pestaña de respuesta a glosa |
| Alertas y trazabilidad ◦ | 14 | 0 | 3 | 11 | Opcional, y sin empezar |
| Resumen de líneas (grilla) | 18 | 9 | 0 | 9 | Están los identificadores; faltan cantidades, IVA y la edición en línea |
| Detalle de la línea | 41 | 36 | 0 | 5 | **Lo más completo del MVP** |
| Reemplazo masivo | 10 | 0 | 3 | 7 | No hay selección múltiple en ninguna pantalla |
| Motivos pendientes | 12 | 7 | 2 | 3 | La resolución masiva ya está, y en producción |
| Filtros, orden y contadores | 21 | 6 | 4 | 11 | Los filtros sí; **el ordenamiento no existe** |
| Glosas y desbloqueo | 13 | 3 | 4 | 6 | Falta todo lo que depende de seleccionar líneas |
| **Total** | **196** | **84** | **30** | **82** | |

Dicho de otro modo: **lo que se mira está casi hecho, lo que se busca y lo que se opera en masa está
por hacer.** El detalle de una línea cumple 36 de sus 41 requisitos; el buscador, que el documento llama
«la pantalla principal», no existe.

### Lo que ya está y conviene no rehacer

- **El detalle de la línea** (41 requisitos, 36 cumplidos): prestación, convenio con sus tres códigos
  tarifarios, diagnósticos, siniestro con su UEN, glosas, pendientes y novedades, cada uno en su
  sección.
- **El encabezado** (20 de 25): las cuatro fechas, los cinco totales, las tres marcas, acuse, tipo de
  servicio y las dos observaciones.
- **La resolución masiva de motivos de pendiente**, que además está medida en producción: 32.661
  operaciones por el endpoint nativo de OHI.
- **La distinción entre motivo bloqueante y no bloqueante**, que el documento pide explícitamente y
  está resuelta en el dominio (depende del par motivo-estado, no solo del motivo).
- **El paginado de líneas por desplazamiento**, que es justo lo que exige la nota repetida dos veces
  en el documento: filtros y órdenes «sobre toda la paginación», no sobre la página a la vista.

## Qué le toca a cada repo

El MVP no reparte trabajo a partes iguales. Agrupado por dónde vive:

### `ms-auditoria-cuenta-medica`

| Qué | Tamaño | Por qué |
|---|---|---|
| **Endpoint de colección de cuentas** con los nueve criterios, paginado | grande | No existe nada: todas las rutas cuelgan de `/cuentas/{codigo}`. Es un endpoint, un caso de uso y un método de puerto nuevos |
| **Parámetro de orden** en el listado de líneas | mediano | `SolicitudBusqueda.desplazada` ya acepta el orden; falta que viaje desde la ruta. Seis de los siete campos se resuelven en OHI |
| **Ensanchar la proyección de la línea**: cantidades, valor cargado, IVA | pequeño, repetido | Son cinco capas por campo (proyección → DTO externo → dominio → DTO de respuesta → front), siempre las mismas |
| **Operación masiva de escritura sobre líneas** | grande | Para el reemplazo masivo y para aplicar glosas a una selección. El puerto ya sabe aplicar ediciones de varias líneas en una operación; falta exponerlo y acotarlo |
| **Empujar el filtro de valor glosado** a OHI | pequeño | Hoy recorre la cuenta en lotes y renuncia al total. Medido: se puede filtrar |
| **Filtro de líneas con novedad** | mediano | Hay que ir por el recurso hijo y volver con `id.in(...)`: el filtro directo devuelve la cuenta entera |
| Nombre del prestador en la cabecera, `processType`, `codigoSiniestro` | pequeño | Campos que OHI publica y la proyección de cabecera no pide |
| Opcional: timeline, alertas, autoría | grande | Ver el bloque de alertas. Exige leer tres recursos de OHI que la ACL no toca y resolver antes la identidad del auditor |

### `sura-auditoria-frontend`

| Qué | Tamaño | Por qué |
|---|---|---|
| **Pantalla de búsqueda de verdad**: formulario de nueve criterios, grilla de resultados, selección de versión | grande | Hoy es un campo de texto que navega al detalle |
| **Selección múltiple en la grilla de líneas** | mediano | Es el prerrequisito de todo lo masivo: reemplazo, glosas, mensajes, pendientes acotados. El patrón ya está resuelto en la pantalla de pendientes |
| **Edición en línea sobre la grilla** | grande | El documento es explícito: «sin que se abra toda la línea». Hoy editar obliga a navegar al detalle |
| **Ordenamiento por columna** | mediano | No existe ninguno. Depende del parámetro de orden del backend |
| **Siete columnas nuevas** en la grilla | mediano | Y antes, una decisión de diseño: la grilla ya va con scroll horizontal y el documento pide 17 campos |
| Contadores de resultados y de seleccionados | pequeño | El de resultados ya está a medias; el de seleccionados depende de la selección múltiple |
| Botonera de la vista 360 y contadores en las pestañas | pequeño | Las acciones existen y están accionables; falta colocarlas donde el documento las pide |
| Opcional: panel de alertas y timeline | grande | Depende por completo del backend |

### Lo que no es de ninguno de los dos

Dos hitos del timeline —validación documental y error de RIPS— **nacen en la radicación**, en
`937-ohi_arl_cuentasmedicas-ms`. El timeline completo no es una consulta nueva: es la unión de tres
fuentes (OHI, la radicación y la traza propia), y eso se decide antes de escribir el endpoint.

## Las siete decisiones que hay que cerrar antes de construir

Ninguna es técnica. Todas bloquean trabajo y ninguna se resuelve leyendo código.

### 1. Qué es una «versión» de la cuenta médica

El documento la usa en tres sitios (resultados del buscador, motivos de desfinalizar, respuesta a
glosa) y **en el sistema hay tres cosas distintas que podrían serlo**. Medido en UAT:

| Candidato | Qué es | Evidencia |
|---|---|---|
| `objectVersionNumber` | El contador de bloqueo optimista. **No es esto**, y es lo que la pantalla rotula hoy como «v91333» | `RespuestaCuenta.version` |
| Varias cuentas con la misma factura | Re-radicaciones. `numeroFactura.eq('JONATHAN201')` → **3 cuentas**, mismo prestador y mismo valor, distinto código y distinto estado | medido |
| `ctrclaims` por `(version, reversal)` | La contabilidad de la cuenta: `CM-94421` tiene **10 filas**, versiones 1–5 cada una con su reverso | medido |

Y hay un cuarto dato que las ata: la lista `respuestaGlosa` de la cuenta trae un campo
`versionamiento` con valores como **`CM-94421-V4`**. Es decir, el propio OHI etiqueta qué versión
produjo cada respuesta a glosa.

Las columnas que el documento pide para los resultados —radicado, fecha de llegada, número de
factura, prestador, valor, estado OHI— encajan con el **segundo** candidato: cada fila tiene su propio
radicado y su propio estado. Pero «con este se activa una nueva versión de la CM» (desfinalizar) y «se
activa el nuevo versionamiento» (respuesta glosa) describen el **tercero**. Hay que preguntarlo; la
respuesta cambia el buscador entero.

### 2. «Valor convenido» y «Valor autorizado» están cruzados

El MVP pide **las dos columnas a la vez**, en la grilla y en el detalle. Hoy no se pueden añadir sin
resolver esto:

- La pantalla de OHI rotula `allowedAmount` como **«Valor convenido»** y `coveredAmount` como
  **«Valor autorizado»**.
- El servicio y el front hacen lo contrario: `valorAutorizado` ← `allowedAmount`, `valorCubierto` ←
  `coveredAmount`. El campo que el formulario llama «Valor Autorizado» escribe el «Valor convenido»
  de OHI.
- Y hay un tercer `valorConvenido` en el detalle que no es ninguno de los dos: sale de las cláusulas
  de tarifación.

La elección de campo al escribir es correcta y está medida (96.735 líneas en producción con
`manualPricing`). **Lo que engaña es el rótulo.** Si se añaden las dos columnas sin cerrar la
equivalencia, la pantalla mostrará dos cifras intercambiadas respecto de OHI y nadie podrá cuadrar un
reporte.

### 3. Qué se busca cuando se busca por autorización o por siniestro

Los dos son datos de línea *y* de cabecera. «Buscar facturas por número de autorización» puede
significar «cuentas cuya cabecera lleva esa autorización» o «cuentas que tienen alguna línea con esa
autorización», y no dan el mismo resultado. Lo mismo con el siniestro. Los dos campos existen en
`claims` —así que las dos lecturas son implementables— pero hay que elegir una.

### 4. Qué estados se le ofrecen al auditor

El documento lista «Finalizado, Pendiente, cambiar, Inicial; entrada, etc.». Dos problemas: **«Pendiente»
no es un estado** —es el indicador de pendientes sin resolver—, y el vocabulario real tiene 17 estados
con tres grafías distintas según dónde se mire (el literal del dominio, el de `q` con espacios, y el de
`groupBy` en CamelCase). Hace falta la lista cerrada de estados que el auditor va a ver, con su
etiqueta en español.

### 5. Qué es «mono usuario»

La regla «si la factura es mono usuario no mostrar cédula ni nombre del afiliado» necesita una
definición operativa. El sistema ya sabe cuándo todas las líneas comparten afiliado —lo usa para el
filtro— pero ocultarlo es lo contrario de lo que hace hoy la pantalla, que lo destaca. Hay que
confirmar que es eso y no una marca de la factura.

### 6. Hasta dónde llega el reemplazo masivo

El documento pone tres ejemplos: autorización, valor convenido y UEN. Medido contra el contrato de
escritura: **los dos primeros se pueden escribir hoy; la UEN no** — vive en un registro dinámico
derivado y no está en el contrato de actualización de línea. Si la UEN es imprescindible, es una
conversación con Oracle, no una tarea de desarrollo.

Y una advertencia de alcance: «debe aplicar la búsqueda en toda la paginación» sobre una cuenta de
4.063 líneas significa que un reemplazo puede tocar miles de líneas en una operación. Eso necesita
confirmación explícita, un resultado parcial legible y, sobre todo, una decisión de negocio sobre si
se permite sin tope.

### 7. Dónde vive la respuesta a glosa

Existe en OHI: `claims.respuestaGlosa` es una lista embebida con `fechaLlegada`, `numeroSecuencia`,
`valor`, `fechaVencimiento` y `versionamiento`, y está poblada (4 de 25 cuentas con glosa en la
muestra de UAT). O sea que **la pestaña se puede pintar leyendo**. Lo que no está claro es la
escritura: el documento dice «desde el portal o manualmente», y si «manualmente» significa que el
auditor la captura aquí, hay que averiguar por dónde se escribe un registro dinámico derivado.

## Lo que se midió contra OHI para esto

Todo lo de abajo es lectura contra UAT el 2026-10-16, sobre `CM-35343660784` (212 líneas) salvo donde
se diga otra cosa. Sirve para no discutir lo que se puede comprobar.

### El buscador es viable entero

Los **nueve** criterios que pide el documento existen en `claims` y se pueden filtrar:

| Criterio | Campo | Comprobado |
|---|---|---|
| Número de factura | `numeroFactura` | 200 · 3 resultados |
| Prestador de facturación | **`claimantProvider.code`** | 200 · 300 cuentas |
| Número de radicado | `code` | ya se usa |
| Documento del afiliado | `person.code` | 200 · 515 cuentas |
| Estado | `status` | 200 · 56.238 |
| Fecha de radicación (rango) | `receiptDate.bet(a,b)` | 200 · 4.424 |
| Tipo de proceso | `processType` | 200 · 11.395 |
| Número de autorización | `authorizationCode` | el campo existe en `claims` |
| Número de siniestro | `codigoSiniestro` | el campo existe en `claims` |

Ojo con dos: el prestador **no** es `provider.code` ni `payToProvider.code` —los dos dan 500— sino
`claimantProvider.code`. Y cualquier búsqueda sobre `claims` tiene que filtrar `processType.eq('C')`
o devolverá también las reservas, que son el 73 % de las filas.

Lo que falta no está en OHI: **no hay ningún endpoint de colección de cuentas**. Las rutas actuales
cuelgan todas de `/cuentas/{codigo}`. El buscador es un endpoint, un caso de uso y un método de puerto
nuevos, y por la regla del contexto 04 nace paginado.

### El ordenamiento: seis de siete

`orderBy` sobre `claimlines`, con el desplazamiento ya en marcha:

| Campo que pide el MVP | `orderBy` | |
|---|---|---|
| Secuencia | `sequence` | ✅ |
| Cédula afiliado | `person.code` | ✅ |
| Fecha de atención | `startDate` | ✅ |
| Código autorización | `authorizationCode` | ✅ |
| CUPS | `procedure.code` | ✅ |
| Valor glosado | `valorGlosado` | ✅ comprobado que ordena de verdad, pese a que OHI lo declare no filtrable |
| **Valor cargado** | `claimedAmount` | ❌ **500**: los importes no se ordenan |

Los tres campos de tipo «monto» (`claimedAmount`, `allowedAmount`, `coveredAmount`) fallan. Para
ordenar por valor cargado hay que traer y ordenar aquí, y entonces el total deja de ser fiable: es un
régimen distinto que la pantalla ya sabe representar.

El orden se combina con el desplazamiento, así que «ordenar sobre toda la paginación» lo resuelve el
servidor sin trabajo extra.

### Un filtro que hoy se hace mal

**`valorGlosado` se puede filtrar en OHI** y discrimina sin un fallo: `gte(0)`→212, `gte(100000)`→50,
`gte(571294)`→20, `gte(999999999)`→204. Hoy el servicio lo trata como filtro local, recorre la cuenta
en lotes de 200 y renuncia al total. Empujarlo es un cambio pequeño que devuelve el contador de
resultados que el documento pide.

**Aviso para quien vaya a comprobarlo**: el `/definition` de OHI declara ese campo
`x-oi-searchable: no`, y el anexo del repo lo copia. Es un **falso negativo** —ver la trampa 8 del
contexto 05—, así que no des por imposible un filtro sin probarlo. El catálogo de la prestación, en
cambio, sí es local a la fuerza: `procedure.flexCodeDefinitionCode` da 500.

### El IVA existe y no se expone

`claimlines` tiene `montoIVACalculado` y `porcentajeIVA`. Ninguno está en la proyección ni en los DTO.
Las dos columnas que pide la grilla son dos campos más en la proyección, no un desarrollo.

### Dos trampas nuevas, que ya están en el contexto 05

Salieron midiendo esto y afectan directamente a varios requisitos:

- **Filtrar por una colección hija devuelve la cuenta entera.** Pedir las líneas que tienen un
  mensaje concreto devolvió las 212 de la cuenta, cuando el mensaje está en 199. Para «filtrar por
  líneas con novedad» hay que ir por el recurso hijo y volver con `id.in(...)`.
- **Un booleano no filtra.** `locked.eq('Y')` y `locked.eq('N')` devuelven las dos el conjunto
  completo. Nada de filtrar por bloqueada, reemplazada o resuelta.

## Reglas que el MVP impone y que hay que respetar

Son suyas, no nuestras, y están repetidas en el documento:

1. **Filtros, órdenes y reemplazos actúan sobre toda la cuenta, no sobre la página a la vista.** La
   nota aparece tres veces. Cualquier implementación en cliente la incumple.
2. **La grilla se edita sin abrir la línea.** «Estos campos se deben dejar editar sin que se abra toda
   la línea y guardar los cambios». Hoy editar exige navegar al detalle.
3. **Hay que decir cuántos resultados hay y cuántos están seleccionados**, también en el paginador.
4. **Paridad con lo que hoy se hace en OHI.** Cada bloque lo repite. Un campo que falte es una razón
   para volver a la pantalla vieja.

## Cómo seguir

El detalle requisito a requisito —los 196, con su evidencia y lo que le falta a cada uno— está en
[08-mvp-requisitos.md](08-mvp-requisitos.md).

Para trabajar cualquiera de estos bloques, el orden de los roles del ecosistema sigue siendo el de
siempre: el analista verifica la regla contra OHI, el arquitecto decide dónde vive, el líder técnico
recorta el alcance, y nada entra sin pruebas (ver [06-pruebas.md](06-pruebas.md), que ya no describe
un repo sin pruebas).

## Mantenimiento

Medido el **2026-10-16** contra el código de ese día y contra OHI UAT. Dos avisos:

- La auditoría envejece con cada despliegue. Si un requisito de aquí dice ❌ y el repo lo tiene,
  **gana el repo**: corrígelo aquí.
- Las siete decisiones abiertas son el estado a fecha de hoy. En cuanto negocio responda una, deja de
  ser una pregunta y pasa a ser un requisito; muévela.
