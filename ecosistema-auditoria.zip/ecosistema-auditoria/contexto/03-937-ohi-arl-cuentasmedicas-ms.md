# Contexto 03 — `937-ohi_arl_cuentasmedicas-ms` (el vecino)

`rootProject.name = 'ms-cuentas-medicas-arl'` · paquete base `sura.cuentasmedicas` · Java + Gradle

## Qué es y qué no es

Es el microservicio de **radicación** de cuentas médicas hacia OHI. No lo consume
`sura-auditoria-frontend` y no comparte código con `ms-auditoria-cuenta-medica`.

Entra en el alcance de estas skills por dos razones, y conviene tenerlas separadas:

1. **Es fuente de verdad del negocio.** Lo que el auditor ve en la pantalla llegó a OHI por aquí. Una
   pregunta del tipo "¿por qué esta línea no tiene prestador?" casi siempre se responde mirando cómo
   radicó el `937`, no mirando el backend de auditoría.
2. **Es la referencia de ingeniería de los tres.** Es el único con una suite de pruebas real
   (178 archivos de prueba sobre 420 de producción) y el único con pipelines de CI
   (`CI/pipeline.yml`, `CI/pipelinePR.yml`, `CI/sonar.properties`). Cuando haya que decidir "cómo se
   prueba esto aquí", el patrón a copiar está en este repo.

## Mapa de módulos

Mismo mecanismo que `ms-auditoria`: `settings.gradle` recorre el árbol y nombra cada módulo como
`<carpeta-padre>-<carpeta>`. Pero **las capas están en inglés**, no en español:

```
domain/
  model/              entidades y puertos
  usecase/            casos de uso
infraestructure/      (sic — así está escrito en el repo, sin la 't')
  driver-adapter/
    ohi-rest-client/      cliente REST contra OHI
    oracle-repository/    persistencia
    web-service/
  entry-points/
    web/                  API REST
    async-event-bus/      eventos
    scheduler/            tareas programadas
  helpers/
    security-app/
    tracing/
applications/
  app-service/        raíz de composición
```

> Ojo con `infraestructure`: está mal escrito en el repo (falta la `t` de *infrastructure*) y además
> difiere del `infraestructura` en español de `ms-auditoria`. No lo "corrijas" de pasada: renombrar esa
> carpeta renombra todos los módulos Gradle que cuelgan de ella.

Diferencias con `ms-auditoria` que hay que tener presentes al saltar de uno a otro:

| | `ms-auditoria-cuenta-medica` | `937-ohi_arl_cuentasmedicas-ms` |
|---|---|---|
| Capas | `dominio` / `infraestructura` / `aplicacion` | `domain` / `infraestructure` / `applications` |
| Adaptadores de salida | `adaptadores/` | `driver-adapter/` |
| Adaptadores de entrada | `puntos-de-entrada/` | `entry-points/` |
| Nombre de módulo | `<capa>-<carpeta>` | `<carpeta-padre>-<carpeta>` |
| Pruebas | 0 | 178 |
| CI | — | `CI/*.yml` + Sonar |

## Lo que está pendiente en este repo

- **El `README.md` es la plantilla de Azure DevOps sin tocar**, con todos los `TODO:` originales. No
  sirve para entender el proyecto; no lo cites como documentación.
- En la raíz hay análisis sueltos en Markdown y SQL (`BRECHAS_DEFINICION_RADICACION.md`,
  `CAMBIO_VALIDACION_RADICADO_ATEP.md`, `PLAN_MENSAJE_FINANCIERO_POR_CUENTA.md`,
  `LOG_ELIMINACION_CM_DYNATRACE.md`, consultas `.sql`). Son notas de trabajo valiosas sobre el
  negocio de la radicación, pero no están organizadas ni versionadas como documentación formal.

## Cuándo tocarlo

Por defecto, **no**. El encargo habitual es "una implementación entre front y backend de auditoría".
Si el análisis concluye que el arreglo real está en la radicación, eso es un hallazgo que hay que
**declarar y escalar**, no resolver de pasada: cambia de equipo, de pipeline y de riesgo.
