# Contexto 02 — `sura-auditoria-frontend`

Angular 22.0.4 · Nx 23.1.1 · vitest 4 · Playwright · ESLint flat config (`eslint.config.mjs`)

## Mapa del workspace

```
apps/
  shell/        host de la aplicación — es lo que se sirve y se construye
  auditoria/    la funcionalidad de auditoría de cuentas médicas
  shell-e2e/    pruebas end-to-end con Playwright (1 spec hoy)
libs/
  data-access/
    auth/       autenticación
    http/       cliente HTTP y el modelo de paginación por cursor
  ui-components/
  util/
    formats/    formateo (fechas, importes)
```

```bash
npx nx serve shell --port 4200      # desarrollo
npx nx build shell                  # build
npx nx test <proyecto>              # vitest
npx nx lint <proyecto>              # eslint
npx nx e2e shell-e2e                # playwright
```

`npm start` y `npm run build` son atajos de `nx serve shell` / `nx build shell`. Con el PATH del Mac
hay que anteponer `PATH=~/.local/node/bin:$PATH` si la shell no lo trae.

## Clean Architecture dentro de `apps/auditoria`

La funcionalidad no está organizada por tipo de archivo sino por capa, igual que el backend:

```
apps/auditoria/src/app/auditoria/
  domain/           entidades y contratos del dominio de UI
  application/
    use-cases/      un archivo por caso de uso: consultar-cuenta, guardar-linea,
                    resolver-pendiente, enviar-cuenta, listar-pendientes,
                    ejecutar-accion, consultar-proceso, guardar-novedades-cuenta,
                    resumir-filtros-lineas, resumir-motivos-pendientes…
  infrastructure/   adaptadores HTTP contra el ms-auditoria
  presentation/     componentes standalone y diálogos
  auditoria.routes.ts
```

**La regla:** un componente de `presentation` **no** llama a HTTP. Invoca un caso de uso de
`application/use-cases`, que a su vez usa un adaptador de `infrastructure`. Los nombres de los casos de
uso del front espejan las operaciones del backend casi uno a uno — esa simetría es deliberada y hay
que mantenerla: si añades un endpoint, el caso de uso del front debería poder nombrarse igual.

## Paginación: dos regímenes, y cuál usa cada pantalla

**Las líneas paginan por desplazamiento. Los pendientes, por cursor.** No es una inconsistencia que
haya que limpiar: son dos problemas distintos y cada uno tiene el modelo que le corresponde.

### Líneas — por desplazamiento (`libs/data-access/http/src/lib/offset-page.model.ts`)

```ts
export interface OffsetPage<T> {
  elementos:      T[];
  desplazamiento: number;
  tamanoPagina:   number;
  pagina:         number;         // contando desde CERO, como el servicio
  totalRegistros: number | null;  // null = no es de fiar, ver abajo
  totalPaginas:   number | null;
  hayMas:         boolean;        // siempre fiable
}
export interface OffsetRequest { pagina: number; tamano: number }
```

- **`pagina` y `tamano` siempre se envían.** `pagina` cuenta desde cero y el servicio la traduce a
  desplazamiento multiplicando por el tamaño.
- **`totalRegistros` y `totalPaginas` llegan `null` cuando no son de fiar**, y hay que respetarlo: pasa
  cuando el filtro incluye el catálogo de la prestación, que el sistema de registro no sabe aplicar. Su
  cuenta sería de las filas de antes de descartar y el paginador ofrecería páginas vacías. Sin total no
  se pintan números de página, solo «siguiente» y «anterior».
- **El fin de la lista lo marca `hayMas === false`**, nunca la aritmética sobre el total.

Esto sustituyó al cursor el 2026-10-16 por un motivo concreto: con cursor solo se podía avanzar «a la
siguiente», así que saltar a la página 50 costaba 49 peticiones en serie y la última página de una
cuenta grande era **inalcanzable** —163 páginas en la cuenta mayor medida, con un tope de 20 saltos
encadenados—. El sistema de registro sí admite desplazamiento, y en profundidad: medido, `offset=4025`
sobre 4.063 líneas devuelve sus filas y el total que acompaña es el verdadero.

Vino con dos arreglos del mismo sitio: la grilla ordena ahora por número de línea y no por
identificador —por identificador las primeras filas de esa cuenta son las líneas 2106, 2477 y 2805— y
«guardar y pasar a la siguiente» dejó de ir montado sobre el cursor (daba la siguiente *por
identificador*) y tiene su propio endpoint, `GET …/lineas/{ref}/siguiente`.

### Pendientes — por cursor (`libs/data-access/http/src/lib/cursor-page.model.ts`)

```ts
export interface CursorPage<T> {
  elementos:       T[];
  cursorSiguiente: string | null; // null = última página
  totalRegistros:  number | null;
  tamanoPagina:    number;
}
```

Siguen con cursor porque su listado **no es un recurso de OHI, son dos concatenados** —los pendientes
de cabecera como prefijo de los de línea— y un desplazamiento de OHI es por recurso: no existe uno que
atraviese las dos colecciones. Migrarlos es antes una decisión de producto (sacar los de cabecera a su
propia sección) que un refactor.

> **Nunca `offset` contra un conjunto que se mueve.** La regla de oro sigue viva donde importa: para
> recorrer tablas globales —en producción entran unas mil cuentas al día— hay que paginar por clave o
> se pierden filas en silencio. Las líneas de **una** cuenta no se mueven salvo que el propio auditor
> las toque, y por eso ahí el desplazamiento es correcto.

## Estado de las pruebas

20 componentes, 8 `.spec.ts`, 1 e2e. Playwright y vitest están configurados y funcionando, así que
aquí —a diferencia del backend— **sí hay dónde apoyarse**: cuando toques un componente, ya existe el
patrón de prueba que copiar.

## Convenciones

- **Componentes standalone.** Angular 22; no se añaden `NgModule` nuevos.
- **Dominio en español**, igual que el backend (`consultar-cuenta.use-case.ts`,
  `enviar-cuenta-dialog.component.ts`).
- Lo compartido entre apps va a `libs/`, no se duplica. Si algo de `apps/auditoria` lo va a usar otra
  app, sube a `libs/ui-components` o `libs/util`.
- `dist/`, `error.log`, `check_errors.js` y `check_pw.js` en la raíz son residuos de depuración, no
  parte de la arquitectura. No los tomes como ejemplo.
