# Contexto 00 — El ecosistema de Auditoría de Cuentas Médicas

> Medido sobre los repos el 2026-10-15. Si una cifra de aquí no cuadra con lo que ves, **gana el repo**:
> verifícalo y corrige este archivo.

## Los tres repositorios

| Repo | Qué es | Stack | Rol en el flujo |
|---|---|---|---|
| `ms-auditoria-cuenta-medica` | Backend de la pantalla de auditoría | Java 21, Spring Boot 3.4.5, **reactivo** (Reactor), Gradle Groovy | Traduce OHI al lenguaje de la auditoría y lo sirve al front |
| `sura-auditoria-frontend` | La pantalla de auditoría | Angular 22.0.4, Nx 23.1.1, vitest 4, Playwright | Única interfaz de usuario |
| `937-ohi_arl_cuentasmedicas-ms` | Radicación de cuentas médicas | Java, Gradle, capas en inglés | Radica cuentas **hacia** OHI; no lo consume el front |

**El par que se toca junto es `sura-auditoria-frontend` ↔ `ms-auditoria-cuenta-medica`.** El `937` es
un vecino: comparte el dominio de negocio y el mismo OHI de producción, pero **no** comparte código ni
contrato con los otros dos. Entra en juego como fuente de verdad del negocio (cómo se radica) y como
referencia de ingeniería (es el único de los tres con una suite de pruebas real).

## Cómo se hablan

```
  sura-auditoria-frontend
        │  HTTP  /api/v1/cuentas · /api/v1/catalogos     (ver contexto 04)
        ▼
  ms-auditoria-cuenta-medica
        │  POST /generic/<recurso>/search  ·  /claims/{id}/...
        ▼
  OHI producción  (Oracle Health Insurance)
        ▲
        │  radicación
  937-ohi_arl_cuentasmedicas-ms
```

Las dos flechas hacia OHI son independientes: el `937` radica, el `ms-auditoria` lee y audita. Un cambio
en uno **no** se entera del otro salvo por el estado que ambos ven en OHI.

## Tamaño real y deuda medida

| | prod | pruebas | ratio |
|---|---|---|---|
| `ms-auditoria-cuenta-medica` | 165 `.java` | **66 `.java`** | ~40 % |
| `937-ohi_arl_cuentasmedicas-ms` | 420 `.java` | 178 `.java` | ~42 % |
| `sura-auditoria-frontend` | 20 componentes | 9 `.spec.ts` + 1 e2e | ~45 % de componentes |

> **Esto cambió, y es el cambio más importante del ecosistema.** Hasta el 2026-10-15 el backend no
> tenía ni una prueba; hoy tiene 66 ficheros y un **trinquete de cobertura** en `build.gradle`
> (`jacocoTestCoverageVerification` encadenado a `check`, con un mínimo por módulo que nunca baja):
> seis módulos están al **1.00** —cualquier línea nueva sin prueba rompe el build— y
> `infraestructura-acl-ohi` va por **0.37** camino del 100 %.
>
> La consecuencia práctica: «los tests pasan» ya es evidencia de algo, y `./gradlew check` es la
> puerta. Lo que antes era «la primera prueba de un módulo la escribe quien lo toca» ahora es
> «quien baje la cobertura de un módulo no pasa».

Ojo con un matiz que es fácil leer mal en el `build.gradle`: el bloque `buildscript.ext` reserva
versiones para ArchUnit 1.3.0, WireMock 3.13.0, Testcontainers 1.20.4 y Cucumber 7.20.1, pero
**ninguna de esas cuatro se usa como dependencia en ningún módulo**. Son constantes huérfanas. Lo
que de verdad está en el classpath de pruebas (declarado en `subprojects`, así que lo tienen todos
los módulos) es:

```groovy
testImplementation 'org.junit.jupiter:junit-jupiter'
testImplementation 'org.mockito:mockito-junit-jupiter'
testImplementation 'org.assertj:assertj-core'
testImplementation 'io.projectreactor:reactor-test'
testRuntimeOnly   'org.junit.platform:junit-platform-launcher'
```

Más el plugin `jacoco`, que **sí impone umbral desde el 2026-10-15**: `ext.MINIMO_COBERTURA` en el
`build.gradle` raíz, uno por módulo, encadenado a `check`. Ver `contexto/06-pruebas.md`.

Las cuatro librerías huérfanas siguen huérfanas: las 66 pruebas se escribieron con lo que de verdad
hay en el classpath, que es suficiente. Si alguna hiciera falta, es una decisión de arquitectura con
su justificación, no un `testImplementation` añadido de pasada.

## Entorno de ejecución

Mac corporativo sin permisos de admin. Toolchain en `~/.local` y `~/Library/Java/JavaVirtualMachines`.
JDK 21 Temurin, Node 22, Gradle 8.9 por wrapper.

```bash
# backend
cd ms-auditoria-cuenta-medica && ./gradlew build
# frontend
cd sura-auditoria-frontend && npx nx serve shell --port 4200
```

Dos trampas del entorno que cuestan horas si no se saben:

- **TLS interceptado en la red Sura.** El firewall `srfwcampus.suramericana.com.co` re-firma los
  certificados. `curl` funciona (el llavero de macOS confía en `SuraRootCA`) pero la JVM falla con
  `PKIX path building failed`, y en `ms-auditoria` eso se manifiesta como **503 en todos los endpoints
  respondidos en ~5 ms** — parece un circuit breaker abierto y es un handshake. Truststore propio en
  `~/.local/share/certs/sura-cacerts`, se activa por `JAVA_TOOL_OPTIONS`.
- **Fuera de la red del campus la cadena valida sin más**, así que el mismo binario funciona por la
  mañana y falla por la tarde según dónde esté el portátil.

## Convenciones transversales

- **Español en el dominio.** Paquetes, clases y rutas en español (`co.sura.auditoria.casodeuso`,
  `RespuestaCuenta`, `/cuentas/{codigo}/pendientes`). El inglés queda para términos técnicos sin
  traducción asentada. El `937` es la excepción: usa capas en inglés (`domain`, `entry-points`).
- **Gradle en Groovy, nunca Kotlin.** Es preferencia explícita del equipo. El wrapper se copia de
  `ms-auditoria` (8.9).
- **Los secretos viven en `.env`** (gitignored), sufijados por perfil (`OHI_CLIENT_SECRET_PROD`).
  Nunca en `application.yml`, nunca en la línea de comandos.

## Los otros archivos de contexto

- `01-ms-auditoria-cuenta-medica.md` — capas, módulos y reglas del backend
- `02-sura-auditoria-frontend.md` — Nx, Clean Architecture del front y paginación
- `03-937-ohi-arl-cuentasmedicas-ms.md` — el vecino y por qué importa
- `04-contrato-api.md` — el contrato entre front y backend, endpoint por endpoint
- `05-ohi-trampas.md` — lo que OHI hace mal y hay que saber de memoria
- `06-pruebas.md` — el estándar de pruebas y el trinquete de cobertura
- `07-mvp-cuentas-medicas.md` — **el alcance**: qué pide el MVP, qué cumple hoy y qué hay que decidir
- `08-mvp-requisitos.md` — el catálogo de requisitos del MVP, uno por uno (generado del YAML)
- `09-sdd.md` — **cómo se trabaja**: la especificación manda, las pruebas la citan, el gate la comprueba
