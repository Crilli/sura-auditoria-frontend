# Contexto 04 — El contrato entre el front y el backend de auditoría

Lo sirve `:infraestructura-web-reactiva` desde `EnrutadorRest.java` (rutas funcionales de WebFlux,
no `@RestController`). Lo consume `apps/auditoria/.../infrastructure` del front.

## Superficie actual

Dos raíces: **`/api/v1/cuentas`** y **`/api/v1/catalogos`**. En total 12 `GET`, 4 `POST`, 2 `PATCH`
— y ningún `DELETE`, lo cual es una decisión de diseño, no un olvido: en auditoría no se borra,
se resuelve o se devuelve.

| Ruta | Para qué |
|---|---|
| `GET /api/v1/cuentas/{codigo}` | la cuenta médica |
| `GET /api/v1/cuentas/{codigo}/lineas` | líneas de la cuenta — **paginado por desplazamiento** (`pagina`, `tamano`) |
| `GET /api/v1/cuentas/{codigo}/lineas/filtros` | valores disponibles para filtrar líneas |
| `GET /api/v1/cuentas/{codigo}/lineas/{ref}/siguiente` | la línea siguiente por número de línea; **204** si era la última |
| `GET /api/v1/cuentas/{codigo}/pendientes` | pendientes de la cuenta |
| `GET /api/v1/cuentas/{codigo}/novedades` | novedades |
| `GET /api/v1/cuentas/{codigo}/acciones` | acciones disponibles según el estado |
| `GET /api/v1/cuentas/{codigo}/proceso` | estado del proceso |
| `GET /api/v1/cuentas/{codigo}/proceso/flujo` | el flujo completo |
| `POST /api/v1/cuentas/{codigo}/acciones/{accion}` | ejecutar una acción |
| `POST /api/v1/cuentas/{codigo}/enviar` | enviar la cuenta |
| `PATCH` sobre líneas y novedades | guardar cambios parciales |
| `POST .../pendientes/{motivo}/resolver` | resolver pendientes, incluida la vía masiva |
| `GET /api/v1/catalogos/{referencia}` | catálogos por referencia |

La tabla es orientativa sobre el agrupamiento; **la lista exacta y vigente está en
`EnrutadorRest.java`**, que es corto y se lee entero en un minuto. Léelo antes de afirmar que un
endpoint existe o no.

## Convención de DTOs

Estricta y sin excepciones hoy:

- **`Solicitud*`** para lo que entra: `SolicitudGuardarLinea`, `SolicitudResolverPendiente`,
  `SolicitudAccion`, `SolicitudEnviarCuenta`, `SolicitudNovedadesCuenta`, `SolicitudResolverEnMasa`.
- **`Respuesta*`** para lo que sale: `RespuestaCuenta`, `RespuestaDetalleLinea`, `RespuestaPaginada`,
  `RespuestaPaginaDesplazada`,
  `RespuestaAcciones`, `RespuestaMotivoPendiente`, `RespuestaResumenLinea`, `RespuestaResumenMotivo`,
  `RespuestaEstadoProceso`, `RespuestaFiltrosLineas`, `RespuestaNovedad`, `RespuestaTiquete`,
  `RespuestaResolucionMasiva`, `RespuestaMotivo`.

Un DTO nuevo que no empiece por `Solicitud` o `Respuesta` es un error de revisión.

**Los DTO viven en el punto de entrada, no en el dominio.** Son el contrato con el front y cambian a
su ritmo; las entidades de `dominio-modelo` cambian al ritmo del negocio. Mezclarlos acopla la UI al
dominio y es la forma más común de romper la hexagonal en este repo.

## Paginación: dos modelos, uno por problema

**Líneas — por desplazamiento.** `RespuestaPaginaDesplazada` (backend) ↔ `OffsetPage<T>` (front):

```
GET /api/v1/cuentas/{codigo}/lineas?pagina=0&tamano=25
→ { elementos: [...], desplazamiento: 0, tamanoPagina: 25, pagina: 0,
    totalRegistros: 4063|null, totalPaginas: 163|null, hayMas: true }
```

- **`pagina` y `tamano` son obligatorios.** No existe «tráemelo todo». `pagina` cuenta desde cero;
  también se admite `desplazamiento`, que es la posición exacta y manda si llegan los dos.
- **El fin de la colección es `hayMas === false`**, nunca la aritmética sobre el total.
- **`totalRegistros` y `totalPaginas` pueden llegar `null`**, y es información, no un fallo: significa
  que el filtro lleva un criterio que el sistema de registro no sabe aplicar (el catálogo de la
  prestación) y su cuenta sería de las filas de antes de descartar. Sin total, la pantalla navega con
  «siguiente» y no ofrece números de página.
- El orden es el **número de línea**, no el identificador.

**Pendientes — por cursor.** `RespuestaPaginada` (backend) ↔ `CursorPage<T>` (front), keyset:

```
GET /api/v1/cuentas/{codigo}/pendientes?tamano=50
→ { elementos: [...], cursorSiguiente: "abc"|null, totalRegistros: 1234|null, tamanoPagina: 50 }
```

Siguen así porque su listado son **dos recursos de OHI concatenados** (los pendientes de cabecera
como prefijo de los de línea) y un `offset` de OHI es por recurso.

### La regla que no cambió

**Nunca `offset` sobre un conjunto que se mueve.** Aguas arriba, para recorrer tablas globales —entran
unas mil cuentas al día— hay que paginar por `id.gt(cursor)` o se pierden filas sin dejar rastro. Lo
que se midió es que las líneas de **una** cuenta no son ese caso: solo cambian si el propio auditor las
edita, y a cambio el desplazamiento es lo único que permite ir a una página cualquiera y a la última.

## Reglas para cambiar el contrato

El contrato es lo único que comparten los dos repos, así que es donde se rompe la compatibilidad.

- **Primero el contrato, después las dos orillas.** Decide la forma del endpoint y de los DTO antes de
  escribir el adaptador del front o el caso de uso del backend. Si ambos se escriben a la vez contra
  una idea distinta del contrato, el error aparece en integración.
- **Añadir un campo opcional es compatible. Quitarlo, renombrarlo o volverlo obligatorio, no.** No hay
  versionado por encima de `/v1`, así que un cambio incompatible exige coordinar el despliegue de los
  dos repos. Eso convierte un cambio técnico en un cambio de planificación: decláralo.
- **Un endpoint nuevo que devuelva colección nace paginado.** Añadir paginación después obliga a tocar
  el front otra vez.
- **El nombre del caso de uso del front debería poder leerse en la ruta.** `consultar-cuenta` ↔
  `GET /cuentas/{codigo}`. Si no se puede, probablemente el endpoint está mal recortado.
