# Contexto 01 — `ms-auditoria-cuenta-medica` (backend)

Java 21 · Spring Boot 3.4.5 · **reactivo (Reactor / WebFlux)** · Gradle Groovy multi-módulo ·
paquete base `co.sura.auditoria`

## Mapa de módulos

Los módulos **no** se declaran a mano. `settings.gradle` recorre el árbol buscando `build.gradle` y
nombra cada módulo como `<capa>-<carpeta>`, donde la capa es el primer directorio bajo la raíz.
Por eso `infraestructura/adaptadores/acl-ohi` se llama `:infraestructura-acl-ohi` y no
`:infraestructura-adaptadores-acl-ohi`.

> **Consecuencia práctica:** crear un módulo nuevo es crear una carpeta con un `build.gradle`.
> No hay que tocar `settings.gradle`. Y renombrar una carpeta **renombra el módulo**, rompiendo
> todos los `project(':...')` que lo referencien.

```
dominio/
  modelo/            → :dominio-modelo          (sin dependencias: Java puro + Reactor)
    co/sura/auditoria/modelo/{auditoria,cuenta,error,puertos}
  casos-de-uso/      → :dominio-casos-de-uso    → dominio-modelo
    co/sura/auditoria/casodeuso
infraestructura/
  adaptadores/
    acl-ohi/              → :infraestructura-acl-ohi            → dominio-modelo
    bus-eventos/          → :infraestructura-bus-eventos        → dominio-modelo
    r2dbc-trazabilidad/   → :infraestructura-r2dbc-trazabilidad → dominio-modelo
    simulador-local/      → :infraestructura-simulador-local    → dominio-modelo
  puntos-de-entrada/
    web-reactiva/    → :infraestructura-web-reactiva  → dominio-modelo + dominio-casos-de-uso
aplicacion/
  servicio-app/      → :aplicacion-servicio-app       → TODOS (raíz de composición, el Spring Boot app)
```

## Las reglas de dependencia, y por qué

La regla es la de siempre en hexagonal, pero conviene decirla con los nombres de aquí:

1. **`dominio-modelo` no depende de nadie.** Ni de Spring, ni de Jackson, ni de otro módulo. Contiene
   las entidades, los errores de dominio y —sobre todo— los **puertos** (`modelo/puertos`), que son las
   interfaces que la infraestructura implementa.
2. **`dominio-casos-de-uso` solo depende de `dominio-modelo`.** Orquesta; no sabe si detrás hay OHI,
   Oracle o un simulador.
3. **Los adaptadores dependen de `dominio-modelo` y jamás entre sí.** Si `acl-ohi` necesita algo de
   `r2dbc-trazabilidad`, la respuesta correcta es un puerto en el dominio, no una dependencia directa.
4. **`aplicacion-servicio-app` lo conoce todo.** Es el único sitio donde se cablean las implementaciones
   a los puertos. Si una clase de configuración acaba en otro módulo, la hexagonal ya se rompió.

Nada de esto está verificado automáticamente. **ArchUnit ni siquiera está en el classpath**: solo
existe la constante `archunitVersion` en el `buildscript`, sin ninguna dependencia que la use. Hoy la
arquitectura se sostiene por disciplina y por revisión humana, punto.

## Lenguaje ubicuo: español, y dónde termina

El repo está casi íntegramente en español y esa consistencia es un activo que hay que defender.
Medido sobre las 165 clases de producción:

- **Los 27 paquetes están en español**, salvo los acrónimos `acl` y `api`, que se quedan como están.
- **Solo 11 clases llevan inglés en el nombre**, y 10 de ellas están en `acl/ohi/externo`.

La regla no es "traducirlo todo", es **dónde está la frontera**:

| Zona | Idioma | Por qué |
|---|---|---|
| `modelo`, `casodeuso`, `api/dto`, `persistencia`, `eventos`, `configuracion` | **español, sin excepción** | es el lenguaje del negocio de auditoría |
| `acl/ohi/externo` | **el vocabulario de OHI** (`OhiClaimItem`, `OhiSearchResponse`, `OhiPendReasonItem`…) | estos tipos espejan campo a campo el contrato del proveedor; traducirlos ocultaría a qué recurso de OHI corresponden |
| `acl/ohi/traductor` | **es la aduana** | aquí y solo aquí `claim` se vuelve `cuenta`, `pendReason` se vuelve `motivoPendiente` |

Que la ACL hable el idioma del proveedor en su borde **no** es una fuga de lenguaje ubicuo: es la ACL
haciendo su trabajo. La fuga sería que `OhiClaimItem` apareciera en `dominio-modelo` o en un DTO de
`api/dto`.

### Las inconsistencias reales que quedan (3)

| Clase | Problema | Debería ser |
|---|---|---|
| `CasosDeUsoConfig` | único `*Config` del repo; sus 5 hermanas son `ConfiguracionSeguridad`, `ConfiguracionCors`, `ConfiguracionResiliencia`, `ConfiguracionClienteOhi`, `ConfiguracionCacheToken` | `ConfiguracionCasosDeUso` |
| `OhiAccionRequest` | spanglish: mezcla las dos convenciones en un nombre | elegir un lado y mantenerlo |
| `OhiResolverPendientesRequest` | ídem | ídem |

Las otras ocho (`OhiClaimItem`, `OhiClaimLineItem`, `OhiMessageItem`, `OhiPendReasonItem`,
`OhiPersonItem`, `OhiProviderItem`, `OhiSearchResponse`, `OhiStatusResponse`) **están bien como
están**: son el contrato de OHI y deben seguir leyéndose como tal.

## Reactivo de verdad, no por accidente

Todo el camino es `Mono`/`Flux`. Consecuencias que hay que respetar al escribir código aquí:

- **Nunca `.block()`** fuera de una prueba. Bloquear en un hilo de Netty mata el event loop.
- **Nunca `Thread.sleep`** para espaciar llamadas; usa `delayElement` / `delaySubscription`.
- Los errores viajan como señal (`Mono.error`), no como excepción lanzada dentro del operador.
- El paralelismo contra OHI se limita a propósito: el cuello de botella es lo que el servicio tolera,
  no la CPU local.

## El adaptador que concentra el riesgo: `acl-ohi`

Es la capa anticorrupción contra OHI y es donde vive la complejidad real del sistema. Antes de tocarlo,
lee `contexto/05-ohi-trampas.md` entero — no es opcional: la mitad de sus reglas producen respuestas
**incorrectas sin ningún error**, que es la peor clase de fallo.

El patrón de token (OAuth2 client_credentials contra IDCS, Basic auth con `clientId:clientSecret`,
token cacheado, `expires_in=3600`) está en `ProveedorTokenOhi`, y este repo es **el proyecto de
referencia** del que copian los demás.

## Perfiles y arranque

Perfiles `dev` / `lab` / `prod`. Las variables van sufijadas (`OHI_CLIENT_SECRET_PROD`) y viven en
`.env` (gitignored). El perfil `local` usa `:infraestructura-simulador-local` y **no** declara
credenciales OHI: por eso los beans de configuración de OHI llevan `@Profile("!local")`.

> **Trampa documentada:** declarar `${VAR}` sin valor por omisión **no** rompe el arranque. El binder
> de `@ConfigurationProperties` resuelve marcadores con `ignoreUnresolvablePlaceholders = true`, así que
> una variable ausente deja el literal `${OHI_CLIENT_SECRET_PROD}` como contraseña y el fallo aparece
> tarde, como un **401 de IDCS**. Por eso `PropiedadesOhi` (que es un `record`) valida en su
> **constructor compacto** y rechaza vacíos y literales `${...}`. Si añades una propiedad obligatoria,
> añádele la validación: nadie más te va a avisar.

Arranque local sin base de datos (R2DBC/JDBC/Flyway excluidos), receta en `comandos/comandos.txt`:

```bash
cd ms-auditoria-cuenta-medica && set -a; source .env; set +a
./gradlew :aplicacion-servicio-app:bootRun --console=plain \
  --args="--spring.profiles.active=prod --spring.flyway.enabled=false --spring.main.lazy-initialization=true"
```

`spring.main.lazy-initialization=true` **no** difiere la creación de los `@ConfigurationProperties`:
la validación corta el arranque igual. Comprobado.

## Documentación que ya existe

`docs/ohi/` tiene 7 documentos y 4 anexos generados del propio API de OHI, más diagramas Mermaid
validados. **Es la fuente de verdad sobre OHI en este ecosistema.** Antes de investigar nada sobre
OHI desde cero, mira si ya está ahí.
