# Ecosistema de Auditoría de Cuentas Médicas — skills, contexto y agente

Conjunto de skills para **gobernar cualquier implementación nueva** entre
`sura-auditoria-frontend` y `ms-auditoria-cuenta-medica`, con
`937-ohi_arl_cuentasmedicas-ms` como vecino de consulta.



## Contenido

```
ecosistema-auditoria/
├── README.md                 este archivo
├── contexto/                 los hechos de los tres repos, medidos
│   ├── 00-ecosistema.md      los tres repos, cómo se hablan, deuda medida, entorno
│   ├── 01-ms-auditoria-cuenta-medica.md   módulos, reglas de dependencia, reactivo, perfiles
│   ├── 02-sura-auditoria-frontend.md      Nx, Clean Architecture, paginación por cursor
│   ├── 03-937-ohi-arl-cuentasmedicas-ms.md  el vecino y en qué se diferencia
│   ├── 04-contrato-api.md    el contrato front↔backend, endpoint por endpoint
│   ├── 05-ohi-trampas.md     las 13 trampas de OHI que devuelven mal sin dar error
│   ├── 06-pruebas.md         JUnit 5 + Mockito, los 6 casos obligatorios, el trinquete de cobertura
│   ├── 07-mvp-cuentas-medicas.md   el alcance del MVP: qué cumple hoy, qué falta y qué hay que decidir
│   ├── 08-mvp-requisitos.md  el catálogo de los 196 requisitos, uno por uno (SE GENERA)
│   └── 09-sdd.md             el ciclo: la especificación manda, y cómo se comprueba
├── especificacion/
│   ├── mvp-cuentas-medicas.yaml  LA FUENTE DE VERDAD: 196 requisitos con id y criterios
│   ├── consultar.py          pregúntale a la especificación
│   ├── trazabilidad.py       comprueba que lo dado por hecho tenga una prueba que lo cite
│   └── generar_catalogo.py   rehace contexto/08 desde el YAML
├── skills/
│   ├── auditoria-analista-negocio/SKILL.md
│   ├── auditoria-arquitecto/SKILL.md
│   ├── auditoria-lider-tecnico/SKILL.md
│   ├── auditoria-desarrollador/SKILL.md
│   └── auditoria-qa/SKILL.md
└── agente/
    └── auditoria-feature.md  encadena los cinco roles de punta a punta
```

## El flujo

Desde el 2026-10-16 el ecosistema trabaja por **SDD**: la especificación es un fichero con
identificadores y todo lo demás cuelga de ellos. El encargo no entra por la izquierda sin pasar antes
por la especificación. Ver `contexto/09-sdd.md`.

```
   encargo  ──►  ¿qué requisito es?  ──►  especificacion/mvp-cuentas-medicas.yaml
      │                                     (si no está y es del MVP, se añade ANTES)
      ▼
 1. analista de negocio  →  01-analisis.md      reglas verificadas contra OHI
      ▼                                          + criterios de aceptación comprobables
 2. arquitecto           →  02-arquitectura.md  dónde vive cada pieza + el contrato
      ▼
 3. líder técnico        →  03-plan.md          orden, qué NO entra, DoD, frenos
      ▼
 4. desarrollador        →  el código
      ▼
 5. QA                   →  05-pruebas.md       + las pruebas, cada una citando su `id`
      ▼
 cierre                  →  estado actualizado en el YAML + trazabilidad.py en verde
```

Los entregables van a `entregables/<feature>/`. Cada rol consume el del anterior: si falta, se pide
en vez de suponerlo.

## Cómo se usan

Invoca una skill suelta cuando sepas qué rol necesitas:

> *"usa auditoria-arquitecto: dónde va el filtro por prestador"*
> *"usa auditoria-qa: diseña las pruebas del envío de cuenta"*
> *"usa auditoria-analista-negocio: escribe los criterios de F3-ORD-02 a F3-ORD-07"*

O lanza el agente cuando quieras que alguien gobierne el encargo entero:

> *"@auditoria-feature: el auditor necesita resolver pendientes en masa desde la pantalla"*

### Para que Claude Code las descubra

Las skills se descubren en `.claude/skills/` y los agentes en `.claude/agents/`. Esta carpeta es la
**biblioteca**; para activarlas, enlázalas en el proyecto donde vayas a trabajar:

```bash
BIB=~/Documents/Proyectos/agents/ecosistema-auditoria
cd ~/Documents/Proyectos/ms-auditoria-cuenta-medica   # o sura-auditoria-frontend
mkdir -p .claude/skills .claude/agents
ln -sfn $BIB/skills/* .claude/skills/
ln -sfn $BIB/agente/auditoria-feature.md .claude/agents/
```

Mantenerlas en un solo sitio y enlazarlas evita que los dos repos se queden con copias que divergen.

## Qué tienen de particular

No son plantillas de roles. Cada regla sale de leer estos repos, y las que más pesan son las que
**ninguna máquina verifica hoy**:

- **El backend pasó de 0 pruebas a 66 ficheros, con trinquete de cobertura.** El classpath real es
  **JUnit 5 + Mockito + AssertJ + reactor-test**; ArchUnit, WireMock, Testcontainers y Cucumber siguen
  existiendo solo como constantes de versión en el `buildscript`, y no han hecho falta. Jacoco impone
  umbral por módulo encadenado a `check`: seis módulos al 1.00 y `acl-ohi` en 0.37, subiendo. El suelo
  nunca baja.
- **La hexagonal se sostiene por disciplina.** ArchUnit ni siquiera está en el classpath, así que
  nada impide que un adaptador importe otro o que un DTO se cuele en el dominio.
- **El lenguaje ubicuo es español, y la frontera está en la ACL.** Los 27 paquetes están en español
  y solo 11 clases llevan inglés — 10 de ellas a propósito, en `acl/ohi/externo`, porque espejan el
  contrato de OHI. Traducirlas sería peor; lo que no puede pasar es que salgan de ahí.
- **Dos regímenes de paginación, uno por problema.** Las líneas van por desplazamiento (para poder ir
  a cualquier página y a la última); los pendientes siguen por cursor, porque su listado son dos
  recursos de OHI concatenados. La regla de oro sigue siendo no usar `offset` sobre un conjunto que se
  mueve: OHI trunca en 200 sin avisar.
- **OHI falla callando.** Trece trampas documentadas que devuelven el dato equivocado con HTTP 200:
  el sobre `resource`, `defaultoverride`, campos no validados, `neq` que descarta nulos, booleanos
  con `"Y"` que devuelven el conjunto contrario…

## Mantenimiento

Los archivos de `contexto/` están medidos el **2026-10-15**. Envejecen: cuando el número de pruebas
del backend deje de ser 0, o cambie el contrato, hay que actualizarlos. La regla que llevan escrita
es que **si el contexto y el repo discrepan, gana el repo** — y corregir el contexto es parte del
trabajo que lo descubrió.
