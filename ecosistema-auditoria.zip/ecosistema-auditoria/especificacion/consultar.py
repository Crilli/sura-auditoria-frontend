#!/usr/bin/env python3
"""Pregunta a la especificación. Es lo primero que se hace ante cualquier encargo.

    python3 consultar.py glosa                 # requisitos cuyo texto menciona «glosa»
    python3 consultar.py F3-ORD-02             # uno concreto, entero, con sus criterios
    python3 consultar.py --bloque filtros      # todo un bloque
    python3 consultar.py --pendientes          # lo que falta, por bloque
    python3 consultar.py --bloqueados          # lo que espera una decisión de negocio
    python3 consultar.py --sin-criterios       # lo que todavía no se puede programar
"""
import argparse
import os
import sys
import unicodedata
from collections import Counter, defaultdict

import yaml

AQUI = os.path.dirname(os.path.abspath(__file__))
ESPEC = os.path.join(AQUI, 'mvp-cuentas-medicas.yaml')

ICONO = {'CUMPLE': '✅', 'PARCIAL': '🟡', 'NO_CUMPLE': '❌'}


def plano(t):
    """Sin tildes y en minúsculas, para que «glosa» encuentre «Glosado»."""
    t = unicodedata.normalize('NFD', (t or '').lower())
    return ''.join(c for c in t if unicodedata.category(c) != 'Mn')


def imprimir_corto(r):
    marca = '' if r['obligatorio'] else ' ◦'
    cand = ' 🔒' if r.get('bloqueado') else ''
    n = len(r.get('criterios') or [])
    crit = f' · {n} criterios' if n else ' · sin criterios'
    print(f"{ICONO.get(r['estado'], '?')} {r['id']:12s}{marca}{cand} {r['requisito'][:88]}{crit}")


def imprimir_largo(r, bloques):
    print(f"{ICONO.get(r['estado'], '?')} {r['id']}   [{bloques.get(r['bloque'], r['bloque'])}]"
          f"   {'obligatorio' if r['obligatorio'] else 'OPCIONAL'}")
    print(f"   {r['requisito']}")
    print()
    ev = r.get('evidencia') or {}
    if ev.get('backend'):
        print(f"   backend : {ev['backend']}")
    if ev.get('frontend'):
        print(f"   frontend: {ev['frontend']}")
    if r.get('falta'):
        print(f"   falta   : {r['falta']}")
    if r.get('riesgo_ohi'):
        print(f"   ⚠ OHI   : {r['riesgo_ohi']}")
    if r.get('bloqueado'):
        print(f"   🔒 BLOQUEADO: {r.get('pregunta_abierta', 'falta una decisión de negocio')}")
    if r.get('nombre_prueba'):
        print(f"   prueba sugerida: {r['nombre_prueba']}")
    print()
    for c in (r.get('criterios') or []):
        borde = ' ⟨borde⟩' if c.get('borde') else ''
        print(f"   · {c['id']} ({c['nivel']}){borde}")
        print(f"       Dado    {c['dado']}")
        print(f"       Cuando  {c['cuando']}")
        print(f"       Entonces {c['entonces']}")
    if not r.get('criterios'):
        print('   (sin criterios de aceptación: no se puede programar todavía)')
    print()


def main():
    p = argparse.ArgumentParser(description='Consulta la especificación del MVP')
    p.add_argument('texto', nargs='?', help='un identificador o un trozo de texto a buscar')
    p.add_argument('--bloque', help='clave del bloque')
    p.add_argument('--estado', choices=['CUMPLE', 'PARCIAL', 'NO_CUMPLE'])
    p.add_argument('--pendientes', action='store_true', help='resumen de lo que falta')
    p.add_argument('--bloqueados', action='store_true')
    p.add_argument('--sin-criterios', action='store_true')
    p.add_argument('--obligatorios', action='store_true', help='deja fuera lo opcional')
    args = p.parse_args()

    doc = yaml.safe_load(open(ESPEC, encoding='utf-8'))
    reqs, bloques = doc['requisitos'], doc['bloques']

    if args.pendientes:
        print('Lo que falta, por bloque')
        print('=' * 64)
        por = defaultdict(Counter)
        for r in reqs:
            por[r['bloque']][r['estado']] += 1
        for clave, titulo in bloques.items():
            c = por[clave]
            total = sum(c.values())
            falta = c['NO_CUMPLE'] + c['PARCIAL']
            if falta:
                print(f"{titulo:34s} {falta:3d} de {total:3d}  "
                      f"(❌ {c['NO_CUMPLE']} · 🟡 {c['PARCIAL']})")
        return 0

    seleccion = reqs
    if args.bloqueados:
        seleccion = [r for r in seleccion if r.get('bloqueado')]
    if args.sin_criterios:
        seleccion = [r for r in seleccion if not r.get('criterios')]
    if args.bloque:
        seleccion = [r for r in seleccion if r['bloque'] == args.bloque]
    if args.estado:
        seleccion = [r for r in seleccion if r['estado'] == args.estado]
    if args.obligatorios:
        seleccion = [r for r in seleccion if r['obligatorio']]

    if args.texto:
        exacto = [r for r in seleccion if r['id'].lower() == args.texto.lower()]
        if exacto:
            for r in exacto:
                imprimir_largo(r, bloques)
            return 0
        aguja = plano(args.texto)
        seleccion = [r for r in seleccion
                     if aguja in plano(r['requisito']) or aguja in plano(r['id'])
                     or aguja in plano(r.get('falta', ''))]

    for r in seleccion:
        imprimir_corto(r)
    print()
    c = Counter(r['estado'] for r in seleccion)
    print(f"{len(seleccion)} requisitos · ✅ {c['CUMPLE']} · 🟡 {c['PARCIAL']} · ❌ {c['NO_CUMPLE']}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
