#!/usr/bin/env python3
"""Genera `contexto/08-mvp-requisitos.md` a partir de la especificación.

La especificación (`mvp-cuentas-medicas.yaml`) es lo que se edita; el catálogo legible
es una vista. Si alguien edita el catálogo a mano, el siguiente que ejecute esto le pisa
el cambio — y así debe ser.

    python3 generar_catalogo.py
"""
import os
import sys
from collections import Counter, defaultdict

import yaml

AQUI = os.path.dirname(os.path.abspath(__file__))
ESPEC = os.path.join(AQUI, 'mvp-cuentas-medicas.yaml')
SALIDA = os.path.join(AQUI, '..', 'contexto', '08-mvp-requisitos.md')

ICONO = {'CUMPLE': '✅', 'PARCIAL': '🟡', 'NO_CUMPLE': '❌', 'NO_VERIFICABLE': '❔'}


def esc(t):
    return (t or '').replace('|', '\\|').replace('\n', ' ').strip()


def recortar(t, n):
    t = esc(t)
    return t if len(t) <= n else t[:n - 1].rstrip() + '…'


def main():
    doc = yaml.safe_load(open(ESPEC, encoding='utf-8'))
    reqs = doc['requisitos']
    bloques = doc['bloques']

    por_bloque = defaultdict(list)
    for r in reqs:
        por_bloque[r['bloque']].append(r)

    c = Counter(r['estado'] for r in reqs)
    con_criterios = sum(1 for r in reqs if r.get('criterios'))
    n_criterios = sum(len(r.get('criterios') or []) for r in reqs)
    bloqueados = [r for r in reqs if r.get('bloqueado')]
    verificados = sum(1 for r in reqs if r.get('verificado'))

    out = []
    w = out.append
    w('# Contexto 08 — Catálogo de requisitos del MVP, uno por uno')
    w('')
    w('> **Este fichero se genera.** La fuente es `especificacion/mvp-cuentas-medicas.yaml`; para')
    w('> cambiar un requisito se edita allí y se vuelve a ejecutar')
    w('> `python3 especificacion/generar_catalogo.py`. Ver [09-sdd.md](09-sdd.md).')
    w('')
    w('La lectura en prosa —el veredicto, las decisiones abiertas y lo medido contra OHI— está en')
    w('[07-mvp-cuentas-medicas.md](07-mvp-cuentas-medicas.md); **empieza por ahí**. Esto es el detalle.')
    w('')
    w(f"Auditado el {doc['auditoria']['fecha']}: **{len(reqs)} requisitos**, "
      f"{c['CUMPLE']} cumplidos, {c['PARCIAL']} a medias, {c['NO_CUMPLE']} sin empezar.")
    w(f'{verificados} afirmaciones pasaron por una verificación que intentaba tumbarlas.')
    w(f'**{con_criterios} requisitos tienen criterios de aceptación** ({n_criterios} criterios en total); '
      f'{len(bloqueados)} están bloqueados a la espera de una decisión de negocio.')
    w('')
    w('| | Significa |')
    w('|---|---|')
    w('| ✅ | Está hecho: el auditor lo ve o lo puede hacer hoy |')
    w('| 🟡 | A medias. La columna de la derecha dice qué le falta |')
    w('| ❌ | No existe en ninguna de las dos orillas |')
    w('| **Op.** | Desarrollo **opcional** (resaltado en amarillo en el documento original) |')
    w('| 🔒 | Bloqueado: no se pueden escribir criterios sin decidir algo antes |')
    w('')
    w('> La regla que separa ✅ de 🟡: que el dato **se pinte en una pantalla**. Un campo que viaja en')
    w('> el JSON y no se enseña no cumple un requisito de visualización.')
    w('')
    w('### Dos correcciones sobre lo que digan las notas de riesgo')
    w('')
    w('Algunas notas se apoyan en lo que OHI declara de sí mismo. En dos puntos **la medición')
    w('contradice la declaración**, y manda la medición:')
    w('')
    w('1. **`claimlines.valorGlosado` SÍ se filtra y SÍ se ordena**, aunque su `x-oi-searchable` diga')
    w('   que no. Comprobado: `gte(0)`→212, `gte(100000)`→50, `gte(571294)`→20, `gte(999999999)`→204.')
    w('2. **Los importes de tipo monto no se ordenan**: `claimedAmount`, `allowedAmount` y')
    w('   `coveredAmount` dan 500 en `orderBy`. Ese sí es un límite real.')
    w('')

    if bloqueados:
        w('## Lo que está bloqueado por una decisión de negocio')
        w('')
        w('No se pueden escribir criterios de aceptación sin responder a esto, y sin criterios no se')
        w('programa. Son las preguntas, tal cual hay que hacerlas:')
        w('')
        w('| Requisito | Pregunta |')
        w('|---|---|')
        for r in bloqueados:
            w(f"| `{r['id']}` | {recortar(r.get('pregunta_abierta', '—'), 220)} |")
        w('')

    for clave, titulo in bloques.items():
        lista = por_bloque.get(clave) or []
        if not lista:
            continue
        cb = Counter(r['estado'] for r in lista)
        w(f'## {titulo}')
        w('')
        w(f"{len(lista)} requisitos · ✅ {cb['CUMPLE']} · 🟡 {cb['PARCIAL']} · ❌ {cb['NO_CUMPLE']}")
        w('')
        w('| | ID | Requisito | Op. | Dónde está hoy / qué falta |')
        w('|---|---|---|---|---|')
        for r in lista:
            ev = r.get('evidencia') or {}
            if r['estado'] == 'CUMPLE':
                detalle = ev.get('frontend') or ev.get('backend') or ''
            else:
                detalle = r.get('falta') or ev.get('frontend') or ev.get('backend') or ''
            if r.get('riesgo_ohi'):
                detalle = (detalle + ' · ⚠ ' + r['riesgo_ohi']) if detalle else '⚠ ' + r['riesgo_ohi']
            marca = '◦' if not r['obligatorio'] else ''
            if r.get('bloqueado'):
                marca = (marca + ' 🔒').strip()
            w(f"| {ICONO.get(r['estado'], '❔')} | `{r['id']}` | {recortar(r['requisito'], 150)} "
              f"| {marca} | {recortar(detalle, 420)} |")
        w('')

        notas = (doc.get('notas_por_bloque') or {}).get(clave) or []
        if notas:
            w('**Lo que salió de paso en este bloque**')
            w('')
            for n in notas:
                w(f'- {recortar(n, 700)}')
            w('')

        conc = [r for r in lista if r.get('criterios')]
        if conc:
            w('<details><summary>Criterios de aceptación de este bloque</summary>')
            w('')
            for r in conc:
                w(f"**`{r['id']}`** · {esc(r['requisito'])}")
                if r.get('nombre_prueba'):
                    w(f"prueba sugerida: `{r['nombre_prueba']}`")
                w('')
                for cr in r['criterios']:
                    marca = ' ⟨borde⟩' if cr.get('borde') else ''
                    w(f"- **{cr['id']}** ({cr['nivel']}){marca}  ")
                    w(f"  *Dado* {esc(cr['dado'])}  ")
                    w(f"  *Cuando* {esc(cr['cuando'])}  ")
                    w(f"  *Entonces* {esc(cr['entonces'])}")
                w('')
            w('</details>')
            w('')

    with open(os.path.abspath(SALIDA), 'w', encoding='utf-8') as f:
        f.write('\n'.join(out) + '\n')
    print('escrito', os.path.abspath(SALIDA), '·', len(out), 'líneas')
    print(f'{len(reqs)} requisitos · {con_criterios} con criterios · {n_criterios} criterios')


if __name__ == '__main__':
    sys.exit(main())
