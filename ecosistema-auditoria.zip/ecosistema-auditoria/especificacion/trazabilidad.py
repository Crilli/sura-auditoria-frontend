#!/usr/bin/env python3
"""Comprueba que la especificación y el código se corresponden.

Es el cierre del ciclo de SDD: la especificación dice qué hay que cumplir, y esto
comprueba que lo que se dice cumplido **está comprobado por alguna prueba**.

Lo que mira, en orden de gravedad:

1. **Un requisito dado por hecho y sin prueba.** Si `estado` es CUMPLE o PARCIAL y
   ninguna prueba lo cita, nadie sabe si sigue siendo cierto mañana. Es la violación
   que importa: el resto del fichero es contabilidad.
2. **Una prueba que cita un requisito que no existe.** Un identificador mal escrito, o
   un requisito que se borró de la especificación y dejó la prueba huérfana.
3. **Un requisito sin criterios de aceptación.** No es una violación por sí sola
   —todavía hay 196 por escribir— pero sin criterios no se puede dar por hecho.

Cómo se cita un requisito desde una prueba:

    Java     @Tag("GRID-08")        sobre el @Test o sobre la clase
    vitest   it('[GRID-08] …')      el identificador entre corchetes en el nombre
    e2e      igual que vitest

En los dos casos el identificador acaba en el texto del fichero, que es lo que esto
busca. No hace falta nada más.

Uso:

    python3 trazabilidad.py                  # informe y salida 0/1
    python3 trazabilidad.py --detalle        # además, requisito por requisito
    python3 trazabilidad.py --minimo 0.25    # trinquete: falla por debajo de ese suelo
    python3 trazabilidad.py --json           # para un pipeline
"""
import argparse
import json
import os
import re
import sys
from collections import defaultdict

import yaml

AQUI = os.path.dirname(os.path.abspath(__file__))
ESPEC = os.path.join(AQUI, 'mvp-cuentas-medicas.yaml')
PROYECTOS = os.path.abspath(os.path.join(AQUI, '..', '..', '..'))

# Dónde viven las pruebas de cada repo. El backend es multi-módulo, así que el camino no
# es una carpeta fija sino cualquier ruta que pase por `src/test`.
FUENTES_DE_PRUEBA = [
    ('ms-auditoria-cuenta-medica', ('.java',), '/src/test/'),
    ('sura-auditoria-frontend', ('.spec.ts', '.e2e.ts'), None),
]
# Carpetas que no se miran nunca.
BASURA = {'build', 'node_modules', 'dist', '.git', '.gradle', '.nx', 'coverage'}

# Un identificador de requisito: letras, guiones y un número al final (BUS-01, F3-ORD-02,
# F2-11, BUS-F1-06). Se exige el guión y el número para no capturar constantes del código.
PATRON_ID = re.compile(r'\b([A-Z][A-Z0-9]{1,5}(?:-[A-Z0-9]{1,6}){1,3})\b')


def cargar_especificacion(ruta):
    with open(ruta, encoding='utf-8') as f:
        doc = yaml.safe_load(f)
    return doc, {r['id']: r for r in doc['requisitos']}


def ficheros_de_prueba(raices=None):
    """Todos los ficheros de prueba de los dos repos, con su ruta relativa legible."""
    for repo, extensiones, debe_contener in (raices or FUENTES_DE_PRUEBA):
        base = os.path.join(PROYECTOS, repo)
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, nombres in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in BASURA and not d.startswith('.')]
            for n in nombres:
                if not n.endswith(extensiones):
                    continue
                completo = os.path.join(dirpath, n)
                if debe_contener and debe_contener not in completo:
                    continue
                yield repo, os.path.relpath(completo, base), completo


def citas(ids_validos):
    """Qué prueba cita qué requisito, y qué citas no corresponden a nada."""
    por_requisito = defaultdict(list)
    huerfanas = []
    ficheros = 0
    for repo, relativo, completo in ficheros_de_prueba():
        ficheros += 1
        try:
            texto = open(completo, encoding='utf-8', errors='replace').read()
        except OSError:
            continue
        vistos = set()
        for m in PATRON_ID.finditer(texto):
            ident = m.group(1)
            if ident in vistos:
                continue
            vistos.add(ident)
            if ident in ids_validos:
                por_requisito[ident].append(f'{repo}/{relativo}')
            elif es_cita_explicita(texto, ident):
                huerfanas.append((f'{repo}/{relativo}', ident))
    return por_requisito, huerfanas, ficheros


def es_cita_explicita(texto, ident):
    """Distingue una cita de verdad de una constante del código que se le parece.

    Solo se considera cita si aparece como `@Tag("ID")` o entre corchetes, que son las
    dos formas que documenta el ciclo. Así una constante como `CLA-FL-PPRI-006` —un
    código de error de OHI que sale en varias pruebas— no se confunde con un requisito.
    """
    return bool(re.search(r'@Tag\(\s*"' + re.escape(ident) + r'"\s*\)', texto)
                or re.search(r'\[' + re.escape(ident) + r'\]', texto))


def analizar(espec, requisitos):
    por_requisito, huerfanas, n_ficheros = citas(set(requisitos))

    dados_por_hechos = [r for r in espec['requisitos'] if r['estado'] in ('CUMPLE', 'PARCIAL')]
    # Al revés: algo que la especificación da por no hecho y sin embargo tiene pruebas que lo
    # citan. No es un error —puede ser una prueba escrita por delante— pero casi siempre
    # significa que se implementó y nadie actualizó el estado.
    desactualizados = [r['id'] for r in espec['requisitos']
                       if r['estado'] == 'NO_CUMPLE' and por_requisito.get(r['id'])]
    sin_prueba = [r for r in dados_por_hechos if not por_requisito.get(r['id'])]
    sin_criterios = [r for r in espec['requisitos'] if not r.get('criterios')]
    cubiertos = len(dados_por_hechos) - len(sin_prueba)
    cobertura = cubiertos / len(dados_por_hechos) if dados_por_hechos else 1.0

    return {
        'ficheros_de_prueba': n_ficheros,
        'requisitos': len(espec['requisitos']),
        'dados_por_hechos': len(dados_por_hechos),
        'con_prueba': cubiertos,
        'cobertura': round(cobertura, 4),
        'sin_prueba': [r['id'] for r in sin_prueba],
        'citas_huerfanas': [{'fichero': f, 'id': i} for f, i in huerfanas],
        'sin_criterios': len(sin_criterios),
        'estado_desactualizado': desactualizados,
        'por_requisito': {k: v for k, v in sorted(por_requisito.items())},
    }


def informe(espec, requisitos, datos, detalle=False):
    print('Trazabilidad especificación ↔ pruebas')
    print('=' * 72)
    print(f"Requisitos en la especificación : {datos['requisitos']}")
    print(f"Ficheros de prueba examinados   : {datos['ficheros_de_prueba']}")
    print(f"Dados por hechos (CUMPLE/PARCIAL): {datos['dados_por_hechos']}")
    print(f"  …de ellos, con prueba que los cita: {datos['con_prueba']} "
          f"({datos['cobertura'] * 100:.1f} %)")
    print(f"Sin criterios de aceptación     : {datos['sin_criterios']}")
    print()

    if datos['citas_huerfanas']:
        print(f"❌ {len(datos['citas_huerfanas'])} citas a requisitos que no existen:")
        for c in datos['citas_huerfanas']:
            print(f"   {c['id']:14s} en {c['fichero']}")
        print()

    if datos['estado_desactualizado']:
        print(f"⚠ {len(datos['estado_desactualizado'])} requisitos en NO_CUMPLE que ya tienen prueba: "
              f"¿se implementaron y nadie actualizó el estado?")
        for ident in datos['estado_desactualizado']:
            print(f"   {ident:14s} {requisitos[ident]['requisito'][:58]}")
        print()

    if datos['por_requisito']:
        print(f"✅ {len(datos['por_requisito'])} requisitos comprobados por alguna prueba:")
        for ident, ficheros in datos['por_requisito'].items():
            r = requisitos[ident]
            print(f"   {ident:14s} {r['requisito'][:58]}")
            for f in ficheros:
                print(f"   {'':14s}   └ {f}")
        print()

    if detalle and datos['sin_prueba']:
        print(f"⚠ {len(datos['sin_prueba'])} dados por hechos sin ninguna prueba que los cite:")
        por_bloque = defaultdict(list)
        for ident in datos['sin_prueba']:
            por_bloque[requisitos[ident]['bloque']].append(ident)
        for bloque, ids in sorted(por_bloque.items()):
            print(f"   {espec['bloques'].get(bloque, bloque)}: {', '.join(ids)}")
        print()


def main():
    p = argparse.ArgumentParser(description='Trazabilidad de la especificación del MVP')
    p.add_argument('--especificacion', default=ESPEC)
    p.add_argument('--detalle', action='store_true', help='lista los requisitos sin prueba')
    p.add_argument('--json', action='store_true', help='salida para un pipeline')
    p.add_argument('--minimo', type=float, default=None, metavar='X',
                   help='suelo de cobertura entre 0 y 1; por debajo, salida distinta de cero')
    args = p.parse_args()

    espec, requisitos = cargar_especificacion(args.especificacion)
    datos = analizar(espec, requisitos)

    if args.json:
        print(json.dumps(datos, ensure_ascii=False, indent=1))
    else:
        informe(espec, requisitos, datos, detalle=args.detalle)

    # Una cita huérfana siempre es un error: o el identificador está mal escrito o el
    # requisito ya no existe. Las dos cosas hay que arreglarlas, no negociarlas.
    fallo = bool(datos['citas_huerfanas'])

    if args.minimo is not None and datos['cobertura'] < args.minimo:
        print(f"❌ Cobertura {datos['cobertura'] * 100:.1f} % por debajo del suelo "
              f"{args.minimo * 100:.1f} %", file=sys.stderr)
        fallo = True

    return 1 if fallo else 0


if __name__ == '__main__':
    sys.exit(main())
