"""Mete los criterios de aceptación en la especificación, ya pasados por el revisor.

PENDIENTE DE EJECUTAR. Los criterios se generaron el 2026-10-16 con un workflow de 22 agentes
(11 escriben, 11 revisan) que se quedó a mitad al agotarse el presupuesto de la sesión. Este
script lee su rastro —`journal.jsonl`, la ruta está abajo— y vuelca lo que haya en el YAML.

    python3 fusionar_criterios.py && python3 generar_catalogo.py && python3 trazabilidad.py

Si el rastro ya no existe, los criterios se vuelven a pedir: es el paso «escribir criterios»
del ciclo (contexto/09-sdd.md), y se puede hacer bloque a bloque.

Qué hace con lo que el revisor rechazó:
  - si propuso una versión corregida, la sustituye;
  - si no tenía arreglo porque falta una decisión de negocio, **quita el criterio** y marca el
    requisito como bloqueado. Un criterio inventado es peor que ninguno.
"""
import glob
import json
import sys

import yaml

J = glob.glob('/Users/criscaor/.claude/projects/-Users-criscaor-Documents-Proyectos/'
              '1ef9e6e1-8e60-4bb0-a6a6-46e21a9f10c0/subagents/workflows/wf_b21ee08c-146/journal.jsonl')
ESPEC = ('/Users/criscaor/Documents/Proyectos/agents/ecosistema-auditoria/'
         'especificacion/mvp-cuentas-medicas.yaml')

INTRUSOS = {'а': 'a', 'е': 'e', 'о': 'o', 'с': 'c', 'р': 'p'}


def limpiar(t):
    if not t:
        return ''
    for malo, bueno in INTRUSOS.items():
        t = t.replace(malo, bueno)
    return ' '.join(t.split())


def cargar_salida():
    """Empareja cada bloque de criterios con su revisión."""
    criterios, revisiones = [], []
    for ln in open(J[0], encoding='utf-8'):
        try:
            d = json.loads(ln)
        except Exception:
            continue
        if d.get('type') != 'result':
            continue
        r = d.get('result')
        if not isinstance(r, dict):
            continue
        if 'requisitos' in r:
            criterios.append(r)
        elif 'rechazos' in r:
            revisiones.append(r)
    return criterios, revisiones


def main():
    bloques, revisiones = cargar_salida()
    # Las revisiones no dicen de qué bloque son, pero sus rechazos citan criterios cuyo
    # identificador empieza por el del requisito, así que se indexan por criterio.
    rechazos, faltan = {}, {}
    for rev in revisiones:
        for x in rev.get('rechazos', []):
            rechazos[x['criterioId']] = x
        for x in rev.get('faltan', []):
            faltan.setdefault(x['requisitoId'], []).append(limpiar(x['queFalta']))

    por_id = {}
    for b in bloques:
        for r in b.get('requisitos', []):
            por_id[r['id']] = r

    with open(ESPEC, encoding='utf-8') as f:
        cabecera = ''.join(ln for ln in f if ln.startswith('#'))
    doc = yaml.safe_load(open(ESPEC, encoding='utf-8'))

    n_crit = n_sust = n_quit = n_bloq = 0
    for req in doc['requisitos']:
        salida = por_id.get(req['id'])
        if not salida:
            continue
        criterios = []
        for c in salida.get('criterios', []):
            rech = rechazos.get(c['id'])
            if rech:
                nuevo = rech.get('reescrito') or {}
                if limpiar(nuevo.get('entonces', '')):
                    c = {
                        'id': c['id'],
                        'dado': limpiar(nuevo.get('dado') or c['dado']),
                        'cuando': limpiar(nuevo.get('cuando') or c['cuando']),
                        'entonces': limpiar(nuevo.get('entonces')),
                        'nivel': nuevo.get('nivel') or c['nivel'],
                        'borde': c.get('borde', False),
                        'corregido_en_revision': True,
                    }
                    n_sust += 1
                else:
                    n_quit += 1
                    continue
            else:
                c = {
                    'id': c['id'],
                    'dado': limpiar(c['dado']),
                    'cuando': limpiar(c['cuando']),
                    'entonces': limpiar(c['entonces']),
                    'nivel': c['nivel'],
                    'borde': c.get('borde', False),
                }
            criterios.append(c)
            n_crit += 1

        req['criterios'] = criterios
        if salida.get('nombrePrueba'):
            req['nombre_prueba'] = salida['nombrePrueba']
        if salida.get('bloqueado'):
            req['bloqueado'] = True
            n_bloq += 1
            if salida.get('preguntaAbierta'):
                req['pregunta_abierta'] = limpiar(salida['preguntaAbierta'])
        if faltan.get(req['id']):
            req['revision_senala'] = faltan[req['id']]

    with open(ESPEC, 'w', encoding='utf-8') as f:
        f.write(cabecera)
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, width=100)

    sin = [r['id'] for r in doc['requisitos'] if not r.get('criterios')]
    print(f'criterios escritos : {n_crit}')
    print(f'  corregidos por el revisor : {n_sust}')
    print(f'  retirados por inventar regla: {n_quit}')
    print(f'requisitos bloqueados por falta de decisión: {n_bloq}')
    print(f'requisitos todavía sin criterios: {len(sin)}')
    if sin:
        print('  ', ', '.join(sin[:20]), '…' if len(sin) > 20 else '')


if __name__ == '__main__':
    sys.exit(main())
